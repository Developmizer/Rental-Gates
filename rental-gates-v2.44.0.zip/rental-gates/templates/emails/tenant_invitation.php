<?php
/**
 * Tenant Portal Invitation Email Template
 * 
 * Sent when inviting a tenant to access their portal.
 * 
 * Available variables:
 * - $tenant_name
 * - $organization_name
 * - $temp_password
 * - $login_url
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Your Tenant Portal is Ready! 🏠', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('Your tenant portal account has been created. You can now access your portal to manage everything related to your rental in one place.', 'rental-gates'); ?>
</p>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('What you can do in your portal:', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0; margin-bottom: 24px;">
    <tr>
        <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; color: #10b981; font-size: 18px;">✓</td>
                    <td style="color: #374151;"><?php _e('View your lease details and documents', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; color: #10b981; font-size: 18px;">✓</td>
                    <td style="color: #374151;"><?php _e('Make rent payments online', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; color: #10b981; font-size: 18px;">✓</td>
                    <td style="color: #374151;"><?php _e('Submit maintenance requests', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; color: #10b981; font-size: 18px;">✓</td>
                    <td style="color: #374151;"><?php _e('Communicate with management', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0 0 8px; font-weight: 600;">' . __('Your temporary password:', 'rental-gates') . '</p>' .
    '<p style="margin: 0; font-family: monospace; font-size: 20px; font-weight: 700; letter-spacing: 1px;">' . esc_html($temp_password ?? '********') . '</p>',
    'warning'
); ?>

<p style="margin: 0 0 24px; color: #dc2626; font-size: 14px; font-weight: 500;">
    ⚠️ <?php _e('Please change your password after your first login for security.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::button($login_url ?? home_url('/rental-gates/login'), __('Log In to Portal', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you didn\'t request this account or have any questions, please contact your property manager.', 'rental-gates'); ?>
</p>
