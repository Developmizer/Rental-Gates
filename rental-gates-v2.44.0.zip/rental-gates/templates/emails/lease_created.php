<?php
/**
 * Lease Created Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Your Lease Agreement is Ready! 📄', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('Your lease agreement has been prepared and is ready for your review.', 'rental-gates'); ?>
</p>

<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($property_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $property_name);
}
if (!empty($unit_name)) {
    echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name);
}
echo Rental_Gates_Email::detail_row(__('Lease Term', 'rental-gates'), ($start_date ?? '-') . ' - ' . ($end_date ?? '-'));
echo Rental_Gates_Email::detail_row(__('Monthly Rent', 'rental-gates'), '$' . number_format($rent_amount ?? 0, 2));
if (!empty($security_deposit)) {
    echo Rental_Gates_Email::detail_row(__('Security Deposit', 'rental-gates'), '$' . number_format($security_deposit, 2), true);
}
echo Rental_Gates_Email::details_table_end();
?>

<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0; font-size: 14px;">' .
    '<strong>' . __('Action Required:', 'rental-gates') . '</strong> ' .
    __('Please review and sign your lease agreement at your earliest convenience.', 'rental-gates') .
    '</p>',
    'warning'
); ?>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/tenant/leases'), __('Review & Sign Lease', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you have any questions about the lease terms, please contact your property manager before signing.', 'rental-gates'); ?>
</p>
