<?php
/**
 * Applications List Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Get applications
$args = array(
    'status' => $status_filter ?: null,
    'search' => $search ?: null,
    'orderby' => 'created_at',
    'order' => 'DESC',
);

$applications = Rental_Gates_Application::get_for_organization($org_id, $args);
$stats = Rental_Gates_Application::get_stats($org_id);

// Status labels and colors
$status_config = array(
    'new' => array('label' => __('New', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'screening' => array('label' => __('Screening', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'approved' => array('label' => __('Approved', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'withdrawn' => array('label' => __('Withdrawn', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'invited' => array('label' => __('Invited', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
);
?>

<style>
    .rg-apps-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    
    .rg-apps-header h1 {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0;
    }
    
    .rg-stats-row {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 16px;
        margin-bottom: 24px;
    }
    
    .rg-stat-card {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 16px 20px;
    }
    
    .rg-stat-card.highlight {
        border-color: #3b82f6;
        background: linear-gradient(135deg, #eff6ff 0%, #fff 100%);
    }
    
    .rg-stat-value {
        font-size: 28px;
        font-weight: 700;
        color: var(--gray-900);
    }
    
    .rg-stat-value.new { color: #3b82f6; }
    .rg-stat-value.pending { color: #f59e0b; }
    .rg-stat-value.approved { color: #10b981; }
    
    .rg-stat-label {
        font-size: 13px;
        color: var(--gray-500);
        margin-top: 4px;
    }
    
    .rg-filters-row {
        display: flex;
        gap: 12px;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }
    
    .rg-search-box {
        flex: 1;
        min-width: 200px;
        position: relative;
    }
    
    .rg-search-box input {
        width: 100%;
        padding: 10px 14px 10px 40px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
    }
    
    .rg-search-box svg {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray-400);
    }
    
    .rg-filter-select {
        padding: 10px 14px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
        min-width: 150px;
    }
    
    .rg-apps-table {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        overflow: hidden;
    }
    
    .rg-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .rg-table th {
        text-align: left;
        padding: 12px 16px;
        background: var(--gray-50);
        font-weight: 600;
        font-size: 12px;
        text-transform: uppercase;
        color: var(--gray-500);
        border-bottom: 1px solid var(--gray-200);
    }
    
    .rg-table td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--gray-100);
        font-size: 14px;
    }
    
    .rg-table tr:last-child td {
        border-bottom: none;
    }
    
    .rg-table tr:hover {
        background: var(--gray-50);
    }
    
    .rg-applicant-info {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .rg-applicant-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 14px;
    }
    
    .rg-applicant-details strong {
        display: block;
        color: var(--gray-900);
    }
    
    .rg-applicant-details span {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-unit-info {
        display: flex;
        flex-direction: column;
    }
    
    .rg-unit-info strong {
        color: var(--gray-900);
    }
    
    .rg-unit-info span {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .rg-status-badge .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
    }
    
    .rg-days-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 8px;
        background: #fef3c7;
        color: #92400e;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 500;
        margin-left: 6px;
    }
    
    .rg-table-actions {
        display: flex;
        gap: 8px;
    }
    
    .rg-table-action {
        padding: 6px 10px;
        border: 1px solid var(--gray-300);
        border-radius: 6px;
        background: #fff;
        color: var(--gray-600);
        font-size: 12px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    .rg-table-action:hover {
        background: var(--gray-50);
        border-color: var(--gray-400);
    }
    
    .rg-table-action.approve {
        border-color: #10b981;
        color: #10b981;
    }
    
    .rg-table-action.approve:hover {
        background: #d1fae5;
    }
    
    .rg-empty-state {
        text-align: center;
        padding: 60px 20px;
    }
    
    .rg-empty-state svg {
        color: var(--gray-300);
        margin-bottom: 16px;
    }
    
    .rg-empty-state h3 {
        font-size: 18px;
        color: var(--gray-700);
        margin-bottom: 8px;
    }
    
    .rg-empty-state p {
        color: var(--gray-500);
        margin-bottom: 20px;
    }
    
    @media (max-width: 1200px) {
        .rg-stats-row {
            grid-template-columns: repeat(3, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .rg-stats-row {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .rg-table-responsive {
            overflow-x: auto;
        }
        
        .rg-table {
            min-width: 700px;
        }
    }
</style>

<!-- Header -->
<div class="rg-apps-header">
    <h1><?php _e('Applications', 'rental-gates'); ?></h1>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card highlight">
        <div class="rg-stat-value new"><?php echo $stats['new']; ?></div>
        <div class="rg-stat-label"><?php _e('New Applications', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value pending"><?php echo $stats['screening']; ?></div>
        <div class="rg-stat-label"><?php _e('In Screening', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value approved"><?php echo $stats['approved']; ?></div>
        <div class="rg-stat-label"><?php _e('Approved', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['declined']; ?></div>
        <div class="rg-stat-label"><?php _e('Declined', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['total']; ?></div>
        <div class="rg-stat-label"><?php _e('Total', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" action="" class="rg-filters-row">
    <div class="rg-search-box">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <input type="text" name="search" placeholder="<?php _e('Search applicants...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
    </div>
    
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="new" <?php selected($status_filter, 'new'); ?>><?php _e('New', 'rental-gates'); ?></option>
        <option value="screening" <?php selected($status_filter, 'screening'); ?>><?php _e('Screening', 'rental-gates'); ?></option>
        <option value="approved" <?php selected($status_filter, 'approved'); ?>><?php _e('Approved', 'rental-gates'); ?></option>
        <option value="declined" <?php selected($status_filter, 'declined'); ?>><?php _e('Declined', 'rental-gates'); ?></option>
        <option value="withdrawn" <?php selected($status_filter, 'withdrawn'); ?>><?php _e('Withdrawn', 'rental-gates'); ?></option>
    </select>
    
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
</form>

<!-- Applications Table -->
<div class="rg-apps-table">
    <?php if (empty($applications)): ?>
    <div class="rg-empty-state">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
        </svg>
        <h3><?php _e('No applications found', 'rental-gates'); ?></h3>
        <p><?php _e('Applications will appear here when prospective tenants apply for your units.', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <div class="rg-table-responsive">
        <table class="rg-table">
            <thead>
                <tr>
                    <th><?php _e('Applicant', 'rental-gates'); ?></th>
                    <th><?php _e('Unit', 'rental-gates'); ?></th>
                    <th><?php _e('Submitted', 'rental-gates'); ?></th>
                    <th><?php _e('Status', 'rental-gates'); ?></th>
                    <th><?php _e('Actions', 'rental-gates'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $app): 
                    $status = $status_config[$app['status']] ?? $status_config['new'];
                    $initials = '';
                    $name_parts = explode(' ', $app['applicant_name']);
                    foreach ($name_parts as $part) {
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                    $initials = substr($initials, 0, 2);
                ?>
                <tr>
                    <td>
                        <div class="rg-applicant-info">
                            <div class="rg-applicant-avatar"><?php echo $initials; ?></div>
                            <div class="rg-applicant-details">
                                <strong><?php echo esc_html($app['applicant_name']); ?></strong>
                                <span><?php echo esc_html($app['applicant_email']); ?></span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="rg-unit-info">
                            <strong><?php echo esc_html($app['unit_name']); ?></strong>
                            <span><?php echo esc_html($app['building_name']); ?></span>
                        </div>
                    </td>
                    <td>
                        <?php 
                        if ($app['submitted_at']) {
                            echo date('M j, Y', strtotime($app['submitted_at']));
                            if ($app['days_pending'] > 0 && in_array($app['status'], array('new', 'screening'))) {
                                echo '<span class="rg-days-badge">' . sprintf(__('%d days', 'rental-gates'), $app['days_pending']) . '</span>';
                            }
                        } else {
                            echo '—';
                        }
                        ?>
                    </td>
                    <td>
                        <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                            <?php echo $status['label']; ?>
                        </span>
                    </td>
                    <td>
                        <div class="rg-table-actions">
                            <a href="<?php echo home_url('/rental-gates/dashboard/applications/' . $app['id']); ?>" class="rg-table-action">
                                <?php _e('View', 'rental-gates'); ?>
                            </a>
                            <?php if (in_array($app['status'], array('new', 'screening'))): ?>
                            <button type="button" class="rg-table-action approve" onclick="quickApprove(<?php echo $app['id']; ?>)">
                                <?php _e('Approve', 'rental-gates'); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
function quickApprove(appId) {
    if (!confirm('<?php _e('Approve this application?', 'rental-gates'); ?>')) return;
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_approve_application');
    formData.append('application_id', appId);
    formData.append('create_tenant', '1');
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.data || '<?php _e('Error approving application', 'rental-gates'); ?>');
            }
        });
}
</script>
