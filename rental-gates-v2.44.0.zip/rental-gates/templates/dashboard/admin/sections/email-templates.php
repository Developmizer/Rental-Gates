<?php
/**
 * Site Admin - Email Templates Section
 * 
 * View and customize email templates.
 */
if (!defined('ABSPATH')) exit;

// Get available templates
$template_dir = dirname(dirname(dirname(__FILE__))) . '/emails/';
$templates = array();

$template_info = array(
    'welcome' => array('name' => __('Welcome Email', 'rental-gates'), 'category' => 'account', 'description' => __('Sent when a new user registers', 'rental-gates')),
    'password_reset' => array('name' => __('Password Reset', 'rental-gates'), 'category' => 'account', 'description' => __('Sent when user requests password reset', 'rental-gates')),
    'tenant_invitation' => array('name' => __('Tenant Invitation', 'rental-gates'), 'category' => 'account', 'description' => __('Invite a tenant to create their account', 'rental-gates')),
    'staff_invitation' => array('name' => __('Staff Invitation', 'rental-gates'), 'category' => 'account', 'description' => __('Invite staff members to join', 'rental-gates')),
    'vendor_invitation' => array('name' => __('Vendor Invitation', 'rental-gates'), 'category' => 'account', 'description' => __('Invite vendors to the platform', 'rental-gates')),
    'application_received' => array('name' => __('Application Received', 'rental-gates'), 'category' => 'applications', 'description' => __('Confirm receipt of rental application', 'rental-gates')),
    'application_approved' => array('name' => __('Application Approved', 'rental-gates'), 'category' => 'applications', 'description' => __('Notify applicant of approval', 'rental-gates')),
    'application_declined' => array('name' => __('Application Declined', 'rental-gates'), 'category' => 'applications', 'description' => __('Notify applicant of decline', 'rental-gates')),
    'lease_created' => array('name' => __('Lease Created', 'rental-gates'), 'category' => 'leases', 'description' => __('New lease ready for signature', 'rental-gates')),
    'lease_ending' => array('name' => __('Lease Ending Soon', 'rental-gates'), 'category' => 'leases', 'description' => __('Reminder that lease is ending', 'rental-gates')),
    'payment_receipt' => array('name' => __('Payment Receipt', 'rental-gates'), 'category' => 'payments', 'description' => __('Confirm successful payment', 'rental-gates')),
    'payment_reminder' => array('name' => __('Payment Reminder', 'rental-gates'), 'category' => 'payments', 'description' => __('Remind tenant of upcoming payment', 'rental-gates')),
    'payment_overdue' => array('name' => __('Payment Overdue', 'rental-gates'), 'category' => 'payments', 'description' => __('Notify tenant of overdue payment', 'rental-gates')),
    'maintenance_created' => array('name' => __('Maintenance Created', 'rental-gates'), 'category' => 'maintenance', 'description' => __('Confirm maintenance request received', 'rental-gates')),
    'maintenance_update' => array('name' => __('Maintenance Update', 'rental-gates'), 'category' => 'maintenance', 'description' => __('Status update on maintenance request', 'rental-gates')),
    'maintenance_completed' => array('name' => __('Maintenance Completed', 'rental-gates'), 'category' => 'maintenance', 'description' => __('Notify that work is complete', 'rental-gates')),
    'vendor_assignment' => array('name' => __('Vendor Assignment', 'rental-gates'), 'category' => 'maintenance', 'description' => __('Notify vendor of new work order', 'rental-gates')),
    'announcement' => array('name' => __('Announcement', 'rental-gates'), 'category' => 'communications', 'description' => __('General announcement to tenants', 'rental-gates')),
    'message_received' => array('name' => __('Message Received', 'rental-gates'), 'category' => 'communications', 'description' => __('Notify of new message', 'rental-gates')),
    'lead_inquiry' => array('name' => __('Lead Inquiry', 'rental-gates'), 'category' => 'leads', 'description' => __('Confirm lead form submission', 'rental-gates')),
);

// Scan for templates
if (is_dir($template_dir)) {
    $files = glob($template_dir . '*.php');
    foreach ($files as $file) {
        $name = basename($file, '.php');
        if ($name !== 'index' && $name !== 'generic') {
            $templates[$name] = array_merge(
                array('file' => $file, 'exists' => true),
                $template_info[$name] ?? array('name' => ucwords(str_replace('_', ' ', $name)), 'category' => 'other', 'description' => '')
            );
        }
    }
}

// Group by category
$categories = array(
    'account' => __('Account', 'rental-gates'),
    'applications' => __('Applications', 'rental-gates'),
    'leases' => __('Leases', 'rental-gates'),
    'payments' => __('Payments', 'rental-gates'),
    'maintenance' => __('Maintenance', 'rental-gates'),
    'communications' => __('Communications', 'rental-gates'),
    'leads' => __('Leads', 'rental-gates'),
    'other' => __('Other', 'rental-gates'),
);

$grouped = array();
foreach ($templates as $key => $template) {
    $cat = $template['category'] ?? 'other';
    if (!isset($grouped[$cat])) $grouped[$cat] = array();
    $grouped[$cat][$key] = $template;
}

// Preview template
$preview_template = isset($_GET['preview']) ? sanitize_file_name($_GET['preview']) : null;
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Email Templates', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <div class="alert alert-info mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <div>
            <?php _e('Email templates are PHP files located in', 'rental-gates'); ?> 
            <code style="background: rgba(0,0,0,0.1); padding: 2px 6px; border-radius: 4px;">/templates/emails/</code>.
            <?php _e('All templates use responsive design with inline CSS.', 'rental-gates'); ?>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <!-- Template List -->
        <div>
            <?php foreach ($grouped as $category => $cat_templates): ?>
            <?php if (empty($cat_templates)) continue; ?>
            <div class="card mb-6">
                <div class="card-header">
                    <h2 class="card-title"><?php echo esc_html($categories[$category] ?? $category); ?></h2>
                </div>
                <div class="card-body" style="padding: 0;">
                    <?php foreach ($cat_templates as $key => $template): ?>
                    <div style="padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; align-items: center; justify-content: space-between; <?php echo $preview_template === $key ? 'background: var(--info-light);' : ''; ?>">
                        <div>
                            <div style="font-weight: 500; color: var(--gray-900);"><?php echo esc_html($template['name']); ?></div>
                            <div style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($template['description']); ?></div>
                        </div>
                        <a href="<?php echo home_url('/rental-gates/admin/email-templates?preview=' . $key); ?>" class="btn btn-sm btn-outline">
                            <?php _e('Preview', 'rental-gates'); ?>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Preview Panel -->
        <div>
            <div class="card" style="position: sticky; top: 100px;">
                <div class="card-header">
                    <h2 class="card-title">
                        <?php if ($preview_template && isset($templates[$preview_template])): ?>
                            <?php echo esc_html($templates[$preview_template]['name']); ?>
                        <?php else: ?>
                            <?php _e('Template Preview', 'rental-gates'); ?>
                        <?php endif; ?>
                    </h2>
                </div>
                <div class="card-body">
                    <?php if ($preview_template && isset($templates[$preview_template])): ?>
                        <div style="background: var(--gray-100); border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                            <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                                <span style="font-weight: 500; color: var(--gray-500); width: 60px;"><?php _e('File:', 'rental-gates'); ?></span>
                                <code style="font-size: 12px;"><?php echo esc_html(basename($templates[$preview_template]['file'])); ?></code>
                            </div>
                            <div style="display: flex; gap: 12px;">
                                <span style="font-weight: 500; color: var(--gray-500); width: 60px;"><?php _e('Category:', 'rental-gates'); ?></span>
                                <span><?php echo esc_html($categories[$templates[$preview_template]['category']] ?? 'Other'); ?></span>
                            </div>
                        </div>
                        
                        <div style="border: 1px solid var(--gray-200); border-radius: 8px; overflow: hidden;">
                            <div style="background: var(--gray-50); padding: 12px 16px; border-bottom: 1px solid var(--gray-200); font-size: 12px;">
                                <strong><?php _e('To:', 'rental-gates'); ?></strong> recipient@example.com<br>
                                <strong><?php _e('Subject:', 'rental-gates'); ?></strong> <?php echo esc_html($templates[$preview_template]['name']); ?>
                            </div>
                            <div style="height: 500px; overflow: auto; background: #fff;">
                                <?php
                                // Render preview with sample data
                                $sample_data = array(
                                    'user_name' => 'John Doe',
                                    'first_name' => 'John',
                                    'property_name' => 'Sunset Apartments',
                                    'property_address' => '123 Main Street, Apt 4B',
                                    'unit_number' => '4B',
                                    'rent_amount' => '$1,500.00',
                                    'due_date' => date('F j, Y', strtotime('+5 days')),
                                    'payment_amount' => '$1,500.00',
                                    'payment_date' => date('F j, Y'),
                                    'lease_start' => date('F j, Y'),
                                    'lease_end' => date('F j, Y', strtotime('+1 year')),
                                    'request_title' => 'Leaky Faucet in Kitchen',
                                    'request_status' => 'In Progress',
                                    'login_url' => home_url('/rental-gates/login'),
                                    'reset_url' => home_url('/rental-gates/reset-password?key=sample'),
                                    'action_url' => home_url('/rental-gates/dashboard'),
                                    'dashboard_url' => home_url('/rental-gates/dashboard'),
                                );
                                
                                // Extract variables
                                extract($sample_data);
                                
                                // Capture output
                                ob_start();
                                @include $templates[$preview_template]['file'];
                                $preview_html = ob_get_clean();
                                
                                if (empty($preview_html)) {
                                    echo '<div style="padding: 40px; text-align: center; color: var(--gray-500);">';
                                    _e('Preview not available. Template may require specific data.', 'rental-gates');
                                    echo '</div>';
                                } else {
                                    echo $preview_html;
                                }
                                ?>
                            </div>
                        </div>
                        
                        <div style="margin-top: 16px; display: flex; gap: 12px;">
                            <a href="<?php echo admin_url('plugin-editor.php?file=rental-gates/templates/emails/' . $preview_template . '.php&plugin=rental-gates/rental-gates.php'); ?>" class="btn btn-secondary" target="_blank">
                                <?php _e('Edit in WordPress', 'rental-gates'); ?>
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                            <h3><?php _e('Select a template', 'rental-gates'); ?></h3>
                            <p><?php _e('Click Preview on any template to see it here.', 'rental-gates'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
