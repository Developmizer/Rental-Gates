<?php
/**
 * Site Admin - Enhanced Dashboard Section
 * 
 * Comprehensive platform overview with analytics, charts, and quick actions.
 * 
 * @package Rental_Gates
 * @version 2.27.0
 */
if (!defined('ABSPATH'))
    exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Helper functions
if (!function_exists('rg_admin_safe_count')) {
    function rg_admin_safe_count($table, $where = '')
    {
        global $wpdb;
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if (!$table_exists)
            return 0;
        $query = "SELECT COUNT(*) FROM {$table}";
        if ($where)
            $query .= " WHERE {$where}";
        $result = $wpdb->get_var($query);
        return $result !== null ? intval($result) : 0;
    }
}

if (!function_exists('rg_admin_safe_sum')) {
    function rg_admin_safe_sum($table, $column, $where = '')
    {
        global $wpdb;
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if (!$table_exists)
            return 0;
        $query = "SELECT COALESCE(SUM({$column}), 0) FROM {$table}";
        if ($where)
            $query .= " WHERE {$where}";
        $result = $wpdb->get_var($query);
        return $result !== null ? floatval($result) : 0;
    }
}

// ============================================
// GATHER ALL STATISTICS
// ============================================

// Organization Stats
$total_orgs = rg_admin_safe_count($tables['organizations']);
$active_orgs = rg_admin_safe_count($tables['organizations'], "status = 'active'");
$suspended_orgs = rg_admin_safe_count($tables['organizations'], "status = 'suspended'");
$trial_orgs = rg_admin_safe_count($tables['organizations'], "status = 'trial'");
$new_orgs_today = rg_admin_safe_count($tables['organizations'], "DATE(created_at) = CURDATE()");
$new_orgs_week = rg_admin_safe_count($tables['organizations'], "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$new_orgs_month = rg_admin_safe_count($tables['organizations'], "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");

// Property Stats
$total_buildings = rg_admin_safe_count($tables['buildings']);
$total_units = rg_admin_safe_count($tables['units']);
$occupied_units = rg_admin_safe_count($tables['units'], "availability = 'occupied'");
$available_units = rg_admin_safe_count($tables['units'], "availability = 'available'");
$occupancy_rate = $total_units > 0 ? round(($occupied_units / $total_units) * 100, 1) : 0;

// People Stats
$total_tenants = rg_admin_safe_count($tables['tenants']);
$total_vendors = rg_admin_safe_count($tables['vendors']);
$active_leases = rg_admin_safe_count($tables['leases'], "status = 'active'");
$expiring_leases = rg_admin_safe_count($tables['leases'], "status = 'active' AND end_date <= DATE_ADD(NOW(), INTERVAL 30 DAY)");

// Financial Stats
$total_revenue = rg_admin_safe_sum($tables['payments'], 'amount', "status = 'completed'");
$this_month = rg_admin_safe_sum(
    $tables['payments'],
    'amount',
    "status = 'completed' AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())"
);
$last_month = rg_admin_safe_sum(
    $tables['payments'],
    'amount',
    "status = 'completed' AND MONTH(created_at) = MONTH(DATE_SUB(NOW(), INTERVAL 1 MONTH)) AND YEAR(created_at) = YEAR(DATE_SUB(NOW(), INTERVAL 1 MONTH))"
);
$today_revenue = rg_admin_safe_sum($tables['payments'], 'amount', "status = 'completed' AND DATE(created_at) = CURDATE()");
$pending_payments = rg_admin_safe_sum($tables['payments'], 'amount', "status = 'pending'");
$failed_payments = rg_admin_safe_count($tables['payments'], "status = 'failed' AND DATE(created_at) >= DATE_SUB(NOW(), INTERVAL 7 DAY)");

// Growth calculations
$revenue_growth = $last_month > 0 ? round((($this_month - $last_month) / $last_month) * 100, 1) : 0;

// Subscription/MRR Stats
$mrr = rg_admin_safe_sum($tables['subscriptions'], 'amount', "status = 'active'");
$active_subscriptions = rg_admin_safe_count($tables['subscriptions'], "status = 'active'");
$churned_this_month = rg_admin_safe_count(
    $tables['subscriptions'],
    "status = 'cancelled' AND MONTH(updated_at) = MONTH(NOW()) AND YEAR(updated_at) = YEAR(NOW())"
);
$churn_rate = $active_subscriptions > 0 ? round(($churned_this_month / $active_subscriptions) * 100, 1) : 0;

// Activity Stats
$pending_applications = rg_admin_safe_count($tables['applications'], "status = 'pending'");
$open_work_orders = rg_admin_safe_count($tables['work_orders'], "status IN ('new', 'assigned', 'in_progress')");
$new_leads_week = rg_admin_safe_count($tables['leads'], "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");

// Monthly revenue data for chart (last 6 months)
$monthly_revenue = array();
for ($i = 5; $i >= 0; $i--) {
    $date = date('Y-m', strtotime("-{$i} months"));
    $month_name = date('M', strtotime("-{$i} months"));
    $amount = rg_admin_safe_sum(
        $tables['payments'],
        'amount',
        "status = 'completed' AND DATE_FORMAT(created_at, '%Y-%m') = '{$date}'"
    );
    $monthly_revenue[] = array('month' => $month_name, 'amount' => $amount);
}

// Signups data for chart (last 6 months)
$monthly_signups = array();
for ($i = 5; $i >= 0; $i--) {
    $date = date('Y-m', strtotime("-{$i} months"));
    $month_name = date('M', strtotime("-{$i} months"));
    $count = rg_admin_safe_count(
        $tables['organizations'],
        "DATE_FORMAT(created_at, '%Y-%m') = '{$date}'"
    );
    $monthly_signups[] = array('month' => $month_name, 'count' => $count);
}

// Recent organizations
$recent_orgs = $wpdb->get_results(
    "SELECT o.*, 
            (SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = o.id) as building_count,
            (SELECT COUNT(*) FROM {$tables['units']} u 
             JOIN {$tables['buildings']} b ON u.building_id = b.id 
             WHERE b.organization_id = o.id) as unit_count,
            (SELECT name FROM {$tables['plans']} WHERE id = o.plan_id) as plan_name
     FROM {$tables['organizations']} o
     ORDER BY o.created_at DESC
     LIMIT 5",
    ARRAY_A
) ?: array();

// Recent payments
$recent_payments = $wpdb->get_results(
    "SELECT p.*, o.name as org_name
     FROM {$tables['payments']} p
     LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     LEFT JOIN {$tables['organizations']} o ON b.organization_id = o.id
     ORDER BY p.created_at DESC
     LIMIT 5",
    ARRAY_A
) ?: array();

// Recent activity
$recent_activity = $wpdb->get_results(
    "SELECT a.*, u.display_name as user_name
     FROM {$tables['activity_log']} a
     LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
     ORDER BY a.created_at DESC
     LIMIT 8",
    ARRAY_A
) ?: array();

// System health
$php_version = phpversion();
$wp_version = get_bloginfo('version');
$db_version = $wpdb->db_version();
$plugin_version = RENTAL_GATES_VERSION;
$memory_limit = ini_get('memory_limit');
$memory_usage = round(memory_get_usage() / 1024 / 1024, 1);
$upload_max = ini_get('upload_max_filesize');

// Check for issues
$health_status = 'healthy';
$issues = array();

if (version_compare($php_version, '7.4', '<')) {
    $issues[] = array('type' => 'warning', 'message' => __('PHP version is below recommended 7.4', 'rental-gates'));
    $health_status = 'warning';
}
if (!extension_loaded('gd') && !extension_loaded('imagick')) {
    $issues[] = array('type' => 'warning', 'message' => __('Image processing extension (GD/Imagick) not installed', 'rental-gates'));
    $health_status = 'warning';
}
if (!is_writable(wp_upload_dir()['basedir'])) {
    $issues[] = array('type' => 'danger', 'message' => __('Upload directory is not writable', 'rental-gates'));
    $health_status = 'critical';
}
if (!is_ssl()) {
    $issues[] = array('type' => 'danger', 'message' => __('HTTPS is not enabled', 'rental-gates'));
    $health_status = 'critical';
}
if ($failed_payments > 0) {
    $issues[] = array('type' => 'warning', 'message' => sprintf(__('%d failed payments in the last 7 days', 'rental-gates'), $failed_payments));
}
if ($expiring_leases > 5) {
    $issues[] = array('type' => 'info', 'message' => sprintf(__('%d leases expiring in the next 30 days', 'rental-gates'), $expiring_leases));
}

// Get activity icons
function get_activity_icon($action)
{
    $icons = array(
        'login' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>',
        'logout' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>',
        'created' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>',
        'updated' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>',
        'deleted' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>',
        'payment' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>',
        'default' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    );

    foreach ($icons as $key => $path) {
        if (stripos($action, $key) !== false) {
            return $path;
        }
    }
    return $icons['default'];
}
?>

<style>
    /* Enhanced Dashboard Styles */
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 24px;
    }

    .metric-card {
        background: #fff;
        border-radius: 12px;
        padding: 20px;
        border: 1px solid var(--gray-200);
        transition: all 0.2s;
    }

    .metric-card:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        transform: translateY(-2px);
    }

    .metric-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
    }

    .metric-icon {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .metric-icon svg {
        width: 24px;
        height: 24px;
        stroke: currentColor;
    }

    .metric-icon.blue {
        background: #dbeafe;
        color: #2563eb;
    }

    .metric-icon.green {
        background: #d1fae5;
        color: #059669;
    }

    .metric-icon.purple {
        background: #ede9fe;
        color: #7c3aed;
    }

    .metric-icon.orange {
        background: #ffedd5;
        color: #ea580c;
    }

    .metric-icon.red {
        background: #fee2e2;
        color: #dc2626;
    }

    .metric-icon.indigo {
        background: #e0e7ff;
        color: #4f46e5;
    }

    .metric-icon.teal {
        background: #ccfbf1;
        color: #0d9488;
    }

    .metric-icon.pink {
        background: #fce7f3;
        color: #db2777;
    }

    .metric-trend {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 12px;
        font-weight: 500;
        padding: 4px 8px;
        border-radius: 20px;
    }

    .metric-trend.up {
        background: #d1fae5;
        color: #059669;
    }

    .metric-trend.down {
        background: #fee2e2;
        color: #dc2626;
    }

    .metric-trend.neutral {
        background: #f3f4f6;
        color: #6b7280;
    }

    .metric-trend svg {
        width: 14px;
        height: 14px;
    }

    .metric-value {
        font-size: 32px;
        font-weight: 700;
        color: var(--gray-900);
        line-height: 1;
        margin-bottom: 4px;
    }

    .metric-label {
        font-size: 14px;
        color: var(--gray-500);
    }

    .metric-sub {
        font-size: 12px;
        color: var(--gray-400);
        margin-top: 8px;
    }

    /* Charts */
    .chart-container {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        padding: 20px;
    }

    .chart-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .chart-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--gray-900);
    }

    .chart-legend {
        display: flex;
        gap: 16px;
        font-size: 12px;
    }

    .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--gray-600);
    }

    .legend-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }

    .bar-chart {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        height: 200px;
        padding-top: 20px;
        border-bottom: 1px solid var(--gray-200);
    }

    .bar-group {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex: 1;
        max-width: 60px;
    }

    .bar {
        width: 32px;
        background: linear-gradient(180deg, #6366f1 0%, #4f46e5 100%);
        border-radius: 4px 4px 0 0;
        transition: all 0.3s;
        cursor: pointer;
        min-height: 4px;
    }

    .bar:hover {
        background: linear-gradient(180deg, #818cf8 0%, #6366f1 100%);
        transform: scaleY(1.02);
    }

    .bar-label {
        font-size: 11px;
        color: var(--gray-500);
        margin-top: 8px;
        font-weight: 500;
    }

    .bar-value {
        font-size: 10px;
        color: var(--gray-400);
        margin-top: 2px;
    }

    /* Quick Actions */
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 24px;
    }

    .quick-action-btn {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 10px;
        text-decoration: none;
        color: var(--gray-700);
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s;
    }

    .quick-action-btn:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: #f5f3ff;
    }

    .quick-action-btn svg {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
    }

    /* Status Indicator */
    .status-indicator {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .status-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        animation: pulse 2s infinite;
    }

    .status-dot.healthy {
        background: #10b981;
    }

    .status-dot.warning {
        background: #f59e0b;
    }

    .status-dot.critical {
        background: #ef4444;
    }

    @keyframes pulse {

        0%,
        100% {
            opacity: 1;
        }

        50% {
            opacity: 0.5;
        }
    }

    /* Two Column Layout */
    .dashboard-columns {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 24px;
        margin-bottom: 24px;
    }

    /* Activity Feed */
    .activity-feed {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
    }

    .activity-item {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 14px 20px;
        border-bottom: 1px solid var(--gray-100);
    }

    .activity-item:last-child {
        border-bottom: none;
    }

    .activity-icon {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        background: var(--gray-100);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .activity-icon svg {
        width: 18px;
        height: 18px;
        stroke: var(--gray-500);
    }

    .activity-content {
        flex: 1;
        min-width: 0;
    }

    .activity-text {
        font-size: 14px;
        color: var(--gray-700);
        line-height: 1.4;
    }

    .activity-text strong {
        color: var(--gray-900);
    }

    .activity-time {
        font-size: 12px;
        color: var(--gray-400);
        margin-top: 2px;
    }

    /* Table Improvements */
    .mini-table {
        width: 100%;
    }

    .mini-table th {
        padding: 10px 16px;
        text-align: left;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--gray-500);
        background: var(--gray-50);
        border-bottom: 1px solid var(--gray-200);
    }

    .mini-table td {
        padding: 12px 16px;
        font-size: 14px;
        border-bottom: 1px solid var(--gray-100);
    }

    .mini-table tr:last-child td {
        border-bottom: none;
    }

    .mini-table tr:hover td {
        background: var(--gray-50);
    }

    /* Responsive */
    @media (max-width: 1200px) {
        .dashboard-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .dashboard-columns {
            grid-template-columns: 1fr;
        }

        .quick-actions {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 768px) {
        .dashboard-grid {
            grid-template-columns: 1fr;
        }

        .quick-actions {
            grid-template-columns: 1fr;
        }
    }
</style>

<header class="admin-header">
    <div>
        <h1 class="header-title"><?php _e('Platform Dashboard', 'rental-gates'); ?></h1>
        <p style="color: var(--gray-500); font-size: 14px; margin-top: 4px;">
            <?php echo sprintf(__('Welcome back! Here\'s what\'s happening on %s.', 'rental-gates'), date('l, F j, Y')); ?>
        </p>
    </div>
    <div class="header-actions">
        <div class="status-indicator">
            <span class="status-dot <?php echo esc_attr($health_status); ?>"></span>
            <span style="font-size: 14px; color: var(--gray-600);">
                <?php
                if ($health_status === 'healthy')
                    echo __('All Systems Operational', 'rental-gates');
                elseif ($health_status === 'warning')
                    echo __('Minor Issues', 'rental-gates');
                else
                    echo __('Attention Required', 'rental-gates');
                ?>
            </span>
        </div>
        <a href="<?php echo home_url('/rental-gates/admin/organizations?action=new'); ?>"
            class="header-btn header-btn-primary">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
            </svg>
            <?php _e('New Organization', 'rental-gates'); ?>
        </a>
    </div>
</header>

<div class="admin-content">
    <!-- System Alerts -->
    <?php if (!empty($issues)): ?>
        <div class="alert alert-<?php echo $health_status === 'critical' ? 'danger' : 'warning'; ?>"
            style="margin-bottom: 24px;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div>
                <strong><?php _e('Attention Required', 'rental-gates'); ?></strong>
                <ul style="margin: 8px 0 0; padding-left: 20px; font-size: 14px;">
                    <?php foreach (array_slice($issues, 0, 3) as $issue): ?>
                        <li><?php echo esc_html($issue['message']); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php if (count($issues) > 3): ?>
                    <a href="<?php echo home_url('/rental-gates/admin/system'); ?>"
                        style="color: inherit; margin-top: 8px; display: inline-block;">
                        <?php echo sprintf(__('+ %d more issues', 'rental-gates'), count($issues) - 3); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <a href="<?php echo home_url('/rental-gates/admin/organizations'); ?>" class="quick-action-btn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
            <?php _e('Manage Organizations', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/users'); ?>" class="quick-action-btn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <?php _e('View All Users', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/plans'); ?>" class="quick-action-btn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
            <?php _e('Subscription Plans', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/reports'); ?>" class="quick-action-btn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <?php _e('View Reports', 'rental-gates'); ?>
        </a>
    </div>

    <!-- Key Metrics -->
    <div class="dashboard-grid">
        <!-- Organizations -->
        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon blue">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                </div>
                <?php if ($new_orgs_week > 0): ?>
                    <span class="metric-trend up">
                        <svg fill="none" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M5 10l7-7m0 0l7 7m-7-7v18" />
                        </svg>
                        +<?php echo $new_orgs_week; ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="metric-value"><?php echo number_format($total_orgs); ?></div>
            <div class="metric-label"><?php _e('Organizations', 'rental-gates'); ?></div>
            <div class="metric-sub">
                <?php echo sprintf(__('%d active, %d trial', 'rental-gates'), $active_orgs, $trial_orgs); ?></div>
        </div>

        <!-- MRR -->
        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon green">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <span class="metric-trend <?php echo $revenue_growth >= 0 ? 'up' : 'down'; ?>">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="<?php echo $revenue_growth >= 0 ? 'M5 10l7-7m0 0l7 7m-7-7v18' : 'M19 14l-7 7m0 0l-7-7m7 7V3'; ?>" />
                    </svg>
                    <?php echo ($revenue_growth >= 0 ? '+' : '') . $revenue_growth; ?>%
                </span>
            </div>
            <div class="metric-value">$<?php echo number_format($mrr); ?></div>
            <div class="metric-label"><?php _e('Monthly Recurring Revenue', 'rental-gates'); ?></div>
            <div class="metric-sub">
                <?php echo sprintf(__('%d active subscriptions', 'rental-gates'), $active_subscriptions); ?></div>
        </div>

        <!-- Properties -->
        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon purple">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                    </svg>
                </div>
            </div>
            <div class="metric-value"><?php echo number_format($total_buildings); ?></div>
            <div class="metric-label"><?php _e('Total Buildings', 'rental-gates'); ?></div>
            <div class="metric-sub">
                <?php echo sprintf(__('%s units (%s%% occupied)', 'rental-gates'), number_format($total_units), $occupancy_rate); ?>
            </div>
        </div>

        <!-- Revenue This Month -->
        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon orange">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                </div>
            </div>
            <div class="metric-value">$<?php echo number_format($this_month); ?></div>
            <div class="metric-label"><?php _e('Revenue This Month', 'rental-gates'); ?></div>
            <div class="metric-sub">$<?php echo number_format($today_revenue); ?> <?php _e('today', 'rental-gates'); ?>
            </div>
        </div>
    </div>

    <!-- Secondary Metrics -->
    <div class="dashboard-grid" style="margin-bottom: 24px;">
        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon teal">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                </div>
            </div>
            <div class="metric-value"><?php echo number_format($total_tenants); ?></div>
            <div class="metric-label"><?php _e('Total Tenants', 'rental-gates'); ?></div>
            <div class="metric-sub"><?php echo number_format($active_leases); ?>
                <?php _e('active leases', 'rental-gates'); ?></div>
        </div>

        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon indigo">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                </div>
                <?php if ($pending_applications > 0): ?>
                    <span class="metric-trend neutral"><?php echo $pending_applications; ?> pending</span>
                <?php endif; ?>
            </div>
            <div class="metric-value"><?php echo number_format($new_leads_week); ?></div>
            <div class="metric-label"><?php _e('New Leads (7 days)', 'rental-gates'); ?></div>
            <div class="metric-sub"><?php echo $pending_applications; ?>
                <?php _e('pending applications', 'rental-gates'); ?></div>
        </div>

        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon pink">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                </div>
                <?php if ($open_work_orders > 0): ?>
                    <span class="metric-trend neutral"><?php echo $open_work_orders; ?> open</span>
                <?php endif; ?>
            </div>
            <div class="metric-value"><?php echo number_format($open_work_orders); ?></div>
            <div class="metric-label"><?php _e('Open Work Orders', 'rental-gates'); ?></div>
            <div class="metric-sub"><?php echo number_format($total_vendors); ?> <?php _e('vendors', 'rental-gates'); ?>
            </div>
        </div>

        <div class="metric-card">
            <div class="metric-header">
                <div class="metric-icon <?php echo $churn_rate > 5 ? 'red' : 'green'; ?>">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                </div>
            </div>
            <div class="metric-value"><?php echo $churn_rate; ?>%</div>
            <div class="metric-label"><?php _e('Churn Rate', 'rental-gates'); ?></div>
            <div class="metric-sub"><?php echo $churned_this_month; ?>
                <?php _e('cancelled this month', 'rental-gates'); ?></div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="grid-2" style="margin-bottom: 24px;">
        <!-- Revenue Chart -->
        <div class="chart-container">
            <div class="chart-header">
                <h3 class="chart-title"><?php _e('Revenue Trend (6 Months)', 'rental-gates'); ?></h3>
                <div class="chart-legend">
                    <span class="legend-item">
                        <span class="legend-dot" style="background: #6366f1;"></span>
                        <?php _e('Revenue', 'rental-gates'); ?>
                    </span>
                </div>
            </div>
            <?php
            $max_revenue = max(array_column($monthly_revenue, 'amount'));
            $max_revenue = $max_revenue > 0 ? $max_revenue : 1;
            ?>
            <div class="bar-chart">
                <?php foreach ($monthly_revenue as $month): ?>
                    <div class="bar-group">
                        <div class="bar" style="height: <?php echo ($month['amount'] / $max_revenue) * 180; ?>px;"
                            title="$<?php echo number_format($month['amount']); ?>"></div>
                        <div class="bar-label"><?php echo $month['month']; ?></div>
                        <div class="bar-value">
                            $<?php echo $month['amount'] >= 1000 ? round($month['amount'] / 1000, 1) . 'k' : number_format($month['amount']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Signups Chart -->
        <div class="chart-container">
            <div class="chart-header">
                <h3 class="chart-title"><?php _e('New Signups (6 Months)', 'rental-gates'); ?></h3>
                <div class="chart-legend">
                    <span class="legend-item">
                        <span class="legend-dot" style="background: #10b981;"></span>
                        <?php _e('Organizations', 'rental-gates'); ?>
                    </span>
                </div>
            </div>
            <?php
            $max_signups = max(array_column($monthly_signups, 'count'));
            $max_signups = $max_signups > 0 ? $max_signups : 1;
            ?>
            <div class="bar-chart">
                <?php foreach ($monthly_signups as $month): ?>
                    <div class="bar-group">
                        <div class="bar"
                            style="height: <?php echo ($month['count'] / $max_signups) * 180; ?>px; background: linear-gradient(180deg, #10b981 0%, #059669 100%);"
                            title="<?php echo $month['count']; ?> signups"></div>
                        <div class="bar-label"><?php echo $month['month']; ?></div>
                        <div class="bar-value"><?php echo $month['count']; ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Main Content Columns -->
    <div class="dashboard-columns">
        <div>
            <!-- Recent Organizations -->
            <div class="card" style="margin-bottom: 24px;">
                <div class="card-header">
                    <h2 class="card-title"><?php _e('Recent Organizations', 'rental-gates'); ?></h2>
                    <a href="<?php echo home_url('/rental-gates/admin/organizations'); ?>"
                        class="btn btn-sm btn-outline">
                        <?php _e('View All', 'rental-gates'); ?>
                    </a>
                </div>
                <div class="card-body" style="padding: 0;">
                    <?php if (empty($recent_orgs)): ?>
                        <div class="empty-state">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                            <h3><?php _e('No organizations yet', 'rental-gates'); ?></h3>
                            <p><?php _e('Organizations will appear here when they register.', 'rental-gates'); ?></p>
                        </div>
                    <?php else: ?>
                        <table class="mini-table">
                            <thead>
                                <tr>
                                    <th><?php _e('Organization', 'rental-gates'); ?></th>
                                    <th><?php _e('Plan', 'rental-gates'); ?></th>
                                    <th><?php _e('Properties', 'rental-gates'); ?></th>
                                    <th><?php _e('Status', 'rental-gates'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_orgs as $org): ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo home_url('/rental-gates/admin/organizations?id=' . $org['id']); ?>"
                                                style="color: var(--primary); text-decoration: none; font-weight: 500;">
                                                <?php echo esc_html($org['name']); ?>
                                            </a>
                                            <div style="font-size: 12px; color: var(--gray-400);">
                                                <?php echo human_time_diff(strtotime($org['created_at']), current_time('timestamp')) . ' ' . __('ago', 'rental-gates'); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span
                                                style="font-size: 13px;"><?php echo esc_html($org['plan_name'] ?? 'Free'); ?></span>
                                        </td>
                                        <td>
                                            <span style="font-size: 13px;"><?php echo number_format($org['building_count']); ?>
                                                / <?php echo number_format($org['unit_count']); ?></span>
                                        </td>
                                        <td>
                                            <span
                                                class="badge badge-<?php echo $org['status'] === 'active' ? 'success' : ($org['status'] === 'trial' ? 'info' : 'warning'); ?>">
                                                <?php echo ucfirst($org['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Payments -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title"><?php _e('Recent Payments', 'rental-gates'); ?></h2>
                    <a href="<?php echo home_url('/rental-gates/admin/reports'); ?>" class="btn btn-sm btn-outline">
                        <?php _e('View Reports', 'rental-gates'); ?>
                    </a>
                </div>
                <div class="card-body" style="padding: 0;">
                    <?php if (empty($recent_payments)): ?>
                        <div class="empty-state">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                            </svg>
                            <h3><?php _e('No payments yet', 'rental-gates'); ?></h3>
                        </div>
                    <?php else: ?>
                        <table class="mini-table">
                            <thead>
                                <tr>
                                    <th><?php _e('Organization', 'rental-gates'); ?></th>
                                    <th><?php _e('Amount', 'rental-gates'); ?></th>
                                    <th><?php _e('Status', 'rental-gates'); ?></th>
                                    <th><?php _e('Date', 'rental-gates'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_payments as $payment): ?>
                                    <tr>
                                        <td><?php echo esc_html($payment['org_name'] ?? 'N/A'); ?></td>
                                        <td style="font-weight: 600;">$<?php echo number_format($payment['amount'], 2); ?></td>
                                        <td>
                                            <span class="badge badge-<?php
                                            echo $payment['status'] === 'completed' ? 'success' :
                                                ($payment['status'] === 'pending' ? 'warning' : 'danger');
                                            ?>">
                                                <?php echo ucfirst($payment['status']); ?>
                                            </span>
                                        </td>
                                        <td style="color: var(--gray-500); font-size: 13px;">
                                            <?php echo human_time_diff(strtotime($payment['created_at']), current_time('timestamp')) . ' ' . __('ago', 'rental-gates'); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Activity Feed -->
        <div class="activity-feed">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Activity Feed', 'rental-gates'); ?></h2>
                <a href="<?php echo home_url('/rental-gates/admin/activity'); ?>" class="btn btn-sm btn-outline">
                    <?php _e('View All', 'rental-gates'); ?>
                </a>
            </div>
            <?php if (empty($recent_activity)): ?>
                <div class="empty-state" style="padding: 40px;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h3><?php _e('No activity yet', 'rental-gates'); ?></h3>
                </div>
            <?php else: ?>
                <?php foreach ($recent_activity as $activity): ?>
                    <div class="activity-item">
                        <div class="activity-icon">
                            <svg fill="none" stroke="currentColor"
                                viewBox="0 0 24 24"><?php echo get_activity_icon($activity['action']); ?></svg>
                        </div>
                        <div class="activity-content">
                            <div class="activity-text">
                                <strong><?php echo esc_html($activity['user_name'] ?? __('System', 'rental-gates')); ?></strong>
                                <?php echo esc_html(ucwords(str_replace('_', ' ', $activity['action']))); ?>
                                <?php if (!empty($activity['entity_type'])): ?>
                                    <span style="color: var(--gray-500);"><?php echo esc_html($activity['entity_type']); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="activity-time">
                                <?php echo human_time_diff(strtotime($activity['created_at']), current_time('timestamp')) . ' ' . __('ago', 'rental-gates'); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- System Info -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php _e('System Information', 'rental-gates'); ?></h2>
            <a href="<?php echo home_url('/rental-gates/admin/system'); ?>" class="btn btn-sm btn-outline">
                <?php _e('Full Diagnostics', 'rental-gates'); ?>
            </a>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 24px;">
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('Plugin', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;">v<?php echo esc_html($plugin_version); ?></div>
                </div>
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('WordPress', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;"><?php echo esc_html($wp_version); ?></div>
                </div>
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('PHP', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;"><?php echo esc_html($php_version); ?></div>
                </div>
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('MySQL', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;"><?php echo esc_html($db_version); ?></div>
                </div>
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('Memory', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;"><?php echo $memory_usage; ?>MB /
                        <?php echo $memory_limit; ?></div>
                </div>
                <div>
                    <div class="text-muted"
                        style="font-size: 11px; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php _e('Upload Max', 'rental-gates'); ?></div>
                    <div style="font-weight: 600; font-size: 15px;"><?php echo esc_html($upload_max); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>