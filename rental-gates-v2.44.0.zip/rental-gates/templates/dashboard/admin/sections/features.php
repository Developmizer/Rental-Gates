<?php
/**
 * Site Admin - Feature Flags Section
 * 
 * Toggle features globally or per organization.
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Define available features
$features = array(
    'online_payments' => array(
        'name' => __('Online Payments', 'rental-gates'),
        'description' => __('Allow tenants to pay rent online via Stripe.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>',
    ),
    'ai_screening' => array(
        'name' => __('AI Tenant Screening', 'rental-gates'),
        'description' => __('Use AI to analyze and score rental applications.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>',
    ),
    'maintenance_photos' => array(
        'name' => __('Maintenance Photos', 'rental-gates'),
        'description' => __('Allow photo uploads on maintenance requests.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>',
    ),
    'tenant_portal' => array(
        'name' => __('Tenant Portal', 'rental-gates'),
        'description' => __('Self-service portal for tenants.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>',
    ),
    'vendor_portal' => array(
        'name' => __('Vendor Portal', 'rental-gates'),
        'description' => __('Portal for maintenance vendors to manage work orders.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>',
    ),
    'public_listings' => array(
        'name' => __('Public Property Listings', 'rental-gates'),
        'description' => __('Show available units on public pages.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>',
    ),
    'qr_codes' => array(
        'name' => __('QR Code Marketing', 'rental-gates'),
        'description' => __('Generate QR codes and flyers for properties.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h2M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/>',
    ),
    'lead_capture' => array(
        'name' => __('Lead Capture & CRM', 'rental-gates'),
        'description' => __('Capture and manage prospective tenant leads.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>',
    ),
    'document_signing' => array(
        'name' => __('Digital Document Signing', 'rental-gates'),
        'description' => __('E-signatures for leases and documents.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
    ),
    'automated_reminders' => array(
        'name' => __('Automated Reminders', 'rental-gates'),
        'description' => __('Auto-send payment reminders and notifications.', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>',
    ),
);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['features_nonce'])) {
    if (wp_verify_nonce($_POST['features_nonce'], 'admin_features')) {
        $enabled_features = isset($_POST['features']) ? array_map('sanitize_key', $_POST['features']) : array();
        update_option('rental_gates_enabled_features', $enabled_features);
        
        wp_redirect(add_query_arg('saved', '1', home_url('/rental-gates/admin/features')));
        exit;
    }
}

// Get enabled features
$enabled_features = get_option('rental_gates_enabled_features', array_keys($features));
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Feature Flags', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <?php if (isset($_GET['saved'])): ?>
    <div class="alert alert-success mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?php _e('Features updated successfully.', 'rental-gates'); ?>
    </div>
    <?php endif; ?>
    
    <div class="alert alert-info mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <div>
            <?php _e('Toggle features on or off globally. Disabled features will be hidden from all organizations.', 'rental-gates'); ?>
        </div>
    </div>
    
    <form method="post" action="">
        <?php wp_nonce_field('admin_features', 'features_nonce'); ?>
        
        <div class="card">
            <div class="card-body" style="padding: 0;">
                <?php foreach ($features as $key => $feature): ?>
                <div style="padding: 20px 24px; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; gap: 16px;">
                    <div style="width: 48px; height: 48px; background: var(--gray-100); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--gray-600);">
                            <?php echo $feature['icon']; ?>
                        </svg>
                    </div>
                    
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: var(--gray-900);"><?php echo esc_html($feature['name']); ?></div>
                        <div style="font-size: 13px; color: var(--gray-500);"><?php echo esc_html($feature['description']); ?></div>
                    </div>
                    
                    <label class="toggle-switch">
                        <input type="checkbox" name="features[]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $enabled_features)); ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div style="margin-top: 24px;">
            <button type="submit" class="btn btn-primary"><?php _e('Save Changes', 'rental-gates'); ?></button>
        </div>
    </form>
</div>

<style>
.toggle-switch {
    position: relative;
    display: inline-block;
    width: 52px;
    height: 28px;
    flex-shrink: 0;
}

.toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--gray-300);
    transition: 0.3s;
    border-radius: 28px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 22px;
    width: 22px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: 0.3s;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.toggle-switch input:checked + .toggle-slider {
    background-color: var(--primary);
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(24px);
}

.toggle-switch input:focus + .toggle-slider {
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
}
</style>
