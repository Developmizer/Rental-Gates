<?php
/**
 * Public Application Form
 * 
 * Rental application form for prospective tenants.
 */
if (!defined('ABSPATH')) exit;

$building_slug = get_query_var('rental_gates_building_slug');
$unit_slug = get_query_var('rental_gates_unit_slug');

if (!$building_slug || !$unit_slug) {
    wp_redirect(home_url('/rental-gates/map'));
    exit;
}

$unit = Rental_Gates_Unit::get_by_slug($unit_slug, $building_slug);
if (!$unit) {
    wp_redirect(home_url('/rental-gates/map'));
    exit;
}

$building = Rental_Gates_Building::get($unit['building_id']);
$organization = Rental_Gates_Organization::get($building['organization_id']);

// Check if applications are allowed
$can_apply = in_array($unit['availability'], array('available', 'coming_soon'));
if (!$can_apply) {
    wp_redirect(home_url('/rental-gates/listings/' . $building_slug . '/' . $unit_slug));
    exit;
}

// Income ranges for dropdown
$income_ranges = array(
    '' => __('Select income range', 'rental-gates'),
    'under_25k' => __('Under $25,000', 'rental-gates'),
    '25k_50k' => __('$25,000 - $50,000', 'rental-gates'),
    '50k_75k' => __('$50,000 - $75,000', 'rental-gates'),
    '75k_100k' => __('$75,000 - $100,000', 'rental-gates'),
    '100k_150k' => __('$100,000 - $150,000', 'rental-gates'),
    'over_150k' => __('Over $150,000', 'rental-gates'),
);

// Handle form submission
$success = false;
$error = '';
$submitted_data = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_nonce'])) {
    if (!wp_verify_nonce($_POST['apply_nonce'], 'rental_gates_apply')) {
        $error = __('Security check failed. Please try again.', 'rental-gates');
    } else {
        // Validate required fields
        $required = array('applicant_name', 'applicant_email', 'applicant_phone');
        $missing = array();
        
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                $missing[] = $field;
            }
        }
        
        if (!empty($missing)) {
            $error = __('Please fill in all required fields.', 'rental-gates');
        } elseif (!is_email($_POST['applicant_email'])) {
            $error = __('Please enter a valid email address.', 'rental-gates');
        } else {
            // Create application
            global $wpdb;
            $tables = Rental_Gates_Database::get_table_names();
            
            $token = wp_generate_password(32, false);
            
            $result = $wpdb->insert($tables['applications'], array(
                'organization_id' => $organization['id'],
                'unit_id' => $unit['id'],
                'token' => $token,
                'applicant_name' => sanitize_text_field($_POST['applicant_name']),
                'applicant_email' => sanitize_email($_POST['applicant_email']),
                'applicant_phone' => sanitize_text_field($_POST['applicant_phone']),
                'current_address' => sanitize_textarea_field($_POST['current_address'] ?? ''),
                'employer' => sanitize_text_field($_POST['employer'] ?? ''),
                'income_range' => sanitize_text_field($_POST['income_range'] ?? ''),
                'desired_move_in' => !empty($_POST['desired_move_in']) ? sanitize_text_field($_POST['desired_move_in']) : null,
                'notes' => sanitize_textarea_field($_POST['notes'] ?? ''),
                'status' => 'new',
                'submitted_at' => current_time('mysql'),
                'created_at' => current_time('mysql'),
            ));
            
            if ($result) {
                $success = true;
                
                // Send notification email to organization
                if (!empty($organization['contact_email'])) {
                    $subject = sprintf(__('New Application for %s', 'rental-gates'), $unit['name']);
                    $message = sprintf(
                        __("You have received a new rental application.\n\nUnit: %s\nBuilding: %s\nApplicant: %s\nEmail: %s\nPhone: %s\n\nLogin to your dashboard to review this application.", 'rental-gates'),
                        $unit['name'],
                        $building['name'],
                        sanitize_text_field($_POST['applicant_name']),
                        sanitize_email($_POST['applicant_email']),
                        sanitize_text_field($_POST['applicant_phone'])
                    );
                    wp_mail($organization['contact_email'], $subject, $message);
                }
                
                // Send confirmation to applicant
                $applicant_subject = sprintf(__('Application Received - %s', 'rental-gates'), $unit['name']);
                $applicant_message = sprintf(
                    __("Thank you for your application!\n\nWe have received your application for:\n%s at %s\n\nA property manager will review your application and contact you soon.\n\nBest regards,\n%s", 'rental-gates'),
                    $unit['name'],
                    $building['name'],
                    $organization['name']
                );
                wp_mail(sanitize_email($_POST['applicant_email']), $applicant_subject, $applicant_message);
            } else {
                $error = __('Error submitting application. Please try again.', 'rental-gates');
            }
        }
        
        // Keep submitted data for form repopulation
        $submitted_data = $_POST;
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Apply for', 'rental-gates'); ?> <?php echo esc_html($unit['name']); ?> | <?php echo esc_html($organization['name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --success: #10b981;
            --error: #ef4444;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--gray-100); color: var(--gray-900); line-height: 1.5; min-height: 100vh; }
        
        /* Header */
        .header { background: #fff; border-bottom: 1px solid var(--gray-200); padding: 16px 0; }
        .header-content { max-width: 800px; margin: 0 auto; padding: 0 20px; display: flex; justify-content: space-between; align-items: center; }
        .back-link { color: var(--gray-500); text-decoration: none; display: flex; align-items: center; gap: 6px; font-size: 14px; }
        .back-link:hover { color: var(--primary); }
        .org-name { font-weight: 600; font-size: 16px; }
        
        /* Main */
        .main { max-width: 800px; margin: 0 auto; padding: 32px 20px; }
        
        /* Unit Preview */
        .unit-preview { background: #fff; border-radius: 16px; padding: 20px; margin-bottom: 24px; display: flex; gap: 16px; border: 1px solid var(--gray-200); }
        .unit-preview-image { width: 120px; height: 80px; border-radius: 10px; overflow: hidden; flex-shrink: 0; background: var(--gray-100); }
        .unit-preview-image img { width: 100%; height: 100%; object-fit: cover; }
        .unit-preview-info h3 { font-size: 16px; font-weight: 600; margin-bottom: 4px; }
        .unit-preview-details { font-size: 14px; color: var(--gray-500); }
        .unit-preview-price { font-size: 18px; font-weight: 700; color: var(--primary); margin-top: 4px; }
        
        /* Form Card */
        .form-card { background: #fff; border-radius: 16px; border: 1px solid var(--gray-200); overflow: hidden; }
        .form-header { padding: 24px; border-bottom: 1px solid var(--gray-100); }
        .form-header h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
        .form-header p { color: var(--gray-500); font-size: 14px; }
        .form-body { padding: 24px; }
        
        /* Form Elements */
        .form-section { margin-bottom: 32px; }
        .form-section:last-child { margin-bottom: 0; }
        .form-section-title { font-size: 16px; font-weight: 600; margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid var(--gray-100); }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
        .form-row.full { grid-template-columns: 1fr; }
        
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-label { font-size: 14px; font-weight: 500; color: var(--gray-700); }
        .form-label .required { color: var(--error); }
        
        .form-input, .form-select, .form-textarea {
            padding: 12px 14px;
            border: 1px solid var(--gray-300);
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: border-color 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
        
        .form-textarea { min-height: 100px; resize: vertical; }
        .form-hint { font-size: 12px; color: var(--gray-500); }
        
        /* Submit */
        .form-actions { padding: 24px; background: var(--gray-50); border-top: 1px solid var(--gray-100); }
        .submit-btn {
            display: block;
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .submit-btn:hover { background: var(--primary-dark); }
        .submit-btn:disabled { background: var(--gray-300); cursor: not-allowed; }
        
        .form-disclaimer { font-size: 12px; color: var(--gray-500); text-align: center; margin-top: 16px; line-height: 1.6; }
        
        /* Alert */
        .alert { padding: 16px; border-radius: 10px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 12px; }
        .alert-success { background: #d1fae5; color: #065f46; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        .alert svg { flex-shrink: 0; margin-top: 2px; }
        
        /* Success State */
        .success-card { background: #fff; border-radius: 16px; padding: 48px 24px; text-align: center; border: 1px solid var(--gray-200); }
        .success-icon { width: 64px; height: 64px; background: #d1fae5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: var(--success); }
        .success-title { font-size: 24px; font-weight: 700; margin-bottom: 8px; }
        .success-message { color: var(--gray-600); margin-bottom: 24px; max-width: 400px; margin-left: auto; margin-right: auto; }
        .success-btn { display: inline-block; padding: 12px 24px; background: var(--primary); color: #fff; border-radius: 10px; text-decoration: none; font-weight: 500; }
        .success-btn:hover { background: var(--primary-dark); }
        
        /* Footer */
        .footer { text-align: center; padding: 24px; font-size: 13px; color: var(--gray-500); }
        .footer a { color: var(--gray-500); }
        
        @media (max-width: 640px) {
            .form-row { grid-template-columns: 1fr; }
            .unit-preview { flex-direction: column; }
            .unit-preview-image { width: 100%; height: 160px; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <a href="<?php echo home_url('/rental-gates/listings/' . $building_slug . '/' . $unit_slug); ?>" class="back-link">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
                <?php _e('Back to listing', 'rental-gates'); ?>
            </a>
            <span class="org-name"><?php echo esc_html($organization['name']); ?></span>
        </div>
    </header>
    
    <main class="main">
        <?php if ($success): ?>
        <!-- Success State -->
        <div class="success-card">
            <div class="success-icon">
                <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
            </div>
            <h1 class="success-title"><?php _e('Application Submitted!', 'rental-gates'); ?></h1>
            <p class="success-message">
                <?php _e('Thank you for your application. We\'ve sent a confirmation to your email. A property manager will review your application and contact you soon.', 'rental-gates'); ?>
            </p>
            <a href="<?php echo home_url('/rental-gates/listings/' . $building_slug . '/' . $unit_slug); ?>" class="success-btn">
                <?php _e('Back to Listing', 'rental-gates'); ?>
            </a>
        </div>
        
        <?php else: ?>
        
        <!-- Unit Preview -->
        <div class="unit-preview">
            <div class="unit-preview-image">
                <?php 
                $gallery = !empty($unit['gallery']) ? $unit['gallery'] : array();
                if (!empty($gallery)): 
                ?>
                    <img src="<?php echo esc_url($gallery[0]); ?>" alt="">
                <?php endif; ?>
            </div>
            <div class="unit-preview-info">
                <h3><?php echo esc_html($unit['name']); ?></h3>
                <div class="unit-preview-details">
                    <?php echo esc_html($building['name']); ?> • 
                    <?php echo intval($unit['bedrooms']); ?> bed, 
                    <?php echo number_format($unit['bathrooms'], $unit['bathrooms'] == floor($unit['bathrooms']) ? 0 : 1); ?> bath
                </div>
                <div class="unit-preview-price">$<?php echo number_format($unit['rent_amount']); ?>/mo</div>
            </div>
        </div>
        
        <!-- Application Form -->
        <form method="post" class="form-card">
            <?php wp_nonce_field('rental_gates_apply', 'apply_nonce'); ?>
            
            <div class="form-header">
                <h1><?php _e('Rental Application', 'rental-gates'); ?></h1>
                <p><?php _e('Fill out the form below to apply for this unit.', 'rental-gates'); ?></p>
            </div>
            
            <div class="form-body">
                <?php if ($error): ?>
                <div class="alert alert-error">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span><?php echo esc_html($error); ?></span>
                </div>
                <?php endif; ?>
                
                <!-- Personal Information -->
                <div class="form-section">
                    <h2 class="form-section-title"><?php _e('Personal Information', 'rental-gates'); ?></h2>
                    
                    <div class="form-row full">
                        <div class="form-group">
                            <label class="form-label" for="applicant_name">
                                <?php _e('Full Name', 'rental-gates'); ?> <span class="required">*</span>
                            </label>
                            <input 
                                type="text" 
                                id="applicant_name" 
                                name="applicant_name" 
                                class="form-input" 
                                value="<?php echo esc_attr($submitted_data['applicant_name'] ?? ''); ?>"
                                required
                            >
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="applicant_email">
                                <?php _e('Email Address', 'rental-gates'); ?> <span class="required">*</span>
                            </label>
                            <input 
                                type="email" 
                                id="applicant_email" 
                                name="applicant_email" 
                                class="form-input" 
                                value="<?php echo esc_attr($submitted_data['applicant_email'] ?? ''); ?>"
                                required
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="applicant_phone">
                                <?php _e('Phone Number', 'rental-gates'); ?> <span class="required">*</span>
                            </label>
                            <input 
                                type="tel" 
                                id="applicant_phone" 
                                name="applicant_phone" 
                                class="form-input" 
                                value="<?php echo esc_attr($submitted_data['applicant_phone'] ?? ''); ?>"
                                required
                            >
                        </div>
                    </div>
                    
                    <div class="form-row full">
                        <div class="form-group">
                            <label class="form-label" for="current_address">
                                <?php _e('Current Address', 'rental-gates'); ?>
                            </label>
                            <textarea 
                                id="current_address" 
                                name="current_address" 
                                class="form-textarea" 
                                rows="2"
                            ><?php echo esc_textarea($submitted_data['current_address'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- Employment & Income -->
                <div class="form-section">
                    <h2 class="form-section-title"><?php _e('Employment & Income', 'rental-gates'); ?></h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="employer">
                                <?php _e('Current Employer', 'rental-gates'); ?>
                            </label>
                            <input 
                                type="text" 
                                id="employer" 
                                name="employer" 
                                class="form-input" 
                                value="<?php echo esc_attr($submitted_data['employer'] ?? ''); ?>"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="income_range">
                                <?php _e('Annual Income', 'rental-gates'); ?>
                            </label>
                            <select id="income_range" name="income_range" class="form-select">
                                <?php foreach ($income_ranges as $value => $label): ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($submitted_data['income_range'] ?? '', $value); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Move-in Details -->
                <div class="form-section">
                    <h2 class="form-section-title"><?php _e('Move-in Details', 'rental-gates'); ?></h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="desired_move_in">
                                <?php _e('Desired Move-in Date', 'rental-gates'); ?>
                            </label>
                            <input 
                                type="date" 
                                id="desired_move_in" 
                                name="desired_move_in" 
                                class="form-input"
                                min="<?php echo date('Y-m-d'); ?>"
                                value="<?php echo esc_attr($submitted_data['desired_move_in'] ?? ''); ?>"
                            >
                        </div>
                    </div>
                    
                    <div class="form-row full">
                        <div class="form-group">
                            <label class="form-label" for="notes">
                                <?php _e('Additional Information', 'rental-gates'); ?>
                            </label>
                            <textarea 
                                id="notes" 
                                name="notes" 
                                class="form-textarea" 
                                rows="3"
                                placeholder="<?php _e('Tell us about yourself, why you\'re interested in this unit, or any questions you have...', 'rental-gates'); ?>"
                            ><?php echo esc_textarea($submitted_data['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="submit-btn">
                    <?php _e('Submit Application', 'rental-gates'); ?>
                </button>
                <p class="form-disclaimer">
                    <?php _e('By submitting this application, you agree to be contacted by the property manager regarding your application. Your information will be kept confidential.', 'rental-gates'); ?>
                </p>
            </div>
        </form>
        
        <?php endif; ?>
    </main>
    
    <!-- Footer -->
    <footer class="footer">
        <?php _e('Powered by', 'rental-gates'); ?> <a href="https://rentalgates.com">Rental Gates</a>
    </footer>
</body>
</html>
