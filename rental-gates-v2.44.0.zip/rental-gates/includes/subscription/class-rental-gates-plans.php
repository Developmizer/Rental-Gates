<?php
/**
 * Rental Gates Plans Class
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Plans {
    
    public static function get_all() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        return $wpdb->get_results("SELECT * FROM {$tables['plans']} WHERE is_active = 1 ORDER BY sort_order ASC", ARRAY_A);
    }
    
    public static function get_by_slug($slug) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['plans']} WHERE slug = %s", $slug), ARRAY_A);
    }
}
