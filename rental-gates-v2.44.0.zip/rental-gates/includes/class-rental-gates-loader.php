<?php
/**
 * Rental Gates Loader Class
 * Registers all actions and filters for the plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Loader {
    
    /**
     * Array of actions to register
     */
    protected $actions = array();
    
    /**
     * Array of filters to register
     */
    protected $filters = array();
    
    /**
     * Add an action to the collection
     */
    public function add_action($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * Add a filter to the collection
     */
    public function add_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * Utility function to register hooks
     */
    private function add($hooks, $hook, $component, $callback, $priority, $accepted_args) {
        $hooks[] = array(
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args
        );
        
        return $hooks;
    }
    
    /**
     * Register all hooks with WordPress
     */
    public function run() {
        foreach ($this->filters as $hook) {
            add_filter(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
        
        foreach ($this->actions as $hook) {
            add_action(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
    }
    
    /**
     * Remove an action from the collection
     */
    public function remove_action($hook, $component, $callback) {
        $this->actions = $this->remove($this->actions, $hook, $component, $callback);
    }
    
    /**
     * Remove a filter from the collection
     */
    public function remove_filter($hook, $component, $callback) {
        $this->filters = $this->remove($this->filters, $hook, $component, $callback);
    }
    
    /**
     * Utility function to remove hooks
     */
    private function remove($hooks, $hook, $component, $callback) {
        return array_filter($hooks, function($item) use ($hook, $component, $callback) {
            return !($item['hook'] === $hook && $item['component'] === $component && $item['callback'] === $callback);
        });
    }
}
