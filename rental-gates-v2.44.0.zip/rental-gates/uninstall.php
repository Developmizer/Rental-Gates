<?php
/**
 * Rental Gates Uninstall
 * 
 * Fired when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if user wants to delete data
$delete_data = get_option('rental_gates_delete_data_on_uninstall', false);

if ($delete_data) {
    global $wpdb;
    
    // Define table prefix
    $prefix = $wpdb->prefix . 'rg_';
    
    // Tables to drop
    $tables = array(
        'organizations',
        'organization_members',
        'buildings',
        'units',
        'tenants',
        'vendors',
        'applications',
        'application_occupants',
        'leases',
        'lease_tenants',
        'rent_adjustments',
        'renewals',
        'leads',
        'lead_interests',
        'work_orders',
        'work_order_notes',
        'work_order_vendors',
        'scheduled_maintenance',
        'payments',
        'payment_items',
        'payment_plans',
        'payment_plan_items',
        'deposits',
        'deposit_deductions',
        'vendor_payouts',
        'plans',
        'subscriptions',
        'invoices',
        'stripe_accounts',
        'payment_methods',
        'documents',
        'message_threads',
        'messages',
        'announcements',
        'announcement_recipients',
        'move_checklists',
        'condition_reports',
        'condition_items',
        'flyers',
        'qr_codes',
        'qr_scans',
        'ai_usage',
        'ai_screenings',
        'notifications',
        'notification_preferences',
        'activity_log',
        'settings',
        'staff_permissions',
    );
    
    // Drop all tables
    foreach ($tables as $table) {
        $wpdb->query("DROP TABLE IF EXISTS {$prefix}{$table}");
    }
    
    // Delete all options
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'rental_gates_%'");
    
    // Delete all transients
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rental_gates_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_rental_gates_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rg_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_rg_%'");
    
    // Delete user meta
    $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'rental_gates_%'");
    
    // Remove custom roles
    $roles = array(
        'rental_gates_site_admin',
        'rental_gates_owner',
        'rental_gates_manager',
        'rental_gates_staff',
        'rental_gates_tenant',
        'rental_gates_vendor',
    );
    
    foreach ($roles as $role) {
        remove_role($role);
    }
    
    // Remove capabilities from administrator
    $admin = get_role('administrator');
    if ($admin) {
        $caps = array(
            'rg_manage_platform',
            'rg_manage_organizations',
            'rg_manage_plans',
            'rg_manage_feature_flags',
            'rg_manage_integrations',
            'rg_manage_templates',
            'rg_view_audit_logs',
            'rg_support_mode',
            'rg_view_all_reports',
            'rg_manage_buildings',
            'rg_manage_units',
            'rg_manage_tenants',
            'rg_manage_leases',
            'rg_manage_applications',
            'rg_manage_payments',
            'rg_manage_maintenance',
            'rg_manage_vendors',
            'rg_manage_leads',
            'rg_manage_marketing',
            'rg_manage_communications',
            'rg_manage_settings',
            'rg_manage_staff',
            'rg_use_ai_tools',
            'rg_view_reports',
            'rg_export_data',
        );
        
        foreach ($caps as $cap) {
            $admin->remove_cap($cap);
        }
    }
    
    // Delete upload directory
    $upload_dir = wp_upload_dir();
    $rental_gates_dir = $upload_dir['basedir'] . '/rental-gates';
    
    if (is_dir($rental_gates_dir)) {
        // Recursive delete function
        $delete_dir = function($dir) use (&$delete_dir) {
            if (!is_dir($dir)) return;
            $files = array_diff(scandir($dir), array('.', '..'));
            foreach ($files as $file) {
                $path = $dir . '/' . $file;
                is_dir($path) ? $delete_dir($path) : unlink($path);
            }
            rmdir($dir);
        };
        
        $delete_dir($rental_gates_dir);
    }
}

// Clear scheduled events
$cron_hooks = array(
    'rental_gates_availability_cron',
    'rental_gates_notifications_cron',
    'rental_gates_ai_credits_reset',
    'rental_gates_cleanup_temp',
);

foreach ($cron_hooks as $hook) {
    wp_clear_scheduled_hook($hook);
}

// Flush rewrite rules
flush_rewrite_rules();
