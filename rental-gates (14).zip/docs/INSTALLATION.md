# Rental Gates - Installation Guide

Complete guide to installing, configuring, and launching Rental Gates on your WordPress site.

---

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Pre-Installation Checklist](#pre-installation-checklist)
3. [Installation Methods](#installation-methods)
4. [Initial Configuration](#initial-configuration)
5. [Stripe Setup](#stripe-setup)
6. [OpenAI Setup](#openai-setup)
7. [Map Provider Setup](#map-provider-setup)
8. [Email Configuration](#email-configuration)
9. [PWA Configuration](#pwa-configuration)
10. [Post-Installation Steps](#post-installation-steps)
11. [Troubleshooting](#troubleshooting)
12. [Upgrading](#upgrading)
13. [Uninstallation](#uninstallation)

---

## System Requirements

### Minimum Requirements

| Component | Version | Notes |
|-----------|---------|-------|
| WordPress | 6.0+ | 6.4+ recommended |
| PHP | 7.4+ | 8.1+ recommended |
| MySQL | 5.7+ | 8.0+ recommended |
| Memory Limit | 128MB | 256MB+ recommended |
| Max Execution Time | 60s | 120s+ for imports |
| Upload Size | 10MB | 50MB+ for media |

### Required PHP Extensions

```
✓ curl        - API communications
✓ json        - Data processing  
✓ mbstring    - Multi-byte string handling
✓ openssl     - Encryption/security
✓ gd          - Image processing (or imagick)
✓ zip         - File compression
```

### Server Requirements

```
✓ HTTPS (SSL Certificate) - Required for payments and PWA
✓ mod_rewrite enabled - Pretty permalinks
✓ Cron support - Scheduled tasks
✓ Mail function or SMTP - Email delivery
```

### Check Your Server

Add this to a temporary PHP file to check requirements:

```php
<?php
echo "PHP Version: " . phpversion() . "\n";
echo "Memory Limit: " . ini_get('memory_limit') . "\n";
echo "Max Execution: " . ini_get('max_execution_time') . "\n";
echo "Upload Size: " . ini_get('upload_max_filesize') . "\n";
echo "\nExtensions:\n";
$required = ['curl', 'json', 'mbstring', 'openssl', 'gd'];
foreach ($required as $ext) {
    echo "$ext: " . (extension_loaded($ext) ? '✓' : '✗') . "\n";
}
```

---

## Pre-Installation Checklist

Before installing Rental Gates:

- [ ] **Backup your site** - Full backup of files and database
- [ ] **Check requirements** - Verify server meets minimum specs
- [ ] **HTTPS enabled** - SSL certificate installed and active
- [ ] **Permalinks configured** - Not using "Plain" permalinks
- [ ] **Admin access** - WordPress administrator credentials
- [ ] **Stripe account** - (Optional) For payment processing
- [ ] **OpenAI account** - (Optional) For AI features

---

## Installation Methods

### Method 1: WordPress Admin Upload (Recommended)

1. Download `rental-gates.zip` from your purchase
2. Log into WordPress Admin
3. Go to **Plugins → Add New**
4. Click **Upload Plugin**
5. Choose the ZIP file and click **Install Now**
6. Click **Activate Plugin**

### Method 2: FTP/SFTP Upload

1. Extract `rental-gates.zip` on your computer
2. Connect to your server via FTP/SFTP
3. Upload the `rental-gates` folder to `/wp-content/plugins/`
4. Go to WordPress Admin → Plugins
5. Find "Rental Gates" and click **Activate**

### Method 3: WP-CLI

```bash
# Upload and activate
wp plugin install rental-gates.zip --activate

# Or from directory
wp plugin activate rental-gates
```

### What Happens on Activation

When you activate Rental Gates, it automatically:

1. Creates 49 database tables
2. Sets up 6 user roles with permissions
3. Seeds 4 default subscription plans
4. Registers URL rewrite rules
5. Schedules cron jobs
6. Creates required directories

---

## Initial Configuration

### Step 1: Access Setup Wizard

After activation, go to:
```
/rental-gates/register
```

Or access the admin panel directly:
```
/rental-gates/admin
```

### Step 2: Create Your Organization

1. Fill in organization details:
   - Organization Name
   - Your Name
   - Email Address
   - Password

2. Select a subscription plan (or start with Free)

3. Complete registration

### Step 3: Configure Settings

Navigate to **Dashboard → Settings** and configure:

#### General Settings

| Setting | Description |
|---------|-------------|
| Organization Name | Your company name |
| Email | Primary contact email |
| Phone | Contact phone number |
| Address | Business address |
| Timezone | Your local timezone |
| Currency | Default currency (USD, EUR, etc.) |
| Date Format | Preferred date display |

#### Property Settings

| Setting | Description |
|---------|-------------|
| Default Lease Term | Standard lease length (12 months) |
| Late Fee Amount | Amount or percentage |
| Late Fee Grace Days | Days before late fee applies |
| Security Deposit | Default deposit amount |
| Application Fee | Fee for rental applications |

#### Notification Settings

| Setting | Description |
|---------|-------------|
| Payment Reminders | Days before due date |
| Lease Expiry Alerts | Days before expiration |
| Maintenance Updates | Notify on status changes |

---

## Stripe Setup

Stripe handles all payment processing. You need both test and live API keys.

### Get Stripe API Keys

1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Create an account or log in
3. Navigate to **Developers → API Keys**
4. Copy your keys:
   - Publishable key (starts with `pk_`)
   - Secret key (starts with `sk_`)

### Configure in Rental Gates

1. Go to **Site Admin → Integrations**
2. Enter your Stripe keys:

```
Test Mode:
- Publishable Key: pk_test_...
- Secret Key: sk_test_...

Live Mode:
- Publishable Key: pk_live_...
- Secret Key: sk_live_...
```

3. Configure webhooks (see below)
4. Save settings

### Webhook Configuration

Webhooks allow Stripe to notify Rental Gates of payment events.

1. In Stripe Dashboard → Developers → Webhooks
2. Click **Add Endpoint**
3. Enter your webhook URL:
   ```
   https://yoursite.com/wp-json/rental-gates/v1/stripe/webhook
   ```
4. Select events to listen for:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `invoice.paid`
   - `invoice.payment_failed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`

5. Copy the **Signing Secret** and add it to Rental Gates settings

### Test Mode

Always test payments before going live:

1. Use test API keys
2. Use [Stripe test cards](https://stripe.com/docs/testing):
   - Success: `4242 4242 4242 4242`
   - Decline: `4000 0000 0000 0002`
   - Requires Auth: `4000 0025 0000 3155`

---

## OpenAI Setup

Enable AI-powered features with OpenAI.

### Get API Key

1. Go to [platform.openai.com](https://platform.openai.com)
2. Create an account or log in
3. Navigate to **API Keys**
4. Create a new secret key
5. Copy the key (starts with `sk-`)

### Configure in Rental Gates

1. Go to **Site Admin → Integrations**
2. Enter your OpenAI API Key
3. Select default model (GPT-4 recommended)
4. Set monthly credit limit per organization
5. Save settings

### AI Features Available

| Feature | Credits | Description |
|---------|---------|-------------|
| Listing Description | 1 | Generate property descriptions |
| Tenant Screening | 2 | Analyze applications |
| Lease Analysis | 2 | Review lease terms |
| Maintenance Triage | 1 | Categorize work orders |
| Message Draft | 1 | Draft communications |

### Credit System

- Credits reset monthly
- Track usage in **AI Tools** section
- Set limits per organization in plans

---

## Map Provider Setup

Choose between Google Maps or OpenStreetMap.

### Google Maps (Recommended)

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project
3. Enable APIs:
   - Maps JavaScript API
   - Places API
   - Geocoding API
4. Create API Key under **Credentials**
5. Restrict key to your domain

Configure in Rental Gates:
```
Site Admin → Integrations → Google Maps API Key
```

### OpenStreetMap (Free)

No API key required. Uses:
- Leaflet.js for maps
- Nominatim for geocoding

Select in settings:
```
Site Admin → Settings → Map Provider → OpenStreetMap
```

---

## Email Configuration

### Default WordPress Mail

Rental Gates uses WordPress's `wp_mail()` function by default. Ensure your server can send email.

### SMTP Configuration (Recommended)

For reliable delivery, use an SMTP plugin:

1. Install **WP Mail SMTP** or similar
2. Configure with your email provider:
   - SendGrid
   - Mailgun
   - Amazon SES
   - Gmail
   - SMTP server

### Email Templates

Customize email templates at:
```
Site Admin → Email Templates
```

Available templates:
- Welcome Email
- Password Reset
- Payment Receipt
- Payment Reminder
- Payment Overdue
- Lease Created
- Lease Ending
- Application Received
- Application Approved/Declined
- Maintenance Updates
- Announcements
- And more...

### Test Email Delivery

1. Go to **Site Admin → System Health**
2. Click **Send Test Email**
3. Verify receipt

---

## PWA Configuration

Enable Progressive Web App features for mobile users.

### Enable PWA

1. Go to **Site Admin → PWA Settings**
2. Toggle **Enable PWA Features**
3. Configure:
   - App Name
   - Short Name (max 12 chars)
   - Theme Color
   - Background Color

### Push Notifications

1. Enable **Push Notifications** in PWA Settings
2. VAPID keys are generated automatically
3. Users can subscribe via browser prompt

### Requirements

- HTTPS required
- Service Worker supported browsers
- Modern mobile browsers (Chrome, Safari, Firefox)

---

## Post-Installation Steps

### 1. Flush Permalinks

```
WordPress Admin → Settings → Permalinks → Save Changes
```

This ensures all Rental Gates URLs work correctly.

### 2. Create Sample Data (Optional)

Use the testing tools to create sample data:
```
Site Admin → Support → Generate Test Data
```

### 3. Customize Branding

- Upload organization logo
- Set brand colors
- Customize email templates

### 4. Invite Team Members

1. Go to **Dashboard → Staff**
2. Click **Add Staff Member**
3. Assign role and permissions
4. Send invitation email

### 5. Add Your First Building

1. Go to **Dashboard → Buildings**
2. Click **Add Building**
3. Click on map to place pin
4. Fill in property details
5. Add units to the building

### 6. Configure Automations

Set up automatic workflows:
```
Dashboard → Settings → Automation
```

- Payment reminders
- Late fee application
- Lease renewal notices
- Maintenance notifications

---

## Troubleshooting

### Common Issues

#### "Page Not Found" Errors

**Solution:** Flush permalinks
```
Settings → Permalinks → Save Changes
```

#### Database Tables Missing

**Solution:** Deactivate and reactivate plugin
```
Plugins → Deactivate Rental Gates
Plugins → Activate Rental Gates
```

#### Map Not Loading

**Solutions:**
1. Check API key is correct
2. Verify API is enabled in Google Console
3. Check browser console for errors
4. Try switching to OpenStreetMap

#### Emails Not Sending

**Solutions:**
1. Check server mail configuration
2. Install SMTP plugin
3. Check spam folders
4. Verify email templates

#### Payments Failing

**Solutions:**
1. Verify Stripe API keys
2. Check webhook configuration
3. Ensure HTTPS is enabled
4. Test with Stripe test cards

#### Memory Limit Errors

**Solution:** Increase PHP memory limit

In `wp-config.php`:
```php
define('WP_MEMORY_LIMIT', '256M');
```

Or in `.htaccess`:
```
php_value memory_limit 256M
```

### Debug Mode

Enable WordPress debug logging:

```php
// wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

Check logs at: `/wp-content/debug.log`

### System Health Check

```
Site Admin → System Health
```

Displays:
- PHP version and extensions
- Database status
- Cron jobs status
- API connections
- Disk space

---

## Upgrading

### Automatic Updates

1. Go to **Plugins**
2. Find "Rental Gates"
3. Click **Update Now** (when available)

### Manual Update

1. **Backup first!**
2. Download new version
3. Deactivate current plugin
4. Delete plugin folder (not database)
5. Upload new version
6. Activate plugin

### Database Migrations

Migrations run automatically on activation. The plugin tracks versions and only runs necessary updates.

---

## Uninstallation

### Keep Data (Deactivate Only)

1. Go to **Plugins**
2. Click **Deactivate** on Rental Gates
3. Data remains in database

### Complete Removal

1. Deactivate plugin
2. Click **Delete**
3. Confirm deletion

**Warning:** This removes all plugin data including:
- 49 database tables
- All properties, tenants, leases
- Payment history
- Documents and files

### Manual Cleanup

If needed, remove database tables manually:

```sql
-- Get all Rental Gates tables
SHOW TABLES LIKE 'wp_rg_%';

-- Drop tables (CAREFUL!)
DROP TABLE wp_rg_organizations;
-- ... etc
```

---

## Getting Help

### Resources

- **Documentation:** `/rental-gates/docs/`
- **Support Tools:** Site Admin → Support
- **Activity Log:** Site Admin → Activity Log
- **System Health:** Site Admin → System Health

### Contact Support

When requesting support, provide:
- WordPress version
- PHP version
- Plugin version
- Steps to reproduce issue
- Error messages
- Browser/device info

---

*Installation Guide v2.24.1*
