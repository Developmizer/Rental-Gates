<?php
/**
 * Tenant Form Section (Add/Edit)
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Determine if editing - PRIMARY method: parse REQUEST_URI directly
$tenant_id = 0;
$tenant = null;
$is_edit = false;

if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    // Match /tenants/123 or /tenants/123/edit but NOT /tenants/add
    if (preg_match('#/tenants/(\d+)(?:/edit)?(?:/|$|\?)#', $uri, $matches)) {
        $tenant_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$tenant_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    if (count($parts) >= 2 && $parts[1] !== 'add' && is_numeric($parts[1])) {
        $tenant_id = intval($parts[1]);
    }
}

if ($tenant_id) {
    $tenant = Rental_Gates_Tenant::get($tenant_id);
    
    if (!$tenant || $tenant['organization_id'] !== $org_id) {
        wp_redirect(home_url('/rental-gates/dashboard/tenants'));
        exit;
    }
    
    $is_edit = true;
}

$page_title = $is_edit ? __('Edit Tenant', 'rental-gates') : __('Add Tenant', 'rental-gates');
?>

<style>
    .rg-form-container { max-width: 800px; }
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    .rg-form-header { margin-bottom: 24px; }
    .rg-form-header h1 { font-size: 24px; font-weight: 700; margin: 0; }
    .rg-form-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-form-section { padding: 24px; border-bottom: 1px solid var(--gray-100); }
    .rg-form-section:last-child { border-bottom: none; }
    .rg-form-section-title { font-size: 16px; font-weight: 600; margin-bottom: 20px; color: var(--gray-900); }
    .rg-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .rg-form-row:last-child { margin-bottom: 0; }
    .rg-form-row.full { grid-template-columns: 1fr; }
    .rg-form-group { display: flex; flex-direction: column; gap: 6px; }
    .rg-form-label { font-size: 14px; font-weight: 500; color: var(--gray-700); }
    .rg-form-label .required { color: #ef4444; }
    .rg-form-input, .rg-form-select, .rg-form-textarea { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; font-family: inherit; transition: border-color 0.2s, box-shadow 0.2s; }
    .rg-form-input:focus, .rg-form-select:focus, .rg-form-textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1); }
    .rg-form-textarea { min-height: 100px; resize: vertical; }
    .rg-form-hint { font-size: 12px; color: var(--gray-500); }
    .rg-radio-group { display: flex; gap: 20px; }
    .rg-radio-item { display: flex; align-items: center; gap: 8px; cursor: pointer; }
    .rg-radio-item input { margin: 0; }
    .rg-form-actions { display: flex; justify-content: flex-end; gap: 12px; padding: 20px 24px; background: var(--gray-50); border-top: 1px solid var(--gray-100); border-radius: 0 0 12px 12px; }
    .rg-alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .rg-alert-error { background: #fee2e2; color: #991b1b; }
    .rg-alert-success { background: #d1fae5; color: #065f46; }
    @media (max-width: 640px) {
        .rg-form-row { grid-template-columns: 1fr; }
        .rg-radio-group { flex-direction: column; gap: 12px; }
        .rg-form-actions { flex-direction: column; }
        .rg-form-actions .rg-btn { width: 100%; }
    }
</style>

<div class="rg-form-container">
    <a href="<?php echo home_url('/rental-gates/dashboard/tenants' . ($is_edit ? '/' . $tenant_id : '')); ?>" class="rg-back-link">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
        <?php echo $is_edit ? __('Back to Tenant', 'rental-gates') : __('Back to Tenants', 'rental-gates'); ?>
    </a>
    
    <div class="rg-form-header">
        <h1><?php echo $page_title; ?></h1>
    </div>
    
    <div id="form-alert"></div>
    
    <form id="tenant-form" class="rg-form-card">
        <input type="hidden" name="tenant_id" value="<?php echo $tenant_id; ?>">
        
        <!-- Personal Information -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Personal Information', 'rental-gates'); ?></h3>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="first_name"><?php _e('First Name', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="text" id="first_name" name="first_name" class="rg-form-input" value="<?php echo esc_attr($tenant['first_name'] ?? ''); ?>" required>
                </div>
                <div class="rg-form-group">
                    <label class="rg-form-label" for="last_name"><?php _e('Last Name', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="text" id="last_name" name="last_name" class="rg-form-input" value="<?php echo esc_attr($tenant['last_name'] ?? ''); ?>" required>
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="email"><?php _e('Email Address', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="email" id="email" name="email" class="rg-form-input" value="<?php echo esc_attr($tenant['email'] ?? ''); ?>" required>
                </div>
                <div class="rg-form-group">
                    <label class="rg-form-label" for="phone"><?php _e('Phone Number', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="tel" id="phone" name="phone" class="rg-form-input" value="<?php echo esc_attr($tenant['phone'] ?? ''); ?>" required>
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="date_of_birth"><?php _e('Date of Birth', 'rental-gates'); ?></label>
                    <input type="date" id="date_of_birth" name="date_of_birth" class="rg-form-input" value="<?php echo esc_attr($tenant['date_of_birth'] ?? ''); ?>">
                </div>
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Preferred Contact', 'rental-gates'); ?></label>
                    <div class="rg-radio-group">
                        <label class="rg-radio-item">
                            <input type="radio" name="preferred_contact" value="email" <?php checked(($tenant['preferred_contact'] ?? 'email'), 'email'); ?>>
                            <?php _e('Email', 'rental-gates'); ?>
                        </label>
                        <label class="rg-radio-item">
                            <input type="radio" name="preferred_contact" value="phone" <?php checked(($tenant['preferred_contact'] ?? ''), 'phone'); ?>>
                            <?php _e('Phone', 'rental-gates'); ?>
                        </label>
                        <label class="rg-radio-item">
                            <input type="radio" name="preferred_contact" value="text" <?php checked(($tenant['preferred_contact'] ?? ''), 'text'); ?>>
                            <?php _e('Text', 'rental-gates'); ?>
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="status"><?php _e('Status', 'rental-gates'); ?></label>
                    <select id="status" name="status" class="rg-form-select">
                        <option value="prospect" <?php selected(($tenant['status'] ?? 'prospect'), 'prospect'); ?>><?php _e('Prospect', 'rental-gates'); ?></option>
                        <option value="active" <?php selected(($tenant['status'] ?? ''), 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
                        <option value="former" <?php selected(($tenant['status'] ?? ''), 'former'); ?>><?php _e('Former', 'rental-gates'); ?></option>
                    </select>
                    <span class="rg-form-hint"><?php _e('Active tenants have a current lease', 'rental-gates'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Emergency Contact -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Emergency Contact', 'rental-gates'); ?></h3>
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="emergency_contact_name"><?php _e('Contact Name', 'rental-gates'); ?></label>
                    <input type="text" id="emergency_contact_name" name="emergency_contact_name" class="rg-form-input" value="<?php echo esc_attr($tenant['emergency_contact_name'] ?? ''); ?>">
                </div>
                <div class="rg-form-group">
                    <label class="rg-form-label" for="emergency_contact_phone"><?php _e('Contact Phone', 'rental-gates'); ?></label>
                    <input type="tel" id="emergency_contact_phone" name="emergency_contact_phone" class="rg-form-input" value="<?php echo esc_attr($tenant['emergency_contact_phone'] ?? ''); ?>">
                </div>
            </div>
        </div>
        
        <!-- Notes -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Additional Information', 'rental-gates'); ?></h3>
            <div class="rg-form-row full">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="notes"><?php _e('Notes', 'rental-gates'); ?></label>
                    <textarea id="notes" name="notes" class="rg-form-textarea" placeholder="<?php _e('Internal notes about this tenant...', 'rental-gates'); ?>"><?php echo esc_textarea($tenant['notes'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>
        
        <div class="rg-form-actions">
            <a href="<?php echo home_url('/rental-gates/dashboard/tenants'); ?>" class="rg-btn rg-btn-secondary"><?php _e('Cancel', 'rental-gates'); ?></a>
            <button type="submit" class="rg-btn rg-btn-primary" id="submit-btn">
                <?php echo $is_edit ? __('Update Tenant', 'rental-gates') : __('Add Tenant', 'rental-gates'); ?>
            </button>
        </div>
    </form>
</div>

<script>
document.getElementById('tenant-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submit-btn');
    const alertContainer = document.getElementById('form-alert');
    
    submitBtn.disabled = true;
    submitBtn.textContent = '<?php _e('Saving...', 'rental-gates'); ?>';
    
    const formData = new FormData(this);
    formData.append('action', '<?php echo $is_edit ? 'rental_gates_update_tenant' : 'rental_gates_create_tenant'; ?>');
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/tenants/'); ?>' + data.data.id;
        } else {
            alertContainer.innerHTML = `<div class="rg-alert rg-alert-error">${data.data || '<?php _e('Error saving tenant', 'rental-gates'); ?>'}</div>`;
            alertContainer.scrollIntoView({ behavior: 'smooth' });
            submitBtn.disabled = false;
            submitBtn.textContent = '<?php echo $is_edit ? __('Update Tenant', 'rental-gates') : __('Add Tenant', 'rental-gates'); ?>';
        }
    })
    .catch(error => {
        alertContainer.innerHTML = `<div class="rg-alert rg-alert-error"><?php _e('Error saving tenant', 'rental-gates'); ?></div>`;
        submitBtn.disabled = false;
        submitBtn.textContent = '<?php echo $is_edit ? __('Update Tenant', 'rental-gates') : __('Add Tenant', 'rental-gates'); ?>';
    });
});
</script>
