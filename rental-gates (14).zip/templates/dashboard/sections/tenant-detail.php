<?php
/**
 * Tenant Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get tenant ID from URL - PRIMARY method: parse REQUEST_URI directly
$tenant_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/tenants/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $tenant_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$tenant_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    $tenant_id = isset($parts[1]) ? intval($parts[1]) : 0;
}

if (!$tenant_id) {
    wp_redirect(home_url('/rental-gates/dashboard/tenants'));
    exit;
}

$tenant = Rental_Gates_Tenant::get($tenant_id);

if (!$tenant || $tenant['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/tenants'));
    exit;
}

// Get lease history
$lease_history = Rental_Gates_Tenant::get_lease_history($tenant_id);
$current_lease = Rental_Gates_Tenant::get_current_lease($tenant_id);

// Status config
$status_config = array(
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'former' => array('label' => __('Former', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'prospect' => array('label' => __('Prospect', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
);

$status = $status_config[$tenant['status']] ?? $status_config['prospect'];
$initials = strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1));
?>

<style>
    .rg-tenant-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 24px;
    }
    
    .rg-back-link {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--gray-500);
        text-decoration: none;
        font-size: 14px;
        margin-bottom: 16px;
    }
    
    .rg-back-link:hover {
        color: var(--primary);
    }
    
    .rg-tenant-profile {
        display: flex;
        align-items: center;
        gap: 16px;
    }
    
    .rg-tenant-avatar-lg {
        width: 72px;
        height: 72px;
        border-radius: 50%;
        background: var(--primary);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 24px;
    }
    
    .rg-tenant-profile h1 {
        font-size: 24px;
        font-weight: 700;
        margin: 0 0 4px 0;
    }
    
    .rg-tenant-profile p {
        color: var(--gray-500);
        margin: 0;
    }
    
    .rg-header-actions {
        display: flex;
        gap: 12px;
    }
    
    .rg-tenant-grid {
        display: grid;
        grid-template-columns: 1fr 340px;
        gap: 24px;
    }
    
    .rg-tenant-main {
        min-width: 0;
    }
    
    .rg-tenant-aside {
        min-width: 0;
    }
    
    .rg-card {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        margin-bottom: 24px;
    }
    
    .rg-card-header {
        padding: 16px 20px;
        border-bottom: 1px solid var(--gray-100);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .rg-card-header h3 {
        font-size: 16px;
        font-weight: 600;
        margin: 0;
    }
    
    .rg-card-body {
        padding: 20px;
    }
    
    .rg-info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
    }
    
    .rg-info-item {
        padding: 12px 0;
    }
    
    .rg-info-item.full {
        grid-column: span 2;
    }
    
    .rg-info-label {
        font-size: 12px;
        color: var(--gray-500);
        margin-bottom: 4px;
    }
    
    .rg-info-value {
        font-size: 14px;
        color: var(--gray-900);
    }
    
    .rg-info-value a {
        color: var(--primary);
        text-decoration: none;
    }
    
    .rg-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
    }
    
    .rg-status-badge .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }
    
    .rg-portal-status {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px;
        background: var(--gray-50);
        border-radius: 8px;
    }
    
    .rg-portal-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .rg-portal-icon.active {
        background: #d1fae5;
        color: #10b981;
    }
    
    .rg-portal-icon.inactive {
        background: var(--gray-200);
        color: var(--gray-500);
    }
    
    .rg-portal-info strong {
        display: block;
        font-size: 14px;
    }
    
    .rg-portal-info span {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-lease-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 0;
        border-bottom: 1px solid var(--gray-100);
    }
    
    .rg-lease-item:last-child {
        border-bottom: none;
    }
    
    .rg-lease-info strong {
        display: block;
        font-size: 14px;
        margin-bottom: 2px;
    }
    
    .rg-lease-info span {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-lease-status {
        font-size: 12px;
        padding: 4px 10px;
        border-radius: 20px;
    }
    
    .rg-empty-section {
        text-align: center;
        padding: 30px;
        color: var(--gray-500);
    }
    
    .rg-btn-danger {
        background: #fee2e2;
        color: #dc2626;
        border-color: #fca5a5;
    }
    
    .rg-btn-danger:hover {
        background: #fecaca;
    }
    
    @media (max-width: 992px) {
        .rg-tenant-grid {
            grid-template-columns: 1fr;
        }
        
        .rg-tenant-aside {
            order: -1;
        }
    }
    
    @media (max-width: 576px) {
        .rg-tenant-header {
            flex-direction: column;
            gap: 16px;
        }
        
        .rg-header-actions {
            width: 100%;
        }
        
        .rg-header-actions .rg-btn {
            flex: 1;
        }
        
        .rg-info-grid {
            grid-template-columns: 1fr;
        }
        
        .rg-info-item.full {
            grid-column: span 1;
        }
    }
</style>

<!-- Back Link -->
<a href="<?php echo home_url('/rental-gates/dashboard/tenants'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
    </svg>
    <?php _e('Back to Tenants', 'rental-gates'); ?>
</a>

<!-- Header -->
<div class="rg-tenant-header">
    <div class="rg-tenant-profile">
        <div class="rg-tenant-avatar-lg"><?php echo $initials; ?></div>
        <div>
            <h1><?php echo esc_html($tenant['full_name']); ?></h1>
            <p>
                <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                    <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                    <?php echo $status['label']; ?>
                </span>
            </p>
        </div>
    </div>
    <div class="rg-header-actions">
        <a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $tenant['id'] . '/edit'); ?>" class="rg-btn rg-btn-secondary">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
            </svg>
            <?php _e('Edit', 'rental-gates'); ?>
        </a>
        <?php if (!$tenant['has_portal_access']): ?>
        <button type="button" class="rg-btn rg-btn-primary" onclick="inviteToPortal(<?php echo $tenant['id']; ?>)">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            <?php _e('Invite to Portal', 'rental-gates'); ?>
        </button>
        <?php endif; ?>
        <button type="button" class="rg-btn rg-btn-danger" onclick="deleteTenant(<?php echo $tenant['id']; ?>)">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
            </svg>
            <?php _e('Delete', 'rental-gates'); ?>
        </button>
    </div>
</div>

<div class="rg-tenant-grid">
    <div class="rg-tenant-main">
        <!-- Contact Information -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Contact Information', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Email', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <a href="mailto:<?php echo esc_attr($tenant['email']); ?>"><?php echo esc_html($tenant['email']); ?></a>
                        </div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Phone', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <a href="tel:<?php echo esc_attr($tenant['phone']); ?>"><?php echo esc_html($tenant['phone']); ?></a>
                        </div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Preferred Contact', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo ucfirst($tenant['preferred_contact']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Date of Birth', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <?php echo $tenant['date_of_birth'] ? date('F j, Y', strtotime($tenant['date_of_birth'])) : '—'; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Emergency Contact -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Emergency Contact', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <?php if ($tenant['emergency_contact_name'] || $tenant['emergency_contact_phone']): ?>
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Name', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($tenant['emergency_contact_name'] ?: '—'); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Phone', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <?php if ($tenant['emergency_contact_phone']): ?>
                            <a href="tel:<?php echo esc_attr($tenant['emergency_contact_phone']); ?>"><?php echo esc_html($tenant['emergency_contact_phone']); ?></a>
                            <?php else: ?>
                            —
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="rg-empty-section">
                    <?php _e('No emergency contact on file', 'rental-gates'); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Lease History -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Lease History', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <?php if (!empty($lease_history)): ?>
                    <?php foreach ($lease_history as $lease): 
                        $lease_status_colors = array(
                            'active' => array('bg' => '#d1fae5', 'color' => '#10b981'),
                            'pending' => array('bg' => '#fef3c7', 'color' => '#f59e0b'),
                            'expired' => array('bg' => '#f3f4f6', 'color' => '#6b7280'),
                            'terminated' => array('bg' => '#fee2e2', 'color' => '#ef4444'),
                        );
                        $l_status = $lease_status_colors[$lease['status']] ?? $lease_status_colors['pending'];
                    ?>
                    <div class="rg-lease-item">
                        <div class="rg-lease-info">
                            <strong><?php echo esc_html($lease['unit_name']); ?></strong>
                            <span><?php echo esc_html($lease['building_name']); ?> • 
                                <?php echo date('M Y', strtotime($lease['start_date'])); ?> - 
                                <?php echo date('M Y', strtotime($lease['end_date'])); ?>
                            </span>
                        </div>
                        <span class="rg-lease-status" style="background: <?php echo $l_status['bg']; ?>; color: <?php echo $l_status['color']; ?>;">
                            <?php echo ucfirst($lease['status']); ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div class="rg-empty-section">
                    <?php _e('No lease history', 'rental-gates'); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Notes -->
        <?php if (!empty($tenant['notes'])): ?>
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Notes', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <p style="white-space: pre-wrap; margin: 0;"><?php echo esc_html($tenant['notes']); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="rg-tenant-aside">
        <!-- Portal Access -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Portal Access', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-portal-status">
                    <div class="rg-portal-icon <?php echo $tenant['has_portal_access'] ? 'active' : 'inactive'; ?>">
                        <?php if ($tenant['has_portal_access']): ?>
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        <?php else: ?>
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                        <?php endif; ?>
                    </div>
                    <div class="rg-portal-info">
                        <strong>
                            <?php echo $tenant['has_portal_access'] 
                                ? __('Portal Access Active', 'rental-gates') 
                                : __('No Portal Access', 'rental-gates'); ?>
                        </strong>
                        <span>
                            <?php echo $tenant['has_portal_access'] 
                                ? __('Tenant can login to view their lease and make payments', 'rental-gates') 
                                : __('Invite tenant to create their account', 'rental-gates'); ?>
                        </span>
                    </div>
                </div>
                
                <?php if (!$tenant['has_portal_access']): ?>
                <button type="button" class="rg-btn rg-btn-primary" style="width: 100%; margin-top: 16px;" onclick="inviteToPortal(<?php echo $tenant['id']; ?>)">
                    <?php _e('Send Portal Invitation', 'rental-gates'); ?>
                </button>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Info -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Quick Info', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Tenant ID', 'rental-gates'); ?></div>
                    <div class="rg-info-value">#<?php echo $tenant['id']; ?></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Added On', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('F j, Y', strtotime($tenant['created_at'])); ?></div>
                </div>
                <?php if ($current_lease): ?>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Current Lease Ends', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('F j, Y', strtotime($current_lease['end_date'])); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Documents Widget -->
        <?php 
        $entity_type = 'tenant';
        $entity_id = $tenant['id'];
        include RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/partials/documents-widget.php';
        ?>
    </div>
</div>

<script>
function inviteToPortal(tenantId) {
    RentalGates.confirmDelete({
        title: '<?php _e('Send Portal Invitation', 'rental-gates'); ?>',
        message: '<?php _e('Send portal invitation to this tenant? They will receive an email with login credentials.', 'rental-gates'); ?>',
        ajaxAction: 'rental_gates_invite_tenant',
        ajaxData: { tenant_id: tenantId },
        onConfirm: function() {
            RentalGates.showToast('<?php _e('Invitation sent successfully!', 'rental-gates'); ?>', 'success');
            window.location.reload();
        }
    });
}

function deleteTenant(tenantId, tenantName) {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Tenant', 'rental-gates'); ?>',
        message: '<?php _e('Are you sure you want to delete this tenant? This action cannot be undone.', 'rental-gates'); ?>',
        itemName: tenantName || '<?php echo esc_js(($tenant['first_name'] ?? '') . ' ' . ($tenant['last_name'] ?? '')); ?>',
        ajaxAction: 'rental_gates_delete_tenant',
        ajaxData: { tenant_id: tenantId },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/tenants'); ?>'
    });
}
</script>
