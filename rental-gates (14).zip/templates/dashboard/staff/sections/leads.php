<?php
/**
 * Staff Portal - Leads Section
 * Manage prospective tenants and inquiries
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Get permission level
$perm = $permissions['leads'] ?? 'none';
$can_edit = ($perm === 'edit' || $perm === 'full');

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$page_num = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;
$offset = ($page_num - 1) * $per_page;

// Build query
$where = array("l.organization_id = %d");
$params = array($org_id);

if ($status_filter) {
    $where[] = "l.status = %s";
    $params[] = $status_filter;
}

if ($search) {
    $where[] = "(l.first_name LIKE %s OR l.last_name LIKE %s OR l.email LIKE %s OR l.phone LIKE %s)";
    $search_like = '%' . $wpdb->esc_like($search) . '%';
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
}

$where_sql = implode(' AND ', $where);

// Get total count
$total = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$tables['leads']} l WHERE {$where_sql}",
    $params
));

// Get leads
$params[] = $per_page;
$params[] = $offset;

$leads = $wpdb->get_results($wpdb->prepare(
    "SELECT l.*, u.name as interested_unit, b.name as building_name
     FROM {$tables['leads']} l
     LEFT JOIN {$tables['units']} u ON l.interested_unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     WHERE {$where_sql}
     ORDER BY l.created_at DESC
     LIMIT %d OFFSET %d",
    $params
), ARRAY_A);

$total_pages = ceil($total / $per_page);

// Get stats
$stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'new' THEN 1 END) as new_count,
        COUNT(CASE WHEN status = 'contacted' THEN 1 END) as contacted_count,
        COUNT(CASE WHEN status = 'qualified' THEN 1 END) as qualified_count,
        COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_count,
        COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as this_week
     FROM {$tables['leads']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);

$status_colors = array(
    'new' => '#3b82f6',
    'contacted' => '#f59e0b',
    'qualified' => '#8b5cf6',
    'showing_scheduled' => '#06b6d4',
    'converted' => '#10b981',
    'lost' => '#ef4444',
);
?>

<style>
    .rg-stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; text-align: center; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-bottom: 8px; }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    
    .rg-filters { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }
    .rg-search-box { flex: 1; min-width: 200px; position: relative; }
    .rg-search-box input { width: 100%; padding: 10px 12px 10px 40px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); }
    .rg-filter-select { padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background: #fff; }
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 16px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
    .rg-btn-secondary:hover { background: var(--gray-200); }
    
    .rg-leads-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px; }
    
    .rg-lead-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; transition: box-shadow 0.2s; }
    .rg-lead-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    
    .rg-lead-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; }
    .rg-lead-name { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .rg-lead-date { font-size: 12px; color: var(--gray-400); }
    
    .rg-lead-status { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; color: #fff; }
    
    .rg-lead-contact { margin: 12px 0; }
    .rg-lead-contact-item { display: flex; align-items: center; gap: 8px; font-size: 14px; color: var(--gray-600); margin-bottom: 6px; }
    .rg-lead-contact-item svg { width: 16px; height: 16px; color: var(--gray-400); }
    .rg-lead-contact-item a { color: var(--primary); text-decoration: none; }
    
    .rg-lead-interest { background: var(--gray-50); border-radius: 8px; padding: 12px; margin-top: 12px; }
    .rg-lead-interest-label { font-size: 11px; color: var(--gray-500); text-transform: uppercase; font-weight: 600; margin-bottom: 4px; }
    .rg-lead-interest-unit { font-size: 14px; color: var(--gray-900); }
    
    .rg-lead-source { font-size: 12px; color: var(--gray-500); margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--gray-100); }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; color: var(--gray-500); background: #fff; border-radius: 12px; border: 1px solid var(--gray-200); }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    
    .rg-pagination { display: flex; justify-content: center; gap: 8px; margin-top: 24px; }
    .rg-pagination a, .rg-pagination span { padding: 8px 12px; border-radius: 6px; text-decoration: none; font-size: 14px; }
    .rg-pagination a { color: var(--gray-600); background: #fff; border: 1px solid var(--gray-200); }
    .rg-pagination a:hover { background: var(--gray-50); }
    .rg-pagination .current { background: var(--primary); color: #fff; border-color: var(--primary); }
    
    @media (max-width: 1200px) {
        .rg-stats-row { grid-template-columns: repeat(3, 1fr); }
    }
    @media (max-width: 768px) {
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
        .rg-leads-grid { grid-template-columns: 1fr; }
    }
</style>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Total Leads', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo intval($stats['total']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('New', 'rental-gates'); ?></div>
        <div class="rg-stat-value" style="color: #3b82f6;"><?php echo intval($stats['new_count']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Contacted', 'rental-gates'); ?></div>
        <div class="rg-stat-value" style="color: #f59e0b;"><?php echo intval($stats['contacted_count']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Converted', 'rental-gates'); ?></div>
        <div class="rg-stat-value" style="color: #10b981;"><?php echo intval($stats['converted_count']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('This Week', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo intval($stats['this_week']); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" class="rg-filters">
    <div class="rg-search-box">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Search leads...', 'rental-gates'); ?>">
    </div>
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="new" <?php selected($status_filter, 'new'); ?>><?php _e('New', 'rental-gates'); ?></option>
        <option value="contacted" <?php selected($status_filter, 'contacted'); ?>><?php _e('Contacted', 'rental-gates'); ?></option>
        <option value="qualified" <?php selected($status_filter, 'qualified'); ?>><?php _e('Qualified', 'rental-gates'); ?></option>
        <option value="showing_scheduled" <?php selected($status_filter, 'showing_scheduled'); ?>><?php _e('Showing Scheduled', 'rental-gates'); ?></option>
        <option value="converted" <?php selected($status_filter, 'converted'); ?>><?php _e('Converted', 'rental-gates'); ?></option>
        <option value="lost" <?php selected($status_filter, 'lost'); ?>><?php _e('Lost', 'rental-gates'); ?></option>
    </select>
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Search', 'rental-gates'); ?></button>
</form>

<!-- Leads Grid -->
<?php if (empty($leads)): ?>
<div class="rg-empty-state">
    <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
    <h3><?php _e('No leads found', 'rental-gates'); ?></h3>
    <p><?php _e('Leads from your property listings will appear here.', 'rental-gates'); ?></p>
</div>
<?php else: ?>
<div class="rg-leads-grid">
    <?php foreach ($leads as $lead): 
        $status_color = $status_colors[$lead['status']] ?? '#6b7280';
    ?>
    <div class="rg-lead-card">
        <div class="rg-lead-header">
            <div>
                <h3 class="rg-lead-name"><?php echo esc_html($lead['first_name'] . ' ' . $lead['last_name']); ?></h3>
                <div class="rg-lead-date"><?php echo human_time_diff(strtotime($lead['created_at']), current_time('timestamp')) . ' ' . __('ago', 'rental-gates'); ?></div>
            </div>
            <span class="rg-lead-status" style="background: <?php echo $status_color; ?>;">
                <?php echo esc_html(ucfirst(str_replace('_', ' ', $lead['status']))); ?>
            </span>
        </div>
        
        <div class="rg-lead-contact">
            <?php if ($lead['email']): ?>
            <div class="rg-lead-contact-item">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                <a href="mailto:<?php echo esc_attr($lead['email']); ?>"><?php echo esc_html($lead['email']); ?></a>
            </div>
            <?php endif; ?>
            <?php if ($lead['phone']): ?>
            <div class="rg-lead-contact-item">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <a href="tel:<?php echo esc_attr($lead['phone']); ?>"><?php echo esc_html($lead['phone']); ?></a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if ($lead['interested_unit']): ?>
        <div class="rg-lead-interest">
            <div class="rg-lead-interest-label"><?php _e('Interested In', 'rental-gates'); ?></div>
            <div class="rg-lead-interest-unit"><?php echo esc_html($lead['interested_unit'] . ' - ' . $lead['building_name']); ?></div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($lead['source'])): ?>
        <div class="rg-lead-source">
            <strong><?php _e('Source:', 'rental-gates'); ?></strong> <?php echo esc_html(ucfirst($lead['source'])); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>

<?php if ($total_pages > 1): ?>
<div class="rg-pagination">
    <?php if ($page_num > 1): ?>
    <a href="<?php echo esc_url(add_query_arg('paged', $page_num - 1)); ?>">&laquo; <?php _e('Previous', 'rental-gates'); ?></a>
    <?php endif; ?>
    
    <?php for ($i = max(1, $page_num - 2); $i <= min($total_pages, $page_num + 2); $i++): ?>
        <?php if ($i === $page_num): ?>
        <span class="current"><?php echo $i; ?></span>
        <?php else: ?>
        <a href="<?php echo esc_url(add_query_arg('paged', $i)); ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>
    
    <?php if ($page_num < $total_pages): ?>
    <a href="<?php echo esc_url(add_query_arg('paged', $page_num + 1)); ?>"><?php _e('Next', 'rental-gates'); ?> &raquo;</a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>
