<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Reset Password', 'rental-gates'); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Plus Jakarta Sans', -apple-system, sans-serif; background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .reset-container { width: 100%; max-width: 420px; }
        .reset-card { background: #fff; border-radius: 16px; padding: 40px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); }
        .reset-logo { text-align: center; margin-bottom: 32px; }
        .reset-logo h1 { font-size: 28px; font-weight: 700; color: #1e3a5f; }
        .reset-logo p { color: #64748b; margin-top: 8px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 6px; }
        .form-group input { width: 100%; padding: 12px 16px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 16px; transition: all 0.2s; }
        .form-group input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
        .form-hint { font-size: 12px; color: #64748b; margin-top: 6px; }
        .btn { width: 100%; padding: 14px; background: #2563eb; color: #fff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.2s; }
        .btn:hover { background: #1d4ed8; }
        .btn:disabled { background: #94a3b8; cursor: not-allowed; }
        .reset-footer { text-align: center; margin-top: 24px; color: #64748b; font-size: 14px; }
        .reset-footer a { color: #2563eb; text-decoration: none; font-weight: 500; }
        .reset-footer a:hover { text-decoration: underline; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
        .password-strength { height: 4px; border-radius: 2px; margin-top: 8px; transition: all 0.3s; }
        .password-strength.weak { background: #ef4444; width: 33%; }
        .password-strength.medium { background: #f59e0b; width: 66%; }
        .password-strength.strong { background: #10b981; width: 100%; }
        .strength-text { font-size: 12px; margin-top: 4px; }
        .strength-text.weak { color: #ef4444; }
        .strength-text.medium { color: #f59e0b; }
        .strength-text.strong { color: #10b981; }
        
        /* Success state */
        .success-icon { width: 80px; height: 80px; background: #d1fae5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; }
        .success-icon svg { width: 40px; height: 40px; color: #10b981; }
        .success-message { text-align: center; }
        .success-message h2 { font-size: 24px; color: #1e3a5f; margin-bottom: 8px; }
        .success-message p { color: #64748b; margin-bottom: 24px; }
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="reset-card">
            <?php
            $key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
            $login = isset($_GET['login']) ? sanitize_text_field($_GET['login']) : '';
            $error = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';
            $success = isset($_GET['success']) ? true : false;
            
            // Verify the reset key if present
            $valid_key = false;
            if ($key && $login) {
                $user = check_password_reset_key($key, $login);
                $valid_key = !is_wp_error($user);
            }
            ?>
            
            <?php if ($success): ?>
            <!-- Success State -->
            <div class="success-message">
                <div class="success-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <h2><?php _e('Password Reset!', 'rental-gates'); ?></h2>
                <p><?php _e('Your password has been successfully reset. You can now log in with your new password.', 'rental-gates'); ?></p>
                <a href="<?php echo home_url('/rental-gates/login'); ?>" class="btn"><?php _e('Go to Login', 'rental-gates'); ?></a>
            </div>
            
            <?php elseif (!$key || !$login): ?>
            <!-- No Key State -->
            <div class="reset-logo">
                <h1><?php _e('Rental Gates', 'rental-gates'); ?></h1>
                <p><?php _e('Password Reset', 'rental-gates'); ?></p>
            </div>
            <div class="alert alert-error">
                <?php _e('Invalid password reset link. Please request a new one.', 'rental-gates'); ?>
            </div>
            <div class="reset-footer">
                <a href="<?php echo home_url('/rental-gates/login'); ?>"><?php _e('Back to Login', 'rental-gates'); ?></a>
            </div>
            
            <?php elseif (!$valid_key): ?>
            <!-- Invalid/Expired Key State -->
            <div class="reset-logo">
                <h1><?php _e('Rental Gates', 'rental-gates'); ?></h1>
                <p><?php _e('Password Reset', 'rental-gates'); ?></p>
            </div>
            <div class="alert alert-error">
                <?php _e('This password reset link has expired or is invalid. Please request a new one.', 'rental-gates'); ?>
            </div>
            <div class="reset-footer">
                <a href="<?php echo home_url('/rental-gates/login'); ?>"><?php _e('Back to Login', 'rental-gates'); ?></a>
            </div>
            
            <?php else: ?>
            <!-- Reset Form -->
            <div class="reset-logo">
                <h1><?php _e('Rental Gates', 'rental-gates'); ?></h1>
                <p><?php _e('Create a new password', 'rental-gates'); ?></p>
            </div>
            
            <div id="reset-alert" class="alert" style="display: none;"></div>
            
            <?php if ($error): ?>
            <div class="alert alert-error">
                <?php 
                switch ($error) {
                    case 'mismatch':
                        _e('Passwords do not match.', 'rental-gates');
                        break;
                    case 'short':
                        _e('Password must be at least 8 characters.', 'rental-gates');
                        break;
                    default:
                        _e('An error occurred. Please try again.', 'rental-gates');
                }
                ?>
            </div>
            <?php endif; ?>
            
            <form id="reset-form" method="post" action="">
                <input type="hidden" name="action" value="rental_gates_do_reset_password">
                <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
                <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>">
                <?php wp_nonce_field('rental_gates_reset_password', 'reset_nonce'); ?>
                
                <div class="form-group">
                    <label for="password"><?php _e('New Password', 'rental-gates'); ?></label>
                    <input type="password" id="password" name="password" required autocomplete="new-password" minlength="8">
                    <div class="password-strength" id="strengthBar"></div>
                    <div class="strength-text" id="strengthText"></div>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password"><?php _e('Confirm New Password', 'rental-gates'); ?></label>
                    <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password" minlength="8">
                    <div class="form-hint"><?php _e('Password must be at least 8 characters', 'rental-gates'); ?></div>
                </div>
                
                <button type="submit" class="btn" id="reset-btn">
                    <?php _e('Reset Password', 'rental-gates'); ?>
                </button>
            </form>
            
            <div class="reset-footer">
                <a href="<?php echo home_url('/rental-gates/login'); ?>"><?php _e('Back to Login', 'rental-gates'); ?></a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php wp_footer(); ?>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var passwordInput = document.getElementById('password');
        var confirmInput = document.getElementById('confirm_password');
        var strengthBar = document.getElementById('strengthBar');
        var strengthText = document.getElementById('strengthText');
        var form = document.getElementById('reset-form');
        var alert = document.getElementById('reset-alert');
        var btn = document.getElementById('reset-btn');
        
        if (passwordInput) {
            passwordInput.addEventListener('input', function() {
                var password = this.value;
                var strength = checkPasswordStrength(password);
                
                strengthBar.className = 'password-strength ' + strength.class;
                strengthText.className = 'strength-text ' + strength.class;
                strengthText.textContent = strength.text;
            });
        }
        
        function checkPasswordStrength(password) {
            var score = 0;
            
            if (password.length >= 8) score++;
            if (password.length >= 12) score++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
            if (/\d/.test(password)) score++;
            if (/[^a-zA-Z0-9]/.test(password)) score++;
            
            if (score <= 2) {
                return { class: 'weak', text: '<?php _e("Weak", "rental-gates"); ?>' };
            } else if (score <= 3) {
                return { class: 'medium', text: '<?php _e("Medium", "rental-gates"); ?>' };
            } else {
                return { class: 'strong', text: '<?php _e("Strong", "rental-gates"); ?>' };
            }
        }
        
        if (form) {
            form.addEventListener('submit', function(e) {
                var password = passwordInput.value;
                var confirm = confirmInput.value;
                
                // Client-side validation
                if (password.length < 8) {
                    e.preventDefault();
                    showAlert('<?php _e("Password must be at least 8 characters", "rental-gates"); ?>', 'error');
                    return;
                }
                
                if (password !== confirm) {
                    e.preventDefault();
                    showAlert('<?php _e("Passwords do not match", "rental-gates"); ?>', 'error');
                    return;
                }
                
                btn.disabled = true;
                btn.textContent = '<?php _e("Resetting...", "rental-gates"); ?>';
            });
        }
        
        function showAlert(message, type) {
            if (alert) {
                alert.className = 'alert alert-' + type;
                alert.textContent = message;
                alert.style.display = 'block';
            }
        }
    });
    </script>
</body>
</html>
