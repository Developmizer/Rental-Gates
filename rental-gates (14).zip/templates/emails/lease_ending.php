<?php
/**
 * Lease Ending Email Template
 */
if (!defined('ABSPATH')) exit;

$days_until = !empty($end_date) ? ceil((strtotime($end_date) - time()) / 86400) : 0;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Your Lease is Expiring Soon', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('This is a friendly reminder that your lease agreement is approaching its end date.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: center;">
        <tr>
            <td style="padding-bottom: 8px;">
                <p style="margin: 0; font-size: 14px; color: #92400e;">' . __('Lease Expires In', 'rental-gates') . '</p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 0; font-size: 48px; font-weight: 700; color: #92400e;">' . intval($days_until) . '</p>
            </td>
        </tr>
        <tr>
            <td style="padding-top: 4px;">
                <p style="margin: 0; font-size: 14px; color: #92400e;">' . __('days', 'rental-gates') . '</p>
            </td>
        </tr>
    </table>',
    'warning'
); ?>

<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($property_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $property_name);
}
if (!empty($unit_name)) {
    echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name);
}
echo Rental_Gates_Email::detail_row(__('Lease End Date', 'rental-gates'), date('F j, Y', strtotime($end_date ?? 'now')), true);
echo Rental_Gates_Email::details_table_end();
?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Your Options', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0; margin-bottom: 24px;">
    <tr>
        <td style="padding: 16px 20px; background-color: #f0fdf4; border-radius: 12px; margin-bottom: 12px;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; vertical-align: top; color: #10b981; font-size: 20px;">✓</td>
                    <td style="padding-left: 12px;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #166534;"><?php _e('Renew Your Lease', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #166534;"><?php _e('Continue living in your current home with a new lease.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><td style="height: 12px;"></td></tr>
    <tr>
        <td style="padding: 16px 20px; background-color: #f9fafb; border-radius: 12px;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 32px; vertical-align: top; color: #6b7280; font-size: 20px;">→</td>
                    <td style="padding-left: 12px;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #374151;"><?php _e('Move Out', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('Provide notice and prepare for your move.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/tenant'), __('View My Options', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('Please contact us as soon as possible to let us know your plans.', 'rental-gates'); ?>
</p>
