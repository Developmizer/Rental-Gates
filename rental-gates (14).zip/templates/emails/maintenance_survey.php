<?php
/**
 * Maintenance Survey Email Template
 * 
 * Variables: $tenant_name, $organization_name, $work_order_id, $work_order_title,
 *            $completed_date, $survey_url
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('How Did We Do?', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($tenant_name ?? 'Tenant')
));

echo Rental_Gates_Email::text(sprintf(
    __('Your recent maintenance request has been completed. We\'d love to hear your feedback!', 'rental-gates')
));

echo Rental_Gates_Email::alert(
    '<strong>' . esc_html($work_order_title ?? 'Maintenance Request') . '</strong><br>' .
    sprintf(__('Completed on %s', 'rental-gates'), esc_html($completed_date ?? date('F j, Y'))),
    'success'
);

echo Rental_Gates_Email::text(
    __('Your feedback helps us improve our service. Please take a moment to rate your experience:', 'rental-gates')
);

// Star rating visual
$rating_html = '<table role="presentation" style="margin: 20px auto; border: none; border-spacing: 0;"><tr>';
for ($i = 1; $i <= 5; $i++) {
    $star_url = !empty($survey_url) ? $survey_url . '?rating=' . $i : '#';
    $rating_html .= '<td style="padding: 0 8px;"><a href="' . esc_url($star_url) . '" style="text-decoration: none; font-size: 32px;">⭐</a></td>';
}
$rating_html .= '</tr><tr>';
$rating_html .= '<td style="text-align: center; padding-top: 5px; font-size: 11px; color: #6b7280;">Poor</td>';
$rating_html .= '<td></td><td></td><td></td>';
$rating_html .= '<td style="text-align: center; padding-top: 5px; font-size: 11px; color: #6b7280;">Great</td>';
$rating_html .= '</tr></table>';

echo $rating_html;

echo Rental_Gates_Email::text(
    __('Click a star above to rate your experience, or use the button below to provide detailed feedback.', 'rental-gates'),
    'center'
);

if (!empty($survey_url)) {
    echo Rental_Gates_Email::button(__('Leave Detailed Feedback', 'rental-gates'), $survey_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    __('Thank you for taking the time to share your thoughts. Your feedback is valuable to us!', 'rental-gates'),
    'small'
);
