<?php
/**
 * Lead Follow-up Email Template
 * 
 * Variables: $lead_name, $organization_name, $property_name, $agent_name,
 *            $message, $action_url, $organization_phone, $organization_email
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('Following Up on Your Interest', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($lead_name ?? 'there')
));

echo Rental_Gates_Email::text(sprintf(
    __('Thank you for your interest in %s! We wanted to follow up and see if you have any questions.', 'rental-gates'),
    esc_html($property_name ?? 'our properties')
));

if (!empty($message)) {
    echo Rental_Gates_Email::alert(
        nl2br(esc_html($message)),
        'info'
    );
}

echo Rental_Gates_Email::text(
    __('We\'d be happy to:', 'rental-gates') . '<br>' .
    '• ' . __('Schedule a tour at your convenience', 'rental-gates') . '<br>' .
    '• ' . __('Answer any questions about the property', 'rental-gates') . '<br>' .
    '• ' . __('Discuss availability and move-in dates', 'rental-gates') . '<br>' .
    '• ' . __('Walk you through the application process', 'rental-gates')
);

if (!empty($action_url)) {
    echo Rental_Gates_Email::button(__('Schedule a Tour', 'rental-gates'), $action_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    '<strong>' . __('Ready to connect?', 'rental-gates') . '</strong>'
);

$contact_info = '';
if (!empty($agent_name)) {
    $contact_info .= sprintf(__('Contact: %s', 'rental-gates'), esc_html($agent_name)) . '<br>';
}
if (!empty($organization_phone)) {
    $contact_info .= '📞 ' . esc_html($organization_phone) . '<br>';
}
if (!empty($organization_email)) {
    $contact_info .= '✉ ' . esc_html($organization_email);
}

if ($contact_info) {
    echo Rental_Gates_Email::text($contact_info, 'small');
}

echo Rental_Gates_Email::text(
    __('We look forward to helping you find your perfect home!', 'rental-gates'),
    'small'
);
