<?php
/**
 * Lease Renewal Offer Email Template
 * 
 * Variables: $tenant_name, $organization_name, $unit_name, $current_end_date,
 *            $new_rent_amount, $current_rent, $renewal_url, $response_deadline
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('Your Lease Renewal Offer', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($tenant_name ?? 'Tenant')
));

echo Rental_Gates_Email::text(sprintf(
    __('Your lease at %s is coming to an end on %s. We\'d love to have you stay!', 'rental-gates'),
    esc_html($unit_name ?? 'your unit'),
    esc_html($current_end_date ?? '')
));

echo Rental_Gates_Email::alert(
    '<strong>' . __('Renewal Offer Details', 'rental-gates') . '</strong>',
    'info'
);

echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), esc_html($unit_name ?? ''));
echo Rental_Gates_Email::detail_row(__('Current Lease Ends', 'rental-gates'), esc_html($current_end_date ?? ''));
echo Rental_Gates_Email::detail_row(__('Current Rent', 'rental-gates'), '$' . number_format($current_rent ?? 0, 2));
echo Rental_Gates_Email::detail_row(__('New Monthly Rent', 'rental-gates'), '$' . number_format($new_rent_amount ?? 0, 2));
if (!empty($response_deadline)) {
    echo Rental_Gates_Email::detail_row(__('Response Deadline', 'rental-gates'), esc_html($response_deadline), true);
} else {
    echo Rental_Gates_Email::detail_row(__('New Lease Term', 'rental-gates'), '12 months', true);
}
echo Rental_Gates_Email::details_table_end();

echo Rental_Gates_Email::text(
    __('Please review this offer and let us know your decision. We value you as a tenant and hope you\'ll choose to renew!', 'rental-gates')
);

if (!empty($renewal_url)) {
    echo Rental_Gates_Email::button(__('Review Renewal Offer', 'rental-gates'), $renewal_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    __('If you have any questions about the renewal terms or would like to discuss options, please contact us.', 'rental-gates'),
    'small'
);
