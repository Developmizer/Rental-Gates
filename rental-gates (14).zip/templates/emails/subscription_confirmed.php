<?php
/**
 * Subscription Confirmation Email Template
 * 
 * Sent when a user successfully subscribes to a plan.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $user_name
 * - $plan_name
 * - $billing_cycle (monthly/yearly)
 * - $amount
 * - $next_billing_date
 * - $subscription_id
 * - $dashboard_url
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Subscription Confirmed! 🎉', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($user_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Thank you for subscribing! Your subscription has been successfully activated and you now have full access to all features included in your plan.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; text-align: center; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
        <tr>
            <td style="word-break: break-word;">
                <p style="margin: 0 0 4px; font-size: 14px; color: #166534; font-weight: 500; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">' . __('Your Plan', 'rental-gates') . '</p>
                <p style="margin: 0 0 8px; font-size: 24px; font-weight: 700; color: #111827; line-height: 1.3; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">' . esc_html($plan_name ?? __('Unknown Plan', 'rental-gates')) . '</p>
                <p style="margin: 0; font-size: 20px; font-weight: 600; color: #166534; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">$' . esc_html($amount ?? '0.00') . ' <span style="font-size: 14px; font-weight: 400; color: #6b7280;">/' . esc_html($billing_cycle === 'yearly' ? __('year', 'rental-gates') : __('month', 'rental-gates')) . '</span></p>
            </td>
        </tr>
    </table>',
    'success'
); ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Subscription Details', 'rental-gates'); ?>
</h2>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Plan Name', 'rental-gates'), $plan_name ?? '-');
echo Rental_Gates_Email::detail_row(__('Billing Cycle', 'rental-gates'), ucfirst($billing_cycle ?? 'monthly'));
echo Rental_Gates_Email::detail_row(__('Amount', 'rental-gates'), '$' . ($amount ?? '0.00') . ' /' . ($billing_cycle === 'yearly' ? __('year', 'rental-gates') : __('month', 'rental-gates')));
if (!empty($next_billing_date)) {
    echo Rental_Gates_Email::detail_row(__('Next Billing Date', 'rental-gates'), $next_billing_date);
}
if (!empty($subscription_id)) {
    echo Rental_Gates_Email::detail_row(__('Subscription ID', 'rental-gates'), $subscription_id, true);
}
echo Rental_Gates_Email::details_table_end();
?>

<?php echo Rental_Gates_Email::divider(); ?>

<h2 style="margin: 0 0 16px; font-size: 18px; font-weight: 600; color: #111827; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('What\'s Next?', 'rental-gates'); ?>
</h2>

<p style="margin: 0 0 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('You can now access all features included in your plan. Here are some things you can do:', 'rental-gates'); ?>
</p>

<ul style="margin: 0 0 24px; padding-left: 20px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('Manage your subscription and billing information', 'rental-gates'); ?></li>
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('Access all premium features and modules', 'rental-gates'); ?></li>
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('View your usage statistics and limits', 'rental-gates'); ?></li>
    <li style="line-height: 1.7;"><?php _e('Update your payment method anytime', 'rental-gates'); ?></li>
</ul>

<?php if (!empty($dashboard_url)): ?>
    <?php echo Rental_Gates_Email::button($dashboard_url, __('Go to Dashboard', 'rental-gates'), 'primary'); ?>
<?php endif; ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('If you have any questions about your subscription or need assistance, please don\'t hesitate to contact our support team.', 'rental-gates'); ?>
</p>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        h1 {
            color: #f9fafb !important;
        }
        h2 {
            color: #f9fafb !important;
        }
        p {
            color: #d1d5db !important;
        }
        ul {
            color: #d1d5db !important;
        }
        li {
            color: #d1d5db !important;
        }
    }
    @media only screen and (max-width: 600px) {
        h1 {
            font-size: 24px !important;
        }
        h2 {
            font-size: 18px !important;
        }
        ul {
            padding-left: 18px !important;
        }
    }
</style>
