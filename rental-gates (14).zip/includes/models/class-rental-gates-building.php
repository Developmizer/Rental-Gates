<?php
/**
 * Rental Gates Building Model
 * Handles building data and operations
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Building {
    
    private static $table_name;
    
    public static function init() {
        $tables = Rental_Gates_Database::get_table_names();
        self::$table_name = $tables['buildings'];
    }
    
    /**
     * Create a new building
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate coordinates (required - no manual address)
        if (empty($data['latitude']) || empty($data['longitude'])) {
            return new WP_Error('missing_coordinates', __('Map coordinates are required', 'rental-gates'));
        }
        
        $coords = Rental_Gates_Security::sanitize_coordinates($data['latitude'], $data['longitude']);
        if (!$coords) {
            return new WP_Error('invalid_coordinates', __('Invalid coordinates', 'rental-gates'));
        }
        
        // Use provided derived_address or get from reverse geocoding
        $derived_address = isset($data['derived_address']) ? $data['derived_address'] : '';
        $address_data = array(
            'formatted_address' => $derived_address,
            'city' => '',
            'state' => '',
            'zip' => '',
            'country' => '',
        );
        
        // Only do reverse geocoding if no address provided
        if (empty($derived_address)) {
            $map_service = rental_gates()->get_map_service();
            $geocode_result = $map_service->reverse_geocode($coords['lat'], $coords['lng']);
            
            if (!is_wp_error($geocode_result)) {
                $address_data = $geocode_result;
            }
        }
        
        // Generate slug
        $slug = self::generate_unique_slug($data['name'], $data['organization_id']);
        
        // Handle gallery - if already JSON string, use it; otherwise encode
        // Use NULL for empty gallery to avoid constraint issues
        $gallery = null;
        if (isset($data['gallery']) && !empty($data['gallery']) && $data['gallery'] !== '[]') {
            $gallery = is_array($data['gallery']) ? wp_json_encode($data['gallery']) : $data['gallery'];
        }
        
        // Handle amenities similarly
        $amenities = null;
        if (isset($data['amenities']) && !empty($data['amenities']) && $data['amenities'] !== '[]') {
            $amenities = is_array($data['amenities']) ? wp_json_encode($data['amenities']) : $data['amenities'];
        }
        
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'name' => sanitize_text_field($data['name']),
            'slug' => $slug,
            'description' => isset($data['description']) ? wp_kses_post($data['description']) : '',
            'latitude' => $coords['lat'],
            'longitude' => $coords['lng'],
            'derived_address' => $address_data['formatted_address'] ?? $derived_address,
            'derived_city' => $address_data['city'] ?? '',
            'derived_state' => $address_data['state'] ?? '',
            'derived_zip' => $address_data['zip'] ?? '',
            'derived_country' => $address_data['country'] ?? '',
            'year_built' => isset($data['year_built']) ? intval($data['year_built']) : null,
            'total_floors' => isset($data['total_floors']) ? intval($data['total_floors']) : null,
            'amenities' => $amenities,
            'gallery' => $gallery,
            'featured_image' => isset($data['featured_image']) ? intval($data['featured_image']) : null,
            'status' => isset($data['status']) ? sanitize_text_field($data['status']) : 'active',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            error_log('Rental Gates: Failed to create building. DB Error: ' . $wpdb->last_error);
            return new WP_Error('db_error', __('Failed to create building', 'rental-gates') . ': ' . $wpdb->last_error);
        }
        
        $building_id = $wpdb->insert_id;
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::clear_building_cache($building_id, $data['organization_id']);
        }
        
        return self::get($building_id);
    }
    
    /**
     * Get building by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $building = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$building) {
            return null;
        }
        
        return self::format_building($building);
    }
    
    /**
     * Get building by slug
     */
    public static function get_by_slug($slug, $org_id = null) {
        global $wpdb;
        self::init();
        
        if ($org_id) {
            $building = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . self::$table_name . " WHERE slug = %s AND organization_id = %d",
                $slug, $org_id
            ), ARRAY_A);
        } else {
            $building = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . self::$table_name . " WHERE slug = %s",
                $slug
            ), ARRAY_A);
        }
        
        if (!$building) {
            return null;
        }
        
        return self::format_building($building);
    }
    
    /**
     * Get buildings for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'status' => 'active',
            'orderby' => 'name',
            'order' => 'ASC',
            'page' => 1,
            'per_page' => 20,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('organization_id = %d');
        $values = array($org_id);
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $values[] = $args['status'];
        }
        
        $where_clause = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'name ASC';
        
        $offset = ($args['page'] - 1) * $args['per_page'];
        
        $query = $wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE {$where_clause} ORDER BY {$orderby} LIMIT %d OFFSET %d",
            array_merge($values, array($args['per_page'], $offset))
        );
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        $buildings = array();
        foreach ($results as $row) {
            $buildings[] = self::format_building($row);
        }
        
        // Get total count
        $count_query = $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE {$where_clause}",
            $values
        );
        $total = $wpdb->get_var($count_query);
        
        return array(
            'items' => $buildings,
            'total' => intval($total),
            'pages' => ceil($total / $args['per_page']),
        );
    }
    
    /**
     * Get all buildings for organization (simple array)
     */
    public static function get_all($org_id) {
        global $wpdb;
        self::init();
        
        // Check if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            self::$table_name
        ));
        
        if (!$table_exists) {
            return array();
        }
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE organization_id = %d ORDER BY name ASC",
            $org_id
        ), ARRAY_A);
        
        if (!$results) {
            return array();
        }
        
        $buildings = array();
        foreach ($results as $row) {
            $buildings[] = self::format_building($row);
        }
        
        return $buildings;
    }
    
    /**
     * Update building
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $building = self::get($id);
        if (!$building) {
            return new WP_Error('not_found', __('Building not found', 'rental-gates'));
        }
        
        $update_data = array('updated_at' => current_time('mysql'));
        
        // Handle coordinate update
        if (isset($data['latitude']) && isset($data['longitude'])) {
            $coords = Rental_Gates_Security::sanitize_coordinates($data['latitude'], $data['longitude']);
            if ($coords) {
                $update_data['latitude'] = $coords['lat'];
                $update_data['longitude'] = $coords['lng'];
                
                // Use provided address or re-geocode
                if (isset($data['derived_address']) && !empty($data['derived_address'])) {
                    $update_data['derived_address'] = sanitize_text_field($data['derived_address']);
                } else {
                    $map_service = rental_gates()->get_map_service();
                    $address_data = $map_service->reverse_geocode($coords['lat'], $coords['lng']);
                    
                    if (!is_wp_error($address_data)) {
                        $update_data['derived_address'] = $address_data['formatted_address'];
                        $update_data['derived_city'] = $address_data['city'] ?? '';
                        $update_data['derived_state'] = $address_data['state'] ?? '';
                        $update_data['derived_zip'] = $address_data['zip'] ?? '';
                        $update_data['derived_country'] = $address_data['country'] ?? '';
                    }
                }
            }
        }
        
        // Other fields
        $allowed_fields = array('name', 'description', 'year_built', 'total_floors', 'featured_image', 'status');
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                if (in_array($field, array('year_built', 'total_floors', 'featured_image'))) {
                    $update_data[$field] = $data[$field] !== '' ? intval($data[$field]) : null;
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        // Handle gallery - use NULL for empty
        if (isset($data['gallery'])) {
            if (empty($data['gallery']) || $data['gallery'] === '[]') {
                $update_data['gallery'] = null;
            } else {
                $update_data['gallery'] = is_array($data['gallery']) ? wp_json_encode($data['gallery']) : $data['gallery'];
            }
        }
        
        // Handle amenities - use NULL for empty
        if (isset($data['amenities'])) {
            if (empty($data['amenities']) || $data['amenities'] === '[]') {
                $update_data['amenities'] = null;
            } else {
                $update_data['amenities'] = is_array($data['amenities']) ? wp_json_encode($data['amenities']) : $data['amenities'];
            }
        }
        
        // Update slug if name changed
        if (isset($data['name']) && $data['name'] !== $building['name']) {
            $update_data['slug'] = self::generate_unique_slug($data['name'], $building['organization_id'], $id);
        }
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            error_log('Rental Gates: Failed to update building. DB Error: ' . $wpdb->last_error);
            return new WP_Error('db_error', __('Failed to update building', 'rental-gates') . ': ' . $wpdb->last_error);
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::clear_building_cache($id, $building['organization_id']);
        }
        
        return self::get($id);
    }
    
    /**
     * Delete building
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $building = self::get($id);
        if (!$building) {
            return new WP_Error('not_found', __('Building not found', 'rental-gates'));
        }
        
        // Check for units
        $unit_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['units']} WHERE building_id = %d",
            $id
        ));
        
        if ($unit_count > 0) {
            return new WP_Error('has_units', __('Cannot delete building with units', 'rental-gates'));
        }
        
        $result = $wpdb->delete(self::$table_name, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to delete building', 'rental-gates'));
        }
        
        Rental_Gates_Cache::clear_building_cache($id, $building['organization_id']);
        
        return true;
    }
    
    /**
     * Get buildings for public map
     */
    public static function get_for_map($bounds = null) {
        global $wpdb;
        self::init();
        
        $where = array('b.status = %s');
        $values = array('active');
        
        if ($bounds) {
            $where[] = 'b.latitude BETWEEN %f AND %f';
            $where[] = 'b.longitude BETWEEN %f AND %f';
            $values[] = $bounds['south'];
            $values[] = $bounds['north'];
            $values[] = $bounds['west'];
            $values[] = $bounds['east'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        $query = $wpdb->prepare(
            "SELECT b.id, b.name, b.slug, b.latitude, b.longitude, b.derived_city, b.derived_state,
                    b.featured_image, o.slug as org_slug,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}rg_units u WHERE u.building_id = b.id AND u.availability = 'available') as available_units
             FROM " . self::$table_name . " b
             JOIN {$wpdb->prefix}rg_organizations o ON b.organization_id = o.id
             WHERE {$where_clause}",
            $values
        );
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    /**
     * Format building data
     */
    private static function format_building($building) {
        // Parse JSON fields safely
        $building['amenities'] = !empty($building['amenities']) ? (json_decode($building['amenities'], true) ?: array()) : array();
        $building['gallery'] = !empty($building['gallery']) ? (json_decode($building['gallery'], true) ?: array()) : array();
        $building['meta_data'] = !empty($building['meta_data']) ? (json_decode($building['meta_data'], true) ?: array()) : array();
        
        // Cast types safely
        $building['id'] = intval($building['id'] ?? 0);
        $building['organization_id'] = intval($building['organization_id'] ?? 0);
        $building['latitude'] = floatval($building['latitude'] ?? 0);
        $building['longitude'] = floatval($building['longitude'] ?? 0);
        $building['year_built'] = !empty($building['year_built']) ? intval($building['year_built']) : null;
        $building['total_floors'] = !empty($building['total_floors']) ? intval($building['total_floors']) : null;
        $building['featured_image'] = !empty($building['featured_image']) ? intval($building['featured_image']) : null;
        
        // Add URLs
        if (!empty($building['featured_image'])) {
            $building['featured_image_url'] = wp_get_attachment_url($building['featured_image']);
        } else {
            $building['featured_image_url'] = null;
        }
        
        $building['public_url'] = home_url('/rental-gates/building/' . ($building['slug'] ?? ''));
        
        return $building;
    }
    
    /**
     * Generate unique slug
     */
    private static function generate_unique_slug($name, $org_id, $exclude_id = null) {
        global $wpdb;
        self::init();
        
        $slug = sanitize_title($name);
        $original_slug = $slug;
        $counter = 1;
        
        while (true) {
            $query = "SELECT id FROM " . self::$table_name . " WHERE organization_id = %d AND slug = %s";
            $values = array($org_id, $slug);
            
            if ($exclude_id) {
                $query .= " AND id != %d";
                $values[] = $exclude_id;
            }
            
            $existing = $wpdb->get_var($wpdb->prepare($query, $values));
            
            if (!$existing) {
                break;
            }
            
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
}
