<?php
/**
 * Rental Gates Maintenance Model
 * 
 * Handles work order management including CRUD operations,
 * status tracking, notes, and vendor assignments.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Maintenance {
    
    private static $table_name;
    private static $notes_table;
    private static $vendors_table;
    
    /**
     * Initialize table names
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['work_orders'];
            self::$notes_table = $tables['work_order_notes'];
            self::$vendors_table = $tables['work_order_vendors'];
        }
    }
    
    /**
     * Create a new work order
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $required = array('organization_id', 'building_id', 'title', 'description');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return new WP_Error('missing_field', sprintf(__('Missing required field: %s', 'rental-gates'), $field));
            }
        }
        
        // Prepare insert data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'building_id' => intval($data['building_id']),
            'unit_id' => !empty($data['unit_id']) ? intval($data['unit_id']) : null,
            'tenant_id' => !empty($data['tenant_id']) ? intval($data['tenant_id']) : null,
            'scheduled_maintenance_id' => !empty($data['scheduled_maintenance_id']) ? intval($data['scheduled_maintenance_id']) : null,
            'title' => sanitize_text_field($data['title']),
            'description' => sanitize_textarea_field($data['description']),
            'category' => in_array($data['category'] ?? '', array('plumbing', 'electrical', 'hvac', 'appliance', 'structural', 'pest', 'cleaning', 'general', 'other'))
                ? $data['category'] : 'other',
            'priority' => in_array($data['priority'] ?? '', array('low', 'medium', 'high', 'emergency'))
                ? $data['priority'] : 'medium',
            'status' => 'open',
            'permission_to_enter' => !empty($data['permission_to_enter']) ? 1 : 0,
            'access_instructions' => sanitize_textarea_field($data['access_instructions'] ?? ''),
            'cost_estimate' => !empty($data['cost_estimate']) ? floatval($data['cost_estimate']) : null,
            'scheduled_date' => !empty($data['scheduled_date']) ? sanitize_text_field($data['scheduled_date']) : null,
            'internal_notes' => sanitize_textarea_field($data['internal_notes'] ?? ''),
            'created_at' => current_time('mysql'),
        );
        
        // Handle photos (JSON array of URLs)
        if (!empty($data['photos']) && is_array($data['photos'])) {
            $insert_data['photos'] = wp_json_encode(array_map('esc_url_raw', $data['photos']));
        }
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating work order', 'rental-gates'));
        }
        
        $work_order_id = $wpdb->insert_id;
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('maintenance_org_' . $data['organization_id']);
        }
        
        return self::get($work_order_id);
    }
    
    /**
     * Get work order by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $work_order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$work_order) {
            return null;
        }
        
        return self::format_work_order($work_order);
    }
    
    /**
     * Get work order with full details
     */
    public static function get_with_details($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $work_order = $wpdb->get_row($wpdb->prepare(
            "SELECT wo.*, 
                    b.name as building_name, b.derived_address as building_address,
                    u.name as unit_name,
                    t.first_name as tenant_first_name, t.last_name as tenant_last_name, 
                    t.email as tenant_email, t.phone as tenant_phone
             FROM " . self::$table_name . " wo
             LEFT JOIN {$tables['buildings']} b ON wo.building_id = b.id
             LEFT JOIN {$tables['units']} u ON wo.unit_id = u.id
             LEFT JOIN {$tables['tenants']} t ON wo.tenant_id = t.id
             WHERE wo.id = %d",
            $id
        ), ARRAY_A);
        
        if (!$work_order) {
            return null;
        }
        
        $formatted = self::format_work_order($work_order);
        
        // Add tenant full name
        if (!empty($work_order['tenant_first_name'])) {
            $formatted['tenant_name'] = $work_order['tenant_first_name'] . ' ' . $work_order['tenant_last_name'];
            $formatted['tenant_email'] = $work_order['tenant_email'];
            $formatted['tenant_phone'] = $work_order['tenant_phone'];
        }
        
        // Get notes
        $formatted['notes'] = self::get_notes($id);
        
        // Get assigned vendors
        $formatted['vendors'] = self::get_assigned_vendors($id);
        
        return $formatted;
    }
    
    /**
     * Get work orders for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => null,
            'priority' => null,
            'category' => null,
            'building_id' => null,
            'unit_id' => null,
            'tenant_id' => null,
            'search' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('wo.organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "wo.status IN ($placeholders)";
                $params = array_merge($params, $args['status']);
            } else {
                $where[] = 'wo.status = %s';
                $params[] = $args['status'];
            }
        }
        
        if ($args['priority']) {
            $where[] = 'wo.priority = %s';
            $params[] = $args['priority'];
        }
        
        if ($args['category']) {
            $where[] = 'wo.category = %s';
            $params[] = $args['category'];
        }
        
        if ($args['building_id']) {
            $where[] = 'wo.building_id = %d';
            $params[] = $args['building_id'];
        }
        
        if ($args['unit_id']) {
            $where[] = 'wo.unit_id = %d';
            $params[] = $args['unit_id'];
        }
        
        if ($args['tenant_id']) {
            $where[] = 'wo.tenant_id = %d';
            $params[] = $args['tenant_id'];
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(wo.title LIKE %s OR wo.description LIKE %s OR u.name LIKE %s OR b.name LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'priority', 'status', 'scheduled_date', 'title'))
            ? 'wo.' . $args['orderby'] : 'wo.created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        // Priority ordering - emergency first
        $priority_order = '';
        if ($args['orderby'] === 'priority') {
            $priority_order = "FIELD(wo.priority, 'emergency', 'high', 'medium', 'low'), ";
        }
        
        $sql = "SELECT wo.*, 
                       b.name as building_name,
                       u.name as unit_name,
                       t.first_name as tenant_first_name, t.last_name as tenant_last_name
                FROM " . self::$table_name . " wo
                LEFT JOIN {$tables['buildings']} b ON wo.building_id = b.id
                LEFT JOIN {$tables['units']} u ON wo.unit_id = u.id
                LEFT JOIN {$tables['tenants']} t ON wo.tenant_id = t.id
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$priority_order}{$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $work_orders = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(function($wo) {
            $formatted = self::format_work_order($wo);
            if (!empty($wo['tenant_first_name'])) {
                $formatted['tenant_name'] = $wo['tenant_first_name'] . ' ' . $wo['tenant_last_name'];
            }
            return $formatted;
        }, $work_orders);
    }
    
    /**
     * Count work orders for organization
     */
    public static function count_for_organization($org_id, $status = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($status) {
            if (is_array($status)) {
                $placeholders = implode(',', array_fill(0, count($status), '%s'));
                $sql .= " AND status IN ($placeholders)";
                $params = array_merge($params, $status);
            } else {
                $sql .= " AND status = %s";
                $params[] = $status;
            }
        }
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Update work order
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $work_order = self::get($id);
        if (!$work_order) {
            return new WP_Error('not_found', __('Work order not found', 'rental-gates'));
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'title', 'description', 'category', 'priority', 'status', 'cause',
            'permission_to_enter', 'access_instructions', 'cost_estimate', 'final_cost',
            'scheduled_date', 'internal_notes', 'building_id', 'unit_id', 'tenant_id'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'cost_estimate':
                    case 'final_cost':
                        $update_data[$field] = floatval($data[$field]);
                        break;
                    case 'permission_to_enter':
                        $update_data[$field] = !empty($data[$field]) ? 1 : 0;
                        break;
                    case 'building_id':
                    case 'unit_id':
                    case 'tenant_id':
                        $update_data[$field] = intval($data[$field]) ?: null;
                        break;
                    case 'category':
                        $valid = array('plumbing', 'electrical', 'hvac', 'appliance', 'structural', 'pest', 'cleaning', 'general', 'other');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    case 'priority':
                        $valid = array('low', 'medium', 'high', 'emergency');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    case 'status':
                        $valid = array('open', 'assigned', 'in_progress', 'on_hold', 'completed', 'cancelled', 'declined');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                            // Set completed_at if completing
                            if ($data[$field] === 'completed' && empty($work_order['completed_at'])) {
                                $update_data['completed_at'] = current_time('mysql');
                            }
                        }
                        break;
                    case 'cause':
                        $valid = array('normal_wear', 'tenant_responsibility', 'external', 'unknown');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    case 'description':
                    case 'access_instructions':
                    case 'internal_notes':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $work_order;
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating work order', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('maintenance_org_' . $work_order['organization_id']);
        }
        
        return self::get($id);
    }
    
    /**
     * Delete work order
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        $work_order = self::get($id);
        if (!$work_order) {
            return new WP_Error('not_found', __('Work order not found', 'rental-gates'));
        }
        
        // Delete notes
        $wpdb->delete(self::$notes_table, array('work_order_id' => $id));
        
        // Delete vendor assignments
        $wpdb->delete(self::$vendors_table, array('work_order_id' => $id));
        
        // Delete work order
        $wpdb->delete(self::$table_name, array('id' => $id));
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('maintenance_org_' . $work_order['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Update status
     */
    public static function update_status($id, $status) {
        return self::update($id, array('status' => $status));
    }
    
    /**
     * Mark as completed
     */
    public static function complete($id, $final_cost = null, $cause = null) {
        $data = array('status' => 'completed');
        
        if ($final_cost !== null) {
            $data['final_cost'] = $final_cost;
        }
        
        if ($cause !== null) {
            $data['cause'] = $cause;
        }
        
        return self::update($id, $data);
    }
    
    /**
     * Add note to work order
     */
    public static function add_note($work_order_id, $user_id, $user_type, $note, $is_internal = false, $attachments = array()) {
        global $wpdb;
        self::init();
        
        $insert_data = array(
            'work_order_id' => intval($work_order_id),
            'user_id' => intval($user_id),
            'user_type' => in_array($user_type, array('staff', 'tenant', 'vendor')) ? $user_type : 'staff',
            'note' => sanitize_textarea_field($note),
            'is_internal' => $is_internal ? 1 : 0,
            'created_at' => current_time('mysql'),
        );
        
        if (!empty($attachments)) {
            $insert_data['attachments'] = wp_json_encode(array_map('esc_url_raw', $attachments));
        }
        
        $result = $wpdb->insert(self::$notes_table, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error adding note', 'rental-gates'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get notes for work order
     */
    public static function get_notes($work_order_id, $include_internal = true) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT n.*, u.display_name as user_name 
                FROM " . self::$notes_table . " n
                LEFT JOIN {$wpdb->users} u ON n.user_id = u.ID
                WHERE n.work_order_id = %d";
        
        if (!$include_internal) {
            $sql .= " AND n.is_internal = 0";
        }
        
        $sql .= " ORDER BY n.created_at ASC";
        
        $notes = $wpdb->get_results($wpdb->prepare($sql, $work_order_id), ARRAY_A);
        
        return array_map(function($note) {
            $note['id'] = intval($note['id']);
            $note['work_order_id'] = intval($note['work_order_id']);
            $note['user_id'] = intval($note['user_id']);
            $note['is_internal'] = (bool) $note['is_internal'];
            if (!empty($note['attachments'])) {
                $note['attachments'] = json_decode($note['attachments'], true);
            } else {
                $note['attachments'] = array();
            }
            return $note;
        }, $notes);
    }
    
    /**
     * Get assigned vendors for work order
     */
    public static function get_assigned_vendors($work_order_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $vendors = $wpdb->get_results($wpdb->prepare(
            "SELECT wov.*, v.company_name, v.contact_name, v.email, v.phone
             FROM " . self::$vendors_table . " wov
             LEFT JOIN {$tables['vendors']} v ON wov.vendor_id = v.id
             WHERE wov.work_order_id = %d
             ORDER BY wov.assigned_at DESC",
            $work_order_id
        ), ARRAY_A);
        
        return $vendors ?: array();
    }
    
    /**
     * Get statistics for organization
     */
    public static function get_stats($org_id) {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total' => 0,
            'open' => 0,
            'assigned' => 0,
            'in_progress' => 0,
            'on_hold' => 0,
            'completed' => 0,
            'emergency' => 0,
            'high' => 0,
            'overdue' => 0,
        );
        
        // Count by status
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             GROUP BY status",
            $org_id
        ), ARRAY_A);
        
        foreach ($results as $row) {
            $stats[$row['status']] = intval($row['count']);
            $stats['total'] += intval($row['count']);
        }
        
        // Count by priority (active only)
        $active_statuses = array('open', 'assigned', 'in_progress', 'on_hold');
        $placeholders = implode(',', array_fill(0, count($active_statuses), '%s'));
        
        $emergency = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND priority = 'emergency' AND status IN ($placeholders)",
            array_merge(array($org_id), $active_statuses)
        ));
        $stats['emergency'] = intval($emergency);
        
        $high = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND priority = 'high' AND status IN ($placeholders)",
            array_merge(array($org_id), $active_statuses)
        ));
        $stats['high'] = intval($high);
        
        // Overdue (scheduled but past date, not completed)
        $overdue = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             AND scheduled_date IS NOT NULL 
             AND scheduled_date < NOW() 
             AND status NOT IN ('completed', 'cancelled', 'declined')",
            $org_id
        ));
        $stats['overdue'] = intval($overdue);
        
        return $stats;
    }
    
    /**
     * Get category label
     */
    public static function get_category_label($category) {
        $labels = array(
            'plumbing' => __('Plumbing', 'rental-gates'),
            'electrical' => __('Electrical', 'rental-gates'),
            'hvac' => __('HVAC', 'rental-gates'),
            'appliance' => __('Appliance', 'rental-gates'),
            'structural' => __('Structural', 'rental-gates'),
            'pest' => __('Pest Control', 'rental-gates'),
            'cleaning' => __('Cleaning', 'rental-gates'),
            'general' => __('General', 'rental-gates'),
            'other' => __('Other', 'rental-gates'),
        );
        
        return $labels[$category] ?? $category;
    }
    
    /**
     * Get priority label
     */
    public static function get_priority_label($priority) {
        $labels = array(
            'low' => __('Low', 'rental-gates'),
            'medium' => __('Medium', 'rental-gates'),
            'high' => __('High', 'rental-gates'),
            'emergency' => __('Emergency', 'rental-gates'),
        );
        
        return $labels[$priority] ?? $priority;
    }
    
    /**
     * Get status label
     */
    public static function get_status_label($status) {
        $labels = array(
            'open' => __('Open', 'rental-gates'),
            'assigned' => __('Assigned', 'rental-gates'),
            'in_progress' => __('In Progress', 'rental-gates'),
            'on_hold' => __('On Hold', 'rental-gates'),
            'completed' => __('Completed', 'rental-gates'),
            'cancelled' => __('Cancelled', 'rental-gates'),
            'declined' => __('Declined', 'rental-gates'),
        );
        
        return $labels[$status] ?? $status;
    }
    
    /**
     * Format work order data
     */
    private static function format_work_order($work_order) {
        if (!$work_order) return null;
        
        $work_order['id'] = intval($work_order['id']);
        $work_order['organization_id'] = intval($work_order['organization_id']);
        $work_order['building_id'] = intval($work_order['building_id']);
        $work_order['unit_id'] = $work_order['unit_id'] ? intval($work_order['unit_id']) : null;
        $work_order['tenant_id'] = $work_order['tenant_id'] ? intval($work_order['tenant_id']) : null;
        $work_order['permission_to_enter'] = (bool) $work_order['permission_to_enter'];
        $work_order['cost_estimate'] = $work_order['cost_estimate'] ? floatval($work_order['cost_estimate']) : null;
        $work_order['final_cost'] = $work_order['final_cost'] ? floatval($work_order['final_cost']) : null;
        
        // Parse photos
        if (!empty($work_order['photos'])) {
            $work_order['photos'] = json_decode($work_order['photos'], true);
        } else {
            $work_order['photos'] = array();
        }
        
        // Parse meta data
        if (!empty($work_order['meta_data'])) {
            $work_order['meta_data'] = json_decode($work_order['meta_data'], true);
        } else {
            $work_order['meta_data'] = array();
        }
        
        // Add labels
        $work_order['category_label'] = self::get_category_label($work_order['category']);
        $work_order['priority_label'] = self::get_priority_label($work_order['priority']);
        $work_order['status_label'] = self::get_status_label($work_order['status']);
        
        // Calculate days open
        if (!empty($work_order['created_at'])) {
            $created = new DateTime($work_order['created_at']);
            $now = new DateTime();
            $work_order['days_open'] = $now->diff($created)->days;
        } else {
            $work_order['days_open'] = 0;
        }
        
        // Check if overdue
        if (!empty($work_order['scheduled_date']) && !in_array($work_order['status'], array('completed', 'cancelled', 'declined'))) {
            $work_order['is_overdue'] = strtotime($work_order['scheduled_date']) < time();
        } else {
            $work_order['is_overdue'] = false;
        }
        
        return $work_order;
    }
}
