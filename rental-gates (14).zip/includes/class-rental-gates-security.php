<?php
/**
 * Rental Gates Security Class
 * Handles CSRF protection, input validation, and security utilities
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Security {
    
    /**
     * Verify REST API nonce
     */
    public static function verify_rest_nonce($request) {
        $nonce = $request->get_header('X-WP-Nonce');
        
        if (!$nonce) {
            return new WP_Error(
                'missing_nonce',
                __('Security token is missing.', 'rental-gates'),
                array('status' => 401)
            );
        }
        
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error(
                'invalid_nonce',
                __('Invalid security token.', 'rental-gates'),
                array('status' => 401)
            );
        }
        
        return true;
    }
    
    /**
     * Verify AJAX nonce
     */
    public static function verify_ajax_nonce($nonce_value, $action = 'rental_gates_nonce') {
        if (!wp_verify_nonce($nonce_value, $action)) {
            wp_send_json_error(array(
                'message' => __('Security verification failed.', 'rental-gates'),
            ), 403);
        }
        
        return true;
    }
    
    /**
     * Generate a secure random token
     */
    public static function generate_token($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    /**
     * Generate application token
     */
    public static function generate_application_token() {
        return 'app_' . self::generate_token(24);
    }
    
    /**
     * Generate QR code identifier
     */
    public static function generate_qr_code() {
        return 'qr_' . self::generate_token(16);
    }
    
    /**
     * Hash a password or token
     */
    public static function hash_token($token) {
        return hash('sha256', $token . wp_salt());
    }
    
    /**
     * Verify a hashed token
     */
    public static function verify_token($token, $hash) {
        return hash_equals($hash, self::hash_token($token));
    }
    
    /**
     * Sanitize and validate email
     */
    public static function sanitize_email($email) {
        $email = sanitize_email($email);
        
        if (!is_email($email)) {
            return false;
        }
        
        return $email;
    }
    
    /**
     * Sanitize phone number
     */
    public static function sanitize_phone($phone) {
        // Remove all non-numeric characters except + - ( ) and spaces
        $phone = preg_replace('/[^\d+\-\(\)\s]/', '', $phone);
        
        // Remove extra spaces
        $phone = preg_replace('/\s+/', ' ', trim($phone));
        
        return $phone;
    }
    
    /**
     * Sanitize currency amount
     */
    public static function sanitize_amount($amount) {
        // Remove currency symbols and commas
        $amount = preg_replace('/[^\d.-]/', '', $amount);
        
        // Convert to float
        $amount = floatval($amount);
        
        // Round to 2 decimal places
        return round($amount, 2);
    }
    
    /**
     * Sanitize and validate date
     */
    public static function sanitize_date($date, $format = 'Y-m-d') {
        $date_obj = DateTime::createFromFormat($format, $date);
        
        if (!$date_obj || $date_obj->format($format) !== $date) {
            return false;
        }
        
        return $date;
    }
    
    /**
     * Sanitize coordinates
     */
    public static function sanitize_coordinates($lat, $lng) {
        $lat = floatval($lat);
        $lng = floatval($lng);
        
        // Validate latitude (-90 to 90)
        if ($lat < -90 || $lat > 90) {
            return false;
        }
        
        // Validate longitude (-180 to 180)
        if ($lng < -180 || $lng > 180) {
            return false;
        }
        
        return array(
            'lat' => round($lat, 8),
            'lng' => round($lng, 8),
        );
    }
    
    /**
     * Sanitize HTML content (allow safe tags)
     */
    public static function sanitize_html($content) {
        $allowed_tags = array(
            'p' => array(),
            'br' => array(),
            'strong' => array(),
            'em' => array(),
            'b' => array(),
            'i' => array(),
            'u' => array(),
            'ul' => array(),
            'ol' => array(),
            'li' => array(),
            'a' => array(
                'href' => array(),
                'title' => array(),
                'target' => array(),
            ),
            'span' => array(
                'class' => array(),
            ),
            'div' => array(
                'class' => array(),
            ),
        );
        
        return wp_kses($content, $allowed_tags);
    }
    
    /**
     * Validate file upload
     */
    public static function validate_file_upload($file, $allowed_types = null, $max_size = null) {
        // Default allowed types
        if ($allowed_types === null) {
            $allowed_types = array(
                'image/jpeg',
                'image/png',
                'image/gif',
                'image/webp',
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            );
        }
        
        // Default max size: 10MB
        if ($max_size === null) {
            $max_size = 10 * 1024 * 1024;
        }
        
        $errors = array();
        
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $upload_errors = array(
                UPLOAD_ERR_INI_SIZE => __('File exceeds server limit.', 'rental-gates'),
                UPLOAD_ERR_FORM_SIZE => __('File exceeds form limit.', 'rental-gates'),
                UPLOAD_ERR_PARTIAL => __('File was only partially uploaded.', 'rental-gates'),
                UPLOAD_ERR_NO_FILE => __('No file was uploaded.', 'rental-gates'),
                UPLOAD_ERR_NO_TMP_DIR => __('Missing temporary folder.', 'rental-gates'),
                UPLOAD_ERR_CANT_WRITE => __('Failed to write file to disk.', 'rental-gates'),
                UPLOAD_ERR_EXTENSION => __('File upload stopped by extension.', 'rental-gates'),
            );
            
            $errors[] = isset($upload_errors[$file['error']]) 
                ? $upload_errors[$file['error']] 
                : __('Unknown upload error.', 'rental-gates');
            
            return $errors;
        }
        
        // Check file size
        if ($file['size'] > $max_size) {
            $errors[] = sprintf(
                __('File size exceeds maximum allowed (%s).', 'rental-gates'),
                size_format($max_size)
            );
        }
        
        // Check MIME type
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $finfo->file($file['tmp_name']);
        
        if (!in_array($mime_type, $allowed_types)) {
            $errors[] = __('File type is not allowed.', 'rental-gates');
        }
        
        // Additional security check for images
        if (strpos($mime_type, 'image/') === 0) {
            $image_info = getimagesize($file['tmp_name']);
            if ($image_info === false) {
                $errors[] = __('Invalid image file.', 'rental-gates');
            }
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Check if current request is from same site
     */
    public static function is_same_origin() {
        $referer = wp_get_referer();
        
        if (!$referer) {
            return false;
        }
        
        $home = parse_url(home_url());
        $ref = parse_url($referer);
        
        return $home['host'] === $ref['host'];
    }
    
    /**
     * Get client IP address
     */
    public static function get_client_ip() {
        $ip_keys = array(
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        );
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ips = explode(',', $ip);
                    $ip = trim($ips[0]);
                }
                
                // Validate IP
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
    
    /**
     * Log security event
     */
    public static function log_security_event($event_type, $details = array()) {
        global $wpdb;
        
        // Check if Database class exists and table is available
        if (!class_exists('Rental_Gates_Database')) {
            return;
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check if table exists before inserting
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $tables['activity_log']
        ));
        
        if (!$table_exists) {
            return; // Table doesn't exist yet, skip logging
        }
        
        // Get organization_id safely
        $org_id = null;
        if (class_exists('Rental_Gates_Roles')) {
            try {
                $org_id = Rental_Gates_Roles::get_organization_id();
            } catch (Exception $e) {
                $org_id = null;
            }
        }
        
        $wpdb->insert(
            $tables['activity_log'],
            array(
                'user_id' => get_current_user_id(),
                'organization_id' => $org_id,
                'action' => 'security_' . $event_type,
                'new_values' => wp_json_encode($details),
                'ip_address' => self::get_client_ip(),
                'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) 
                    ? sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT'], 0, 500)) 
                    : '',
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Check if user is in support mode (viewing as another user)
     */
    public static function is_support_mode() {
        return !empty($_SESSION['rental_gates_support_mode']);
    }
    
    /**
     * Get support mode details
     */
    public static function get_support_mode_details() {
        if (!self::is_support_mode()) {
            return null;
        }
        
        return array(
            'admin_user_id' => $_SESSION['rental_gates_support_admin_id'] ?? 0,
            'viewing_as_user_id' => $_SESSION['rental_gates_support_viewing_as'] ?? 0,
            'organization_id' => $_SESSION['rental_gates_support_org_id'] ?? 0,
            'reason' => $_SESSION['rental_gates_support_reason'] ?? '',
            'started_at' => $_SESSION['rental_gates_support_started'] ?? '',
        );
    }
    
    /**
     * Enter support mode (admin viewing as user)
     */
    public static function enter_support_mode($admin_user_id, $target_user_id, $organization_id, $reason) {
        if (!Rental_Gates_Roles::is_site_admin($admin_user_id)) {
            return new WP_Error('unauthorized', __('Only site admins can use support mode.', 'rental-gates'));
        }
        
        if (empty($reason)) {
            return new WP_Error('missing_reason', __('Support mode requires a reason.', 'rental-gates'));
        }
        
        // Start session if not started
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        $_SESSION['rental_gates_support_mode'] = true;
        $_SESSION['rental_gates_support_admin_id'] = $admin_user_id;
        $_SESSION['rental_gates_support_viewing_as'] = $target_user_id;
        $_SESSION['rental_gates_support_org_id'] = $organization_id;
        $_SESSION['rental_gates_support_reason'] = $reason;
        $_SESSION['rental_gates_support_started'] = current_time('mysql');
        
        // Log support mode entry
        self::log_security_event('support_mode_enter', array(
            'admin_user_id' => $admin_user_id,
            'target_user_id' => $target_user_id,
            'organization_id' => $organization_id,
            'reason' => $reason,
        ));
        
        return true;
    }
    
    /**
     * Exit support mode
     */
    public static function exit_support_mode() {
        if (!self::is_support_mode()) {
            return;
        }
        
        // Log support mode exit
        self::log_security_event('support_mode_exit', self::get_support_mode_details());
        
        // Clear session variables
        unset($_SESSION['rental_gates_support_mode']);
        unset($_SESSION['rental_gates_support_admin_id']);
        unset($_SESSION['rental_gates_support_viewing_as']);
        unset($_SESSION['rental_gates_support_org_id']);
        unset($_SESSION['rental_gates_support_reason']);
        unset($_SESSION['rental_gates_support_started']);
    }
    
    /**
     * Encrypt sensitive data
     */
    public static function encrypt($data) {
        $key = wp_salt('auth');
        $iv = random_bytes(16);
        
        $encrypted = openssl_encrypt(
            $data,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
        
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * Decrypt sensitive data
     */
    public static function decrypt($data) {
        $key = wp_salt('auth');
        $data = base64_decode($data);
        
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        
        return openssl_decrypt(
            $encrypted,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
    }
    
    /**
     * Mask sensitive data for display
     */
    public static function mask_email($email) {
        $parts = explode('@', $email);
        if (count($parts) !== 2) {
            return '***';
        }
        
        $name = $parts[0];
        $domain = $parts[1];
        
        $masked_name = substr($name, 0, 2) . str_repeat('*', max(strlen($name) - 2, 3));
        
        return $masked_name . '@' . $domain;
    }
    
    /**
     * Mask phone number
     */
    public static function mask_phone($phone) {
        $digits = preg_replace('/\D/', '', $phone);
        $length = strlen($digits);
        
        if ($length < 4) {
            return str_repeat('*', $length);
        }
        
        return str_repeat('*', $length - 4) . substr($digits, -4);
    }
    
    /**
     * Mask card number
     */
    public static function mask_card($card_number) {
        return '**** **** **** ' . substr($card_number, -4);
    }
}
