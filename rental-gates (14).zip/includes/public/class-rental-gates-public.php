<?php
/**
 * Rental Gates Public Class
 */
if (!defined('ABSPATH'))
    exit;

class Rental_Gates_Public
{

    /**
     * Initialize the class and set its properties.
     */
    public function __construct()
    {
    }

    /**
     * Register rewrite rules for pretty invoice URLs
     */
    public function add_rewrite_rules()
    {
        add_rewrite_rule(
            '^rental-gates/invoice/([0-9]+)/?$',
            'index.php?rg_invoice_id=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^rental-gates/magic-login/?$',
            'index.php?rg_magic_login=1',
            'top'
        );
    }

    /**
     * Register query var
     */
    public function add_query_vars($vars)
    {
        $vars[] = 'rg_invoice_id';
        $vars[] = 'rg_magic_login';
        return $vars;
    }

    /**
     * Template include for invoice rendering
     */
    public function template_redirect()
    {
        $invoice_id = get_query_var('rg_invoice_id');

        if ($invoice_id) {
            // Check if user is logged in
            if (!is_user_logged_in()) {
                auth_redirect();
            }

            // Check permissions (ensure user owns the invoice)
            $org_id = rg_feature_gate()->get_user_org_id();

            if (!$org_id && !current_user_can('manage_options')) {
                wp_die(__('Unauthorized access', 'rental-gates'), 403);
            }

            // Allow admins to view any invoice, otherwise restrict to org
            $invoice = Rental_Gates_Subscription_Invoice::get($invoice_id);

            if (!$invoice) {
                global $wp_query;
                $wp_query->set_404();
                status_header(404);
                get_template_part(404);
                exit;
            }

            if ($invoice['organization_id'] != $org_id && !current_user_can('manage_options')) {
                wp_die(__('You do not have permission to view this invoice.', 'rental-gates'), 403);
            }

            // Render invoice
            echo Rental_Gates_Subscription_Invoice::generate_html($invoice);
            exit;
        }

        // Magic Login Handler
        if (get_query_var('rg_magic_login')) {
            $token = $_GET['token'] ?? '';
            if ($token) {
                // Verify
                $user_id = Rental_Gates_Auth::verify_magic_token($token);

                if (is_wp_error($user_id)) {
                    wp_die($user_id->get_error_message(), __('Login Failed', 'rental-gates'), 403);
                }

                // Redirect to dashboard
                wp_safe_redirect(Rental_Gates_Roles::get_dashboard_url($user_id));
                exit;
            }
        }
    }
}
