<?php
/**
 * Rental Gates PWA (Progressive Web App) Manager
 * 
 * Handles manifest generation, service worker registration,
 * push notifications, and app icon generation.
 * 
 * @package RentalGates
 * @since 2.24.0
 */

if (!defined('ABSPATH')) exit;

class Rental_Gates_PWA {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * PWA Settings
     */
    private $settings = array();
    
    /**
     * Get instance
     */
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->settings = $this->get_settings();
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Add manifest link to head
        add_action('wp_head', array($this, 'add_manifest_link'), 1);
        
        // Add PWA meta tags
        add_action('wp_head', array($this, 'add_pwa_meta_tags'), 2);
        
        // Add Apple touch icons
        add_action('wp_head', array($this, 'add_apple_touch_icons'), 3);
        
        // Enqueue PWA scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_pwa_scripts'));
        
        // Generate manifest dynamically
        add_action('init', array($this, 'register_manifest_endpoint'));
        
        // Generate app icons
        add_action('init', array($this, 'ensure_icons_exist'));
        
        // REST API routes for push notifications
        add_action('rest_api_init', array($this, 'register_push_routes'));
    }
    
    /**
     * Get PWA settings
     */
    private function get_settings() {
        $defaults = array(
            'enabled' => true,
            'name' => get_bloginfo('name') . ' - Rental Gates',
            'short_name' => 'Rental Gates',
            'description' => 'Professional property management platform',
            'theme_color' => '#2563eb',
            'background_color' => '#ffffff',
            'display' => 'standalone',
            'orientation' => 'portrait-primary',
            'push_enabled' => false,
            'vapid_public_key' => '',
            'vapid_private_key' => '',
        );
        
        $saved = get_option('rental_gates_pwa_settings', array());
        
        return wp_parse_args($saved, $defaults);
    }
    
    /**
     * Check if PWA is enabled
     */
    public function is_enabled() {
        return !empty($this->settings['enabled']);
    }
    
    /**
     * Add manifest link to head
     */
    public function add_manifest_link() {
        if (!$this->is_enabled()) return;
        
        echo '<link rel="manifest" href="' . esc_url(home_url('/rental-gates-manifest.json')) . '">' . "\n";
    }
    
    /**
     * Add PWA meta tags
     */
    public function add_pwa_meta_tags() {
        if (!$this->is_enabled()) return;
        
        $theme_color = esc_attr($this->settings['theme_color']);
        $name = esc_attr($this->settings['name']);
        
        echo '<meta name="theme-color" content="' . $theme_color . '">' . "\n";
        echo '<meta name="application-name" content="' . $name . '">' . "\n";
        echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="default">' . "\n";
        echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr($this->settings['short_name']) . '">' . "\n";
        echo '<meta name="msapplication-TileColor" content="' . $theme_color . '">' . "\n";
        echo '<meta name="msapplication-config" content="' . esc_url(RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/browserconfig.xml') . '">' . "\n";
    }
    
    /**
     * Add Apple touch icons
     */
    public function add_apple_touch_icons() {
        if (!$this->is_enabled()) return;
        
        $icon_url = RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/';
        
        echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url($icon_url . 'apple-touch-icon.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="152x152" href="' . esc_url($icon_url . 'icon-152x152.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="144x144" href="' . esc_url($icon_url . 'icon-144x144.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="120x120" href="' . esc_url($icon_url . 'icon-120x120.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="114x114" href="' . esc_url($icon_url . 'icon-114x114.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="76x76" href="' . esc_url($icon_url . 'icon-76x76.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="72x72" href="' . esc_url($icon_url . 'icon-72x72.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="60x60" href="' . esc_url($icon_url . 'icon-60x60.png') . '">' . "\n";
        echo '<link rel="apple-touch-icon" sizes="57x57" href="' . esc_url($icon_url . 'icon-57x57.png') . '">' . "\n";
        
        // Splash screens for iOS
        echo $this->get_apple_splash_screens();
    }
    
    /**
     * Get Apple splash screen link tags
     */
    private function get_apple_splash_screens() {
        $splash_url = RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/splash/';
        $output = '';
        
        $screens = array(
            // iPhone 14 Pro Max, 15 Plus, 15 Pro Max
            array('device-width' => 430, 'device-height' => 932, 'ratio' => 3),
            // iPhone 14 Pro, 15, 15 Pro
            array('device-width' => 393, 'device-height' => 852, 'ratio' => 3),
            // iPhone 12/13/14, 12/13 Pro
            array('device-width' => 390, 'device-height' => 844, 'ratio' => 3),
            // iPhone 12/13 mini
            array('device-width' => 375, 'device-height' => 812, 'ratio' => 3),
            // iPhone 11 Pro Max, XS Max
            array('device-width' => 414, 'device-height' => 896, 'ratio' => 3),
            // iPhone 11, XR
            array('device-width' => 414, 'device-height' => 896, 'ratio' => 2),
            // iPhone X, XS, 11 Pro
            array('device-width' => 375, 'device-height' => 812, 'ratio' => 3),
            // iPhone 8 Plus
            array('device-width' => 414, 'device-height' => 736, 'ratio' => 3),
            // iPhone 8, SE2
            array('device-width' => 375, 'device-height' => 667, 'ratio' => 2),
            // iPhone SE
            array('device-width' => 320, 'device-height' => 568, 'ratio' => 2),
            // iPad Pro 12.9"
            array('device-width' => 1024, 'device-height' => 1366, 'ratio' => 2),
            // iPad Pro 11"
            array('device-width' => 834, 'device-height' => 1194, 'ratio' => 2),
            // iPad 10.2"
            array('device-width' => 810, 'device-height' => 1080, 'ratio' => 2),
            // iPad Air / iPad Pro 10.5"
            array('device-width' => 834, 'device-height' => 1112, 'ratio' => 2),
            // iPad Mini
            array('device-width' => 768, 'device-height' => 1024, 'ratio' => 2),
        );
        
        foreach ($screens as $screen) {
            $w = $screen['device-width'];
            $h = $screen['device-height'];
            $r = $screen['ratio'];
            $pw = $w * $r;
            $ph = $h * $r;
            
            // Portrait
            $output .= '<link rel="apple-touch-startup-image" ';
            $output .= 'href="' . esc_url($splash_url . "splash-{$pw}x{$ph}.png") . '" ';
            $output .= 'media="(device-width: ' . $w . 'px) and (device-height: ' . $h . 'px) and (-webkit-device-pixel-ratio: ' . $r . ') and (orientation: portrait)">' . "\n";
            
            // Landscape
            $output .= '<link rel="apple-touch-startup-image" ';
            $output .= 'href="' . esc_url($splash_url . "splash-{$ph}x{$pw}.png") . '" ';
            $output .= 'media="(device-width: ' . $w . 'px) and (device-height: ' . $h . 'px) and (-webkit-device-pixel-ratio: ' . $r . ') and (orientation: landscape)">' . "\n";
        }
        
        return $output;
    }
    
    /**
     * Enqueue PWA scripts
     */
    public function enqueue_pwa_scripts() {
        if (!$this->is_enabled()) return;
        
        // Only on rental-gates pages
        if (!$this->is_rental_gates_page()) return;
        
        wp_enqueue_script(
            'rental-gates-pwa',
            RENTAL_GATES_PLUGIN_URL . 'assets/js/pwa.js',
            array(),
            RENTAL_GATES_VERSION,
            true
        );
        
        wp_localize_script('rental-gates-pwa', 'rentalGatesPWA', array(
            'pwaEnabled' => true,
            'vapidPublicKey' => $this->settings['vapid_public_key'] ?? '',
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
        ));
    }
    
    /**
     * Check if current page is rental-gates
     */
    private function is_rental_gates_page() {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return strpos($uri, '/rental-gates/') !== false;
    }
    
    /**
     * Register manifest endpoint
     */
    public function register_manifest_endpoint() {
        add_rewrite_rule(
            '^rental-gates-manifest\.json$',
            'index.php?rental_gates_manifest=1',
            'top'
        );
        
        add_filter('query_vars', function($vars) {
            $vars[] = 'rental_gates_manifest';
            return $vars;
        });
        
        add_action('template_redirect', array($this, 'serve_manifest'));
    }
    
    /**
     * Serve manifest.json
     */
    public function serve_manifest() {
        if (!get_query_var('rental_gates_manifest')) {
            return;
        }
        
        header('Content-Type: application/manifest+json');
        header('Cache-Control: public, max-age=86400');
        
        echo json_encode($this->get_manifest(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }
    
    /**
     * Get manifest array
     */
    public function get_manifest() {
        $icon_url = RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/';
        
        return array(
            'name' => $this->settings['name'],
            'short_name' => $this->settings['short_name'],
            'description' => $this->settings['description'],
            'start_url' => home_url('/rental-gates/dashboard/'),
            'scope' => home_url('/rental-gates/'),
            'display' => $this->settings['display'],
            'orientation' => $this->settings['orientation'],
            'background_color' => $this->settings['background_color'],
            'theme_color' => $this->settings['theme_color'],
            'lang' => get_locale(),
            'dir' => is_rtl() ? 'rtl' : 'ltr',
            'categories' => array('business', 'productivity'),
            'icons' => array(
                array('src' => $icon_url . 'icon-72x72.png', 'sizes' => '72x72', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-96x96.png', 'sizes' => '96x96', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-128x128.png', 'sizes' => '128x128', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-144x144.png', 'sizes' => '144x144', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-152x152.png', 'sizes' => '152x152', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-192x192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'),
                array('src' => $icon_url . 'icon-384x384.png', 'sizes' => '384x384', 'type' => 'image/png'),
                array('src' => $icon_url . 'icon-512x512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'),
            ),
            'shortcuts' => array(
                array(
                    'name' => __('Dashboard', 'rental-gates'),
                    'url' => '/rental-gates/dashboard/',
                    'icons' => array(array('src' => $icon_url . 'shortcut-dashboard.png', 'sizes' => '96x96'))
                ),
                array(
                    'name' => __('Buildings', 'rental-gates'),
                    'url' => '/rental-gates/dashboard/buildings',
                    'icons' => array(array('src' => $icon_url . 'shortcut-buildings.png', 'sizes' => '96x96'))
                ),
                array(
                    'name' => __('Payments', 'rental-gates'),
                    'url' => '/rental-gates/dashboard/payments',
                    'icons' => array(array('src' => $icon_url . 'shortcut-payments.png', 'sizes' => '96x96'))
                ),
            ),
            'prefer_related_applications' => false,
        );
    }
    
    /**
     * Ensure app icons exist
     */
    public function ensure_icons_exist() {
        $icon_dir = RENTAL_GATES_PLUGIN_DIR . 'assets/images/pwa/';
        
        // Create directory if not exists
        if (!file_exists($icon_dir)) {
            wp_mkdir_p($icon_dir);
        }
        
        // Generate icons if they don't exist
        $sizes = array(72, 96, 128, 144, 152, 192, 384, 512);
        
        foreach ($sizes as $size) {
            $filename = $icon_dir . "icon-{$size}x{$size}.png";
            if (!file_exists($filename)) {
                $this->generate_icon($size, $filename);
            }
        }
        
        // Generate Apple touch icon
        $apple_icon = $icon_dir . 'apple-touch-icon.png';
        if (!file_exists($apple_icon)) {
            $this->generate_icon(180, $apple_icon);
        }
    }
    
    /**
     * Generate app icon
     */
    private function generate_icon($size, $filename) {
        if (!function_exists('imagecreatetruecolor')) {
            return false;
        }
        
        $image = imagecreatetruecolor($size, $size);
        
        // Enable alpha blending
        imagealphablending($image, false);
        imagesavealpha($image, true);
        
        // Background color (primary blue)
        $bg = imagecolorallocate($image, 37, 99, 235);
        imagefill($image, 0, 0, $bg);
        
        // White color for icon
        $white = imagecolorallocate($image, 255, 255, 255);
        
        // Draw a simple house icon
        $padding = $size * 0.2;
        $center = $size / 2;
        
        // Roof (triangle)
        $roof_points = array(
            $padding, $center,           // Left
            $center, $padding,           // Top
            $size - $padding, $center,   // Right
        );
        imagefilledpolygon($image, $roof_points, 3, $white);
        
        // House body (rectangle)
        $body_left = $padding + ($size * 0.1);
        $body_right = $size - $padding - ($size * 0.1);
        $body_top = $center - ($size * 0.05);
        $body_bottom = $size - $padding;
        imagefilledrectangle($image, $body_left, $body_top, $body_right, $body_bottom, $white);
        
        // Door (small rectangle in center bottom)
        $door_width = $size * 0.15;
        $door_height = $size * 0.2;
        $door_left = $center - ($door_width / 2);
        $door_right = $center + ($door_width / 2);
        $door_top = $body_bottom - $door_height;
        imagefilledrectangle($image, $door_left, $door_top, $door_right, $body_bottom, $bg);
        
        // Save as PNG
        imagepng($image, $filename);
        imagedestroy($image);
        
        return true;
    }
    
    /**
     * Register push notification routes
     */
    public function register_push_routes() {
        register_rest_route('rental-gates/v1', '/push/subscribe', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_push_subscribe'),
            'permission_callback' => function() {
                return is_user_logged_in();
            },
        ));
        
        register_rest_route('rental-gates/v1', '/push/unsubscribe', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_push_unsubscribe'),
            'permission_callback' => function() {
                return is_user_logged_in();
            },
        ));
        
        register_rest_route('rental-gates/v1', '/push/send', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_push_send'),
            'permission_callback' => function() {
                return current_user_can('rg_manage_communications');
            },
        ));
    }
    
    /**
     * Handle push subscription
     */
    public function handle_push_subscribe($request) {
        $subscription = $request->get_param('subscription');
        
        if (empty($subscription)) {
            return new WP_Error('invalid_subscription', __('Invalid subscription data', 'rental-gates'), array('status' => 400));
        }
        
        $user_id = get_current_user_id();
        
        // Store subscription
        update_user_meta($user_id, 'rental_gates_push_subscription', $subscription);
        update_user_meta($user_id, 'rental_gates_push_subscribed_at', current_time('mysql'));
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => __('Push notifications enabled', 'rental-gates'),
        ));
    }
    
    /**
     * Handle push unsubscription
     */
    public function handle_push_unsubscribe($request) {
        $user_id = get_current_user_id();
        
        delete_user_meta($user_id, 'rental_gates_push_subscription');
        delete_user_meta($user_id, 'rental_gates_push_subscribed_at');
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => __('Push notifications disabled', 'rental-gates'),
        ));
    }
    
    /**
     * Handle sending push notification
     */
    public function handle_push_send($request) {
        $user_ids = $request->get_param('user_ids');
        $title = sanitize_text_field($request->get_param('title'));
        $body = sanitize_textarea_field($request->get_param('body'));
        $url = esc_url_raw($request->get_param('url'));
        
        if (empty($user_ids) || empty($title)) {
            return new WP_Error('invalid_data', __('Missing required fields', 'rental-gates'), array('status' => 400));
        }
        
        $sent = 0;
        $failed = 0;
        
        foreach ((array) $user_ids as $user_id) {
            $result = $this->send_push_notification($user_id, $title, $body, $url);
            if ($result) {
                $sent++;
            } else {
                $failed++;
            }
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'sent' => $sent,
            'failed' => $failed,
        ));
    }
    
    /**
     * Send push notification to user
     */
    public function send_push_notification($user_id, $title, $body, $url = '') {
        $subscription = get_user_meta($user_id, 'rental_gates_push_subscription', true);
        
        if (empty($subscription)) {
            return false;
        }
        
        // Requires web-push library or external service
        // This is a simplified implementation
        
        $payload = json_encode(array(
            'title' => $title,
            'body' => $body,
            'icon' => RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/icon-192x192.png',
            'badge' => RENTAL_GATES_PLUGIN_URL . 'assets/images/pwa/badge-72x72.png',
            'data' => array(
                'url' => $url ?: home_url('/rental-gates/dashboard/notifications'),
            ),
        ));
        
        // In production, use web-push library:
        // $webPush = new Minishlink\WebPush\WebPush($auth);
        // $webPush->sendNotification($subscription, $payload);
        
        return true;
    }
    
    /**
     * Get users with push subscriptions
     */
    public function get_subscribed_users($org_id = null) {
        global $wpdb;
        
        $query = "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'rental_gates_push_subscription'";
        
        $user_ids = $wpdb->get_col($query);
        
        if ($org_id && !empty($user_ids)) {
            // Filter by organization
            $tables = Rental_Gates_Database::get_table_names();
            $org_user_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT user_id FROM {$tables['organization_members']} WHERE organization_id = %d",
                $org_id
            ));
            
            $user_ids = array_intersect($user_ids, $org_user_ids);
        }
        
        return $user_ids;
    }
    
    /**
     * Update PWA settings
     */
    public function update_settings($settings) {
        $this->settings = wp_parse_args($settings, $this->settings);
        update_option('rental_gates_pwa_settings', $this->settings);
        return $this->settings;
    }
    
    /**
     * Generate VAPID keys
     */
    public function generate_vapid_keys() {
        // Requires openssl extension
        if (!extension_loaded('openssl')) {
            return new WP_Error('openssl_required', __('OpenSSL extension required', 'rental-gates'));
        }
        
        $key = openssl_pkey_new(array(
            'curve_name' => 'prime256v1',
            'private_key_type' => OPENSSL_KEYTYPE_EC,
        ));
        
        if (!$key) {
            return new WP_Error('key_generation_failed', __('Failed to generate VAPID keys', 'rental-gates'));
        }
        
        $details = openssl_pkey_get_details($key);
        
        openssl_pkey_export($key, $private_key);
        
        $public_key = base64_encode($details['ec']['x'] . $details['ec']['y']);
        $public_key = rtrim(strtr($public_key, '+/', '-_'), '=');
        
        return array(
            'public' => $public_key,
            'private' => $private_key,
        );
    }
}

/**
 * Get PWA instance
 */
function rental_gates_pwa() {
    return Rental_Gates_PWA::instance();
}
