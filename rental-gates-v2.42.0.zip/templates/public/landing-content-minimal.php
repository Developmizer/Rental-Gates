<?php
/**
 * Rental Gates - Landing Page Content (Minimal Theme)
 * Clean, editorial-style design with dynamic brand colors
 * Dual-audience design for renters and property managers
 * @version 2.40.0
 */
if (!defined('ABSPATH')) exit;

$platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
$support_email = get_option('rental_gates_support_email', get_option('admin_email'));
$is_logged_in = is_user_logged_in();
$dashboard_url = home_url('/rental-gates/dashboard');
$login_url = home_url('/rental-gates/login');
$register_url = home_url('/rental-gates/register');
$map_url = home_url('/rental-gates/map');

// Section visibility settings
$show_renter_section = get_option('rental_gates_landing_show_renter_section', '1') === '1';
$show_logos = get_option('rental_gates_landing_show_logos', '1') === '1';
$show_features = get_option('rental_gates_landing_show_features', '1') === '1';
$show_steps = get_option('rental_gates_landing_show_steps', '1') === '1';
$show_pricing = get_option('rental_gates_landing_show_pricing', '1') === '1';
$show_testimonials = get_option('rental_gates_landing_show_testimonials', '1') === '1';
$show_cta = get_option('rental_gates_landing_show_cta', '1') === '1';

// Logo settings
$use_site_logo = get_option('rental_gates_landing_use_site_logo', '1') === '1';
$logo_height = intval(get_option('rental_gates_landing_logo_height', 40));
$site_logo_id = get_theme_mod('custom_logo');
$site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'medium') : '';

// Hero content customization
$hero_badge = get_option('rental_gates_landing_hero_badge', '');
$hero_title = get_option('rental_gates_landing_hero_title', '');
$hero_subtitle = get_option('rental_gates_landing_hero_subtitle', '');
$hero_cta_text = get_option('rental_gates_landing_hero_cta_text', '');
$hero_cta_secondary = get_option('rental_gates_landing_hero_cta_secondary', '');
$hero_renter_title = get_option('rental_gates_landing_hero_renter_title', '');
$hero_owner_title = get_option('rental_gates_landing_hero_owner_title', '');
$map_cta_text = get_option('rental_gates_landing_map_cta_text', '');

// Social proof / logos
$logos_title = get_option('rental_gates_landing_logos_title', '');
$logos_list = get_option('rental_gates_landing_logos_list', '');
$logos_array = array_filter(array_map('trim', explode("\n", $logos_list)));

// Social links
$social_twitter = get_option('rental_gates_landing_social_twitter', '');
$social_facebook = get_option('rental_gates_landing_social_facebook', '');
$social_linkedin = get_option('rental_gates_landing_social_linkedin', '');
$social_instagram = get_option('rental_gates_landing_social_instagram', '');

// Get brand color from admin settings
$brand_color = get_option('rental_gates_primary_color', '#0ea5e9');
$brand_rgb = array(
    hexdec(substr($brand_color, 1, 2)),
    hexdec(substr($brand_color, 3, 2)),
    hexdec(substr($brand_color, 5, 2))
);
$brand_rgb_str = implode(', ', $brand_rgb);

// Default content if not customized
if (empty($hero_badge)) $hero_badge = __('Property Management Platform', 'rental-gates');
if (empty($hero_title)) $hero_title = __('Find Your Perfect Rental or Manage Your Properties', 'rental-gates');
if (empty($hero_subtitle)) $hero_subtitle = __('Discover available rentals on our interactive map, or streamline your property management with our all-in-one platform.', 'rental-gates');
if (empty($hero_cta_text)) $hero_cta_text = __('Get Started', 'rental-gates');
if (empty($hero_cta_secondary)) $hero_cta_secondary = __('Learn More', 'rental-gates');
if (empty($hero_renter_title)) $hero_renter_title = __('I\'m Looking for a Rental', 'rental-gates');
if (empty($hero_owner_title)) $hero_owner_title = __('I Manage Properties', 'rental-gates');
if (empty($map_cta_text)) $map_cta_text = __('Browse Map', 'rental-gates');
if (empty($logos_title)) $logos_title = __('Trusted by property managers', 'rental-gates');
if (empty($logos_array)) $logos_array = array('Apex Properties', 'Urban Living', 'Prime Rentals', 'Metro Housing', 'Skyline Mgmt');

// Get property count for renter section
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();
$property_count = $wpdb->get_var(
    "SELECT COUNT(DISTINCT b.id) 
     FROM {$tables['buildings']} b
     JOIN {$tables['units']} u ON u.building_id = b.id
     WHERE u.availability IN ('available', 'coming_soon')"
);
$property_count = $property_count ? intval($property_count) : 0;
?>

<div class="rgm-landing" id="rgm-landing">
<style>
/* ============================================
   Minimal Theme - CSS Variables
   ============================================ */
.rgm-landing {
    /* Brand Colors */
    --rgm-primary: <?php echo esc_attr($brand_color); ?>;
    --rgm-primary-rgb: <?php echo $brand_rgb_str; ?>;
    --rgm-primary-hover: color-mix(in srgb, var(--rgm-primary), #000 10%);
    
    /* Light Theme */
    --rgm-bg: #ffffff;
    --rgm-bg-alt: #fafafa;
    --rgm-text: #18181b;
    --rgm-text-secondary: #52525b;
    --rgm-text-muted: #71717a;
    --rgm-border: #e4e4e7;
    
    /* Layout */
    --rgm-container: 1140px;
    --rgm-header-h: 72px;
    --rgm-section-py: 120px;
    --rgm-radius: 8px;
    
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 16px;
    line-height: 1.6;
    color: var(--rgm-text);
    background: var(--rgm-bg);
    -webkit-font-smoothing: antialiased;
}

.rgm-landing.dark {
    --rgm-bg: #09090b;
    --rgm-bg-alt: #18181b;
    --rgm-text: #fafafa;
    --rgm-text-secondary: #a1a1aa;
    --rgm-text-muted: #71717a;
    --rgm-border: #27272a;
}

/* Reset */
.rgm-landing *, .rgm-landing *::before, .rgm-landing *::after { box-sizing: border-box; margin: 0; padding: 0; }
.rgm-landing img { max-width: 100%; height: auto; }
.rgm-landing a { color: inherit; text-decoration: none; }
.rgm-landing button { font-family: inherit; cursor: pointer; border: none; background: none; }

/* Container */
.rgm-container { 
    width: 100%; 
    max-width: var(--rgm-container); 
    margin: 0 auto; 
    padding: 0 24px; 
}

/* ============================================
   Header - Clean & Simple
   ============================================ */
.rgm-header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: var(--rgm-header-h);
    background: var(--rgm-bg);
    border-bottom: 1px solid transparent;
    z-index: 1000;
    transition: all 0.2s;
}

.rgm-header.scrolled {
    border-bottom-color: var(--rgm-border);
}

.rgm-header > .rgm-container {
    height: 100%;
}

.rgm-header-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    gap: 32px;
}

/* Logo - Text Only */
.rgm-logo {
    font-size: 20px;
    font-weight: 700;
    color: var(--rgm-text);
    letter-spacing: -0.02em;
}

/* Nav - Underline Style */
.rgm-nav {
    display: flex;
    align-items: center;
    gap: 32px;
}

.rgm-nav-link {
    position: relative;
    font-size: 14px;
    font-weight: 500;
    color: var(--rgm-text-muted);
    padding: 4px 0;
    transition: color 0.2s;
}

.rgm-nav-link::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 0;
    height: 1px;
    background: var(--rgm-primary);
    transition: width 0.2s;
}

.rgm-nav-link:hover { color: var(--rgm-text); }
.rgm-nav-link:hover::after,
.rgm-nav-link.active::after { width: 100%; }
.rgm-nav-link.active { color: var(--rgm-text); }

/* Header Actions */
.rgm-header-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.rgm-theme-toggle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    color: var(--rgm-text-muted);
    border-radius: 50%;
    transition: all 0.2s;
}

.rgm-theme-toggle:hover { color: var(--rgm-text); background: var(--rgm-bg-alt); }
.rgm-theme-toggle svg { width: 18px; height: 18px; }
.rgm-theme-toggle .sun { display: none; }
.dark .rgm-theme-toggle .sun { display: block; }
.dark .rgm-theme-toggle .moon { display: none; }

/* Buttons - Clean */
.rgm-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 500;
    border-radius: var(--rgm-radius);
    transition: all 0.2s;
}

.rgm-btn-primary {
    background: var(--rgm-primary);
    color: white;
}

.rgm-btn-primary:hover {
    background: var(--rgm-primary-hover);
}

.rgm-btn-outline {
    background: transparent;
    color: var(--rgm-text);
    border: 1px solid var(--rgm-border);
}

.rgm-btn-outline:hover {
    border-color: var(--rgm-text);
}

.rgm-btn-text {
    background: transparent;
    color: var(--rgm-text-muted);
    padding: 8px 12px;
}

.rgm-btn-text:hover { color: var(--rgm-text); }

.rgm-btn-lg { padding: 14px 28px; font-size: 15px; }

.rgm-btn svg { width: 16px; height: 16px; }

/* Mobile Menu Toggle */
.rgm-mobile-btn {
    display: none;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    color: var(--rgm-text);
}

.rgm-mobile-btn svg { width: 24px; height: 24px; }
.rgm-mobile-btn .icon-close { display: none; }
.rgm-mobile-btn.active .icon-menu { display: none; }
.rgm-mobile-btn.active .icon-close { display: block; }

/* Mobile Menu */
.rgm-mobile-menu {
    display: none;
    position: fixed;
    top: var(--rgm-header-h);
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--rgm-bg);
    padding: 24px;
    z-index: 999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s;
}

.rgm-mobile-menu.open { opacity: 1; visibility: visible; }

.rgm-mobile-nav { display: flex; flex-direction: column; gap: 8px; }

.rgm-mobile-nav-link {
    display: block;
    padding: 16px 0;
    font-size: 18px;
    font-weight: 500;
    color: var(--rgm-text);
    border-bottom: 1px solid var(--rgm-border);
}

.rgm-mobile-actions {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 32px;
}

.rgm-mobile-actions .rgm-btn { width: 100%; justify-content: center; }

/* ============================================
   Hero - Left Aligned, Typography Focused
   ============================================ */
.rgm-hero {
    padding: calc(var(--rgm-header-h) + 80px) 0 100px;
}

.rgm-hero-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 64px;
    align-items: center;
}

.rgm-hero-eyebrow {
    display: inline-block;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--rgm-primary);
    margin-bottom: 24px;
}

.rgm-hero-title {
    font-size: clamp(40px, 5vw, 64px);
    font-weight: 700;
    line-height: 1.1;
    letter-spacing: -0.03em;
    color: var(--rgm-text);
    margin: 0 0 24px 0;
}

.rgm-hero-subtitle {
    font-size: 18px;
    line-height: 1.7;
    color: var(--rgm-text-secondary);
    margin: 0 0 40px 0;
    max-width: 480px;
}

.rgm-hero-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.rgm-hero-note {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 24px;
    font-size: 13px;
    color: var(--rgm-text-muted);
}

.rgm-hero-note svg { width: 16px; height: 16px; color: var(--rgm-primary); }

/* Hero Visual */
.rgm-hero-visual {
    position: relative;
}

.rgm-hero-image {
    width: 100%;
    aspect-ratio: 4/3;
    background: var(--rgm-bg-alt);
    border: 1px solid var(--rgm-border);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.rgm-hero-image svg {
    width: 120px;
    height: 120px;
    color: var(--rgm-border);
}

/* ============================================
   Logos - Simple Row
   ============================================ */
.rgm-logos {
    padding: 64px 0;
    border-top: 1px solid var(--rgm-border);
    border-bottom: 1px solid var(--rgm-border);
}

.rgm-logos-title {
    text-align: center;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--rgm-text-muted);
    margin: 0 0 32px 0;
}

.rgm-logos-grid {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 48px;
    flex-wrap: wrap;
}

.rgm-logo-item {
    font-size: 16px;
    font-weight: 600;
    color: var(--rgm-text-secondary);
}

/* ============================================
   Section Styles
   ============================================ */
.rgm-section { padding: var(--rgm-section-py) 0; }

.rgm-section-header {
    max-width: 560px;
    margin: 0 0 64px 0;
}

.rgm-section-header.centered {
    text-align: center;
    margin: 0 auto 64px;
}

.rgm-section-eyebrow {
    display: inline-block;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--rgm-primary);
    margin-bottom: 16px;
}

.rgm-section-title {
    font-size: clamp(28px, 4vw, 40px);
    font-weight: 700;
    line-height: 1.2;
    letter-spacing: -0.02em;
    color: var(--rgm-text);
    margin: 0 0 16px 0;
}

.rgm-section-subtitle {
    font-size: 17px;
    line-height: 1.7;
    color: var(--rgm-text-secondary);
    margin: 0;
}

/* ============================================
   Features - Clean Grid
   ============================================ */
.rgm-features-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 48px;
}

.rgm-feature {
    padding: 0;
}

.rgm-feature-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    margin-bottom: 20px;
    color: var(--rgm-primary);
}

.rgm-feature-icon svg { width: 28px; height: 28px; stroke-width: 1.5; }

.rgm-feature-title {
    font-size: 17px;
    font-weight: 600;
    color: var(--rgm-text);
    margin: 0 0 12px 0;
}

.rgm-feature-text {
    font-size: 15px;
    line-height: 1.7;
    color: var(--rgm-text-secondary);
    margin: 0;
}

/* ============================================
   Steps - Numbered List
   ============================================ */
.rgm-steps-section {
    background: var(--rgm-bg-alt);
}

.rgm-steps {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 32px;
}

.rgm-step {
    position: relative;
}

.rgm-step-number {
    font-size: 48px;
    font-weight: 700;
    color: var(--rgm-border);
    line-height: 1;
    margin-bottom: 16px;
}

.dark .rgm-step-number { color: var(--rgm-border); }

.rgm-step-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--rgm-text);
    margin: 0 0 8px 0;
}

.rgm-step-text {
    font-size: 14px;
    line-height: 1.6;
    color: var(--rgm-text-secondary);
    margin: 0;
}

/* ============================================
   Pricing - Clean Cards
   ============================================ */
.rgm-pricing-toggle {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    margin-bottom: 48px;
}

.rgm-billing-label {
    font-size: 14px;
    font-weight: 500;
    color: var(--rgm-text-muted);
    transition: color 0.2s;
}

.rgm-billing-label.active { color: var(--rgm-text); }

.rgm-billing-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: var(--rgm-border);
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
}

.rgm-billing-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: white;
    border-radius: 50%;
    transition: transform 0.2s;
}

.rgm-billing-switch.yearly { background: var(--rgm-primary); }
.rgm-billing-switch.yearly::after { transform: translateX(20px); }

.rgm-billing-save {
    font-size: 12px;
    font-weight: 600;
    color: var(--rgm-primary);
}

.rgm-pricing-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

.rgm-pricing-grid-4 {
    grid-template-columns: repeat(4, 1fr);
}

.rgm-pricing-card {
    background: var(--rgm-bg);
    border: 1px solid var(--rgm-border);
    border-radius: 12px;
    padding: 32px;
    transition: all 0.2s;
    display: flex;
    flex-direction: column;
}

.rgm-pricing-card:hover {
    border-color: var(--rgm-text-muted);
}

.rgm-pricing-card.featured {
    border-color: var(--rgm-primary);
    position: relative;
}

.rgm-pricing-badge {
    position: absolute;
    top: -12px;
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 12px;
    background: var(--rgm-primary);
    color: white;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    border-radius: 4px;
}

.rgm-pricing-name {
    font-size: 18px;
    font-weight: 600;
    color: var(--rgm-text);
    margin: 0 0 8px 0;
}

.rgm-pricing-desc {
    font-size: 14px;
    color: var(--rgm-text-muted);
    margin: 0 0 24px 0;
}

.rgm-pricing-price {
    display: flex;
    align-items: baseline;
    gap: 4px;
    margin-bottom: 24px;
}

.rgm-pricing-currency {
    font-size: 20px;
    font-weight: 600;
    color: var(--rgm-text);
}

.rgm-pricing-amount {
    font-size: 48px;
    font-weight: 700;
    line-height: 1;
    color: var(--rgm-text);
    letter-spacing: -0.02em;
}

.rgm-pricing-period {
    font-size: 14px;
    color: var(--rgm-text-muted);
}

.rgm-pricing-features {
    list-style: none;
    margin: 0 0 32px 0;
    padding: 0;
}

.rgm-pricing-features li {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 10px 0;
    font-size: 14px;
    color: var(--rgm-text-secondary);
    border-bottom: 1px solid var(--rgm-border);
}

.rgm-pricing-features li:last-child { border-bottom: none; }

.rgm-pricing-features svg {
    flex-shrink: 0;
    width: 18px;
    height: 18px;
    color: var(--rgm-primary);
    margin-top: 1px;
}

.rgm-pricing-card .rgm-btn { width: 100%; justify-content: center; }

/* ============================================
   Testimonials - Quote Style
   ============================================ */
.rgm-testimonials-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 32px;
}

.rgm-testimonial {
    padding: 32px;
    background: var(--rgm-bg-alt);
    border-radius: 12px;
}

.rgm-testimonial-quote {
    font-size: 32px;
    line-height: 1;
    color: var(--rgm-primary);
    margin-bottom: 16px;
}

.rgm-testimonial-text {
    font-size: 15px;
    line-height: 1.7;
    color: var(--rgm-text-secondary);
    margin: 0 0 24px 0;
}

.rgm-testimonial-author {
    display: flex;
    align-items: center;
    gap: 12px;
}

.rgm-testimonial-avatar {
    width: 40px;
    height: 40px;
    background: var(--rgm-primary);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 14px;
    font-weight: 600;
}

.rgm-testimonial-name {
    font-size: 14px;
    font-weight: 600;
    color: var(--rgm-text);
    margin: 0;
}

.rgm-testimonial-role {
    font-size: 13px;
    color: var(--rgm-text-muted);
    margin: 2px 0 0 0;
}

/* ============================================
   CTA - Simple
   ============================================ */
.rgm-cta {
    background: var(--rgm-bg-alt);
    text-align: center;
}

.rgm-cta-content {
    max-width: 560px;
    margin: 0 auto;
}

.rgm-cta-title {
    font-size: clamp(28px, 4vw, 40px);
    font-weight: 700;
    line-height: 1.2;
    letter-spacing: -0.02em;
    color: var(--rgm-text);
    margin: 0 0 16px 0;
}

.rgm-cta-subtitle {
    font-size: 17px;
    line-height: 1.7;
    color: var(--rgm-text-secondary);
    margin: 0 0 32px 0;
}

/* ============================================
   Footer - Minimal
   ============================================ */
.rgm-footer {
    padding: 64px 0 32px;
    border-top: 1px solid var(--rgm-border);
}

.rgm-footer-grid {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr;
    gap: 48px;
    margin-bottom: 48px;
}

.rgm-footer-brand {
    max-width: 280px;
}

.rgm-footer-logo {
    font-size: 18px;
    font-weight: 700;
    color: var(--rgm-text);
    margin-bottom: 16px;
}

.rgm-footer-text {
    font-size: 14px;
    line-height: 1.6;
    color: var(--rgm-text-muted);
    margin: 0;
}

.rgm-footer-heading {
    font-size: 13px;
    font-weight: 600;
    color: var(--rgm-text);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin: 0 0 20px 0;
}

.rgm-footer-links {
    list-style: none;
    margin: 0;
    padding: 0;
}

.rgm-footer-links li { margin-bottom: 12px; }

.rgm-footer-links a {
    font-size: 14px;
    color: var(--rgm-text-muted);
    transition: color 0.2s;
}

.rgm-footer-links a:hover { color: var(--rgm-text); }

.rgm-footer-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 32px;
    border-top: 1px solid var(--rgm-border);
}

.rgm-footer-copy {
    font-size: 13px;
    color: var(--rgm-text-muted);
    margin: 0;
}

.rgm-footer-legal {
    display: flex;
    gap: 24px;
}

.rgm-footer-legal a {
    font-size: 13px;
    color: var(--rgm-text-muted);
    transition: color 0.2s;
}

.rgm-footer-legal a:hover { color: var(--rgm-text); }

/* ============================================
   Responsive
   ============================================ */
@media (max-width: 1200px) {
    .rgm-pricing-grid-4 { grid-template-columns: repeat(2, 1fr); max-width: 800px; margin: 0 auto; }
}

@media (max-width: 1024px) {
    .rgm-hero-grid { grid-template-columns: 1fr; gap: 48px; }
    .rgm-hero-visual { order: -1; }
    .rgm-features-grid { grid-template-columns: repeat(2, 1fr); }
    .rgm-steps { grid-template-columns: repeat(2, 1fr); }
    .rgm-pricing-grid { grid-template-columns: 1fr; max-width: 400px; margin: 0 auto; }
    .rgm-pricing-grid-4 { grid-template-columns: 1fr; max-width: 400px; }
    .rgm-testimonials-grid { grid-template-columns: repeat(2, 1fr); }
    .rgm-footer-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .rgm-landing { --rgm-section-py: 80px; --rgm-header-h: 64px; }
    .rgm-nav { display: none; }
    .rgm-mobile-btn { display: flex; }
    .rgm-mobile-menu { display: block; }
    .rgm-hero { padding: calc(var(--rgm-header-h) + 48px) 0 64px; }
    .rgm-hero-actions { flex-direction: column; align-items: flex-start; }
    .rgm-hero-actions .rgm-btn { width: 100%; max-width: 280px; justify-content: center; }
    .rgm-features-grid, .rgm-steps, .rgm-testimonials-grid { grid-template-columns: 1fr; }
    .rgm-logos-grid { gap: 24px; }
    .rgm-logo-item { font-size: 14px; }
    .rgm-footer-grid { grid-template-columns: 1fr; gap: 32px; }
    .rgm-footer-brand { max-width: none; }
    .rgm-footer-bottom { flex-direction: column; gap: 16px; text-align: center; }
}

@media (max-width: 480px) {
    .rgm-container { padding: 0 16px; }
    .rgm-hero-title { font-size: 36px; }
    .rgm-section-title { font-size: 28px; }
    .rgm-pricing-card { padding: 24px; }
    .rgm-pricing-amount { font-size: 40px; }
    .rgm-testimonial { padding: 24px; }
}
</style>

<!-- Header -->
<header class="rgm-header" id="rgm-header">
    <div class="rgm-container">
        <div class="rgm-header-inner">
            <a href="<?php echo home_url('/rental-gates'); ?>" class="rgm-logo">
                <?php if ($use_site_logo && $site_logo_url): ?>
                <img src="<?php echo esc_url($site_logo_url); ?>" alt="<?php echo esc_attr($platform_name); ?>" style="height: <?php echo $logo_height; ?>px; width: auto;">
                <?php else: ?>
                <?php echo esc_html($platform_name); ?>
                <?php endif; ?>
            </a>
            
            <nav class="rgm-nav">
                <a href="<?php echo esc_url($map_url); ?>" class="rgm-nav-link" aria-label="<?php esc_attr_e('Browse available properties', 'rental-gates'); ?>"><?php _e('Browse Properties', 'rental-gates'); ?></a>
                <?php if ($show_features): ?><a href="#rgm-features" class="rgm-nav-link"><?php _e('Features', 'rental-gates'); ?></a><?php endif; ?>
                <?php if ($show_pricing): ?><a href="#rgm-pricing" class="rgm-nav-link"><?php _e('Pricing', 'rental-gates'); ?></a><?php endif; ?>
                <?php if ($show_testimonials): ?><a href="#rgm-testimonials" class="rgm-nav-link"><?php _e('Reviews', 'rental-gates'); ?></a><?php endif; ?>
                <a href="mailto:<?php echo esc_attr($support_email); ?>" class="rgm-nav-link"><?php _e('Contact', 'rental-gates'); ?></a>
            </nav>
            
            <div class="rgm-header-actions">
                <button type="button" class="rgm-theme-toggle" id="rgm-theme-toggle" aria-label="<?php esc_attr_e('Toggle dark mode', 'rental-gates'); ?>">
                    <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                    <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                </button>
                
                <?php if ($is_logged_in): ?>
                <a href="<?php echo esc_url($dashboard_url); ?>" class="rgm-btn rgm-btn-primary"><?php _e('Dashboard', 'rental-gates'); ?></a>
                <?php else: ?>
                <a href="<?php echo esc_url($login_url); ?>" class="rgm-btn rgm-btn-text"><?php _e('Sign In', 'rental-gates'); ?></a>
                <a href="<?php echo esc_url($register_url); ?>" class="rgm-btn rgm-btn-primary"><?php _e('Get Started', 'rental-gates'); ?></a>
                <?php endif; ?>
                
                <button type="button" class="rgm-mobile-btn" id="rgm-mobile-btn" aria-label="<?php esc_attr_e('Toggle menu', 'rental-gates'); ?>">
                    <svg class="icon-menu" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
                    <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
            </div>
        </div>
    </div>
</header>

<!-- Mobile Menu -->
<div class="rgm-mobile-menu" id="rgm-mobile-menu">
    <nav class="rgm-mobile-nav">
        <a href="<?php echo esc_url($map_url); ?>" class="rgm-mobile-nav-link"><?php _e('Browse Properties', 'rental-gates'); ?></a>
        <?php if ($show_features): ?><a href="#rgm-features" class="rgm-mobile-nav-link"><?php _e('Features', 'rental-gates'); ?></a><?php endif; ?>
        <?php if ($show_pricing): ?><a href="#rgm-pricing" class="rgm-mobile-nav-link"><?php _e('Pricing', 'rental-gates'); ?></a><?php endif; ?>
        <?php if ($show_testimonials): ?><a href="#rgm-testimonials" class="rgm-mobile-nav-link"><?php _e('Reviews', 'rental-gates'); ?></a><?php endif; ?>
        <a href="mailto:<?php echo esc_attr($support_email); ?>" class="rgm-mobile-nav-link"><?php _e('Contact', 'rental-gates'); ?></a>
    </nav>
    <div class="rgm-mobile-actions">
        <?php if ($is_logged_in): ?>
        <a href="<?php echo esc_url($dashboard_url); ?>" class="rgm-btn rgm-btn-primary"><?php _e('Dashboard', 'rental-gates'); ?></a>
        <?php else: ?>
        <a href="<?php echo esc_url($register_url); ?>" class="rgm-btn rgm-btn-primary"><?php echo esc_html($hero_cta_text); ?></a>
        <a href="<?php echo esc_url($login_url); ?>" class="rgm-btn rgm-btn-outline"><?php _e('Sign In', 'rental-gates'); ?></a>
        <?php endif; ?>
    </div>
</div>

<!-- Hero -->
<section class="rgm-hero">
    <div class="rgm-container">
        <div class="rgm-hero-grid">
            <div class="rgm-hero-content">
                <span class="rgm-hero-eyebrow"><?php echo esc_html($hero_badge); ?></span>
                <h1 class="rgm-hero-title"><?php echo esc_html($hero_title); ?></h1>
                <p class="rgm-hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
                <div class="rgm-hero-actions">
                    <a href="<?php echo esc_url($map_url); ?>" class="rgm-btn rgm-btn-primary rgm-btn-lg" aria-label="<?php esc_attr_e('Browse available properties', 'rental-gates'); ?>"><?php echo esc_html($map_cta_text); ?></a>
                    <a href="<?php echo esc_url($register_url); ?>" class="rgm-btn rgm-btn-outline rgm-btn-lg" aria-label="<?php esc_attr_e('Start managing properties', 'rental-gates'); ?>"><?php echo esc_html($hero_cta_text); ?></a>
                </div>
                <p class="rgm-hero-note">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                    <?php _e('14-day free trial • No credit card required', 'rental-gates'); ?>
                </p>
            </div>
            <div class="rgm-hero-visual">
                <div class="rgm-hero-image">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Logos -->
<section class="rgm-logos">
    <div class="rgm-container">
        <p class="rgm-logos-title"><?php _e('Trusted by property managers', 'rental-gates'); ?></p>
        <div class="rgm-logos-grid">
            <span class="rgm-logo-item">Apex Properties</span>
            <span class="rgm-logo-item">Urban Living</span>
            <span class="rgm-logo-item">Prime Rentals</span>
            <span class="rgm-logo-item">Metro Housing</span>
            <span class="rgm-logo-item">Skyline Mgmt</span>
        </div>
    </div>
</section>

<!-- Features -->
<section class="rgm-section" id="rgm-features">
    <div class="rgm-container">
        <div class="rgm-section-header">
            <span class="rgm-section-eyebrow"><?php _e('Features', 'rental-gates'); ?></span>
            <h2 class="rgm-section-title"><?php _e('Everything you need, nothing you don\'t', 'rental-gates'); ?></h2>
            <p class="rgm-section-subtitle"><?php _e('Purpose-built tools that help you manage properties efficiently.', 'rental-gates'); ?></p>
        </div>
        
        <div class="rgm-features-grid">
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Property Management', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Organize buildings, units, and amenities in one central location.', 'rental-gates'); ?></p>
            </div>
            
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Tenant Portal', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Give tenants access to pay rent, submit requests, and view documents.', 'rental-gates'); ?></p>
            </div>
            
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Lease Tracking', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Track lease terms, renewals, and important dates automatically.', 'rental-gates'); ?></p>
            </div>
            
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Online Payments', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Accept rent payments online with automatic receipts and tracking.', 'rental-gates'); ?></p>
            </div>
            
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Maintenance', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Track and resolve maintenance requests with full history.', 'rental-gates'); ?></p>
            </div>
            
            <div class="rgm-feature">
                <div class="rgm-feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                </div>
                <h3 class="rgm-feature-title"><?php _e('Document Storage', 'rental-gates'); ?></h3>
                <p class="rgm-feature-text"><?php _e('Store leases, photos, and documents securely in the cloud.', 'rental-gates'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Steps -->
<section class="rgm-section rgm-steps-section">
    <div class="rgm-container">
        <div class="rgm-section-header">
            <span class="rgm-section-eyebrow"><?php _e('How It Works', 'rental-gates'); ?></span>
            <h2 class="rgm-section-title"><?php _e('Get started in minutes', 'rental-gates'); ?></h2>
        </div>
        
        <div class="rgm-steps">
            <div class="rgm-step">
                <div class="rgm-step-number">01</div>
                <h3 class="rgm-step-title"><?php _e('Create Account', 'rental-gates'); ?></h3>
                <p class="rgm-step-text"><?php _e('Sign up free in under 2 minutes.', 'rental-gates'); ?></p>
            </div>
            <div class="rgm-step">
                <div class="rgm-step-number">02</div>
                <h3 class="rgm-step-title"><?php _e('Add Properties', 'rental-gates'); ?></h3>
                <p class="rgm-step-text"><?php _e('Import or add your buildings and units.', 'rental-gates'); ?></p>
            </div>
            <div class="rgm-step">
                <div class="rgm-step-number">03</div>
                <h3 class="rgm-step-title"><?php _e('Invite Tenants', 'rental-gates'); ?></h3>
                <p class="rgm-step-text"><?php _e('Send invites so tenants can access their portal.', 'rental-gates'); ?></p>
            </div>
            <div class="rgm-step">
                <div class="rgm-step-number">04</div>
                <h3 class="rgm-step-title"><?php _e('Start Managing', 'rental-gates'); ?></h3>
                <p class="rgm-step-text"><?php _e('Collect rent and manage properties effortlessly.', 'rental-gates'); ?></p>
            </div>
        </div>
    </div>
</section>

<?php if ($show_pricing): ?>
<!-- Pricing -->
<section class="rgm-section" id="rgm-pricing">
    <div class="rgm-container">
        <div class="rgm-section-header centered">
            <span class="rgm-section-eyebrow"><?php _e('Pricing', 'rental-gates'); ?></span>
            <h2 class="rgm-section-title"><?php _e('Simple, transparent pricing', 'rental-gates'); ?></h2>
            <p class="rgm-section-subtitle"><?php _e('Start free, scale as you grow.', 'rental-gates'); ?></p>
        </div>
        
        <div class="rgm-pricing-toggle">
            <span class="rgm-billing-label active" data-period="monthly"><?php _e('Monthly', 'rental-gates'); ?></span>
            <button type="button" class="rgm-billing-switch" id="rgm-billing-switch" aria-label="<?php esc_attr_e('Toggle billing period', 'rental-gates'); ?>"></button>
            <span class="rgm-billing-label" data-period="yearly"><?php _e('Yearly', 'rental-gates'); ?></span>
            <span class="rgm-billing-save"><?php _e('Save 20%', 'rental-gates'); ?></span>
        </div>
        
        <?php
        // Get plans from feature gate
        $feature_gate = rg_feature_gate();
        $plans = $feature_gate->get_all_plans();
        
        // Sort plans by sort_order
        uasort($plans, function($a, $b) {
            return ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0);
        });
        
        // Count visible plans for grid class
        $visible_plans = array_filter($plans, function($plan) {
            return Rental_Gates_Pricing::is_plan_visible($plan);
        });
        $plan_count = count($visible_plans);
        $grid_class = $plan_count >= 4 ? 'rgm-pricing-grid-4' : '';
        
        // Module labels for display
        $module_labels = array(
            'tenant_portal' => __('Tenant portal', 'rental-gates'),
            'online_payments' => __('Online payments', 'rental-gates'),
            'maintenance' => __('Maintenance tracking', 'rental-gates'),
            'lease_management' => __('Lease management', 'rental-gates'),
            'ai_screening' => __('AI-powered tools', 'rental-gates'),
            'marketing_qr' => __('Marketing & QR codes', 'rental-gates'),
            'vendor_management' => __('Vendor management', 'rental-gates'),
            'chat_messaging' => __('Chat & messaging', 'rental-gates'),
            'advanced_reports' => __('Advanced reports', 'rental-gates'),
            'bulk_operations' => __('Bulk operations', 'rental-gates'),
            'api_access' => __('API access', 'rental-gates'),
            'white_label' => __('White label', 'rental-gates'),
        );
        ?>
        <div class="rgm-pricing-grid <?php echo esc_attr($grid_class); ?>">
            <?php 
            // Get pricing helper
            $pricing_helper = function_exists('rental_gates_pricing') ? rental_gates_pricing() : null;
            
            foreach ($plans as $plan_id => $plan): 
                // Skip hidden/inactive plans
                if (!Rental_Gates_Pricing::is_plan_visible($plan)) continue;
                
                $is_featured = !empty($plan['is_featured']);
                
                // Use unified pricing helper for consistent calculations
                $plan['id'] = $plan_id;
                
                if ($pricing_helper) {
                    $pricing = $pricing_helper->get_plan_pricing($plan);
                } else {
                    // Fallback if pricing helper not available
                    $monthly = floatval($plan['price_monthly'] ?? 0);
                    $yearly = floatval($plan['price_yearly'] ?? 0);
                    
                    // Default yearly to 80% of monthly * 12 if not set
                    if ($yearly <= 0 && $monthly > 0) {
                        $yearly = round($monthly * 12 * 0.8, 0);
                    }
                    
                    $pricing = array(
                        'is_free' => !empty($plan['is_free']) || empty($plan['price_monthly']),
                        'monthly_discounted' => $monthly,
                        'yearly_monthly_discounted' => $yearly > 0 ? round($yearly / 12, 0) : 0,
                    );
                }
                
                $is_free = $pricing['is_free'];
                $price_monthly = intval($pricing['monthly_discounted']);
                $price_yearly_monthly = intval($pricing['yearly_monthly_discounted']);
            ?>
            <div class="rgm-pricing-card <?php echo $is_featured ? 'featured' : ''; ?>" data-plan="<?php echo esc_attr($plan_id); ?>">
                <?php if ($is_featured): ?>
                <span class="rgm-pricing-badge"><?php _e('Popular', 'rental-gates'); ?></span>
                <?php endif; ?>
                <h3 class="rgm-pricing-name"><?php echo esc_html($plan['name']); ?></h3>
                <p class="rgm-pricing-desc"><?php echo esc_html($plan['description'] ?? ''); ?></p>
                <div class="rgm-pricing-price">
                    <span class="rgm-pricing-currency">$</span>
                    <span class="rgm-pricing-amount" data-monthly="<?php echo $price_monthly; ?>" data-yearly="<?php echo $price_yearly_monthly; ?>"><?php echo $price_monthly; ?></span>
                    <span class="rgm-pricing-period">/<?php _e('month', 'rental-gates'); ?></span>
                </div>
                <ul class="rgm-pricing-features">
                    <?php 
                    // Show limits - Buildings first, then units
                    $limits_order = array('buildings', 'units', 'staff');
                    foreach ($limits_order as $limit_key):
                        $value = $plan['limits'][$limit_key] ?? 0;
                        if ($value == 0) continue;
                        
                        $limit_labels = array(
                            'buildings' => __('buildings', 'rental-gates'),
                            'units' => __('units', 'rental-gates'),
                            'staff' => __('staff', 'rental-gates'),
                        );
                        
                        if ($value == -1) {
                            $display = sprintf(__('Unlimited %s', 'rental-gates'), $limit_labels[$limit_key]);
                        } else {
                            $display = sprintf(__('Up to %d %s', 'rental-gates'), $value, $limit_labels[$limit_key]);
                        }
                    ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php echo esc_html($display); ?></li>
                    <?php endforeach; ?>
                    
                    <?php 
                    // Show key modules (limit to 3 for minimal display)
                    $modules_to_show = array('online_payments', 'ai_screening', 'api_access');
                    $shown_count = 0;
                    foreach ($modules_to_show as $mod_key):
                        if ($shown_count >= 2) break;
                        $enabled = !empty($plan['modules'][$mod_key]);
                        if (!$enabled) continue;
                    ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php echo esc_html($module_labels[$mod_key] ?? $mod_key); ?></li>
                    <?php 
                        $shown_count++;
                    endforeach; 
                    ?>
                    
                    <?php 
                    // Show first custom feature
                    $custom_feature = !empty($plan['custom_features']) ? $plan['custom_features'][0] : null;
                    if ($custom_feature): 
                    ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php echo esc_html($custom_feature); ?></li>
                    <?php endif; ?>
                </ul>
                <?php 
                $btn_class = $is_featured ? 'rgm-btn-primary' : 'rgm-btn-outline';
                $btn_text = $is_free ? __('Get Started Free', 'rental-gates') : ($plan['cta_text'] ?? __('Get Started', 'rental-gates'));
                $plan_url = $is_free 
                    ? $register_url . '?plan=' . $plan_id 
                    : $register_url . '?plan=' . $plan_id . '&billing=monthly';
                ?>
                <a href="<?php echo esc_url($plan_url); ?>" class="rgm-btn <?php echo $btn_class; ?> rgm-plan-btn"><?php echo esc_html($btn_text); ?></a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_testimonials): ?>
<!-- Testimonials -->
<section class="rgm-section" id="rgm-testimonials" style="background: var(--rgm-bg-alt);">
    <div class="rgm-container">
        <div class="rgm-section-header centered">
            <span class="rgm-section-eyebrow"><?php _e('Testimonials', 'rental-gates'); ?></span>
            <h2 class="rgm-section-title"><?php _e('What our customers say', 'rental-gates'); ?></h2>
        </div>
        
        <div class="rgm-testimonials-grid">
            <div class="rgm-testimonial">
                <div class="rgm-testimonial-quote">"</div>
                <p class="rgm-testimonial-text"><?php _e('Finally, a property management tool that doesn\'t try to do everything. It does exactly what I need, beautifully.', 'rental-gates'); ?></p>
                <div class="rgm-testimonial-author">
                    <div class="rgm-testimonial-avatar">SK</div>
                    <div>
                        <p class="rgm-testimonial-name">Sarah K.</p>
                        <p class="rgm-testimonial-role"><?php _e('Property Manager', 'rental-gates'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="rgm-testimonial">
                <div class="rgm-testimonial-quote">"</div>
                <p class="rgm-testimonial-text"><?php _e('The clean interface makes it easy to train new staff. We were up and running in a day.', 'rental-gates'); ?></p>
                <div class="rgm-testimonial-author">
                    <div class="rgm-testimonial-avatar">MR</div>
                    <div>
                        <p class="rgm-testimonial-name">Michael R.</p>
                        <p class="rgm-testimonial-role"><?php _e('Real Estate Investor', 'rental-gates'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="rgm-testimonial">
                <div class="rgm-testimonial-quote">"</div>
                <p class="rgm-testimonial-text"><?php _e('Our tenants love the simplicity of the portal. Payment collection has never been easier.', 'rental-gates'); ?></p>
                <div class="rgm-testimonial-author">
                    <div class="rgm-testimonial-avatar">JT</div>
                    <div>
                        <p class="rgm-testimonial-name">Jennifer T.</p>
                        <p class="rgm-testimonial-role"><?php _e('HOA President', 'rental-gates'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA -->
<section class="rgm-section rgm-cta">
    <div class="rgm-container">
        <div class="rgm-cta-content">
            <h2 class="rgm-cta-title"><?php _e('Ready to simplify your workflow?', 'rental-gates'); ?></h2>
            <p class="rgm-cta-subtitle"><?php _e('Join property managers who value clarity over complexity.', 'rental-gates'); ?></p>
            <a href="<?php echo esc_url($register_url); ?>" class="rgm-btn rgm-btn-primary rgm-btn-lg"><?php _e('Start Your Free Trial', 'rental-gates'); ?></a>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="rgm-footer">
    <div class="rgm-container">
        <div class="rgm-footer-grid">
            <div class="rgm-footer-brand">
                <div class="rgm-footer-logo"><?php echo esc_html($platform_name); ?></div>
                <p class="rgm-footer-text"><?php _e('Simple, focused property management for professionals who value their time.', 'rental-gates'); ?></p>
            </div>
            <div>
                <h4 class="rgm-footer-heading"><?php _e('Product', 'rental-gates'); ?></h4>
                <ul class="rgm-footer-links">
                    <li><a href="#rgm-features"><?php _e('Features', 'rental-gates'); ?></a></li>
                    <?php if ($show_pricing): ?><li><a href="#rgm-pricing"><?php _e('Pricing', 'rental-gates'); ?></a></li><?php endif; ?>
                    <li><a href="<?php echo home_url('/rental-gates/faq'); ?>"><?php _e('FAQ', 'rental-gates'); ?></a></li>
                </ul>
            </div>
            <div>
                <h4 class="rgm-footer-heading"><?php _e('Company', 'rental-gates'); ?></h4>
                <ul class="rgm-footer-links">
                    <li><a href="<?php echo home_url('/rental-gates/about'); ?>"><?php _e('About', 'rental-gates'); ?></a></li>
                    <li><a href="<?php echo home_url('/rental-gates/contact'); ?>"><?php _e('Contact', 'rental-gates'); ?></a></li>
                </ul>
            </div>
            <div>
                <h4 class="rgm-footer-heading"><?php _e('Legal', 'rental-gates'); ?></h4>
                <ul class="rgm-footer-links">
                    <li><a href="<?php echo esc_url(get_option('rental_gates_privacy_url', '#')); ?>"><?php _e('Privacy', 'rental-gates'); ?></a></li>
                    <li><a href="<?php echo esc_url(get_option('rental_gates_terms_url', '#')); ?>"><?php _e('Terms', 'rental-gates'); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="rgm-footer-bottom">
            <p class="rgm-footer-copy">&copy; <?php echo date('Y'); ?> <?php echo esc_html($platform_name); ?>. <?php _e('All rights reserved.', 'rental-gates'); ?></p>
            <div class="rgm-footer-legal">
                <a href="mailto:<?php echo esc_attr($support_email); ?>"><?php echo esc_html($support_email); ?></a>
            </div>
        </div>
    </div>
</footer>

<script>
(function() {
    const landing = document.getElementById('rgm-landing');
    const header = document.getElementById('rgm-header');
    const themeToggle = document.getElementById('rgm-theme-toggle');
    const mobileBtn = document.getElementById('rgm-mobile-btn');
    const mobileMenu = document.getElementById('rgm-mobile-menu');
    const billingSwitch = document.getElementById('rgm-billing-switch');
    
    // Theme
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('rgm-theme');
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
        landing.classList.add('dark');
    }
    
    themeToggle?.addEventListener('click', () => {
        landing.classList.toggle('dark');
        localStorage.setItem('rgm-theme', landing.classList.contains('dark') ? 'dark' : 'light');
    });
    
    // Header scroll
    window.addEventListener('scroll', () => {
        header.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
    
    // Mobile menu
    if (mobileBtn && mobileMenu) {
        mobileBtn.addEventListener('click', () => {
            const isOpen = mobileMenu.classList.toggle('open');
            mobileBtn.classList.toggle('active', isOpen);
            document.body.style.overflow = isOpen ? 'hidden' : '';
        });
        
        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.remove('open');
                mobileBtn.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }
    
    // Billing toggle
    if (billingSwitch) {
        billingSwitch.addEventListener('click', function() {
            this.classList.toggle('yearly');
            const isYearly = this.classList.contains('yearly');
            const billingPeriod = isYearly ? 'yearly' : 'monthly';
            
            // Update billing labels
            document.querySelectorAll('.rgm-billing-label').forEach(label => {
                label.classList.toggle('active', label.dataset.period === billingPeriod);
            });
            
            // Update price amounts
            document.querySelectorAll('.rgm-pricing-amount').forEach(amount => {
                amount.textContent = isYearly ? amount.dataset.yearly : amount.dataset.monthly;
            });
            
            // Update plan button URLs with billing parameter
            document.querySelectorAll('.rgm-plan-btn').forEach(btn => {
                const url = new URL(btn.href);
                if (url.searchParams.has('billing')) {
                    url.searchParams.set('billing', billingPeriod);
                    btn.href = url.toString();
                }
            });
        });
    }
    
    // Smooth scroll
    document.querySelectorAll('.rgm-landing a[href^="#rgm-"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offset = header.offsetHeight + 20;
                const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
                window.scrollTo({ top, behavior: 'smooth' });
            }
        });
    });
})();
</script>
</div>
