<?php
/**
 * Rental Gates - Landing Page Content
 * Modern, professional design with dark mode & dynamic brand colors
 * Dual-audience design for renters and property managers
 * @version 2.40.0
 */
if (!defined('ABSPATH')) exit;

$platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
$support_email = get_option('rental_gates_support_email', get_option('admin_email'));
$is_logged_in = is_user_logged_in();
$dashboard_url = home_url('/rental-gates/dashboard');
$login_url = home_url('/rental-gates/login');
$register_url = home_url('/rental-gates/register');
$map_url = home_url('/rental-gates/map');

// Section visibility settings
$show_renter_section = get_option('rental_gates_landing_show_renter_section', '1') === '1';
$show_logos = get_option('rental_gates_landing_show_logos', '1') === '1';
$show_features = get_option('rental_gates_landing_show_features', '1') === '1';
$show_steps = get_option('rental_gates_landing_show_steps', '1') === '1';
$show_pricing = get_option('rental_gates_landing_show_pricing', '1') === '1';
$show_testimonials = get_option('rental_gates_landing_show_testimonials', '1') === '1';
$show_cta = get_option('rental_gates_landing_show_cta', '1') === '1';

// Logo settings
$use_site_logo = get_option('rental_gates_landing_use_site_logo', '1') === '1';
$logo_height = intval(get_option('rental_gates_landing_logo_height', 40));
$site_logo_id = get_theme_mod('custom_logo');
$site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'medium') : '';

// Hero content customization
$hero_badge = get_option('rental_gates_landing_hero_badge', '');
$hero_title = get_option('rental_gates_landing_hero_title', '');
$hero_subtitle = get_option('rental_gates_landing_hero_subtitle', '');
$hero_cta_text = get_option('rental_gates_landing_hero_cta_text', '');
$hero_cta_secondary = get_option('rental_gates_landing_hero_cta_secondary', '');
$hero_renter_title = get_option('rental_gates_landing_hero_renter_title', '');
$hero_owner_title = get_option('rental_gates_landing_hero_owner_title', '');
$map_cta_text = get_option('rental_gates_landing_map_cta_text', '');

// Social proof / logos
$logos_title = get_option('rental_gates_landing_logos_title', '');
$logos_list = get_option('rental_gates_landing_logos_list', '');
$logos_array = array_filter(array_map('trim', explode("\n", $logos_list)));

// Social links
$social_twitter = get_option('rental_gates_landing_social_twitter', '');
$social_facebook = get_option('rental_gates_landing_social_facebook', '');
$social_linkedin = get_option('rental_gates_landing_social_linkedin', '');
$social_instagram = get_option('rental_gates_landing_social_instagram', '');

// Get brand color from admin settings
$brand_color = get_option('rental_gates_primary_color', '#0ea5e9');
$brand_rgb = array(
    hexdec(substr($brand_color, 1, 2)),
    hexdec(substr($brand_color, 3, 2)),
    hexdec(substr($brand_color, 5, 2))
);
$brand_rgb_str = implode(', ', $brand_rgb);

// Default content if not customized
if (empty($hero_badge)) $hero_badge = __('Now with AI-Powered Tools', 'rental-gates');
if (empty($hero_title)) $hero_title = __('Find Your Perfect Rental or Manage Your Properties', 'rental-gates');
if (empty($hero_subtitle)) $hero_subtitle = __('Discover available rentals on our interactive map, or streamline your property management with our all-in-one platform.', 'rental-gates');
if (empty($hero_cta_text)) $hero_cta_text = __('Get Started', 'rental-gates');
if (empty($hero_cta_secondary)) $hero_cta_secondary = __('See Features', 'rental-gates');
if (empty($hero_renter_title)) $hero_renter_title = __('I\'m Looking for a Rental', 'rental-gates');
if (empty($hero_owner_title)) $hero_owner_title = __('I Manage Properties', 'rental-gates');
if (empty($map_cta_text)) $map_cta_text = __('Browse Map', 'rental-gates');
if (empty($logos_title)) $logos_title = __('Trusted by property managers worldwide', 'rental-gates');
if (empty($logos_array)) $logos_array = array('Apex Properties', 'Urban Living', 'Prime Rentals', 'Metro Housing', 'Skyline Mgmt');

// Get property count for renter section
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();
$property_count = $wpdb->get_var(
    "SELECT COUNT(DISTINCT b.id) 
     FROM {$tables['buildings']} b
     JOIN {$tables['units']} u ON u.building_id = b.id
     WHERE u.availability IN ('available', 'coming_soon')"
);
$property_count = $property_count ? intval($property_count) : 0;
?>

<div class="rg-landing" id="rg-landing">
<style>
/* CSS Variables & Theme System - Dynamic Brand Color */
.rg-landing {
    /* Brand Colors from Admin Settings */
    --rg-primary: <?php echo esc_attr($brand_color); ?>;
    --rg-primary-rgb: <?php echo $brand_rgb_str; ?>;
    --rg-primary-dark: color-mix(in srgb, var(--rg-primary), #000 15%);
    --rg-primary-light: color-mix(in srgb, var(--rg-primary), #fff 20%);
    --rg-primary-50: rgba(<?php echo $brand_rgb_str; ?>, 0.08);
    --rg-primary-100: rgba(<?php echo $brand_rgb_str; ?>, 0.15);
    --rg-gradient: linear-gradient(135deg, var(--rg-primary) 0%, color-mix(in srgb, var(--rg-primary), #6366f1 40%) 100%);
    --rg-shadow-glow: 0 0 40px rgba(<?php echo $brand_rgb_str; ?>, 0.2);
    
    /* Light Theme */
    --rg-bg: #ffffff;
    --rg-bg-alt: #f8fafc;
    --rg-bg-card: #ffffff;
    --rg-text: #0f172a;
    --rg-text-secondary: #475569;
    --rg-text-muted: #64748b;
    --rg-border: #e2e8f0;
    --rg-border-light: #f1f5f9;
    
    /* Semantic Colors */
    --rg-success: #10b981;
    --rg-warning: #f59e0b;
    --rg-danger: #ef4444;
    
    /* Effects */
    --rg-shadow: 0 4px 6px -1px rgba(0,0,0,0.07), 0 2px 4px -2px rgba(0,0,0,0.05);
    --rg-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -4px rgba(0,0,0,0.04);
    --rg-shadow-xl: 0 25px 50px -12px rgba(0,0,0,0.15);
    
    /* Layout */
    --rg-radius: 12px;
    --rg-radius-lg: 16px;
    --rg-radius-xl: 24px;
    --rg-radius-full: 9999px;
    --rg-header-h: 80px;
    --rg-container: 1200px;
    --rg-section-py: 100px;
    
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 16px;
    line-height: 1.6;
    color: var(--rg-text);
    background: var(--rg-bg);
    -webkit-font-smoothing: antialiased;
}

.rg-landing.dark {
    --rg-bg: #0a0f1a;
    --rg-bg-alt: #111827;
    --rg-bg-card: #1f2937;
    --rg-text: #f9fafb;
    --rg-text-secondary: #e5e7eb;
    --rg-text-muted: #d1d5db;
    --rg-border: #374151;
    --rg-border-light: #1f2937;
    --rg-primary-50: rgba(<?php echo $brand_rgb_str; ?>, 0.2);
    --rg-shadow: 0 4px 6px -1px rgba(0,0,0,0.4);
    --rg-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.5);
}

.rg-landing *, .rg-landing *::before, .rg-landing *::after { box-sizing: border-box; margin: 0; padding: 0; }
.rg-landing img { max-width: 100%; height: auto; }
.rg-landing a { color: inherit; text-decoration: none; transition: color 0.2s; }
.rg-landing button { font-family: inherit; cursor: pointer; border: none; background: none; }
.rg-container { width: 100%; max-width: var(--rg-container); margin: 0 auto; padding: 0 24px; }
.rg-section { padding: var(--rg-section-py) 0; }

/* ============================================
   Modern Header - Centered Alignment
   ============================================ */
.rg-header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: var(--rg-header-h);
    z-index: 1000;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.rg-header > .rg-container {
    height: 100%;
}

.rg-header::before {
    content: '';
    position: absolute;
    inset: 0;
    background: var(--rg-bg);
    opacity: 0;
    transition: opacity 0.3s;
    border-bottom: 1px solid transparent;
}

.rg-header.scrolled::before {
    opacity: 0.95;
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-bottom-color: var(--rg-border);
}

.rg-header.scrolled {
    box-shadow: var(--rg-shadow);
}

.rg-header-inner {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    gap: 32px;
}

/* Logo */
.rg-logo {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 20px;
    font-weight: 800;
    color: var(--rg-text);
    letter-spacing: -0.02em;
    flex-shrink: 0;
}

.rg-logo-mark {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    background: var(--rg-gradient);
    border-radius: 12px;
    color: white;
    box-shadow: 0 4px 12px rgba(var(--rg-primary-rgb), 0.3);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.rg-logo:hover .rg-logo-mark {
    transform: scale(1.05) rotate(-3deg);
    box-shadow: 0 6px 18px rgba(var(--rg-primary-rgb), 0.4);
}

.rg-logo-mark svg { width: 22px; height: 22px; }

/* Navigation - Pill Style */
.rg-nav {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 5px;
    background: var(--rg-bg-alt);
    border: 1px solid var(--rg-border-light);
    border-radius: var(--rg-radius-full);
}

.rg-nav-link {
    padding: 8px 18px;
    font-size: 14px;
    font-weight: 600;
    color: var(--rg-text-secondary);
    border-radius: var(--rg-radius-full);
    transition: all 0.2s;
}

.rg-nav-link:hover { color: var(--rg-text); }

.rg-nav-link.active {
    color: var(--rg-text);
    background: var(--rg-bg);
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}

/* Header Actions */
.rg-header-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
}

/* Theme Toggle - Compact */
.rg-theme-toggle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: var(--rg-bg-alt);
    border: 1px solid var(--rg-border);
    border-radius: var(--rg-radius);
    color: var(--rg-text-secondary);
    transition: all 0.2s;
}

.rg-theme-toggle:hover {
    color: var(--rg-primary);
    border-color: var(--rg-primary);
    background: var(--rg-primary-50);
}

.rg-theme-toggle svg { width: 18px; height: 18px; }
.rg-theme-toggle .sun { display: none; }
.dark .rg-theme-toggle .sun { display: block; }
.dark .rg-theme-toggle .moon { display: none; }

/* Mobile Menu Toggle */
.rg-mobile-btn {
    display: none;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: var(--rg-bg-alt);
    border: 1px solid var(--rg-border);
    border-radius: var(--rg-radius);
    color: var(--rg-text);
    transition: all 0.2s;
}

.rg-mobile-btn:hover {
    background: var(--rg-primary-50);
    border-color: var(--rg-primary);
    color: var(--rg-primary);
}

.rg-mobile-btn svg { width: 20px; height: 20px; }
.rg-mobile-btn .icon-close { display: none; }
.rg-mobile-btn.active .icon-menu { display: none; }
.rg-mobile-btn.active .icon-close { display: block; }

/* Mobile Menu - Full Screen Overlay */
.rg-mobile-menu {
    display: none;
    position: fixed;
    top: var(--rg-header-h);
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--rg-bg);
    padding: 24px;
    z-index: 999;
    overflow-y: auto;
    transform: translateY(-20px);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.rg-mobile-menu.open {
    transform: translateY(0);
    opacity: 1;
    visibility: visible;
}

.rg-mobile-nav {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.rg-mobile-nav-link {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 20px;
    font-size: 16px;
    font-weight: 600;
    color: var(--rg-text);
    background: var(--rg-bg-alt);
    border-radius: var(--rg-radius);
    transition: all 0.2s;
}

.rg-mobile-nav-link:hover,
.rg-mobile-nav-link:active {
    background: var(--rg-primary-50);
    color: var(--rg-primary);
}

.rg-mobile-nav-link svg {
    width: 20px;
    height: 20px;
    color: var(--rg-text-muted);
}

.rg-mobile-nav-link:hover svg { color: var(--rg-primary); }

.rg-mobile-divider {
    height: 1px;
    background: var(--rg-border);
    margin: 20px 0;
}

.rg-mobile-actions {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.rg-mobile-actions .rg-btn {
    width: 100%;
    justify-content: center;
    padding: 18px 24px;
    font-size: 16px;
}

.rg-mobile-theme {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 20px;
    background: var(--rg-bg-alt);
    border-radius: var(--rg-radius);
    margin-top: 20px;
}

.rg-mobile-theme span {
    font-size: 14px;
    font-weight: 500;
    color: var(--rg-text-muted);
}

/* Buttons */
.rg-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    font-family: inherit;
    font-size: 14px;
    font-weight: 600;
    border-radius: var(--rg-radius);
    border: none;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    white-space: nowrap;
}

.rg-btn svg { width: 18px; height: 18px; transition: transform 0.2s; }

.rg-btn-primary {
    background: var(--rg-gradient);
    color: white;
    box-shadow: 0 2px 8px rgba(var(--rg-primary-rgb), 0.35), inset 0 1px 0 rgba(255,255,255,0.15);
}

.rg-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(var(--rg-primary-rgb), 0.4), inset 0 1px 0 rgba(255,255,255,0.15);
}

.rg-btn-primary:hover svg { transform: translateX(4px); }
.rg-btn-primary:active { transform: translateY(0); }

.rg-btn-secondary {
    background: var(--rg-bg);
    color: var(--rg-text);
    border: 1px solid var(--rg-border);
    box-shadow: var(--rg-shadow);
}

.rg-btn-secondary:hover {
    border-color: var(--rg-primary);
    box-shadow: 0 0 0 3px var(--rg-primary-50);
}

.rg-btn-ghost {
    background: transparent;
    color: var(--rg-text-secondary);
    padding: 10px 16px;
}

.rg-btn-ghost:hover {
    color: var(--rg-text);
    background: var(--rg-bg-alt);
}

.rg-btn-lg { padding: 14px 28px; font-size: 15px; border-radius: var(--rg-radius-lg); }
.rg-btn-sm { padding: 8px 16px; font-size: 13px; }

/* Hero */
.rg-hero { padding: calc(var(--rg-header-h) + 60px) 0 80px; background: linear-gradient(180deg, var(--rg-primary-50) 0%, var(--rg-bg) 100%); position: relative; overflow: hidden; }
.rg-hero::before { content: ''; position: absolute; inset: 0; background-image: radial-gradient(circle at 20% 30%, rgba(14,165,233,0.08) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(99,102,241,0.06) 0%, transparent 40%); pointer-events: none; }
.rg-hero-grid { position: absolute; inset: 0; background-image: linear-gradient(var(--rg-border) 1px, transparent 1px), linear-gradient(90deg, var(--rg-border) 1px, transparent 1px); background-size: 60px 60px; opacity: 0.3; mask-image: linear-gradient(180deg, transparent, rgba(0,0,0,0.5) 20%, rgba(0,0,0,0.5) 80%, transparent); }
.dark .rg-hero-grid { opacity: 0.15; }
.rg-hero-content { position: relative; z-index: 1; max-width: 800px; margin: 0 auto; text-align: center; }

.rg-hero-badge { display: inline-flex; align-items: center; gap: 10px; padding: 8px 18px; background: var(--rg-bg-card); border: 1px solid var(--rg-border); border-radius: var(--rg-radius-full); font-size: 14px; font-weight: 500; color: var(--rg-text-secondary); margin-bottom: 32px; box-shadow: var(--rg-shadow); animation: fadeUp 0.6s ease; }
.rg-hero-badge-dot { width: 8px; height: 8px; background: var(--rg-success); border-radius: 50%; animation: pulse 2s ease infinite; }
@keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.6; transform: scale(1.2); } }
@keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

.rg-hero-title { font-size: clamp(40px, 6vw, 64px); font-weight: 800; line-height: 1.1; color: var(--rg-text); margin: 0 0 24px 0; letter-spacing: -0.02em; animation: fadeUp 0.6s ease 0.1s both; }
.rg-hero-title-gradient { background: var(--rg-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.rg-hero-subtitle { font-size: 18px; line-height: 1.7; color: var(--rg-text-secondary); margin: 0 auto 40px; max-width: 600px; animation: fadeUp 0.6s ease 0.2s both; }
.rg-hero-actions { display: flex; align-items: center; justify-content: center; gap: 16px; flex-wrap: wrap; margin-bottom: 32px; animation: fadeUp 0.6s ease 0.3s both; }
.rg-hero-note { display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 14px; color: var(--rg-text-muted); animation: fadeUp 0.6s ease 0.4s both; }
.rg-hero-note svg { width: 16px; height: 16px; color: var(--rg-success); }

.rg-hero-stats { display: flex; align-items: center; justify-content: center; gap: 48px; margin-top: 64px; padding-top: 48px; border-top: 1px solid var(--rg-border); animation: fadeUp 0.6s ease 0.5s both; }
.rg-hero-stat { text-align: center; }
.rg-hero-stat-value { font-size: 32px; font-weight: 800; color: var(--rg-text); line-height: 1; margin-bottom: 8px; }
.rg-hero-stat-label { font-size: 14px; color: var(--rg-text-muted); }

/* Dual-Audience Hero */
.rg-hero-dual { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; max-width: 1000px; margin: 0 auto; }
.rg-hero-card { background: var(--rg-bg-card); border: 2px solid var(--rg-border); border-radius: var(--rg-radius-xl); padding: 40px; text-align: center; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; overflow: hidden; }
.rg-hero-card::before { content: ''; position: absolute; inset: 0; background: var(--rg-gradient); opacity: 0; transition: opacity 0.3s; }
.rg-hero-card:hover { transform: translateY(-8px); box-shadow: var(--rg-shadow-xl); border-color: var(--rg-primary); }
.rg-hero-card:hover::before { opacity: 0.05; }
.rg-hero-card-renter { border-color: color-mix(in srgb, var(--rg-primary), #10b981 30%); }
.rg-hero-card-renter:hover { border-color: #10b981; }
.rg-hero-card-owner { border-color: var(--rg-primary); }
.rg-hero-card-icon { display: flex; align-items: center; justify-content: center; width: 64px; height: 64px; background: var(--rg-primary-50); border-radius: var(--rg-radius-lg); margin: 0 auto 24px; color: var(--rg-primary); position: relative; z-index: 1; }
.rg-hero-card-renter .rg-hero-card-icon { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.rg-hero-card-icon svg { width: 32px; height: 32px; }
.rg-hero-card-title { font-size: 24px; font-weight: 700; color: var(--rg-text); margin: 0 0 16px 0; position: relative; z-index: 1; }
.rg-hero-card-description { font-size: 15px; color: var(--rg-text-secondary); line-height: 1.6; margin: 0 0 24px 0; position: relative; z-index: 1; }
.rg-hero-card-actions { display: flex; flex-direction: column; gap: 12px; position: relative; z-index: 1; }
.rg-hero-card-actions .rg-btn { width: 100%; justify-content: center; }

/* Logos */
/* Logos Section - Improved Contrast */
.rg-logos { padding: 48px 0; background: var(--rg-bg-alt); border-bottom: 1px solid var(--rg-border); }
.rg-logos-title { text-align: center; font-size: 12px; font-weight: 700; color: var(--rg-text-secondary); text-transform: uppercase; letter-spacing: 1.5px; margin: 0 0 24px 0; }
.rg-logos-grid { display: flex; align-items: center; justify-content: center; gap: 48px; flex-wrap: wrap; }
.rg-logo-item { font-size: 17px; font-weight: 700; color: var(--rg-text-secondary); }

/* Section Headers */
.rg-section-header { text-align: center; max-width: 640px; margin: 0 auto 64px; }
.rg-section-badge { display: inline-flex; padding: 6px 14px; background: var(--rg-primary); color: white; border-radius: var(--rg-radius-full); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 20px; }
.rg-section-title { font-size: clamp(28px, 4vw, 42px); font-weight: 800; color: var(--rg-text); margin: 0 0 16px 0; letter-spacing: -0.02em; }
.rg-section-subtitle { font-size: 17px; color: var(--rg-text-secondary); line-height: 1.7; margin: 0; }

/* Features */
.rg-features { background: var(--rg-bg); }
.rg-features-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.rg-feature-card { background: var(--rg-bg-card); border: 1px solid var(--rg-border); border-radius: var(--rg-radius-lg); padding: 32px; transition: 0.2s; }
.rg-feature-card:hover { transform: translateY(-4px); box-shadow: var(--rg-shadow-lg); border-color: var(--rg-primary); }
.rg-feature-icon { display: flex; align-items: center; justify-content: center; width: 56px; height: 56px; background: var(--rg-primary-50); border-radius: var(--rg-radius-lg); color: var(--rg-primary); margin-bottom: 20px; }
.rg-feature-icon svg { width: 28px; height: 28px; }
.rg-feature-title { font-size: 18px; font-weight: 700; color: var(--rg-text); margin: 0 0 12px 0; }
.rg-feature-description { font-size: 15px; color: var(--rg-text-secondary); line-height: 1.6; margin: 0; }

/* How It Works */
.rg-steps-section { background: var(--rg-bg-alt); }
.rg-steps { display: grid; grid-template-columns: repeat(4, 1fr); gap: 32px; position: relative; }
.rg-steps::before { content: ''; position: absolute; top: 40px; left: 80px; right: 80px; height: 2px; background: var(--rg-primary); opacity: 0.3; }
.rg-step { text-align: center; position: relative; }
.rg-step-number { display: flex; align-items: center; justify-content: center; width: 80px; height: 80px; background: var(--rg-bg-card); border: 2px solid var(--rg-primary); border-radius: 50%; font-size: 28px; font-weight: 800; color: var(--rg-primary); margin: 0 auto 24px; position: relative; z-index: 1; }
.rg-step-title { font-size: 18px; font-weight: 700; color: var(--rg-text); margin: 0 0 12px 0; }
.rg-step-description { font-size: 15px; color: var(--rg-text-secondary); line-height: 1.6; margin: 0; }

/* Pricing */
.rg-pricing { background: var(--rg-bg); }
.rg-billing-toggle { display: flex; align-items: center; justify-content: center; gap: 16px; margin-bottom: 48px; }
.rg-billing-label { font-size: 15px; font-weight: 600; color: var(--rg-text-muted); transition: 0.2s; cursor: pointer; }
.rg-billing-label.active { color: var(--rg-text); }
.rg-billing-switch { position: relative; width: 56px; height: 32px; background: var(--rg-border); border-radius: var(--rg-radius-full); cursor: pointer; transition: 0.2s; }
.rg-billing-switch.yearly { background: var(--rg-primary); }
.rg-billing-switch::after { content: ''; position: absolute; top: 4px; left: 4px; width: 24px; height: 24px; background: white; border-radius: 50%; box-shadow: var(--rg-shadow); transition: 0.2s; }
.rg-billing-switch.yearly::after { transform: translateX(24px); }
.rg-billing-save { display: inline-flex; padding: 4px 12px; background: var(--rg-success); color: white; border-radius: var(--rg-radius-full); font-size: 12px; font-weight: 700; }

.rg-pricing-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; max-width: 1100px; margin: 0 auto; }
.rg-pricing-grid-4 { grid-template-columns: repeat(4, 1fr); max-width: 1200px; }
.rg-pricing-card { background: var(--rg-bg-card); border: 1px solid var(--rg-border); border-radius: var(--rg-radius-lg); padding: 32px; position: relative; transition: 0.2s; display: flex; flex-direction: column; }
.rg-pricing-card:hover { transform: translateY(-4px); box-shadow: var(--rg-shadow-lg); }
.rg-pricing-card.featured { border-color: var(--rg-primary); transform: scale(1.02); z-index: 1; }
.rg-pricing-card.featured:hover { transform: scale(1.02) translateY(-4px); }
.rg-pricing-badge { position: absolute; top: -12px; left: 50%; transform: translateX(-50%); padding: 6px 16px; background: var(--rg-gradient); color: white; border-radius: var(--rg-radius-full); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap; }
.rg-pricing-name { font-size: 20px; font-weight: 700; color: var(--rg-text); margin: 0 0 8px 0; }
.rg-pricing-description { font-size: 14px; color: var(--rg-text-muted); margin: 0 0 24px 0; }
.rg-pricing-price { display: flex; align-items: baseline; gap: 4px; margin-bottom: 24px; }
.rg-pricing-currency { font-size: 24px; font-weight: 700; color: var(--rg-text); }
.rg-pricing-amount { font-size: 48px; font-weight: 800; color: var(--rg-text); line-height: 1; }
.rg-pricing-period { font-size: 16px; color: var(--rg-text-muted); margin-left: 4px; }
.rg-pricing-features { display: flex; flex-direction: column; gap: 12px; margin-bottom: 32px; flex-grow: 1; }
.rg-pricing-feature { display: flex; align-items: center; gap: 12px; font-size: 14px; color: var(--rg-text-secondary); }
.rg-pricing-feature svg { width: 18px; height: 18px; color: var(--rg-success); flex-shrink: 0; }
.rg-pricing-feature-disabled { color: var(--rg-text-muted); opacity: 0.6; }
.rg-pricing-feature-disabled svg { color: var(--rg-text-muted); }
.rg-pricing-card .rg-btn { width: 100%; margin-top: auto; }

/* Testimonials */
.rg-testimonials { background: var(--rg-bg-alt); }
.rg-testimonials-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.rg-testimonial-card { background: var(--rg-bg-card); border: 1px solid var(--rg-border); border-radius: var(--rg-radius-lg); padding: 32px; transition: 0.2s; }
.rg-testimonial-card:hover { transform: translateY(-4px); box-shadow: var(--rg-shadow-lg); }
.rg-testimonial-stars { display: flex; gap: 4px; margin-bottom: 20px; color: var(--rg-warning); }
.rg-testimonial-stars svg { width: 18px; height: 18px; }
.rg-testimonial-text { font-size: 15px; color: var(--rg-text-secondary); line-height: 1.7; margin: 0 0 24px 0; }
.rg-testimonial-author { display: flex; align-items: center; gap: 12px; }
.rg-testimonial-avatar { width: 48px; height: 48px; background: var(--rg-gradient); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 16px; }
.rg-testimonial-name { font-size: 15px; font-weight: 700; color: var(--rg-text); margin: 0; }
.rg-testimonial-role { font-size: 13px; color: var(--rg-text-muted); margin: 4px 0 0 0; }

/* CTA */
.rg-cta { background: var(--rg-bg); position: relative; overflow: hidden; }
.rg-cta::before { content: ''; position: absolute; inset: 0; background: var(--rg-gradient); opacity: 0.05; }
.rg-cta-content { position: relative; z-index: 1; text-align: center; max-width: 640px; margin: 0 auto; }
.rg-cta-title { font-size: clamp(28px, 4vw, 40px); font-weight: 800; color: var(--rg-text); margin: 0 0 16px 0; letter-spacing: -0.02em; }
.rg-cta-subtitle { font-size: 17px; color: var(--rg-text-secondary); line-height: 1.7; margin: 0 0 32px 0; }

/* Dual CTA Cards */
.rg-cta-dual { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; max-width: 900px; margin: 0 auto; }
.rg-cta-card { background: var(--rg-bg-card); border: 2px solid var(--rg-border); border-radius: var(--rg-radius-xl); padding: 40px; text-align: center; transition: all 0.3s; position: relative; overflow: hidden; }
.rg-cta-card::before { content: ''; position: absolute; inset: 0; background: var(--rg-gradient); opacity: 0; transition: opacity 0.3s; }
.rg-cta-card:hover { transform: translateY(-4px); box-shadow: var(--rg-shadow-xl); border-color: var(--rg-primary); }
.rg-cta-card:hover::before { opacity: 0.05; }
.rg-cta-card-renter { border-color: color-mix(in srgb, var(--rg-primary), #10b981 30%); }
.rg-cta-card-renter:hover { border-color: #10b981; }
.rg-cta-card-owner { border-color: var(--rg-primary); }
.rg-cta-card-icon { display: flex; align-items: center; justify-content: center; width: 56px; height: 56px; background: var(--rg-primary-50); border-radius: var(--rg-radius-lg); margin: 0 auto 20px; color: var(--rg-primary); position: relative; z-index: 1; }
.rg-cta-card-renter .rg-cta-card-icon { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.rg-cta-card-icon svg { width: 28px; height: 28px; }
.rg-cta-card-title { font-size: 22px; font-weight: 700; color: var(--rg-text); margin: 0 0 12px 0; position: relative; z-index: 1; }
.rg-cta-card-description { font-size: 14px; color: var(--rg-text-secondary); line-height: 1.6; margin: 0 0 24px 0; position: relative; z-index: 1; }
.rg-cta-card .rg-btn { position: relative; z-index: 1; }

/* Footer */
.rg-footer { background: var(--rg-bg-alt); border-top: 1px solid var(--rg-border); padding: 64px 0 32px; }
.rg-footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 48px; margin-bottom: 48px; }
.rg-footer-brand { max-width: 280px; }
.rg-footer-logo { display: flex; align-items: center; gap: 10px; font-size: 18px; font-weight: 700; color: var(--rg-text); margin-bottom: 16px; }
.rg-footer-logo-icon { display: flex; align-items: center; justify-content: center; width: 32px; height: 32px; background: var(--rg-gradient); border-radius: 8px; color: white; }
.rg-footer-logo-icon svg { width: 18px; height: 18px; }
.rg-footer-description { font-size: 14px; color: var(--rg-text-muted); line-height: 1.6; margin: 0 0 20px 0; }
.rg-footer-social { display: flex; gap: 12px; }
.rg-footer-social a { display: flex; align-items: center; justify-content: center; width: 36px; height: 36px; background: var(--rg-border); border-radius: var(--rg-radius); color: var(--rg-text-muted); transition: 0.2s; }
.rg-footer-social a:hover { background: var(--rg-primary); color: white; }
.rg-footer-social svg { width: 16px; height: 16px; }
.rg-footer-heading { font-size: 14px; font-weight: 700; color: var(--rg-text); text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 20px 0; }
.rg-footer-links { list-style: none; margin: 0; padding: 0; }
.rg-footer-links li { margin-bottom: 12px; }
.rg-footer-links a { font-size: 14px; color: var(--rg-text-muted); transition: 0.2s; }
.rg-footer-links a:hover { color: var(--rg-primary); }
.rg-footer-bottom { display: flex; align-items: center; justify-content: space-between; padding-top: 32px; border-top: 1px solid var(--rg-border); }
.rg-footer-copy { font-size: 14px; color: var(--rg-text-muted); margin: 0; }
.rg-footer-legal { display: flex; gap: 24px; }
.rg-footer-legal a { font-size: 14px; color: var(--rg-text-muted); transition: 0.2s; }
.rg-footer-legal a:hover { color: var(--rg-primary); }

/* Responsive */
@media (max-width: 1200px) {
    .rg-pricing-grid-4 { grid-template-columns: repeat(2, 1fr); max-width: 800px; }
    .rg-pricing-card.featured { transform: none; }
}

@media (max-width: 1024px) {
    .rg-features-grid, .rg-testimonials-grid { grid-template-columns: repeat(2, 1fr); }
    .rg-pricing-grid { grid-template-columns: 1fr; max-width: 420px; }
    .rg-pricing-grid-4 { grid-template-columns: 1fr; max-width: 420px; }
    .rg-pricing-card.featured { transform: none; order: -1; }
    .rg-steps { grid-template-columns: repeat(2, 1fr); }
    .rg-steps::before { display: none; }
    .rg-footer-grid { grid-template-columns: 1fr 1fr; }
    .rg-logos-grid { gap: 32px; }
}

@media (max-width: 768px) {
    .rg-landing { --rg-section-py: 64px; --rg-header-h: 64px; }
    .rg-nav { display: none; }
    .rg-mobile-btn { display: flex; }
    .rg-mobile-menu { display: block; }
    
    /* Hide desktop-only auth buttons on mobile */
    .rg-header-actions .rg-btn-ghost,
    .rg-header-actions .rg-btn-primary:not(.rg-btn-sm) { display: none; }
    
    .rg-logo-mark { width: 38px; height: 38px; border-radius: 10px; }
    .rg-logo-mark svg { width: 20px; height: 20px; }
    .rg-logo { font-size: 18px; gap: 10px; }
    
    .rg-hero { padding: calc(var(--rg-header-h) + 48px) 0 64px; }
    .rg-hero-dual { grid-template-columns: 1fr; gap: 24px; }
    .rg-hero-card { padding: 32px 24px; }
    .rg-hero-actions { flex-direction: column; }
    .rg-hero-actions .rg-btn { width: 100%; max-width: 320px; }
    .rg-hero-stats { gap: 32px; flex-wrap: wrap; }
    .rg-hero-stat-value { font-size: 28px; }
    .rg-features-grid, .rg-testimonials-grid, .rg-steps { grid-template-columns: 1fr; }
    .rg-cta-dual { grid-template-columns: 1fr; }
    .rg-cta-card { padding: 32px 24px; }
    .rg-footer-grid { grid-template-columns: 1fr; gap: 32px; }
    .rg-footer-brand { max-width: none; }
    .rg-footer-bottom { flex-direction: column; gap: 16px; text-align: center; }
    .rg-billing-toggle { flex-wrap: wrap; justify-content: center; }
    .rg-logos-grid { gap: 24px; }
    .rg-logo-item { font-size: 15px; }
    
    .rg-pricing-amount { font-size: 40px; }
}

@media (max-width: 480px) {
    .rg-container { padding: 0 16px; }
    .rg-landing { --rg-header-h: 60px; }
    
    .rg-logo { font-size: 16px; gap: 8px; }
    .rg-logo-mark { width: 36px; height: 36px; border-radius: 10px; }
    .rg-logo-mark svg { width: 18px; height: 18px; }
    
    .rg-theme-toggle, .rg-mobile-btn { width: 36px; height: 36px; }
    .rg-theme-toggle svg, .rg-mobile-btn svg { width: 16px; height: 16px; }
    
    .rg-hero-badge { font-size: 11px; padding: 5px 10px; }
    .rg-hero-title { font-size: 32px; }
    
    .rg-pricing-amount { font-size: 40px; }
    .rg-feature-card, .rg-testimonial-card, .rg-pricing-card { padding: 24px; }
    
    .rg-mobile-nav-link { padding: 14px 16px; font-size: 15px; }
    .rg-logos-grid { gap: 16px; }
    .rg-logo-item { font-size: 14px; }
}

/* Floating Action Button for Mobile */
.rg-fab {
    position: fixed;
    bottom: 24px;
    right: 24px;
    width: 64px;
    height: 64px;
    background: var(--rg-gradient);
    border-radius: 50%;
    display: none;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: 0 8px 24px rgba(var(--rg-primary-rgb), 0.4);
    z-index: 999;
    transition: all 0.3s;
    text-decoration: none;
}

.rg-fab:hover {
    transform: scale(1.1);
    box-shadow: 0 12px 32px rgba(var(--rg-primary-rgb), 0.5);
}

.rg-fab svg {
    width: 28px;
    height: 28px;
}

@media (max-width: 768px) {
    .rg-fab {
        display: flex;
    }
}
</style>

<!-- Header -->
<header class="rg-header" id="rg-header">
    <div class="rg-container">
        <div class="rg-header-inner">
            <a href="<?php echo home_url('/rental-gates'); ?>" class="rg-logo">
                <?php if ($use_site_logo && $site_logo_url): ?>
                <img src="<?php echo esc_url($site_logo_url); ?>" alt="<?php echo esc_attr($platform_name); ?>" class="rg-logo-img" style="height: <?php echo $logo_height; ?>px; width: auto;" loading="eager" width="auto" height="<?php echo $logo_height; ?>">
                <?php else: ?>
                <div class="rg-logo-mark">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                </div>
                <span><?php echo esc_html($platform_name); ?></span>
                <?php endif; ?>
            </a>
            
            <nav class="rg-nav">
                <a href="<?php echo esc_url($map_url); ?>" class="rg-nav-link" aria-label="<?php esc_attr_e('Browse available properties', 'rental-gates'); ?>">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="margin-right: 4px; vertical-align: middle;">
                        <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
                    </svg>
                    <?php _e('Browse Properties', 'rental-gates'); ?>
                </a>
                <?php if ($show_features): ?><a href="#rg-features" class="rg-nav-link"><?php _e('Features', 'rental-gates'); ?></a><?php endif; ?>
                <?php if ($show_pricing): ?><a href="#rg-pricing" class="rg-nav-link"><?php _e('Pricing', 'rental-gates'); ?></a><?php endif; ?>
                <?php if ($show_testimonials): ?><a href="#rg-testimonials" class="rg-nav-link"><?php _e('Reviews', 'rental-gates'); ?></a><?php endif; ?>
                <a href="mailto:<?php echo esc_attr($support_email); ?>" class="rg-nav-link"><?php _e('Contact', 'rental-gates'); ?></a>
            </nav>
            
            <div class="rg-header-actions">
                <button type="button" class="rg-theme-toggle" id="rg-theme-toggle" aria-label="<?php esc_attr_e('Toggle dark mode', 'rental-gates'); ?>">
                    <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                    <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                </button>
                
                <?php if ($is_logged_in): ?>
                <a href="<?php echo esc_url($dashboard_url); ?>" class="rg-btn rg-btn-primary rg-btn-sm"><?php _e('Dashboard', 'rental-gates'); ?></a>
                <?php else: ?>
                <a href="<?php echo esc_url($login_url); ?>" class="rg-btn rg-btn-ghost"><?php _e('Sign In', 'rental-gates'); ?></a>
                <a href="<?php echo esc_url($register_url); ?>" class="rg-btn rg-btn-primary rg-btn-sm"><?php _e('Get Started', 'rental-gates'); ?></a>
                <?php endif; ?>
                
                <button type="button" class="rg-mobile-btn" id="rg-mobile-btn" aria-label="<?php esc_attr_e('Toggle menu', 'rental-gates'); ?>">
                    <svg class="icon-menu" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
                    <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
            </div>
        </div>
    </div>
</header>

<!-- Mobile Menu -->
<div class="rg-mobile-menu" id="rg-mobile-menu">
    <nav class="rg-mobile-nav">
        <a href="<?php echo esc_url($map_url); ?>" class="rg-mobile-nav-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
            <?php _e('Browse Properties', 'rental-gates'); ?>
        </a>
        <a href="#rg-features" class="rg-mobile-nav-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            <?php _e('Features', 'rental-gates'); ?>
        </a>
        <?php if ($show_pricing): ?>
        <a href="#rg-pricing" class="rg-mobile-nav-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            <?php _e('Pricing', 'rental-gates'); ?>
        </a>
        <?php endif; ?>
        <?php if ($show_testimonials): ?>
        <a href="#rg-testimonials" class="rg-mobile-nav-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <?php _e('Reviews', 'rental-gates'); ?>
        </a>
        <?php endif; ?>
        <a href="mailto:<?php echo esc_attr($support_email); ?>" class="rg-mobile-nav-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            <?php _e('Contact', 'rental-gates'); ?>
        </a>
    </nav>
    
    <div class="rg-mobile-divider"></div>
    
    <div class="rg-mobile-actions">
        <?php if ($is_logged_in): ?>
        <a href="<?php echo esc_url($dashboard_url); ?>" class="rg-btn rg-btn-primary"><?php _e('Go to Dashboard', 'rental-gates'); ?></a>
        <?php else: ?>
        <a href="<?php echo esc_url($register_url); ?>" class="rg-btn rg-btn-primary"><?php _e('Get Started', 'rental-gates'); ?></a>
        <a href="<?php echo esc_url($login_url); ?>" class="rg-btn rg-btn-secondary"><?php _e('Sign In', 'rental-gates'); ?></a>
        <?php endif; ?>
    </div>
    
    <div class="rg-mobile-theme">
        <span><?php _e('Theme', 'rental-gates'); ?></span>
        <button type="button" class="rg-theme-toggle" id="rg-theme-toggle-mobile" aria-label="<?php esc_attr_e('Toggle dark mode', 'rental-gates'); ?>">
            <svg class="moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            <svg class="sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
        </button>
    </div>
</div>

<!-- Hero -->
<section class="rg-hero">
    <div class="rg-hero-grid"></div>
    <div class="rg-container">
        <div class="rg-hero-content">
            <div class="rg-hero-badge"><span class="rg-hero-badge-dot"></span><?php echo esc_html($hero_badge); ?></div>
            <h1 class="rg-hero-title"><?php echo esc_html($hero_title); ?></h1>
            <p class="rg-hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
            
            <!-- Dual-Audience Cards -->
            <div class="rg-hero-dual">
                <!-- Renter Card -->
                <div class="rg-hero-card rg-hero-card-renter">
                    <div class="rg-hero-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
                        </svg>
                    </div>
                    <h2 class="rg-hero-card-title"><?php echo esc_html($hero_renter_title); ?></h2>
                    <p class="rg-hero-card-description"><?php _e('Discover available rentals on our interactive map. Filter by price, location, amenities, and more.', 'rental-gates'); ?></p>
                    <div class="rg-hero-card-actions">
                        <a href="<?php echo esc_url($map_url); ?>" class="rg-btn rg-btn-primary" aria-label="<?php esc_attr_e('Browse available properties on map', 'rental-gates'); ?>">
                            <?php echo esc_html($map_cta_text); ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                        </a>
                        <a href="<?php echo esc_url($map_url); ?>" class="rg-btn rg-btn-ghost"><?php _e('Find Rentals', 'rental-gates'); ?></a>
                    </div>
                </div>
                
                <!-- Owner Card -->
                <div class="rg-hero-card rg-hero-card-owner">
                    <div class="rg-hero-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                        </svg>
                    </div>
                    <h2 class="rg-hero-card-title"><?php echo esc_html($hero_owner_title); ?></h2>
                    <p class="rg-hero-card-description"><?php _e('Streamline operations with our all-in-one platform for buildings, tenants, leases, and payments.', 'rental-gates'); ?></p>
                    <div class="rg-hero-card-actions">
                        <a href="<?php echo esc_url($register_url); ?>" class="rg-btn rg-btn-primary" aria-label="<?php esc_attr_e('Start managing properties', 'rental-gates'); ?>">
                            <?php echo esc_html($hero_cta_text); ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                        </a>
                        <a href="#rg-features" class="rg-btn rg-btn-ghost"><?php echo esc_html($hero_cta_secondary); ?></a>
                    </div>
                </div>
            </div>
            
            <p class="rg-hero-note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('14-day free trial • No credit card required', 'rental-gates'); ?></p>
            <div class="rg-hero-stats">
                <div class="rg-hero-stat"><div class="rg-hero-stat-value"><?php echo number_format($property_count); ?>+</div><div class="rg-hero-stat-label"><?php _e('Properties', 'rental-gates'); ?></div></div>
                <div class="rg-hero-stat"><div class="rg-hero-stat-value">99.9%</div><div class="rg-hero-stat-label"><?php _e('Uptime', 'rental-gates'); ?></div></div>
                <div class="rg-hero-stat"><div class="rg-hero-stat-value">4.9/5</div><div class="rg-hero-stat-label"><?php _e('Rating', 'rental-gates'); ?></div></div>
            </div>
        </div>
    </div>
</section>

<?php if ($show_logos): ?>
<!-- Logos -->
<section class="rg-logos">
    <div class="rg-container">
        <p class="rg-logos-title"><?php echo esc_html($logos_title); ?></p>
        <div class="rg-logos-grid">
            <?php foreach ($logos_array as $logo_name): ?>
            <span class="rg-logo-item"><?php echo esc_html($logo_name); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_renter_section): ?>
<!-- Renter-Focused Section: Discover Your Next Home -->
<section class="rg-renter-section rg-section" id="rg-renter-section">
    <div class="rg-container">
        <div class="rg-section-header">
            <span class="rg-section-badge"><?php _e('For Renters', 'rental-gates'); ?></span>
            <h2 class="rg-section-title"><?php _e('Discover Your Next Home', 'rental-gates'); ?></h2>
            <p class="rg-section-subtitle"><?php _e('Find the perfect rental property with our powerful search tools and interactive map.', 'rental-gates'); ?></p>
        </div>
        <div class="rg-features-grid">
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Interactive Map Search', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Explore properties on an interactive map. See locations, prices, and availability at a glance.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Advanced Filters', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Filter by price, bedrooms, bathrooms, square footage, amenities, and more to find exactly what you need.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Photos & Virtual Tours', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('View high-quality photos and virtual tours of each property before scheduling a visit.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Easy Application', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Apply for properties directly through our platform. Submit applications quickly and securely.', 'rental-gates'); ?></p>
            </div>
        </div>
        <div style="text-align: center; margin-top: 48px;">
            <p style="font-size: 18px; color: var(--rg-text-secondary); margin-bottom: 24px;">
                <?php printf(__('<strong>%s properties</strong> available now', 'rental-gates'), number_format($property_count)); ?>
            </p>
            <a href="<?php echo esc_url($map_url); ?>" class="rg-btn rg-btn-primary rg-btn-lg" aria-label="<?php esc_attr_e('Start browsing available properties', 'rental-gates'); ?>">
                <?php _e('Start Browsing Properties', 'rental-gates'); ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_features): ?>
<!-- Features -->
<section class="rg-features rg-section" id="rg-features">
    <div class="rg-container">
        <div class="rg-section-header">
            <span class="rg-section-badge"><?php _e('For Property Managers & Owners', 'rental-gates'); ?></span>
            <h2 class="rg-section-title"><?php _e('Everything You Need', 'rental-gates'); ?></h2>
            <p class="rg-section-subtitle"><?php _e('From lease management to maintenance requests, we\'ve got property management covered.', 'rental-gates'); ?></p>
        </div>
        <div class="rg-features-grid">
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Building Management', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Organize your portfolio with map-based building creation and detailed property profiles.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Tenant Portal', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Self-service portal for rent payments, maintenance requests, and lease documents.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Lease Management', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Create, track, and renew leases. Get alerts before leases expire.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Online Payments', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Accept rent payments online via credit card or bank transfer.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('Maintenance', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Track maintenance requests from submission to completion.', 'rental-gates'); ?></p>
            </div>
            <div class="rg-feature-card">
                <div class="rg-feature-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
                <h3 class="rg-feature-title"><?php _e('AI Tools', 'rental-gates'); ?></h3>
                <p class="rg-feature-description"><?php _e('Generate descriptions, marketing copy, and intelligent insights.', 'rental-gates'); ?></p>
            </div>
        </div>
        <div style="text-align: center; margin-top: 48px;">
            <a href="<?php echo esc_url($register_url); ?>" class="rg-btn rg-btn-primary rg-btn-lg" aria-label="<?php esc_attr_e('Start managing properties', 'rental-gates'); ?>">
                <?php _e('Start Managing Properties', 'rental-gates'); ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_steps): ?>
<!-- How It Works -->
<section class="rg-steps-section rg-section">
    <div class="rg-container">
        <div class="rg-section-header">
            <span class="rg-section-badge"><?php _e('How It Works', 'rental-gates'); ?></span>
            <h2 class="rg-section-title"><?php _e('Get Started in Minutes', 'rental-gates'); ?></h2>
        </div>
        <div class="rg-steps">
            <div class="rg-step"><div class="rg-step-number">1</div><h3 class="rg-step-title"><?php _e('Create Account', 'rental-gates'); ?></h3><p class="rg-step-description"><?php _e('Sign up free in under 2 minutes.', 'rental-gates'); ?></p></div>
            <div class="rg-step"><div class="rg-step-number">2</div><h3 class="rg-step-title"><?php _e('Add Properties', 'rental-gates'); ?></h3><p class="rg-step-description"><?php _e('Add buildings and units easily.', 'rental-gates'); ?></p></div>
            <div class="rg-step"><div class="rg-step-number">3</div><h3 class="rg-step-title"><?php _e('Invite Tenants', 'rental-gates'); ?></h3><p class="rg-step-description"><?php _e('Give tenants portal access.', 'rental-gates'); ?></p></div>
            <div class="rg-step"><div class="rg-step-number">4</div><h3 class="rg-step-title"><?php _e('Start Managing', 'rental-gates'); ?></h3><p class="rg-step-description"><?php _e('Everything in one place.', 'rental-gates'); ?></p></div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_pricing): ?>
<!-- Pricing -->
<section class="rg-pricing rg-section" id="rg-pricing">
    <div class="rg-container">
        <div class="rg-section-header">
            <span class="rg-section-badge"><?php _e('Pricing', 'rental-gates'); ?></span>
            <h2 class="rg-section-title"><?php _e('Simple, Transparent Pricing', 'rental-gates'); ?></h2>
            <p class="rg-section-subtitle"><?php _e('Start free, scale as you grow. No hidden fees.', 'rental-gates'); ?></p>
        </div>
        <div class="rg-billing-toggle">
            <span class="rg-billing-label active" data-period="monthly"><?php _e('Monthly', 'rental-gates'); ?></span>
            <div class="rg-billing-switch" id="rg-billing-switch"></div>
            <span class="rg-billing-label" data-period="yearly"><?php _e('Yearly', 'rental-gates'); ?></span>
            <span class="rg-billing-save"><?php _e('Save 20%', 'rental-gates'); ?></span>
        </div>
        <?php
        // Get plans from feature gate
        $feature_gate = rg_feature_gate();
        $plans = $feature_gate->get_all_plans();
        
        // Sort plans by sort_order
        uasort($plans, function($a, $b) {
            return ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0);
        });
        
        // Count visible plans for grid class
        $visible_plans = array_filter($plans, function($plan) {
            return Rental_Gates_Pricing::is_plan_visible($plan);
        });
        $plan_count = count($visible_plans);
        $grid_class = $plan_count >= 4 ? 'rg-pricing-grid-4' : '';
        
        // Module labels for display
        $module_labels = array(
            'tenant_portal' => __('Tenant portal', 'rental-gates'),
            'online_payments' => __('Online payments', 'rental-gates'),
            'maintenance' => __('Maintenance tracking', 'rental-gates'),
            'lease_management' => __('Lease management', 'rental-gates'),
            'ai_screening' => __('AI-powered tools', 'rental-gates'),
            'marketing_qr' => __('Marketing & QR codes', 'rental-gates'),
            'vendor_management' => __('Vendor management', 'rental-gates'),
            'chat_messaging' => __('Chat & messaging', 'rental-gates'),
            'advanced_reports' => __('Advanced reports', 'rental-gates'),
            'bulk_operations' => __('Bulk operations', 'rental-gates'),
            'api_access' => __('API access', 'rental-gates'),
            'white_label' => __('White label', 'rental-gates'),
        );
        ?>
        <div class="rg-pricing-grid <?php echo esc_attr($grid_class); ?>">
            <?php 
            // Get pricing helper
            $pricing_helper = function_exists('rental_gates_pricing') ? rental_gates_pricing() : null;
            
            foreach ($plans as $plan_id => $plan): 
                // Skip hidden/inactive plans
                if (!Rental_Gates_Pricing::is_plan_visible($plan)) continue;
                
                $is_featured = !empty($plan['is_featured']);
                
                // Use unified pricing helper for consistent calculations
                $plan['id'] = $plan_id;
                
                if ($pricing_helper) {
                    $pricing = $pricing_helper->get_plan_pricing($plan);
                } else {
                    // Fallback if pricing helper not available
                    $monthly = floatval($plan['price_monthly'] ?? 0);
                    $yearly = floatval($plan['price_yearly'] ?? 0);
                    
                    // Default yearly to 80% of monthly * 12 if not set
                    if ($yearly <= 0 && $monthly > 0) {
                        $yearly = round($monthly * 12 * 0.8, 0);
                    }
                    
                    $pricing = array(
                        'is_free' => !empty($plan['is_free']) || empty($plan['price_monthly']),
                        'monthly_discounted' => $monthly,
                        'yearly_monthly_discounted' => $yearly > 0 ? round($yearly / 12, 0) : 0,
                    );
                }
                
                $is_free = $pricing['is_free'];
                $price_monthly = intval($pricing['monthly_discounted']);
                $price_yearly_monthly = intval($pricing['yearly_monthly_discounted']);
            ?>
            <div class="rg-pricing-card <?php echo $is_featured ? 'featured' : ''; ?>" data-plan="<?php echo esc_attr($plan_id); ?>">
                <?php if ($is_featured): ?>
                <span class="rg-pricing-badge"><?php _e('Most Popular', 'rental-gates'); ?></span>
                <?php endif; ?>
                <h3 class="rg-pricing-name"><?php echo esc_html($plan['name']); ?></h3>
                <p class="rg-pricing-description"><?php echo esc_html($plan['description'] ?? ''); ?></p>
                <div class="rg-pricing-price">
                    <span class="rg-pricing-currency">$</span>
                    <span class="rg-pricing-amount" data-monthly="<?php echo $price_monthly; ?>" data-yearly="<?php echo $price_yearly_monthly; ?>"><?php echo $price_monthly; ?></span>
                    <span class="rg-pricing-period">/mo</span>
                </div>
                <div class="rg-pricing-features">
                    <?php 
                    // Show limits - Buildings first, then units, then others
                    $limits_order = array('buildings', 'units', 'staff', 'vendors', 'tenants');
                    foreach ($limits_order as $limit_key):
                        $value = $plan['limits'][$limit_key] ?? 0;
                        if ($value == 0) continue;
                        
                        // Format display
                        $limit_labels = array(
                            'buildings' => __('buildings', 'rental-gates'),
                            'units' => __('units', 'rental-gates'),
                            'staff' => __('staff members', 'rental-gates'),
                            'vendors' => __('vendors', 'rental-gates'),
                            'tenants' => __('tenants', 'rental-gates'),
                        );
                        
                        if ($value == -1) {
                            $display = sprintf(__('Unlimited %s', 'rental-gates'), $limit_labels[$limit_key]);
                        } else {
                            $display = sprintf(__('Up to %d %s', 'rental-gates'), $value, $limit_labels[$limit_key]);
                        }
                    ?>
                    <div class="rg-pricing-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                        <?php echo esc_html($display); ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php 
                    // Show key modules (limit to 4-5 for clean display)
                    $modules_to_show = array('tenant_portal', 'online_payments', 'maintenance', 'ai_screening', 'api_access');
                    $shown_count = 0;
                    foreach ($modules_to_show as $mod_key):
                        if ($shown_count >= 4) break;
                        $enabled = !empty($plan['modules'][$mod_key]);
                    ?>
                    <div class="rg-pricing-feature <?php echo !$enabled ? 'rg-pricing-feature-disabled' : ''; ?>">
                        <?php if ($enabled): ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                        <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        <?php endif; ?>
                        <?php echo esc_html($module_labels[$mod_key] ?? $mod_key); ?>
                    </div>
                    <?php 
                        $shown_count++;
                    endforeach; 
                    ?>
                    
                    <?php 
                    // Show custom features (limit to 2)
                    $custom_features = array_slice($plan['custom_features'] ?? array(), 0, 2);
                    foreach ($custom_features as $feature): 
                    ?>
                    <div class="rg-pricing-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                        <?php echo esc_html($feature); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php 
                $btn_class = $is_featured ? 'rg-btn-primary' : 'rg-btn-secondary';
                $btn_text = $is_free ? __('Get Started Free', 'rental-gates') : ($plan['cta_text'] ?? __('Get Started', 'rental-gates'));
                $plan_url = $is_free 
                    ? $register_url . '?plan=' . $plan_id 
                    : $register_url . '?plan=' . $plan_id . '&billing=monthly';
                ?>
                <a href="<?php echo esc_url($plan_url); ?>" class="rg-btn <?php echo $btn_class; ?> rg-plan-btn"><?php echo esc_html($btn_text); ?></a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_testimonials): ?>
<!-- Testimonials -->
<section class="rg-testimonials rg-section" id="rg-testimonials">
    <div class="rg-container">
        <div class="rg-section-header">
            <span class="rg-section-badge"><?php _e('Testimonials', 'rental-gates'); ?></span>
            <h2 class="rg-section-title"><?php _e('Loved by Property Managers', 'rental-gates'); ?></h2>
        </div>
        <div class="rg-testimonials-grid">
            <div class="rg-testimonial-card">
                <div class="rg-testimonial-stars"><?php for ($i = 0; $i < 5; $i++): ?><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><?php endfor; ?></div>
                <p class="rg-testimonial-text">"<?php _e('Rental Gates has completely transformed how I manage my properties. What used to take hours now takes minutes.', 'rental-gates'); ?>"</p>
                <div class="rg-testimonial-author"><div class="rg-testimonial-avatar">SM</div><div><p class="rg-testimonial-name">Sarah Mitchell</p><p class="rg-testimonial-role"><?php _e('Property Owner, 32 Units', 'rental-gates'); ?></p></div></div>
            </div>
            <div class="rg-testimonial-card">
                <div class="rg-testimonial-stars"><?php for ($i = 0; $i < 5; $i++): ?><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><?php endfor; ?></div>
                <p class="rg-testimonial-text">"<?php _e('The AI tools save me so much time generating property descriptions and marketing copy. Worth every penny.', 'rental-gates'); ?>"</p>
                <div class="rg-testimonial-author"><div class="rg-testimonial-avatar">JC</div><div><p class="rg-testimonial-name">James Chen</p><p class="rg-testimonial-role"><?php _e('Real Estate Investor', 'rental-gates'); ?></p></div></div>
            </div>
            <div class="rg-testimonial-card">
                <div class="rg-testimonial-stars"><?php for ($i = 0; $i < 5; $i++): ?><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><?php endfor; ?></div>
                <p class="rg-testimonial-text">"<?php _e('Clean interface, powerful features, and excellent support. Finally a system that understands what we need.', 'rental-gates'); ?>"</p>
                <div class="rg-testimonial-author"><div class="rg-testimonial-avatar">RB</div><div><p class="rg-testimonial-name">Rachel Brooks</p><p class="rg-testimonial-role"><?php _e('Property Manager', 'rental-gates'); ?></p></div></div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($show_cta): ?>
<!-- CTA -->
<section class="rg-cta rg-section">
    <div class="rg-container">
        <div class="rg-cta-dual">
            <!-- Renter CTA Card -->
            <div class="rg-cta-card rg-cta-card-renter">
                <div class="rg-cta-card-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
                    </svg>
                </div>
                <h3 class="rg-cta-card-title"><?php _e('Looking for a Rental?', 'rental-gates'); ?></h3>
                <p class="rg-cta-card-description"><?php _e('Browse our interactive map to find available properties that match your needs.', 'rental-gates'); ?></p>
                <a href="<?php echo esc_url($map_url); ?>" class="rg-btn rg-btn-primary" aria-label="<?php esc_attr_e('Browse available properties', 'rental-gates'); ?>">
                    <?php _e('Browse Available Properties', 'rental-gates'); ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </a>
            </div>
            
            <!-- Owner CTA Card -->
            <div class="rg-cta-card rg-cta-card-owner">
                <div class="rg-cta-card-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
                <h3 class="rg-cta-card-title"><?php _e('Manage Properties?', 'rental-gates'); ?></h3>
                <p class="rg-cta-card-description"><?php _e('Join thousands of property managers who trust Rental Gates to streamline operations.', 'rental-gates'); ?></p>
                <a href="<?php echo esc_url($register_url); ?>" class="rg-btn rg-btn-primary" aria-label="<?php esc_attr_e('Start free trial', 'rental-gates'); ?>">
                    <?php _e('Start Free Trial', 'rental-gates'); ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Footer -->
<footer class="rg-footer">
    <div class="rg-container">
        <div class="rg-footer-grid">
            <div class="rg-footer-brand">
                <?php if ($use_site_logo && $site_logo_url): ?>
                <div class="rg-footer-logo"><img src="<?php echo esc_url($site_logo_url); ?>" alt="<?php echo esc_attr($platform_name); ?>" style="height: 32px; width: auto;" loading="lazy" width="auto" height="32"></div>
                <?php else: ?>
                <div class="rg-footer-logo"><div class="rg-footer-logo-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><?php echo esc_html($platform_name); ?></div>
                <?php endif; ?>
                <p class="rg-footer-description"><?php _e('Modern property management software. Simplify operations and grow your portfolio.', 'rental-gates'); ?></p>
                <div class="rg-footer-social">
                    <?php if ($social_twitter): ?><a href="<?php echo esc_url($social_twitter); ?>" target="_blank" rel="noopener" aria-label="Twitter"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"/></svg></a><?php endif; ?>
                    <?php if ($social_facebook): ?><a href="<?php echo esc_url($social_facebook); ?>" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a><?php endif; ?>
                    <?php if ($social_linkedin): ?><a href="<?php echo esc_url($social_linkedin); ?>" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2zM4 6a2 2 0 100-4 2 2 0 000 4z"/></svg></a><?php endif; ?>
                    <?php if ($social_instagram): ?><a href="<?php echo esc_url($social_instagram); ?>" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a><?php endif; ?>
                </div>
            </div>
            <div><h4 class="rg-footer-heading"><?php _e('Product', 'rental-gates'); ?></h4><ul class="rg-footer-links"><?php if ($show_features): ?><li><a href="#rg-features"><?php _e('Features', 'rental-gates'); ?></a></li><?php endif; ?><?php if ($show_pricing): ?><li><a href="#rg-pricing"><?php _e('Pricing', 'rental-gates'); ?></a></li><?php endif; ?><li><a href="<?php echo home_url('/rental-gates/faq'); ?>"><?php _e('FAQ', 'rental-gates'); ?></a></li></ul></div>
            <div><h4 class="rg-footer-heading"><?php _e('Company', 'rental-gates'); ?></h4><ul class="rg-footer-links"><li><a href="<?php echo home_url('/rental-gates/about'); ?>"><?php _e('About', 'rental-gates'); ?></a></li><li><a href="<?php echo home_url('/rental-gates/contact'); ?>"><?php _e('Contact', 'rental-gates'); ?></a></li><li><a href="mailto:<?php echo esc_attr($support_email); ?>"><?php _e('Support', 'rental-gates'); ?></a></li></ul></div>
            <div><h4 class="rg-footer-heading"><?php _e('Legal', 'rental-gates'); ?></h4><ul class="rg-footer-links"><?php $terms_url = get_option('rental_gates_terms_url'); $privacy_url = get_option('rental_gates_privacy_url'); ?><?php if ($privacy_url): ?><li><a href="<?php echo esc_url($privacy_url); ?>"><?php _e('Privacy Policy', 'rental-gates'); ?></a></li><?php endif; ?><?php if ($terms_url): ?><li><a href="<?php echo esc_url($terms_url); ?>"><?php _e('Terms of Service', 'rental-gates'); ?></a></li><?php endif; ?></ul></div>
        </div>
        <div class="rg-footer-bottom">
            <p class="rg-footer-copy">&copy; <?php echo date('Y'); ?> <?php echo esc_html($platform_name); ?>. <?php _e('All rights reserved.', 'rental-gates'); ?></p>
            <div class="rg-footer-legal">
                <a href="mailto:<?php echo esc_attr($support_email); ?>"><?php echo esc_html($support_email); ?></a>
            </div>
        </div>
    </div>
</footer>

<script>
(function() {
    const landing = document.getElementById('rg-landing');
    const header = document.getElementById('rg-header');
    const themeToggles = document.querySelectorAll('.rg-theme-toggle');
    const mobileBtn = document.getElementById('rg-mobile-btn');
    const mobileMenu = document.getElementById('rg-mobile-menu');
    const billingSwitch = document.getElementById('rg-billing-switch');
    
    // Theme Toggle
    function setTheme(dark) {
        landing.classList.toggle('dark', dark);
        localStorage.setItem('rg-theme', dark ? 'dark' : 'light');
    }
    
    // Initialize theme
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('rg-theme');
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
        landing.classList.add('dark');
    }
    
    // Handle all theme toggles (desktop and mobile)
    themeToggles.forEach(toggle => {
        toggle.addEventListener('click', () => setTheme(!landing.classList.contains('dark')));
    });
    
    // Header scroll effect
    let ticking = false;
    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                header.classList.toggle('scrolled', window.scrollY > 50);
                ticking = false;
            });
            ticking = true;
        }
    }, { passive: true });
    
    // Mobile menu
    if (mobileBtn && mobileMenu) {
        mobileBtn.addEventListener('click', function() {
            const isOpen = mobileMenu.classList.toggle('open');
            mobileBtn.classList.toggle('active', isOpen);
            document.body.style.overflow = isOpen ? 'hidden' : '';
        });
        
        // Close mobile menu on link click
        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.remove('open');
                mobileBtn.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }
    
    // Billing toggle
    if (billingSwitch) {
        billingSwitch.addEventListener('click', function() {
            this.classList.toggle('yearly');
            const isYearly = this.classList.contains('yearly');
            const billingPeriod = isYearly ? 'yearly' : 'monthly';
            
            // Update billing labels
            document.querySelectorAll('.rg-billing-label').forEach(label => {
                label.classList.toggle('active', label.dataset.period === billingPeriod);
            });
            
            // Update price amounts
            document.querySelectorAll('.rg-pricing-amount').forEach(amount => {
                amount.textContent = isYearly ? amount.dataset.yearly : amount.dataset.monthly;
            });
            
            // Update plan button URLs with billing parameter
            document.querySelectorAll('.rg-plan-btn').forEach(btn => {
                const url = new URL(btn.href);
                if (url.searchParams.has('billing')) {
                    url.searchParams.set('billing', billingPeriod);
                    btn.href = url.toString();
                }
            });
        });
    }
    
    // Smooth scroll for anchor links
    document.querySelectorAll('.rg-landing a[href^="#rg-"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offset = header.offsetHeight + 20;
                const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
                window.scrollTo({ top, behavior: 'smooth' });
            }
        });
    });
    
    // Active nav link on scroll
    const sections = document.querySelectorAll('.rg-section[id]');
    const navLinks = document.querySelectorAll('.rg-nav-link');
    
    function updateActiveNav() {
        const scrollPos = window.scrollY + header.offsetHeight + 100;
        
        sections.forEach(section => {
            const top = section.offsetTop;
            const height = section.offsetHeight;
            const id = section.getAttribute('id');
            
            if (scrollPos >= top && scrollPos < top + height) {
                navLinks.forEach(link => {
                    link.classList.toggle('active', link.getAttribute('href') === '#' + id);
                });
            }
        });
    }
    
    window.addEventListener('scroll', updateActiveNav, { passive: true });
    updateActiveNav();
    
    // Preload map page on hover over map CTAs
    const mapLinks = document.querySelectorAll('a[href*="/rental-gates/map"]');
    mapLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            const link = document.createElement('link');
            link.rel = 'prefetch';
            link.href = this.href;
            document.head.appendChild(link);
        }, { once: true });
    });
})();
</script>

<!-- Floating Action Button for Mobile -->
<a href="<?php echo esc_url($map_url); ?>" class="rg-fab" aria-label="<?php esc_attr_e('Browse properties', 'rental-gates'); ?>" title="<?php esc_attr_e('Browse Properties', 'rental-gates'); ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
    </svg>
</a>
</div>
