<?php
/**
 * Rental Gates - Privacy Policy Page
 */
if (!defined('ABSPATH')) exit;

$page_title = __('Privacy Policy', 'rental-gates');
$page_subtitle = __('How we collect, use, and protect your information', 'rental-gates');
$meta_description = __('Rental Gates Privacy Policy - Learn how we collect, use, store, and protect your personal information.', 'rental-gates');
$current_page = 'privacy';
$last_updated = '2024-01-01';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-header.php';
?>

<section class="content-section">
    <div class="container">
        <div class="content-grid sidebar">
            <article class="prose">
                <p><strong><?php _e('Last Updated:', 'rental-gates'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($last_updated)); ?></p>
                
                <h2><?php _e('Introduction', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('%s ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our property management platform and services.', 'rental-gates'), esc_html($platform_name)); ?></p>
                <p><?php _e('By using our services, you agree to the collection and use of information in accordance with this policy.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Information We Collect', 'rental-gates'); ?></h2>
                
                <h3><?php _e('Information You Provide', 'rental-gates'); ?></h3>
                <ul>
                    <li><strong><?php _e('Account Information:', 'rental-gates'); ?></strong> <?php _e('Name, email address, phone number, and password when you create an account.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Property Information:', 'rental-gates'); ?></strong> <?php _e('Address, unit details, photos, and other property-related data you enter.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Tenant Information:', 'rental-gates'); ?></strong> <?php _e('Names, contact details, lease information, and payment records of your tenants.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Payment Information:', 'rental-gates'); ?></strong> <?php _e('Billing details processed through our secure payment provider (we do not store full card numbers).', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Communications:', 'rental-gates'); ?></strong> <?php _e('Messages sent through our platform and correspondence with our support team.', 'rental-gates'); ?></li>
                </ul>
                
                <h3><?php _e('Information Collected Automatically', 'rental-gates'); ?></h3>
                <ul>
                    <li><strong><?php _e('Usage Data:', 'rental-gates'); ?></strong> <?php _e('Pages visited, features used, time spent, and actions taken within the platform.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Device Information:', 'rental-gates'); ?></strong> <?php _e('Browser type, operating system, device type, and IP address.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Cookies:', 'rental-gates'); ?></strong> <?php _e('Small files stored on your device to improve functionality and user experience.', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('How We Use Your Information', 'rental-gates'); ?></h2>
                <p><?php _e('We use the information we collect to:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('Provide, maintain, and improve our services', 'rental-gates'); ?></li>
                    <li><?php _e('Process transactions and send related information', 'rental-gates'); ?></li>
                    <li><?php _e('Send notifications about your account and properties', 'rental-gates'); ?></li>
                    <li><?php _e('Respond to your comments, questions, and requests', 'rental-gates'); ?></li>
                    <li><?php _e('Monitor and analyze usage trends to improve user experience', 'rental-gates'); ?></li>
                    <li><?php _e('Detect, prevent, and address technical issues and security threats', 'rental-gates'); ?></li>
                    <li><?php _e('Comply with legal obligations', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Data Sharing and Disclosure', 'rental-gates'); ?></h2>
                <p><?php _e('We do not sell your personal information. We may share your information in the following circumstances:', 'rental-gates'); ?></p>
                <ul>
                    <li><strong><?php _e('Service Providers:', 'rental-gates'); ?></strong> <?php _e('Third-party companies that help us operate our platform (payment processors, hosting providers, email services).', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Legal Requirements:', 'rental-gates'); ?></strong> <?php _e('When required by law, court order, or government request.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Business Transfers:', 'rental-gates'); ?></strong> <?php _e('In connection with a merger, acquisition, or sale of assets.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('With Your Consent:', 'rental-gates'); ?></strong> <?php _e('When you have given us explicit permission to share.', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Data Security', 'rental-gates'); ?></h2>
                <p><?php _e('We implement industry-standard security measures to protect your information:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('256-bit SSL encryption for all data transmission', 'rental-gates'); ?></li>
                    <li><?php _e('Encrypted data storage at rest', 'rental-gates'); ?></li>
                    <li><?php _e('Regular security audits and penetration testing', 'rental-gates'); ?></li>
                    <li><?php _e('Access controls and authentication requirements', 'rental-gates'); ?></li>
                    <li><?php _e('Regular backups to prevent data loss', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Data Retention', 'rental-gates'); ?></h2>
                <p><?php _e('We retain your information for as long as your account is active or as needed to provide services. We may retain certain information as required by law or for legitimate business purposes. You can request deletion of your data by contacting us.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Your Rights', 'rental-gates'); ?></h2>
                <p><?php _e('Depending on your location, you may have the following rights:', 'rental-gates'); ?></p>
                <ul>
                    <li><strong><?php _e('Access:', 'rental-gates'); ?></strong> <?php _e('Request a copy of your personal data.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Correction:', 'rental-gates'); ?></strong> <?php _e('Request correction of inaccurate data.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Deletion:', 'rental-gates'); ?></strong> <?php _e('Request deletion of your data.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Portability:', 'rental-gates'); ?></strong> <?php _e('Request a portable copy of your data.', 'rental-gates'); ?></li>
                    <li><strong><?php _e('Opt-Out:', 'rental-gates'); ?></strong> <?php _e('Opt out of marketing communications.', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Cookies', 'rental-gates'); ?></h2>
                <p><?php _e('We use cookies and similar technologies for:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('Keeping you signed in', 'rental-gates'); ?></li>
                    <li><?php _e('Remembering your preferences', 'rental-gates'); ?></li>
                    <li><?php _e('Understanding how you use our platform', 'rental-gates'); ?></li>
                    <li><?php _e('Improving our services', 'rental-gates'); ?></li>
                </ul>
                <p><?php _e('You can control cookies through your browser settings, but this may limit functionality.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Children\'s Privacy', 'rental-gates'); ?></h2>
                <p><?php _e('Our services are not intended for children under 18. We do not knowingly collect information from children.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Changes to This Policy', 'rental-gates'); ?></h2>
                <p><?php _e('We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last Updated" date.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Contact Us', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('If you have questions about this Privacy Policy, please contact us at <a href="mailto:%s">%s</a> or through our <a href="%s">Contact page</a>.', 'rental-gates'), esc_attr($support_email), esc_html($support_email), home_url('/rental-gates/contact')); ?></p>
            </article>
            
            <aside>
                <div class="card">
                    <h3 style="font-size: 1rem; font-weight: 600; color: var(--gray-900); margin-bottom: 16px;"><?php _e('Quick Links', 'rental-gates'); ?></h3>
                    <ul style="list-style: none; font-size: 0.9375rem;">
                        <li style="margin-bottom: 12px;"><a href="#" style="color: var(--primary);"><?php _e('Download PDF', 'rental-gates'); ?></a></li>
                        <li style="margin-bottom: 12px;"><a href="<?php echo home_url('/rental-gates/terms'); ?>" style="color: var(--primary);"><?php _e('Terms of Service', 'rental-gates'); ?></a></li>
                        <li style="margin-bottom: 12px;"><a href="<?php echo home_url('/rental-gates/contact'); ?>" style="color: var(--primary);"><?php _e('Contact Us', 'rental-gates'); ?></a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-footer.php'; ?>
