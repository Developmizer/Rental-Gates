<?php
/**
 * Payment Overdue Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Payment Overdue - Action Required', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('Our records show that your rent payment is past due. Please make your payment as soon as possible to avoid any late fees.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: center;">
        <tr>
            <td style="padding-bottom: 8px;">
                <p style="margin: 0; font-size: 14px; color: #991b1b;">' . __('Amount Overdue', 'rental-gates') . '</p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="margin: 0; font-size: 36px; font-weight: 700; color: #991b1b;">$' . esc_html($amount_due ?? '0.00') . '</p>
            </td>
        </tr>
        <tr>
            <td style="padding-top: 12px;">
                <p style="margin: 0; font-size: 14px; color: #991b1b;">' . sprintf(__('Was due: %s', 'rental-gates'), esc_html($due_date ?? '-')) . '</p>
            </td>
        </tr>
    </table>',
    'danger'
); ?>

<?php if (!empty($late_fee)): ?>
<p style="margin: 0 0 24px; color: #991b1b; font-size: 14px; font-weight: 500;">
    ⚠️ <?php printf(__('A late fee of $%s may apply.', 'rental-gates'), esc_html($late_fee)); ?>
</p>
<?php endif; ?>

<?php echo Rental_Gates_Email::button($payment_url ?? home_url('/rental-gates/tenant/payments'), __('Pay Now', 'rental-gates'), 'danger'); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you\'re experiencing financial difficulties, please contact us immediately to discuss payment options.', 'rental-gates'); ?>
</p>
