<?php
/**
 * Maintenance Assigned Email Template
 * 
 * Variables: $tenant_name, $organization_name, $work_order_id, $work_order_title,
 *            $technician_name, $scheduled_date, $scheduled_time, $action_url
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('Technician Assigned', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($tenant_name ?? 'Tenant')
));

echo Rental_Gates_Email::text(sprintf(
    __('Great news! A technician has been assigned to your maintenance request.', 'rental-gates')
));

echo Rental_Gates_Email::alert(
    '<strong>' . esc_html($work_order_title ?? 'Maintenance Request') . '</strong><br>' .
    sprintf(__('Work Order #%s', 'rental-gates'), esc_html($work_order_id ?? '')),
    'info'
);

echo Rental_Gates_Email::details_table_start();
if (!empty($technician_name)) {
    echo Rental_Gates_Email::detail_row(__('Technician', 'rental-gates'), esc_html($technician_name));
}
if (!empty($scheduled_date)) {
    echo Rental_Gates_Email::detail_row(__('Scheduled Date', 'rental-gates'), esc_html($scheduled_date));
}
if (!empty($scheduled_time)) {
    echo Rental_Gates_Email::detail_row(__('Scheduled Time', 'rental-gates'), esc_html($scheduled_time), true);
} else {
    echo Rental_Gates_Email::detail_row(__('Status', 'rental-gates'), __('Scheduled', 'rental-gates'), true);
}
echo Rental_Gates_Email::details_table_end();

echo Rental_Gates_Email::text(
    __('Please ensure someone is available at the property during the scheduled time. If you need to reschedule, please contact us as soon as possible.', 'rental-gates')
);

if (!empty($action_url)) {
    echo Rental_Gates_Email::button(__('View Request Status', 'rental-gates'), $action_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    __('If you have any questions or need to reschedule, please reply to this email or contact your property manager.', 'rental-gates'),
    'small'
);
