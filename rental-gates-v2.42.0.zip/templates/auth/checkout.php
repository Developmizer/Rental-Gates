<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Complete Your Subscription', 'rental-gates'); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <?php
    // Get subscription info from URL
    $subscription_id = isset($_GET['subscription_id']) ? intval($_GET['subscription_id']) : 0;
    $plan_slug = isset($_GET['plan']) ? sanitize_text_field($_GET['plan']) : '';
    $billing_cycle = isset($_GET['billing']) ? sanitize_text_field($_GET['billing']) : 'monthly';
    
    // Error tracking
    $error_message = '';
    $subscription = null;
    $organization_id = 0;
    
    // Get current user
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    
    if (!$user_id) {
        $error_message = __('Please log in to continue.', 'rental-gates');
    } else {
        // Get organization
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        $org_member = $wpdb->get_row($wpdb->prepare(
            "SELECT organization_id FROM {$tables['organization_members']} WHERE user_id = %d AND is_primary = 1",
            $user_id
        ));
        $organization_id = $org_member ? $org_member->organization_id : 0;
        
        if (!$organization_id) {
            $error_message = __('Organization not found.', 'rental-gates');
        } elseif (!$subscription_id) {
            $error_message = __('No subscription specified.', 'rental-gates');
        } else {
            // Try to find the subscription
            $subscription = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$tables['subscriptions']} WHERE id = %d AND organization_id = %d",
                $subscription_id,
                $organization_id
            ), ARRAY_A);
            
            if (!$subscription) {
                $error_message = __('Subscription not found.', 'rental-gates');
            } elseif ($subscription['status'] === 'active') {
                // Already active - redirect to dashboard
                wp_redirect(home_url('/rental-gates/dashboard?already_active=1'));
                exit;
            } elseif ($subscription['status'] !== 'pending_payment') {
                $error_message = sprintf(__('Invalid subscription status: %s', 'rental-gates'), $subscription['status']);
            }
        }
    }
    
    // If there's an error, show error page instead of redirecting silently
    $has_error = !empty($error_message);
    
    // Plan details (even if error, for display purposes)
    $plan_prices = array(
        'free' => array('name' => 'Free', 'monthly' => 0, 'yearly' => 0),
        'starter' => array('name' => 'Starter', 'monthly' => 19, 'yearly' => 180),
        'professional' => array('name' => 'Professional', 'monthly' => 49, 'yearly' => 468),
        'enterprise' => array('name' => 'Enterprise', 'monthly' => 149, 'yearly' => 1428),
    );
    
    // Use subscription plan_slug if available, otherwise URL param
    if ($subscription && !empty($subscription['plan_slug'])) {
        $plan_slug = $subscription['plan_slug'];
        $billing_cycle = $subscription['billing_cycle'] ?? 'monthly';
    }
    
    $plan_info = isset($plan_prices[$plan_slug]) ? $plan_prices[$plan_slug] : $plan_prices['starter'];
    $amount = $billing_cycle === 'yearly' ? $plan_info['yearly'] : $plan_info['monthly'];
    $monthly_equivalent = $billing_cycle === 'yearly' ? round($plan_info['yearly'] / 12) : $plan_info['monthly'];
    
    // Get platform settings
    $platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
    $primary_color = get_option('rental_gates_primary_color', '#2563eb');
    
    // Get Stripe keys
    $stripe_mode = get_option('rental_gates_stripe_mode', 'test');
    $stripe_publishable_key = $stripe_mode === 'live' 
        ? get_option('rental_gates_stripe_live_publishable_key', '')
        : get_option('rental_gates_stripe_test_publishable_key', '');
    
    $stripe_configured = !empty($stripe_publishable_key);
    ?>
    <style>
        :root {
            --primary: <?php echo esc_attr($primary_color); ?>;
            --primary-dark: <?php echo esc_attr($primary_color); ?>dd;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%); 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            padding: 20px;
        }
        
        .checkout-wrapper {
            width: 100%;
            max-width: 1100px;
            display: grid;
            grid-template-columns: 1fr 480px;
            background: #fff;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
        }
        
        /* Left Panel - Order Summary */
        .summary-panel {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 48px;
            display: flex;
            flex-direction: column;
        }
        
        .summary-header {
            margin-bottom: 40px;
        }
        
        .summary-logo {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
            opacity: 0.9;
        }
        
        .summary-title {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 8px;
        }
        
        .summary-subtitle {
            font-size: 15px;
            opacity: 0.85;
        }
        
        .order-card {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }
        
        .order-plan {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .order-plan-name {
            font-size: 20px;
            font-weight: 700;
        }
        
        .order-plan-badge {
            padding: 4px 12px;
            background: rgba(255,255,255,0.2);
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .order-price {
            display: flex;
            align-items: baseline;
            gap: 4px;
            margin-bottom: 8px;
        }
        
        .order-price-currency {
            font-size: 24px;
            font-weight: 600;
        }
        
        .order-price-amount {
            font-size: 56px;
            font-weight: 800;
            line-height: 1;
        }
        
        .order-price-period {
            font-size: 18px;
            opacity: 0.8;
            margin-left: 4px;
        }
        
        .order-billing {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .order-features {
            list-style: none;
            margin-top: 24px;
        }
        
        .order-features li {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            padding: 10px 0;
            opacity: 0.9;
        }
        
        .order-features svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
            color: #34d399;
        }
        
        .guarantee-box {
            margin-top: auto;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 12px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }
        
        .guarantee-box svg {
            width: 24px;
            height: 24px;
            flex-shrink: 0;
            color: #34d399;
        }
        
        .guarantee-box p {
            font-size: 13px;
            line-height: 1.5;
            opacity: 0.9;
        }
        
        /* Right Panel - Payment Form */
        .payment-panel {
            padding: 48px;
            background: #fff;
        }
        
        .payment-header {
            margin-bottom: 32px;
        }
        
        .payment-header h2 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 8px;
        }
        
        .payment-header p {
            color: #64748b;
            font-size: 15px;
        }
        
        .payment-user {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 12px;
            margin-bottom: 24px;
        }
        
        .payment-user-avatar {
            width: 48px;
            height: 48px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
        }
        
        .payment-user-info {
            flex: 1;
        }
        
        .payment-user-name {
            font-weight: 600;
            color: #1e293b;
        }
        
        .payment-user-email {
            font-size: 14px;
            color: #64748b;
        }
        
        /* Stripe Elements */
        #payment-element {
            margin-bottom: 24px;
        }
        
        #payment-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
            display: none;
        }
        
        #payment-message.error {
            display: block;
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        #payment-message.success {
            display: block;
            background: #f0fdf4;
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }
        
        .btn-pay {
            width: 100%;
            padding: 16px 24px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-pay:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }
        
        .btn-pay:disabled {
            background: #94a3b8;
            cursor: not-allowed;
            transform: none;
        }
        
        .btn-pay svg {
            width: 20px;
            height: 20px;
        }
        
        .payment-security {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 24px;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid #e5e7eb;
        }
        
        .security-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: #64748b;
        }
        
        .security-item svg {
            width: 16px;
            height: 16px;
            color: #059669;
        }
        
        .skip-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #64748b;
            font-size: 14px;
            text-decoration: none;
        }
        
        .skip-link:hover {
            color: var(--primary);
        }
        
        /* Stripe not configured */
        .stripe-not-configured {
            padding: 32px;
            background: #fef3c7;
            border-radius: 12px;
            text-align: center;
        }
        
        .stripe-not-configured svg {
            width: 48px;
            height: 48px;
            color: #d97706;
            margin-bottom: 16px;
        }
        
        .stripe-not-configured h3 {
            font-size: 18px;
            font-weight: 600;
            color: #92400e;
            margin-bottom: 8px;
        }
        
        .stripe-not-configured p {
            color: #a16207;
            font-size: 14px;
            margin-bottom: 16px;
        }
        
        .btn-skip {
            display: inline-block;
            padding: 12px 24px;
            background: #1e293b;
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
        }
        
        .btn-skip:hover {
            background: #334155;
            color: #fff;
        }
        
        /* Responsive */
        @media (max-width: 900px) {
            .checkout-wrapper {
                grid-template-columns: 1fr;
                max-width: 520px;
            }
            
            .summary-panel {
                padding: 32px;
            }
            
            .payment-panel {
                padding: 32px;
            }
        }
        
        @media (max-width: 520px) {
            body {
                padding: 0;
            }
            
            .checkout-wrapper {
                border-radius: 0;
                min-height: 100vh;
            }
            
            .payment-security {
                flex-wrap: wrap;
                gap: 12px;
            }
        }
        
        /* Loading spinner */
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .spinner {
            animation: spin 1s linear infinite;
        }
    </style>
</head>
<body>
    <?php if ($has_error): ?>
    <!-- Error State -->
    <div class="checkout-wrapper" style="max-width: 500px;">
        <div class="payment-panel" style="text-align: center; padding: 60px 40px;">
            <div style="width: 80px; height: 80px; margin: 0 auto 24px; background: #fef2f2; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" style="width: 40px; height: 40px;">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
            </div>
            <h2 style="font-size: 24px; font-weight: 700; color: #1e293b; margin-bottom: 12px;"><?php _e('Unable to Process', 'rental-gates'); ?></h2>
            <p style="color: #64748b; margin-bottom: 24px; line-height: 1.6;"><?php echo esc_html($error_message); ?></p>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="btn-skip" style="padding: 12px 24px; background: var(--primary); color: #fff; border-radius: 8px; text-decoration: none; font-weight: 600;">
                    <?php _e('Go to Dashboard', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/register'); ?>" style="padding: 12px 24px; border: 1px solid #e5e7eb; color: #374151; border-radius: 8px; text-decoration: none; font-weight: 600;">
                    <?php _e('Start Over', 'rental-gates'); ?>
                </a>
            </div>
            <p style="margin-top: 24px; font-size: 13px; color: #9ca3af;">
                <?php _e('If you continue to experience issues, please contact support.', 'rental-gates'); ?>
            </p>
        </div>
    </div>
    <?php else: ?>
    <div class="checkout-wrapper">
        <!-- Left Panel - Order Summary -->
        <div class="summary-panel">
            <div class="summary-header">
                <div class="summary-logo"><?php echo esc_html($platform_name); ?></div>
                <h1 class="summary-title"><?php _e('Complete Your Subscription', 'rental-gates'); ?></h1>
                <p class="summary-subtitle"><?php _e('Secure payment powered by Stripe', 'rental-gates'); ?></p>
            </div>
            
            <div class="order-card">
                <div class="order-plan">
                    <span class="order-plan-name"><?php echo esc_html($plan_info['name']); ?> <?php _e('Plan', 'rental-gates'); ?></span>
                    <span class="order-plan-badge"><?php echo $billing_cycle === 'yearly' ? __('Annual', 'rental-gates') : __('Monthly', 'rental-gates'); ?></span>
                </div>
                
                <div class="order-price">
                    <span class="order-price-currency">$</span>
                    <span class="order-price-amount"><?php echo esc_html($monthly_equivalent); ?></span>
                    <span class="order-price-period">/<?php _e('mo', 'rental-gates'); ?></span>
                </div>
                
                <?php if ($billing_cycle === 'yearly'): ?>
                <p class="order-billing"><?php printf(__('Billed annually at $%s/year', 'rental-gates'), number_format($amount)); ?></p>
                <?php else: ?>
                <p class="order-billing"><?php _e('Billed monthly', 'rental-gates'); ?></p>
                <?php endif; ?>
                
                <ul class="order-features">
                    <?php if ($plan_slug === 'starter'): ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Up to 10 units', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Online payments', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Tenant portal', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Email support', 'rental-gates'); ?></li>
                    <?php elseif ($plan_slug === 'professional'): ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Up to 50 units', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('AI-powered tools', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Vendor management', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Priority support', 'rental-gates'); ?></li>
                    <?php elseif ($plan_slug === 'enterprise'): ?>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Unlimited units', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('API access', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Custom integrations', 'rental-gates'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg><?php _e('Dedicated manager', 'rental-gates'); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <div class="guarantee-box">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
                <p><?php _e('30-day money-back guarantee. Cancel anytime with no questions asked.', 'rental-gates'); ?></p>
            </div>
        </div>
        
        <!-- Right Panel - Payment Form -->
        <div class="payment-panel">
            <div class="payment-header">
                <h2><?php _e('Payment Details', 'rental-gates'); ?></h2>
                <p><?php _e('Enter your card information to complete your subscription', 'rental-gates'); ?></p>
            </div>
            
            <div class="payment-user">
                <div class="payment-user-avatar">
                    <?php echo esc_html(strtoupper(substr($current_user->display_name, 0, 1))); ?>
                </div>
                <div class="payment-user-info">
                    <div class="payment-user-name"><?php echo esc_html($current_user->display_name); ?></div>
                    <div class="payment-user-email"><?php echo esc_html($current_user->user_email); ?></div>
                </div>
            </div>
            
            <?php if ($stripe_configured): ?>
            <div id="payment-message"></div>
            
            <form id="payment-form">
                <input type="hidden" name="subscription_id" value="<?php echo esc_attr($subscription_id); ?>">
                <input type="hidden" name="plan" value="<?php echo esc_attr($plan_slug); ?>">
                <input type="hidden" name="billing" value="<?php echo esc_attr($billing_cycle); ?>">
                <input type="hidden" name="amount" value="<?php echo esc_attr($amount); ?>">
                
                <div id="payment-element"></div>
                
                <button type="submit" id="submit-button" class="btn-pay">
                    <span id="button-text"><?php printf(__('Pay $%s', 'rental-gates'), number_format($amount, 2)); ?></span>
                    <svg id="button-spinner" class="spinner" style="display: none;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10" stroke-dasharray="32" stroke-dashoffset="32"/>
                    </svg>
                </button>
            </form>
            
            <div class="payment-security">
                <div class="security-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                        <path d="M7 11V7a5 5 0 0110 0v4"/>
                    </svg>
                    <?php _e('Encrypted', 'rental-gates'); ?>
                </div>
                <div class="security-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    </svg>
                    <?php _e('Secure', 'rental-gates'); ?>
                </div>
                <div class="security-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                        <line x1="1" y1="10" x2="23" y2="10"/>
                    </svg>
                    <?php _e('Powered by Stripe', 'rental-gates'); ?>
                </div>
            </div>
            
            <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="skip-link">
                <?php _e('Skip for now (continue with Free plan)', 'rental-gates'); ?>
            </a>
            
            <?php else: ?>
            <!-- Stripe not configured -->
            <div class="stripe-not-configured">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
                <h3><?php _e('Payment System Setup Required', 'rental-gates'); ?></h3>
                <p><?php _e('Stripe payment processing is not yet configured. Please contact the administrator or continue with the free plan for now.', 'rental-gates'); ?></p>
                <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="btn-skip">
                    <?php _e('Continue with Free Plan', 'rental-gates'); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php wp_footer(); ?>
    
    <?php if (!$has_error && $stripe_configured): ?>
    <script src="https://js.stripe.com/v3/"></script>
    <script>
    (function() {
        const stripe = Stripe('<?php echo esc_js($stripe_publishable_key); ?>');
        const form = document.getElementById('payment-form');
        const submitButton = document.getElementById('submit-button');
        const buttonText = document.getElementById('button-text');
        const buttonSpinner = document.getElementById('button-spinner');
        const messageEl = document.getElementById('payment-message');
        
        let elements;
        let clientSecret;
        
        // Create payment intent on page load
        async function initialize() {
            try {
                const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'rental_gates_create_subscription_intent',
                        subscription_id: '<?php echo esc_js($subscription_id); ?>',
                        plan: '<?php echo esc_js($plan_slug); ?>',
                        billing: '<?php echo esc_js($billing_cycle); ?>',
                        nonce: '<?php echo wp_create_nonce("rental_gates_subscription_nonce"); ?>'
                    })
                });
                
                const data = await response.json();
                
                if (!data.success) {
                    showMessage(data.data?.message || 'Failed to initialize payment', 'error');
                    submitButton.disabled = true;
                    return;
                }
                
                clientSecret = data.data.client_secret;
                
                elements = stripe.elements({
                    clientSecret: clientSecret,
                    appearance: {
                        theme: 'stripe',
                        variables: {
                            colorPrimary: '<?php echo esc_js($primary_color); ?>',
                            fontFamily: '"Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                            borderRadius: '10px',
                        }
                    }
                });
                
                const paymentElement = elements.create('payment', {
                    layout: 'tabs'
                });
                paymentElement.mount('#payment-element');
                
            } catch (error) {
                console.error('Error:', error);
                showMessage('Failed to load payment form. Please refresh the page.', 'error');
                submitButton.disabled = true;
            }
        }
        
        // Handle form submission
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            if (!clientSecret || !elements) {
                showMessage('Payment not initialized. Please refresh the page.', 'error');
                return;
            }
            
            setLoading(true);
            
            try {
                const { error, paymentIntent } = await stripe.confirmPayment({
                    elements,
                    confirmParams: {
                        return_url: '<?php echo esc_js(home_url("/rental-gates/dashboard?payment=success")); ?>',
                    },
                    redirect: 'if_required'
                });
                
                if (error) {
                    if (error.type === 'card_error' || error.type === 'validation_error') {
                        showMessage(error.message, 'error');
                    } else {
                        showMessage('An unexpected error occurred.', 'error');
                    }
                    setLoading(false);
                    return;
                }
                
                if (paymentIntent && paymentIntent.status === 'succeeded') {
                    // Payment successful - activate subscription
                    await activateSubscription(paymentIntent.id);
                }
                
            } catch (error) {
                console.error('Payment error:', error);
                showMessage('Payment failed. Please try again.', 'error');
                setLoading(false);
            }
        });
        
        async function activateSubscription(paymentIntentId) {
            try {
                const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'rental_gates_activate_subscription',
                        subscription_id: '<?php echo esc_js($subscription_id); ?>',
                        payment_intent_id: paymentIntentId,
                        nonce: '<?php echo wp_create_nonce("rental_gates_subscription_nonce"); ?>'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showMessage('Payment successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = '<?php echo esc_js(home_url("/rental-gates/dashboard?upgraded=1")); ?>';
                    }, 1500);
                } else {
                    showMessage(data.data?.message || 'Failed to activate subscription', 'error');
                    setLoading(false);
                }
                
            } catch (error) {
                console.error('Activation error:', error);
                // Payment went through but activation failed - still redirect
                showMessage('Payment received. Redirecting...', 'success');
                setTimeout(() => {
                    window.location.href = '<?php echo esc_js(home_url("/rental-gates/dashboard?payment=pending")); ?>';
                }, 1500);
            }
        }
        
        function showMessage(message, type) {
            messageEl.textContent = message;
            messageEl.className = type;
        }
        
        function setLoading(isLoading) {
            submitButton.disabled = isLoading;
            buttonText.style.display = isLoading ? 'none' : 'inline';
            buttonSpinner.style.display = isLoading ? 'inline' : 'none';
        }
        
        // Initialize on page load
        initialize();
    })();
    </script>
    <?php endif; ?>
</body>
</html>
