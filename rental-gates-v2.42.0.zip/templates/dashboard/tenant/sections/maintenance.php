<?php
/**
 * Tenant Maintenance Section - Enhanced
 * Full-featured maintenance request management for tenants
 */
if (!defined('ABSPATH')) exit;

$ajax_url = admin_url('admin-ajax.php');

// Get all maintenance requests for this tenant
$maintenance_requests = $wpdb->get_results($wpdb->prepare(
    "SELECT wo.*, b.name as building_name, u.name as unit_name 
     FROM {$tables['work_orders']} wo
     LEFT JOIN {$tables['buildings']} b ON wo.building_id = b.id
     LEFT JOIN {$tables['units']} u ON wo.unit_id = u.id
     WHERE wo.tenant_id = %d
     ORDER BY wo.created_at DESC",
    $tenant_id
), ARRAY_A);

// Get notes for each request
$notes_by_request = array();
if (!empty($maintenance_requests)) {
    $request_ids = array_column($maintenance_requests, 'id');
    if (!empty($request_ids)) {
        $placeholders = implode(',', array_fill(0, count($request_ids), '%d'));
        $notes = $wpdb->get_results($wpdb->prepare(
            "SELECT won.*, u.display_name as user_name
             FROM {$tables['work_order_notes']} won
             LEFT JOIN {$wpdb->users} u ON won.user_id = u.ID
             WHERE won.work_order_id IN ($placeholders) AND won.is_internal = 0
             ORDER BY won.created_at ASC",
            ...$request_ids
        ), ARRAY_A);
        
        foreach ($notes as $note) {
            $notes_by_request[$note['work_order_id']][] = $note;
        }
    }
}

$status_config = array(
    'open' => array('label' => __('Open', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'assigned' => array('label' => __('Assigned', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'in_progress' => array('label' => __('In Progress', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'on_hold' => array('label' => __('On Hold', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'completed' => array('label' => __('Completed', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'cancelled' => array('label' => __('Cancelled', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
);

$priority_config = array(
    'emergency' => array('label' => __('Emergency', 'rental-gates'), 'color' => '#dc2626', 'bg' => '#fee2e2'),
    'high' => array('label' => __('High', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'medium' => array('label' => __('Medium', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'low' => array('label' => __('Low', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

$categories = array(
    'plumbing' => array('label' => __('Plumbing', 'rental-gates'), 'icon' => '🚿'),
    'electrical' => array('label' => __('Electrical', 'rental-gates'), 'icon' => '⚡'),
    'hvac' => array('label' => __('HVAC', 'rental-gates'), 'icon' => '❄️'),
    'appliance' => array('label' => __('Appliance', 'rental-gates'), 'icon' => '🔌'),
    'structural' => array('label' => __('Structural', 'rental-gates'), 'icon' => '🏠'),
    'pest' => array('label' => __('Pest Control', 'rental-gates'), 'icon' => '🐛'),
    'cleaning' => array('label' => __('Cleaning', 'rental-gates'), 'icon' => '🧹'),
    'general' => array('label' => __('General', 'rental-gates'), 'icon' => '🔧'),
    'other' => array('label' => __('Other', 'rental-gates'), 'icon' => '📋'),
);

// Count by status
$open_count = $in_progress_count = $completed_count = $needs_feedback_count = 0;
foreach ($maintenance_requests as $req) {
    if (in_array($req['status'], array('open', 'assigned'))) $open_count++;
    elseif ($req['status'] === 'in_progress') $in_progress_count++;
    elseif ($req['status'] === 'completed') {
        $completed_count++;
        $meta = json_decode($req['meta_data'] ?? '{}', true);
        if (empty($meta['tenant_feedback']) && strtotime($req['completed_at'] ?? $req['updated_at']) > strtotime('-7 days')) {
            $needs_feedback_count++;
        }
    }
}

// Check for active request detail view
$view_request_id = isset($_GET['view']) ? intval($_GET['view']) : null;
$active_request = null;
$active_notes = array();

if ($view_request_id) {
    foreach ($maintenance_requests as $req) {
        if ($req['id'] == $view_request_id) {
            $active_request = $req;
            $active_notes = $notes_by_request[$view_request_id] ?? array();
            break;
        }
    }
}
?>

<style>
    .tp-maint-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .tp-stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
    .tp-stat-mini { background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 16px; text-align: center; }
    .tp-stat-mini-value { font-size: 28px; font-weight: 700; }
    .tp-stat-mini-label { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    .tp-stat-mini.alert { border-color: #fecaca; background: #fef2f2; }
    .tp-stat-mini.alert .tp-stat-mini-value { color: #dc2626; }
    
    .tp-filter-tabs { display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; }
    .tp-filter-tab { padding: 8px 16px; border-radius: 20px; font-size: 13px; font-weight: 500; cursor: pointer; border: 1px solid var(--gray-200); background: #fff; color: var(--gray-600); }
    .tp-filter-tab.active { background: var(--primary); border-color: var(--primary); color: #fff; }
    .tp-filter-count { display: inline-flex; min-width: 18px; height: 18px; padding: 0 5px; background: rgba(0,0,0,0.1); border-radius: 9px; font-size: 11px; margin-left: 6px; align-items: center; justify-content: center; }
    .tp-filter-tab.active .tp-filter-count { background: rgba(255,255,255,0.2); }
    
    .tp-request-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 16px; overflow: hidden; cursor: pointer; transition: all 0.2s; }
    .tp-request-card:hover { border-color: var(--primary); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .tp-request-card.needs-feedback { border-color: #fbbf24; border-width: 2px; }
    .tp-request-card-header { display: flex; justify-content: space-between; padding: 16px 20px; gap: 16px; }
    .tp-request-title { font-weight: 600; font-size: 16px; margin: 0 0 8px; display: flex; align-items: center; gap: 8px; }
    .tp-request-meta { display: flex; gap: 12px; flex-wrap: wrap; font-size: 13px; color: var(--gray-500); }
    .tp-request-meta-item { display: flex; align-items: center; gap: 4px; }
    .tp-request-meta-item svg { width: 14px; height: 14px; }
    .tp-badge { display: inline-flex; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .tp-priority-badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
    .tp-request-card-body { padding: 0 20px 16px; }
    .tp-request-desc { font-size: 14px; color: var(--gray-600); line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .tp-request-card-footer { display: flex; justify-content: space-between; padding: 12px 20px; background: var(--gray-50); border-top: 1px solid var(--gray-100); }
    .tp-request-photos { display: flex; gap: 4px; }
    .tp-request-photo-thumb { width: 32px; height: 32px; border-radius: 6px; object-fit: cover; }
    .tp-request-photo-more { width: 32px; height: 32px; border-radius: 6px; background: var(--gray-200); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; }
    .tp-feedback-banner { background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 8px 12px; display: flex; align-items: center; gap: 8px; font-size: 13px; color: #92400e; margin: 0 20px 16px; }
    .tp-feedback-banner svg { width: 16px; height: 16px; }
    
    .tp-empty { text-align: center; padding: 60px 20px; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; }
    .tp-empty svg { width: 64px; height: 64px; color: var(--gray-300); margin-bottom: 16px; }
    .tp-empty h3 { font-size: 18px; margin: 0 0 8px; }
    .tp-empty p { color: var(--gray-500); margin: 0 0 20px; }
    
    .tp-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; padding: 20px; }
    .tp-modal-overlay.open { display: flex; }
    .tp-modal { background: #fff; border-radius: 16px; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto; }
    .tp-modal.large { max-width: 800px; }
    .tp-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; background: #fff; z-index: 10; }
    .tp-modal-header h3 { margin: 0; font-size: 18px; display: flex; align-items: center; gap: 10px; }
    .tp-modal-close { background: none; border: none; cursor: pointer; padding: 8px; color: var(--gray-400); border-radius: 8px; }
    .tp-modal-close:hover { background: var(--gray-100); }
    .tp-modal-body { padding: 24px; }
    
    .tp-form-group { margin-bottom: 20px; }
    .tp-form-group label { display: block; font-size: 14px; font-weight: 500; margin-bottom: 6px; }
    .tp-form-group .required { color: #dc2626; }
    .tp-form-group input, .tp-form-group select, .tp-form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .tp-form-group input:focus, .tp-form-group select:focus, .tp-form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1); }
    .tp-form-group textarea { min-height: 100px; resize: vertical; }
    .tp-form-hint { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    .tp-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .tp-form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-100); }
    
    .tp-file-upload { border: 2px dashed var(--gray-300); border-radius: 12px; padding: 24px; text-align: center; cursor: pointer; background: var(--gray-50); }
    .tp-file-upload:hover { border-color: var(--primary); background: #f5f3ff; }
    .tp-file-upload.dragover { border-color: var(--primary); background: #ede9fe; }
    .tp-file-upload svg { width: 40px; height: 40px; color: var(--gray-400); margin-bottom: 8px; }
    .tp-file-upload p { margin: 0; font-size: 14px; }
    .tp-file-upload span { font-size: 12px; color: var(--gray-400); }
    .tp-file-preview { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 16px; }
    .tp-file-item { position: relative; width: 80px; height: 80px; border-radius: 8px; overflow: hidden; }
    .tp-file-item img { width: 100%; height: 100%; object-fit: cover; }
    .tp-file-item-remove { position: absolute; top: 4px; right: 4px; width: 20px; height: 20px; border-radius: 50%; background: rgba(0,0,0,0.6); color: #fff; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 14px; }
    
    .tp-detail-section { margin-bottom: 24px; }
    .tp-detail-section-title { font-size: 14px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
    .tp-detail-description { background: var(--gray-50); padding: 16px; border-radius: 8px; font-size: 14px; line-height: 1.6; }
    .tp-detail-photos { display: flex; flex-wrap: wrap; gap: 12px; }
    .tp-detail-photo { width: 120px; height: 120px; border-radius: 8px; object-fit: cover; cursor: pointer; }
    
    .tp-timeline { position: relative; }
    .tp-timeline::before { content: ''; position: absolute; left: 16px; top: 24px; bottom: 24px; width: 2px; background: var(--gray-200); }
    .tp-timeline-item { display: flex; gap: 16px; padding: 12px 0; position: relative; }
    .tp-timeline-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--primary); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 600; z-index: 1; }
    .tp-timeline-avatar.tenant { background: #10b981; }
    .tp-timeline-avatar.staff { background: var(--primary); }
    .tp-timeline-avatar.system { background: var(--gray-400); }
    .tp-timeline-content { flex: 1; background: var(--gray-50); padding: 12px 16px; border-radius: 8px; }
    .tp-timeline-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
    .tp-timeline-name { font-weight: 600; font-size: 13px; }
    .tp-timeline-time { font-size: 12px; color: var(--gray-400); }
    .tp-timeline-note { font-size: 14px; color: var(--gray-700); line-height: 1.5; }
    .tp-timeline-attachments { display: flex; gap: 8px; margin-top: 8px; }
    .tp-timeline-attachment { width: 60px; height: 60px; border-radius: 6px; object-fit: cover; }
    
    .tp-add-note { background: var(--gray-50); border-radius: 12px; padding: 16px; margin-top: 16px; }
    .tp-add-note-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 12px; }
    .tp-add-note-attach { display: flex; align-items: center; gap: 8px; color: var(--gray-500); font-size: 13px; cursor: pointer; }
    .tp-add-note-attach:hover { color: var(--primary); }
    .tp-add-note-attach svg { width: 18px; height: 18px; }
    
    .tp-feedback-section { background: linear-gradient(135deg, #ecfdf5, #d1fae5); border: 1px solid #a7f3d0; border-radius: 12px; padding: 20px; margin-bottom: 24px; }
    .tp-feedback-title { font-size: 16px; font-weight: 600; color: #065f46; margin: 0 0 8px; display: flex; align-items: center; gap: 8px; }
    .tp-feedback-title svg { width: 20px; height: 20px; }
    .tp-feedback-text { font-size: 14px; color: #047857; margin: 0 0 16px; }
    .tp-feedback-buttons { display: flex; gap: 12px; }
    .tp-feedback-btn { padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; }
    .tp-feedback-btn.positive { background: #10b981; color: #fff; }
    .tp-feedback-btn.positive:hover { background: #059669; }
    .tp-feedback-btn.negative { background: #fff; color: #dc2626; border: 1px solid #fecaca; }
    .tp-feedback-btn.negative:hover { background: #fef2f2; }
    
    .tp-confirm-delete { text-align: center; padding: 20px 0; }
    .tp-confirm-delete svg { width: 48px; height: 48px; color: #dc2626; margin-bottom: 16px; }
    .tp-confirm-delete h4 { font-size: 18px; margin: 0 0 8px; }
    .tp-confirm-delete p { color: var(--gray-500); margin: 0 0 24px; }
    .tp-confirm-actions { display: flex; gap: 12px; justify-content: center; }
    .tp-btn-danger { background: #dc2626; color: #fff; }
    .tp-btn-danger:hover { background: #b91c1c; }
    
    @media (max-width: 768px) {
        .tp-stats-row { grid-template-columns: repeat(2, 1fr); }
        .tp-maint-header { flex-direction: column; align-items: stretch; }
        .tp-form-row { grid-template-columns: 1fr; }
    }
</style>

<?php if ($active_request): ?>
<?php
$status = $status_config[$active_request['status']] ?? $status_config['open'];
$priority = $priority_config[$active_request['priority']] ?? $priority_config['medium'];
$category = $categories[$active_request['category']] ?? $categories['other'];
$photos = json_decode($active_request['photos'] ?? '[]', true);
$meta = json_decode($active_request['meta_data'] ?? '{}', true);
$can_delete = in_array($active_request['status'], array('open', 'assigned'));
$needs_feedback = ($active_request['status'] === 'completed' && empty($meta['tenant_feedback']));
?>

<div class="tp-maint-header">
    <div>
        <a href="<?php echo remove_query_arg('view'); ?>" style="display: flex; align-items: center; gap: 8px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 8px;">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            <?php _e('Back to all requests', 'rental-gates'); ?>
        </a>
        <h2 style="margin: 0; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 24px;"><?php echo $category['icon']; ?></span>
            <?php echo esc_html($active_request['title']); ?>
        </h2>
    </div>
    <?php if ($can_delete): ?>
    <button class="tp-btn tp-btn-secondary" onclick="openDeleteModal(<?php echo $active_request['id']; ?>, '<?php echo esc_js($active_request['title']); ?>')" style="color: #dc2626; border-color: #fecaca;">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        <?php _e('Delete', 'rental-gates'); ?>
    </button>
    <?php endif; ?>
</div>

<?php if ($needs_feedback): ?>
<div class="tp-feedback-section">
    <h3 class="tp-feedback-title">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <?php _e('Was this issue resolved?', 'rental-gates'); ?>
    </h3>
    <p class="tp-feedback-text"><?php _e('Please let us know if the maintenance issue has been resolved to your satisfaction.', 'rental-gates'); ?></p>
    <div class="tp-feedback-buttons">
        <button class="tp-feedback-btn positive" onclick="submitFeedback(<?php echo $active_request['id']; ?>, 'satisfied')"><?php _e('Yes, issue resolved', 'rental-gates'); ?></button>
        <button class="tp-feedback-btn negative" onclick="submitFeedback(<?php echo $active_request['id']; ?>, 'not_satisfied')"><?php _e('No, still has issues', 'rental-gates'); ?></button>
    </div>
</div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
    <div>
        <div class="tp-detail-section">
            <div class="tp-detail-section-title"><?php _e('Request Details', 'rental-gates'); ?></div>
            <div class="tp-detail-description"><?php echo nl2br(esc_html($active_request['description'])); ?></div>
        </div>
        
        <?php if (!empty($photos)): ?>
        <div class="tp-detail-section">
            <div class="tp-detail-section-title"><?php _e('Photos', 'rental-gates'); ?></div>
            <div class="tp-detail-photos">
                <?php foreach ($photos as $photo): ?>
                <img src="<?php echo esc_url($photo); ?>" class="tp-detail-photo" onclick="window.open('<?php echo esc_url($photo); ?>', '_blank')">
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="tp-detail-section">
            <div class="tp-detail-section-title"><?php _e('Activity & Updates', 'rental-gates'); ?></div>
            <div class="tp-timeline">
                <div class="tp-timeline-item">
                    <div class="tp-timeline-avatar tenant"><?php echo strtoupper(substr($tenant['first_name'], 0, 1)); ?></div>
                    <div class="tp-timeline-content">
                        <div class="tp-timeline-header">
                            <span class="tp-timeline-name"><?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></span>
                            <span class="tp-timeline-time"><?php echo date_i18n('M j, Y g:i a', strtotime($active_request['created_at'])); ?></span>
                        </div>
                        <div class="tp-timeline-note"><?php _e('Created this maintenance request', 'rental-gates'); ?></div>
                    </div>
                </div>
                
                <?php foreach ($active_notes as $note): 
                    $is_tenant = ($note['user_type'] === 'tenant');
                    $note_attachments = json_decode($note['attachments'] ?? '[]', true);
                ?>
                <div class="tp-timeline-item">
                    <div class="tp-timeline-avatar <?php echo $note['user_type']; ?>"><?php echo strtoupper(substr($note['user_name'] ?? 'S', 0, 1)); ?></div>
                    <div class="tp-timeline-content">
                        <div class="tp-timeline-header">
                            <span class="tp-timeline-name"><?php echo esc_html($note['user_name'] ?? ($is_tenant ? __('You', 'rental-gates') : __('Staff', 'rental-gates'))); ?></span>
                            <span class="tp-timeline-time"><?php echo date_i18n('M j, Y g:i a', strtotime($note['created_at'])); ?></span>
                        </div>
                        <div class="tp-timeline-note"><?php echo nl2br(esc_html($note['note'])); ?></div>
                        <?php if (!empty($note_attachments)): ?>
                        <div class="tp-timeline-attachments">
                            <?php foreach ($note_attachments as $att): ?>
                            <img src="<?php echo esc_url($att); ?>" class="tp-timeline-attachment" onclick="window.open('<?php echo esc_url($att); ?>', '_blank')">
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if ($active_request['status'] === 'completed'): ?>
                <div class="tp-timeline-item">
                    <div class="tp-timeline-avatar system">✓</div>
                    <div class="tp-timeline-content" style="background: #d1fae5;">
                        <div class="tp-timeline-header">
                            <span class="tp-timeline-name" style="color: #065f46;"><?php _e('Completed', 'rental-gates'); ?></span>
                            <span class="tp-timeline-time"><?php echo date_i18n('M j, Y g:i a', strtotime($active_request['completed_at'] ?? $active_request['updated_at'])); ?></span>
                        </div>
                        <div class="tp-timeline-note" style="color: #047857;"><?php _e('This maintenance request has been marked as completed.', 'rental-gates'); ?></div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if (!in_array($active_request['status'], array('completed', 'cancelled', 'declined'))): ?>
            <div class="tp-add-note">
                <form id="addNoteForm">
                    <textarea id="noteText" placeholder="<?php esc_attr_e('Add a comment or update...', 'rental-gates'); ?>" rows="2" style="width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px;"></textarea>
                    <input type="file" id="noteAttachment" accept="image/*" multiple style="display: none;">
                    <div id="noteFilePreview" class="tp-file-preview"></div>
                    <div class="tp-add-note-actions">
                        <label class="tp-add-note-attach" onclick="document.getElementById('noteAttachment').click()">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                            <?php _e('Attach photo', 'rental-gates'); ?>
                        </label>
                        <button type="submit" class="tp-btn tp-btn-primary" id="addNoteBtn"><?php _e('Add Comment', 'rental-gates'); ?></button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div>
        <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; margin-bottom: 16px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                <span style="font-size: 14px; color: var(--gray-500);"><?php _e('Status', 'rental-gates'); ?></span>
                <span class="tp-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;"><?php echo $status['label']; ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                <span style="font-size: 14px; color: var(--gray-500);"><?php _e('Priority', 'rental-gates'); ?></span>
                <span class="tp-priority-badge" style="background: <?php echo $priority['bg']; ?>; color: <?php echo $priority['color']; ?>;"><?php echo $priority['label']; ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                <span style="font-size: 14px; color: var(--gray-500);"><?php _e('Category', 'rental-gates'); ?></span>
                <span style="font-size: 14px;"><?php echo $category['icon']; ?> <?php echo $category['label']; ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="font-size: 14px; color: var(--gray-500);"><?php _e('Submitted', 'rental-gates'); ?></span>
                <span style="font-size: 14px;"><?php echo date_i18n('M j, Y', strtotime($active_request['created_at'])); ?></span>
            </div>
            <?php if ($active_request['scheduled_date']): ?>
            <div style="display: flex; justify-content: space-between; margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-100);">
                <span style="font-size: 14px; color: var(--gray-500);"><?php _e('Scheduled', 'rental-gates'); ?></span>
                <span style="font-size: 14px; font-weight: 500; color: var(--primary);"><?php echo date_i18n('M j, Y g:i a', strtotime($active_request['scheduled_date'])); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px;">
            <div style="font-size: 14px; font-weight: 600; color: var(--gray-500); margin-bottom: 12px;"><?php _e('Location', 'rental-gates'); ?></div>
            <?php if ($active_request['building_name']): ?>
            <div style="font-size: 14px; margin-bottom: 4px;"><strong><?php _e('Building:', 'rental-gates'); ?></strong> <?php echo esc_html($active_request['building_name']); ?></div>
            <?php endif; ?>
            <?php if ($active_request['unit_name']): ?>
            <div style="font-size: 14px;"><strong><?php _e('Unit:', 'rental-gates'); ?></strong> <?php echo esc_html($active_request['unit_name']); ?></div>
            <?php endif; ?>
            <?php if ($active_request['permission_to_enter']): ?>
            <div style="margin-top: 12px; padding: 8px 12px; background: #d1fae5; border-radius: 6px; font-size: 13px; color: #065f46;">✓ <?php _e('Entry permission granted', 'rental-gates'); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php else: ?>
<!-- List View -->
<div class="tp-maint-header">
    <div>
        <h2 style="margin: 0 0 4px;"><?php _e('Maintenance Requests', 'rental-gates'); ?></h2>
        <p style="margin: 0; color: var(--gray-500); font-size: 14px;"><?php _e('Submit and track maintenance issues for your unit', 'rental-gates'); ?></p>
    </div>
    <button class="tp-btn tp-btn-primary" onclick="openRequestModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
        <?php _e('New Request', 'rental-gates'); ?>
    </button>
</div>

<div class="tp-stats-row">
    <div class="tp-stat-mini">
        <div class="tp-stat-mini-value" style="color: #3b82f6;"><?php echo $open_count; ?></div>
        <div class="tp-stat-mini-label"><?php _e('Open', 'rental-gates'); ?></div>
    </div>
    <div class="tp-stat-mini">
        <div class="tp-stat-mini-value" style="color: #f59e0b;"><?php echo $in_progress_count; ?></div>
        <div class="tp-stat-mini-label"><?php _e('In Progress', 'rental-gates'); ?></div>
    </div>
    <div class="tp-stat-mini">
        <div class="tp-stat-mini-value" style="color: #10b981;"><?php echo $completed_count; ?></div>
        <div class="tp-stat-mini-label"><?php _e('Completed', 'rental-gates'); ?></div>
    </div>
    <div class="tp-stat-mini <?php echo $needs_feedback_count > 0 ? 'alert' : ''; ?>">
        <div class="tp-stat-mini-value" style="<?php echo $needs_feedback_count > 0 ? '' : 'color: var(--gray-400);'; ?>"><?php echo $needs_feedback_count > 0 ? $needs_feedback_count : count($maintenance_requests); ?></div>
        <div class="tp-stat-mini-label"><?php echo $needs_feedback_count > 0 ? __('Needs Feedback', 'rental-gates') : __('Total', 'rental-gates'); ?></div>
    </div>
</div>

<div class="tp-filter-tabs">
    <button class="tp-filter-tab active" data-filter="all"><?php _e('All', 'rental-gates'); ?><span class="tp-filter-count"><?php echo count($maintenance_requests); ?></span></button>
    <button class="tp-filter-tab" data-filter="open"><?php _e('Open', 'rental-gates'); ?><span class="tp-filter-count"><?php echo $open_count; ?></span></button>
    <button class="tp-filter-tab" data-filter="in_progress"><?php _e('In Progress', 'rental-gates'); ?><span class="tp-filter-count"><?php echo $in_progress_count; ?></span></button>
    <button class="tp-filter-tab" data-filter="completed"><?php _e('Completed', 'rental-gates'); ?><span class="tp-filter-count"><?php echo $completed_count; ?></span></button>
</div>

<?php if (empty($maintenance_requests)): ?>
    <div class="tp-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
        <h3><?php _e('No Maintenance Requests', 'rental-gates'); ?></h3>
        <p><?php _e('You haven\'t submitted any maintenance requests yet. If something needs repair in your unit, let us know!', 'rental-gates'); ?></p>
        <button class="tp-btn tp-btn-primary" onclick="openRequestModal()"><?php _e('Submit Your First Request', 'rental-gates'); ?></button>
    </div>
<?php else: ?>
    <div id="requestList">
    <?php foreach ($maintenance_requests as $req): 
        $status = $status_config[$req['status']] ?? $status_config['open'];
        $priority = $priority_config[$req['priority']] ?? $priority_config['medium'];
        $category = $categories[$req['category']] ?? $categories['other'];
        $photos = json_decode($req['photos'] ?? '[]', true);
        $meta = json_decode($req['meta_data'] ?? '{}', true);
        $needs_feedback = ($req['status'] === 'completed' && empty($meta['tenant_feedback']) && strtotime($req['completed_at'] ?? $req['updated_at']) > strtotime('-7 days'));
        $notes_count = count($notes_by_request[$req['id']] ?? array());
        $status_class = in_array($req['status'], array('open', 'assigned')) ? 'open' : $req['status'];
    ?>
        <div class="tp-request-card <?php echo $needs_feedback ? 'needs-feedback' : ''; ?>" data-status="<?php echo esc_attr($status_class); ?>" onclick="window.location.href='?section=maintenance&view=<?php echo $req['id']; ?>'">
            <div class="tp-request-card-header">
                <div style="flex: 1; min-width: 0;">
                    <h4 class="tp-request-title"><span><?php echo $category['icon']; ?></span><?php echo esc_html($req['title']); ?></h4>
                    <div class="tp-request-meta">
                        <span class="tp-request-meta-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                            <?php echo date_i18n('M j, Y', strtotime($req['created_at'])); ?>
                        </span>
                        <span class="tp-request-meta-item">
                            <span class="tp-priority-badge" style="background: <?php echo $priority['bg']; ?>; color: <?php echo $priority['color']; ?>;"><?php echo $priority['label']; ?></span>
                        </span>
                        <?php if ($notes_count > 0): ?>
                        <span class="tp-request-meta-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                            <?php echo $notes_count; ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="tp-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;"><?php echo $status['label']; ?></span>
            </div>
            
            <?php if ($req['description']): ?>
            <div class="tp-request-card-body"><p class="tp-request-desc"><?php echo esc_html($req['description']); ?></p></div>
            <?php endif; ?>
            
            <div class="tp-request-card-footer">
                <div class="tp-request-photos">
                    <?php foreach (array_slice($photos, 0, 3) as $photo): ?>
                    <img src="<?php echo esc_url($photo); ?>" class="tp-request-photo-thumb" alt="">
                    <?php endforeach; ?>
                    <?php if (count($photos) > 3): ?><div class="tp-request-photo-more">+<?php echo count($photos) - 3; ?></div><?php endif; ?>
                </div>
                <?php if ($needs_feedback): ?>
                <span style="font-size: 12px; color: #92400e;">⚠️ <?php _e('Feedback needed', 'rental-gates'); ?></span>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php endif; ?>

<!-- New Request Modal -->
<div class="tp-modal-overlay" id="requestModal">
    <div class="tp-modal large">
        <div class="tp-modal-header">
            <h3><svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg><?php _e('Submit Maintenance Request', 'rental-gates'); ?></h3>
            <button class="tp-modal-close" onclick="closeRequestModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
        </div>
        <form id="maintenanceForm" class="tp-modal-body" enctype="multipart/form-data">
            <div class="tp-form-group">
                <label for="req_title"><?php _e('What\'s the issue?', 'rental-gates'); ?> <span class="required">*</span></label>
                <input type="text" id="req_title" name="title" required placeholder="<?php esc_attr_e('e.g., Leaky faucet in bathroom', 'rental-gates'); ?>">
            </div>
            
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="req_category"><?php _e('Category', 'rental-gates'); ?> <span class="required">*</span></label>
                    <select id="req_category" name="category" required>
                        <option value=""><?php _e('Select a category', 'rental-gates'); ?></option>
                        <?php foreach ($categories as $key => $cat): ?>
                            <option value="<?php echo esc_attr($key); ?>"><?php echo $cat['icon']; ?> <?php echo esc_html($cat['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="tp-form-group">
                    <label for="req_priority"><?php _e('Priority Level', 'rental-gates'); ?></label>
                    <select id="req_priority" name="priority">
                        <option value="low"><?php _e('Low - Can wait a few days', 'rental-gates'); ?></option>
                        <option value="medium" selected><?php _e('Medium - Needs attention soon', 'rental-gates'); ?></option>
                        <option value="high"><?php _e('High - Urgent issue', 'rental-gates'); ?></option>
                        <option value="emergency"><?php _e('🚨 Emergency - Safety hazard', 'rental-gates'); ?></option>
                    </select>
                    <p class="tp-form-hint"><?php _e('Emergency: No water, gas leak, fire damage, flooding', 'rental-gates'); ?></p>
                </div>
            </div>
            
            <div class="tp-form-group">
                <label for="req_description"><?php _e('Describe the issue', 'rental-gates'); ?> <span class="required">*</span></label>
                <textarea id="req_description" name="description" required placeholder="<?php esc_attr_e('Please provide details: Where is it? When did it start?', 'rental-gates'); ?>" rows="4"></textarea>
            </div>
            
            <div class="tp-form-group">
                <label><?php _e('Photos (optional)', 'rental-gates'); ?></label>
                <div class="tp-file-upload" id="photoDropZone" onclick="document.getElementById('req_photos').click()">
                    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <p><?php _e('Click to upload or drag and drop', 'rental-gates'); ?></p>
                    <span><?php _e('PNG, JPG up to 5MB each (max 5)', 'rental-gates'); ?></span>
                </div>
                <input type="file" id="req_photos" name="photos[]" accept="image/*" multiple style="display: none;">
                <div id="photoPreview" class="tp-file-preview"></div>
            </div>
            
            <div class="tp-form-group" style="background: var(--gray-50); padding: 16px; border-radius: 8px;">
                <label style="display: flex; align-items: flex-start; gap: 10px; font-weight: normal; cursor: pointer; margin: 0;">
                    <input type="checkbox" name="permission_to_enter" value="1" checked style="width: auto; margin-top: 3px;">
                    <span><strong><?php _e('Permission to Enter', 'rental-gates'); ?></strong><br><span style="font-size: 13px; color: var(--gray-500);"><?php _e('I give permission for maintenance staff to enter my unit if I\'m not home', 'rental-gates'); ?></span></span>
                </label>
            </div>
            
            <div class="tp-form-actions">
                <button type="button" class="tp-btn tp-btn-secondary" onclick="closeRequestModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="tp-btn tp-btn-primary" id="submitRequestBtn"><?php _e('Submit Request', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="tp-modal-overlay" id="deleteModal">
    <div class="tp-modal" style="max-width: 400px;">
        <div class="tp-modal-header">
            <h3><?php _e('Delete Request', 'rental-gates'); ?></h3>
            <button class="tp-modal-close" onclick="closeDeleteModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
        </div>
        <div class="tp-modal-body">
            <div class="tp-confirm-delete">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                <h4><?php _e('Are you sure?', 'rental-gates'); ?></h4>
                <p id="deleteRequestTitle"></p>
                <div class="tp-confirm-actions">
                    <button type="button" class="tp-btn tp-btn-secondary" onclick="closeDeleteModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                    <button type="button" class="tp-btn tp-btn-danger" id="confirmDeleteBtn" onclick="confirmDelete()"><?php _e('Delete Request', 'rental-gates'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Use existing ajaxurl or define it
if (typeof ajaxurl === 'undefined') {
    var ajaxurl = '<?php echo esc_js($ajax_url); ?>';
}
const nonce = '<?php echo wp_create_nonce('rental_gates_nonce'); ?>';
const tenantId = <?php echo intval($tenant_id); ?>;
const orgId = <?php echo intval($org_id); ?>;
const buildingId = <?php echo intval($current_lease['building_id'] ?? 0); ?>;
const unitId = <?php echo intval($current_lease['unit_id'] ?? 0); ?>;

let deleteRequestId = null;
let selectedPhotos = [];
let noteAttachments = [];

function openRequestModal() { document.getElementById('requestModal').classList.add('open'); document.body.style.overflow = 'hidden'; }
function closeRequestModal() { document.getElementById('requestModal').classList.remove('open'); document.body.style.overflow = ''; document.getElementById('maintenanceForm').reset(); selectedPhotos = []; document.getElementById('photoPreview').innerHTML = ''; }
function openDeleteModal(id, title) { deleteRequestId = id; document.getElementById('deleteRequestTitle').textContent = '"' + title + '"'; document.getElementById('deleteModal').classList.add('open'); document.body.style.overflow = 'hidden'; }
function closeDeleteModal() { document.getElementById('deleteModal').classList.remove('open'); document.body.style.overflow = ''; deleteRequestId = null; }

// Filter tabs
document.querySelectorAll('.tp-filter-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.tp-filter-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        document.querySelectorAll('.tp-request-card').forEach(card => {
            card.style.display = (filter === 'all' || card.dataset.status === filter) ? '' : 'none';
        });
    });
});

// Photo upload
const photoInput = document.getElementById('req_photos');
const dropZone = document.getElementById('photoDropZone');
const photoPreview = document.getElementById('photoPreview');

if (dropZone) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => dropZone.addEventListener(e, ev => { ev.preventDefault(); ev.stopPropagation(); }));
    ['dragenter', 'dragover'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.add('dragover')));
    ['dragleave', 'drop'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.remove('dragover')));
    dropZone.addEventListener('drop', e => handleFiles(e.dataTransfer.files));
}
if (photoInput) photoInput.addEventListener('change', function() { handleFiles(this.files); });

function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (selectedPhotos.length >= 5) return alert('<?php echo esc_js(__('Maximum 5 photos', 'rental-gates')); ?>');
        if (file.size > 5 * 1024 * 1024) return alert('<?php echo esc_js(__('File too large (max 5MB)', 'rental-gates')); ?>');
        if (!file.type.startsWith('image/')) return alert('<?php echo esc_js(__('Only images allowed', 'rental-gates')); ?>');
        selectedPhotos.push(file);
        const reader = new FileReader();
        reader.onload = e => {
            const div = document.createElement('div');
            div.className = 'tp-file-item';
            div.innerHTML = `<img src="${e.target.result}"><button type="button" class="tp-file-item-remove" onclick="removePhoto(${selectedPhotos.length - 1})">&times;</button>`;
            photoPreview.appendChild(div);
        };
        reader.readAsDataURL(file);
    });
}

function removePhoto(index) { selectedPhotos.splice(index, 1); photoPreview.innerHTML = ''; selectedPhotos.forEach((f, i) => { const r = new FileReader(); r.onload = e => { const d = document.createElement('div'); d.className = 'tp-file-item'; d.innerHTML = `<img src="${e.target.result}"><button type="button" class="tp-file-item-remove" onclick="removePhoto(${i})">&times;</button>`; photoPreview.appendChild(d); }; r.readAsDataURL(f); }); }

// Note attachments
const noteAttachmentInput = document.getElementById('noteAttachment');
const noteFilePreview = document.getElementById('noteFilePreview');
if (noteAttachmentInput) noteAttachmentInput.addEventListener('change', function() { noteAttachments = Array.from(this.files); if (noteFilePreview) { noteFilePreview.innerHTML = ''; noteAttachments.forEach((f, i) => { const r = new FileReader(); r.onload = e => { const d = document.createElement('div'); d.className = 'tp-file-item'; d.innerHTML = `<img src="${e.target.result}"><button type="button" class="tp-file-item-remove" onclick="removeNoteAttachment(${i})">&times;</button>`; noteFilePreview.appendChild(d); }; r.readAsDataURL(f); }); } });
function removeNoteAttachment(i) { noteAttachments.splice(i, 1); if (noteFilePreview) { noteFilePreview.innerHTML = ''; noteAttachments.forEach((f, idx) => { const r = new FileReader(); r.onload = e => { const d = document.createElement('div'); d.className = 'tp-file-item'; d.innerHTML = `<img src="${e.target.result}"><button type="button" class="tp-file-item-remove" onclick="removeNoteAttachment(${idx})">&times;</button>`; noteFilePreview.appendChild(d); }; r.readAsDataURL(f); }); } }

// Submit form
document.getElementById('maintenanceForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = document.getElementById('submitRequestBtn');
    btn.disabled = true; btn.innerHTML = '<?php echo esc_js(__('Submitting...', 'rental-gates')); ?>';
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_tenant_create_maintenance');
    formData.append('nonce', nonce);
    formData.append('tenant_id', tenantId);
    formData.append('organization_id', orgId);
    formData.append('building_id', buildingId);
    formData.append('unit_id', unitId);
    selectedPhotos.forEach(p => formData.append('photos[]', p));
    
    try {
        const resp = await fetch(ajaxurl, { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.success) location.reload();
        else { alert(data.data?.message || 'Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Submit Request', 'rental-gates')); ?>'; }
    } catch (err) { alert('Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Submit Request', 'rental-gates')); ?>'; }
});

// Delete request
async function confirmDelete() {
    if (!deleteRequestId) return;
    const btn = document.getElementById('confirmDeleteBtn');
    btn.disabled = true; btn.innerHTML = '<?php echo esc_js(__('Deleting...', 'rental-gates')); ?>';
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_tenant_delete_maintenance');
    formData.append('nonce', nonce);
    formData.append('request_id', deleteRequestId);
    formData.append('tenant_id', tenantId);
    
    try {
        const resp = await fetch(ajaxurl, { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.success) window.location.href = '?section=maintenance';
        else { alert(data.data?.message || 'Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Delete Request', 'rental-gates')); ?>'; }
    } catch (err) { alert('Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Delete Request', 'rental-gates')); ?>'; }
}

// Feedback
async function submitFeedback(requestId, feedback) {
    const formData = new FormData();
    formData.append('action', 'rental_gates_tenant_maintenance_feedback');
    formData.append('nonce', nonce);
    formData.append('request_id', requestId);
    formData.append('tenant_id', tenantId);
    formData.append('feedback', feedback);
    
    try {
        const resp = await fetch(ajaxurl, { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.success) {
            if (feedback === 'not_satisfied') {
                const details = prompt('<?php echo esc_js(__('What still needs attention?', 'rental-gates')); ?>');
                if (details) {
                    const noteData = new FormData();
                    noteData.append('action', 'rental_gates_tenant_add_note');
                    noteData.append('nonce', nonce);
                    noteData.append('request_id', requestId);
                    noteData.append('tenant_id', tenantId);
                    noteData.append('note', '<?php echo esc_js(__('Issue not resolved:', 'rental-gates')); ?> ' + details);
                    await fetch(ajaxurl, { method: 'POST', body: noteData });
                }
            }
            location.reload();
        } else alert(data.data?.message || 'Error');
    } catch (err) { alert('Error'); }
}

// Add note
const addNoteForm = document.getElementById('addNoteForm');
if (addNoteForm) {
    addNoteForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const noteText = document.getElementById('noteText').value.trim();
        if (!noteText && noteAttachments.length === 0) return alert('<?php echo esc_js(__('Enter a comment or attach a photo', 'rental-gates')); ?>');
        
        const btn = document.getElementById('addNoteBtn');
        btn.disabled = true; btn.innerHTML = '<?php echo esc_js(__('Adding...', 'rental-gates')); ?>';
        
        const formData = new FormData();
        formData.append('action', 'rental_gates_tenant_add_note');
        formData.append('nonce', nonce);
        formData.append('request_id', <?php echo intval($view_request_id ?: 0); ?>);
        formData.append('tenant_id', tenantId);
        formData.append('note', noteText);
        noteAttachments.forEach(f => formData.append('attachments[]', f));
        
        try {
            const resp = await fetch(ajaxurl, { method: 'POST', body: formData });
            const data = await resp.json();
            if (data.success) location.reload();
            else { alert(data.data?.message || 'Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Add Comment', 'rental-gates')); ?>'; }
        } catch (err) { alert('Error'); btn.disabled = false; btn.innerHTML = '<?php echo esc_js(__('Add Comment', 'rental-gates')); ?>'; }
    });
}

// Close modals
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeRequestModal(); closeDeleteModal(); } });
document.querySelectorAll('.tp-modal-overlay').forEach(o => o.addEventListener('click', function(e) { if (e.target === this) { this.classList.remove('open'); document.body.style.overflow = ''; } }));
</script>
