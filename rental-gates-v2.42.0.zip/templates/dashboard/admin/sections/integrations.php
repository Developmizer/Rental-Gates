<?php
/**
 * Site Admin - Integrations Section
 * 
 * Manage API keys, webhooks, and third-party integrations.
 */
if (!defined('ABSPATH')) exit;

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'api';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['integrations_nonce'])) {
    if (wp_verify_nonce($_POST['integrations_nonce'], 'admin_integrations')) {
        $tab = sanitize_text_field($_POST['settings_tab'] ?? 'api');
        
        if ($tab === 'api') {
            // Regenerate API key if requested
            if (isset($_POST['regenerate_key'])) {
                $new_key = 'rg_' . wp_generate_password(32, false);
                update_option('rental_gates_api_key', $new_key);
            }
            update_option('rental_gates_api_enabled', isset($_POST['api_enabled']) ? '1' : '0');
            update_option('rental_gates_api_rate_limit', intval($_POST['api_rate_limit']));
        }
        
        if ($tab === 'google') {
            update_option('rental_gates_google_maps_key', sanitize_text_field($_POST['google_maps_key']));
            update_option('rental_gates_google_places_enabled', isset($_POST['google_places_enabled']) ? '1' : '0');
        }
        
        if ($tab === 'ai') {
            // Enable/Disable AI Tools (main toggle)
            update_option('rental_gates_enable_ai_tools', isset($_POST['enable_ai_tools']) ? '1' : '0');
            
            // AI Provider selection
            update_option('rental_gates_ai_provider', sanitize_text_field($_POST['ai_provider'] ?? 'openai'));
            
            // OpenAI settings
            if (!empty($_POST['openai_api_key'])) {
                update_option('rental_gates_openai_api_key', sanitize_text_field($_POST['openai_api_key']));
            }
            update_option('rental_gates_openai_model', sanitize_text_field($_POST['openai_model'] ?? 'gpt-4o-mini'));
            
            // Gemini settings
            if (!empty($_POST['gemini_api_key'])) {
                update_option('rental_gates_gemini_api_key', sanitize_text_field($_POST['gemini_api_key']));
            }
            update_option('rental_gates_gemini_model', sanitize_text_field($_POST['gemini_model'] ?? 'gemini-1.5-flash'));
            
            // Credit rollover settings
            update_option('rental_gates_ai_allow_rollover', isset($_POST['allow_rollover']) ? '1' : '0');
            update_option('rental_gates_ai_max_rollover', intval($_POST['max_rollover'] ?? 50));
        }
        
        if ($tab === 'webhooks') {
            update_option('rental_gates_webhook_url', esc_url_raw($_POST['webhook_url']));
            update_option('rental_gates_webhook_secret', sanitize_text_field($_POST['webhook_secret']));
            $events = isset($_POST['webhook_events']) ? array_map('sanitize_text_field', $_POST['webhook_events']) : array();
            update_option('rental_gates_webhook_events', $events);
        }
        
        wp_redirect(add_query_arg(array('tab' => $tab, 'saved' => '1'), home_url('/rental-gates/admin/integrations')));
        exit;
    }
}

// Get settings
$settings = array(
    'api_enabled' => get_option('rental_gates_api_enabled', '0'),
    'api_key' => get_option('rental_gates_api_key', ''),
    'api_rate_limit' => get_option('rental_gates_api_rate_limit', 1000),
    'google_maps_key' => get_option('rental_gates_google_maps_key', ''),
    'google_places_enabled' => get_option('rental_gates_google_places_enabled', '1'),
    // AI Settings - using correct option names
    'enable_ai_tools' => get_option('rental_gates_enable_ai_tools', '0'),
    'ai_provider' => get_option('rental_gates_ai_provider', 'openai'),
    'openai_api_key' => get_option('rental_gates_openai_api_key', ''),
    'openai_model' => get_option('rental_gates_openai_model', 'gpt-4o-mini'),
    'gemini_api_key' => get_option('rental_gates_gemini_api_key', ''),
    'gemini_model' => get_option('rental_gates_gemini_model', 'gemini-1.5-flash'),
    'allow_rollover' => get_option('rental_gates_ai_allow_rollover', '0'),
    'max_rollover' => get_option('rental_gates_ai_max_rollover', 50),
    // Webhooks
    'webhook_url' => get_option('rental_gates_webhook_url', ''),
    'webhook_secret' => get_option('rental_gates_webhook_secret', ''),
    'webhook_events' => get_option('rental_gates_webhook_events', array()),
);

// Generate API key if not exists
if (empty($settings['api_key'])) {
    $settings['api_key'] = 'rg_' . wp_generate_password(32, false);
    update_option('rental_gates_api_key', $settings['api_key']);
}

$webhook_event_options = array(
    'tenant.created' => __('Tenant Created', 'rental-gates'),
    'tenant.updated' => __('Tenant Updated', 'rental-gates'),
    'lease.created' => __('Lease Created', 'rental-gates'),
    'lease.ended' => __('Lease Ended', 'rental-gates'),
    'payment.completed' => __('Payment Completed', 'rental-gates'),
    'payment.failed' => __('Payment Failed', 'rental-gates'),
    'maintenance.created' => __('Maintenance Request Created', 'rental-gates'),
    'maintenance.completed' => __('Maintenance Completed', 'rental-gates'),
    'application.submitted' => __('Application Submitted', 'rental-gates'),
    'application.approved' => __('Application Approved', 'rental-gates'),
);
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Integrations', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <?php if (isset($_GET['saved'])): ?>
    <div class="alert alert-success mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?php _e('Settings saved successfully.', 'rental-gates'); ?>
    </div>
    <?php endif; ?>
    
    <!-- Tabs -->
    <div class="tabs">
        <a href="<?php echo home_url('/rental-gates/admin/integrations?tab=api'); ?>" class="tab <?php echo $current_tab === 'api' ? 'active' : ''; ?>">
            <?php _e('API', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/integrations?tab=google'); ?>" class="tab <?php echo $current_tab === 'google' ? 'active' : ''; ?>">
            <?php _e('Google Maps', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/integrations?tab=ai'); ?>" class="tab <?php echo $current_tab === 'ai' ? 'active' : ''; ?>">
            <?php _e('AI / OpenAI', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/integrations?tab=webhooks'); ?>" class="tab <?php echo $current_tab === 'webhooks' ? 'active' : ''; ?>">
            <?php _e('Webhooks', 'rental-gates'); ?>
        </a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <?php if ($current_tab === 'api'): ?>
            <!-- API Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_integrations', 'integrations_nonce'); ?>
                <input type="hidden" name="settings_tab" value="api">
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="api_enabled" value="1" <?php checked($settings['api_enabled'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable REST API', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('Allow external applications to access data via API.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('API Key', 'rental-gates'); ?></label>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" class="form-input font-mono" value="<?php echo esc_attr($settings['api_key']); ?>" readonly style="flex: 1;">
                        <button type="button" class="btn btn-secondary" onclick="navigator.clipboard.writeText('<?php echo esc_js($settings['api_key']); ?>'); this.textContent='Copied!'; setTimeout(() => this.textContent='Copy', 2000);">
                            <?php _e('Copy', 'rental-gates'); ?>
                        </button>
                    </div>
                    <div class="form-hint"><?php _e('Use this key in the Authorization header.', 'rental-gates'); ?></div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Rate Limit (requests/hour)', 'rental-gates'); ?></label>
                    <input type="number" name="api_rate_limit" class="form-input" value="<?php echo esc_attr($settings['api_rate_limit']); ?>" min="100" max="10000" style="max-width: 200px;">
                </div>
                
                <div style="display: flex; gap: 12px; margin-top: 24px;">
                    <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
                    <button type="submit" name="regenerate_key" value="1" class="btn btn-outline" onclick="return confirm('<?php echo esc_js(__('Are you sure? Existing integrations will stop working.', 'rental-gates')); ?>');">
                        <?php _e('Regenerate Key', 'rental-gates'); ?>
                    </button>
                </div>
            </form>
            
            <?php elseif ($current_tab === 'google'): ?>
            <!-- Google Maps Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_integrations', 'integrations_nonce'); ?>
                <input type="hidden" name="settings_tab" value="google">
                
                <div class="alert alert-info mb-6">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                        <?php _e('Get your API key from the', 'rental-gates'); ?> 
                        <a href="https://console.cloud.google.com/apis/credentials" target="_blank" style="color: inherit; font-weight: 500;">Google Cloud Console</a>.
                        <?php _e('Enable Maps JavaScript API and Places API.', 'rental-gates'); ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Google Maps API Key', 'rental-gates'); ?></label>
                    <input type="text" name="google_maps_key" class="form-input font-mono" value="<?php echo esc_attr($settings['google_maps_key']); ?>" placeholder="AIza...">
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="google_places_enabled" value="1" <?php checked($settings['google_places_enabled'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable Places Autocomplete', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('Allow address autocomplete when adding buildings.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            
            <?php elseif ($current_tab === 'ai'): ?>
            <!-- AI Integration Settings - Comprehensive -->
            <style>
                .ai-settings-grid {
                    display: grid;
                    gap: 24px;
                }
                .ai-settings-card {
                    background: #fff;
                    border: 1px solid var(--gray-200, #e5e7eb);
                    border-radius: 12px;
                    padding: 24px;
                }
                .ai-settings-card.highlight {
                    border-color: var(--primary, #2563eb);
                    background: linear-gradient(135deg, #eff6ff 0%, #fff 100%);
                }
                .ai-card-header {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    margin-bottom: 20px;
                    padding-bottom: 16px;
                    border-bottom: 1px solid var(--gray-100, #f3f4f6);
                }
                .ai-card-icon {
                    width: 40px;
                    height: 40px;
                    border-radius: 10px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-shrink: 0;
                }
                .ai-card-icon svg {
                    width: 20px;
                    height: 20px;
                }
                .ai-card-icon.blue { background: #dbeafe; color: #2563eb; }
                .ai-card-icon.purple { background: #ede9fe; color: #7c3aed; }
                .ai-card-icon.green { background: #d1fae5; color: #059669; }
                .ai-card-icon.amber { background: #fef3c7; color: #d97706; }
                .ai-card-title {
                    font-size: 16px;
                    font-weight: 600;
                    color: var(--gray-900, #111827);
                }
                .ai-card-subtitle {
                    font-size: 13px;
                    color: var(--gray-500, #6b7280);
                    margin-top: 2px;
                }
                .toggle-switch {
                    position: relative;
                    width: 48px;
                    height: 26px;
                    margin-left: auto;
                }
                .toggle-switch input {
                    opacity: 0;
                    width: 0;
                    height: 0;
                }
                .toggle-slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: #cbd5e1;
                    transition: .3s;
                    border-radius: 26px;
                }
                .toggle-slider:before {
                    position: absolute;
                    content: "";
                    height: 20px;
                    width: 20px;
                    left: 3px;
                    bottom: 3px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                }
                .toggle-switch input:checked + .toggle-slider {
                    background-color: #10b981;
                }
                .toggle-switch input:checked + .toggle-slider:before {
                    transform: translateX(22px);
                }
                .provider-cards {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 16px;
                    margin-bottom: 20px;
                }
                .provider-card {
                    border: 2px solid var(--gray-200, #e5e7eb);
                    border-radius: 12px;
                    padding: 20px;
                    cursor: pointer;
                    transition: all 0.2s;
                    position: relative;
                }
                .provider-card:hover {
                    border-color: var(--gray-300, #d1d5db);
                }
                .provider-card.selected {
                    border-color: var(--primary, #2563eb);
                    background: #f0f7ff;
                }
                .provider-card.selected::after {
                    content: '';
                    position: absolute;
                    top: 12px;
                    right: 12px;
                    width: 20px;
                    height: 20px;
                    background: var(--primary, #2563eb);
                    border-radius: 50%;
                    background-image: url("data:image/svg+xml,%3Csvg fill='white' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'/%3E%3C/svg%3E");
                    background-size: 14px;
                    background-position: center;
                    background-repeat: no-repeat;
                }
                .provider-card input[type="radio"] {
                    display: none;
                }
                .provider-logo {
                    height: 32px;
                    margin-bottom: 12px;
                }
                .provider-name {
                    font-weight: 600;
                    color: var(--gray-900, #111827);
                    margin-bottom: 4px;
                }
                .provider-desc {
                    font-size: 13px;
                    color: var(--gray-500, #6b7280);
                }
                .api-key-input-group {
                    position: relative;
                }
                .api-key-input-group input {
                    padding-right: 100px;
                }
                .api-key-actions {
                    position: absolute;
                    right: 8px;
                    top: 50%;
                    transform: translateY(-50%);
                    display: flex;
                    gap: 4px;
                }
                .api-key-actions button {
                    padding: 6px 10px;
                    font-size: 12px;
                    border-radius: 6px;
                    border: none;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .btn-show-key {
                    background: var(--gray-100, #f3f4f6);
                    color: var(--gray-600, #4b5563);
                }
                .btn-show-key:hover {
                    background: var(--gray-200, #e5e7eb);
                }
                .btn-test-key {
                    background: var(--primary, #2563eb);
                    color: white;
                }
                .btn-test-key:hover {
                    background: #1d4ed8;
                }
                .status-indicator {
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    padding: 6px 12px;
                    border-radius: 100px;
                    font-size: 13px;
                    font-weight: 500;
                }
                .status-indicator.connected {
                    background: #d1fae5;
                    color: #065f46;
                }
                .status-indicator.disconnected {
                    background: #fee2e2;
                    color: #991b1b;
                }
                .status-indicator.pending {
                    background: #fef3c7;
                    color: #92400e;
                }
                .status-dot {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: currentColor;
                }
                .credit-config {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 16px;
                }
                @media (max-width: 640px) {
                    .provider-cards, .credit-config {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
            
            <form method="post" action="">
                <?php wp_nonce_field('admin_integrations', 'integrations_nonce'); ?>
                <input type="hidden" name="settings_tab" value="ai">
                
                <div class="ai-settings-grid">
                    <!-- Master Toggle -->
                    <div class="ai-settings-card highlight">
                        <div class="ai-card-header" style="border: none; margin-bottom: 0; padding-bottom: 0;">
                            <div class="ai-card-icon blue">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                            </div>
                            <div>
                                <div class="ai-card-title"><?php _e('AI Tools', 'rental-gates'); ?></div>
                                <div class="ai-card-subtitle"><?php _e('Enable AI-powered features for all organizations', 'rental-gates'); ?></div>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="enable_ai_tools" value="1" <?php checked($settings['enable_ai_tools'], '1'); ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Provider Selection -->
                    <div class="ai-settings-card">
                        <div class="ai-card-header">
                            <div class="ai-card-icon purple">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                            </div>
                            <div>
                                <div class="ai-card-title"><?php _e('AI Provider', 'rental-gates'); ?></div>
                                <div class="ai-card-subtitle"><?php _e('Select your preferred AI service', 'rental-gates'); ?></div>
                            </div>
                        </div>
                        
                        <div class="provider-cards">
                            <label class="provider-card <?php echo $settings['ai_provider'] === 'openai' ? 'selected' : ''; ?>">
                                <input type="radio" name="ai_provider" value="openai" <?php checked($settings['ai_provider'], 'openai'); ?>>
                                <svg class="provider-logo" viewBox="0 0 120 32" fill="currentColor" style="color: #10a37f;">
                                    <path d="M27.09 13.33c-.77-2.82-2.81-5.18-5.48-6.32C19.01 5.9 16 6.24 13.59 7.8c-1.62-1.24-3.63-1.9-5.67-1.86C4.44 5.99 1.4 8.28.35 11.58c-1.05 3.3.14 6.9 2.9 8.79-.77 2.82-.14 5.89 1.67 8.16s4.72 3.54 7.71 3.38c1.62 1.24 3.63 1.9 5.67 1.86 3.48-.05 6.52-2.34 7.57-5.64 1.05-3.3-.14-6.9-2.9-8.79.77-2.82.14-5.89-1.67-8.16s-4.72-3.54-7.71-3.38zm-5.4 18.35c-1.76.77-3.78.55-5.33-.58l.27-.15 7.73-4.46c.39-.22.63-.64.62-1.09v-10.9l3.27 1.89v9.01c0 2.82-2.26 5.14-5.06 5.19-.52.01-1.03-.06-1.52-.19l.02.28zm-13.9-5.34c-.88-1.52-1.13-3.31-.7-5.01l.27.16 7.73 4.46c.39.23.87.23 1.27 0l9.44-5.45v3.78l-7.85 4.53c-2.44 1.41-5.57.58-6.98-1.86-.56-.97-.85-2.07-.84-3.19l-.34.58zm-1.81-12.4c.88-1.53 2.34-2.64 4.06-3.09v9.18c0 .45.24.87.63 1.09l9.44 5.45-3.27 1.89-7.85-4.53c-2.45-1.41-3.28-4.53-1.87-6.98.28-.48.6-.93.97-1.33l-2.11.32zm23.9 5.56l-9.44-5.45 3.27-1.89 7.85 4.53c2.45 1.41 3.28 4.54 1.86 6.99-.56.97-1.39 1.76-2.38 2.28v-9.18c0-.45-.24-.87-.63-1.09l-.53-.19zm3.25-5.05l-.27-.16-7.73-4.46c-.39-.23-.87-.23-1.27 0l-9.44 5.45V11.5l7.85-4.53c2.45-1.41 5.57-.58 6.98 1.86.56.97.85 2.07.84 3.19l3.04 2.43zm-20.45 6.72l-3.27-1.89v-9.01c0-2.83 2.3-5.12 5.13-5.12 1.76 0 3.4.91 4.33 2.4l-.27.15-7.73 4.46c-.39.22-.63.64-.62 1.09l.43 7.92zm1.78-3.83l4.21-2.43 4.21 2.43v4.86l-4.21 2.43-4.21-2.43v-4.86z"/>
                                </svg>
                                <div class="provider-name">OpenAI</div>
                                <div class="provider-desc"><?php _e('GPT-4o, GPT-4 Turbo models', 'rental-gates'); ?></div>
                            </label>
                            
                            <label class="provider-card <?php echo $settings['ai_provider'] === 'gemini' ? 'selected' : ''; ?>">
                                <input type="radio" name="ai_provider" value="gemini" <?php checked($settings['ai_provider'], 'gemini'); ?>>
                                <svg class="provider-logo" viewBox="0 0 120 32" fill="currentColor" style="color: #4285f4;">
                                    <text x="0" y="24" font-family="Arial, sans-serif" font-size="22" font-weight="bold">Gemini</text>
                                </svg>
                                <div class="provider-name">Google Gemini</div>
                                <div class="provider-desc"><?php _e('Gemini 1.5 Flash, Pro models', 'rental-gates'); ?></div>
                            </label>
                        </div>
                    </div>
                    
                    <!-- OpenAI Configuration -->
                    <div class="ai-settings-card" id="openai-config" style="<?php echo $settings['ai_provider'] !== 'openai' ? 'display:none;' : ''; ?>">
                        <div class="ai-card-header">
                            <div class="ai-card-icon green">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                            </div>
                            <div>
                                <div class="ai-card-title"><?php _e('OpenAI Configuration', 'rental-gates'); ?></div>
                                <div class="ai-card-subtitle">
                                    <?php _e('Get your API key from', 'rental-gates'); ?> 
                                    <a href="https://platform.openai.com/api-keys" target="_blank" style="color: var(--primary);">platform.openai.com</a>
                                </div>
                            </div>
                            <?php if (!empty($settings['openai_api_key'])): ?>
                            <span class="status-indicator connected">
                                <span class="status-dot"></span>
                                <?php _e('Configured', 'rental-gates'); ?>
                            </span>
                            <?php else: ?>
                            <span class="status-indicator disconnected">
                                <span class="status-dot"></span>
                                <?php _e('Not Configured', 'rental-gates'); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php _e('API Key', 'rental-gates'); ?></label>
                            <div class="api-key-input-group">
                                <input type="password" name="openai_api_key" id="openai_api_key" class="form-input font-mono" 
                                       value="<?php echo esc_attr($settings['openai_api_key']); ?>" 
                                       placeholder="sk-...">
                                <div class="api-key-actions">
                                    <button type="button" class="btn-show-key" onclick="toggleKeyVisibility('openai_api_key', this)">
                                        <?php _e('Show', 'rental-gates'); ?>
                                    </button>
                                    <button type="button" class="btn-test-key" onclick="testOpenAIKey()">
                                        <?php _e('Test', 'rental-gates'); ?>
                                    </button>
                                </div>
                            </div>
                            <div class="form-hint"><?php _e('Your API key is encrypted and stored securely.', 'rental-gates'); ?></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php _e('Model', 'rental-gates'); ?></label>
                            <select name="openai_model" class="form-select" style="max-width: 300px;">
                                <option value="gpt-4o-mini" <?php selected($settings['openai_model'], 'gpt-4o-mini'); ?>>GPT-4o Mini (Fast & Affordable)</option>
                                <option value="gpt-4o" <?php selected($settings['openai_model'], 'gpt-4o'); ?>>GPT-4o (Most Capable)</option>
                                <option value="gpt-4-turbo" <?php selected($settings['openai_model'], 'gpt-4-turbo'); ?>>GPT-4 Turbo (128K Context)</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Gemini Configuration -->
                    <div class="ai-settings-card" id="gemini-config" style="<?php echo $settings['ai_provider'] !== 'gemini' ? 'display:none;' : ''; ?>">
                        <div class="ai-card-header">
                            <div class="ai-card-icon green">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                            </div>
                            <div>
                                <div class="ai-card-title"><?php _e('Google Gemini Configuration', 'rental-gates'); ?></div>
                                <div class="ai-card-subtitle">
                                    <?php _e('Get your API key from', 'rental-gates'); ?> 
                                    <a href="https://aistudio.google.com/apikey" target="_blank" style="color: var(--primary);">aistudio.google.com</a>
                                </div>
                            </div>
                            <?php if (!empty($settings['gemini_api_key'])): ?>
                            <span class="status-indicator connected">
                                <span class="status-dot"></span>
                                <?php _e('Configured', 'rental-gates'); ?>
                            </span>
                            <?php else: ?>
                            <span class="status-indicator disconnected">
                                <span class="status-dot"></span>
                                <?php _e('Not Configured', 'rental-gates'); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php _e('API Key', 'rental-gates'); ?></label>
                            <div class="api-key-input-group">
                                <input type="password" name="gemini_api_key" id="gemini_api_key" class="form-input font-mono" 
                                       value="<?php echo esc_attr($settings['gemini_api_key']); ?>" 
                                       placeholder="AIza...">
                                <div class="api-key-actions">
                                    <button type="button" class="btn-show-key" onclick="toggleKeyVisibility('gemini_api_key', this)">
                                        <?php _e('Show', 'rental-gates'); ?>
                                    </button>
                                    <button type="button" class="btn-test-key" onclick="testGeminiKey()">
                                        <?php _e('Test', 'rental-gates'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php _e('Model', 'rental-gates'); ?></label>
                            <select name="gemini_model" class="form-select" style="max-width: 300px;">
                                <option value="gemini-1.5-flash" <?php selected($settings['gemini_model'], 'gemini-1.5-flash'); ?>>Gemini 1.5 Flash (Fast)</option>
                                <option value="gemini-1.5-pro" <?php selected($settings['gemini_model'], 'gemini-1.5-pro'); ?>>Gemini 1.5 Pro (Advanced)</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Credit Rollover Settings -->
                    <div class="ai-settings-card">
                        <div class="ai-card-header">
                            <div class="ai-card-icon amber">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                            </div>
                            <div>
                                <div class="ai-card-title"><?php _e('Credit Rollover', 'rental-gates'); ?></div>
                                <div class="ai-card-subtitle"><?php _e('Allow unused subscription credits to roll over', 'rental-gates'); ?></div>
                            </div>
                        </div>
                        
                        <div class="credit-config">
                            <div class="form-group">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                                    <input type="checkbox" name="allow_rollover" value="1" <?php checked($settings['allow_rollover'], '1'); ?> style="width: 20px; height: 20px;">
                                    <div>
                                        <div style="font-weight: 500;"><?php _e('Enable Rollover', 'rental-gates'); ?></div>
                                        <div class="form-hint" style="margin-top: 2px;"><?php _e('Unused credits carry to next billing cycle', 'rental-gates'); ?></div>
                                    </div>
                                </label>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label"><?php _e('Maximum Rollover', 'rental-gates'); ?></label>
                                <input type="number" name="max_rollover" class="form-input" value="<?php echo esc_attr($settings['max_rollover']); ?>" min="0" max="1000" style="max-width: 120px;">
                                <div class="form-hint"><?php _e('Set to 0 for unlimited rollover', 'rental-gates'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 8px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <?php _e('Save AI Settings', 'rental-gates'); ?>
                    </button>
                </div>
            </form>
            
            <script>
            // Provider card selection
            document.querySelectorAll('.provider-card').forEach(card => {
                card.addEventListener('click', function() {
                    document.querySelectorAll('.provider-card').forEach(c => c.classList.remove('selected'));
                    this.classList.add('selected');
                    
                    const provider = this.querySelector('input').value;
                    document.getElementById('openai-config').style.display = provider === 'openai' ? 'block' : 'none';
                    document.getElementById('gemini-config').style.display = provider === 'gemini' ? 'block' : 'none';
                });
            });
            
            // Toggle key visibility
            function toggleKeyVisibility(inputId, btn) {
                const input = document.getElementById(inputId);
                if (input.type === 'password') {
                    input.type = 'text';
                    btn.textContent = '<?php _e('Hide', 'rental-gates'); ?>';
                } else {
                    input.type = 'password';
                    btn.textContent = '<?php _e('Show', 'rental-gates'); ?>';
                }
            }
            
            // Test OpenAI key
            function testOpenAIKey() {
                const key = document.getElementById('openai_api_key').value;
                if (!key) {
                    alert('<?php _e('Please enter an API key first.', 'rental-gates'); ?>');
                    return;
                }
                
                const btn = event.target;
                btn.textContent = '<?php _e('Testing...', 'rental-gates'); ?>';
                btn.disabled = true;
                
                fetch('https://api.openai.com/v1/models', {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + key
                    }
                })
                .then(response => {
                    if (response.ok) {
                        alert('<?php _e('✓ API key is valid!', 'rental-gates'); ?>');
                    } else {
                        alert('<?php _e('✗ Invalid API key. Please check and try again.', 'rental-gates'); ?>');
                    }
                })
                .catch(() => {
                    alert('<?php _e('✗ Could not verify API key. Please check your connection.', 'rental-gates'); ?>');
                })
                .finally(() => {
                    btn.textContent = '<?php _e('Test', 'rental-gates'); ?>';
                    btn.disabled = false;
                });
            }
            
            // Test Gemini key
            function testGeminiKey() {
                const key = document.getElementById('gemini_api_key').value;
                if (!key) {
                    alert('<?php _e('Please enter an API key first.', 'rental-gates'); ?>');
                    return;
                }
                
                const btn = event.target;
                btn.textContent = '<?php _e('Testing...', 'rental-gates'); ?>';
                btn.disabled = true;
                
                fetch('https://generativelanguage.googleapis.com/v1/models?key=' + key)
                .then(response => {
                    if (response.ok) {
                        alert('<?php _e('✓ API key is valid!', 'rental-gates'); ?>');
                    } else {
                        alert('<?php _e('✗ Invalid API key. Please check and try again.', 'rental-gates'); ?>');
                    }
                })
                .catch(() => {
                    alert('<?php _e('✗ Could not verify API key. Please check your connection.', 'rental-gates'); ?>');
                })
                .finally(() => {
                    btn.textContent = '<?php _e('Test', 'rental-gates'); ?>';
                    btn.disabled = false;
                });
            }
            </script>
            
            <?php elseif ($current_tab === 'webhooks'): ?>
            <!-- Webhook Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_integrations', 'integrations_nonce'); ?>
                <input type="hidden" name="settings_tab" value="webhooks">
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Webhook URL', 'rental-gates'); ?></label>
                    <input type="url" name="webhook_url" class="form-input" value="<?php echo esc_attr($settings['webhook_url']); ?>" placeholder="https://your-server.com/webhook">
                    <div class="form-hint"><?php _e('POST requests will be sent to this URL.', 'rental-gates'); ?></div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Webhook Secret', 'rental-gates'); ?></label>
                    <input type="text" name="webhook_secret" class="form-input font-mono" value="<?php echo esc_attr($settings['webhook_secret']); ?>" placeholder="whsec_...">
                    <div class="form-hint"><?php _e('Used to sign webhook payloads for verification.', 'rental-gates'); ?></div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Events to Send', 'rental-gates'); ?></label>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-top: 8px;">
                        <?php foreach ($webhook_event_options as $event => $label): ?>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="webhook_events[]" value="<?php echo esc_attr($event); ?>" <?php checked(in_array($event, $settings['webhook_events'])); ?>>
                            <span><?php echo esc_html($label); ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
