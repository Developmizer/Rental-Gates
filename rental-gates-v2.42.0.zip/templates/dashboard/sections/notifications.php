<?php
/**
 * Notifications Center
 */
if (!defined('ABSPATH')) exit;

$current_user_id = get_current_user_id();
$org_id = Rental_Gates_Roles::get_organization_id();

// Handle actions
if (isset($_GET['action']) && isset($_GET['id']) && wp_verify_nonce($_GET['_wpnonce'] ?? '', 'notification_action')) {
    $notification_id = intval($_GET['id']);
    
    if ($_GET['action'] === 'read') {
        Rental_Gates_Notification::mark_read($notification_id, $current_user_id);
    } elseif ($_GET['action'] === 'delete') {
        Rental_Gates_Notification::delete($notification_id, $current_user_id);
    }
    
    wp_redirect(remove_query_arg(array('action', 'id', '_wpnonce')));
    exit;
}

// Mark all as read
if (isset($_POST['mark_all_read']) && wp_verify_nonce($_POST['_wpnonce'], 'mark_all_read')) {
    Rental_Gates_Notification::mark_all_read($current_user_id);
    wp_redirect(home_url('/rental-gates/dashboard/notifications'));
    exit;
}

// Get filter parameters
$filter = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : 'all';

$args = array(
    'limit' => 50,
    'order' => 'DESC',
);

if ($filter === 'unread') {
    $args['is_read'] = 0;
} elseif ($filter === 'read') {
    $args['is_read'] = 1;
}

$notifications = Rental_Gates_Notification::get_for_user($current_user_id, $args);
$unread_count = Rental_Gates_Notification::get_unread_count($current_user_id);

// Group notifications by date
$grouped = array();
foreach ($notifications as $notification) {
    $date = date('Y-m-d', strtotime($notification['created_at']));
    if ($date === date('Y-m-d')) {
        $group = __('Today', 'rental-gates');
    } elseif ($date === date('Y-m-d', strtotime('-1 day'))) {
        $group = __('Yesterday', 'rental-gates');
    } elseif (strtotime($date) > strtotime('-7 days')) {
        $group = __('This Week', 'rental-gates');
    } elseif (strtotime($date) > strtotime('-30 days')) {
        $group = __('This Month', 'rental-gates');
    } else {
        $group = __('Older', 'rental-gates');
    }
    
    if (!isset($grouped[$group])) {
        $grouped[$group] = array();
    }
    $grouped[$group][] = $notification;
}

// Get notification icon based on type
function get_notification_icon($type) {
    $icons = array(
        'lease' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
        'payment' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        'maintenance' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>',
        'application' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>',
        'tenant' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>',
        'vendor' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>',
        'announcement' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/>',
        'system' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    );
    
    // Determine icon category from type
    if (strpos($type, 'lease') !== false) return $icons['lease'];
    if (strpos($type, 'payment') !== false || strpos($type, 'late_fee') !== false) return $icons['payment'];
    if (strpos($type, 'maintenance') !== false) return $icons['maintenance'];
    if (strpos($type, 'application') !== false) return $icons['application'];
    if (strpos($type, 'tenant') !== false) return $icons['tenant'];
    if (strpos($type, 'vendor') !== false) return $icons['vendor'];
    if ($type === 'announcement') return $icons['announcement'];
    
    return $icons['system'];
}

function get_notification_color($type) {
    if (strpos($type, 'overdue') !== false || strpos($type, 'terminated') !== false || strpos($type, 'expired') !== false || strpos($type, 'late_fee') !== false) {
        return '#ef4444';
    }
    if (strpos($type, 'expiring') !== false || strpos($type, 'reminder') !== false || strpos($type, 'due') !== false) {
        return '#f59e0b';
    }
    if (strpos($type, 'completed') !== false || strpos($type, 'received') !== false || strpos($type, 'activated') !== false || strpos($type, 'approved') !== false) {
        return '#10b981';
    }
    return '#6b7280';
}
?>

<style>
    .rg-notifications-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-notifications-header h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; display: flex; align-items: center; gap: 12px; }
    .rg-unread-badge { background: #ef4444; color: #fff; font-size: 12px; font-weight: 600; padding: 2px 8px; border-radius: 10px; }
    
    .rg-notifications-actions { display: flex; gap: 12px; align-items: center; }
    
    .rg-filter-tabs { display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: 8px; }
    .rg-filter-tab { padding: 8px 16px; border-radius: 6px; font-size: 14px; text-decoration: none; color: var(--gray-600); transition: all 0.2s; }
    .rg-filter-tab:hover { color: var(--gray-900); }
    .rg-filter-tab.active { background: #fff; color: var(--gray-900); box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    
    .rg-notifications-container { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    
    .rg-notification-group { border-bottom: 1px solid var(--gray-100); }
    .rg-notification-group:last-child { border-bottom: none; }
    .rg-notification-group-title { padding: 12px 20px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; }
    
    .rg-notification-item { display: flex; gap: 16px; padding: 16px 20px; border-bottom: 1px solid var(--gray-100); transition: background 0.2s; }
    .rg-notification-item:last-child { border-bottom: none; }
    .rg-notification-item:hover { background: var(--gray-50); }
    .rg-notification-item.unread { background: #eff6ff; }
    .rg-notification-item.unread:hover { background: #dbeafe; }
    
    .rg-notification-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-notification-icon svg { width: 20px; height: 20px; }
    
    .rg-notification-content { flex: 1; min-width: 0; }
    .rg-notification-title { font-size: 14px; font-weight: 600; color: var(--gray-900); margin-bottom: 4px; }
    .rg-notification-message { font-size: 14px; color: var(--gray-600); margin-bottom: 6px; }
    .rg-notification-meta { font-size: 12px; color: var(--gray-400); display: flex; align-items: center; gap: 8px; }
    .rg-notification-type { padding: 2px 6px; background: var(--gray-100); border-radius: 4px; font-size: 11px; }
    
    .rg-notification-actions { display: flex; gap: 8px; flex-shrink: 0; }
    .rg-notification-action { padding: 8px; border: none; background: none; cursor: pointer; color: var(--gray-400); border-radius: 6px; transition: all 0.2s; }
    .rg-notification-action:hover { background: var(--gray-100); color: var(--gray-600); }
    .rg-notification-action.danger:hover { background: #fee2e2; color: #dc2626; }
    .rg-notification-action svg { width: 16px; height: 16px; display: block; }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { font-size: 18px; color: var(--gray-700); margin-bottom: 8px; }
    .rg-empty-state p { color: var(--gray-500); }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; text-decoration: none; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
    .rg-btn-secondary:hover { background: var(--gray-50); }
    .rg-btn svg { width: 16px; height: 16px; }
    
    @media (max-width: 768px) {
        .rg-notifications-header { flex-direction: column; align-items: flex-start; }
        .rg-notifications-actions { width: 100%; justify-content: space-between; }
    }
</style>

<!-- Header -->
<div class="rg-notifications-header">
    <h1>
        <?php _e('Notifications', 'rental-gates'); ?>
        <?php if ($unread_count > 0): ?>
            <span class="rg-unread-badge"><?php echo $unread_count; ?> <?php _e('unread', 'rental-gates'); ?></span>
        <?php endif; ?>
    </h1>
    
    <div class="rg-notifications-actions">
        <div class="rg-filter-tabs">
            <a href="<?php echo esc_url(add_query_arg('filter', 'all')); ?>" class="rg-filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>"><?php _e('All', 'rental-gates'); ?></a>
            <a href="<?php echo esc_url(add_query_arg('filter', 'unread')); ?>" class="rg-filter-tab <?php echo $filter === 'unread' ? 'active' : ''; ?>"><?php _e('Unread', 'rental-gates'); ?></a>
            <a href="<?php echo esc_url(add_query_arg('filter', 'read')); ?>" class="rg-filter-tab <?php echo $filter === 'read' ? 'active' : ''; ?>"><?php _e('Read', 'rental-gates'); ?></a>
        </div>
        
        <?php if ($unread_count > 0): ?>
        <form method="post" style="display: inline;">
            <?php wp_nonce_field('mark_all_read'); ?>
            <button type="submit" name="mark_all_read" class="rg-btn rg-btn-secondary">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <?php _e('Mark All Read', 'rental-gates'); ?>
            </button>
        </form>
        <?php endif; ?>
    </div>
</div>

<!-- Notifications -->
<div class="rg-notifications-container">
    <?php if (empty($notifications)): ?>
    <div class="rg-empty-state">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
        <h3><?php _e('No notifications', 'rental-gates'); ?></h3>
        <p><?php _e('You\'re all caught up! Check back later for updates.', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
        <?php foreach ($grouped as $group_name => $group_notifications): ?>
        <div class="rg-notification-group">
            <div class="rg-notification-group-title"><?php echo esc_html($group_name); ?></div>
            
            <?php foreach ($group_notifications as $notification): 
                $icon_color = get_notification_color($notification['type']);
            ?>
            <div class="rg-notification-item <?php echo !$notification['is_read'] ? 'unread' : ''; ?>">
                <div class="rg-notification-icon" style="background: <?php echo $icon_color; ?>20; color: <?php echo $icon_color; ?>;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <?php echo get_notification_icon($notification['type']); ?>
                    </svg>
                </div>
                
                <div class="rg-notification-content">
                    <div class="rg-notification-title"><?php echo esc_html($notification['title']); ?></div>
                    <?php if ($notification['message']): ?>
                    <div class="rg-notification-message"><?php echo esc_html($notification['message']); ?></div>
                    <?php endif; ?>
                    <div class="rg-notification-meta">
                        <span><?php echo esc_html($notification['time_ago']); ?></span>
                        <span class="rg-notification-type"><?php echo esc_html($notification['type_label']); ?></span>
                    </div>
                </div>
                
                <div class="rg-notification-actions">
                    <?php if ($notification['action_url']): ?>
                    <a href="<?php echo esc_url($notification['action_url']); ?>" class="rg-notification-action" title="<?php _e('View', 'rental-gates'); ?>">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    </a>
                    <?php endif; ?>
                    
                    <?php if (!$notification['is_read']): ?>
                    <a href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('action' => 'read', 'id' => $notification['id'])), 'notification_action')); ?>" class="rg-notification-action" title="<?php _e('Mark as Read', 'rental-gates'); ?>">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    </a>
                    <?php endif; ?>
                    
                    <a href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('action' => 'delete', 'id' => $notification['id'])), 'notification_action')); ?>" class="rg-notification-action danger" title="<?php _e('Delete', 'rental-gates'); ?>" onclick="return confirm('<?php echo esc_js(__('Delete this notification?', 'rental-gates')); ?>');">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
