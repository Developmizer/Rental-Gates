# Rental Gates - Changelog

All notable changes to Rental Gates are documented in this file.

---

## [2.41.0] - 2026-01-XX

### Added - Marketing System Enhancements

#### PDF Flyer Generation
- Converted flyer generation from HTML to print-optimized format
- Added organization branding support (logo, custom colors, fonts)
- Implemented flyer preview functionality before generation
- Enhanced flyer templates with better print optimization and @media print styles
- Added support for custom branding colors per organization

#### Enhanced QR Code Analytics
- Added geographic breakdown (country-level tracking)
- Implemented hourly distribution analysis
- Added growth percentage calculations vs previous period
- Enhanced conversion tracking (QR scan → Lead → Application → Lease)
- Added organization-wide QR analytics with top performing codes
- Implemented daily trend analysis for scans and leads

#### Lead Scoring System
- Created comprehensive lead scoring algorithm with configurable rules
- Implemented behavioral and engagement scoring
- Added property interest scoring (single vs multiple properties, high-value)
- Created priority levels (hot, warm, cool, cold) based on score
- Added score breakdown and history tracking
- Implemented automatic score calculation on lead events
- Added lead scoring database table and model

#### Marketing Analytics Dashboard
- Created comprehensive marketing analytics dashboard (`marketing-analytics.php`)
- Implemented conversion funnel visualization with step-by-step tracking
- Added ROI tracking and calculations
- Created lead source performance metrics with charts
- Added QR code performance tracking
- Implemented time-series charts using Chart.js
- Added daily lead trend analysis
- Created leads by source and stage breakdowns with visualizations

#### Conversion Tracking
- Implemented end-to-end conversion tracking from QR scan to lease
- Added attribution modeling (first-touch, last-touch, multi-touch)
- Created conversion funnel analysis with rate calculations
- Added scan-to-lease conversion tracking
- Implemented conversion rate calculations at each funnel stage

#### Campaign Management System
- Created marketing campaign management system
- Added campaign goals and KPIs tracking
- Implemented multi-channel campaign support (QR, Flyer, Email, Social, Multi)
- Added budget tracking and ROI calculations
- Created campaign performance metrics
- Added campaign status management (draft, active, paused, completed, cancelled)
- Implemented campaign database table and model

#### Marketing Automation
- Created marketing automation system with trigger-based actions
- Implemented automated email sequences
- Created lead nurturing workflows
- Added automated follow-up reminders
- Implemented automation rules management
- Created default automation rules (welcome emails, follow-ups)
- Added triggers: new_lead, lead_stage_change, qr_scan, application_submitted, follow_up_due, no_activity
- Added actions: send_email, update_stage, assign_to, add_note, create_task

#### Email Marketing Integration
- Created email marketing integration class
- Added Mailchimp integration support
- Added SendGrid integration support
- Implemented automatic lead syncing to email platforms
- Added generic SMTP/API support structure

#### Social Media Integration
- Created social media integration class
- Added Facebook posting support
- Added LinkedIn posting support
- Created structure for Instagram and Twitter (placeholders for future implementation)
- Added scheduled post support structure

#### Database Enhancements
- Added `rg_lead_scores` table for lead scoring history and breakdowns
- Added `rg_marketing_campaigns` table for campaign management
- Added `rg_marketing_automation_rules` table for automation workflows
- Enhanced existing marketing tables with new fields

#### UI/UX Improvements
- Enhanced marketing dashboard with modern, data-driven design
- Added real-time analytics widgets and metrics cards
- Improved QR code management interface with better visualizations
- Enhanced flyer creation workflow with preview functionality
- Added conversion funnel visualization
- Improved mobile responsiveness across all marketing pages
- Added period selector for analytics (day, week, month, quarter, year)

#### AJAX Handlers
- Added `rental_gates_flyer_preview` handler for flyer previews
- Added `rental_gates_calculate_lead_score` handler for lead scoring
- Added `rental_gates_get_marketing_analytics` handler for analytics data

### Changed
- Flyer generation now uses print-optimized templates with better branding support
- QR analytics now include comprehensive conversion tracking
- Lead model now triggers automation and email marketing sync on creation
- Marketing dashboard redesigned for better data visualization and user experience
- Analytics tab in marketing section now redirects to full analytics dashboard

### Fixed
- Fixed flyer generation to properly support branding customization
- Improved QR code analytics accuracy with better data aggregation
- Enhanced lead scoring calculation accuracy with proper rule application
- Fixed conversion tracking data consistency across funnel stages

## [2.40.0] - 2026-01-11

### Added
- **Landing Page Dual-Audience Redesign**: Complete transformation to serve both renters and property managers
  - **Dual-Audience Hero Section**:
    - Split hero design with two distinct cards (Renter and Owner)
    - Visual separation with different styling and colors
    - Clear CTAs for each audience type
    - Responsive grid layout (stacks on mobile)
  - **Enhanced Navigation**:
    - "Browse Properties" link added to main navigation with map icon
    - Prominent positioning as first nav item
    - Mobile menu includes map link
  - **Renter-Focused Section**:
    - New "Discover Your Next Home" section
    - 4 feature cards highlighting property discovery features
    - Dynamic property count display
    - Large CTA button linking to map page
  - **Owner Section Enhancement**:
    - Updated header: "For Property Managers & Owners"
    - Added CTA button: "Start Managing Properties"
  - **Dual CTA Section**:
    - Replaced single CTA with two side-by-side cards
    - Renter card: "Looking for a Rental?" → "Browse Available Properties"
    - Owner card: "Manage Properties?" → "Start Free Trial"
  - **SEO & Accessibility Improvements**:
    - Enhanced meta description for both audiences
    - Open Graph and Twitter Card tags
    - Structured data (Organization, WebSite)
    - Skip link for accessibility
    - ARIA labels on all CTAs
    - Canonical URL
  - **Performance Optimizations**:
    - Optimized font loading with media="print" and onload
    - Preload hints for map page on hover
    - Lazy loading for footer images
    - Proper width/height attributes
  - **Mobile Enhancements**:
    - Floating action button (FAB) for "Browse Map" on mobile
    - Full-width CTAs on mobile for better tap targets
    - Responsive dual-audience hero (stacks vertically)
  - **Admin Settings**:
    - New customization options: `rental_gates_landing_hero_renter_title`
    - New customization options: `rental_gates_landing_hero_owner_title`
    - New customization options: `rental_gates_landing_map_cta_text`
    - New section visibility: `rental_gates_landing_show_renter_section`
  - **Minimal Theme Updates**:
    - Added map link to navigation
    - Updated hero to include dual-audience CTAs
    - Consistent dual-audience messaging

### Changed
- Landing page hero title default: "Find Your Perfect Rental or Manage Your Properties"
- Landing page subtitle now addresses both audiences
- Property count now dynamically fetched from database
- All landing page templates updated to version 2.40.0

### Fixed
- Clear entry point for renters to discover properties
- Missing links to map/property discovery experience
- Improved user journey for both audiences from first screen

---

## [2.39.0] - 2026-01-11

### Added
- **Public Map Page Enhancement**: Complete redesign with modern UI/UX and comprehensive features
  - **View Mode Toggle**: 
    - Full-screen map mode
    - List-only view mode
    - Split view (map + sidebar)
    - View mode persistence in localStorage and URL hash
    - Keyboard shortcuts (M for map, L for list, S for split)
  - **Enhanced List View**:
    - Grid layout (2-3 columns on desktop)
    - Compact list view option
    - List view mode toggle (grid/compact)
    - Sticky filters header when scrolling
  - **Advanced Filtering**:
    - Bathrooms filter (1+, 1.5+, 2+, 2.5+, 3+)
    - Square footage range filter (min/max)
    - Availability filter (Available Now, Coming Soon)
    - Active filter badges with individual remove buttons
    - Filter count indicator
    - "Clear all" functionality
    - Filters persist in URL parameters
  - **Enhanced Search**:
    - Autocomplete with Nominatim integration
    - Search suggestions dropdown
    - Recent searches (last 10, stored in localStorage)
    - Keyboard navigation (Arrow keys, Enter, Escape)
    - Popular locations support
  - **Sorting Options**:
    - Sort by price (low-high, high-low)
    - Sort by bedrooms (low-high, high-low)
    - Sort by name (A-Z)
    - Visual sort indicators
    - Sort preference persists in URL
  - **Mobile Optimization**:
    - Mobile floating controls (Map/List toggle)
    - Swipe gestures for sidebar drawer
    - Bottom sheet for list view
    - Full-screen map with floating controls
    - Touch-friendly controls
    - Responsive breakpoints
  - **My Location Feature**:
    - "Find my location" button
    - Geolocation API integration
    - Error handling for location permissions
    - Loading states
  - **Loading States**:
    - Skeleton loaders for listings
    - Loading spinner for map markers
    - Smooth transitions
  - **Error Handling**:
    - Error toast notifications
    - Graceful degradation
    - Network error handling
    - Improved empty states
  - **Accessibility Improvements**:
    - ARIA labels for all interactive elements
    - Keyboard navigation support
    - Screen reader compatibility
    - Focus management
    - High contrast mode support
    - Semantic HTML structure
  - **Performance Optimizations**:
    - Debounced search input (300ms)
    - Lazy loading for images
    - Image error handling
    - Optimized marker rendering
    - Viewport-based rendering
  - **URL State Management**:
    - Filters sync to URL parameters
    - View mode syncs to URL hash
    - Sort preference in URL
    - Shareable URLs with filters
    - Browser back/forward support
    - Filters restore from URL on page load

### Improved
- **Map Interface**:
  - Better marker clustering
  - Improved popup design
  - Smooth animations
  - Better visual hierarchy
- **List View**:
  - Enhanced card design with hover effects
  - Better image handling with lazy loading
  - Improved metadata display (bathrooms, square footage)
  - Better responsive grid layout
- **Filter UI**:
  - Collapsible filter sections
  - Better filter menu design
  - Active filter visual indicators
  - Improved filter button states
- **Search Experience**:
  - Faster autocomplete response
  - Better suggestion formatting
  - Improved keyboard navigation
  - Better mobile search experience
- **Mobile Experience**:
  - Native app-like interface
  - Better touch interactions
  - Improved sidebar drawer
  - Better mobile controls placement
- **Code Quality**:
  - Modular JavaScript functions
  - Reusable CSS components
  - Better error boundaries
  - Comprehensive code comments
  - Improved code organization

### Fixed
- Map not resizing properly when switching view modes
- Filters not persisting across page reloads
- Search not working properly on mobile
- Accessibility issues with keyboard navigation
- Image loading errors not handled gracefully
- Mobile sidebar not responding to gestures properly

---

## [2.38.0] - 2026-01-11

### Added
- **Advanced Reports Section**: Comprehensive reporting with multiple chart types and export options
  - **Enhanced Financial Reports**: 
    - Interactive 12-month revenue trend line chart
    - Revenue by type donut chart with Chart.js
    - Revenue by building horizontal bar chart
    - Growth indicators (MoM percentages)
    - Export buttons for all charts
  - **Enhanced Occupancy Reports**:
    - Units by status donut chart
    - Occupancy by building tables with progress bars
    - Average days vacant metric
    - Vacancy rate tracking
  - **Enhanced Maintenance Reports**:
    - Work orders by category bar chart
    - Work orders by status donut chart
    - Average response and completion time metrics
    - Building-level maintenance statistics
  - **Export Functionality**:
    - CSV export for all report types (Financial, Occupancy, Maintenance)
    - PDF export with print-friendly HTML layout
    - Chart export as PNG images
    - Table export as CSV files
    - Export buttons on all charts and tables
  - **Analytics Integration**: Reports now use the new `Rental_Gates_Analytics` class for consistent data aggregation

### Improved
- **Reports Dashboard**:
  - All charts converted from static SVG to interactive Chart.js visualizations
  - Better tooltips with formatted currency and percentages
  - Responsive chart containers
  - Professional styling with gradients and animations
  - Period-based filtering (month, quarter, year)
  - Enhanced metric cards with trend indicators
- **Export System**:
  - Unified export handler supporting CSV and PDF formats
  - Print-friendly PDF layout with proper styling
  - Excel-compatible CSV with UTF-8 BOM
  - Organized export buttons in report headers
- **Data Visualization**:
  - Line charts for trends (revenue)
  - Bar charts for comparisons (revenue by building, work orders by category)
  - Donut charts for distributions (revenue by type, units by status, work orders by status)
  - All charts include export functionality

### Technical
- **Export Handler Enhancement**: Updated `handle_report_export()` to support both CSV and PDF formats
- **Chart.js Integration**: Properly integrated across all report sections
- **Analytics Class Usage**: Reports now leverage centralized analytics calculations
- **Export Functions**: Added JavaScript functions for chart and table exports

---

## [2.37.0] - 2026-01-11

### Added
- **Advanced Analytics Dashboard**: Comprehensive analytics system with interactive charts and insights
  - **Analytics Helper Class**: New `Rental_Gates_Analytics` class for data aggregation and calculations
  - **Financial Analytics**: Revenue trends, collection rates, growth metrics, revenue by building/type
  - **Occupancy Analytics**: Occupancy rates, vacancy tracking, average days vacant, building-level occupancy
  - **Maintenance Analytics**: Work order statistics, response times, completion times, priority breakdowns
  - **Revenue Trend Chart**: Interactive 12-month revenue trend with line chart visualization
  - **Revenue by Building Chart**: Horizontal bar chart showing revenue breakdown by building
  - **Growth Indicators**: Month-over-month and period-over-period growth percentages on metric cards
  - **Period Selector**: Dropdown to filter analytics by period (7 days, 30 days, month, quarter, year)
  - **Chart Export**: Export charts as PNG images with one-click download
  - **Enhanced Metrics**: Improved metric cards with growth trends and comparative data

### Improved
- **Overview Dashboard**: Enhanced with:
  - Interactive Chart.js line charts replacing static CSS bars
  - Real-time growth calculations and trend indicators
  - Better data visualization with tooltips and formatting
  - Period-based filtering for flexible date ranges
  - Revenue breakdown by building visualization
- **Chart Integration**: 
  - Chart.js properly enqueued for dashboard pages
  - Better chart styling with gradients and animations
  - Responsive chart containers
  - Professional tooltips with formatted currency
- **Data Aggregation**: 
  - Centralized analytics calculations in helper class
  - Support for multiple date range types
  - Previous period comparison calculations
  - Efficient database queries with proper indexing

### Technical
- **Analytics Class**: New `includes/class-rental-gates-analytics.php` with methods:
  - `get_financial_analytics()` - Comprehensive financial data
  - `get_occupancy_analytics()` - Occupancy metrics and trends
  - `get_revenue_trend()` - Multi-month revenue trend data
  - `get_maintenance_analytics()` - Maintenance statistics
  - Date range calculation helpers
  - Previous period comparison logic

---

## [2.36.0] - 2026-01-11

### Added
- **Modern Email Template System**: Complete redesign of all email templates with professional, modern design
  - **Full Dark Mode Support**: All emails automatically adapt to user's dark mode preference with proper color schemes
  - **Responsive Design**: Fully responsive across all devices and screen sizes with mobile-optimized layouts
  - **Accessibility Improvements**: WCAG AA compliant contrast ratios, semantic HTML, ARIA labels, and proper heading structure
  - **Email Client Compatibility**: Optimized for Gmail, Outlook, Apple Mail, Yahoo Mail, and other major email clients
  - **Modern Typography**: System font stack for consistent rendering across platforms
  - **Enhanced Helper Methods**: Updated button, info_box, detail_row, and divider methods with dark mode support

### Improved
- **Email Wrapper Layout**: Enhanced base email layout with:
  - Comprehensive dark mode color scheme with proper contrast ratios
  - Mobile-responsive padding and spacing
  - Better email client compatibility (MSO conditional comments, proper table structure)
  - Improved accessibility with ARIA roles and semantic HTML
  - Better text rendering with word-break and line-height optimizations
- **Email Templates**: Redesigned key templates:
  - `subscription_confirmed.php`: Modern design with clear hierarchy and dark mode support
  - `welcome.php`: Enhanced feature cards with responsive layout
  - `payment_receipt.php`: Clean, professional receipt design
  - `password_reset.php`: Secure, accessible password reset flow
  - `payment_failed.php`: Clear error messaging with actionable steps
  - `generic.php`: Improved fallback template
- **Button Component**: Enhanced with:
  - Dark mode color variants
  - Mobile-responsive sizing
  - Better accessibility (rel="noopener noreferrer")
  - Improved email client compatibility
- **Info Box Component**: Enhanced with:
  - Dark mode color schemes for all variants (info, success, warning, danger, gray)
  - Mobile-responsive padding
  - Better contrast ratios for readability
- **Detail Row Component**: Enhanced with:
  - Dark mode text colors
  - Mobile-responsive layout
  - Better spacing and typography
- **Details Table**: Enhanced with:
  - Dark mode border colors
  - Mobile-responsive padding
  - Better table structure for email clients

### Fixed
- **Dark Mode Rendering**: Fixed color issues in dark mode across all email components
- **Mobile Responsiveness**: Fixed layout issues on small screens with proper media queries
- **Email Client Compatibility**: Fixed rendering issues in Outlook and other email clients
- **Accessibility**: Fixed contrast ratio issues and improved semantic structure
- **Typography**: Fixed font rendering across different email clients

---

## [2.35.0] - 2026-01-11

### Added
- **Comprehensive Payment Method Management**: Complete system for users to manage their saved payment methods
  - **Payment Methods View**: New dedicated page (`/rental-gates/dashboard/billing?view=payment`) for managing payment methods
  - **View Saved Methods**: Display all saved payment methods with card brand, last 4 digits, and expiration date
  - **Add New Payment Method**: Secure card input using Stripe Elements with real-time validation
  - **Set Default Payment Method**: Mark any payment method as default for future charges
  - **Update Subscription Payment Method**: Change which payment method is used for active subscriptions
  - **Delete Payment Methods**: Remove saved payment methods (with protection against deleting active subscription payment method)
  - **Visual Indicators**: Shows which payment method is default and which is currently active for subscription
  - **Auto-Sync**: Automatically syncs payment methods from Stripe to ensure data is up-to-date
  - **Card Brand Icons**: Visual representation of card brands (Visa, Mastercard, Amex, generic)
  - **Responsive Design**: Works beautifully on desktop and mobile devices

### Improved
- **Payment Method Sync**: Enhanced sync logic to update existing payment methods with latest info from Stripe
- **Default Payment Method**: Setting default now also updates Stripe customer's default payment method
- **Delete Protection**: Prevents deleting payment methods that are currently being used by active subscriptions
- **Error Handling**: Better error messages and user feedback for all payment method operations
- **Stripe Integration**: Improved integration with Stripe to ensure payment methods are properly attached to customers

### Fixed
- **Payment Method Attachment**: Ensured payment methods are properly attached to Stripe customers when added
- **Subscription Payment Method Update**: Fixed issue where updating subscription payment method wasn't working correctly

---

## [2.34.2] - 2026-01-11

### Fixed
- **Subscription Confirmation Email Not Sending**: Fixed multiple issues preventing subscription confirmation emails from being sent
  - **Email Address Retrieval**: Improved email address lookup to use current user email first, then owner email, then organization contact email
  - **Error Handling**: Added comprehensive error logging throughout the email sending process
  - **Email Validation**: Added validation for email addresses before sending
  - **Template Verification**: Added checks to ensure email template is found and rendered correctly
  - **Logging**: Added detailed logging at each step to help diagnose email delivery issues
  - **Fallback Logic**: Multiple fallback methods to find the correct user email address

### Improved
- **Email Debugging**: Added extensive logging to help identify email delivery issues
  - Logs when email is attempted
  - Logs email address used
  - Logs template name and subject
  - Logs success/failure status
  - Logs any errors encountered

---

## [2.34.1] - 2026-01-11

### Fixed
- **Downgrade Error for Incomplete Subscriptions**: Fixed error when trying to downgrade a subscription in `incomplete` or `pending_payment` status
  - **Root Cause**: Stripe doesn't allow plan changes on subscriptions with incomplete/pending status
  - **Fix**: Automatically cancels incomplete/pending subscriptions and creates a new subscription for the selected plan
  - **Handles**: `incomplete`, `incomplete_expired`, and `pending_payment` statuses
  - **User Experience**: Downgrade now works seamlessly without showing error messages

---

## [2.34.0] - 2026-01-11

### Added
- **Subscription Confirmation Email**: Users now receive a professional, responsive email after subscribing to a plan
  - **Features**:
    - Beautiful, responsive design with inline styles for maximum email client compatibility
    - Displays plan name, billing cycle, amount, and next billing date
    - Includes subscription ID for reference
    - Provides helpful next steps and links to dashboard
    - Uses the existing Rental Gates email system for consistency
  - **Triggers**: Email is sent automatically when:
    - User subscribes to a new plan
    - User upgrades or downgrades their plan
  - **Template**: Located at `templates/emails/subscription_confirmed.php`
  - **Customization**: Can be overridden by adding template to theme at `your-theme/rental-gates/emails/subscription_confirmed.php`

---

## [2.33.5] - 2026-01-11

### Fixed
- **Critical Parse Error**: Fixed syntax error caused by duplicate `endif` statement in billing.php
- **Cancelled Subscription Not Showing**: Fixed issue where cancelled subscriptions with future period_end weren't being found
  - **Root Cause**: Query excluded cancelled subscriptions even when period_end was in the future
  - **Fix**: Updated query to include cancelled subscriptions where `current_period_end > now()`
  - **Additional Fix**: Updated sync function to keep status as 'active' if period hasn't ended yet, even if Stripe returns 'canceled'
  - This ensures users maintain access until their paid period actually expires

---

## [2.33.4] - 2026-01-11

### Fixed
- **Resume Button Not Showing After Cancel**: Fixed issue where Resume button didn't appear after canceling subscription
  - **Root Cause**: Cancel function was setting status to 'cancelled', which excluded the subscription from queries
  - **Fix**: Keep status as 'active' when canceling (only set `cancel_at_period_end = 1`)
  - **Additional Fixes**:
    - Updated subscription query to include subscriptions with `cancel_at_period_end = 1`
    - Updated resume subscription query to find subscriptions scheduled to cancel
  - Status will only change to 'cancelled' when the billing period actually ends (via webhook)

---

## [2.33.3] - 2026-01-11

### Improved
- **Code Cleanup**: Removed all debug logging statements added during troubleshooting
  - Removed verbose debug logs from billing page template
  - Removed debug logs from subscription sync functions
  - Kept essential production logging for subscription saves

---

## [2.33.2] - 2026-01-11

### Fixed
- **Critical: Yearly Plan Not Displaying (Root Cause Fix)**: Fixed issue where yearly subscriptions were not showing in Current Plan card
  - **Root Cause**: Subscription query was filtering out subscriptions with empty/null status
  - **Fix**: Updated query to include subscriptions with empty/null status
  - **Additional Fixes**:
    - Added one-time database fix to set status to 'active' for existing subscriptions with empty status
    - Added fallback in `save_subscription_to_db()` to default status to 'active' if empty
    - Added fallback in `sync_subscription_status()` to ensure status is always set
  - Yearly subscriptions now correctly display with `/year` period and correct pricing

---

## [2.33.1] - 2026-01-11

### Improved
- **Current Plan Card Price Display**: Now shows actual subscription amount from Stripe instead of hardcoded plan prices
  - More accurate as it reflects discounts, prorations, or any price adjustments
  - Falls back to plan prices if subscription amount is not available
  - Formats whole numbers without decimals (e.g., $99 instead of $99.00)

---

## [2.33.0] - 2026-01-11

### Fixed
- **Security: Resume Subscription AJAX Handler**: Added missing authentication and authorization checks
  - Added `is_user_logged_in()` check
  - Added organization validation
  - Added owner role permission check (only organization owners can resume subscriptions)
- **Stripe 3D Secure Handler**: Replaced `alert()` calls with toast notifications for consistent UX
- **Checkout Button Text**: Fixed JavaScript fallback button text to respect billing cycle (was always showing monthly)
- **Method Visibility Bug**: Changed `update_org_plan()` from private to public since it's called from webhook handler

### Added
- **Trial End Sync**: Now properly syncs `trial_end` date in both `save_subscription_to_db()` and webhook handler
- **Updated Timestamp**: `update_org_plan()` now updates `updated_at` timestamp when changing plans
- **Resume Subscription Timestamp**: Now updates `updated_at` when resuming a cancelled subscription

### Improved
- **3D Secure UX**: Added success toast and delay before redirect after 3D Secure confirmation
- **Button State Handling**: Added null check for upgrade button in `handleStripeAction()`

---

## [2.32.0] - 2026-01-11

### Fixed
- **Yearly Billing Display (Critical Fix)**: Current Plan card now correctly shows yearly pricing for yearly subscriptions
  - Added multi-source billing cycle detection:
    1. Check `billing_cycle` column in database
    2. Compare subscription amount with plan's yearly price
    3. Calculate period length (>60 days = yearly)
  - Added automatic database fix for legacy subscriptions with incorrect billing_cycle
  - Billing Cycle status now uses the same detection logic

### Added
- **Auto-Fix for Legacy Data**: When billing page loads, if period length indicates yearly but billing_cycle says monthly, the database is automatically corrected

### Improved
- **Code Cleanup**: Consolidated billing cycle detection logic to a single location at the top of the file, removing redundant calculations from multiple template sections

---

## [2.31.0] - 2026-01-11

### Fixed
- **Yearly Billing Cycle Display**: Fixed critical bug where Current Plan card always showed monthly pricing even for yearly subscriptions
  - `save_subscription_to_db()` now properly determines billing cycle from Stripe's plan interval
  - Added fallback detection from `stripe_sub['items']['data'][0]['price']['recurring']['interval']`
  - Webhook handler now syncs billing_cycle when subscription is updated
  - `sync_subscription_status()` now extracts and updates billing_cycle from Stripe

### Added
- **Auto-Sync on Billing Page**: Added automatic subscription sync when data is stale (>1 hour old)
- **Debug Logging**: Added error_log statements for subscription save and webhook events to aid debugging
- **plan_slug Column**: Now properly saves plan_slug alongside plan_id for compatibility

### Improved
- **Stripe Data Extraction**: Improved handling of different Stripe response structures for amount and interval
- **Webhook Handler**: Enhanced `handle_subscription_updated` to sync billing_cycle, amount, and period dates

---

## [2.30.0] - 2026-01-11

### Added
- **Subscription Sync System**: New `sync_subscription_status()` method to ensure local database stays in sync with Stripe
- **Enhanced Status Indicators**: Current Plan card now shows distinct visual states for:
  - Active subscriptions (green pulsing dot)
  - Trial periods (purple pulsing dot with countdown badge)
  - Past due payments (red alert with action button)
  - Pending cancellation (amber warning)
  - Scheduled downgrades (info banner)
- **Toast Notification System**: Modern toast notifications replace browser alerts for better UX
- **Subscription Helper Methods**: Added utility methods for checking subscription state:
  - `has_active_subscription()` - Check if org has active paid subscription
  - `get_days_remaining()` - Get days left in billing period
  - `get_trial_days_remaining()` - Get trial days remaining

### Fixed
- **Duplicate AJAX Handler Registration**: Removed duplicate registration of subscription AJAX handlers that could cause conflicts
- **Subscription Query Consistency**: Added `pending_payment` status to subscription queries for complete state handling
- **Cancel Action**: Fixed cancel subscription AJAX action name from `rental_gates_cancel` to `rental_gates_cancel_subscription`

### Changed
- **Current Plan Card**: Completely redesigned status section with better visual hierarchy
- **Error Handling**: All subscription actions now use toast notifications instead of browser alerts
- **CSS Animations**: Added smooth animations for status indicators and toast notifications

### Improved
- Better handling of trial subscriptions with visible countdown
- Past due subscriptions now prominently show "Update Payment Method" CTA
- Scheduled downgrades display informative banner about upcoming plan change
- Console logging for debugging subscription errors

---

## [2.29.0] - 2026-01-11

### Fixed
- **Current Plan Card Display**: Fixed issues after subscription
  - Price now correctly reflects yearly vs monthly billing cycle
  - Cancel button now properly appears for paid subscriptions
  - Renewal/expiration date displays correctly

---

## [2.28.0] - 2026-01-11

### Fixed
- **Yearly Subscription Pricing**: Fixed critical bug where yearly plans charged monthly price/interval
  - Frontend now reads billing cycle from URL and displays correct yearly prices
  - Backend properly creates Stripe prices with yearly interval for yearly subscriptions
  - Billing cycle now correctly saved to database

---

## [2.27.0] - 2024-12-20

### Fixed
- **Subscription Pricing**: Corrected Gold plan price from $199 to $499/month.
- **Invoice Generation**: Added immediate invoice creation upon subscription to prevent delays.
- **Price ID Management**: Improved logic to regenerate Stripe Price IDs if local plan prices change.
- **Data Migration**: Added automatic migration to fix stale plan prices in database.

### Changed
- Updated plugin version to 2.27.0 across all files.

---

## [2.26.0] - 2024-12-19

### Added
- **Enhanced Admin Dashboard**
  - Comprehensive KPI metrics with trend indicators
  - Revenue and signups bar charts (6-month trend)
  - Quick actions panel for common tasks
  - Real-time system health status indicator
  - Secondary metrics: tenants, leads, work orders, churn rate
  - Recent payments table
  - Improved activity feed with contextual icons
  - Responsive grid layout

### Changed
- Admin dashboard now shows 8 key metrics with growth trends
- Activity feed icons now match action types
- System information expanded to 6 columns
- Charts use CSS-based bar rendering (no JS dependencies)

---

## [2.25.0] - 2024-12-19

### Added
- **Comprehensive Documentation**
  - README.md (394 lines) - Plugin overview
  - INSTALLATION.md (621 lines) - Setup guide
  - USER-GUIDE.md (945 lines) - All portal guides
  - ADMIN-GUIDE.md (779 lines) - Site admin guide
  - API-REFERENCE.md (1,312 lines) - REST API docs
  - DEVELOPER-GUIDE.md (1,121 lines) - Hooks & customization
  - CHANGELOG.md (414 lines) - Version history

---

## [2.24.1] - 2024-12-19

### Fixed
- PWA Settings menu item missing from Site Admin sidebar
- Added safety check for PWA class loading in admin template

---

## [2.24.0] - 2024-12-19

### Added
- **Progressive Web App (PWA) Support**
  - Service Worker for offline support
  - Push notifications with VAPID keys
  - Home screen installation prompts
  - Auto-generated app icons
  - iOS splash screen support
  - Network status indicators
  - Background sync for offline actions

- **PWA Admin Settings**
  - Enable/disable PWA features
  - Customize app name and description
  - Theme and background color configuration
  - Push notification management
  - System diagnostics

### Changed
- Updated mobile documentation with PWA features

---

## [2.23.1] - 2024-12-19

### Fixed
- Announcement "Permission denied" error - changed capability check from non-existent `rg_manage_properties` to `rg_manage_communications`
- Document upload/delete permission checks updated

---

## [2.23.0] - 2024-12-18

### Added
- Subscription invoice model with PDF generation
- Invoice viewing in admin dashboard
- Payment return handling with status pages

### Fixed
- Various minor bug fixes

---

## [2.22.0] - 2024-12-18

### Added
- **Plans Management Enhancement**
  - Create custom subscription plans
  - Edit existing plans
  - Feature toggles per plan
  - Usage limits configuration

### Changed
- Improved plans admin interface
- Better plan feature management

---

## [2.21.0] - 2024-12-18

### Added
- **OpenAI Integration**
  - AI-powered listing descriptions
  - Tenant screening assistance
  - Maintenance request analysis
  - Message drafting
  - Credit-based usage system

- **AI Tools Dashboard Section**
  - Tool selection interface
  - Credit usage tracking
  - Generation history

---

## [2.20.0] - 2024-12-18

### Added
- **PDF Generation System**
  - Lease agreement PDFs
  - Payment receipts
  - Invoice generation
  - Custom letterhead support

---

## [2.19.0] - 2024-12-18

### Added
- **Complete Email Template System**
  - 28 transactional email templates
  - Customizable via admin interface
  - Variable substitution support
  - HTML and plain text versions

### Email Templates Added
- Welcome, Password Reset
- Tenant/Staff/Vendor Invitations
- Application lifecycle emails
- Lease lifecycle emails
- Payment notifications
- Maintenance updates
- Announcements
- Lead followups

---

## [2.18.0] - 2024-12-18

### Added
- **QR Code Generation**
  - Building and unit QR codes
  - Scan tracking analytics
  - Customizable QR designs
  - Download and print options

---

## [2.17.0] - 2024-12-17

### Added
- **Lead Model & CRM**
  - Full lead management
  - Pipeline stages
  - Source tracking
  - Interest tracking
  - Conversion to application

---

## [2.16.0] - 2024-12-17

### Added
- **REST API Completion**
  - 156+ API endpoints
  - Full CRUD for all entities
  - Proper authentication
  - Rate limiting
  - Error handling

---

## [2.15.0] - 2024-12-17

### Added
- Site Admin dashboard layout
- Organizations management
- Users management across platform
- System health monitoring
- Activity log viewer

---

## [2.14.0] - 2024-12-17

### Added
- Vendor portal layout
- Work order management for vendors
- Vendor profile management
- Job history tracking

---

## [2.13.0] - 2024-12-17

### Added
- Staff portal layout
- Role-based dashboard
- Task management
- Lead assignment

---

## [2.12.0] - 2024-12-17

### Added
- Tenant portal layout
- Rent payment interface
- Maintenance request submission
- Lease viewing
- Profile management

---

## [2.11.4] - 2024-12-17

### Added
- **Comprehensive Mobile Optimization**
  - 600+ lines of mobile CSS
  - Bottom navigation bar
  - Swipe gestures
  - iOS safe area support
  - Touch target optimization
  - RTL support

### Fixed
- Modal dialogs on mobile
- Form input zoom on iOS
- Sidebar overlay behavior

---

## [2.11.0] - 2024-12-17

### Added
- Billing section with Stripe integration
- Plan selection interface
- Payment method management
- Invoice history

---

## [2.10.0] - 2024-12-17

### Added
- Vendor model with full CRUD
- Vendor management dashboard
- Service categories
- Performance tracking

---

## [2.9.0] - 2024-12-17

### Added
- Maintenance model with work orders
- Work order dashboard
- Status tracking
- Vendor assignment

---

## [2.8.0] - 2024-12-17

### Added
- Payment model with Stripe
- Payment recording
- Online payment processing
- Late fee calculation

---

## [2.7.0] - 2024-12-17

### Added
- Application model
- Application review interface
- Application status workflow
- Occupant management

---

## [2.6.0] - 2024-12-17

### Added
- Lease model with full lifecycle
- Lease creation interface
- Renewal system
- Termination handling

---

## [2.5.0] - 2024-12-17

### Added
- Tenant model with full CRUD
- Tenant directory
- Tenant profiles
- Portal invitations

---

## [2.4.0] - 2024-12-16

### Added
- Unit detail pages
- Availability state machine
- Unit amenities
- Gallery management

---

## [2.3.0] - 2024-12-16

### Added
- Unit management
- Unit forms with room counts
- Floor plans
- Pricing configuration

---

## [2.2.0] - 2024-12-16

### Added
- Building detail pages
- Unit list per building
- Building statistics
- Photo gallery

---

## [2.1.0] - 2024-12-16

### Added
- Building management
- Map-based location picker
- Geocoding integration
- Building amenities

---

## [2.0.0] - 2024-12-15

### Added
- Owner dashboard layout
- Dashboard overview section
- Statistics widgets
- Quick actions

---

## [1.0.4] - 2024-12-15

### Fixed
- Fatal error on activation (bracket mismatch)
- 500 error on edit pages (double JSON decode)
- Amenity toggle bug (label click double toggle)
- Missing component files

---

## [1.0.3] - 2024-12-15

### Added
- Multi-level caching system
- Cache invalidation hooks

---

## [1.0.2] - 2024-12-15

### Added
- Rate limiting system
- Configurable limits per action

---

## [1.0.1] - 2024-12-15

### Added
- Email queue system
- 6 initial email templates

---

## [1.0.0] - 2024-12-15

### Added
- **Initial Release**
- 49 database tables
- 6 user roles with capabilities
- Multi-tenant architecture
- Authentication system
- Organization model
- Building model (basic)
- Unit model (basic)
- Map services (Google/OSM)
- Security utilities
- Validation system

---

## Version Numbering

Rental Gates follows [Semantic Versioning](https://semver.org/):

- **MAJOR.MINOR.PATCH**
- MAJOR: Breaking changes
- MINOR: New features (backwards compatible)
- PATCH: Bug fixes (backwards compatible)

---

## Upgrade Notes

### Upgrading from 1.x to 2.x

No breaking changes. Database migrations run automatically.

### Upgrading to 2.24.0 (PWA)

1. Flush permalinks after upgrade
2. Configure PWA settings in Site Admin
3. HTTPS required for PWA features

---

*Maintained by Rental Gates Development Team*
