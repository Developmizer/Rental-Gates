<?php
/**
 * Magic Link Email Template
 * 
 * Sent when a user requests a passwordless login link.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $login_url: The secure magic link URL (expires in 15 minutes)
 * - $name: User's display name
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Your Secure Login Link', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('You requested a secure login link. Click the button below to sign in to your account without a password.', 'rental-gates'); ?>
</p>

<?php if (!empty($login_url)): ?>
    <?php echo Rental_Gates_Email::button($login_url, __('Sign In Securely', 'rental-gates'), 'primary'); ?>
<?php endif; ?>

<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0; font-size: 14px; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">' .
    '<strong>' . __('This link expires in 15 minutes.', 'rental-gates') . '</strong><br>' .
    __('For your security, please do not share this link with anyone.', 'rental-gates') .
    '</p>',
    'warning'
); ?>

<?php if (!empty($login_url)): ?>
<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('If the button doesn\'t work, copy and paste this link into your browser:', 'rental-gates'); ?>
</p>
<p style="margin: 8px 0 0; font-size: 13px; color: #2563eb; word-break: break-all; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <a href="<?php echo esc_url($login_url); ?>" style="color: #2563eb; text-decoration: none; border-bottom: 1px solid transparent;"><?php echo esc_url($login_url); ?></a>
</p>
<?php endif; ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('If you didn\'t request this login link, you can safely ignore this email. Your account remains secure.', 'rental-gates'); ?>
</p>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        h1 {
            color: #f9fafb !important;
        }
        p {
            color: #d1d5db !important;
        }
        a {
            color: #60a5fa !important;
        }
    }
    @media only screen and (max-width: 600px) {
        h1 {
            font-size: 24px !important;
        }
    }
</style>
