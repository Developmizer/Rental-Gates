<?php
/**
 * Vendor Invitation Email Template
 * 
 * Sent when inviting a vendor to access their portal.
 * 
 * Available variables:
 * - $vendor_name
 * - $company_name
 * - $organization_name
 * - $temp_password
 * - $login_url
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Vendor Portal Access 🔧', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($vendor_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php printf(
        __('You\'ve been set up as a vendor for <strong>%s</strong>. You can now access your vendor portal to manage work orders.', 'rental-gates'),
        esc_html($organization_name ?? '')
    ); ?>
</p>

<?php if (!empty($company_name)): ?>
<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0; font-size: 14px; color: #1e40af;">' . __('Company', 'rental-gates') . '</p>' .
    '<p style="margin: 4px 0 0; font-size: 20px; font-weight: 700; color: #1e40af;">' . esc_html($company_name) . '</p>',
    'info'
); ?>
<?php endif; ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Your Login Credentials', 'rental-gates'); ?>
</h2>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Email', 'rental-gates'), $vendor_email ?? '-');
echo Rental_Gates_Email::detail_row(__('Temporary Password', 'rental-gates'), $temp_password ?? '********', true);
echo Rental_Gates_Email::details_table_end();
?>

<p style="margin: 24px 0; color: #dc2626; font-size: 14px; font-weight: 500;">
    ⚠️ <?php _e('Please change your password after your first login.', 'rental-gates'); ?>
</p>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('In your portal, you can:', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0; margin-bottom: 24px;">
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('View assigned work orders', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Update job status and add notes', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Upload photos and documentation', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Track your work history', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php echo Rental_Gates_Email::button($login_url ?? home_url('/rental-gates/login'), __('Access Vendor Portal', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you have any questions, please contact the property manager.', 'rental-gates'); ?>
</p>
