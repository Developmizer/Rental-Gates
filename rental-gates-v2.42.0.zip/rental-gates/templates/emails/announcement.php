<?php
/**
 * Announcement Email Template
 * 
 * Sent for important announcements to tenants/residents.
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php echo esc_html($announcement_title ?? __('Important Announcement', 'rental-gates')); ?>
</h1>

<p style="margin: 0 0 32px; font-size: 14px; color: #6b7280;">
    <?php echo esc_html(date('F j, Y')); ?>
</p>

<?php if (!empty($recipient_name)): ?>
<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Dear %s,', 'rental-gates'), esc_html($recipient_name)); ?>
</p>
<?php endif; ?>

<div style="margin: 0 0 32px; color: #374151; font-size: 16px; line-height: 1.7;">
    <?php echo wp_kses_post($announcement_content ?? $message ?? ''); ?>
</div>

<?php if (!empty($action_url)): ?>
<?php echo Rental_Gates_Email::button($action_url, $action_text ?? __('Learn More', 'rental-gates')); ?>
<?php endif; ?>

<?php if (!empty($contact_info)): ?>
<?php echo Rental_Gates_Email::divider(); ?>
<p style="margin: 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you have any questions, please contact:', 'rental-gates'); ?><br>
    <?php echo esc_html($contact_info); ?>
</p>
<?php endif; ?>
