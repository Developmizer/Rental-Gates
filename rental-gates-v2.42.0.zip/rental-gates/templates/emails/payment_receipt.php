<?php
/**
 * Payment Receipt Email Template
 * 
 * Sent when a payment is successfully processed.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $tenant_name
 * - $payment_number
 * - $amount
 * - $payment_date
 * - $payment_method
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Payment Confirmed ✓', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Thank you for your payment! This email confirms that your payment has been successfully processed.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%%; border: none; border-collapse: collapse; border-spacing: 0; text-align: center; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
        <tr>
            <td style="word-break: break-word;">
                <p style="margin: 0 0 4px; font-size: 14px; color: #166534; font-weight: 500; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">' . __('Amount Paid', 'rental-gates') . '</p>
                <p style="margin: 0; font-size: 36px; font-weight: 700; color: #166534; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">$' . esc_html($amount ?? '0.00') . '</p>
            </td>
        </tr>
    </table>',
    'success'
); ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Payment Details', 'rental-gates'); ?>
</h2>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Confirmation Number', 'rental-gates'), $payment_number ?? '-');
echo Rental_Gates_Email::detail_row(__('Payment Date', 'rental-gates'), $payment_date ?? '-');
echo Rental_Gates_Email::detail_row(__('Payment Method', 'rental-gates'), $payment_method ?? '-');
echo Rental_Gates_Email::detail_row(__('Amount', 'rental-gates'), '$' . ($amount ?? '0.00'), true);
echo Rental_Gates_Email::details_table_end();
?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Keep this email for your records. If you have any questions about this payment, please contact your property manager.', 'rental-gates'); ?>
</p>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        h1 {
            color: #f9fafb !important;
        }
        h2 {
            color: #f9fafb !important;
        }
        p {
            color: #d1d5db !important;
        }
    }
    @media only screen and (max-width: 600px) {
        h1 {
            font-size: 24px !important;
        }
        h2 {
            font-size: 18px !important;
        }
    }
</style>
