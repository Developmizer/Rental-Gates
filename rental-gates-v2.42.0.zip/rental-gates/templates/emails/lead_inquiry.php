<?php
/**
 * Lead Inquiry Email Template
 * 
 * Sent to property managers when a new lead submits an inquiry.
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('New Inquiry Received! 🎯', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php _e('You have a new inquiry from your property listing.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
        <tr>
            <td>
                <p style="margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #1e40af;">' . esc_html($lead_name ?? 'Unknown') . '</p>
                <p style="margin: 0; font-size: 14px; color: #1e40af;">' . esc_html($lead_email ?? '') . '</p>
                ' . (!empty($lead_phone) ? '<p style="margin: 4px 0 0; font-size: 14px; color: #1e40af;">' . esc_html($lead_phone) . '</p>' : '') . '
            </td>
        </tr>
    </table>',
    'info'
); ?>

<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($property_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $property_name);
}
echo Rental_Gates_Email::detail_row(__('Source', 'rental-gates'), ucfirst(str_replace('_', ' ', $source ?? 'Website')));
echo Rental_Gates_Email::detail_row(__('Received', 'rental-gates'), date('F j, Y \a\t g:i A'), true);
echo Rental_Gates_Email::details_table_end();
?>

<?php if (!empty($lead_message)): ?>
<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Message', 'rental-gates'); ?>
</h2>
<p style="margin: 0; padding: 20px; background-color: #f9fafb; border-radius: 12px; color: #374151; font-style: italic;">
    "<?php echo esc_html($lead_message); ?>"
</p>
<?php endif; ?>

<table role="presentation" style="width: 100%; margin: 32px 0; border: none; border-spacing: 0;">
    <tr>
        <td style="padding-right: 8px;">
            <?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/dashboard/leads'), __('View in Dashboard', 'rental-gates')); ?>
        </td>
    </tr>
</table>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
    <tr>
        <td style="text-align: center;">
            <p style="margin: 0 0 8px; font-size: 14px; color: #6b7280;"><?php _e('Quick actions:', 'rental-gates'); ?></p>
            <a href="mailto:<?php echo esc_attr($lead_email ?? ''); ?>" style="display: inline-block; padding: 8px 16px; margin: 0 4px; background-color: #f3f4f6; color: #374151; text-decoration: none; border-radius: 6px; font-size: 14px;">📧 <?php _e('Email', 'rental-gates'); ?></a>
            <?php if (!empty($lead_phone)): ?>
            <a href="tel:<?php echo esc_attr($lead_phone); ?>" style="display: inline-block; padding: 8px 16px; margin: 0 4px; background-color: #f3f4f6; color: #374151; text-decoration: none; border-radius: 6px; font-size: 14px;">📞 <?php _e('Call', 'rental-gates'); ?></a>
            <?php endif; ?>
        </td>
    </tr>
</table>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; text-align: center;">
    <?php _e('Respond quickly to increase your chances of converting this lead!', 'rental-gates'); ?>
</p>
