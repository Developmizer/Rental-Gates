<?php
/**
 * Maintenance Completed Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Maintenance Complete! ✓', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('Great news! Your maintenance request has been completed.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: center;">
        <tr>
            <td>
                <div style="width: 64px; height: 64px; margin: 0 auto 12px; background-color: #d1fae5; border-radius: 50%; line-height: 64px; font-size: 32px;">✓</div>
                <p style="margin: 0; font-size: 18px; font-weight: 600; color: #166534;">' . __('Completed', 'rental-gates') . '</p>
            </td>
        </tr>
    </table>',
    'success'
); ?>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Request', 'rental-gates'), $work_order_title ?? '-');
echo Rental_Gates_Email::detail_row(__('Completed On', 'rental-gates'), $completed_date ?? date('F j, Y'));
if (!empty($technician_name)) {
    echo Rental_Gates_Email::detail_row(__('Technician', 'rental-gates'), $technician_name, true);
} else {
    echo Rental_Gates_Email::detail_row(__('Request ID', 'rental-gates'), '#' . ($work_order_id ?? '-'), true);
}
echo Rental_Gates_Email::details_table_end();
?>

<?php if (!empty($completion_notes)): ?>
<p style="margin: 24px 0; padding: 16px; background-color: #f9fafb; border-radius: 8px; color: #374151; font-size: 14px;">
    <strong><?php _e('Completion Notes:', 'rental-gates'); ?></strong><br>
    <?php echo esc_html($completion_notes); ?>
</p>
<?php endif; ?>

<?php echo Rental_Gates_Email::divider(); ?>

<p style="margin: 0 0 16px; color: #374151; text-align: center;">
    <?php _e('How was your experience?', 'rental-gates'); ?>
</p>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
    <tr>
        <td style="text-align: center;">
            <?php if (!empty($survey_url)): ?>
            <a href="<?php echo esc_url($survey_url); ?>" style="text-decoration: none;">
                <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😞</span>
                <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😐</span>
                <span style="display: inline-block; margin: 0 4px; font-size: 32px;">🙂</span>
                <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😊</span>
                <span style="display: inline-block; margin: 0 4px; font-size: 32px;">🤩</span>
            </a>
            <?php else: ?>
            <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😞</span>
            <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😐</span>
            <span style="display: inline-block; margin: 0 4px; font-size: 32px;">🙂</span>
            <span style="display: inline-block; margin: 0 4px; font-size: 32px;">😊</span>
            <span style="display: inline-block; margin: 0 4px; font-size: 32px;">🤩</span>
            <?php endif; ?>
        </td>
    </tr>
</table>

<?php if (!empty($survey_url)): ?>
<?php echo Rental_Gates_Email::button($survey_url, __('Rate Your Experience', 'rental-gates'), 'outline'); ?>
<?php endif; ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; text-align: center;">
    <?php _e('Thank you for your patience!', 'rental-gates'); ?>
</p>
