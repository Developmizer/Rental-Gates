<?php
/**
 * Maintenance Created Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Maintenance Request Received 🔧', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('We\'ve received your maintenance request and will get it assigned to a technician shortly.', 'rental-gates'); ?>
</p>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Request ID', 'rental-gates'), '#' . ($work_order_id ?? '-'));
echo Rental_Gates_Email::detail_row(__('Issue', 'rental-gates'), $work_order_title ?? '-');
echo Rental_Gates_Email::detail_row(__('Priority', 'rental-gates'), ucfirst($priority ?? 'normal'));
echo Rental_Gates_Email::detail_row(__('Status', 'rental-gates'), __('Submitted', 'rental-gates'), true);
echo Rental_Gates_Email::details_table_end();
?>

<?php if (!empty($description)): ?>
<p style="margin: 24px 0; padding: 16px; background-color: #f9fafb; border-radius: 8px; color: #374151; font-size: 14px;">
    <strong><?php _e('Description:', 'rental-gates'); ?></strong><br>
    <?php echo esc_html($description); ?>
</p>
<?php endif; ?>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/tenant/maintenance'), __('Track Request', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('We\'ll notify you when there are updates to your request.', 'rental-gates'); ?>
</p>
