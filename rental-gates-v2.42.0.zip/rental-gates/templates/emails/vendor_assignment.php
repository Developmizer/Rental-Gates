<?php
/**
 * Vendor Assignment Email Template
 * 
 * Sent to vendors when they're assigned a new work order.
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('New Work Order Assignment 🔧', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($vendor_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('You\'ve been assigned a new work order. Please review the details below and take action as needed.', 'rental-gates'); ?>
</p>

<?php 
$priority_colors = array(
    'urgent' => '#ef4444',
    'high' => '#f59e0b',
    'normal' => '#6366f1',
    'low' => '#10b981',
);
$priority_color = $priority_colors[$priority ?? 'normal'] ?? '#6366f1';
?>

<table role="presentation" style="width: 100%; margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 12px; border-spacing: 0; overflow: hidden;">
    <tr>
        <td style="padding: 20px; background-color: <?php echo esc_attr($priority_color); ?>;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td>
                        <p style="margin: 0 0 4px; font-size: 14px; color: rgba(255,255,255,0.9);"><?php _e('Work Order', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 20px; font-weight: 700; color: #ffffff;"><?php echo esc_html($work_order_title ?? '-'); ?></p>
                    </td>
                    <td style="text-align: right;">
                        <span style="display: inline-block; padding: 6px 12px; background-color: rgba(255,255,255,0.2); border-radius: 20px; color: #ffffff; font-size: 12px; font-weight: 600; text-transform: uppercase;">
                            <?php echo esc_html(ucfirst($priority ?? 'Normal')); ?> <?php _e('Priority', 'rental-gates'); ?>
                        </span>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 20px;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <?php echo Rental_Gates_Email::detail_row(__('Work Order ID', 'rental-gates'), '#' . ($work_order_id ?? '-')); ?>
                <?php if (!empty($property_name)): ?>
                <?php echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $property_name); ?>
                <?php endif; ?>
                <?php if (!empty($unit_name)): ?>
                <?php echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name); ?>
                <?php endif; ?>
                <?php if (!empty($scheduled_date)): ?>
                <?php echo Rental_Gates_Email::detail_row(__('Scheduled', 'rental-gates'), $scheduled_date, true); ?>
                <?php else: ?>
                <?php echo Rental_Gates_Email::detail_row(__('Assigned', 'rental-gates'), date('F j, Y'), true); ?>
                <?php endif; ?>
            </table>
        </td>
    </tr>
</table>

<?php if (!empty($description)): ?>
<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Description', 'rental-gates'); ?>
</h2>
<p style="margin: 0; padding: 20px; background-color: #f9fafb; border-radius: 12px; color: #374151;">
    <?php echo esc_html($description); ?>
</p>
<?php endif; ?>

<?php if (!empty($property_address)): ?>
<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
        <tr>
            <td style="width: 24px; vertical-align: top; font-size: 18px;">📍</td>
            <td style="padding-left: 8px;">
                <p style="margin: 0 0 4px; font-weight: 600; color: #374151;">' . __('Location', 'rental-gates') . '</p>
                <p style="margin: 0; color: #374151;">' . esc_html($property_address) . '</p>
            </td>
        </tr>
    </table>',
    'gray'
); ?>
<?php endif; ?>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/vendor'), __('View Work Order', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('Please update the work order status as you progress through the job.', 'rental-gates'); ?>
</p>
