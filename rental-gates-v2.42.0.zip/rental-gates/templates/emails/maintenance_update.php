<?php
/**
 * Maintenance Update Email Template
 */
if (!defined('ABSPATH')) exit;

$status_colors = array(
    'assigned' => '#6366f1',
    'in_progress' => '#f59e0b',
    'on_hold' => '#6b7280',
    'completed' => '#10b981',
);
$status_color = $status_colors[$status ?? 'assigned'] ?? '#6366f1';
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Maintenance Request Update', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('There\'s an update on your maintenance request.', 'rental-gates'); ?>
</p>

<table role="presentation" style="width: 100%; margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 12px; border-spacing: 0; overflow: hidden;">
    <tr>
        <td style="padding: 20px; background-color: <?php echo esc_attr($status_color); ?>;">
            <p style="margin: 0; font-size: 14px; color: rgba(255,255,255,0.9);"><?php _e('Current Status', 'rental-gates'); ?></p>
            <p style="margin: 4px 0 0; font-size: 24px; font-weight: 700; color: #ffffff;">
                <?php echo esc_html(ucfirst(str_replace('_', ' ', $status ?? 'updated'))); ?>
            </p>
        </td>
    </tr>
    <tr>
        <td style="padding: 20px;">
            <p style="margin: 0 0 4px; font-size: 13px; color: #6b7280;"><?php _e('Request', 'rental-gates'); ?></p>
            <p style="margin: 0; font-size: 16px; font-weight: 600; color: #111827;"><?php echo esc_html($work_order_title ?? '-'); ?></p>
        </td>
    </tr>
</table>

<?php if (!empty($update_message)): ?>
<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0 0 4px; font-weight: 600;">' . __('Update Notes:', 'rental-gates') . '</p>' .
    '<p style="margin: 0;">' . esc_html($update_message) . '</p>',
    'gray'
); ?>
<?php endif; ?>

<?php if (!empty($scheduled_date)): ?>
<p style="margin: 24px 0; color: #374151;">
    📅 <strong><?php _e('Scheduled for:', 'rental-gates'); ?></strong> <?php echo esc_html($scheduled_date); ?>
</p>
<?php endif; ?>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/tenant/maintenance'), __('View Details', 'rental-gates')); ?>
