<?php
/**
 * Generic Email Template
 * 
 * Fallback template for emails without a specific template.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $message: Main message content
 * - $action_url: Optional CTA button URL
 * - $action_text: Optional CTA button text
 */
if (!defined('ABSPATH')) exit;
?>

<?php if (!empty($message)): ?>
<div style="color: #374151; font-size: 16px; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; word-break: break-word;">
    <?php echo wp_kses_post($message); ?>
</div>
<?php endif; ?>

<?php if (!empty($action_url)): ?>
    <?php echo Rental_Gates_Email::button($action_url, $action_text ?? __('View Details', 'rental-gates'), 'primary'); ?>
<?php endif; ?>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        div {
            color: #d1d5db !important;
        }
    }
    @media only screen and (max-width: 600px) {
        div {
            font-size: 15px !important;
        }
    }
</style>
