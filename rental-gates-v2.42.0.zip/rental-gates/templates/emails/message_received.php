<?php
/**
 * Message Received Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('New Message 💬', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($recipient_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php printf(__('You have a new message from <strong>%s</strong>.', 'rental-gates'), esc_html($sender_name ?? __('your property manager', 'rental-gates'))); ?>
</p>

<?php if (!empty($subject)): ?>
<p style="margin: 0 0 16px; font-size: 14px; color: #6b7280;">
    <strong><?php _e('Subject:', 'rental-gates'); ?></strong> <?php echo esc_html($subject); ?>
</p>
<?php endif; ?>

<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0; white-space: pre-wrap;">' . esc_html($message_preview ?? $message ?? '') . '</p>',
    'gray'
); ?>

<?php echo Rental_Gates_Email::button($action_url ?? home_url('/rental-gates/tenant/messages'), __('View & Reply', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('Log in to your portal to read the full message and respond.', 'rental-gates'); ?>
</p>
