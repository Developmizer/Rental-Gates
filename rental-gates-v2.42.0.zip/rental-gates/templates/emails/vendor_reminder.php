<?php
/**
 * Vendor Reminder Email Template
 * 
 * Variables: $vendor_name, $organization_name, $work_order_id, $work_order_title,
 *            $property_address, $scheduled_date, $priority, $action_url
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('Work Order Reminder', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($vendor_name ?? 'Vendor')
));

echo Rental_Gates_Email::text(
    __('This is a friendly reminder about an upcoming or pending work order.', 'rental-gates')
);

$priority_color = ($priority ?? '') === 'urgent' ? 'error' : (($priority ?? '') === 'high' ? 'warning' : 'info');
echo Rental_Gates_Email::alert(
    '<strong>' . esc_html($work_order_title ?? 'Work Order') . '</strong><br>' .
    sprintf(__('Work Order #%s', 'rental-gates'), esc_html($work_order_id ?? '')) .
    (!empty($priority) ? '<br><span style="text-transform: uppercase;">' . esc_html($priority) . ' Priority</span>' : ''),
    $priority_color
);

echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), esc_html($property_address ?? ''));
if (!empty($scheduled_date)) {
    echo Rental_Gates_Email::detail_row(__('Scheduled', 'rental-gates'), esc_html($scheduled_date));
}
echo Rental_Gates_Email::detail_row(__('Client', 'rental-gates'), esc_html($organization_name ?? ''), true);
echo Rental_Gates_Email::details_table_end();

echo Rental_Gates_Email::text(
    __('Please ensure this work order is completed on schedule. If you have any issues or need to reschedule, please contact the property manager immediately.', 'rental-gates')
);

if (!empty($action_url)) {
    echo Rental_Gates_Email::button(__('View Work Order', 'rental-gates'), $action_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    __('Thank you for your prompt attention to this matter.', 'rental-gates'),
    'small'
);
