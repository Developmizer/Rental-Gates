<?php
/**
 * Welcome Email Template
 * 
 * Sent when a new owner/manager creates an account.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $user_name
 * - $organization_name
 * - $dashboard_url
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Welcome, %s! 👋', 'rental-gates'), esc_html($user_name ?? __('there', 'rental-gates'))); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 18px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('We\'re excited to have you on board.', 'rental-gates'); ?>
</p>

<p style="margin: 0 0 24px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(
        __('Your organization <strong>%s</strong> has been created and is ready to use. You can now start managing your properties, tenants, and more.', 'rental-gates'),
        esc_html($organization_name ?? '')
    ); ?>
</p>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Here\'s what you can do:', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; margin-bottom: 24px; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
    <tr>
        <td style="padding: 16px 20px; background-color: #f9fafb; border-radius: 12px; margin-bottom: 12px; word-break: break-word;">
            <table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                <tr>
                    <td style="width: 48px; vertical-align: top;">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 10px; text-align: center; line-height: 40px;">
                            <span style="color: #fff; font-size: 18px; display: inline-block; line-height: 40px;">🏢</span>
                        </div>
                    </td>
                    <td style="padding-left: 16px; vertical-align: top; word-break: break-word;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Add Properties', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Add your buildings and units with map pin locations', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><td style="height: 12px; line-height: 12px; font-size: 12px;">&nbsp;</td></tr>
    <tr>
        <td style="padding: 16px 20px; background-color: #f9fafb; border-radius: 12px; margin-bottom: 12px; word-break: break-word;">
            <table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                <tr>
                    <td style="width: 48px; vertical-align: top;">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #10b981, #059669); border-radius: 10px; text-align: center; line-height: 40px;">
                            <span style="color: #fff; font-size: 18px; display: inline-block; line-height: 40px;">📱</span>
                        </div>
                    </td>
                    <td style="padding-left: 16px; vertical-align: top; word-break: break-word;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Generate QR Codes', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Create QR codes for easy property discovery', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><td style="height: 12px; line-height: 12px; font-size: 12px;">&nbsp;</td></tr>
    <tr>
        <td style="padding: 16px 20px; background-color: #f9fafb; border-radius: 12px; margin-bottom: 12px; word-break: break-word;">
            <table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                <tr>
                    <td style="width: 48px; vertical-align: top;">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #f59e0b, #d97706); border-radius: 10px; text-align: center; line-height: 40px;">
                            <span style="color: #fff; font-size: 18px; display: inline-block; line-height: 40px;">💰</span>
                        </div>
                    </td>
                    <td style="padding-left: 16px; vertical-align: top; word-break: break-word;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Collect Payments', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Receive rent payments online via Stripe', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr><td style="height: 12px; line-height: 12px; font-size: 12px;">&nbsp;</td></tr>
    <tr>
        <td style="padding: 16px 20px; background-color: #f9fafb; border-radius: 12px; word-break: break-word;">
            <table role="presentation" style="width: 100%; border: none; border-collapse: collapse; border-spacing: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                <tr>
                    <td style="width: 48px; vertical-align: top;">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 10px; text-align: center; line-height: 40px;">
                            <span style="color: #fff; font-size: 18px; display: inline-block; line-height: 40px;">🔧</span>
                        </div>
                    </td>
                    <td style="padding-left: 16px; vertical-align: top; word-break: break-word;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Handle Maintenance', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;"><?php _e('Track and manage maintenance requests efficiently', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php echo Rental_Gates_Email::button($dashboard_url ?? home_url('/rental-gates/dashboard'), __('Go to Dashboard', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Need help getting started? Reply to this email and our team will be happy to assist you.', 'rental-gates'); ?>
</p>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        h1 {
            color: #f9fafb !important;
        }
        h2 {
            color: #f9fafb !important;
        }
        p {
            color: #d1d5db !important;
        }
        .feature-box {
            background-color: #374151 !important;
        }
        .feature-box p:first-child {
            color: #f9fafb !important;
        }
        .feature-box p:last-child {
            color: #d1d5db !important;
        }
    }
    @media only screen and (max-width: 600px) {
        h1 {
            font-size: 24px !important;
        }
        h2 {
            font-size: 18px !important;
        }
        .feature-box {
            padding: 12px 16px !important;
        }
        .feature-box td:first-child {
            width: 40px !important;
        }
        .feature-box td:last-child {
            padding-left: 12px !important;
        }
    }
</style>
