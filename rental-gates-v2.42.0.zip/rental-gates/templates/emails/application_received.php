<?php
/**
 * Application Received Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Application Received! 📝', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($applicant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 32px; color: #374151;">
    <?php _e('Thank you for submitting your rental application. We\'ve received it and will begin reviewing it shortly.', 'rental-gates'); ?>
</p>

<?php if (!empty($unit_name) || !empty($building_name)): ?>
<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($building_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $building_name);
}
if (!empty($unit_name)) {
    echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name);
}
echo Rental_Gates_Email::detail_row(__('Application Date', 'rental-gates'), date('F j, Y'), true);
echo Rental_Gates_Email::details_table_end();
?>
<?php endif; ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('What happens next?', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #6366f1; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">1</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Application Review', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('We\'ll review your application within 1-3 business days.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #d1d5db; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">2</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Background Check', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('If applicable, we\'ll run a background and credit check.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #d1d5db; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">3</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Decision', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('We\'ll notify you of our decision via email.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you have any questions about your application, please don\'t hesitate to contact us.', 'rental-gates'); ?>
</p>
