<?php
/**
 * Staff Invitation Email Template
 * 
 * Sent when inviting a staff member to join the organization.
 * 
 * Available variables:
 * - $staff_name
 * - $organization_name
 * - $role_name
 * - $inviter_name
 * - $temp_password
 * - $login_url
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('You\'ve Been Invited! 🎉', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($staff_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php printf(
        __('%s has invited you to join <strong>%s</strong> as a team member.', 'rental-gates'),
        esc_html($inviter_name ?? __('Your administrator', 'rental-gates')),
        esc_html($organization_name ?? '')
    ); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
        <tr>
            <td style="text-align: center;">
                <p style="margin: 0 0 4px; font-size: 13px; color: #1e40af;">' . __('Your Role', 'rental-gates') . '</p>
                <p style="margin: 0; font-size: 24px; font-weight: 700; color: #1e40af;">' . esc_html(ucfirst($role_name ?? 'Staff')) . '</p>
            </td>
        </tr>
    </table>',
    'info'
); ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Your Login Credentials', 'rental-gates'); ?>
</h2>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Email', 'rental-gates'), $staff_email ?? '-');
echo Rental_Gates_Email::detail_row(__('Temporary Password', 'rental-gates'), $temp_password ?? '********', true);
echo Rental_Gates_Email::details_table_end();
?>

<p style="margin: 24px 0; color: #dc2626; font-size: 14px; font-weight: 500;">
    ⚠️ <?php _e('Please change your password after your first login for security.', 'rental-gates'); ?>
</p>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('What you\'ll be able to do:', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0; margin-bottom: 24px;">
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Manage properties and units', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Handle tenant communications', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Process maintenance requests', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 8px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 24px; color: #10b981; font-size: 16px;">✓</td>
                    <td style="color: #374151; font-size: 15px;"><?php _e('Access reports and analytics', 'rental-gates'); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php echo Rental_Gates_Email::button($login_url ?? home_url('/rental-gates/login'), __('Accept Invitation & Log In', 'rental-gates')); ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('If you have any questions, please contact your administrator.', 'rental-gates'); ?>
</p>
