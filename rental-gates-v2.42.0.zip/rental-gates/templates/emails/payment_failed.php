<?php
/**
 * Payment Failed Email Template
 * 
 * Sent when a payment fails to process.
 * Modern, responsive, accessible design with dark mode support.
 * 
 * Available variables:
 * - $tenant_name
 * - $organization_name
 * - $amount
 * - $payment_date
 * - $failure_reason
 * - $retry_url
 * - $organization_phone
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827; line-height: 1.2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Payment Failed - Action Required', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($tenant_name ?? __('there', 'rental-gates'))); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0; font-size: 15px; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">' .
    '<strong>' . __('Your payment could not be processed', 'rental-gates') . '</strong><br>' .
    __('Please update your payment method to avoid late fees.', 'rental-gates') .
    '</p>',
    'danger'
); ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827; line-height: 1.4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('Payment Details', 'rental-gates'); ?>
</h2>

<?php 
echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Amount', 'rental-gates'), '$' . number_format($amount ?? 0, 2));
echo Rental_Gates_Email::detail_row(__('Date Attempted', 'rental-gates'), esc_html($payment_date ?? date('F j, Y')));
if (!empty($failure_reason)) {
    echo Rental_Gates_Email::detail_row(__('Reason', 'rental-gates'), esc_html($failure_reason), true);
} else {
    echo Rental_Gates_Email::detail_row(__('Reason', 'rental-gates'), __('Payment could not be processed', 'rental-gates'), true);
}
echo Rental_Gates_Email::details_table_end();
?>

<p style="margin: 24px 0 16px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php _e('This may have occurred due to:', 'rental-gates'); ?>
</p>

<ul style="margin: 0 0 24px; padding-left: 20px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('Insufficient funds', 'rental-gates'); ?></li>
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('Expired card', 'rental-gates'); ?></li>
    <li style="margin-bottom: 8px; line-height: 1.7;"><?php _e('Card declined by bank', 'rental-gates'); ?></li>
    <li style="line-height: 1.7;"><?php _e('Incorrect payment details', 'rental-gates'); ?></li>
</ul>

<p style="margin: 0 0 24px; color: #374151; line-height: 1.7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <strong><?php _e('Please update your payment method and try again as soon as possible to avoid any late fees.', 'rental-gates'); ?></strong>
</p>

<?php if (!empty($retry_url)): ?>
    <?php echo Rental_Gates_Email::button($retry_url, __('Update Payment Method', 'rental-gates'), 'primary'); ?>
<?php endif; ?>

<?php echo Rental_Gates_Email::divider(); ?>

<?php if (!empty($organization_phone)): ?>
<p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <?php printf(__('Need help? Contact us at %s', 'rental-gates'), '<a href="tel:' . esc_attr($organization_phone) . '" style="color: #6366f1; text-decoration: none; border-bottom: 1px solid transparent;">' . esc_html($organization_phone) . '</a>'); ?>
</p>
<?php endif; ?>

<style type="text/css">
    @media (prefers-color-scheme: dark) {
        h1 {
            color: #f9fafb !important;
        }
        h2 {
            color: #f9fafb !important;
        }
        p {
            color: #d1d5db !important;
        }
        ul {
            color: #d1d5db !important;
        }
        li {
            color: #d1d5db !important;
        }
        a {
            color: #818cf8 !important;
        }
    }
    @media only screen and (max-width: 600px) {
        h1 {
            font-size: 24px !important;
        }
        h2 {
            font-size: 18px !important;
        }
        ul {
            padding-left: 18px !important;
        }
    }
</style>
