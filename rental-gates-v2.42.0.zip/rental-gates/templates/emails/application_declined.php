<?php
/**
 * Application Declined Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Application Status Update', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($applicant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('Thank you for your interest in our property. After careful review, we regret to inform you that we are unable to approve your application at this time.', 'rental-gates'); ?>
</p>

<?php if (!empty($unit_name) || !empty($building_name)): ?>
<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($building_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $building_name);
}
if (!empty($unit_name)) {
    echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name, true);
}
echo Rental_Gates_Email::details_table_end();
?>
<?php endif; ?>

<?php if (!empty($decline_reason)): ?>
<?php echo Rental_Gates_Email::info_box(
    '<p style="margin: 0 0 4px; font-weight: 600;">' . __('Reason:', 'rental-gates') . '</p>' .
    '<p style="margin: 0;">' . esc_html($decline_reason) . '</p>',
    'gray'
); ?>
<?php endif; ?>

<p style="margin: 24px 0; color: #374151;">
    <?php _e('This decision is based on our current application criteria and does not reflect your character or worth as a person. We encourage you to continue your housing search.', 'rental-gates'); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('If you believe there has been an error or would like to discuss this decision, please feel free to contact us.', 'rental-gates'); ?>
</p>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('We wish you the best in finding your new home.', 'rental-gates'); ?>
</p>
