<?php
/**
 * Lease Signed Email Template
 * 
 * Variables: $tenant_name, $organization_name, $unit_name, $building_name, 
 *            $start_date, $end_date, $rent_amount, $dashboard_url
 */
if (!defined('ABSPATH')) exit;

echo Rental_Gates_Email::heading(__('Lease Agreement Signed!', 'rental-gates'));

echo Rental_Gates_Email::text(sprintf(
    __('Hi %s,', 'rental-gates'),
    esc_html($tenant_name ?? 'Tenant')
));

echo Rental_Gates_Email::text(
    __('Great news! Your lease agreement has been signed and is now active.', 'rental-gates')
);

echo Rental_Gates_Email::alert(
    '<strong>' . __('Your lease is now active!', 'rental-gates') . '</strong><br>' .
    __('You can access your lease documents and tenant portal anytime.', 'rental-gates'),
    'success'
);

echo Rental_Gates_Email::details_table_start();
echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), esc_html($unit_name ?? '') . ' at ' . esc_html($building_name ?? ''));
echo Rental_Gates_Email::detail_row(__('Lease Start', 'rental-gates'), esc_html($start_date ?? ''));
echo Rental_Gates_Email::detail_row(__('Lease End', 'rental-gates'), esc_html($end_date ?? ''));
echo Rental_Gates_Email::detail_row(__('Monthly Rent', 'rental-gates'), '$' . number_format($rent_amount ?? 0, 2), true);
echo Rental_Gates_Email::details_table_end();

echo Rental_Gates_Email::text(
    __('You can view your complete lease agreement and manage your account through your tenant portal.', 'rental-gates')
);

if (!empty($dashboard_url)) {
    echo Rental_Gates_Email::button(__('View Tenant Portal', 'rental-gates'), $dashboard_url);
}

echo Rental_Gates_Email::divider();

echo Rental_Gates_Email::text(
    __('Welcome to your new home! If you have any questions, please don\'t hesitate to reach out.', 'rental-gates'),
    'small'
);
