<?php
/**
 * Application Approved Email Template
 */
if (!defined('ABSPATH')) exit;
?>

<h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #111827;">
    <?php _e('Congratulations! 🎉', 'rental-gates'); ?>
</h1>

<p style="margin: 0 0 24px; font-size: 16px; color: #374151;">
    <?php printf(__('Hi %s,', 'rental-gates'), esc_html($applicant_name ?? __('there', 'rental-gates'))); ?>
</p>

<p style="margin: 0 0 24px; color: #374151;">
    <?php _e('Great news! Your rental application has been approved.', 'rental-gates'); ?>
</p>

<?php echo Rental_Gates_Email::info_box(
    '<table role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: center;">
        <tr>
            <td>
                <div style="width: 64px; height: 64px; margin: 0 auto 12px; background-color: #d1fae5; border-radius: 50%; line-height: 64px; font-size: 32px;">✓</div>
                <p style="margin: 0; font-size: 20px; font-weight: 700; color: #166534;">' . __('Application Approved', 'rental-gates') . '</p>
            </td>
        </tr>
    </table>',
    'success'
); ?>

<?php if (!empty($unit_name) || !empty($building_name)): ?>
<?php 
echo Rental_Gates_Email::details_table_start();
if (!empty($building_name)) {
    echo Rental_Gates_Email::detail_row(__('Property', 'rental-gates'), $building_name);
}
if (!empty($unit_name)) {
    echo Rental_Gates_Email::detail_row(__('Unit', 'rental-gates'), $unit_name);
}
if (!empty($move_in_date)) {
    echo Rental_Gates_Email::detail_row(__('Move-in Date', 'rental-gates'), $move_in_date);
}
if (!empty($rent_amount)) {
    echo Rental_Gates_Email::detail_row(__('Monthly Rent', 'rental-gates'), '$' . number_format($rent_amount, 2), true);
}
echo Rental_Gates_Email::details_table_end();
?>
<?php endif; ?>

<h2 style="margin: 32px 0 16px; font-size: 18px; font-weight: 600; color: #111827;">
    <?php _e('Next Steps', 'rental-gates'); ?>
</h2>

<table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #6366f1; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">1</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Review & Sign Lease', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('You\'ll receive your lease agreement to review and sign.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #d1d5db; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">2</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Pay Security Deposit', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('Submit your security deposit to secure the unit.', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="padding: 12px 0;">
            <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                <tr>
                    <td style="width: 40px; vertical-align: top;">
                        <div style="width: 32px; height: 32px; background-color: #d1d5db; border-radius: 50%; text-align: center; line-height: 32px; color: #fff; font-weight: 600;">3</div>
                    </td>
                    <td style="padding-left: 12px; vertical-align: top;">
                        <p style="margin: 0 0 4px; font-weight: 600; color: #111827;"><?php _e('Move In!', 'rental-gates'); ?></p>
                        <p style="margin: 0; font-size: 14px; color: #6b7280;"><?php _e('Pick up your keys and welcome to your new home!', 'rental-gates'); ?></p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php if (!empty($action_url)): ?>
<?php echo Rental_Gates_Email::button($action_url, __('View Application Details', 'rental-gates')); ?>
<?php endif; ?>

<p style="margin: 32px 0 0; font-size: 14px; color: #6b7280;">
    <?php _e('We\'re excited to have you! If you have any questions, please don\'t hesitate to reach out.', 'rental-gates'); ?>
</p>
