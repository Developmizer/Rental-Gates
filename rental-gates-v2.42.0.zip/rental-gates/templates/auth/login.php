<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title><?php _e('Login', 'rental-gates'); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
            background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%);
            min-height: 100vh;
            min-height: -webkit-fill-available;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            padding-top: calc(20px + env(safe-area-inset-top, 0px));
            padding-bottom: calc(20px + env(safe-area-inset-bottom, 0px));
        }

        html {
            height: -webkit-fill-available;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
        }

        .login-card {
            background: #fff;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        .login-logo {
            text-align: center;
            margin-bottom: 32px;
        }

        .login-logo h1 {
            font-size: 28px;
            font-weight: 700;
            color: #1e3a5f;
        }

        .login-logo p {
            color: #64748b;
            margin-top: 8px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #374151;
            margin-bottom: 6px;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.2s;
            -webkit-appearance: none;
            appearance: none;
        }

        .form-group input:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            min-height: 44px;
        }

        .form-check input[type="checkbox"] {
            width: 22px;
            height: 22px;
            cursor: pointer;
            flex-shrink: 0;
        }

        .form-check label {
            cursor: pointer;
            font-size: 14px;
            color: #374151;
        }

        .btn {
            width: 100%;
            padding: 16px;
            background: #2563eb;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
            min-height: 52px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn:hover {
            background: #1d4ed8;
        }

        .btn:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }

        .btn:active {
            transform: scale(0.98);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .login-footer {
            text-align: center;
            margin-top: 24px;
            color: #64748b;
            font-size: 14px;
        }

        .login-footer a {
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }

        .alert-success {
            background: #f0fdf4;
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }

        .forgot-link {
            text-align: right;
            margin-bottom: 20px;
        }

        .forgot-link a {
            color: #64748b;
            font-size: 14px;
            text-decoration: none;
            cursor: pointer;
            padding: 8px 0;
            display: inline-block;
        }

        .forgot-link a:hover {
            color: #2563eb;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            display: none;
            align-items: flex-end;
            justify-content: center;
            z-index: 1000;
            padding: 0;
        }

        .modal-overlay.open {
            display: flex;
        }

        .modal {
            background: #fff;
            border-radius: 20px 20px 0 0;
            padding: 32px;
            padding-bottom: calc(32px + env(safe-area-inset-bottom, 0px));
            width: 100%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }

        .modal h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1e3a5f;
            margin-bottom: 8px;
        }

        .modal p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 24px;
        }

        .modal-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 20px;
        }

        .modal-actions .btn {
            flex: 1;
        }

        /* Responsive */
        @media (max-width: 480px) {
            body {
                padding: 16px;
            }

            .login-card {
                padding: 28px 20px;
                border-radius: 12px;
            }

            .login-logo h1 {
                font-size: 24px;
            }

            .form-group input {
                padding: 12px 14px;
            }
        }

        @media (min-width: 500px) {
            .modal-overlay {
                align-items: center;
                padding: 20px;
            }

            .modal {
                border-radius: 16px;
            }

            .modal-actions {
                flex-direction: row;
            }
        }

        /* Loading spinner */
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .spinner {
            animation: spin 1s linear infinite;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-logo">
                <h1><?php _e('Rental Gates', 'rental-gates'); ?></h1>
                <p><?php _e('Sign in to your account', 'rental-gates'); ?></p>
            </div>

            <div id="login-alert" class="alert" style="display: none;"></div>

            <form id="login-form">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('rental_gates_nonce'); ?>">

                <div class="form-group">
                    <label for="email"><?php _e('Email Address', 'rental-gates'); ?></label>
                    <input type="email" id="email" name="email" required autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="password"><?php _e('Password', 'rental-gates'); ?></label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>

                <div class="forgot-link">
                    <a href="javascript:void(0)"
                        onclick="openForgotPasswordModal()"><?php _e('Forgot password?', 'rental-gates'); ?></a>
                </div>

                <div class="form-check">
                    <input type="checkbox" id="remember" name="remember" value="1">
                    <label for="remember"><?php _e('Remember me for 14 days', 'rental-gates'); ?></label>
                </div>

                <button type="submit" class="btn" id="login-btn">
                    <?php _e('Sign In', 'rental-gates'); ?>
                </button>

                <div style="margin-top: 16px; position: relative; text-align: center;">
                    <span
                        style="background: #fff; padding: 0 10px; color: #64748b; font-size: 13px; position: relative; z-index: 1;">Or</span>
                    <div
                        style="position: absolute; left: 0; right: 0; top: 50%; height: 1px; background: #e5e7eb; z-index: 0;">
                    </div>
                </div>

                <button type="button" class="btn btn-secondary" id="magic-link-btn" style="margin-top: 16px;"
                    onclick="sendMagicLink()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
                    </svg>
                    <?php _e('Email me a login link', 'rental-gates'); ?>
                </button>
            </form>

            <div class="login-footer">
                <p><?php _e("Don't have an account?", 'rental-gates'); ?> <a
                        href="<?php echo home_url('/rental-gates/register'); ?>"><?php _e('Sign up', 'rental-gates'); ?></a>
                </p>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div class="modal-overlay" id="forgotModal">
        <div class="modal">
            <h2><?php _e('Reset Password', 'rental-gates'); ?></h2>
            <p><?php _e("Enter your email address and we'll send you a link to reset your password.", 'rental-gates'); ?>
            </p>

            <div id="forgot-alert" class="alert" style="display: none;"></div>

            <form id="forgot-form">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('rental_gates_nonce'); ?>">
                <div class="form-group">
                    <label for="forgot-email"><?php _e('Email Address', 'rental-gates'); ?></label>
                    <input type="email" id="forgot-email" name="email" required>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary"
                        onclick="closeForgotPasswordModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                    <button type="submit" class="btn"
                        id="forgot-btn"><?php _e('Send Reset Link', 'rental-gates'); ?></button>
                </div>
            </form>
        </div>
    </div>

    <?php wp_footer(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('login-form');
            const alert = document.getElementById('login-alert');
            const btn = document.getElementById('login-btn');

            form.addEventListener('submit', async function (e) {
                e.preventDefault();

                btn.disabled = true;
                btn.textContent = '<?php _e("Signing in...", "rental-gates"); ?>';
                alert.style.display = 'none';

                const formData = new FormData(form);
                formData.append('action', 'rental_gates_login');

                try {
                    const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        window.location.href = data.data.redirect_url;
                    } else {
                        alert.className = 'alert alert-error';
                        alert.textContent = data.data.message || '<?php _e("Login failed", "rental-gates"); ?>';
                        alert.style.display = 'block';
                        btn.disabled = false;
                        btn.textContent = '<?php _e("Sign In", "rental-gates"); ?>';
                    }
                } catch (error) {
                    alert.className = 'alert alert-error';
                    alert.textContent = '<?php _e("An error occurred. Please try again.", "rental-gates"); ?>';
                    alert.style.display = 'block';
                    btn.disabled = false;
                    btn.textContent = '<?php _e("Sign In", "rental-gates"); ?>';
                }
            });

            // Check for logged_out param
            const params = new URLSearchParams(window.location.search);
            if (params.get('logged_out')) {
                alert.className = 'alert alert-success';
                alert.textContent = '<?php _e("You have been logged out successfully.", "rental-gates"); ?>';
                alert.style.display = 'block';
            }
            if (params.get('password_reset')) {
                alert.className = 'alert alert-success';
                alert.textContent = '<?php _e("Password reset successfully. Please log in with your new password.", "rental-gates"); ?>';
                alert.style.display = 'block';
            }

            // Forgot password form
            const forgotForm = document.getElementById('forgot-form');
            const forgotAlert = document.getElementById('forgot-alert');
            const forgotBtn = document.getElementById('forgot-btn');

            forgotForm.addEventListener('submit', async function (e) {
                e.preventDefault();

                forgotBtn.disabled = true;
                forgotBtn.textContent = '<?php _e("Sending...", "rental-gates"); ?>';
                forgotAlert.style.display = 'none';

                const formData = new FormData(forgotForm);
                formData.append('action', 'rental_gates_forgot_password');

                try {
                    const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        forgotAlert.className = 'alert alert-success';
                        forgotAlert.textContent = data.data.message;
                        forgotAlert.style.display = 'block';
                        forgotForm.reset();
                        forgotBtn.textContent = '<?php _e("Sent!", "rental-gates"); ?>';

                        // Close modal after 3 seconds
                        setTimeout(function () {
                            closeForgotPasswordModal();
                            forgotBtn.disabled = false;
                            forgotBtn.textContent = '<?php _e("Send Reset Link", "rental-gates"); ?>';
                            forgotAlert.style.display = 'none';
                        }, 3000);
                    } else {
                        forgotAlert.className = 'alert alert-error';
                        forgotAlert.textContent = data.data.message || '<?php _e("Failed to send reset link", "rental-gates"); ?>';
                        forgotAlert.style.display = 'block';
                        forgotBtn.disabled = false;
                        forgotBtn.textContent = '<?php _e("Send Reset Link", "rental-gates"); ?>';
                    }
                } catch (error) {
                    forgotAlert.className = 'alert alert-error';
                    forgotAlert.textContent = '<?php _e("An error occurred. Please try again.", "rental-gates"); ?>';
                    forgotAlert.style.display = 'block';
                    forgotBtn.disabled = false;
                    forgotBtn.textContent = '<?php _e("Send Reset Link", "rental-gates"); ?>';
                }
            });
        });

        function openForgotPasswordModal() {
            document.getElementById('forgotModal').classList.add('open');
            document.getElementById('forgot-email').focus();
        }

        function closeForgotPasswordModal() {
            document.getElementById('forgotModal').classList.remove('open');
        }

        // Close modal on overlay click
        document.getElementById('forgotModal').addEventListener('click', function (e) {
            if (e.target === this) closeForgotPasswordModal();
        });

        // Close modal on Escape key
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeForgotPasswordModal();
        });
        // Magic Link
        async function sendMagicLink() {
            const emailInput = document.getElementById('email');
            const email = emailInput.value;
            const btn = document.getElementById('magic-link-btn');
            const alert = document.getElementById('login-alert');

            if (!email) {
                alert.className = 'alert alert-error';
                alert.textContent = '<?php _e("Please enter your email address first.", "rental-gates"); ?>';
                alert.style.display = 'block';
                emailInput.focus();
                return;
            }

            btn.disabled = true;
            const originalText = btn.innerHTML;
            btn.textContent = '<?php _e("Sending...", "rental-gates"); ?>';
            alert.style.display = 'none';

            const formData = new FormData();
            formData.append('action', 'rental_gates_send_magic_link');
            formData.append('email', email);
            formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');

            try {
                const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    alert.className = 'alert alert-success';
                    alert.textContent = data.data.message;
                    alert.style.display = 'block';
                    btn.textContent = '<?php _e("Link Sent!", "rental-gates"); ?>';
                } else {
                    alert.className = 'alert alert-error';
                    alert.textContent = data.data.message || '<?php _e("Failed to send link", "rental-gates"); ?>';
                    alert.style.display = 'block';
                    btn.disabled = false;
                    btn.innerHTML = originalText;
                }
            } catch (error) {
                alert.className = 'alert alert-error';
                alert.textContent = '<?php _e("An error occurred. Please try again.", "rental-gates"); ?>';
                alert.style.display = 'block';
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        }
    </script>
</body>

</html>