<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Register', 'rental-gates'); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <?php
    // Get plan from URL parameter
    $selected_plan = isset($_GET['plan']) ? sanitize_text_field($_GET['plan']) : 'free';
    $billing_cycle = isset($_GET['billing']) ? sanitize_text_field($_GET['billing']) : 'monthly';
    
    // Valid plans
    $valid_plans = array('free', 'starter', 'professional', 'enterprise');
    if (!in_array($selected_plan, $valid_plans)) {
        $selected_plan = 'free';
    }
    
    // Plan details
    $plans = array(
        'free' => array(
            'name' => __('Free', 'rental-gates'),
            'price_monthly' => 0,
            'price_yearly' => 0,
            'description' => __('Up to 3 units', 'rental-gates'),
            'features' => array(
                __('Basic dashboard', 'rental-gates'),
                __('Tenant management', 'rental-gates'),
                __('Lease tracking', 'rental-gates'),
            ),
        ),
        'starter' => array(
            'name' => __('Starter', 'rental-gates'),
            'price_monthly' => 19,
            'price_yearly' => 15,
            'description' => __('Up to 10 units', 'rental-gates'),
            'features' => array(
                __('Tenant portal', 'rental-gates'),
                __('Online payments', 'rental-gates'),
                __('Maintenance tracking', 'rental-gates'),
                __('Email support', 'rental-gates'),
            ),
        ),
        'professional' => array(
            'name' => __('Professional', 'rental-gates'),
            'price_monthly' => 49,
            'price_yearly' => 39,
            'description' => __('Up to 50 units', 'rental-gates'),
            'features' => array(
                __('Everything in Starter', 'rental-gates'),
                __('AI-powered tools', 'rental-gates'),
                __('Vendor management', 'rental-gates'),
                __('Priority support', 'rental-gates'),
            ),
            'popular' => true,
        ),
        'enterprise' => array(
            'name' => __('Enterprise', 'rental-gates'),
            'price_monthly' => 149,
            'price_yearly' => 119,
            'description' => __('Unlimited units', 'rental-gates'),
            'features' => array(
                __('Everything in Professional', 'rental-gates'),
                __('API access', 'rental-gates'),
                __('Custom integrations', 'rental-gates'),
                __('Dedicated manager', 'rental-gates'),
            ),
        ),
    );
    
    $current_plan = $plans[$selected_plan];
    $is_free = $selected_plan === 'free';
    $price = $billing_cycle === 'yearly' ? $current_plan['price_yearly'] : $current_plan['price_monthly'];
    
    // Get platform settings
    $platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
    $primary_color = get_option('rental_gates_primary_color', '#2563eb');
    $terms_url = get_option('rental_gates_terms_url', '');
    $privacy_url = get_option('rental_gates_privacy_url', '');
    ?>
    <style>
        :root {
            --primary: <?php echo esc_attr($primary_color); ?>;
            --primary-dark: <?php echo esc_attr($primary_color); ?>dd;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%); 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            padding: 20px;
        }
        
        .register-wrapper {
            width: 100%;
            max-width: 1000px;
            display: grid;
            grid-template-columns: 380px 1fr;
            background: #fff;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
        }
        
        /* Left Panel - Plan Summary */
        .plan-panel {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 40px;
            display: flex;
            flex-direction: column;
        }
        
        .plan-panel-header { margin-bottom: 32px; }
        .plan-panel-logo { font-size: 20px; font-weight: 700; margin-bottom: 8px; opacity: 0.9; }
        .plan-panel-title { font-size: 14px; opacity: 0.8; }
        
        .plan-card {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }
        
        .plan-badge {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(255,255,255,0.2);
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }
        
        .plan-badge.popular { background: #fbbf24; color: #1e3a5f; }
        .plan-name { font-size: 28px; font-weight: 800; margin-bottom: 4px; }
        .plan-description { font-size: 14px; opacity: 0.85; margin-bottom: 16px; }
        .plan-price { display: flex; align-items: baseline; gap: 4px; margin-bottom: 8px; }
        .plan-price-currency { font-size: 20px; font-weight: 600; }
        .plan-price-amount { font-size: 48px; font-weight: 800; line-height: 1; }
        .plan-price-period { font-size: 16px; opacity: 0.8; }
        .plan-billing-note { font-size: 13px; opacity: 0.75; }
        
        .plan-features { list-style: none; margin-top: 24px; }
        .plan-features li { display: flex; align-items: center; gap: 10px; font-size: 14px; padding: 8px 0; opacity: 0.9; }
        .plan-features svg { width: 18px; height: 18px; flex-shrink: 0; }
        
        .plan-change { margin-top: auto; padding-top: 24px; }
        .plan-change a { color: white; opacity: 0.8; font-size: 14px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; transition: opacity 0.2s; }
        .plan-change a:hover { opacity: 1; }
        .plan-change svg { width: 16px; height: 16px; }
        
        /* Right Panel - Registration Form */
        .form-panel { padding: 40px; }
        .form-header { margin-bottom: 32px; }
        .form-header h1 { font-size: 24px; font-weight: 700; color: #1e293b; margin-bottom: 8px; }
        .form-header p { color: #64748b; font-size: 15px; }
        
        .trial-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: #ecfdf5;
            color: #059669;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 24px;
        }
        .trial-badge svg { width: 18px; height: 18px; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 6px; }
        .form-group input { width: 100%; padding: 12px 16px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 16px; transition: all 0.2s; background: #fff; }
        .form-group input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
        .form-group small { display: block; color: #64748b; font-size: 12px; margin-top: 4px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        
        .btn {
            width: 100%;
            padding: 14px 24px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn:hover { background: var(--primary-dark); transform: translateY(-1px); }
        .btn:disabled { background: #94a3b8; cursor: not-allowed; transform: none; }
        .btn svg { width: 20px; height: 20px; }
        
        .terms { font-size: 13px; color: #64748b; margin-bottom: 20px; line-height: 1.6; }
        .terms a { color: var(--primary); text-decoration: none; }
        .terms a:hover { text-decoration: underline; }
        
        .form-footer { text-align: center; margin-top: 24px; padding-top: 24px; border-top: 1px solid #e5e7eb; color: #64748b; font-size: 14px; }
        .form-footer a { color: var(--primary); text-decoration: none; font-weight: 600; }
        .form-footer a:hover { text-decoration: underline; }
        
        .alert { padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; display: flex; align-items: center; gap: 10px; }
        .alert svg { width: 20px; height: 20px; flex-shrink: 0; }
        .alert-error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
        
        .security-badges { display: flex; align-items: center; justify-content: center; gap: 16px; margin-top: 24px; padding-top: 20px; border-top: 1px solid #e5e7eb; }
        .security-badge { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #64748b; }
        .security-badge svg { width: 16px; height: 16px; color: #059669; }
        
        @media (max-width: 900px) {
            .register-wrapper { grid-template-columns: 1fr; max-width: 500px; }
            .plan-panel { padding: 24px; }
            .plan-card { display: flex; flex-wrap: wrap; gap: 16px; align-items: center; }
            .plan-card > div:first-child { flex: 1; }
            .plan-features { width: 100%; display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px 16px; margin-top: 16px; }
            .plan-features li { padding: 4px 0; }
            .plan-change { display: none; }
        }
        
        @media (max-width: 500px) {
            body { padding: 0; }
            .register-wrapper { border-radius: 0; min-height: 100vh; }
            .form-row { grid-template-columns: 1fr; }
            .plan-features { grid-template-columns: 1fr; }
            .security-badges { flex-wrap: wrap; gap: 12px; }
        }
        
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin { animation: spin 1s linear infinite; }
    </style>
</head>
<body>
    <div class="register-wrapper">
        <!-- Left Panel - Plan Summary -->
        <div class="plan-panel">
            <div class="plan-panel-header">
                <div class="plan-panel-logo"><?php echo esc_html($platform_name); ?></div>
                <div class="plan-panel-title"><?php _e('Your selected plan', 'rental-gates'); ?></div>
            </div>
            
            <div class="plan-card">
                <div>
                    <?php if (!empty($current_plan['popular'])): ?>
                    <span class="plan-badge popular"><?php _e('Most Popular', 'rental-gates'); ?></span>
                    <?php elseif ($is_free): ?>
                    <span class="plan-badge"><?php _e('Free Forever', 'rental-gates'); ?></span>
                    <?php else: ?>
                    <span class="plan-badge"><?php echo $billing_cycle === 'yearly' ? __('Annual Billing', 'rental-gates') : __('Monthly Billing', 'rental-gates'); ?></span>
                    <?php endif; ?>
                    
                    <h2 class="plan-name"><?php echo esc_html($current_plan['name']); ?></h2>
                    <p class="plan-description"><?php echo esc_html($current_plan['description']); ?></p>
                    
                    <div class="plan-price">
                        <span class="plan-price-currency">$</span>
                        <span class="plan-price-amount"><?php echo esc_html($price); ?></span>
                        <span class="plan-price-period">/<?php _e('mo', 'rental-gates'); ?></span>
                    </div>
                    
                    <?php if (!$is_free && $billing_cycle === 'yearly'): ?>
                    <p class="plan-billing-note"><?php printf(__('Billed annually at $%s/year', 'rental-gates'), $current_plan['price_yearly'] * 12); ?></p>
                    <?php elseif (!$is_free): ?>
                    <p class="plan-billing-note"><?php _e('Billed monthly', 'rental-gates'); ?></p>
                    <?php endif; ?>
                </div>
                
                <ul class="plan-features">
                    <?php foreach ($current_plan['features'] as $feature): ?>
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 13l4 4L19 7"/></svg>
                        <?php echo esc_html($feature); ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <div class="plan-change">
                <a href="<?php echo home_url('/rental-gates#rg-pricing'); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5m7-7l-7 7 7 7"/></svg>
                    <?php _e('Change plan', 'rental-gates'); ?>
                </a>
            </div>
        </div>
        
        <!-- Right Panel - Registration Form -->
        <div class="form-panel">
            <div class="form-header">
                <h1><?php _e('Create your account', 'rental-gates'); ?></h1>
                <p><?php _e('Start managing your properties in minutes', 'rental-gates'); ?></p>
            </div>
            
            <?php if (!$is_free): ?>
            <div class="payment-notice" style="display: flex; align-items: center; gap: 10px; padding: 12px 16px; background: #eff6ff; border-radius: 8px; margin-bottom: 20px; font-size: 14px; color: #1e40af;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 20px; height: 20px; flex-shrink: 0;"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <?php _e('Payment will be collected after account creation', 'rental-gates'); ?>
            </div>
            <?php endif; ?>
            
            <div id="register-alert" class="alert" style="display: none;"></div>
            
            <form id="register-form">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('rental_gates_nonce'); ?>">
                <input type="hidden" name="plan" value="<?php echo esc_attr($selected_plan); ?>">
                <input type="hidden" name="billing" value="<?php echo esc_attr($billing_cycle); ?>">
                
                <div class="form-group">
                    <label for="name"><?php _e('Full Name', 'rental-gates'); ?></label>
                    <input type="text" id="name" name="name" required autocomplete="name" placeholder="<?php esc_attr_e('John Smith', 'rental-gates'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email"><?php _e('Email Address', 'rental-gates'); ?></label>
                    <input type="email" id="email" name="email" required autocomplete="email" placeholder="<?php esc_attr_e('you@company.com', 'rental-gates'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="organization_name"><?php _e('Company / Organization', 'rental-gates'); ?></label>
                    <input type="text" id="organization_name" name="organization_name" required placeholder="<?php esc_attr_e('Acme Properties LLC', 'rental-gates'); ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password"><?php _e('Password', 'rental-gates'); ?></label>
                        <input type="password" id="password" name="password" required minlength="8" autocomplete="new-password" placeholder="<?php esc_attr_e('Min 8 characters', 'rental-gates'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password"><?php _e('Confirm Password', 'rental-gates'); ?></label>
                        <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password" placeholder="<?php esc_attr_e('Confirm password', 'rental-gates'); ?>">
                    </div>
                </div>
                
                <div class="terms">
                    <?php 
                    $terms_link = $terms_url ? '<a href="' . esc_url($terms_url) . '" target="_blank">' . __('Terms of Service', 'rental-gates') . '</a>' : __('Terms of Service', 'rental-gates');
                    $privacy_link = $privacy_url ? '<a href="' . esc_url($privacy_url) . '" target="_blank">' . __('Privacy Policy', 'rental-gates') . '</a>' : __('Privacy Policy', 'rental-gates');
                    printf(__('By creating an account, you agree to our %s and %s.', 'rental-gates'), $terms_link, $privacy_link); 
                    ?>
                </div>
                
                <button type="submit" class="btn" id="register-btn">
                    <?php echo $is_free ? __('Create Free Account', 'rental-gates') : __('Subscribe Now', 'rental-gates'); ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-7-7l7 7-7 7"/></svg>
                </button>
            </form>
            
            <div class="form-footer">
                <p><?php _e('Already have an account?', 'rental-gates'); ?> <a href="<?php echo home_url('/rental-gates/login'); ?>"><?php _e('Sign in', 'rental-gates'); ?></a></p>
            </div>
            
            <div class="security-badges">
                <div class="security-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    <?php _e('SSL Secured', 'rental-gates'); ?>
                </div>
                <div class="security-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                    <?php _e('Data Protected', 'rental-gates'); ?>
                </div>
                <div class="security-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    <?php _e('GDPR Ready', 'rental-gates'); ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php wp_footer(); ?>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('register-form');
        const alertEl = document.getElementById('register-alert');
        const btn = document.getElementById('register-btn');
        const selectedPlan = '<?php echo esc_js($selected_plan); ?>';
        const isFree = selectedPlan === 'free';
        const defaultBtnText = isFree ? '<?php echo esc_js(__("Create Free Account", "rental-gates")); ?>' : '<?php echo esc_js(__("Subscribe Now", "rental-gates")); ?>';
        
        function showAlert(type, message) {
            alertEl.className = 'alert alert-' + type;
            alertEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
                (type === 'error' ? '<circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6m0-6l6 6"/>' : '<path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>') + '</svg>' + message;
            alertEl.style.display = 'flex';
        }
        
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                showAlert('error', '<?php echo esc_js(__("Passwords do not match", "rental-gates")); ?>');
                return;
            }
            
            if (password.length < 8) {
                showAlert('error', '<?php echo esc_js(__("Password must be at least 8 characters", "rental-gates")); ?>');
                return;
            }
            
            btn.disabled = true;
            btn.innerHTML = '<svg class="animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" stroke-dasharray="32" stroke-dashoffset="32"/></svg> <?php echo esc_js(__("Creating account...", "rental-gates")); ?>';
            alertEl.style.display = 'none';
            
            const formData = new FormData(form);
            formData.append('action', 'rental_gates_register');
            
            try {
                const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', { method: 'POST', body: formData });
                const data = await response.json();
                
                console.log('Registration response:', data); // Debug log
                
                if (data.success) {
                    // Check if payment is required
                    if (data.data.payment_required) {
                        showAlert('success', '<?php echo esc_js(__("Account created! Redirecting to payment...", "rental-gates")); ?>');
                        btn.innerHTML = '<?php echo esc_js(__("Redirecting to payment...", "rental-gates")); ?>';
                    } else {
                        showAlert('success', '<?php echo esc_js(__("Account created successfully!", "rental-gates")); ?>');
                        btn.innerHTML = '<?php echo esc_js(__("Redirecting to dashboard...", "rental-gates")); ?>';
                    }
                    
                    // Always use redirect_url from response
                    const redirectUrl = data.data.redirect_url || '<?php echo esc_js(home_url("/rental-gates/dashboard")); ?>';
                    setTimeout(() => { window.location.href = redirectUrl; }, 1000);
                } else {
                    showAlert('error', data.data.message || '<?php echo esc_js(__("Registration failed", "rental-gates")); ?>');
                    btn.disabled = false;
                    btn.innerHTML = defaultBtnText;
                }
            } catch (error) {
                console.error('Registration error:', error);
                showAlert('error', '<?php echo esc_js(__("An error occurred. Please try again.", "rental-gates")); ?>');
                btn.disabled = false;
                btn.innerHTML = defaultBtnText;
            }
        });
    });
    </script>
</body>
</html>
