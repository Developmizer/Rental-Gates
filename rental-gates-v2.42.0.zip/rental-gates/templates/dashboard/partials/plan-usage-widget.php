<?php
/**
 * Plan Usage Widget - Shows current plan limits and usage
 */
if (!defined('ABSPATH')) exit;

// Get feature gate instance
$feature_gate = rg_feature_gate();
$plan = $feature_gate->get_org_plan();
$usage = $feature_gate->get_all_usage();
$modules = $feature_gate->get_all_modules();

// Count enabled modules
$enabled_modules = array_filter($modules, function($m) { return $m['enabled']; });
$total_modules = count($modules);
$enabled_count = count($enabled_modules);
?>

<div class="plan-usage-widget">
    <div class="plan-header">
        <div class="plan-info">
            <span class="plan-badge <?php echo esc_attr($plan['id'] ?? 'free'); ?>">
                <?php echo esc_html($plan['name'] ?? 'Free'); ?>
            </span>
            <span class="plan-label"><?php _e('Current Plan', 'rental-gates'); ?></span>
        </div>
        <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/billing')); ?>" class="btn btn-sm btn-outline">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
            </svg>
            <?php _e('Upgrade', 'rental-gates'); ?>
        </a>
    </div>
    
    <div class="usage-section">
        <h4 class="usage-title"><?php _e('Resource Usage', 'rental-gates'); ?></h4>
        
        <div class="usage-bars">
            <?php foreach ($usage as $resource => $data): 
                if ($data['disabled']) continue;
                
                $status = 'good';
                if ($data['percentage'] >= 90) $status = 'critical';
                elseif ($data['percentage'] >= 70) $status = 'warning';
            ?>
            <div class="usage-item">
                <div class="usage-item-header">
                    <span class="usage-item-label"><?php echo esc_html($data['label']); ?></span>
                    <span class="usage-item-value">
                        <?php if ($data['unlimited']): ?>
                            <?php echo esc_html($data['current']); ?> / ∞
                        <?php else: ?>
                            <?php echo esc_html($data['current']); ?> / <?php echo esc_html($data['limit']); ?>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="usage-bar-track">
                    <div class="usage-bar-fill <?php echo esc_attr($status); ?>" style="width: <?php echo $data['unlimited'] ? '0' : $data['percentage']; ?>%"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div class="modules-section">
        <h4 class="usage-title">
            <?php _e('Features', 'rental-gates'); ?>
            <span class="modules-count"><?php echo $enabled_count; ?>/<?php echo $total_modules; ?></span>
        </h4>
        
        <div class="modules-grid">
            <?php foreach ($modules as $module): ?>
            <div class="module-item <?php echo $module['enabled'] ? 'enabled' : 'disabled'; ?>" title="<?php echo esc_attr($module['description']); ?>">
                <?php if ($module['enabled']): ?>
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
                <?php else: ?>
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                </svg>
                <?php endif; ?>
                <span><?php echo esc_html($module['label']); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<style>
.plan-usage-widget {
    background: #fff;
    border: 1px solid #e7e5e4;
    border-radius: 12px;
    padding: 20px;
}

.plan-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px solid #f5f5f4;
}

.plan-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.plan-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 100px;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
}

.plan-badge.free { background: #e7e5e4; color: #57534e; }
.plan-badge.basic { background: #dbeafe; color: #1e40af; }
.plan-badge.silver { background: #f3e8ff; color: #7c3aed; }
.plan-badge.gold { background: #fef3c7; color: #b45309; }

.plan-label {
    font-size: 13px;
    color: #78716c;
}

.usage-section {
    margin-bottom: 20px;
}

.usage-title {
    font-size: 13px;
    font-weight: 600;
    color: #57534e;
    margin: 0 0 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.modules-count {
    font-weight: 500;
    color: #78716c;
}

.usage-bars {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.usage-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.usage-item-header {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
}

.usage-item-label {
    color: #57534e;
    font-weight: 500;
}

.usage-item-value {
    color: #78716c;
    font-family: monospace;
}

.usage-bar-track {
    height: 6px;
    background: #f5f5f4;
    border-radius: 3px;
    overflow: hidden;
}

.usage-bar-fill {
    height: 100%;
    border-radius: 3px;
    transition: width 0.3s ease;
}

.usage-bar-fill.good { background: #059669; }
.usage-bar-fill.warning { background: #f59e0b; }
.usage-bar-fill.critical { background: #dc2626; }

.modules-section {
    padding-top: 16px;
    border-top: 1px solid #f5f5f4;
}

.modules-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
}

.module-item {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 500;
}

.module-item.enabled {
    background: #f0fdfa;
    color: #0d9488;
}

.module-item.disabled {
    background: #fafaf9;
    color: #a8a29e;
}

.module-item svg {
    flex-shrink: 0;
}
</style>
