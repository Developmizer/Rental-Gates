<?php
/**
 * Documents Widget - Reusable component for entity detail pages
 * 
 * Usage: Include this file with these variables set:
 * - $entity_type: 'building', 'unit', 'tenant', 'lease', 'vendor', etc.
 * - $entity_id: The ID of the entity
 * - $org_id: Organization ID
 */
if (!defined('ABSPATH')) exit;

if (!isset($entity_type) || !isset($entity_id) || !isset($org_id)) {
    return;
}

// Get documents for this entity
$entity_documents = Rental_Gates_Document::get_for_entity($entity_type, $entity_id);
$document_types = Rental_Gates_Document::get_document_types();

// Generate unique ID for this widget instance
$widget_id = 'doc_widget_' . $entity_type . '_' . $entity_id;
?>

<style>
    .rg-docs-widget { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-top: 20px; }
    .rg-docs-widget-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-docs-widget-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; display: flex; align-items: center; gap: 8px; }
    .rg-docs-widget-title svg { width: 20px; height: 20px; color: var(--gray-500); }
    .rg-docs-widget-count { background: var(--gray-100); color: var(--gray-600); padding: 2px 8px; border-radius: 10px; font-size: 12px; font-weight: 500; }
    
    .rg-docs-widget-body { padding: 16px 20px; }
    .rg-docs-widget-empty { text-align: center; padding: 30px 20px; color: var(--gray-500); }
    .rg-docs-widget-empty svg { width: 40px; height: 40px; color: var(--gray-300); margin-bottom: 12px; }
    
    .rg-docs-widget-list { display: flex; flex-direction: column; gap: 12px; }
    .rg-docs-widget-item { display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid var(--gray-200); border-radius: 8px; transition: all 0.2s; }
    .rg-docs-widget-item:hover { border-color: var(--gray-300); background: var(--gray-50); }
    
    .rg-docs-widget-icon { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-docs-widget-icon.pdf { background: #fee2e2; color: #dc2626; }
    .rg-docs-widget-icon.doc { background: #dbeafe; color: #2563eb; }
    .rg-docs-widget-icon.xls { background: #d1fae5; color: #059669; }
    .rg-docs-widget-icon.img { background: #fef3c7; color: #d97706; }
    .rg-docs-widget-icon.default { background: var(--gray-100); color: var(--gray-500); }
    .rg-docs-widget-icon svg { width: 20px; height: 20px; }
    
    .rg-docs-widget-info { flex: 1; min-width: 0; }
    .rg-docs-widget-name { font-size: 14px; font-weight: 500; color: var(--gray-900); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rg-docs-widget-meta { font-size: 12px; color: var(--gray-500); margin-top: 2px; }
    
    .rg-docs-widget-actions { display: flex; gap: 4px; }
    .rg-docs-widget-action { padding: 6px; border: none; background: none; cursor: pointer; color: var(--gray-400); border-radius: 6px; transition: all 0.2s; }
    .rg-docs-widget-action:hover { background: var(--gray-100); color: var(--gray-600); }
    .rg-docs-widget-action.danger:hover { background: #fee2e2; color: #dc2626; }
    .rg-docs-widget-action svg { width: 16px; height: 16px; display: block; }
    
    .rg-docs-widget-upload { margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-100); }
    .rg-docs-upload-zone { border: 2px dashed var(--gray-300); border-radius: 8px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; }
    .rg-docs-upload-zone:hover, .rg-docs-upload-zone.dragover { border-color: var(--primary); background: #eff6ff; }
    .rg-docs-upload-zone svg { width: 24px; height: 24px; color: var(--gray-400); margin-bottom: 8px; }
    .rg-docs-upload-zone p { font-size: 13px; color: var(--gray-500); margin: 0; }
    .rg-docs-upload-zone input { display: none; }
    
    .rg-docs-upload-form { display: none; margin-top: 12px; }
    .rg-docs-upload-form.active { display: block; }
    .rg-docs-upload-form select, .rg-docs-upload-form input { width: 100%; padding: 8px 12px; border: 1px solid var(--gray-300); border-radius: 6px; font-size: 13px; margin-bottom: 8px; }
    .rg-docs-upload-form-row { display: flex; gap: 8px; }
    .rg-docs-upload-form-row button { flex: 1; padding: 8px; border-radius: 6px; font-size: 13px; cursor: pointer; }
    .rg-docs-upload-form-row .cancel { background: #fff; border: 1px solid var(--gray-300); color: var(--gray-600); }
    .rg-docs-upload-form-row .upload { background: var(--primary); border: none; color: #fff; }
</style>

<div class="rg-docs-widget" id="<?php echo esc_attr($widget_id); ?>">
    <div class="rg-docs-widget-header">
        <h4 class="rg-docs-widget-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            <?php _e('Documents', 'rental-gates'); ?>
            <span class="rg-docs-widget-count"><?php echo count($entity_documents); ?></span>
        </h4>
    </div>
    
    <div class="rg-docs-widget-body">
        <?php if (empty($entity_documents)): ?>
        <div class="rg-docs-widget-empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            <p><?php _e('No documents uploaded yet', 'rental-gates'); ?></p>
        </div>
        <?php else: ?>
        <div class="rg-docs-widget-list">
            <?php foreach ($entity_documents as $doc): 
                $icon_class = 'default';
                if (strpos($doc['mime_type'], 'pdf') !== false) $icon_class = 'pdf';
                elseif (strpos($doc['mime_type'], 'word') !== false || strpos($doc['mime_type'], 'document') !== false) $icon_class = 'doc';
                elseif (strpos($doc['mime_type'], 'excel') !== false || strpos($doc['mime_type'], 'sheet') !== false) $icon_class = 'xls';
                elseif (strpos($doc['mime_type'], 'image') !== false) $icon_class = 'img';
            ?>
            <div class="rg-docs-widget-item" data-id="<?php echo $doc['id']; ?>">
                <div class="rg-docs-widget-icon <?php echo $icon_class; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                </div>
                <div class="rg-docs-widget-info">
                    <div class="rg-docs-widget-name" title="<?php echo esc_attr($doc['title']); ?>"><?php echo esc_html($doc['title']); ?></div>
                    <div class="rg-docs-widget-meta"><?php echo esc_html($doc['document_type_label']); ?> • <?php echo esc_html($doc['file_size_formatted']); ?></div>
                </div>
                <div class="rg-docs-widget-actions">
                    <a href="<?php echo esc_url($doc['file_url']); ?>" target="_blank" class="rg-docs-widget-action" title="<?php _e('View', 'rental-gates'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    </a>
                    <a href="<?php echo esc_url($doc['file_url']); ?>" download class="rg-docs-widget-action" title="<?php _e('Download', 'rental-gates'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                    <button onclick="deleteWidgetDoc(<?php echo $doc['id']; ?>, '<?php echo esc_js($widget_id); ?>')" class="rg-docs-widget-action danger" title="<?php _e('Delete', 'rental-gates'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div class="rg-docs-widget-upload">
            <div class="rg-docs-upload-zone" id="<?php echo esc_attr($widget_id); ?>_zone" onclick="document.getElementById('<?php echo esc_attr($widget_id); ?>_file').click()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <p><?php _e('Click or drag to upload document', 'rental-gates'); ?></p>
                <input type="file" id="<?php echo esc_attr($widget_id); ?>_file" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif,.webp,.txt,.csv">
            </div>
            
            <form class="rg-docs-upload-form" id="<?php echo esc_attr($widget_id); ?>_form">
                <input type="hidden" name="entity_type" value="<?php echo esc_attr($entity_type); ?>">
                <input type="hidden" name="entity_id" value="<?php echo esc_attr($entity_id); ?>">
                <input type="text" name="title" placeholder="<?php _e('Document title...', 'rental-gates'); ?>" id="<?php echo esc_attr($widget_id); ?>_title">
                <select name="document_type">
                    <?php foreach ($document_types as $key => $label): ?>
                        <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="rg-docs-upload-form-row">
                    <button type="button" class="cancel" onclick="cancelWidgetUpload('<?php echo esc_js($widget_id); ?>')"><?php _e('Cancel', 'rental-gates'); ?></button>
                    <button type="submit" class="upload"><?php _e('Upload', 'rental-gates'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function() {
    const widgetId = '<?php echo esc_js($widget_id); ?>';
    const fileInput = document.getElementById(widgetId + '_file');
    const uploadZone = document.getElementById(widgetId + '_zone');
    const uploadForm = document.getElementById(widgetId + '_form');
    
    let selectedFile = null;
    
    fileInput.addEventListener('change', function() {
        if (this.files[0]) {
            selectedFile = this.files[0];
            document.getElementById(widgetId + '_title').value = selectedFile.name.replace(/\.[^/.]+$/, '');
            uploadZone.style.display = 'none';
            uploadForm.classList.add('active');
        }
    });
    
    uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('dragover'); });
    uploadZone.addEventListener('dragleave', () => { uploadZone.classList.remove('dragover'); });
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            fileInput.files = e.dataTransfer.files;
            fileInput.dispatchEvent(new Event('change'));
        }
    });
    
    uploadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        if (!selectedFile) return;
        
        const btn = this.querySelector('.upload');
        btn.disabled = true;
        btn.textContent = '<?php echo esc_js(__('Uploading...', 'rental-gates')); ?>';
        
        const formData = new FormData();
        formData.append('action', 'rental_gates_upload_document');
        formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
        formData.append('document', selectedFile);
        formData.append('entity_type', this.entity_type.value);
        formData.append('entity_id', this.entity_id.value);
        formData.append('document_type', this.document_type.value);
        formData.append('title', this.title.value || selectedFile.name);
        
        try {
            const response = await fetch(ajaxurl, { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                location.reload();
            } else {
                alert(data.data?.message || '<?php echo esc_js(__('Upload failed', 'rental-gates')); ?>');
            }
        } catch (error) {
            alert('<?php echo esc_js(__('An error occurred', 'rental-gates')); ?>');
        }
        
        btn.disabled = false;
        btn.textContent = '<?php echo esc_js(__('Upload', 'rental-gates')); ?>';
    });
})();

function cancelWidgetUpload(widgetId) {
    document.getElementById(widgetId + '_file').value = '';
    document.getElementById(widgetId + '_zone').style.display = 'block';
    document.getElementById(widgetId + '_form').classList.remove('active');
}

function deleteWidgetDoc(docId, widgetId) {
    if (!confirm('<?php echo esc_js(__('Delete this document?', 'rental-gates')); ?>')) return;
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_delete_document');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
    formData.append('document_id', docId);
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const item = document.querySelector('#' + widgetId + ' .rg-docs-widget-item[data-id="' + docId + '"]');
            if (item) item.remove();
            // Update count
            const countEl = document.querySelector('#' + widgetId + ' .rg-docs-widget-count');
            if (countEl) countEl.textContent = parseInt(countEl.textContent) - 1;
        } else {
            alert(data.data?.message || '<?php echo esc_js(__('Delete failed', 'rental-gates')); ?>');
        }
    });
}
</script>
