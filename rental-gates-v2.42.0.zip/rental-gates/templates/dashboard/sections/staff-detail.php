<?php
/**
 * Staff Management - Detail View
 * View staff member details and permissions
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Ensure org_id is set
if (empty($org_id)) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Get staff ID from URL
$staff_id = 0;
if (preg_match('#/staff/(\d+)(?:/|$)#', $_SERVER['REQUEST_URI'], $matches)) {
    $staff_id = intval($matches[1]);
}

if (!$staff_id) {
    echo '<div class="rg-error-box"><h2>' . __('Staff member not found', 'rental-gates') . '</h2><a href="' . home_url('/rental-gates/dashboard/staff') . '">' . __('Back to Staff', 'rental-gates') . '</a></div>';
    return;
}

// Get staff details
$staff = $wpdb->get_row($wpdb->prepare(
    "SELECT om.*, u.display_name, u.user_email, u.user_registered,
            um_phone.meta_value as phone,
            um_title.meta_value as job_title
     FROM {$tables['organization_members']} om
     JOIN {$wpdb->users} u ON om.user_id = u.ID
     LEFT JOIN {$wpdb->usermeta} um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'phone'
     LEFT JOIN {$wpdb->usermeta} um_title ON u.ID = um_title.user_id AND um_title.meta_key = 'job_title'
     WHERE om.id = %d AND om.organization_id = %d AND om.role = 'staff'",
    $staff_id,
    $org_id
), ARRAY_A);

if (!$staff) {
    echo '<div class="rg-error-box"><h2>' . __('Staff member not found', 'rental-gates') . '</h2><a href="' . home_url('/rental-gates/dashboard/staff') . '">' . __('Back to Staff', 'rental-gates') . '</a></div>';
    return;
}

$permissions = json_decode($staff['permissions'] ?? '{}', true) ?: array();

// Module definitions
$modules = array(
    'buildings' => array('label' => __('Buildings & Units', 'rental-gates'), 'icon' => '🏢'),
    'tenants' => array('label' => __('Tenants', 'rental-gates'), 'icon' => '👥'),
    'leases' => array('label' => __('Leases', 'rental-gates'), 'icon' => '📋'),
    'applications' => array('label' => __('Applications', 'rental-gates'), 'icon' => '📝'),
    'maintenance' => array('label' => __('Maintenance', 'rental-gates'), 'icon' => '🔧'),
    'payments' => array('label' => __('Payments', 'rental-gates'), 'icon' => '💳'),
    'vendors' => array('label' => __('Vendors', 'rental-gates'), 'icon' => '🏪'),
    'leads' => array('label' => __('Leads', 'rental-gates'), 'icon' => '🎯'),
);

// Get initials
$initials = strtoupper(substr($staff['display_name'], 0, 1) . substr(strstr($staff['display_name'], ' '), 1, 1));
if (strlen($initials) < 2) $initials = strtoupper(substr($staff['display_name'], 0, 2));

// Get recent activity (placeholder - would need activity log table)
$recent_logins = $wpdb->get_var($wpdb->prepare(
    "SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = 'last_login'",
    $staff['user_id']
));
?>

<style>
    .rg-page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-back-link { display: inline-flex; align-items: center; gap: 8px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 8px; }
    .rg-back-link:hover { color: var(--primary); }
    .rg-page-title { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
    .rg-btn-secondary:hover { background: var(--gray-200); }
    
    .rg-detail-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 24px; }
    
    .rg-profile-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 32px; text-align: center; }
    .rg-profile-avatar { width: 96px; height: 96px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 36px; font-weight: 600; margin: 0 auto 20px; }
    .rg-profile-name { font-size: 20px; font-weight: 700; color: var(--gray-900); margin: 0 0 4px; }
    .rg-profile-title { font-size: 14px; color: var(--gray-500); margin: 0 0 16px; }
    .rg-profile-status { display: inline-flex; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-profile-status.active { background: #d1fae5; color: #065f46; }
    .rg-profile-status.pending { background: #fef3c7; color: #92400e; }
    .rg-profile-status.inactive { background: #fee2e2; color: #991b1b; }
    
    .rg-profile-contact { margin-top: 24px; padding-top: 24px; border-top: 1px solid var(--gray-100); text-align: left; }
    .rg-contact-item { display: flex; align-items: center; gap: 12px; padding: 10px 0; }
    .rg-contact-item svg { width: 18px; height: 18px; color: var(--gray-400); flex-shrink: 0; }
    .rg-contact-item a { color: var(--primary); text-decoration: none; }
    .rg-contact-item span { color: var(--gray-600); font-size: 14px; }
    
    .rg-profile-meta { margin-top: 24px; padding-top: 24px; border-top: 1px solid var(--gray-100); }
    .rg-meta-item { display: flex; justify-content: space-between; padding: 8px 0; font-size: 13px; }
    .rg-meta-label { color: var(--gray-500); }
    .rg-meta-value { color: var(--gray-900); font-weight: 500; }
    
    .rg-permissions-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; }
    .rg-card-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .rg-card-body { padding: 24px; }
    
    .rg-permissions-table { width: 100%; border-collapse: collapse; }
    .rg-permissions-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; }
    .rg-permissions-table td { padding: 16px; border-top: 1px solid var(--gray-100); }
    .rg-permissions-table tr:hover { background: var(--gray-50); }
    
    .rg-module-cell { display: flex; align-items: center; gap: 12px; }
    .rg-module-icon { font-size: 20px; }
    .rg-module-name { font-weight: 500; color: var(--gray-900); }
    
    .rg-perm-badge { display: inline-flex; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-perm-badge.none { background: var(--gray-100); color: var(--gray-500); }
    .rg-perm-badge.view { background: #dbeafe; color: #1d4ed8; }
    .rg-perm-badge.edit { background: #d1fae5; color: #065f46; }
    .rg-perm-badge.full { background: #ede9fe; color: #6d28d9; }
    
    .rg-perm-desc { font-size: 12px; color: var(--gray-500); }
    
    @media (max-width: 1024px) {
        .rg-detail-grid { grid-template-columns: 1fr; }
    }
</style>

<!-- Page Header -->
<div class="rg-page-header">
    <div>
        <a href="<?php echo home_url('/rental-gates/dashboard/staff'); ?>" class="rg-back-link">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            <?php _e('Back to Staff', 'rental-gates'); ?>
        </a>
        <h1 class="rg-page-title"><?php _e('Staff Details', 'rental-gates'); ?></h1>
    </div>
    <a href="<?php echo home_url('/rental-gates/dashboard/staff/' . $staff_id . '/edit'); ?>" class="rg-btn rg-btn-primary">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        <?php _e('Edit Permissions', 'rental-gates'); ?>
    </a>
</div>

<div class="rg-detail-grid">
    <!-- Profile Card -->
    <div class="rg-profile-card">
        <div class="rg-profile-avatar"><?php echo esc_html($initials); ?></div>
        <h2 class="rg-profile-name"><?php echo esc_html($staff['display_name']); ?></h2>
        <?php if (!empty($staff['job_title'])): ?>
        <p class="rg-profile-title"><?php echo esc_html($staff['job_title']); ?></p>
        <?php endif; ?>
        <span class="rg-profile-status <?php echo esc_attr($staff['status']); ?>">
            <?php echo esc_html(ucfirst($staff['status'])); ?>
        </span>
        
        <div class="rg-profile-contact">
            <div class="rg-contact-item">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                <a href="mailto:<?php echo esc_attr($staff['user_email']); ?>"><?php echo esc_html($staff['user_email']); ?></a>
            </div>
            <?php if (!empty($staff['phone'])): ?>
            <div class="rg-contact-item">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <a href="tel:<?php echo esc_attr($staff['phone']); ?>"><?php echo esc_html($staff['phone']); ?></a>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="rg-profile-meta">
            <div class="rg-meta-item">
                <span class="rg-meta-label"><?php _e('Added', 'rental-gates'); ?></span>
                <span class="rg-meta-value"><?php echo date('M j, Y', strtotime($staff['created_at'])); ?></span>
            </div>
            <?php if ($recent_logins): ?>
            <div class="rg-meta-item">
                <span class="rg-meta-label"><?php _e('Last Login', 'rental-gates'); ?></span>
                <span class="rg-meta-value"><?php echo human_time_diff(strtotime($recent_logins), current_time('timestamp')) . ' ' . __('ago', 'rental-gates'); ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Permissions Card -->
    <div class="rg-permissions-card">
        <div class="rg-card-header">
            <h3 class="rg-card-title"><?php _e('Access Permissions', 'rental-gates'); ?></h3>
        </div>
        <div class="rg-card-body" style="padding: 0;">
            <table class="rg-permissions-table">
                <thead>
                    <tr>
                        <th><?php _e('Module', 'rental-gates'); ?></th>
                        <th><?php _e('Access Level', 'rental-gates'); ?></th>
                        <th><?php _e('Can Do', 'rental-gates'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($modules as $key => $module): 
                        $perm = $permissions[$key] ?? 'none';
                        $perm_labels = array(
                            'none' => __('No Access', 'rental-gates'),
                            'view' => __('View Only', 'rental-gates'),
                            'edit' => __('View & Edit', 'rental-gates'),
                            'full' => __('Full Access', 'rental-gates'),
                        );
                        $perm_desc = array(
                            'none' => __('Cannot access this module', 'rental-gates'),
                            'view' => __('Can view records but not modify', 'rental-gates'),
                            'edit' => __('Can view and modify existing records', 'rental-gates'),
                            'full' => __('Can create, edit, and delete records', 'rental-gates'),
                        );
                    ?>
                    <tr>
                        <td>
                            <div class="rg-module-cell">
                                <span class="rg-module-icon"><?php echo $module['icon']; ?></span>
                                <span class="rg-module-name"><?php echo esc_html($module['label']); ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="rg-perm-badge <?php echo esc_attr($perm); ?>">
                                <?php echo esc_html($perm_labels[$perm]); ?>
                            </span>
                        </td>
                        <td>
                            <span class="rg-perm-desc"><?php echo esc_html($perm_desc[$perm]); ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
