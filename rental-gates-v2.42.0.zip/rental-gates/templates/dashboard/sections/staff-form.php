<?php
/**
 * Staff Management - Add/Edit Form
 * Invite new staff or edit existing staff permissions
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Ensure org_id is set
if (empty($org_id)) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Check if editing existing staff
$staff_id = 0;
$staff = null;
$is_edit = false;

if (preg_match('#/staff/(\d+)/edit#', $_SERVER['REQUEST_URI'], $matches)) {
    $staff_id = intval($matches[1]);
    $is_edit = true;
    
    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT om.*, u.display_name, u.user_email
         FROM {$tables['organization_members']} om
         JOIN {$wpdb->users} u ON om.user_id = u.ID
         WHERE om.id = %d AND om.organization_id = %d AND om.role = 'staff'",
        $staff_id,
        $org_id
    ), ARRAY_A);
    
    if (!$staff) {
        echo '<div class="rg-error-box"><h2>' . __('Staff member not found', 'rental-gates') . '</h2><a href="' . home_url('/rental-gates/dashboard/staff') . '">' . __('Back to Staff', 'rental-gates') . '</a></div>';
        return;
    }
}

// Get current permissions
$current_permissions = $is_edit ? (json_decode($staff['permissions'] ?? '{}', true) ?: array()) : array();

// Module definitions
$modules = array(
    'buildings' => array(
        'label' => __('Buildings & Units', 'rental-gates'),
        'description' => __('Manage property listings, units, and availability', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>',
    ),
    'tenants' => array(
        'label' => __('Tenants', 'rental-gates'),
        'description' => __('View and manage tenant information', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>',
    ),
    'leases' => array(
        'label' => __('Leases', 'rental-gates'),
        'description' => __('View and manage lease agreements', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>',
    ),
    'applications' => array(
        'label' => __('Applications', 'rental-gates'),
        'description' => __('Review and process rental applications', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>',
    ),
    'maintenance' => array(
        'label' => __('Maintenance', 'rental-gates'),
        'description' => __('Handle work orders and maintenance requests', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>',
    ),
    'payments' => array(
        'label' => __('Payments', 'rental-gates'),
        'description' => __('View payment records and transactions', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    ),
    'vendors' => array(
        'label' => __('Vendors', 'rental-gates'),
        'description' => __('Manage vendor relationships and contacts', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>',
    ),
    'leads' => array(
        'label' => __('Leads', 'rental-gates'),
        'description' => __('Track and manage prospective tenants', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>',
    ),
);

// Permission levels
$permission_levels = array(
    'none' => array('label' => __('No Access', 'rental-gates'), 'color' => '#9ca3af'),
    'view' => array('label' => __('View Only', 'rental-gates'), 'color' => '#3b82f6'),
    'edit' => array('label' => __('View & Edit', 'rental-gates'), 'color' => '#10b981'),
    'full' => array('label' => __('Full Access', 'rental-gates'), 'color' => '#8b5cf6'),
);
?>

<style>
    .rg-form-container { max-width: 900px; }
    
    .rg-page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .rg-page-title { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    .rg-back-link { display: inline-flex; align-items: center; gap: 8px; color: var(--gray-500); text-decoration: none; font-size: 14px; }
    .rg-back-link:hover { color: var(--primary); }
    
    .rg-form-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-form-card-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); }
    .rg-form-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .rg-form-card-subtitle { font-size: 13px; color: var(--gray-500); margin: 4px 0 0; }
    .rg-form-card-body { padding: 24px; }
    
    .rg-form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 20px; }
    .rg-form-row.single { grid-template-columns: 1fr; }
    .rg-form-group { display: flex; flex-direction: column; gap: 6px; }
    .rg-form-label { font-size: 14px; font-weight: 500; color: var(--gray-700); }
    .rg-form-label .required { color: #ef4444; }
    .rg-form-input { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; transition: border-color 0.2s, box-shadow 0.2s; }
    .rg-form-input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.1); }
    .rg-form-hint { font-size: 12px; color: var(--gray-500); }
    
    .rg-permissions-grid { display: grid; gap: 16px; }
    .rg-permission-item { display: grid; grid-template-columns: 1fr auto; gap: 16px; align-items: center; padding: 16px; background: var(--gray-50); border-radius: 10px; border: 1px solid var(--gray-200); }
    .rg-permission-info { display: flex; align-items: flex-start; gap: 12px; }
    .rg-permission-icon { width: 40px; height: 40px; background: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; border: 1px solid var(--gray-200); }
    .rg-permission-icon svg { width: 20px; height: 20px; color: var(--gray-600); }
    .rg-permission-text h4 { font-size: 14px; font-weight: 600; color: var(--gray-900); margin: 0 0 4px; }
    .rg-permission-text p { font-size: 12px; color: var(--gray-500); margin: 0; }
    
    .rg-permission-select { display: flex; gap: 8px; }
    .rg-perm-option { padding: 8px 14px; border: 2px solid var(--gray-200); border-radius: 8px; font-size: 13px; font-weight: 500; background: #fff; cursor: pointer; transition: all 0.2s; white-space: nowrap; }
    .rg-perm-option:hover { border-color: var(--gray-300); }
    .rg-perm-option.selected { border-color: var(--primary); background: rgba(14, 165, 233, 0.05); color: var(--primary); }
    .rg-perm-option input { display: none; }
    
    .rg-quick-actions { display: flex; gap: 12px; margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid var(--gray-200); }
    .rg-quick-btn { padding: 8px 16px; border: 1px solid var(--gray-300); border-radius: 8px; background: #fff; font-size: 13px; cursor: pointer; transition: all 0.2s; }
    .rg-quick-btn:hover { background: var(--gray-50); border-color: var(--gray-400); }
    
    .rg-form-actions { display: flex; justify-content: flex-end; gap: 12px; padding: 20px 24px; border-top: 1px solid var(--gray-100); background: var(--gray-50); border-radius: 0 0 12px 12px; }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
    .rg-btn-secondary:hover { background: var(--gray-200); }
    .rg-btn-danger { background: #fee2e2; color: #991b1b; }
    .rg-btn-danger:hover { background: #fecaca; }
    
    .rg-alert { padding: 16px 20px; border-radius: 10px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 12px; }
    .rg-alert-info { background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; }
    .rg-alert svg { flex-shrink: 0; margin-top: 2px; }
    
    @media (max-width: 768px) {
        .rg-form-row { grid-template-columns: 1fr; }
        .rg-permission-item { grid-template-columns: 1fr; }
        .rg-permission-select { flex-wrap: wrap; }
    }
</style>

<div class="rg-form-container">
    <!-- Page Header -->
    <div class="rg-page-header">
        <div>
            <a href="<?php echo home_url('/rental-gates/dashboard/staff'); ?>" class="rg-back-link">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                <?php _e('Back to Staff', 'rental-gates'); ?>
            </a>
            <h1 class="rg-page-title"><?php echo $is_edit ? __('Edit Staff Member', 'rental-gates') : __('Invite Staff Member', 'rental-gates'); ?></h1>
        </div>
    </div>

    <form id="staff-form" method="post">
        <?php wp_nonce_field('rental_gates_staff_form', 'staff_nonce'); ?>
        <input type="hidden" name="action" value="<?php echo $is_edit ? 'update_staff' : 'invite_staff'; ?>">
        <?php if ($is_edit): ?>
        <input type="hidden" name="staff_id" value="<?php echo esc_attr($staff_id); ?>">
        <?php endif; ?>
        
        <?php if (!$is_edit): ?>
        <!-- Invite Info -->
        <div class="rg-alert rg-alert-info">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <div>
                <strong><?php _e('How invitations work', 'rental-gates'); ?></strong>
                <p style="margin: 4px 0 0; font-size: 13px;"><?php _e('An email will be sent to the staff member with a link to set up their account. They\'ll automatically be assigned the staff role with the permissions you configure below.', 'rental-gates'); ?></p>
            </div>
        </div>
        
        <!-- Basic Information -->
        <div class="rg-form-card">
            <div class="rg-form-card-header">
                <h2 class="rg-form-card-title"><?php _e('Staff Information', 'rental-gates'); ?></h2>
                <p class="rg-form-card-subtitle"><?php _e('Enter the details of the person you want to invite', 'rental-gates'); ?></p>
            </div>
            <div class="rg-form-card-body">
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Full Name', 'rental-gates'); ?> <span class="required">*</span></label>
                        <input type="text" name="display_name" class="rg-form-input" required placeholder="<?php _e('John Smith', 'rental-gates'); ?>">
                    </div>
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Email Address', 'rental-gates'); ?> <span class="required">*</span></label>
                        <input type="email" name="email" class="rg-form-input" required placeholder="<?php _e('john@example.com', 'rental-gates'); ?>">
                        <span class="rg-form-hint"><?php _e('Invitation will be sent to this email', 'rental-gates'); ?></span>
                    </div>
                </div>
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Phone Number', 'rental-gates'); ?></label>
                        <input type="tel" name="phone" class="rg-form-input" placeholder="<?php _e('(555) 123-4567', 'rental-gates'); ?>">
                    </div>
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Job Title', 'rental-gates'); ?></label>
                        <input type="text" name="job_title" class="rg-form-input" placeholder="<?php _e('Property Manager, Leasing Agent, etc.', 'rental-gates'); ?>">
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Edit Mode - Show current info -->
        <div class="rg-form-card">
            <div class="rg-form-card-header">
                <h2 class="rg-form-card-title"><?php _e('Staff Information', 'rental-gates'); ?></h2>
            </div>
            <div class="rg-form-card-body">
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Name', 'rental-gates'); ?></label>
                        <input type="text" class="rg-form-input" value="<?php echo esc_attr($staff['display_name']); ?>" disabled>
                    </div>
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Email', 'rental-gates'); ?></label>
                        <input type="email" class="rg-form-input" value="<?php echo esc_attr($staff['user_email']); ?>" disabled>
                    </div>
                </div>
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Status', 'rental-gates'); ?></label>
                        <select name="status" class="rg-form-input">
                            <option value="active" <?php selected($staff['status'], 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
                            <option value="inactive" <?php selected($staff['status'], 'inactive'); ?>><?php _e('Inactive', 'rental-gates'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Permissions -->
        <div class="rg-form-card">
            <div class="rg-form-card-header">
                <h2 class="rg-form-card-title"><?php _e('Permissions', 'rental-gates'); ?></h2>
                <p class="rg-form-card-subtitle"><?php _e('Control what this staff member can access and do in each module', 'rental-gates'); ?></p>
            </div>
            <div class="rg-form-card-body">
                <!-- Quick Actions -->
                <div class="rg-quick-actions">
                    <button type="button" class="rg-quick-btn" onclick="setAllPermissions('none')"><?php _e('Remove All', 'rental-gates'); ?></button>
                    <button type="button" class="rg-quick-btn" onclick="setAllPermissions('view')"><?php _e('View Only (All)', 'rental-gates'); ?></button>
                    <button type="button" class="rg-quick-btn" onclick="setAllPermissions('edit')"><?php _e('View & Edit (All)', 'rental-gates'); ?></button>
                    <button type="button" class="rg-quick-btn" onclick="setAllPermissions('full')"><?php _e('Full Access (All)', 'rental-gates'); ?></button>
                </div>
                
                <!-- Permission Legend -->
                <div style="margin-bottom: 20px; padding: 16px; background: var(--gray-50); border-radius: 8px;">
                    <div style="font-size: 12px; font-weight: 600; color: var(--gray-500); margin-bottom: 8px;"><?php _e('Permission Levels:', 'rental-gates'); ?></div>
                    <div style="display: flex; flex-wrap: wrap; gap: 16px; font-size: 13px;">
                        <span><strong style="color: #9ca3af;">●</strong> <?php _e('No Access', 'rental-gates'); ?> - <?php _e('Cannot see this module', 'rental-gates'); ?></span>
                        <span><strong style="color: #3b82f6;">●</strong> <?php _e('View Only', 'rental-gates'); ?> - <?php _e('Can view but not modify', 'rental-gates'); ?></span>
                        <span><strong style="color: #10b981;">●</strong> <?php _e('View & Edit', 'rental-gates'); ?> - <?php _e('Can view and modify existing', 'rental-gates'); ?></span>
                        <span><strong style="color: #8b5cf6;">●</strong> <?php _e('Full Access', 'rental-gates'); ?> - <?php _e('Can create, edit, and delete', 'rental-gates'); ?></span>
                    </div>
                </div>
                
                <!-- Permissions Grid -->
                <div class="rg-permissions-grid">
                    <?php foreach ($modules as $key => $module): 
                        $current_perm = $current_permissions[$key] ?? 'none';
                    ?>
                    <div class="rg-permission-item">
                        <div class="rg-permission-info">
                            <div class="rg-permission-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><?php echo $module['icon']; ?></svg>
                            </div>
                            <div class="rg-permission-text">
                                <h4><?php echo esc_html($module['label']); ?></h4>
                                <p><?php echo esc_html($module['description']); ?></p>
                            </div>
                        </div>
                        <div class="rg-permission-select">
                            <?php foreach ($permission_levels as $level => $info): ?>
                            <label class="rg-perm-option <?php echo $current_perm === $level ? 'selected' : ''; ?>" data-module="<?php echo esc_attr($key); ?>" data-level="<?php echo esc_attr($level); ?>">
                                <input type="radio" name="permissions[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($level); ?>" <?php checked($current_perm, $level); ?>>
                                <?php echo esc_html($info['label']); ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="rg-form-actions">
                <a href="<?php echo home_url('/rental-gates/dashboard/staff'); ?>" class="rg-btn rg-btn-secondary"><?php _e('Cancel', 'rental-gates'); ?></a>
                <?php if ($is_edit): ?>
                <button type="button" class="rg-btn rg-btn-danger" onclick="confirmRemoveStaff()"><?php _e('Remove Staff', 'rental-gates'); ?></button>
                <?php endif; ?>
                <button type="submit" class="rg-btn rg-btn-primary">
                    <?php echo $is_edit ? __('Save Changes', 'rental-gates') : __('Send Invitation', 'rental-gates'); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<script>
// Permission option click handling
document.querySelectorAll('.rg-perm-option').forEach(function(option) {
    option.addEventListener('click', function() {
        var module = this.dataset.module;
        document.querySelectorAll('.rg-perm-option[data-module="' + module + '"]').forEach(function(opt) {
            opt.classList.remove('selected');
        });
        this.classList.add('selected');
        this.querySelector('input').checked = true;
    });
});

// Set all permissions
function setAllPermissions(level) {
    document.querySelectorAll('.rg-perm-option').forEach(function(option) {
        option.classList.remove('selected');
        if (option.dataset.level === level) {
            option.classList.add('selected');
            option.querySelector('input').checked = true;
        }
    });
}

// Form submission
document.getElementById('staff-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    var form = this;
    var formData = new FormData(form);
    formData.append('action', 'rental_gates_save_staff');
    
    var submitBtn = form.querySelector('button[type="submit"]');
    var originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> <?php echo $is_edit ? __('Saving...', 'rental-gates') : __('Sending Invitation...', 'rental-gates'); ?>';
    submitBtn.disabled = true;
    
    fetch(ajaxurl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            <?php if ($is_edit): ?>
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/staff'); ?>?updated=1';
            <?php else: ?>
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/staff'); ?>?invited=1';
            <?php endif; ?>
        } else {
            alert(data.data || '<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>');
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    })
    .catch(error => {
        alert('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
});

<?php if ($is_edit): ?>
function confirmRemoveStaff() {
    if (confirm('<?php _e('Are you sure you want to remove this staff member? They will lose access to all organization data.', 'rental-gates'); ?>')) {
        var formData = new FormData();
        formData.append('action', 'rental_gates_remove_staff');
        formData.append('staff_id', <?php echo $staff_id; ?>);
        formData.append('staff_nonce', document.querySelector('input[name="staff_nonce"]').value);
        
        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '<?php echo home_url('/rental-gates/dashboard/staff'); ?>?removed=1';
            } else {
                alert(data.data || '<?php _e('Failed to remove staff member.', 'rental-gates'); ?>');
            }
        });
    }
}
<?php endif; ?>
</script>
