<?php
/**
 * Invoice/Receipt View Template
 * 
 * Displays invoice/receipt with print and download options.
 * Accessed via /rental-gates/dashboard/invoice/{id} (owner)
 * or /rental-gates/tenant/invoice?id={id} (tenant)
 */
if (!defined('ABSPATH')) exit;

// Get invoice ID from URL
$invoice_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Detect if we're in tenant portal
$is_tenant_portal = strpos($_SERVER['REQUEST_URI'], '/rental-gates/tenant/') !== false;
$back_url = $is_tenant_portal ? home_url('/rental-gates/tenant/payments') : home_url('/rental-gates/dashboard/payments');

if (!$invoice_id) {
    wp_redirect($back_url);
    exit;
}

// Get invoice
$invoice = Rental_Gates_Invoice::get($invoice_id);

if (!$invoice) {
    echo '<div class="rg-error-message">' . __('Invoice not found', 'rental-gates') . '</div>';
    return;
}

// Security check - verify user has access
$current_user_id = get_current_user_id();
$has_access = false;

// Check if user is owner/PM of the organization
$user_org_id = Rental_Gates_Roles::get_organization_id();
if ($user_org_id && $user_org_id == $invoice['organization_id']) {
    $has_access = true;
}

// Check if user is the tenant
if (!$has_access && $invoice['tenant_id']) {
    $tenant = Rental_Gates_Tenant::get($invoice['tenant_id']);
    if ($tenant && $tenant['user_id'] == $current_user_id) {
        $has_access = true;
    }
}

// Also check by lease if tenant_id is null
if (!$has_access && $invoice['lease_id']) {
    $tables = Rental_Gates_Database::get_table_names();
    global $wpdb;
    $lease_tenant = $wpdb->get_var($wpdb->prepare(
        "SELECT t.user_id FROM {$tables['tenants']} t
         JOIN {$tables['lease_tenants']} lt ON t.id = lt.tenant_id
         WHERE lt.lease_id = %d AND t.user_id = %d AND lt.removed_at IS NULL
         LIMIT 1",
        $invoice['lease_id'], $current_user_id
    ));
    if ($lease_tenant) {
        $has_access = true;
    }
}

if (!$has_access) {
    echo '<div class="rg-error-message">' . __('Access denied', 'rental-gates') . '</div>';
    return;
}

$is_receipt = $invoice['type'] === 'receipt';
?>

<style>
    .invoice-view-container {
        max-width: 900px;
        margin: 0 auto;
    }
    
    .invoice-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding: 16px 20px;
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
    }
    
    .invoice-toolbar-title {
        font-size: 18px;
        font-weight: 600;
        color: var(--gray-900);
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .invoice-toolbar-title .badge {
        font-size: 12px;
        padding: 4px 10px;
        border-radius: 20px;
        font-weight: 500;
    }
    
    .invoice-toolbar-title .badge.receipt {
        background: #d1fae5;
        color: #059669;
    }
    
    .invoice-toolbar-title .badge.invoice {
        background: #dbeafe;
        color: #2563eb;
    }
    
    .invoice-toolbar-actions {
        display: flex;
        gap: 12px;
    }
    
    .invoice-toolbar-actions .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        text-decoration: none;
    }
    
    .invoice-toolbar-actions .btn-primary {
        background: var(--primary);
        color: #fff;
    }
    
    .invoice-toolbar-actions .btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
    }
    
    .invoice-toolbar-actions .btn-secondary {
        background: #fff;
        color: var(--gray-700);
        border: 1px solid var(--gray-300);
    }
    
    .invoice-toolbar-actions .btn-secondary:hover {
        background: var(--gray-50);
    }
    
    .invoice-frame {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
    }
    
    .invoice-frame iframe {
        width: 100%;
        height: 800px;
        border: none;
    }
    
    .invoice-download-options {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        margin-top: 8px;
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 8px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        min-width: 180px;
        z-index: 100;
    }
    
    .invoice-download-options.active {
        display: block;
    }
    
    .invoice-download-options a {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        color: var(--gray-700);
        text-decoration: none;
        font-size: 14px;
        transition: background 0.2s;
    }
    
    .invoice-download-options a:hover {
        background: var(--gray-50);
    }
    
    .invoice-download-options a svg {
        color: var(--gray-400);
    }
    
    .dropdown-wrapper {
        position: relative;
    }
    
    @media print {
        .invoice-toolbar,
        .rg-dashboard-nav,
        .rg-dashboard-sidebar,
        .no-print {
            display: none !important;
        }
        
        .invoice-frame {
            border: none;
            box-shadow: none;
        }
    }
</style>

<div class="invoice-view-container">
    <!-- Toolbar -->
    <div class="invoice-toolbar no-print">
        <div class="invoice-toolbar-title">
            <?php if ($is_receipt): ?>
                <svg width="24" height="24" fill="none" stroke="#059669" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M9 12l2 2 4-4"/>
                    <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            <?php else: ?>
                <svg width="24" height="24" fill="none" stroke="#2563eb" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                    <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>
                </svg>
            <?php endif; ?>
            <span><?php echo $is_receipt ? __('Receipt', 'rental-gates') : __('Invoice', 'rental-gates'); ?> #<?php echo esc_html($invoice['invoice_number']); ?></span>
            <span class="badge <?php echo $is_receipt ? 'receipt' : 'invoice'; ?>">
                <?php echo esc_html(ucfirst($invoice['status'])); ?>
            </span>
        </div>
        
        <div class="invoice-toolbar-actions">
            <a href="<?php echo esc_url($back_url); ?>" class="btn btn-secondary">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
                <?php _e('Back', 'rental-gates'); ?>
            </a>
            
            <button type="button" class="btn btn-secondary" onclick="window.print()">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M6 9V2h12v7"/>
                    <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                    <rect x="6" y="14" width="12" height="8"/>
                </svg>
                <?php _e('Print', 'rental-gates'); ?>
            </button>
            
            <div class="dropdown-wrapper">
                <button type="button" class="btn btn-primary" onclick="toggleDownloadMenu()">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <?php _e('Download', 'rental-gates'); ?>
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </button>
                
                <div class="invoice-download-options" id="download-menu">
                    <a href="<?php echo add_query_arg(array('action' => 'rental_gates_download_invoice', 'id' => $invoice_id, 'format' => 'pdf', 'nonce' => wp_create_nonce('download_invoice')), admin_url('admin-ajax.php')); ?>">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                            <path d="M14 2v6h6"/>
                        </svg>
                        <?php _e('Download PDF', 'rental-gates'); ?>
                    </a>
                    <a href="<?php echo add_query_arg(array('action' => 'rental_gates_download_invoice', 'id' => $invoice_id, 'format' => 'html', 'nonce' => wp_create_nonce('download_invoice')), admin_url('admin-ajax.php')); ?>">
                        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/>
                            <polyline points="13 2 13 9 20 9"/>
                        </svg>
                        <?php _e('Download HTML', 'rental-gates'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Invoice Content -->
    <div class="invoice-frame">
        <iframe id="invoice-frame" srcdoc="<?php echo esc_attr($invoice['html_content'] ?: Rental_Gates_Invoice::generate_html($invoice)); ?>"></iframe>
    </div>
</div>

<script>
function toggleDownloadMenu() {
    document.getElementById('download-menu').classList.toggle('active');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const dropdown = document.querySelector('.dropdown-wrapper');
    if (!dropdown.contains(e.target)) {
        document.getElementById('download-menu').classList.remove('active');
    }
});

// Print functionality - print just the iframe content
window.addEventListener('beforeprint', function() {
    const iframe = document.getElementById('invoice-frame');
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    
    // Create print stylesheet if not exists
    if (!iframeDoc.getElementById('print-style')) {
        const style = iframeDoc.createElement('style');
        style.id = 'print-style';
        style.textContent = '@page { margin: 20mm; } body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }';
        iframeDoc.head.appendChild(style);
    }
});
</script>
