<?php
/**
 * Marketing Section - QR Codes & Flyers
 * 
 * Features:
 * - QR Code management for buildings/units
 * - Scan analytics and tracking
 * - Printable flyer generation
 * - Bulk QR code generation
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    echo '<div class="rg-alert rg-alert-error">' . __('Organization not found', 'rental-gates') . '</div>';
    return;
}

// Get current tab
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'qr-codes';

// Get QR codes for this organization
$qr = new Rental_Gates_QR();
$qr_codes = Rental_Gates_QR::get_for_organization($org_id, array('per_page' => 100));

// Get buildings and units for generating QR codes
$buildings = Rental_Gates_Building::get_for_organization($org_id, array('per_page' => 100));
$units_data = array();

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Get units with building info
$units = $wpdb->get_results($wpdb->prepare(
    "SELECT u.*, b.name as building_name 
     FROM {$tables['units']} u
     JOIN {$tables['buildings']} b ON u.building_id = b.id
     WHERE u.organization_id = %d
     ORDER BY b.name ASC, u.name ASC",
    $org_id
), ARRAY_A);

// Calculate analytics summary
$total_scans = 0;
$total_qr_codes = count($qr_codes['items']);
foreach ($qr_codes['items'] as $qr_item) {
    $total_scans += intval($qr_item['scan_count'] ?? 0);
}

// Get recent scans (last 30 days)
$recent_scans = $wpdb->get_results($wpdb->prepare(
    "SELECT qs.*, qc.type, qc.entity_id, qc.code
     FROM {$tables['qr_scans']} qs
     JOIN {$tables['qr_codes']} qc ON qs.qr_code_id = qc.id
     WHERE qc.organization_id = %d
     AND qs.scanned_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     ORDER BY qs.scanned_at DESC
     LIMIT 50",
    $org_id
), ARRAY_A);

// Check which columns exist in flyers table
$flyer_columns = $wpdb->get_col("DESCRIBE {$tables['flyers']}", 0);
$has_type_column = in_array('type', $flyer_columns);
$has_entity_id = in_array('entity_id', $flyer_columns);

// Get flyers with backward-compatible query
if ($has_type_column && $has_entity_id) {
    $flyers = $wpdb->get_results($wpdb->prepare(
        "SELECT f.*, 
                CASE WHEN f.type = 'unit' THEN u.name ELSE b.name END as entity_name,
                b.name as building_name
         FROM {$tables['flyers']} f
         LEFT JOIN {$tables['units']} u ON f.type = 'unit' AND f.entity_id = u.id
         LEFT JOIN {$tables['buildings']} b ON (f.type = 'building' AND f.entity_id = b.id) 
                                            OR (f.type = 'unit' AND u.building_id = b.id)
         WHERE f.organization_id = %d
         ORDER BY f.created_at DESC",
        $org_id
    ), ARRAY_A);
} else {
    // Fallback for old schema (unit_id column)
    $flyers = $wpdb->get_results($wpdb->prepare(
        "SELECT f.*, u.name as entity_name, b.name as building_name
         FROM {$tables['flyers']} f
         LEFT JOIN {$tables['units']} u ON f.unit_id = u.id
         LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
         WHERE f.organization_id = %d
         ORDER BY f.created_at DESC",
        $org_id
    ), ARRAY_A);
}
?>

<style>
    .mkt-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
        gap: 16px;
    }
    .mkt-header h2 {
        margin: 0;
        font-size: 20px;
        font-weight: 600;
    }
    .mkt-header-actions {
        display: flex;
        gap: 12px;
    }
    
    /* Stats Cards */
    .mkt-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }
    .mkt-stat-card {
        background: #fff;
        border-radius: 12px;
        padding: 20px;
        border: 1px solid var(--gray-200);
    }
    .mkt-stat-value {
        font-size: 28px;
        font-weight: 700;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    .mkt-stat-label {
        font-size: 13px;
        color: var(--gray-500);
    }
    .mkt-stat-card.primary .mkt-stat-value { color: var(--primary); }
    .mkt-stat-card.success .mkt-stat-value { color: #10b981; }
    .mkt-stat-card.warning .mkt-stat-value { color: #f59e0b; }
    
    /* Tabs */
    .mkt-tabs {
        display: flex;
        gap: 4px;
        background: var(--gray-100);
        padding: 4px;
        border-radius: 10px;
        margin-bottom: 24px;
        width: fit-content;
    }
    .mkt-tab {
        padding: 10px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        color: var(--gray-600);
        text-decoration: none;
        transition: all 0.2s;
    }
    .mkt-tab:hover {
        color: var(--gray-900);
    }
    .mkt-tab.active {
        background: #fff;
        color: var(--gray-900);
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    /* QR Code Grid */
    .qr-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
    }
    .qr-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
        transition: all 0.2s;
    }
    .qr-card:hover {
        border-color: var(--primary);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .qr-card-image {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
        background: var(--gray-50);
        border-bottom: 1px solid var(--gray-200);
    }
    .qr-card-image img {
        width: 160px;
        height: 160px;
        border-radius: 8px;
    }
    .qr-card-body {
        padding: 16px;
    }
    .qr-card-title {
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .qr-card-type {
        font-size: 11px;
        padding: 2px 8px;
        border-radius: 4px;
        background: var(--gray-100);
        color: var(--gray-600);
        text-transform: uppercase;
    }
    .qr-card-type.building { background: #dbeafe; color: #1d4ed8; }
    .qr-card-type.unit { background: #d1fae5; color: #047857; }
    .qr-card-meta {
        font-size: 13px;
        color: var(--gray-500);
        margin-bottom: 12px;
    }
    .qr-card-stats {
        display: flex;
        gap: 16px;
        padding-top: 12px;
        border-top: 1px solid var(--gray-100);
        margin-bottom: 12px;
    }
    .qr-card-stat {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        color: var(--gray-600);
    }
    .qr-card-stat svg {
        width: 16px;
        height: 16px;
        color: var(--gray-400);
    }
    .qr-card-actions {
        display: flex;
        gap: 8px;
    }
    .qr-card-actions .rg-btn {
        flex: 1;
        justify-content: center;
        font-size: 13px;
        padding: 8px 12px;
    }
    .qr-card-actions .rg-btn-danger {
        flex: 0 0 auto;
        background: #fef2f2;
        color: #dc2626;
        border-color: #fecaca;
    }
    .qr-card-actions .rg-btn-danger:hover {
        background: #fee2e2;
        border-color: #fca5a5;
    }
    
    /* Generate Card */
    .qr-generate-card {
        background: linear-gradient(135deg, var(--primary) 0%, #4f46e5 100%);
        border: none;
        cursor: pointer;
        min-height: 300px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: #fff;
        transition: all 0.2s;
    }
    .qr-generate-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(79, 70, 229, 0.3);
    }
    .qr-generate-card svg {
        width: 48px;
        height: 48px;
        margin-bottom: 16px;
        opacity: 0.9;
    }
    .qr-generate-card h3 {
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 8px;
    }
    .qr-generate-card p {
        font-size: 14px;
        opacity: 0.8;
        margin: 0;
    }
    
    /* Flyer Grid */
    .flyer-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
        gap: 20px;
    }
    .flyer-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
        transition: all 0.2s;
    }
    .flyer-card:hover {
        border-color: var(--primary);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .flyer-card-preview {
        aspect-ratio: 8.5/11;
        background: var(--gray-100);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    .flyer-card-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .flyer-card-preview .placeholder {
        color: var(--gray-400);
    }
    .flyer-card-body {
        padding: 16px;
    }
    .flyer-card-title {
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    .flyer-card-meta {
        font-size: 13px;
        color: var(--gray-500);
        margin-bottom: 12px;
    }
    
    /* Recent Scans Table */
    .scans-table {
        width: 100%;
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }
    .scans-table th {
        text-align: left;
        padding: 12px 16px;
        background: var(--gray-50);
        font-size: 12px;
        font-weight: 600;
        color: var(--gray-600);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .scans-table td {
        padding: 12px 16px;
        border-top: 1px solid var(--gray-100);
        font-size: 14px;
    }
    .device-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        background: var(--gray-100);
        color: var(--gray-600);
    }
    .device-badge.mobile { background: #dbeafe; color: #1d4ed8; }
    .device-badge.tablet { background: #fef3c7; color: #92400e; }
    .device-badge.desktop { background: #d1fae5; color: #047857; }
    
    /* Modal */
    .mkt-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10000;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    .mkt-modal.active {
        display: flex;
    }
    .mkt-modal-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
    }
    .mkt-modal-content {
        position: relative;
        background: #fff;
        border-radius: 16px;
        max-width: 600px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    }
    .mkt-modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 24px;
        border-bottom: 1px solid var(--gray-200);
    }
    .mkt-modal-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
    }
    .mkt-modal-close {
        background: none;
        border: none;
        font-size: 24px;
        color: var(--gray-400);
        cursor: pointer;
        padding: 0;
        line-height: 1;
    }
    .mkt-modal-close:hover {
        color: var(--gray-600);
    }
    .mkt-modal-body {
        padding: 24px;
    }
    .mkt-modal-footer {
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        padding: 16px 24px;
        border-top: 1px solid var(--gray-200);
        background: var(--gray-50);
    }
    
    /* Form Styles */
    .mkt-form-group {
        margin-bottom: 20px;
    }
    .mkt-form-group label {
        display: block;
        font-size: 14px;
        font-weight: 500;
        color: var(--gray-700);
        margin-bottom: 6px;
    }
    .mkt-form-group select,
    .mkt-form-group input {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
    }
    .mkt-form-group select:focus,
    .mkt-form-group input:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    /* QR Preview in Modal */
    .qr-preview {
        text-align: center;
        padding: 24px;
        background: var(--gray-50);
        border-radius: 12px;
        margin-bottom: 20px;
    }
    .qr-preview img {
        width: 200px;
        height: 200px;
        border-radius: 8px;
        margin-bottom: 16px;
    }
    .qr-preview-url {
        font-size: 13px;
        color: var(--gray-500);
        word-break: break-all;
    }
    
    /* Empty State */
    .mkt-empty {
        text-align: center;
        padding: 60px 20px;
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
    }
    .mkt-empty svg {
        width: 64px;
        height: 64px;
        color: var(--gray-300);
        margin-bottom: 16px;
    }
    .mkt-empty h3 {
        font-size: 18px;
        color: var(--gray-900);
        margin: 0 0 8px;
    }
    .mkt-empty p {
        color: var(--gray-500);
        margin: 0 0 20px;
    }
    
    @media (max-width: 768px) {
        .mkt-header {
            flex-direction: column;
            align-items: flex-start;
        }
        .mkt-tabs {
            width: 100%;
            overflow-x: auto;
        }
        .qr-grid, .flyer-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Stats Overview -->
<div class="mkt-stats">
    <div class="mkt-stat-card primary">
        <div class="mkt-stat-value"><?php echo number_format($total_qr_codes); ?></div>
        <div class="mkt-stat-label"><?php _e('QR Codes', 'rental-gates'); ?></div>
    </div>
    <div class="mkt-stat-card success">
        <div class="mkt-stat-value"><?php echo number_format($total_scans); ?></div>
        <div class="mkt-stat-label"><?php _e('Total Scans', 'rental-gates'); ?></div>
    </div>
    <div class="mkt-stat-card">
        <div class="mkt-stat-value"><?php echo count($recent_scans); ?></div>
        <div class="mkt-stat-label"><?php _e('Scans (30 days)', 'rental-gates'); ?></div>
    </div>
    <div class="mkt-stat-card warning">
        <div class="mkt-stat-value"><?php echo count($flyers); ?></div>
        <div class="mkt-stat-label"><?php _e('Flyers', 'rental-gates'); ?></div>
    </div>
    <?php
    // Get lead count from QR sources
    $qr_leads = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$tables['leads']} 
         WHERE organization_id = %d 
         AND source IN ('qr_building', 'qr_unit')",
        $org_id
    ));
    ?>
    <div class="mkt-stat-card" style="border-left: 4px solid #3b82f6;">
        <div class="mkt-stat-value"><?php echo number_format($qr_leads); ?></div>
        <div class="mkt-stat-label"><?php _e('Leads from QR', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Tabs -->
<div class="mkt-tabs">
    <a href="?tab=qr-codes" class="mkt-tab <?php echo $current_tab === 'qr-codes' ? 'active' : ''; ?>">
        <?php _e('QR Codes', 'rental-gates'); ?>
    </a>
    <a href="?tab=flyers" class="mkt-tab <?php echo $current_tab === 'flyers' ? 'active' : ''; ?>">
        <?php _e('Flyers', 'rental-gates'); ?>
    </a>
    <a href="<?php echo home_url('/rental-gates/dashboard/marketing-analytics'); ?>" class="mkt-tab">
        <?php _e('Analytics', 'rental-gates'); ?>
    </a>
</div>

<?php if ($current_tab === 'qr-codes'): ?>
<!-- QR Codes Tab -->
<div class="mkt-header">
    <h2><?php _e('QR Codes', 'rental-gates'); ?></h2>
    <div class="mkt-header-actions">
        <button type="button" class="rg-btn rg-btn-secondary" onclick="openBulkGenerateModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM17 14v3m0 3v-3m0 0h3m-3 0h-3"/>
            </svg>
            <?php _e('Bulk Generate', 'rental-gates'); ?>
        </button>
        <button type="button" class="rg-btn rg-btn-primary" onclick="openGenerateModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M12 4v16m8-8H4"/>
            </svg>
            <?php _e('Generate QR Code', 'rental-gates'); ?>
        </button>
    </div>
</div>

<div class="qr-grid">
    <?php if (empty($qr_codes['items'])): ?>
    <!-- Generate Card as First Item -->
    <div class="qr-card qr-generate-card" onclick="openGenerateModal()">
        <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
            <path d="M12 4v16m8-8H4"/>
        </svg>
        <h3><?php _e('Create Your First QR Code', 'rental-gates'); ?></h3>
        <p><?php _e('Generate QR codes for your properties', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <?php foreach ($qr_codes['items'] as $qr_item): 
        // Get entity name
        $entity_name = '';
        if ($qr_item['type'] === 'building') {
            $building = Rental_Gates_Building::get($qr_item['entity_id']);
            $entity_name = $building['name'] ?? 'Unknown Building';
        } elseif ($qr_item['type'] === 'unit') {
            $unit = Rental_Gates_Unit::get($qr_item['entity_id']);
            $entity_name = $unit['name'] ?? 'Unknown Unit';
        } else {
            $entity_name = $qr_item['label'] ?? 'Custom QR';
        }
    ?>
    <div class="qr-card">
        <div class="qr-card-image">
            <img src="<?php echo esc_url($qr_item['qr_image']); ?>" alt="QR Code">
        </div>
        <div class="qr-card-body">
            <div class="qr-card-title">
                <?php echo esc_html($entity_name); ?>
                <span class="qr-card-type <?php echo esc_attr($qr_item['type']); ?>">
                    <?php echo esc_html(ucfirst($qr_item['type'])); ?>
                </span>
            </div>
            <div class="qr-card-meta">
                <?php echo esc_html($qr_item['code']); ?>
            </div>
            <div class="qr-card-stats">
                <div class="qr-card-stat">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                    <?php echo number_format($qr_item['scan_count'] ?? 0); ?> <?php _e('scans', 'rental-gates'); ?>
                </div>
                <?php if (!empty($qr_item['last_scanned_at'])): ?>
                <div class="qr-card-stat">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 6v6l4 2"/>
                    </svg>
                    <?php echo human_time_diff(strtotime($qr_item['last_scanned_at'])); ?> <?php _e('ago', 'rental-gates'); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="qr-card-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="downloadQR(<?php echo $qr_item['id']; ?>, '<?php echo esc_js($entity_name); ?>')">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                    </svg>
                    <?php _e('Download', 'rental-gates'); ?>
                </button>
                <button type="button" class="rg-btn rg-btn-secondary rg-btn-danger" onclick="deleteQR(<?php echo $qr_item['id']; ?>, '<?php echo esc_js($entity_name); ?>')" title="<?php esc_attr_e('Delete QR Code', 'rental-gates'); ?>">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php elseif ($current_tab === 'flyers'): ?>
<!-- Flyers Tab -->
<div class="mkt-header">
    <h2><?php _e('Property Flyers', 'rental-gates'); ?></h2>
    <div class="mkt-header-actions">
        <button type="button" class="rg-btn rg-btn-primary" onclick="openFlyerModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M12 4v16m8-8H4"/>
            </svg>
            <?php _e('Create Flyer', 'rental-gates'); ?>
        </button>
    </div>
</div>

<?php if (empty($flyers)): ?>
<div class="mkt-empty">
    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
        <path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
    </svg>
    <h3><?php _e('No Flyers Yet', 'rental-gates'); ?></h3>
    <p><?php _e('Create professional flyers to promote your properties.', 'rental-gates'); ?></p>
    <button type="button" class="rg-btn rg-btn-primary" onclick="openFlyerModal()">
        <?php _e('Create Your First Flyer', 'rental-gates'); ?>
    </button>
</div>
<?php else: ?>
<div class="flyer-grid">
    <?php foreach ($flyers as $flyer): ?>
    <div class="flyer-card">
        <div class="flyer-card-preview">
            <?php if (!empty($flyer['thumbnail_url'])): ?>
                <img src="<?php echo esc_url($flyer['thumbnail_url']); ?>" alt="Flyer Preview">
            <?php else: ?>
                <svg class="placeholder" width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-width="1.5" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
                </svg>
            <?php endif; ?>
        </div>
        <div class="flyer-card-body">
            <div class="flyer-card-title">
                <?php echo esc_html($flyer['title'] ?: $flyer['entity_name']); ?>
            </div>
            <div class="flyer-card-meta">
                <?php echo esc_html($flyer['building_name']); ?> • 
                <?php echo ucfirst($flyer['template']); ?> template
            </div>
            <div class="qr-card-actions">
                <?php if (!empty($flyer['file_url'])): ?>
                <a href="<?php echo esc_url($flyer['file_url']); ?>" target="_blank" class="rg-btn rg-btn-secondary">
                    <?php _e('Download', 'rental-gates'); ?>
                </a>
                <?php endif; ?>
                <button type="button" class="rg-btn rg-btn-secondary" onclick="regenerateFlyer(<?php echo $flyer['id']; ?>)">
                    <?php _e('Regenerate', 'rental-gates'); ?>
                </button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php else: ?>
<!-- Analytics Tab -->
<div class="mkt-header">
    <h2><?php _e('Scan Analytics', 'rental-gates'); ?></h2>
</div>

<?php if (empty($recent_scans)): ?>
<div class="mkt-empty">
    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
        <path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
    </svg>
    <h3><?php _e('No Scans Yet', 'rental-gates'); ?></h3>
    <p><?php _e('Once people start scanning your QR codes, you\'ll see the analytics here.', 'rental-gates'); ?></p>
</div>
<?php else: ?>
<div style="background: #fff; border-radius: 12px; border: 1px solid var(--gray-200); overflow: hidden;">
    <table class="scans-table">
        <thead>
            <tr>
                <th><?php _e('QR Code', 'rental-gates'); ?></th>
                <th><?php _e('Type', 'rental-gates'); ?></th>
                <th><?php _e('Device', 'rental-gates'); ?></th>
                <th><?php _e('Location', 'rental-gates'); ?></th>
                <th><?php _e('Scanned', 'rental-gates'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($recent_scans as $scan): ?>
            <tr>
                <td>
                    <code style="font-size: 12px; background: var(--gray-100); padding: 2px 6px; border-radius: 4px;">
                        <?php echo esc_html($scan['code']); ?>
                    </code>
                </td>
                <td>
                    <span class="qr-card-type <?php echo esc_attr($scan['type']); ?>">
                        <?php echo esc_html(ucfirst($scan['type'])); ?>
                    </span>
                </td>
                <td>
                    <span class="device-badge <?php echo esc_attr($scan['device_type'] ?? 'desktop'); ?>">
                        <?php 
                        $device = $scan['device_type'] ?? 'desktop';
                        $icons = array(
                            'mobile' => '📱',
                            'tablet' => '📲',
                            'desktop' => '💻'
                        );
                        echo ($icons[$device] ?? '💻') . ' ' . ucfirst($device);
                        ?>
                    </span>
                </td>
                <td><?php echo esc_html($scan['country'] ?: '—'); ?></td>
                <td><?php echo human_time_diff(strtotime($scan['scanned_at'])); ?> <?php _e('ago', 'rental-gates'); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Generate QR Modal -->
<div id="generate-qr-modal" class="mkt-modal">
    <div class="mkt-modal-overlay" onclick="closeGenerateModal()"></div>
    <div class="mkt-modal-content">
        <div class="mkt-modal-header">
            <h3><?php _e('Generate QR Code', 'rental-gates'); ?></h3>
            <button type="button" class="mkt-modal-close" onclick="closeGenerateModal()">&times;</button>
        </div>
        <div class="mkt-modal-body">
            <form id="generate-qr-form">
                <div class="mkt-form-group">
                    <label><?php _e('Type', 'rental-gates'); ?></label>
                    <select name="type" id="qr-type" onchange="updateEntityOptions()">
                        <option value="building"><?php _e('Building', 'rental-gates'); ?></option>
                        <option value="unit"><?php _e('Unit', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div class="mkt-form-group" id="building-select-group">
                    <label><?php _e('Building', 'rental-gates'); ?></label>
                    <select name="building_id" id="qr-building">
                        <option value=""><?php _e('Select a building', 'rental-gates'); ?></option>
                        <?php foreach ($buildings['items'] as $building): ?>
                        <option value="<?php echo $building['id']; ?>"><?php echo esc_html($building['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mkt-form-group" id="unit-select-group" style="display: none;">
                    <label><?php _e('Unit', 'rental-gates'); ?></label>
                    <select name="unit_id" id="qr-unit">
                        <option value=""><?php _e('Select a unit', 'rental-gates'); ?></option>
                        <?php foreach ($units as $unit): ?>
                        <option value="<?php echo $unit['id']; ?>" data-building="<?php echo $unit['building_id']; ?>">
                            <?php echo esc_html($unit['building_name'] . ' - ' . $unit['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mkt-form-group">
                    <label><?php _e('Size', 'rental-gates'); ?></label>
                    <select name="size" id="qr-size">
                        <option value="small"><?php _e('Small (150px)', 'rental-gates'); ?></option>
                        <option value="medium" selected><?php _e('Medium (300px)', 'rental-gates'); ?></option>
                        <option value="large"><?php _e('Large (500px)', 'rental-gates'); ?></option>
                        <option value="print"><?php _e('Print Quality (1000px)', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div id="qr-preview-container" style="display: none;">
                    <div class="qr-preview">
                        <img id="qr-preview-img" src="" alt="QR Code Preview">
                        <div class="qr-preview-url" id="qr-preview-url"></div>
                    </div>
                </div>
            </form>
        </div>
        <div class="mkt-modal-footer">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="closeGenerateModal()">
                <?php _e('Cancel', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-primary" onclick="generateQRCode()" id="generate-qr-btn">
                <?php _e('Generate QR Code', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Bulk Generate Modal -->
<div id="bulk-generate-modal" class="mkt-modal">
    <div class="mkt-modal-overlay" onclick="closeBulkModal()"></div>
    <div class="mkt-modal-content">
        <div class="mkt-modal-header">
            <h3><?php _e('Bulk Generate QR Codes', 'rental-gates'); ?></h3>
            <button type="button" class="mkt-modal-close" onclick="closeBulkModal()">&times;</button>
        </div>
        <div class="mkt-modal-body">
            <p style="color: var(--gray-600); margin-bottom: 20px;">
                <?php _e('Generate QR codes for all your properties at once.', 'rental-gates'); ?>
            </p>
            
            <div class="mkt-form-group">
                <label>
                    <input type="checkbox" id="bulk-buildings" checked>
                    <?php printf(__('All Buildings (%d)', 'rental-gates'), count($buildings['items'])); ?>
                </label>
            </div>
            
            <div class="mkt-form-group">
                <label>
                    <input type="checkbox" id="bulk-units" checked>
                    <?php printf(__('All Units (%d)', 'rental-gates'), count($units)); ?>
                </label>
            </div>
            
            <div class="mkt-form-group">
                <label><?php _e('Size', 'rental-gates'); ?></label>
                <select id="bulk-size">
                    <option value="medium" selected><?php _e('Medium (300px)', 'rental-gates'); ?></option>
                    <option value="large"><?php _e('Large (500px)', 'rental-gates'); ?></option>
                    <option value="print"><?php _e('Print Quality (1000px)', 'rental-gates'); ?></option>
                </select>
            </div>
            
            <div id="bulk-progress" style="display: none;">
                <div style="background: var(--gray-200); border-radius: 4px; height: 8px; overflow: hidden;">
                    <div id="bulk-progress-bar" style="background: var(--primary); height: 100%; width: 0%; transition: width 0.3s;"></div>
                </div>
                <p id="bulk-progress-text" style="text-align: center; margin-top: 8px; font-size: 13px; color: var(--gray-600);"></p>
            </div>
        </div>
        <div class="mkt-modal-footer">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="closeBulkModal()">
                <?php _e('Cancel', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-primary" onclick="bulkGenerateQR()" id="bulk-generate-btn">
                <?php _e('Generate All', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Create Flyer Modal -->
<div id="flyer-modal" class="mkt-modal">
    <div class="mkt-modal-overlay" onclick="closeFlyerModal()"></div>
    <div class="mkt-modal-content">
        <div class="mkt-modal-header">
            <h3><?php _e('Create Property Flyer', 'rental-gates'); ?></h3>
            <button type="button" class="mkt-modal-close" onclick="closeFlyerModal()">&times;</button>
        </div>
        <div class="mkt-modal-body">
            <form id="flyer-form">
                <div class="mkt-form-group">
                    <label><?php _e('Property', 'rental-gates'); ?></label>
                    <select name="unit_id" id="flyer-unit" required>
                        <option value=""><?php _e('Select a unit', 'rental-gates'); ?></option>
                        <?php foreach ($units as $unit): ?>
                        <option value="<?php echo $unit['id']; ?>">
                            <?php echo esc_html($unit['building_name'] . ' - ' . $unit['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mkt-form-group">
                    <label><?php _e('Template', 'rental-gates'); ?></label>
                    <select name="template" id="flyer-template">
                        <option value="modern"><?php _e('Modern', 'rental-gates'); ?></option>
                        <option value="classic"><?php _e('Classic', 'rental-gates'); ?></option>
                        <option value="minimal"><?php _e('Minimal', 'rental-gates'); ?></option>
                        <option value="bold"><?php _e('Bold', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div class="mkt-form-group">
                    <label>
                        <input type="checkbox" name="include_qr" id="flyer-include-qr" checked>
                        <?php _e('Include QR Code', 'rental-gates'); ?>
                    </label>
                </div>
                
                <div class="mkt-form-group">
                    <label><?php _e('Custom Title (optional)', 'rental-gates'); ?></label>
                    <input type="text" name="title" id="flyer-title" placeholder="<?php esc_attr_e('Leave blank for auto-generated', 'rental-gates'); ?>">
                </div>
            </form>
        </div>
        <div class="mkt-modal-footer">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="closeFlyerModal()">
                <?php _e('Cancel', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-primary" onclick="createFlyer()" id="create-flyer-btn">
                <?php _e('Create Flyer', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<!-- QR Analytics Modal -->
<div id="analytics-modal" class="mkt-modal">
    <div class="mkt-modal-overlay" onclick="closeAnalyticsModal()"></div>
    <div class="mkt-modal-content" style="max-width: 700px;">
        <div class="mkt-modal-header">
            <h3><?php _e('QR Code Analytics', 'rental-gates'); ?></h3>
            <button type="button" class="mkt-modal-close" onclick="closeAnalyticsModal()">&times;</button>
        </div>
        <div class="mkt-modal-body" id="analytics-content">
            <div style="text-align: center; padding: 40px;">
                <div class="spinner"></div>
                <p><?php _e('Loading analytics...', 'rental-gates'); ?></p>
            </div>
        </div>
    </div>
</div>

<script>
const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
const nonce = '<?php echo wp_create_nonce('rental_gates_nonce'); ?>';

// Modal Functions
function openGenerateModal() {
    document.getElementById('generate-qr-modal').classList.add('active');
    document.getElementById('qr-preview-container').style.display = 'none';
}

function closeGenerateModal() {
    document.getElementById('generate-qr-modal').classList.remove('active');
}

function openBulkGenerateModal() {
    document.getElementById('bulk-generate-modal').classList.add('active');
    document.getElementById('bulk-progress').style.display = 'none';
}

function closeBulkModal() {
    document.getElementById('bulk-generate-modal').classList.remove('active');
}

function openFlyerModal() {
    document.getElementById('flyer-modal').classList.add('active');
}

function closeFlyerModal() {
    document.getElementById('flyer-modal').classList.remove('active');
}

function closeAnalyticsModal() {
    document.getElementById('analytics-modal').classList.remove('active');
}

// Update entity options based on type
function updateEntityOptions() {
    const type = document.getElementById('qr-type').value;
    const buildingGroup = document.getElementById('building-select-group');
    const unitGroup = document.getElementById('unit-select-group');
    
    if (type === 'building') {
        buildingGroup.style.display = 'block';
        unitGroup.style.display = 'none';
    } else {
        buildingGroup.style.display = 'none';
        unitGroup.style.display = 'block';
    }
}

// Generate QR Code
async function generateQRCode() {
    const type = document.getElementById('qr-type').value;
    const size = document.getElementById('qr-size').value;
    let entityId;
    
    if (type === 'building') {
        entityId = document.getElementById('qr-building').value;
    } else {
        entityId = document.getElementById('qr-unit').value;
    }
    
    if (!entityId) {
        alert('<?php _e('Please select a property', 'rental-gates'); ?>');
        return;
    }
    
    const btn = document.getElementById('generate-qr-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner" style="margin-right: 8px;"></span> <?php _e('Generating...', 'rental-gates'); ?>';
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_generate_qr',
                nonce: nonce,
                type: type,
                entity_id: entityId,
                size: size
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show preview
            document.getElementById('qr-preview-container').style.display = 'block';
            document.getElementById('qr-preview-img').src = result.data.qr_image;
            document.getElementById('qr-preview-url').textContent = result.data.url;
            
            // Change button to download
            btn.innerHTML = '<?php _e('Download QR Code', 'rental-gates'); ?>';
            btn.onclick = function() {
                downloadQRImage(result.data.qr_image, type + '-' + entityId + '-qr.png');
            };
        } else {
            alert(result.data?.message || '<?php _e('Error generating QR code', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('QR generation error:', error);
        alert('<?php _e('Error generating QR code', 'rental-gates'); ?>');
    } finally {
        btn.disabled = false;
        if (btn.innerHTML.includes('Generating')) {
            btn.innerHTML = '<?php _e('Generate QR Code', 'rental-gates'); ?>';
        }
    }
}

// Download QR Image
function downloadQRImage(url, filename) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Download QR by ID
async function downloadQR(qrId, name) {
    // Fetch QR with print size
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_get_qr',
                nonce: nonce,
                qr_id: qrId,
                size: 'print'
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            downloadQRImage(result.data.qr_image, name.replace(/[^a-z0-9]/gi, '-') + '-qr.png');
        }
    } catch (error) {
        console.error('Download error:', error);
    }
}

// Delete QR Code
async function deleteQR(qrId, name) {
    if (!confirm(`<?php _e('Are you sure you want to delete the QR code for', 'rental-gates'); ?> "${name}"? <?php _e('This action cannot be undone.', 'rental-gates'); ?>`)) {
        return;
    }
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_delete_qr',
                nonce: nonce,
                qr_id: qrId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Reload page to show updated list
            location.reload();
        } else {
            alert(result.data?.message || '<?php _e('Error deleting QR code', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Delete error:', error);
        alert('<?php _e('Error deleting QR code', 'rental-gates'); ?>');
    }
}

// View QR Analytics
async function viewQRAnalytics(qrId) {
    document.getElementById('analytics-modal').classList.add('active');
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_qr_analytics',
                nonce: nonce,
                qr_id: qrId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            const data = result.data;
            document.getElementById('analytics-content').innerHTML = `
                <div class="mkt-stats" style="margin-bottom: 24px;">
                    <div class="mkt-stat-card">
                        <div class="mkt-stat-value">${data.total_scans}</div>
                        <div class="mkt-stat-label"><?php _e('Total Scans', 'rental-gates'); ?></div>
                    </div>
                    <div class="mkt-stat-card">
                        <div class="mkt-stat-value">${data.unique_visitors}</div>
                        <div class="mkt-stat-label"><?php _e('Unique Visitors', 'rental-gates'); ?></div>
                    </div>
                </div>
                <h4 style="margin-bottom: 12px;"><?php _e('Device Breakdown', 'rental-gates'); ?></h4>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    ${data.device_breakdown.map(d => `
                        <div class="device-badge ${d.device_type}">
                            ${d.device_type === 'mobile' ? '📱' : d.device_type === 'tablet' ? '📲' : '💻'}
                            ${d.device_type}: ${d.count}
                        </div>
                    `).join('')}
                </div>
            `;
        }
    } catch (error) {
        document.getElementById('analytics-content').innerHTML = '<p class="error"><?php _e('Error loading analytics', 'rental-gates'); ?></p>';
    }
}

// Bulk Generate
async function bulkGenerateQR() {
    const includeBuildings = document.getElementById('bulk-buildings').checked;
    const includeUnits = document.getElementById('bulk-units').checked;
    const size = document.getElementById('bulk-size').value;
    
    if (!includeBuildings && !includeUnits) {
        alert('<?php _e('Please select at least one option', 'rental-gates'); ?>');
        return;
    }
    
    const btn = document.getElementById('bulk-generate-btn');
    btn.disabled = true;
    document.getElementById('bulk-progress').style.display = 'block';
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_bulk_generate_qr',
                nonce: nonce,
                include_buildings: includeBuildings ? '1' : '0',
                include_units: includeUnits ? '1' : '0',
                size: size
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('bulk-progress-bar').style.width = '100%';
            document.getElementById('bulk-progress-text').textContent = 
                `<?php _e('Generated', 'rental-gates'); ?> ${result.data.count} <?php _e('QR codes', 'rental-gates'); ?>`;
            
            setTimeout(() => {
                closeBulkModal();
                location.reload();
            }, 1500);
        } else {
            alert(result.data?.message || '<?php _e('Error generating QR codes', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Bulk generation error:', error);
        alert('<?php _e('Error generating QR codes', 'rental-gates'); ?>');
    } finally {
        btn.disabled = false;
    }
}

// Preview Flyer
async function previewFlyer() {
    const unitId = document.getElementById('flyer-unit').value;
    const template = document.getElementById('flyer-template').value;
    const includeQr = document.getElementById('flyer-include-qr').checked;
    const title = document.getElementById('flyer-title').value;
    
    if (!unitId) {
        alert('<?php _e('Please select a property', 'rental-gates'); ?>');
        return;
    }
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_flyer_preview',
                nonce: nonce,
                type: 'unit',
                entity_id: unitId,
                template: template,
                include_qr: includeQr ? '1' : '0',
                title: title
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.preview_url) {
            const previewWindow = window.open('', '_blank', 'width=800,height=1000');
            previewWindow.document.write(result.data.html);
            previewWindow.document.close();
        } else {
            alert(result.data?.message || '<?php _e('Error generating preview', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Preview error:', error);
        alert('<?php _e('Error generating preview', 'rental-gates'); ?>');
    }
}

// Create Flyer
async function createFlyer() {
    const unitId = document.getElementById('flyer-unit').value;
    const template = document.getElementById('flyer-template').value;
    const includeQr = document.getElementById('flyer-include-qr').checked;
    const title = document.getElementById('flyer-title').value;
    
    if (!unitId) {
        alert('<?php _e('Please select a property', 'rental-gates'); ?>');
        return;
    }
    
    const btn = document.getElementById('create-flyer-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner" style="margin-right: 8px;"></span> <?php _e('Creating...', 'rental-gates'); ?>';
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_create_flyer',
                nonce: nonce,
                unit_id: unitId,
                template: template,
                include_qr: includeQr ? '1' : '0',
                title: title
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            closeFlyerModal();
            
            // Open flyer in new tab if URL provided
            if (result.data.file_url) {
                window.open(result.data.file_url, '_blank');
            }
            
            location.reload();
        } else {
            alert(result.data?.message || '<?php _e('Error creating flyer', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Flyer creation error:', error);
        alert('<?php _e('Error creating flyer', 'rental-gates'); ?>');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<?php _e('Create Flyer', 'rental-gates'); ?>';
    }
}

// Preview Flyer
async function previewFlyer() {
    const unitId = document.getElementById('flyer-unit').value;
    const template = document.getElementById('flyer-template').value;
    const includeQr = document.getElementById('flyer-include-qr').checked;
    const title = document.getElementById('flyer-title').value;
    
    if (!unitId) {
        alert('<?php _e('Please select a property', 'rental-gates'); ?>');
        return;
    }
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_flyer_preview',
                nonce: nonce,
                type: 'unit',
                entity_id: unitId,
                template: template,
                include_qr: includeQr ? '1' : '0',
                title: title
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.preview_url) {
            window.open(result.data.preview_url, '_blank', 'width=800,height=1000');
        } else {
            alert(result.data?.message || '<?php _e('Error generating preview', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Preview error:', error);
        alert('<?php _e('Error generating preview', 'rental-gates'); ?>');
    }
}

// Regenerate Flyer
async function regenerateFlyer(flyerId) {
    if (!confirm('<?php _e('Regenerate this flyer?', 'rental-gates'); ?>')) return;
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_regenerate_flyer',
                nonce: nonce,
                flyer_id: flyerId
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.file_url) {
            window.open(result.data.file_url, '_blank');
            location.reload();
        }
    } catch (error) {
        console.error('Regenerate error:', error);
    }
}

// Close modals on escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeGenerateModal();
        closeBulkModal();
        closeFlyerModal();
        closeAnalyticsModal();
    }
});
</script>
