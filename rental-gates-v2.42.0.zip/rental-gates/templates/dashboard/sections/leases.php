<?php
/**
 * Leases List Section - Improved
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Get leases - properly access items from paginated result
$args = array(
    'status' => $status_filter ?: null,
    'search' => $search ?: null,
    'orderby' => 'start_date',
    'order' => 'DESC',
    'per_page' => 100,
);

$result = Rental_Gates_Lease::get_for_organization($org_id, $args);
$leases = isset($result['items']) ? $result['items'] : array();
$total_leases = isset($result['total']) ? $result['total'] : 0;

$stats = Rental_Gates_Lease::get_stats($org_id);
if (!is_array($stats)) {
    $stats = array('active' => 0, 'draft' => 0, 'expiring_soon' => 0, 'ended' => 0, 'monthly_revenue' => 0);
}

// Status labels and colors
$status_config = array(
    'draft' => array('label' => __('Draft', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'pending' => array('label' => __('Pending', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'ending' => array('label' => __('Ending Soon', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'ended' => array('label' => __('Ended', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'terminated' => array('label' => __('Terminated', 'rental-gates'), 'color' => '#dc2626', 'bg' => '#fee2e2'),
    'renewed' => array('label' => __('Renewed', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
);
?>

<style>
    .rg-leases-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-leases-header h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 16px 20px; }
    .rg-stat-card.highlight { border-color: #10b981; background: linear-gradient(135deg, #ecfdf5 0%, #fff 100%); }
    .rg-stat-card.warning { border-color: #f59e0b; background: linear-gradient(135deg, #fffbeb 0%, #fff 100%); }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-value.success { color: #10b981; }
    .rg-stat-value.warning { color: #f59e0b; }
    .rg-stat-value.danger { color: #ef4444; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-filters-row { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .rg-search-box { flex: 1; min-width: 200px; position: relative; }
    .rg-search-box input { width: 100%; padding: 10px 14px 10px 40px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); }
    .rg-filter-select { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; min-width: 150px; }
    
    .rg-leases-table { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    .rg-table { width: 100%; border-collapse: collapse; }
    .rg-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-weight: 600; font-size: 12px; text-transform: uppercase; color: var(--gray-500); border-bottom: 1px solid var(--gray-200); }
    .rg-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); font-size: 14px; vertical-align: middle; }
    .rg-table tr:last-child td { border-bottom: none; }
    .rg-table tr:hover { background: var(--gray-50); }
    
    .rg-lease-unit { display: flex; flex-direction: column; }
    .rg-lease-unit strong { color: var(--gray-900); font-size: 14px; }
    .rg-lease-unit span { font-size: 13px; color: var(--gray-500); }
    
    .rg-tenant-list { display: flex; flex-wrap: wrap; gap: 4px; }
    .rg-tenant-chip { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; background: var(--gray-100); border-radius: 12px; font-size: 12px; }
    .rg-tenant-chip.primary { background: #dbeafe; color: #1d4ed8; }
    .rg-tenant-chip a { color: inherit; text-decoration: none; }
    .rg-tenant-chip a:hover { text-decoration: underline; }
    
    .rg-lease-term { display: flex; flex-direction: column; }
    .rg-lease-term-dates { font-size: 13px; color: var(--gray-700); }
    .rg-lease-term-type { font-size: 12px; color: var(--gray-500); }
    
    .rg-rent-amount { font-weight: 600; color: var(--gray-900); }
    .rg-rent-frequency { font-size: 12px; color: var(--gray-500); }
    
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-status-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
    
    .rg-expiring-badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; background: #fef3c7; color: #92400e; border-radius: 12px; font-size: 11px; font-weight: 500; margin-left: 6px; }
    .rg-overdue-badge { background: #fee2e2; color: #dc2626; }
    
    .rg-table-actions { display: flex; gap: 6px; flex-wrap: wrap; }
    .rg-table-action { padding: 6px 10px; border: 1px solid var(--gray-300); border-radius: 6px; background: #fff; color: var(--gray-600); font-size: 12px; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 4px; transition: all 0.15s; white-space: nowrap; }
    .rg-table-action:hover { background: var(--gray-50); border-color: var(--gray-400); }
    .rg-table-action.primary { border-color: var(--primary); color: var(--primary); }
    .rg-table-action.primary:hover { background: #eff6ff; }
    .rg-table-action.success { border-color: #10b981; color: #10b981; }
    .rg-table-action.success:hover { background: #d1fae5; }
    .rg-table-action.warning { border-color: #f59e0b; color: #f59e0b; }
    .rg-table-action.warning:hover { background: #fef3c7; }
    .rg-table-action.danger { border-color: #ef4444; color: #ef4444; }
    .rg-table-action.danger:hover { background: #fee2e2; }
    .rg-table-action svg { width: 14px; height: 14px; }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { font-size: 18px; color: var(--gray-700); margin-bottom: 8px; }
    .rg-empty-state p { color: var(--gray-500); margin-bottom: 20px; }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; text-decoration: none; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
    .rg-btn-secondary:hover { background: var(--gray-50); }
    .rg-btn svg { width: 16px; height: 16px; }
    
    /* Modal styles */
    .rg-modal-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .rg-modal-overlay.active { display: flex; }
    .rg-modal { background: #fff; border-radius: 16px; width: 100%; max-width: 480px; max-height: 90vh; overflow-y: auto; }
    .rg-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-title { font-size: 18px; font-weight: 600; color: var(--gray-900); }
    .rg-modal-close { background: none; border: none; padding: 8px; cursor: pointer; color: var(--gray-400); border-radius: 8px; }
    .rg-modal-close:hover { background: var(--gray-100); color: var(--gray-600); }
    .rg-modal-body { padding: 24px; }
    .rg-modal-footer { padding: 16px 24px; border-top: 1px solid var(--gray-200); display: flex; justify-content: flex-end; gap: 12px; }
    
    .rg-form-row { margin-bottom: 16px; }
    .rg-form-row label { display: block; font-size: 13px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .rg-form-row input, .rg-form-row select, .rg-form-row textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-form-row textarea { resize: vertical; min-height: 80px; }
    
    @media (max-width: 1200px) { .rg-stats-row { grid-template-columns: repeat(3, 1fr); } }
    @media (max-width: 768px) { 
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
        .rg-table-responsive { overflow-x: auto; } 
        .rg-table { min-width: 900px; }
    }
</style>

<!-- Header -->
<div class="rg-leases-header">
    <h1><?php _e('Leases', 'rental-gates'); ?></h1>
    <a href="<?php echo home_url('/rental-gates/dashboard/leases/add'); ?>" class="rg-btn rg-btn-primary">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        <?php _e('New Lease', 'rental-gates'); ?>
    </a>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card highlight">
        <div class="rg-stat-value success"><?php echo intval($stats['active'] ?? 0); ?></div>
        <div class="rg-stat-label"><?php _e('Active Leases', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo intval($stats['draft'] ?? 0); ?></div>
        <div class="rg-stat-label"><?php _e('Drafts', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card warning">
        <div class="rg-stat-value warning"><?php echo intval($stats['expiring_soon'] ?? 0); ?></div>
        <div class="rg-stat-label"><?php _e('Expiring in 30 Days', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo intval($stats['ended'] ?? 0); ?></div>
        <div class="rg-stat-label"><?php _e('Ended', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value success">$<?php echo number_format(floatval($stats['monthly_revenue'] ?? 0)); ?></div>
        <div class="rg-stat-label"><?php _e('Monthly Revenue', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" action="<?php echo esc_url(home_url('/rental-gates/dashboard/leases')); ?>" class="rg-filters-row">
    <div class="rg-search-box">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" name="search" placeholder="<?php _e('Search by unit, building, or tenant...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
    </div>
    
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
        <option value="draft" <?php selected($status_filter, 'draft'); ?>><?php _e('Draft', 'rental-gates'); ?></option>
        <option value="pending" <?php selected($status_filter, 'pending'); ?>><?php _e('Pending', 'rental-gates'); ?></option>
        <option value="ending" <?php selected($status_filter, 'ending'); ?>><?php _e('Ending Soon', 'rental-gates'); ?></option>
        <option value="ended" <?php selected($status_filter, 'ended'); ?>><?php _e('Ended', 'rental-gates'); ?></option>
        <option value="terminated" <?php selected($status_filter, 'terminated'); ?>><?php _e('Terminated', 'rental-gates'); ?></option>
        <option value="renewed" <?php selected($status_filter, 'renewed'); ?>><?php _e('Renewed', 'rental-gates'); ?></option>
    </select>
    
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
</form>

<!-- Leases Table -->
<div class="rg-leases-table">
    <?php if (empty($leases)): ?>
    <div class="rg-empty-state">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
        <h3><?php _e('No leases found', 'rental-gates'); ?></h3>
        <p><?php _e('Create your first lease to start tracking rental agreements.', 'rental-gates'); ?></p>
        <a href="<?php echo home_url('/rental-gates/dashboard/leases/add'); ?>" class="rg-btn rg-btn-primary"><?php _e('Create Lease', 'rental-gates'); ?></a>
    </div>
    <?php else: ?>
    <div class="rg-table-responsive">
        <table class="rg-table">
            <thead>
                <tr>
                    <th><?php _e('Unit', 'rental-gates'); ?></th>
                    <th><?php _e('Tenants', 'rental-gates'); ?></th>
                    <th><?php _e('Term', 'rental-gates'); ?></th>
                    <th><?php _e('Rent', 'rental-gates'); ?></th>
                    <th><?php _e('Status', 'rental-gates'); ?></th>
                    <th><?php _e('Actions', 'rental-gates'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($leases as $lease): 
                    $status = $status_config[$lease['status']] ?? $status_config['draft'];
                    $is_active = $lease['status'] === 'active';
                    $is_draft = $lease['status'] === 'draft';
                    $is_pending = $lease['status'] === 'pending';
                    $is_ended = in_array($lease['status'], array('ended', 'terminated'));
                    $can_renew = in_array($lease['status'], array('active', 'ending'));
                    $can_terminate = in_array($lease['status'], array('active', 'pending'));
                    $can_activate = in_array($lease['status'], array('draft', 'pending'));
                ?>
                <tr>
                    <td>
                        <div class="rg-lease-unit">
                            <strong><?php echo esc_html($lease['unit_name'] ?? __('No Unit', 'rental-gates')); ?></strong>
                            <span><?php echo esc_html($lease['building_name'] ?? ''); ?></span>
                        </div>
                    </td>
                    <td>
                        <div class="rg-tenant-list">
                            <?php if (empty($lease['tenants'])): ?>
                                <span style="color: var(--gray-400); font-style: italic;"><?php _e('No tenants', 'rental-gates'); ?></span>
                            <?php else: ?>
                                <?php foreach ($lease['tenants'] as $index => $tenant): 
                                    if ($index >= 3) { 
                                        echo '<span class="rg-tenant-chip">+' . (count($lease['tenants']) - 3) . ' more</span>';
                                        break; 
                                    }
                                ?>
                                <span class="rg-tenant-chip <?php echo ($tenant['role'] ?? '') === 'primary' ? 'primary' : ''; ?>">
                                    <a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $tenant['tenant_id']); ?>">
                                        <?php echo esc_html($tenant['full_name'] ?? 'Unknown'); ?>
                                    </a>
                                </span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div class="rg-lease-term">
                            <span class="rg-lease-term-dates">
                                <?php 
                                if (!empty($lease['start_date'])) {
                                    echo date('M j, Y', strtotime($lease['start_date']));
                                    if (!empty($lease['end_date'])) {
                                        echo ' - ' . date('M j, Y', strtotime($lease['end_date']));
                                    }
                                } else {
                                    echo '—';
                                }
                                ?>
                            </span>
                            <span class="rg-lease-term-type">
                                <?php 
                                if (!empty($lease['is_month_to_month'])) {
                                    _e('Month-to-month', 'rental-gates');
                                } elseif (!empty($lease['end_date']) && !empty($lease['start_date'])) {
                                    $months = round((strtotime($lease['end_date']) - strtotime($lease['start_date'])) / (30 * 24 * 60 * 60));
                                    echo sprintf(_n('%d month', '%d months', $months, 'rental-gates'), $months);
                                }
                                ?>
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="rg-rent-amount">$<?php echo number_format(floatval($lease['rent_amount'] ?? 0)); ?></div>
                        <span class="rg-rent-frequency">/<?php 
                            $freq = $lease['billing_frequency'] ?? 'monthly';
                            echo $freq === 'monthly' ? 'mo' : ($freq === 'weekly' ? 'wk' : 'bi-wk'); 
                        ?></span>
                    </td>
                    <td>
                        <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                            <?php echo $status['label']; ?>
                        </span>
                        <?php if (!empty($lease['is_expiring_soon']) && !empty($lease['days_until_end'])): ?>
                        <span class="rg-expiring-badge">
                            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                            <?php echo sprintf(__('%d days left', 'rental-gates'), $lease['days_until_end']); ?>
                        </span>
                        <?php elseif ($is_ended && !empty($lease['end_date']) && strtotime($lease['end_date']) < time()): ?>
                        <span class="rg-expiring-badge rg-overdue-badge">
                            <?php _e('Expired', 'rental-gates'); ?>
                        </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="rg-table-actions">
                            <!-- View - Always available -->
                            <a href="<?php echo home_url('/rental-gates/dashboard/leases/' . $lease['id']); ?>" class="rg-table-action" title="<?php _e('View Details', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                <?php _e('View', 'rental-gates'); ?>
                            </a>
                            
                            <!-- Edit - Draft/Pending only -->
                            <?php if ($is_draft || $is_pending): ?>
                            <a href="<?php echo home_url('/rental-gates/dashboard/leases/' . $lease['id'] . '/edit'); ?>" class="rg-table-action" title="<?php _e('Edit Lease', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                <?php _e('Edit', 'rental-gates'); ?>
                            </a>
                            <?php endif; ?>
                            
                            <!-- Activate - Draft/Pending -->
                            <?php if ($can_activate): ?>
                            <button onclick="activateLease(<?php echo $lease['id']; ?>)" class="rg-table-action success" title="<?php _e('Activate Lease', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <?php _e('Activate', 'rental-gates'); ?>
                            </button>
                            <?php endif; ?>
                            
                            <!-- Renew - Active/Ending -->
                            <?php if ($can_renew): ?>
                            <button onclick="showRenewModal(<?php echo $lease['id']; ?>, '<?php echo esc_js($lease['end_date'] ?? ''); ?>', <?php echo floatval($lease['rent_amount']); ?>)" class="rg-table-action primary" title="<?php _e('Renew Lease', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                                <?php _e('Renew', 'rental-gates'); ?>
                            </button>
                            <?php endif; ?>
                            
                            <!-- Terminate - Active/Pending -->
                            <?php if ($can_terminate): ?>
                            <button onclick="showTerminateModal(<?php echo $lease['id']; ?>)" class="rg-table-action danger" title="<?php _e('Terminate Lease', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                            </button>
                            <?php endif; ?>
                            
                            <!-- Delete - Draft only -->
                            <?php if ($is_draft): ?>
                            <button onclick="deleteLease(<?php echo $lease['id']; ?>)" class="rg-table-action danger" title="<?php _e('Delete Lease', 'rental-gates'); ?>">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Renew Modal -->
<div class="rg-modal-overlay" id="renewModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3 class="rg-modal-title"><?php _e('Renew Lease', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeRenewModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <form id="renewForm" onsubmit="submitRenew(event)">
            <input type="hidden" name="lease_id" id="renewLeaseId">
            <div class="rg-modal-body">
                <div class="rg-form-row">
                    <label><?php _e('New End Date', 'rental-gates'); ?> *</label>
                    <input type="date" name="new_end_date" id="renewEndDate" required>
                </div>
                <div class="rg-form-row">
                    <label><?php _e('New Monthly Rent (optional)', 'rental-gates'); ?></label>
                    <input type="number" name="new_rent_amount" id="renewRentAmount" step="0.01" min="0" placeholder="Leave blank to keep current">
                </div>
                <div class="rg-form-row">
                    <label><?php _e('Notes (optional)', 'rental-gates'); ?></label>
                    <textarea name="notes" rows="3" placeholder="<?php _e('Any notes about this renewal...', 'rental-gates'); ?>"></textarea>
                </div>
            </div>
            <div class="rg-modal-footer">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeRenewModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Renew Lease', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Terminate Modal -->
<div class="rg-modal-overlay" id="terminateModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3 class="rg-modal-title"><?php _e('Terminate Lease', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeTerminateModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <form id="terminateForm" onsubmit="submitTerminate(event)">
            <input type="hidden" name="lease_id" id="terminateLeaseId">
            <div class="rg-modal-body">
                <p style="color: var(--gray-600); margin-bottom: 16px;">
                    <?php _e('Terminating a lease will mark it as terminated and free up the unit. This action cannot be undone.', 'rental-gates'); ?>
                </p>
                <div class="rg-form-row">
                    <label><?php _e('Termination Date', 'rental-gates'); ?> *</label>
                    <input type="date" name="termination_date" id="terminationDate" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="rg-form-row">
                    <label><?php _e('Reason for Termination', 'rental-gates'); ?> *</label>
                    <select name="termination_reason" required>
                        <option value=""><?php _e('Select reason...', 'rental-gates'); ?></option>
                        <option value="tenant_request"><?php _e('Tenant Request', 'rental-gates'); ?></option>
                        <option value="non_payment"><?php _e('Non-Payment', 'rental-gates'); ?></option>
                        <option value="lease_violation"><?php _e('Lease Violation', 'rental-gates'); ?></option>
                        <option value="mutual_agreement"><?php _e('Mutual Agreement', 'rental-gates'); ?></option>
                        <option value="property_sale"><?php _e('Property Sale', 'rental-gates'); ?></option>
                        <option value="other"><?php _e('Other', 'rental-gates'); ?></option>
                    </select>
                </div>
                <div class="rg-form-row">
                    <label><?php _e('Notes', 'rental-gates'); ?></label>
                    <textarea name="notes" rows="3" placeholder="<?php _e('Additional details about the termination...', 'rental-gates'); ?>"></textarea>
                </div>
            </div>
            <div class="rg-modal-footer">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeTerminateModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary" style="background: #dc2626;"><?php _e('Terminate Lease', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
const nonce = '<?php echo wp_create_nonce('rental_gates_nonce'); ?>';

// Activate Lease
function activateLease(leaseId) {
    RentalGates.confirmDelete({
        title: '<?php echo esc_js(__('Activate Lease', 'rental-gates')); ?>',
        message: '<?php echo esc_js(__('Activate this lease? This will mark the unit as occupied and tenant(s) as active.', 'rental-gates')); ?>',
        ajaxAction: 'rental_gates_activate_lease',
        ajaxData: { lease_id: leaseId },
        onConfirm: function() {
            location.reload();
        }
    });
}

// Renew Modal
function showRenewModal(leaseId, currentEndDate, currentRent) {
    document.getElementById('renewLeaseId').value = leaseId;
    document.getElementById('renewRentAmount').placeholder = '$' + currentRent.toFixed(2);
    
    // Set minimum date to current end date + 1 day
    if (currentEndDate) {
        const minDate = new Date(currentEndDate);
        minDate.setDate(minDate.getDate() + 1);
        document.getElementById('renewEndDate').min = minDate.toISOString().split('T')[0];
        
        // Default to 1 year from current end
        const defaultDate = new Date(currentEndDate);
        defaultDate.setFullYear(defaultDate.getFullYear() + 1);
        document.getElementById('renewEndDate').value = defaultDate.toISOString().split('T')[0];
    }
    
    document.getElementById('renewModal').classList.add('active');
}

function closeRenewModal() {
    document.getElementById('renewModal').classList.remove('active');
    document.getElementById('renewForm').reset();
}

function submitRenew(e) {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = '<?php echo esc_js(__('Renewing...', 'rental-gates')); ?>';
    
    const formData = new FormData(form);
    formData.append('action', 'rental_gates_renew_lease');
    formData.append('nonce', nonce);
    
    fetch(ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                RentalGates.showToast('<?php echo esc_js(__('Lease renewed successfully', 'rental-gates')); ?>', 'success');
                location.reload();
            } else {
                RentalGates.showToast(data.data?.message || '<?php echo esc_js(__('Error renewing lease', 'rental-gates')); ?>', 'error');
                btn.disabled = false;
                btn.textContent = '<?php echo esc_js(__('Renew Lease', 'rental-gates')); ?>';
            }
        });
}

// Terminate Modal
function showTerminateModal(leaseId) {
    document.getElementById('terminateLeaseId').value = leaseId;
    document.getElementById('terminateModal').classList.add('active');
}

function closeTerminateModal() {
    document.getElementById('terminateModal').classList.remove('active');
    document.getElementById('terminateForm').reset();
}

function submitTerminate(e) {
    e.preventDefault();
    
    RentalGates.confirmDelete({
        title: '<?php echo esc_js(__('Terminate Lease', 'rental-gates')); ?>',
        message: '<?php echo esc_js(__('Are you sure you want to terminate this lease? This action cannot be undone.', 'rental-gates')); ?>',
        onConfirm: function() {
            const form = document.getElementById('terminateForm');
            const btn = form.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.textContent = '<?php echo esc_js(__('Terminating...', 'rental-gates')); ?>';
            
            const formData = new FormData(form);
            formData.append('action', 'rental_gates_terminate_lease');
            formData.append('nonce', nonce);
            
            fetch(ajaxUrl, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        RentalGates.showToast('<?php echo esc_js(__('Lease terminated', 'rental-gates')); ?>', 'success');
                        location.reload();
                    } else {
                        RentalGates.showToast(data.data?.message || '<?php echo esc_js(__('Error terminating lease', 'rental-gates')); ?>', 'error');
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('Terminate Lease', 'rental-gates')); ?>';
                    }
                });
        }
    });
}

// Delete Lease
function deleteLease(leaseId) {
    RentalGates.confirmDelete({
        title: '<?php echo esc_js(__('Delete Lease', 'rental-gates')); ?>',
        message: '<?php echo esc_js(__('Delete this draft lease? This action cannot be undone.', 'rental-gates')); ?>',
        ajaxAction: 'rental_gates_delete_lease',
        ajaxData: { lease_id: leaseId },
        onConfirm: function() {
            location.reload();
        }
    });
}

// Close modals on outside click
document.getElementById('renewModal').addEventListener('click', function(e) {
    if (e.target === this) closeRenewModal();
});
document.getElementById('terminateModal').addEventListener('click', function(e) {
    if (e.target === this) closeTerminateModal();
});
</script>
