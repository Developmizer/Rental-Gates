<?php
/**
 * Dashboard Section: Buildings & Units List
 * 
 * Displays all buildings with unit counts and quick actions.
 * Units are accessed by clicking into a building (Rule 2: Buildings Own Units).
 */
if (!defined('ABSPATH')) exit;

// Get organization ID
$org_id = null;
$buildings = array();
$stats = array('total' => 0, 'active' => 0, 'inactive' => 0);

try {
    if (class_exists('Rental_Gates_Roles')) {
        $org_id = Rental_Gates_Roles::get_organization_id();
    }
    
    if ($org_id && class_exists('Rental_Gates_Building')) {
        // Get all buildings for this organization
        $buildings = Rental_Gates_Building::get_all($org_id);
        
        // Calculate stats
        foreach ($buildings as $building) {
            $stats['total']++;
            if ($building['status'] === 'active') {
                $stats['active']++;
            } else {
                $stats['inactive']++;
            }
        }
    }
} catch (Exception $e) {
    error_log('Rental Gates: Error loading buildings: ' . $e->getMessage());
}

// Search/filter parameters
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
?>

<style>
    .rg-page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        flex-wrap: wrap;
        gap: 16px;
    }
    
    .rg-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0;
    }
    
    .rg-page-subtitle {
        font-size: 14px;
        color: var(--gray-500);
        margin-top: 4px;
    }
    
    .rg-filters-bar {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 24px;
        flex-wrap: wrap;
    }
    
    .rg-search-input {
        flex: 1;
        min-width: 200px;
        max-width: 400px;
        padding: 10px 16px 10px 40px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
        background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239ca3af'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'/%3E%3C/svg%3E") 12px center no-repeat;
        background-size: 20px;
    }
    
    .rg-search-input:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }
    
    .rg-filter-tabs {
        display: flex;
        background: var(--gray-100);
        border-radius: 8px;
        padding: 4px;
    }
    
    .rg-filter-tab {
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        color: var(--gray-600);
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        background: transparent;
    }
    
    .rg-filter-tab:hover {
        color: var(--gray-900);
    }
    
    .rg-filter-tab.active {
        background: #fff;
        color: var(--primary);
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .rg-buildings-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 20px;
    }
    
    .rg-building-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
        transition: all 0.2s;
        cursor: pointer;
    }
    
    .rg-building-card:hover {
        border-color: var(--primary);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        transform: translateY(-2px);
    }
    
    .rg-building-image {
        height: 160px;
        background: linear-gradient(135deg, var(--gray-200), var(--gray-300));
        position: relative;
        overflow: hidden;
    }
    
    .rg-building-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .rg-building-image-placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        color: var(--gray-400);
    }
    
    .rg-building-status {
        position: absolute;
        top: 12px;
        right: 12px;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .rg-building-status.active {
        background: var(--success);
        color: #fff;
    }
    
    .rg-building-status.inactive {
        background: var(--gray-400);
        color: #fff;
    }
    
    .rg-building-content {
        padding: 16px;
    }
    
    .rg-building-name {
        font-size: 18px;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .rg-building-address {
        font-size: 14px;
        color: var(--gray-500);
        margin-bottom: 16px;
        display: flex;
        align-items: flex-start;
        gap: 6px;
    }
    
    .rg-building-address svg {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
        margin-top: 2px;
    }
    
    .rg-unit-counts {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .rg-unit-count {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background: var(--gray-50);
        border-radius: 6px;
        font-size: 13px;
    }
    
    .rg-unit-count-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }
    
    .rg-unit-count-dot.total { background: var(--gray-400); }
    .rg-unit-count-dot.available { background: var(--success); }
    .rg-unit-count-dot.occupied { background: var(--primary); }
    .rg-unit-count-dot.coming-soon { background: var(--warning); }
    
    .rg-building-actions {
        display: flex;
        gap: 8px;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid var(--gray-100);
    }
    
    .rg-building-action {
        flex: 1;
        padding: 8px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s;
        border: 1px solid var(--gray-200);
        background: #fff;
        color: var(--gray-700);
        text-decoration: none;
    }
    
    .rg-building-action:hover {
        border-color: var(--primary);
        color: var(--primary);
    }
    
    .rg-building-action.primary {
        background: var(--primary);
        border-color: var(--primary);
        color: #fff;
    }
    
    .rg-building-action.primary:hover {
        background: var(--primary-dark);
    }
    
    /* Empty State */
    .rg-empty-state {
        text-align: center;
        padding: 60px 20px;
        background: #fff;
        border-radius: 12px;
        border: 2px dashed var(--gray-300);
    }
    
    .rg-empty-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        background: var(--gray-100);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-400);
    }
    
    .rg-empty-title {
        font-size: 20px;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 8px;
    }
    
    .rg-empty-text {
        font-size: 14px;
        color: var(--gray-500);
        margin-bottom: 24px;
        max-width: 400px;
        margin-left: auto;
        margin-right: auto;
    }
    
    @media (max-width: 768px) {
        .rg-buildings-grid {
            grid-template-columns: 1fr;
        }
        
        .rg-page-header {
            flex-direction: column;
            align-items: stretch;
            gap: 16px;
        }
        
        .rg-page-header .rg-btn {
            width: 100%;
            justify-content: center;
        }
        
        .rg-filters-bar {
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
        }
        
        .rg-search-input {
            max-width: none;
            width: 100%;
        }
        
        .rg-filter-tabs {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            padding-bottom: 4px;
            gap: 8px;
            flex-wrap: nowrap;
        }
        
        .rg-filter-tabs::-webkit-scrollbar {
            display: none;
        }
        
        .rg-filter-tab {
            white-space: nowrap;
            flex-shrink: 0;
            min-height: 44px;
            padding: 10px 16px;
        }
        
        .rg-building-card {
            padding: 16px;
        }
    }
    
    @media (max-width: 375px) {
        .rg-page-title {
            font-size: 20px;
        }
        
        .rg-building-card {
            padding: 12px;
        }
    }
</style>

<!-- Page Header -->
<div class="rg-page-header">
    <div>
        <h1 class="rg-page-title"><?php _e('Buildings & Units', 'rental-gates'); ?></h1>
        <p class="rg-page-subtitle">
            <?php printf(
                _n('%d building', '%d buildings', $stats['total'], 'rental-gates'),
                $stats['total']
            ); ?>
            <?php if ($stats['active'] > 0): ?>
                · <?php printf(__('%d active', 'rental-gates'), $stats['active']); ?>
            <?php endif; ?>
        </p>
    </div>
    <a href="<?php echo home_url('/rental-gates/dashboard/buildings/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        <?php _e('Add Building', 'rental-gates'); ?>
    </a>
</div>

<?php if (!empty($buildings) || !empty($search)): ?>
<!-- Filters Bar -->
<div class="rg-filters-bar">
    <form method="get" action="" style="flex: 1; display: flex; gap: 12px; flex-wrap: wrap;">
        <input type="hidden" name="page" value="buildings">
        <input 
            type="text" 
            name="search" 
            class="rg-search-input" 
            placeholder="<?php _e('Search buildings...', 'rental-gates'); ?>"
            value="<?php echo esc_attr($search); ?>"
        >
        
        <div class="rg-filter-tabs">
            <button type="submit" name="status" value="all" class="rg-filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
                <?php _e('All', 'rental-gates'); ?>
            </button>
            <button type="submit" name="status" value="active" class="rg-filter-tab <?php echo $status_filter === 'active' ? 'active' : ''; ?>">
                <?php _e('Active', 'rental-gates'); ?>
            </button>
            <button type="submit" name="status" value="inactive" class="rg-filter-tab <?php echo $status_filter === 'inactive' ? 'active' : ''; ?>">
                <?php _e('Inactive', 'rental-gates'); ?>
            </button>
        </div>
    </form>
</div>
<?php endif; ?>

<?php if (empty($buildings)): ?>
<!-- Empty State -->
<div class="rg-empty-state">
    <div class="rg-empty-icon">
        <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
        </svg>
    </div>
    <h2 class="rg-empty-title"><?php _e('No buildings yet', 'rental-gates'); ?></h2>
    <p class="rg-empty-text">
        <?php _e('Add your first building by placing a pin on the map. Units can then be added within each building.', 'rental-gates'); ?>
    </p>
    <a href="<?php echo home_url('/rental-gates/dashboard/buildings/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        <?php _e('Add Your First Building', 'rental-gates'); ?>
    </a>
</div>

<?php else: ?>
<!-- Buildings Grid -->
<div class="rg-buildings-grid" id="buildings-grid">
    <?php foreach ($buildings as $building): 
        // Apply filters
        if ($status_filter !== 'all' && $building['status'] !== $status_filter) continue;
        if ($search && stripos($building['name'], $search) === false && stripos($building['derived_address'], $search) === false) continue;
        
        // Get unit counts for this building
        $unit_counts = array(
            'total' => 0,
            'available' => 0,
            'occupied' => 0,
            'coming_soon' => 0
        );
        
        if (class_exists('Rental_Gates_Unit')) {
            $units = Rental_Gates_Unit::get_by_building($building['id']);
            foreach ($units as $unit) {
                $unit_counts['total']++;
                if (isset($unit_counts[$unit['availability']])) {
                    $unit_counts[$unit['availability']]++;
                }
            }
        }
        
        // Get first gallery image - already decoded by format_building()
        // Handle both string URLs and objects {id, url, thumbnail}
        $gallery = !empty($building['gallery']) && is_array($building['gallery']) ? $building['gallery'] : array();
        $first_image = null;
        if (!empty($gallery[0])) {
            $img = $gallery[0];
            $first_image = is_array($img) ? ($img['url'] ?? $img['thumbnail'] ?? null) : $img;
        }
    ?>
    <div class="rg-building-card" onclick="window.location.href='<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id']); ?>'">
        <div class="rg-building-image">
            <?php if ($first_image): ?>
                <img src="<?php echo esc_url($first_image); ?>" alt="<?php echo esc_attr($building['name']); ?>">
            <?php else: ?>
                <div class="rg-building-image-placeholder">
                    <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
            <?php endif; ?>
            <span class="rg-building-status <?php echo esc_attr($building['status']); ?>">
                <?php echo esc_html($building['status']); ?>
            </span>
        </div>
        
        <div class="rg-building-content">
            <h3 class="rg-building-name"><?php echo esc_html($building['name']); ?></h3>
            <div class="rg-building-address">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <span><?php echo esc_html($building['derived_address'] ?: __('No address', 'rental-gates')); ?></span>
            </div>
            
            <div class="rg-unit-counts">
                <div class="rg-unit-count">
                    <span class="rg-unit-count-dot total"></span>
                    <?php printf(__('%d units', 'rental-gates'), $unit_counts['total']); ?>
                </div>
                <?php if ($unit_counts['available'] > 0): ?>
                <div class="rg-unit-count">
                    <span class="rg-unit-count-dot available"></span>
                    <?php printf(__('%d available', 'rental-gates'), $unit_counts['available']); ?>
                </div>
                <?php endif; ?>
                <?php if ($unit_counts['occupied'] > 0): ?>
                <div class="rg-unit-count">
                    <span class="rg-unit-count-dot occupied"></span>
                    <?php printf(__('%d occupied', 'rental-gates'), $unit_counts['occupied']); ?>
                </div>
                <?php endif; ?>
                <?php if ($unit_counts['coming_soon'] > 0): ?>
                <div class="rg-unit-count">
                    <span class="rg-unit-count-dot coming-soon"></span>
                    <?php printf(__('%d coming soon', 'rental-gates'), $unit_counts['coming_soon']); ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="rg-building-actions" onclick="event.stopPropagation();">
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id']); ?>" class="rg-building-action">
                    <?php _e('View', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/edit'); ?>" class="rg-building-action">
                    <?php _e('Edit', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/units/add'); ?>" class="rg-building-action primary">
                    <?php _e('Add Unit', 'rental-gates'); ?>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
