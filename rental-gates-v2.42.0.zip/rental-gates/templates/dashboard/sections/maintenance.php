<?php
/**
 * Maintenance List Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$priority_filter = isset($_GET['priority']) ? sanitize_text_field($_GET['priority']) : '';
$category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Get work orders
$args = array(
    'status' => $status_filter ?: null,
    'priority' => $priority_filter ?: null,
    'category' => $category_filter ?: null,
    'search' => $search ?: null,
    'orderby' => 'priority',
    'order' => 'DESC',
);

$work_orders = Rental_Gates_Maintenance::get_for_organization($org_id, $args);
$stats = Rental_Gates_Maintenance::get_stats($org_id);

// Status config
$status_config = array(
    'open' => array('label' => __('Open', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'assigned' => array('label' => __('Assigned', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'in_progress' => array('label' => __('In Progress', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'on_hold' => array('label' => __('On Hold', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'completed' => array('label' => __('Completed', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'cancelled' => array('label' => __('Cancelled', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
);

// Priority config
$priority_config = array(
    'emergency' => array('label' => __('Emergency', 'rental-gates'), 'color' => '#dc2626', 'bg' => '#fee2e2'),
    'high' => array('label' => __('High', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'medium' => array('label' => __('Medium', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'low' => array('label' => __('Low', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

// Category icons
$category_icons = array(
    'plumbing' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/>',
    'electrical' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>',
    'hvac' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
    'appliance' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>',
    'structural' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>',
    'pest' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    'cleaning' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>',
    'general' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>',
    'other' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
);
?>

<style>
    .rg-maintenance-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-maintenance-header h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 16px 20px; }
    .rg-stat-card.highlight { border-color: #3b82f6; background: linear-gradient(135deg, #eff6ff 0%, #fff 100%); }
    .rg-stat-card.danger { border-color: #ef4444; background: linear-gradient(135deg, #fef2f2 0%, #fff 100%); }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-value.danger { color: #dc2626; }
    .rg-stat-value.warning { color: #f59e0b; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-filters-row { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .rg-search-box { flex: 1; min-width: 200px; position: relative; }
    .rg-search-box input { width: 100%; padding: 10px 14px 10px 40px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background-color: #fff; }
    .rg-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); }
    .rg-filter-select { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; min-width: 130px; background-color: #fff; }
    
    .rg-maintenance-table { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    .rg-table { width: 100%; border-collapse: collapse; }
    .rg-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-weight: 600; font-size: 12px; text-transform: uppercase; color: var(--gray-500); border-bottom: 1px solid var(--gray-200); }
    .rg-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); font-size: 14px; }
    .rg-table tr:last-child td { border-bottom: none; }
    .rg-table tr:hover { background: var(--gray-50); }
    
    .rg-wo-info { display: flex; align-items: flex-start; gap: 12px; }
    .rg-wo-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-wo-icon svg { width: 20px; height: 20px; }
    .rg-wo-details { min-width: 0; }
    .rg-wo-details strong { display: block; color: var(--gray-900); font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px; }
    .rg-wo-details span { font-size: 12px; color: var(--gray-500); }
    
    .rg-priority-badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-priority-badge.emergency { animation: pulse 2s infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
    
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-status-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
    
    .rg-days-badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; background: var(--gray-100); color: var(--gray-600); border-radius: 12px; font-size: 11px; }
    .rg-days-badge.overdue { background: #fee2e2; color: #dc2626; }
    
    .rg-table-actions { display: flex; gap: 8px; }
    .rg-table-action { padding: 6px 10px; border: 1px solid var(--gray-300); border-radius: 6px; background: #fff; color: var(--gray-600); font-size: 12px; cursor: pointer; text-decoration: none; }
    .rg-table-action:hover { background: var(--gray-50); border-color: var(--gray-400); }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { font-size: 18px; color: var(--gray-700); margin-bottom: 8px; }
    .rg-empty-state p { color: var(--gray-500); margin-bottom: 20px; }
    
    @media (max-width: 1200px) { .rg-stats-row { grid-template-columns: repeat(3, 1fr); } }
    @media (max-width: 768px) { 
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
        .rg-table-responsive { overflow-x: auto; } 
        .rg-table { min-width: 800px; }
    }
</style>

<!-- Header -->
<div class="rg-maintenance-header">
    <h1><?php _e('Maintenance', 'rental-gates'); ?></h1>
    <a href="<?php echo home_url('/rental-gates/dashboard/maintenance/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        <?php _e('New Work Order', 'rental-gates'); ?>
    </a>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card highlight">
        <div class="rg-stat-value"><?php echo $stats['open']; ?></div>
        <div class="rg-stat-label"><?php _e('Open', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['in_progress']; ?></div>
        <div class="rg-stat-label"><?php _e('In Progress', 'rental-gates'); ?></div>
    </div>
    <?php if ($stats['emergency'] > 0): ?>
    <div class="rg-stat-card danger">
        <div class="rg-stat-value danger"><?php echo $stats['emergency']; ?></div>
        <div class="rg-stat-label"><?php _e('Emergency', 'rental-gates'); ?></div>
    </div>
    <?php else: ?>
    <div class="rg-stat-card">
        <div class="rg-stat-value warning"><?php echo $stats['high']; ?></div>
        <div class="rg-stat-label"><?php _e('High Priority', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['completed']; ?></div>
        <div class="rg-stat-label"><?php _e('Completed', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['total']; ?></div>
        <div class="rg-stat-label"><?php _e('Total', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" action="" class="rg-filters-row">
    <div class="rg-search-box">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" name="search" placeholder="<?php _e('Search work orders...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
    </div>
    
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="open" <?php selected($status_filter, 'open'); ?>><?php _e('Open', 'rental-gates'); ?></option>
        <option value="assigned" <?php selected($status_filter, 'assigned'); ?>><?php _e('Assigned', 'rental-gates'); ?></option>
        <option value="in_progress" <?php selected($status_filter, 'in_progress'); ?>><?php _e('In Progress', 'rental-gates'); ?></option>
        <option value="on_hold" <?php selected($status_filter, 'on_hold'); ?>><?php _e('On Hold', 'rental-gates'); ?></option>
        <option value="completed" <?php selected($status_filter, 'completed'); ?>><?php _e('Completed', 'rental-gates'); ?></option>
    </select>
    
    <select name="priority" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Priorities', 'rental-gates'); ?></option>
        <option value="emergency" <?php selected($priority_filter, 'emergency'); ?>><?php _e('Emergency', 'rental-gates'); ?></option>
        <option value="high" <?php selected($priority_filter, 'high'); ?>><?php _e('High', 'rental-gates'); ?></option>
        <option value="medium" <?php selected($priority_filter, 'medium'); ?>><?php _e('Medium', 'rental-gates'); ?></option>
        <option value="low" <?php selected($priority_filter, 'low'); ?>><?php _e('Low', 'rental-gates'); ?></option>
    </select>
    
    <select name="category" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Categories', 'rental-gates'); ?></option>
        <option value="plumbing" <?php selected($category_filter, 'plumbing'); ?>><?php _e('Plumbing', 'rental-gates'); ?></option>
        <option value="electrical" <?php selected($category_filter, 'electrical'); ?>><?php _e('Electrical', 'rental-gates'); ?></option>
        <option value="hvac" <?php selected($category_filter, 'hvac'); ?>><?php _e('HVAC', 'rental-gates'); ?></option>
        <option value="appliance" <?php selected($category_filter, 'appliance'); ?>><?php _e('Appliance', 'rental-gates'); ?></option>
        <option value="structural" <?php selected($category_filter, 'structural'); ?>><?php _e('Structural', 'rental-gates'); ?></option>
        <option value="pest" <?php selected($category_filter, 'pest'); ?>><?php _e('Pest Control', 'rental-gates'); ?></option>
        <option value="cleaning" <?php selected($category_filter, 'cleaning'); ?>><?php _e('Cleaning', 'rental-gates'); ?></option>
        <option value="general" <?php selected($category_filter, 'general'); ?>><?php _e('General', 'rental-gates'); ?></option>
    </select>
    
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
</form>

<!-- Work Orders Table -->
<div class="rg-maintenance-table">
    <?php if (empty($work_orders)): ?>
    <div class="rg-empty-state">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        <h3><?php _e('No work orders found', 'rental-gates'); ?></h3>
        <p><?php _e('Create a work order to track maintenance requests.', 'rental-gates'); ?></p>
        <a href="<?php echo home_url('/rental-gates/dashboard/maintenance/add'); ?>" class="rg-btn rg-btn-primary"><?php _e('New Work Order', 'rental-gates'); ?></a>
    </div>
    <?php else: ?>
    <div class="rg-table-responsive">
        <table class="rg-table">
            <thead>
                <tr>
                    <th><?php _e('Work Order', 'rental-gates'); ?></th>
                    <th><?php _e('Location', 'rental-gates'); ?></th>
                    <th><?php _e('Priority', 'rental-gates'); ?></th>
                    <th><?php _e('Status', 'rental-gates'); ?></th>
                    <th><?php _e('Created', 'rental-gates'); ?></th>
                    <th><?php _e('Actions', 'rental-gates'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($work_orders as $wo):
                    $status = $status_config[$wo['status']] ?? $status_config['open'];
                    $priority = $priority_config[$wo['priority']] ?? $priority_config['medium'];
                    $icon = $category_icons[$wo['category']] ?? $category_icons['other'];
                ?>
                <tr>
                    <td>
                        <div class="rg-wo-info">
                            <div class="rg-wo-icon" style="background: <?php echo $priority['bg']; ?>; color: <?php echo $priority['color']; ?>;">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><?php echo $icon; ?></svg>
                            </div>
                            <div class="rg-wo-details">
                                <strong><?php echo esc_html($wo['title']); ?></strong>
                                <span><?php echo esc_html($wo['category_label']); ?></span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div>
                            <strong style="font-size: 14px;"><?php echo esc_html($wo['unit_name'] ?? $wo['building_name']); ?></strong><br>
                            <?php if ($wo['unit_name']): ?>
                            <span style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($wo['building_name']); ?></span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <span class="rg-priority-badge <?php echo $wo['priority']; ?>" style="background: <?php echo $priority['bg']; ?>; color: <?php echo $priority['color']; ?>;">
                            <?php echo $priority['label']; ?>
                        </span>
                    </td>
                    <td>
                        <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                            <?php echo $status['label']; ?>
                        </span>
                    </td>
                    <td>
                        <?php echo date('M j, Y', strtotime($wo['created_at'])); ?>
                        <?php if ($wo['days_open'] > 0 && !in_array($wo['status'], array('completed', 'cancelled'))): ?>
                        <span class="rg-days-badge <?php echo $wo['days_open'] > 7 ? 'overdue' : ''; ?>">
                            <?php echo $wo['days_open']; ?>d
                        </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="rg-table-actions">
                            <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/maintenance/' . $wo['id'])); ?>" class="rg-table-action"><?php _e('View', 'rental-gates'); ?></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
