<?php
/**
 * Vendor Form Section (Add/Edit)
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Check if editing
$vendor_id = 0;
$vendor = null;
$is_edit = false;

if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/vendors/(\d+)(?:/edit)?(?:/|$|\?)#', $uri, $matches)) {
        $vendor_id = intval($matches[1]);
    }
}

if ($vendor_id) {
    $vendor = Rental_Gates_Vendor::get($vendor_id);
    if ($vendor && $vendor['organization_id'] === $org_id) {
        $is_edit = true;
    }
}

// Get buildings for service area selection
$buildings_result = Rental_Gates_Building::get_for_organization($org_id);
$buildings = $buildings_result['items'] ?? array();

// Service categories
$categories = Rental_Gates_Vendor::get_service_categories();

$page_title = $is_edit ? __('Edit Vendor', 'rental-gates') : __('Add Vendor', 'rental-gates');
?>

<style>
    .rg-form-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .rg-form-header h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-back-link { display: inline-flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--gray-700); }
    
    .rg-form-container { max-width: 800px; }
    
    .rg-form-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 24px; margin-bottom: 20px; }
    .rg-form-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0 0 20px 0; padding-bottom: 12px; border-bottom: 1px solid var(--gray-100); }
    
    .rg-form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 16px; }
    .rg-form-row.single { grid-template-columns: 1fr; }
    
    .rg-form-group { margin-bottom: 0; }
    .rg-form-group label { display: block; font-size: 14px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .rg-form-group label .required { color: #dc2626; }
    .rg-form-group input,
    .rg-form-group select,
    .rg-form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background-color: #fff; }
    .rg-form-group input:focus,
    .rg-form-group select:focus,
    .rg-form-group textarea:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
    .rg-form-group textarea { min-height: 100px; resize: vertical; }
    .rg-form-hint { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-checkbox-group { display: flex; flex-wrap: wrap; gap: 12px; }
    .rg-checkbox-item { display: flex; align-items: center; gap: 8px; padding: 10px 14px; background: var(--gray-50); border: 1px solid var(--gray-200); border-radius: 8px; cursor: pointer; transition: all 0.2s; }
    .rg-checkbox-item:hover { border-color: #3b82f6; background: #eff6ff; }
    .rg-checkbox-item.checked { border-color: #3b82f6; background: #eff6ff; }
    .rg-checkbox-item input { width: 16px; height: 16px; margin: 0; cursor: pointer; }
    .rg-checkbox-item span { font-size: 14px; color: var(--gray-700); }
    
    .rg-status-options { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .rg-status-option { display: flex; flex-direction: column; align-items: center; padding: 16px; border: 2px solid var(--gray-200); border-radius: 10px; cursor: pointer; transition: all 0.2s; }
    .rg-status-option:hover { border-color: var(--gray-300); }
    .rg-status-option.selected { border-color: #3b82f6; background: #eff6ff; }
    .rg-status-option input { display: none; }
    .rg-status-option .status-dot { width: 12px; height: 12px; border-radius: 50%; margin-bottom: 8px; }
    .rg-status-option .status-label { font-size: 14px; font-weight: 500; color: var(--gray-700); }
    .rg-status-option .status-desc { font-size: 12px; color: var(--gray-500); margin-top: 4px; text-align: center; }
    
    .rg-form-actions { display: flex; gap: 12px; justify-content: flex-end; padding-top: 20px; border-top: 1px solid var(--gray-200); margin-top: 20px; }
    
    .rg-action-btn { padding: 10px 20px; border: 1px solid var(--gray-300); background: #fff; border-radius: 8px; font-size: 14px; font-weight: 500; color: var(--gray-700); cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }
    .rg-action-btn:hover { background: var(--gray-50); border-color: var(--gray-400); }
    .rg-action-btn.primary { background: #3b82f6; border-color: #3b82f6; color: #fff; }
    .rg-action-btn.primary:hover { background: #2563eb; }
    .rg-action-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    
    @media (max-width: 768px) {
        .rg-form-row { grid-template-columns: 1fr; }
        .rg-status-options { grid-template-columns: 1fr; }
    }
</style>

<a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors' . ($is_edit ? '/' . $vendor_id : ''))); ?>" class="rg-back-link">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 12H5M12 19l-7-7 7-7"/>
    </svg>
    <?php echo $is_edit ? __('Back to Vendor', 'rental-gates') : __('Back to Vendors', 'rental-gates'); ?>
</a>

<div class="rg-form-header">
    <h1><?php echo esc_html($page_title); ?></h1>
</div>

<form id="vendorForm" class="rg-form-container">
    <input type="hidden" name="vendor_id" value="<?php echo $is_edit ? intval($vendor['id']) : 0; ?>">
    
    <!-- Company Information -->
    <div class="rg-form-card">
        <h3 class="rg-form-card-title"><?php _e('Company Information', 'rental-gates'); ?></h3>
        
        <div class="rg-form-row">
            <div class="rg-form-group">
                <label for="company_name"><?php _e('Company Name', 'rental-gates'); ?> <span class="required">*</span></label>
                <input type="text" id="company_name" name="company_name" required value="<?php echo $is_edit ? esc_attr($vendor['company_name']) : ''; ?>" placeholder="<?php esc_attr_e('e.g., ABC Plumbing Services', 'rental-gates'); ?>">
            </div>
            <div class="rg-form-group">
                <label for="contact_name"><?php _e('Contact Person', 'rental-gates'); ?> <span class="required">*</span></label>
                <input type="text" id="contact_name" name="contact_name" required value="<?php echo $is_edit ? esc_attr($vendor['contact_name']) : ''; ?>" placeholder="<?php esc_attr_e('e.g., John Smith', 'rental-gates'); ?>">
            </div>
        </div>
        
        <div class="rg-form-row">
            <div class="rg-form-group">
                <label for="email"><?php _e('Email', 'rental-gates'); ?> <span class="required">*</span></label>
                <input type="email" id="email" name="email" required value="<?php echo $is_edit ? esc_attr($vendor['email']) : ''; ?>" placeholder="<?php esc_attr_e('vendor@example.com', 'rental-gates'); ?>">
            </div>
            <div class="rg-form-group">
                <label for="phone"><?php _e('Phone', 'rental-gates'); ?> <span class="required">*</span></label>
                <input type="tel" id="phone" name="phone" required value="<?php echo $is_edit ? esc_attr($vendor['phone']) : ''; ?>" placeholder="<?php esc_attr_e('(555) 123-4567', 'rental-gates'); ?>">
            </div>
        </div>
        
        <div class="rg-form-row single">
            <div class="rg-form-group">
                <label for="hourly_rate"><?php _e('Hourly Rate', 'rental-gates'); ?></label>
                <input type="number" id="hourly_rate" name="hourly_rate" step="0.01" min="0" value="<?php echo $is_edit && $vendor['hourly_rate'] ? esc_attr($vendor['hourly_rate']) : ''; ?>" placeholder="<?php esc_attr_e('e.g., 75.00', 'rental-gates'); ?>">
                <div class="rg-form-hint"><?php _e('Optional. Used for estimating job costs.', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <!-- Service Categories -->
    <div class="rg-form-card">
        <h3 class="rg-form-card-title"><?php _e('Service Categories', 'rental-gates'); ?></h3>
        <p style="font-size: 14px; color: var(--gray-600); margin: 0 0 16px 0;">
            <?php _e('Select the types of services this vendor provides. This helps match them to relevant work orders.', 'rental-gates'); ?>
        </p>
        
        <div class="rg-checkbox-group">
            <?php 
            $selected_categories = $is_edit ? $vendor['service_categories'] : array();
            foreach ($categories as $key => $label): 
                $checked = in_array($key, $selected_categories);
            ?>
                <label class="rg-checkbox-item <?php echo $checked ? 'checked' : ''; ?>">
                    <input type="checkbox" name="service_categories[]" value="<?php echo esc_attr($key); ?>" <?php checked($checked); ?> onchange="this.parentElement.classList.toggle('checked', this.checked)">
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Service Areas (Buildings) -->
    <?php if (!empty($buildings)): ?>
    <div class="rg-form-card">
        <h3 class="rg-form-card-title"><?php _e('Service Areas', 'rental-gates'); ?></h3>
        <p style="font-size: 14px; color: var(--gray-600); margin: 0 0 16px 0;">
            <?php _e('Optionally limit this vendor to specific buildings. Leave all unchecked to allow service at any building.', 'rental-gates'); ?>
        </p>
        
        <div class="rg-checkbox-group">
            <?php 
            $selected_buildings = $is_edit ? $vendor['service_buildings'] : array();
            foreach ($buildings as $building): 
                $checked = in_array($building['id'], $selected_buildings);
            ?>
                <label class="rg-checkbox-item <?php echo $checked ? 'checked' : ''; ?>">
                    <input type="checkbox" name="service_buildings[]" value="<?php echo esc_attr($building['id']); ?>" <?php checked($checked); ?> onchange="this.parentElement.classList.toggle('checked', this.checked)">
                    <span><?php echo esc_html($building['name']); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Status -->
    <div class="rg-form-card">
        <h3 class="rg-form-card-title"><?php _e('Status', 'rental-gates'); ?></h3>
        
        <div class="rg-status-options">
            <?php 
            $current_status = $is_edit ? $vendor['status'] : 'active';
            $statuses = array(
                'active' => array(
                    'label' => __('Active', 'rental-gates'),
                    'desc' => __('Available for assignments', 'rental-gates'),
                    'color' => '#10b981',
                ),
                'paused' => array(
                    'label' => __('Paused', 'rental-gates'),
                    'desc' => __('Temporarily unavailable', 'rental-gates'),
                    'color' => '#f59e0b',
                ),
                'inactive' => array(
                    'label' => __('Inactive', 'rental-gates'),
                    'desc' => __('No longer working with', 'rental-gates'),
                    'color' => '#6b7280',
                ),
            );
            foreach ($statuses as $key => $status):
            ?>
                <label class="rg-status-option <?php echo $current_status === $key ? 'selected' : ''; ?>">
                    <input type="radio" name="status" value="<?php echo esc_attr($key); ?>" <?php checked($current_status, $key); ?> onchange="document.querySelectorAll('.rg-status-option').forEach(el => el.classList.remove('selected')); this.parentElement.classList.add('selected');">
                    <div class="status-dot" style="background-color: <?php echo esc_attr($status['color']); ?>;"></div>
                    <div class="status-label"><?php echo esc_html($status['label']); ?></div>
                    <div class="status-desc"><?php echo esc_html($status['desc']); ?></div>
                </label>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Notes -->
    <div class="rg-form-card">
        <h3 class="rg-form-card-title"><?php _e('Notes', 'rental-gates'); ?></h3>
        
        <div class="rg-form-group">
            <label for="notes"><?php _e('Internal Notes', 'rental-gates'); ?></label>
            <textarea id="notes" name="notes" placeholder="<?php esc_attr_e('Add any internal notes about this vendor...', 'rental-gates'); ?>"><?php echo $is_edit ? esc_textarea($vendor['notes']) : ''; ?></textarea>
            <div class="rg-form-hint"><?php _e('These notes are only visible to your team, not to the vendor.', 'rental-gates'); ?></div>
        </div>
    </div>
    
    <!-- Form Actions -->
    <div class="rg-form-actions">
        <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors' . ($is_edit ? '/' . $vendor_id : ''))); ?>" class="rg-action-btn">
            <?php _e('Cancel', 'rental-gates'); ?>
        </a>
        <button type="submit" class="rg-action-btn primary" id="submitBtn">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                <polyline points="7 3 7 8 15 8"></polyline>
            </svg>
            <?php echo $is_edit ? __('Save Changes', 'rental-gates') : __('Create Vendor', 'rental-gates'); ?>
        </button>
    </div>
</form>

<script>
document.getElementById('vendorForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submitBtn');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<svg class="animate-spin" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg> <?php echo esc_js(__('Saving...', 'rental-gates')); ?>';
    
    const formData = new FormData(this);
    const vendorId = formData.get('vendor_id');
    const isEdit = vendorId && vendorId !== '0';
    
    formData.append('action', isEdit ? 'rental_gates_update_vendor' : 'rental_gates_create_vendor');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
    
    try {
        const response = await fetch(ajaxurl, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            const redirectId = data.data?.vendor_id || vendorId;
            window.location.href = '<?php echo esc_url(home_url('/rental-gates/dashboard/vendors/')); ?>' + redirectId;
        } else {
            alert(data.data?.message || '<?php echo esc_js(__('An error occurred', 'rental-gates')); ?>');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    } catch (error) {
        console.error('Error:', error);
        alert('<?php echo esc_js(__('An error occurred', 'rental-gates')); ?>');
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    }
});
</script>
