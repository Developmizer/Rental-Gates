<?php
/**
 * Owner Dashboard - Billing & Subscription Section
 * 
 * View current plan, usage statistics, and manage subscription.
 */
if (!defined('ABSPATH'))
    exit;

// Get feature gate instance
$feature_gate = rg_feature_gate();
$current_plan = $feature_gate->get_org_plan();
$usage = $feature_gate->get_all_usage();
$modules = $feature_gate->get_all_modules();

// Get plans from feature gate (includes fallback to defaults)
$plans = $feature_gate->get_all_plans();

// Sort plans by sort_order
uasort($plans, function ($a, $b) {
    return ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0);
});

// Get organization details
$org_id = $feature_gate->get_user_org_id();
global $wpdb;
$organization = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}rg_organizations WHERE id = %d",
    $org_id
), ARRAY_A);

// Get Stripe settings - check both option name formats for compatibility
$stripe_mode = get_option('rental_gates_stripe_mode', 'test');

// Check short format first (dashboard settings), then long format (WP admin)
$stripe_pk = get_option('rental_gates_stripe_' . $stripe_mode . '_pk', '');
if (empty($stripe_pk)) {
    $stripe_pk = get_option('rental_gates_stripe_' . $stripe_mode . '_publishable_key', '');
}
$stripe_enabled = !empty($stripe_pk);

// Get subscription info (if exists) - include all relevant statuses
// Also include subscriptions with cancel_at_period_end = 1 (scheduled to cancel) so resume button shows
// Include cancelled subscriptions that haven't reached period_end yet (still have access)
$subscription = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}rg_subscriptions 
     WHERE organization_id = %d 
     AND (status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete', 'incomplete_expired', 'pending_payment') 
          OR status IS NULL 
          OR status = ''
          OR cancel_at_period_end = 1
          OR (status = 'cancelled' AND current_period_end > %s))
     ORDER BY created_at DESC LIMIT 1",
    $org_id,
    current_time('mysql')
), ARRAY_A);

// If subscription has a Stripe ID, sync on page load to ensure data is fresh
// This ensures billing_cycle and other data is up-to-date with Stripe
// Also sync if status is empty (fix for subscriptions with missing status)
if ($subscription && !empty($subscription['stripe_subscription_id']) && class_exists('Rental_Gates_Billing')) {
    // Always sync with Stripe to ensure billing_cycle and status are correct
    // This is especially important if status is empty
    $needs_sync = empty($subscription['status']) || empty($subscription['billing_cycle']);
    $sync_result = Rental_Gates_Billing::sync_subscription_status($org_id);
    if (!is_wp_error($sync_result) && isset($sync_result['subscription'])) {
        $subscription = $sync_result['subscription'];
    }
    
    // One-time fix: If status is empty, set it to 'active' (fix for existing subscriptions)
    if (empty($subscription['status'])) {
        $wpdb->update(
            $wpdb->prefix . 'rg_subscriptions',
            array('status' => 'active', 'updated_at' => current_time('mysql')),
            array('id' => $subscription['id']),
            array('%s', '%s'),
            array('%d')
        );
        $subscription['status'] = 'active';
    }
    
    // One-time fix: If billing_cycle is monthly but period is yearly, update the database
    if (($subscription['billing_cycle'] ?? 'monthly') === 'monthly' 
        && !empty($subscription['current_period_start']) 
        && !empty($subscription['current_period_end'])) {
        
        $period_start = strtotime($subscription['current_period_start']);
        $period_end = strtotime($subscription['current_period_end']);
        $period_days = ($period_end - $period_start) / 86400;
        
        // If period is more than 60 days, it's yearly - fix the database
        if ($period_days > 60) {
            $wpdb->update(
                $wpdb->prefix . 'rg_subscriptions',
                array('billing_cycle' => 'yearly', 'updated_at' => current_time('mysql')),
                array('id' => $subscription['id']),
                array('%s', '%s'),
                array('%d')
            );
            $subscription['billing_cycle'] = 'yearly';
        }
    }
}

// Subscription status helpers
$is_cancelling = !empty($subscription['cancel_at_period_end']);
$is_trialing = !empty($subscription['status']) && $subscription['status'] === 'trialing';
$is_past_due = !empty($subscription['status']) && $subscription['status'] === 'past_due';
$is_pending = !empty($subscription['status']) && $subscription['status'] === 'pending_payment';
$has_stripe_sub = !empty($subscription['stripe_subscription_id']);

// Calculate cancel date
$cancel_date = $is_cancelling && !empty($subscription['current_period_end'])
    ? date_i18n(get_option('date_format'), strtotime($subscription['current_period_end']))
    : null;

// Calculate trial end date
$trial_end_date = $is_trialing && !empty($subscription['trial_end'])
    ? date_i18n(get_option('date_format'), strtotime($subscription['trial_end']))
    : null;

// Check for scheduled downgrade
$scheduled_downgrade = !empty($subscription['downgrade_to_plan']) ? $subscription['downgrade_to_plan'] : null;

// Determine billing cycle using multiple detection methods
$sub_billing_cycle = 'monthly';
if ($subscription) {
    // 1. Check subscription's billing_cycle field
    if (!empty($subscription['billing_cycle'])) {
        $sub_billing_cycle = $subscription['billing_cycle'];
    }
    
    // 2. Fallback: Check period length (>60 days = yearly)
    if ($sub_billing_cycle === 'monthly' 
        && !empty($subscription['current_period_start']) 
        && !empty($subscription['current_period_end'])) {
        $period_days = (strtotime($subscription['current_period_end']) - strtotime($subscription['current_period_start'])) / 86400;
        if ($period_days > 60) {
            $sub_billing_cycle = 'yearly';
        }
    }
    
    // 3. Fallback: Check if amount matches yearly price
    if ($sub_billing_cycle === 'monthly' && !empty($subscription['amount']) && !empty($current_plan['price_yearly'])) {
        $sub_amount = floatval($subscription['amount']);
        $yearly_price = floatval($current_plan['price_yearly']);
        if ($yearly_price > 0 && abs($sub_amount - $yearly_price) < 1) {
            $sub_billing_cycle = 'yearly';
        }
    }
}

// Get invoices
$invoices = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}rg_invoices WHERE organization_id = %d ORDER BY created_at DESC LIMIT 10",
    $org_id
), ARRAY_A) ?: array();

// Module labels
$module_labels = array(
    'tenant_portal' => 'Tenant Portal',
    'online_payments' => 'Online Payments',
    'maintenance' => 'Maintenance Tracking',
    'lease_management' => 'Lease Management',
    'ai_screening' => 'AI Tenant Screening',
    'marketing_qr' => 'Marketing & QR Codes',
    'vendor_management' => 'Vendor Management',
    'chat_messaging' => 'Chat & Messaging',
    'api_access' => 'API Access',
    'advanced_reports' => 'Advanced Reports',
    'bulk_operations' => 'Bulk Operations',
    'white_label' => 'White Label',
);

// Limit labels
$limit_labels = array(
    'buildings' => 'Buildings',
    'units' => 'Units',
    'staff' => 'Staff Members',
    'vendors' => 'Vendors',
    'tenants' => 'Tenants',
    'storage_gb' => 'Storage',
);

// Handle plan change request
$selected_plan = isset($_GET['plan']) ? sanitize_key($_GET['plan']) : null;
$show_checkout = $selected_plan && isset($plans[$selected_plan]) && $selected_plan !== ($current_plan['id'] ?? 'free');

// Get billing cycle from URL (defaults to monthly)
$billing_cycle = isset($_GET['billing_cycle']) && $_GET['billing_cycle'] === 'yearly' ? 'yearly' : 'monthly';

// Current view
$view = isset($_GET['view']) ? sanitize_key($_GET['view']) : 'overview';
?>

<style>
    /* ==========================================
   BILLING PAGE - ENHANCED UI/UX
   ========================================== */

    /* CSS Variables for theming */
    :root {
        --billing-primary: #0d9488;
        --billing-primary-dark: #0f766e;
        --billing-primary-light: #14b8a6;
        --billing-success: #22c55e;
        --billing-warning: #f59e0b;
        --billing-danger: #ef4444;
        --billing-info: #3b82f6;
    }

    /* Animations */
    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes pulse {

        0%,
        100% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.05);
        }
    }

    @keyframes shimmer {
        0% {
            background-position: -200% 0;
        }

        100% {
            background-position: 200% 0;
        }
    }

    /* Alert Styles */
    .billing-alert {
        display: flex;
        align-items: flex-start;
        gap: 14px;
        padding: 16px 20px;
        border-radius: 12px;
        margin-bottom: 24px;
        animation: fadeInDown 0.4s ease-out;
        border: 1px solid transparent;
    }

    .billing-alert svg {
        width: 22px;
        height: 22px;
        flex-shrink: 0;
        margin-top: 1px;
    }

    .billing-alert-content {
        flex: 1;
    }

    .billing-alert-title {
        font-weight: 600;
        font-size: 15px;
        margin-bottom: 2px;
    }

    .billing-alert-message {
        font-size: 14px;
        opacity: 0.9;
    }

    .billing-alert.success {
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        border-color: #86efac;
        color: #166534;
    }

    .billing-alert.success svg {
        color: #22c55e;
    }

    .billing-alert.info {
        background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
        border-color: #93c5fd;
        color: #1e40af;
    }

    .billing-alert.info svg {
        color: #3b82f6;
    }

    .billing-alert.warning {
        background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
        border-color: #fcd34d;
        color: #92400e;
    }

    .billing-alert.warning svg {
        color: #f59e0b;
    }

    .billing-alert-close {
        background: none;
        border: none;
        padding: 4px;
        cursor: pointer;
        opacity: 0.5;
        transition: opacity 0.2s;
    }

    .billing-alert-close:hover {
        opacity: 1;
    }

    /* Header */
    .billing-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 32px;
        flex-wrap: wrap;
        gap: 16px;
    }

    .billing-title {
        font-size: 26px;
        font-weight: 700;
        color: #1c1917;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .billing-title-icon {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, var(--billing-primary) 0%, var(--billing-primary-dark) 100%);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
    }

    .billing-title-icon svg {
        width: 22px;
        height: 22px;
    }

    /* Tabs */
    .billing-tabs {
        display: flex;
        gap: 4px;
        background: #f5f5f4;
        padding: 5px;
        border-radius: 12px;
    }

    .billing-tab {
        padding: 10px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        color: #57534e;
        text-decoration: none;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .billing-tab svg {
        width: 16px;
        height: 16px;
    }

    .billing-tab:hover {
        color: #1c1917;
        background: rgba(255, 255, 255, 0.5);
    }

    .billing-tab.active {
        background: #fff;
        color: #1c1917;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    /* Button Styles */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px;
        border: none;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.2s ease;
        white-space: nowrap;
    }

    .btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }

    .btn svg {
        width: 18px;
        height: 18px;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--billing-primary) 0%, var(--billing-primary-dark) 100%);
        color: #fff;
        box-shadow: 0 2px 8px rgba(13, 148, 136, 0.3);
    }

    .btn-primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(13, 148, 136, 0.4);
    }

    .btn-primary:active:not(:disabled) {
        transform: translateY(0);
    }

    .btn-secondary {
        background: #f5f5f4;
        color: #57534e;
        border: 1px solid #e7e5e4;
    }

    .btn-secondary:hover:not(:disabled) {
        background: #e7e5e4;
        color: #1c1917;
    }

    .btn-outline {
        background: transparent;
        color: var(--billing-primary);
        border: 2px solid var(--billing-primary);
    }

    .btn-outline:hover:not(:disabled) {
        background: var(--billing-primary);
        color: #fff;
    }

    .btn-danger {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: #fff;
    }

    .btn-danger:hover:not(:disabled) {
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
    }

    .btn-warning {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: #fff;
    }

    .btn-warning:hover:not(:disabled) {
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
    }

    .btn-ghost {
        background: transparent;
        color: #57534e;
    }

    .btn-ghost:hover:not(:disabled) {
        background: #f5f5f4;
        color: #1c1917;
    }

    .btn-sm {
        padding: 6px 14px;
        font-size: 13px;
        border-radius: 8px;
    }

    .btn-lg {
        padding: 14px 28px;
        font-size: 16px;
        border-radius: 12px;
    }

    .btn-upgrade {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        color: #fff;
        box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
    }

    .btn-upgrade:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
    }

    .btn-gold {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: #fff;
        box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);
    }

    .btn-gold:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
    }

    /* Current Plan Card */
    .current-plan-card {
        background: linear-gradient(135deg, #1c1917 0%, #292524 100%);
        border-radius: 24px;
        padding: 32px;
        color: #fff;
        margin-bottom: 32px;
        position: relative;
        overflow: hidden;
        animation: slideUp 0.5s ease-out;
    }

    .current-plan-card::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 60%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
        pointer-events: none;
    }

    .current-plan-card::after {
        content: '';
        position: absolute;
        bottom: -30%;
        left: -10%;
        width: 40%;
        height: 100%;
        background: radial-gradient(circle, rgba(13, 148, 136, 0.2) 0%, transparent 70%);
        pointer-events: none;
    }

    .current-plan-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 28px;
        position: relative;
        z-index: 1;
    }

    .current-plan-info h2 {
        font-size: 12px;
        font-weight: 600;
        color: #a8a29e;
        margin: 0 0 10px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .current-plan-name {
        font-size: 34px;
        font-weight: 700;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .plan-badge-inline {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .plan-badge-inline.free {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(10px);
    }

    .plan-badge-inline.basic {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    }

    .plan-badge-inline.silver {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
    }

    .plan-badge-inline.gold {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    }

    .current-plan-price {
        text-align: right;
        position: relative;
        z-index: 1;
    }

    .price-amount {
        font-size: 40px;
        font-weight: 700;
        line-height: 1;
    }

    .price-amount sup {
        font-size: 20px;
        vertical-align: super;
        opacity: 0.7;
    }

    .price-period {
        font-size: 14px;
        color: #a8a29e;
        margin-top: 4px;
    }

    .plan-status {
        display: flex;
        gap: 32px;
        padding-top: 24px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        position: relative;
        z-index: 1;
        flex-wrap: wrap;
    }

    .plan-status-item {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .plan-status-label {
        font-size: 11px;
        color: #a8a29e;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .plan-status-value {
        font-size: 15px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .status-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        box-shadow: 0 0 8px currentColor;
    }

    .status-dot.active {
        background: #22c55e;
        color: #22c55e;
    }

    .status-dot.trialing {
        background: #8b5cf6;
        color: #8b5cf6;
        animation: pulse 2s infinite;
    }

    .status-dot.past_due {
        background: #ef4444;
        color: #ef4444;
        animation: pulse 1.5s infinite;
    }

    .status-dot.incomplete,
    .status-dot.pending_payment {
        background: #f59e0b;
        color: #f59e0b;
    }

    .status-dot.cancelled {
        background: #6b7280;
        color: #6b7280;
    }

    .status-dot.cancelling {
        background: #f59e0b;
        color: #f59e0b;
    }

    /* Trial badge */
    .trial-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* Past due alert */
    .past-due-alert {
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.3);
        border-radius: 10px;
        padding: 12px 16px;
        margin-top: 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        color: #fca5a5;
        font-size: 14px;
    }

    .past-due-alert svg {
        flex-shrink: 0;
        color: #ef4444;
    }

    /* Toast Notifications */
    .billing-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 20px;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 500;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
        transform: translateX(120%);
        transition: transform 0.3s ease;
        max-width: 400px;
    }

    .billing-toast.show {
        transform: translateX(0);
    }

    .billing-toast-success {
        background: linear-gradient(135deg, #059669 0%, #047857 100%);
        color: #fff;
    }

    .billing-toast-error {
        background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
        color: #fff;
    }

    .billing-toast-warning {
        background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
        color: #fff;
    }

    .billing-toast-info {
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        color: #fff;
    }

    .billing-toast-close {
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: #fff;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: auto;
        flex-shrink: 0;
    }

    .billing-toast-close:hover {
        background: rgba(255, 255, 255, 0.3);
    }

    .plan-actions {
        display: flex;
        gap: 10px;
        margin-left: auto;
    }

    .plan-actions .btn {
        backdrop-filter: blur(10px);
    }

    /* Usage Section */
    .usage-section {
        background: #fff;
        border: 1px solid #e7e5e4;
        border-radius: 20px;
        padding: 28px;
        margin-bottom: 24px;
        animation: slideUp 0.5s ease-out 0.1s both;
    }

    .usage-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }

    .usage-section-title {
        font-size: 17px;
        font-weight: 700;
        color: #1c1917;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .usage-section-title svg {
        width: 20px;
        height: 20px;
        color: var(--billing-primary);
    }

    .usage-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 16px;
    }

    .usage-item {
        padding: 18px;
        background: linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%);
        border-radius: 14px;
        transition: all 0.2s ease;
    }

    .usage-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .usage-item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 14px;
    }

    .usage-item-label {
        font-size: 13px;
        font-weight: 600;
        color: #57534e;
    }

    .usage-item-value {
        font-size: 13px;
        font-weight: 700;
        color: #1c1917;
        background: #fff;
        padding: 4px 10px;
        border-radius: 6px;
    }

    .usage-bar {
        height: 10px;
        background: #e7e5e4;
        border-radius: 5px;
        overflow: hidden;
    }

    .usage-bar-fill {
        height: 100%;
        border-radius: 5px;
        transition: width 0.5s ease;
    }

    .usage-bar-fill.good {
        background: linear-gradient(90deg, #22c55e, #16a34a);
    }

    .usage-bar-fill.warning {
        background: linear-gradient(90deg, #f59e0b, #d97706);
    }

    .usage-bar-fill.critical {
        background: linear-gradient(90deg, #ef4444, #dc2626);
    }

    .usage-bar-fill.unlimited {
        background: linear-gradient(90deg, #3b82f6, #8b5cf6);
        width: 100% !important;
        background-size: 200% 100%;
        animation: shimmer 2s ease-in-out infinite;
    }

    /* Modules Grid */
    .modules-section {
        background: #fff;
        border: 1px solid #e7e5e4;
        border-radius: 20px;
        padding: 28px;
        margin-bottom: 24px;
        animation: slideUp 0.5s ease-out 0.2s both;
    }

    .modules-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 12px;
    }

    .module-chip {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        border-radius: 12px;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .module-chip.enabled {
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        color: #166534;
        border: 1px solid #86efac;
    }

    .module-chip.enabled:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(34, 197, 94, 0.15);
    }

    .module-chip.disabled {
        background: #fafaf9;
        color: #a8a29e;
        border: 1px solid #e7e5e4;
    }

    .module-chip svg {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
    }

    .module-chip.enabled svg {
        color: #22c55e;
    }

    .module-chip.disabled svg {
        color: #d6d3d1;
    }

    /* Plans Section */
    .plans-section {
        margin-bottom: 32px;
    }

    .plans-section-header {
        text-align: center;
        margin-bottom: 40px;
    }

    .plans-section-title {
        font-size: 28px;
        font-weight: 700;
        color: #1c1917;
        margin: 0 0 10px;
    }

    .plans-section-subtitle {
        font-size: 16px;
        color: #57534e;
        margin: 0;
    }

    /* Billing Period Toggle */
    .billing-toggle-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 16px;
        margin-top: 24px;
    }

    .billing-toggle-label {
        font-size: 15px;
        font-weight: 500;
        color: #78716c;
        cursor: pointer;
        transition: color 0.2s;
    }

    .billing-toggle-label.active {
        color: #1c1917;
        font-weight: 600;
    }

    .billing-toggle {
        width: 52px;
        height: 28px;
        background: #e7e5e4;
        border-radius: 100px;
        cursor: pointer;
        position: relative;
        transition: background 0.3s;
    }

    .billing-toggle.yearly {
        background: linear-gradient(135deg, var(--billing-primary) 0%, var(--billing-primary-dark) 100%);
    }

    .billing-toggle::after {
        content: '';
        position: absolute;
        width: 22px;
        height: 22px;
        background: #fff;
        border-radius: 50%;
        top: 3px;
        left: 3px;
        transition: transform 0.3s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .billing-toggle.yearly::after {
        transform: translateX(24px);
    }

    .billing-save-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
        color: #166534;
        font-size: 12px;
        font-weight: 700;
        border-radius: 100px;
        animation: pulse 2s ease-in-out infinite;
    }

    .billing-save-badge svg {
        width: 14px;
        height: 14px;
    }

    /* Plan card price transitions */
    .plan-card-price {
        margin: 24px 0;
        text-align: center;
        padding: 20px;
        background: #fafaf9;
        border-radius: 16px;
    }

    .plan-card-amount {
        font-size: 48px;
        font-weight: 700;
        color: #1c1917;
        line-height: 1;
        transition: all 0.3s ease;
    }

    .plan-card-amount sup {
        font-size: 24px;
        vertical-align: super;
    }

    .plan-card-amount.free-price {
        color: #059669;
        font-size: 36px;
    }

    .plan-card-period {
        font-size: 14px;
        color: #78716c;
        margin-top: 4px;
    }

    .plan-card-original-price {
        font-size: 16px;
        color: #a8a29e;
        text-decoration: line-through;
        margin-bottom: 4px;
    }

    .plan-card-savings {
        display: inline-block;
        margin-top: 8px;
        padding: 4px 10px;
        background: #dcfce7;
        color: #166534;
        font-size: 12px;
        font-weight: 600;
        border-radius: 100px;
    }

    .plans-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 24px;
        max-width: 1200px;
        margin: 0 auto;
    }

    /* Modern Plan Card Design */
    .plan-card {
        background: #fff;
        border: 1px solid #e5e5e5;
        border-radius: 20px;
        padding: 0;
        position: relative;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: slideUp 0.5s ease-out both;
    }

    .plan-card:nth-child(1) {
        animation-delay: 0s;
    }

    .plan-card:nth-child(2) {
        animation-delay: 0.1s;
    }

    .plan-card:nth-child(3) {
        animation-delay: 0.2s;
    }

    .plan-card:nth-child(4) {
        animation-delay: 0.3s;
    }

    .plan-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08), 0 8px 16px rgba(0, 0, 0, 0.06);
    }

    .plan-card.current {
        border: 2px solid var(--billing-primary);
    }

    .plan-card.current::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--billing-primary), var(--billing-primary-light));
    }

    .plan-card.featured {
        border: 2px solid #8b5cf6;
        box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.08);
    }

    .plan-card.featured::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #8b5cf6, #a78bfa);
    }

    .plan-card.featured:hover {
        transform: translateY(-8px) scale(1.01);
        box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.12), 0 20px 40px rgba(139, 92, 246, 0.15);
    }

    /* Plan Card Header */
    .plan-card-header-section {
        padding: 32px 28px 24px;
        text-align: center;
        background: linear-gradient(180deg, #fafafa 0%, #fff 100%);
        border-bottom: 1px solid #f0f0f0;
    }

    .plan-card-badge {
        position: absolute;
        top: 16px;
        right: 16px;
        padding: 6px 14px;
        border-radius: 100px;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .plan-card-badge svg {
        width: 12px;
        height: 12px;
    }

    .plan-card-badge.current-badge {
        background: var(--billing-primary);
        color: #fff;
    }

    .plan-card-badge.featured-badge {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        color: #fff;
    }

    .plan-card-icon {
        width: 64px;
        height: 64px;
        margin: 0 auto 20px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
    }

    .plan-card-icon::after {
        content: '';
        position: absolute;
        inset: -4px;
        border-radius: 20px;
        opacity: 0.15;
    }

    .plan-card-icon.free-icon {
        background: #f5f5f4;
        color: #78716c;
    }

    .plan-card-icon.free-icon::after {
        background: #78716c;
    }

    .plan-card-icon.basic-icon {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: #fff;
    }

    .plan-card-icon.basic-icon::after {
        background: #3b82f6;
    }

    .plan-card-icon.silver-icon {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        color: #fff;
    }

    .plan-card-icon.silver-icon::after {
        background: #8b5cf6;
    }

    .plan-card-icon.gold-icon {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: #fff;
    }

    .plan-card-icon.gold-icon::after {
        background: #f59e0b;
    }

    .plan-card-icon svg {
        width: 28px;
        height: 28px;
    }

    .plan-card-name {
        font-size: 24px;
        font-weight: 700;
        color: #1c1917;
        margin: 0 0 8px;
        letter-spacing: -0.02em;
    }

    .plan-card-desc {
        font-size: 14px;
        color: #78716c;
        margin: 0;
        line-height: 1.5;
    }

    /* Plan Card Price Section */
    .plan-card-price {
        padding: 24px 28px;
        text-align: center;
        background: #fff;
    }

    .plan-card-amount {
        display: flex;
        align-items: baseline;
        justify-content: center;
        gap: 4px;
        line-height: 1;
        transition: all 0.3s ease;
    }

    .plan-card-amount .currency {
        font-size: 24px;
        font-weight: 600;
        color: #57534e;
        align-self: flex-start;
        margin-top: 8px;
    }

    .plan-card-amount .price-value {
        font-size: 56px;
        font-weight: 800;
        color: #1c1917;
        letter-spacing: -0.03em;
    }

    .plan-card-amount.free-price .price-value {
        font-size: 40px;
        color: #22c55e;
        font-weight: 700;
    }

    .plan-card-period {
        font-size: 14px;
        color: #78716c;
        margin-top: 8px;
    }

    .plan-card-original-price {
        font-size: 16px;
        color: #a8a29e;
        text-decoration: line-through;
        margin-bottom: 4px;
    }

    .plan-card-savings {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        margin-top: 12px;
        padding: 6px 14px;
        background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
        color: #166534;
        font-size: 12px;
        font-weight: 700;
        border-radius: 100px;
    }

    .plan-card-savings svg {
        width: 14px;
        height: 14px;
    }

    /* Plan Card Features */
    .plan-card-features {
        padding: 24px 28px;
        flex: 1;
        border-top: 1px solid #f0f0f0;
    }

    .plan-features-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #a8a29e;
        margin-bottom: 16px;
    }

    .plan-feature {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 10px 0;
        font-size: 14px;
        color: #44403c;
        line-height: 1.4;
    }

    .plan-feature:not(:last-child) {
        border-bottom: 1px solid #f5f5f4;
    }

    .plan-feature .check-icon {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        color: #22c55e;
        margin-top: 1px;
    }

    .plan-feature .x-icon {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
        color: #d6d3d1;
        margin-top: 1px;
    }

    .plan-feature.disabled {
        color: #a8a29e;
    }

    /* Plan Card Action */
    .plan-card-action {
        padding: 20px 28px 28px;
        margin-top: auto;
    }

    .plan-card-action .btn {
        width: 100%;
        padding: 16px 24px;
        font-size: 15px;
        font-weight: 600;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.3s ease;
    }

    .plan-card-action .btn:hover:not(:disabled) {
        transform: translateY(-2px);
    }

    .plan-card-action .btn-upgrade {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        color: #fff;
        border: none;
    }

    .plan-card-action .btn-upgrade:hover:not(:disabled) {
        box-shadow: 0 8px 20px rgba(139, 92, 246, 0.35);
    }

    .plan-card-action .btn-gold {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: #fff;
        border: none;
    }

    .plan-card-action .btn-gold:hover:not(:disabled) {
        box-shadow: 0 8px 20px rgba(245, 158, 11, 0.35);
    }

    .plan-card-action .btn-ghost {
        background: #f5f5f4;
        color: #57534e;
        border: 1px solid #e7e5e4;
    }

    .plan-card-action .btn-ghost:hover:not(:disabled) {
        background: #fff;
        border-color: #d6d3d1;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .plan-card-action .btn-secondary:disabled {
        background: #f0fdf4;
        color: #22c55e;
        border: 1px solid #bbf7d0;
        opacity: 1;
        cursor: default;
    }

    /* ==========================================
   MODERN PLAN CARDS - Landing Page Style
   ========================================== */

    .plans-grid-modern {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 24px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .plan-card-modern {
        background: #fff;
        border: 1px solid #e5e5e5;
        border-radius: 16px;
        padding: 32px;
        position: relative;
        transition: all 0.2s ease;
        display: flex;
        flex-direction: column;
        animation: slideUp 0.5s ease-out both;
    }

    .plan-card-modern:nth-child(1) {
        animation-delay: 0s;
    }

    .plan-card-modern:nth-child(2) {
        animation-delay: 0.1s;
    }

    .plan-card-modern:nth-child(3) {
        animation-delay: 0.15s;
    }

    .plan-card-modern:nth-child(4) {
        animation-delay: 0.2s;
    }

    .plan-card-modern:hover {
        transform: translateY(-4px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    }

    .plan-card-modern.current {
        border-color: var(--billing-primary);
        border-width: 2px;
    }

    .plan-card-modern.featured {
        border-color: var(--billing-primary);
        border-width: 2px;
        transform: scale(1.02);
        z-index: 1;
    }

    .plan-card-modern.featured:hover {
        transform: scale(1.02) translateY(-4px);
    }

    /* Plan Badge */
    .plan-badge {
        position: absolute;
        top: -12px;
        left: 50%;
        transform: translateX(-50%);
        padding: 6px 16px;
        border-radius: 100px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .plan-badge svg {
        width: 12px;
        height: 12px;
    }

    .plan-badge-current {
        background: var(--billing-primary);
        color: #fff;
    }

    .plan-badge-popular {
        background: linear-gradient(135deg, var(--billing-primary) 0%, var(--billing-primary-dark) 100%);
        color: #fff;
    }

    .plan-badge-promo {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: #fff;
    }

    /* Plan Header */
    .plan-card-modern .plan-header {
        margin-bottom: 24px;
    }

    .plan-card-modern .plan-name {
        font-size: 20px;
        font-weight: 700;
        color: #1c1917;
        margin: 0 0 8px 0;
    }

    .plan-card-modern .plan-description {
        font-size: 14px;
        color: #78716c;
        margin: 0;
        line-height: 1.5;
    }

    /* Plan Price Section */
    .plan-card-modern .plan-price-section {
        margin-bottom: 24px;
    }

    .plan-card-modern .plan-price {
        display: flex;
        align-items: baseline;
        gap: 2px;
        transition: all 0.3s ease;
    }

    .plan-card-modern .plan-price-original {
        font-size: 14px;
        color: #a8a29e;
        text-decoration: line-through;
        margin-bottom: 4px;
    }

    .plan-card-modern .price-currency {
        font-size: 24px;
        font-weight: 700;
        color: #1c1917;
    }

    .plan-card-modern .price-amount {
        font-size: 48px;
        font-weight: 800;
        color: #1c1917;
        line-height: 1;
    }

    .plan-card-modern .price-period {
        font-size: 16px;
        color: #78716c;
        margin-left: 4px;
    }

    .plan-card-modern .plan-price-free .price-amount {
        color: #22c55e;
    }

    .plan-card-modern .plan-price-period-text {
        margin-top: 8px;
    }

    .plan-card-modern .plan-price-period-text .period-label {
        font-size: 13px;
        color: #a8a29e;
    }

    .plan-card-modern .plan-savings {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        margin-top: 8px;
        padding: 4px 10px;
        background: #dcfce7;
        color: #166534;
        font-size: 12px;
        font-weight: 600;
        border-radius: 100px;
    }

    .plan-card-modern .plan-savings svg {
        width: 14px;
        height: 14px;
    }

    /* Plan Features Section */
    .plan-card-modern .plan-features-section {
        flex: 1;
        margin-bottom: 24px;
    }

    .plan-card-modern .plan-features-title {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #a8a29e;
        margin-bottom: 16px;
    }

    .plan-card-modern .plan-features-group {
        margin-bottom: 8px;
    }

    .plan-card-modern .plan-feature {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 0;
        font-size: 14px;
        color: #44403c;
        line-height: 1.4;
    }

    .plan-card-modern .plan-feature strong {
        font-weight: 600;
        color: #1c1917;
    }

    .plan-card-modern .feature-icon {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
    }

    .plan-card-modern .feature-icon-check {
        color: #22c55e;
    }

    .plan-card-modern .feature-icon-star {
        color: #f59e0b;
    }

    .plan-card-modern .plan-feature-disabled {
        color: #a8a29e;
        opacity: 0.6;
    }

    .plan-card-modern .plan-feature-disabled .feature-icon {
        color: #d6d3d1;
    }

    /* Plan Action Buttons */
    .plan-card-modern .plan-action {
        margin-top: auto;
    }

    .plan-card-modern .plan-btn {
        width: 100%;
        padding: 14px 24px;
        font-size: 15px;
        font-weight: 600;
        border-radius: 10px;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.2s ease;
        text-decoration: none;
    }

    .plan-card-modern .plan-btn svg {
        width: 18px;
        height: 18px;
    }

    .plan-card-modern .plan-btn-current {
        background: #f0fdf4;
        color: #22c55e;
        border: 1px solid #bbf7d0;
        cursor: default;
    }

    .plan-card-modern .plan-btn-upgrade {
        background: #f5f5f4;
        color: #1c1917;
        border: 1px solid #e5e5e5;
    }

    .plan-card-modern .plan-btn-upgrade:hover {
        background: #fff;
        border-color: var(--billing-primary);
        color: var(--billing-primary);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .plan-card-modern .plan-btn-featured {
        background: linear-gradient(135deg, var(--billing-primary) 0%, var(--billing-primary-dark) 100%);
        color: #fff;
        border: none;
    }

    .plan-card-modern .plan-btn-featured:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(13, 148, 136, 0.35);
    }

    .plan-card-modern .plan-btn-downgrade {
        background: transparent;
        color: #78716c;
        border: 1px solid #e5e5e5;
    }

    .plan-card-modern .plan-btn-downgrade:hover {
        background: #fef2f2;
        border-color: #fecaca;
        color: #dc2626;
    }

    /* Plans Guarantee Section */
    .plans-guarantee {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        margin-top: 40px;
        padding: 20px 24px;
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        border-radius: 12px;
        text-align: left;
    }

    .plans-guarantee svg {
        width: 32px;
        height: 32px;
        color: #22c55e;
        flex-shrink: 0;
    }

    .plans-guarantee strong {
        display: block;
        font-size: 15px;
        font-weight: 700;
        color: #166534;
        margin-bottom: 2px;
    }

    .plans-guarantee span {
        font-size: 13px;
        color: #15803d;
    }

    /* Responsive Modern Plan Cards */
    @media (max-width: 1200px) {
        .plans-grid-modern {
            grid-template-columns: repeat(2, 1fr);
            max-width: 800px;
        }

        .plan-card-modern.featured {
            transform: none;
        }

        .plan-card-modern.featured:hover {
            transform: translateY(-4px);
        }
    }

    @media (max-width: 768px) {
        .plans-grid-modern {
            grid-template-columns: 1fr;
            max-width: 420px;
        }

        .plan-card-modern.featured {
            order: -1;
        }

        .plan-card-modern {
            padding: 24px;
        }

        .plan-card-modern .price-amount {
            font-size: 40px;
        }

        .plans-guarantee {
            flex-direction: column;
            text-align: center;
        }
    }

    /* Responsive Plan Cards */
    @media (max-width: 768px) {
        .plans-grid {
            grid-template-columns: 1fr;
            gap: 20px;
        }

        .plan-card-amount .price-value {
            font-size: 48px;
        }

        .plan-card-header-section,
        .plan-card-price,
        .plan-card-features,
        .plan-card-action {
            padding-left: 24px;
            padding-right: 24px;
        }
    }

    padding: 20px;
    background: #fafaf9;
    border-radius: 16px;
    }

    .plan-card-amount {
        font-size: 48px;
        font-weight: 700;
        color: #1c1917;
        line-height: 1;
    }

    .plan-card-amount sup {
        font-size: 24px;
        vertical-align: super;
    }

    .plan-card-amount.free-price {
        color: #059669;
        font-size: 36px;
    }

    .plan-card-period {
        font-size: 14px;
        color: #78716c;
        margin-top: 4px;
    }

    .plan-card-features {
        margin-bottom: 28px;
        flex: 1;
    }

    .plan-feature {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 0;
        font-size: 14px;
        color: #44403c;
        border-bottom: 1px solid #f5f5f4;
    }

    .plan-feature:last-child {
        border-bottom: none;
    }

    .plan-feature svg {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
    }

    .plan-feature .check-icon {
        color: #22c55e;
    }

    .plan-feature .x-icon {
        color: #d6d3d1;
    }

    .plan-feature.disabled {
        color: #a8a29e;
    }

    .plan-card-action {
        margin-top: auto;
    }

    .plan-card-action .btn {
        width: 100%;
        justify-content: center;
        padding: 14px 24px;
        font-size: 15px;
    }

    /* Checkout Section */
    .checkout-section {
        max-width: 560px;
        margin: 0 auto;
        animation: slideUp 0.5s ease-out;
    }

    .checkout-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: #57534e;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 20px;
        transition: color 0.2s;
    }

    .checkout-back:hover {
        color: #1c1917;
    }

    .checkout-back svg {
        width: 18px;
        height: 18px;
    }

    .checkout-card {
        background: #fff;
        border: 1px solid #e7e5e4;
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.06);
    }

    .checkout-header {
        padding: 28px;
        background: linear-gradient(135deg, #1c1917 0%, #292524 100%);
        color: #fff;
        position: relative;
        overflow: hidden;
    }

    .checkout-header::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 50%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.05) 0%, transparent 70%);
    }

    .checkout-header h2 {
        font-size: 22px;
        font-weight: 700;
        margin: 0 0 8px;
        position: relative;
    }

    .checkout-header p {
        font-size: 14px;
        color: #a8a29e;
        margin: 0;
        position: relative;
    }

    .checkout-body {
        padding: 28px;
    }

    .checkout-summary {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        background: linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%);
        border-radius: 16px;
        margin-bottom: 28px;
    }

    .checkout-plan-info {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .checkout-plan-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #ede9fe 0%, #ddd6fe 100%);
        color: #7c3aed;
    }

    .checkout-plan-icon svg {
        width: 24px;
        height: 24px;
    }

    .checkout-plan-name {
        font-size: 17px;
        font-weight: 700;
        color: #1c1917;
    }

    .checkout-plan-desc {
        font-size: 13px;
        color: #78716c;
    }

    .checkout-plan-price {
        text-align: right;
    }

    .checkout-plan-amount {
        font-size: 28px;
        font-weight: 700;
        color: #1c1917;
    }

    .checkout-plan-period {
        font-size: 13px;
        color: #78716c;
    }

    .checkout-form-label {
        font-size: 14px;
        font-weight: 600;
        color: #1c1917;
        margin-bottom: 10px;
        display: block;
    }

    #card-element {
        padding: 16px;
        border: 2px solid #e7e5e4;
        border-radius: 12px;
        background: #fff;
        margin-bottom: 12px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    #card-element:focus-within {
        border-color: var(--billing-primary);
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }

    #card-errors {
        color: #dc2626;
        font-size: 13px;
        margin-bottom: 20px;
        min-height: 20px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    #card-errors:not(:empty)::before {
        content: '';
        width: 16px;
        height: 16px;
        background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23dc2626'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z'/%3E%3C/svg%3E") no-repeat center;
        flex-shrink: 0;
    }

    .checkout-secure {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 12px;
        background: #f0fdf4;
        border-radius: 10px;
        margin-bottom: 20px;
        font-size: 13px;
        color: #166534;
    }

    .checkout-secure svg {
        width: 16px;
        height: 16px;
        color: #22c55e;
    }

    .checkout-footer {
        padding: 20px 28px;
        background: #fafaf9;
        border-top: 1px solid #e7e5e4;
        display: flex;
        gap: 12px;
    }

    .checkout-footer .btn {
        flex: 1;
    }

    /* Invoices Table */
    .invoices-section {
        background: #fff;
        border: 1px solid #e7e5e4;
        border-radius: 20px;
        overflow: hidden;
        animation: slideUp 0.5s ease-out;
    }

    .invoices-table {
        width: 100%;
        border-collapse: collapse;
    }

    .invoices-table th {
        padding: 16px 24px;
        text-align: left;
        font-size: 11px;
        font-weight: 700;
        color: #57534e;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        background: #fafaf9;
        border-bottom: 1px solid #e7e5e4;
    }

    .invoices-table td {
        padding: 18px 24px;
        font-size: 14px;
        color: #44403c;
        border-bottom: 1px solid #f5f5f4;
    }

    .invoices-table tr:last-child td {
        border-bottom: none;
    }

    .invoices-table tr:hover td {
        background: #fafaf9;
    }

    .invoice-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 100px;
        font-size: 12px;
        font-weight: 600;
    }

    .invoice-status.paid {
        background: #f0fdf4;
        color: #166534;
    }

    .invoice-status.pending {
        background: #fef3c7;
        color: #92400e;
    }

    .invoice-status.failed {
        background: #fef2f2;
        color: #dc2626;
    }

    /* Invoice Section */
    .invoices-section-header {
        margin-bottom: 32px;
    }

    .invoices-section-title {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 24px;
        font-weight: 700;
        color: #1c1917;
        margin: 0 0 8px;
    }

    .invoices-section-title svg {
        width: 28px;
        height: 28px;
        color: var(--billing-primary);
    }

    .invoices-section-subtitle {
        font-size: 15px;
        color: #78716c;
        margin: 0;
    }

    /* Invoice Cards Grid */
    .invoices-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 20px;
    }

    .invoice-card {
        background: #fff;
        border: 1px solid #e7e5e4;
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.2s ease;
    }

    .invoice-card:hover {
        border-color: #d6d3d1;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
        transform: translateY(-2px);
    }

    .invoice-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        background: linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%);
        border-bottom: 1px solid #e7e5e4;
    }

    .invoice-card-number {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        font-weight: 600;
        color: #44403c;
    }

    .invoice-card-number svg {
        width: 18px;
        height: 18px;
        color: #78716c;
    }

    .invoice-status-badge {
        display: inline-flex;
        align-items: center;
        padding: 4px 12px;
        border-radius: 100px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .invoice-status-badge.paid {
        background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
        color: #166534;
    }

    .invoice-status-badge.pending {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        color: #92400e;
    }

    .invoice-status-badge.failed {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        color: #dc2626;
    }

    .invoice-status-badge.refunded {
        background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        color: #6b7280;
    }

    .invoice-card-body {
        padding: 20px;
    }

    .invoice-card-plan {
        font-size: 16px;
        font-weight: 600;
        color: #1c1917;
        margin-bottom: 8px;
    }

    .invoice-card-amount {
        font-size: 28px;
        font-weight: 700;
        color: var(--billing-primary);
        margin-bottom: 12px;
    }

    .invoice-card-date {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        color: #78716c;
    }

    .invoice-card-date svg {
        width: 16px;
        height: 16px;
    }

    .invoice-card-actions {
        display: flex;
        gap: 8px;
        padding: 16px 20px;
        background: #fafaf9;
        border-top: 1px solid #e7e5e4;
    }

    .invoice-action-btn {
        flex: 1;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s;
        background: #fff;
        color: #57534e;
        border: 1px solid #d6d3d1;
    }

    .invoice-action-btn:hover {
        background: #f5f5f4;
        border-color: #a8a29e;
    }

    .invoice-action-btn svg {
        width: 16px;
        height: 16px;
    }

    .invoice-action-btn.primary {
        background: var(--billing-primary);
        color: #fff;
        border-color: var(--billing-primary);
    }

    .invoice-action-btn.primary:hover {
        background: var(--billing-primary-dark);
        border-color: var(--billing-primary-dark);
    }

    /* Empty States */
    .empty-state {
        text-align: center;
        padding: 60px 24px;
    }

    .empty-state-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        background: #f5f5f4;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .empty-state-icon svg {
        width: 40px;
        height: 40px;
        color: #a8a29e;
    }

    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        color: #44403c;
        margin: 0 0 8px;
    }

    .empty-state p {
        font-size: 14px;
        color: #78716c;
        margin: 0;
    }

    /* Cancel Modal */
    .modal-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(4px);
        z-index: 1000;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }

    .modal-overlay.active {
        display: flex;
    }

    .modal-content {
        background: #fff;
        border-radius: 20px;
        width: 100%;
        max-width: 440px;
        padding: 28px;
        animation: slideUp 0.3s ease-out;
    }

    .modal-header {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-bottom: 20px;
    }

    .modal-icon {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .modal-icon.warning {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        color: #d97706;
    }

    .modal-icon.success {
        background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
        color: #16a34a;
    }

    .modal-icon.danger {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        color: #dc2626;
    }

    .modal-icon svg {
        width: 28px;
        height: 28px;
    }

    .modal-title {
        font-size: 20px;
        font-weight: 700;
        color: #1c1917;
        margin: 0;
    }

    .modal-body {
        margin-bottom: 28px;
    }

    .modal-body p {
        font-size: 14px;
        color: #57534e;
        margin: 0 0 14px;
        line-height: 1.6;
    }

    .modal-body ul {
        margin: 0;
        padding: 0 0 0 20px;
    }

    .modal-body li {
        font-size: 14px;
        color: #57534e;
        margin-bottom: 8px;
    }

    .modal-footer {
        display: flex;
        gap: 12px;
    }

    .modal-footer .btn {
        flex: 1;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .billing-header {
            flex-direction: column;
            align-items: stretch;
            gap: 16px;
        }

        .billing-tabs {
            justify-content: flex-start;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            padding-bottom: 4px;
            gap: 4px;
        }

        .billing-tabs::-webkit-scrollbar {
            display: none;
        }

        .billing-tab {
            white-space: nowrap;
            flex-shrink: 0;
            padding: 10px 16px;
            min-height: 44px;
        }

        .current-plan-header {
            flex-direction: column;
            gap: 16px;
        }

        .current-plan-price {
            text-align: left;
        }

        .plan-status {
            flex-direction: column;
            gap: 12px;
        }

        .plan-actions {
            margin-left: 0;
            width: 100%;
            flex-direction: column;
        }

        .plan-actions .btn {
            width: 100%;
            justify-content: center;
        }

        .plans-grid {
            grid-template-columns: 1fr;
            gap: 16px;
        }

        .plan-card.featured {
            transform: none;
        }

        .plan-card.featured:hover {
            transform: translateY(-4px);
        }

        .invoices-grid {
            grid-template-columns: 1fr;
        }

        .invoice-card-actions {
            flex-direction: column;
        }

        .invoice-action-btn {
            width: 100%;
            justify-content: center;
        }

        .checkout-card {
            margin: 0;
        }

        .checkout-summary {
            flex-direction: column;
            gap: 16px;
        }

        .checkout-plan-price {
            text-align: left;
        }

        .billing-alert {
            padding: 14px;
        }

        .billing-alert-content {
            flex: 1;
        }

        .current-plan-card {
            padding: 20px;
        }

        .plan-feature-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 375px) {
        .plan-card {
            padding: 20px;
        }

        .plan-card-header {
            padding: 16px;
        }

        .plan-card-body {
            padding: 16px;
        }

        .current-plan-card {
            padding: 16px;
        }

        .checkout-body {
            padding: 16px;
        }
    }
</style>

<?php
// Display success/error messages
if (isset($_GET['subscribed'])):
    $invoice_id = intval($_GET['invoice_id'] ?? 0);
    ?>
    <div class="billing-alert success">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div class="billing-alert-content">
            <div class="billing-alert-title"><?php _e('Subscription Activated!', 'rental-gates'); ?></div>
            <div class="billing-alert-message">
                <?php _e('Welcome to your new plan. Your features are now unlocked.', 'rental-gates'); ?>
                <?php if ($invoice_id): ?>
                    <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=rental_gates_view_subscription_invoice&id=' . $invoice_id)); ?>"
                        target="_blank" style="color: #166534; font-weight: 600; text-decoration: underline; margin-left: 8px;">
                        <?php _e('View Invoice →', 'rental-gates'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (isset($_GET['changed'])): ?>
    <div class="billing-alert success">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div class="billing-alert-content">
            <div class="billing-alert-title"><?php _e('Plan Changed', 'rental-gates'); ?></div>
            <div class="billing-alert-message"><?php _e('Your plan has been updated successfully.', 'rental-gates'); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (isset($_GET['cancelled'])): ?>
    <div class="billing-alert warning">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
        <div class="billing-alert-content">
            <div class="billing-alert-title"><?php _e('Subscription Scheduled to Cancel', 'rental-gates'); ?></div>
            <div class="billing-alert-message">
                <?php if ($cancel_date): ?>
                    <?php printf(__('Your subscription will end on %s. You can resume anytime before then.', 'rental-gates'), '<strong>' . esc_html($cancel_date) . '</strong>'); ?>
                <?php else: ?>
                    <?php _e('You will retain access to your current features until the end of your billing period.', 'rental-gates'); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (isset($_GET['resumed'])): ?>
    <div class="billing-alert success">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div class="billing-alert-content">
            <div class="billing-alert-title"><?php _e('Subscription Resumed!', 'rental-gates'); ?></div>
            <div class="billing-alert-message">
                <?php _e('Your subscription is active again and will continue as normal.', 'rental-gates'); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="billing-header">
    <h1 class="billing-title">
        <span class="billing-title-icon">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
        </span>
        <?php _e('Billing & Subscription', 'rental-gates'); ?>
    </h1>

    <div class="billing-tabs">
        <a href="<?php echo esc_url(add_query_arg('view', 'overview', home_url('/rental-gates/dashboard/billing'))); ?>"
            class="billing-tab <?php echo $view === 'overview' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
            <?php _e('Overview', 'rental-gates'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
            class="billing-tab <?php echo $view === 'plans' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
            <?php _e('Plans', 'rental-gates'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('view', 'invoices', home_url('/rental-gates/dashboard/billing'))); ?>"
            class="billing-tab <?php echo $view === 'invoices' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <?php _e('Invoices', 'rental-gates'); ?>
        </a>
    </div>
</div>

<?php if ($show_checkout):
    $checkout_plan = $plans[$selected_plan];
    $plan_icon_class = $selected_plan . '-icon';
    ?>
    <!-- Checkout View -->
    <div class="checkout-section">
        <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
            class="checkout-back">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            <?php _e('Back to plans', 'rental-gates'); ?>
        </a>

        <div class="checkout-card">
            <div class="checkout-header">
                <h2><?php _e('Complete Your Subscription', 'rental-gates'); ?></h2>
                <p><?php printf(__('Upgrading to %s plan', 'rental-gates'), esc_html($checkout_plan['name'])); ?></p>
            </div>

            <div class="checkout-body">
                <div class="checkout-summary">
                    <div class="checkout-plan-info">
                        <div class="checkout-plan-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                            </svg>
                        </div>
                        <div>
                            <div class="checkout-plan-name"><?php echo esc_html($checkout_plan['name']); ?> Plan</div>
                            <div class="checkout-plan-desc">
                                <?php echo $billing_cycle === 'yearly' ? __('Billed yearly', 'rental-gates') : __('Billed monthly', 'rental-gates'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="checkout-plan-price">
                        <?php if (empty($checkout_plan['is_free'])): ?>
                            <?php
                            $display_price = $billing_cycle === 'yearly'
                                ? ($checkout_plan['price_yearly'] ?? $checkout_plan['price_monthly'] * 12)
                                : $checkout_plan['price_monthly'];
                            $period_text = $billing_cycle === 'yearly' ? __('/year', 'rental-gates') : __('/month', 'rental-gates');
                            ?>
                            <div class="checkout-plan-amount">$<?php echo esc_html($display_price); ?></div>
                            <div class="checkout-plan-period"><?php echo $period_text; ?></div>
                        <?php else: ?>
                            <div class="checkout-plan-amount" style="color: #059669;">Free</div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($stripe_enabled && empty($checkout_plan['is_free'])): ?>
                    <form id="checkout-form">
                        <input type="hidden" name="plan_id" value="<?php echo esc_attr($selected_plan); ?>">

                        <label class="checkout-form-label">
                            <?php _e('Card Details', 'rental-gates'); ?>
                        </label>
                        <div id="card-element"></div>
                        <div id="card-errors" role="alert"></div>

                        <div class="checkout-secure">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                            </svg>
                            <?php _e('Your payment is secured with 256-bit SSL encryption', 'rental-gates'); ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg" id="submit-btn" style="width: 100%;">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                            <?php
                            $btn_price = $billing_cycle === 'yearly'
                                ? ($checkout_plan['price_yearly'] ?? $checkout_plan['price_monthly'] * 12)
                                : $checkout_plan['price_monthly'];
                            $btn_period = $billing_cycle === 'yearly' ? '/year' : '/month';
                            printf(__('Subscribe - $%s%s', 'rental-gates'), esc_html($btn_price), $btn_period);
                            ?>
                        </button>
                    </form>

                    <p
                        style="font-size: 12px; color: #78716c; text-align: center; margin-top: 20px; display: flex; align-items: center; justify-content: center; gap: 16px;">
                        <span style="display: flex; align-items: center; gap: 4px;">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-7v2h2v-2h-2zm0-8v6h2V7h-2z" />
                            </svg>
                            Cancel anytime
                        </span>
                        <span style="display: flex; align-items: center; gap: 4px;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path
                                    d="M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 2.227 0 4.515.858 6.09 1.631l.89-5.494C18.252.975 15.697 0 12.165 0 9.667 0 7.589.654 6.104 1.872 4.56 3.147 3.757 4.992 3.757 7.218c0 4.039 2.467 5.76 6.476 7.219 2.585.92 3.445 1.574 3.445 2.583 0 .98-.84 1.545-2.354 1.545-1.875 0-4.965-.921-6.99-2.109l-.9 5.555C5.175 22.99 8.385 24 11.714 24c2.641 0 4.843-.624 6.328-1.813 1.664-1.305 2.525-3.236 2.525-5.732 0-4.128-2.524-5.851-6.594-7.305h.003z" />
                            </svg>
                            Powered by Stripe
                        </span>
                    </p>

                <?php elseif (empty($checkout_plan['is_free'])): ?>
                    <div class="billing-alert warning">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <div class="billing-alert-content">
                            <div class="billing-alert-title"><?php _e('Payment Not Configured', 'rental-gates'); ?></div>
                            <div class="billing-alert-message">
                                <?php _e('Payment processing is not configured. Please contact support.', 'rental-gates'); ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <form id="free-plan-form">
                        <input type="hidden" name="plan_id" value="<?php echo esc_attr($selected_plan); ?>">
                        <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                            <?php _e('Switch to Free Plan', 'rental-gates'); ?>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php elseif ($view === 'plans'): ?>
    <!-- Plans View - Redesigned to Match Landing Page -->
    <div class="plans-section">
        <div class="plans-section-header">
            <h2 class="plans-section-title"><?php _e('Choose Your Plan', 'rental-gates'); ?></h2>
            <p class="plans-section-subtitle">
                <?php _e('Simple, transparent pricing. Start free, scale as you grow.', 'rental-gates'); ?>
            </p>

            <!-- Billing Period Toggle -->
            <div class="billing-toggle-wrapper">
                <span class="billing-toggle-label active"
                    data-period="monthly"><?php _e('Monthly', 'rental-gates'); ?></span>
                <div class="billing-toggle" id="billing-period-toggle"></div>
                <span class="billing-toggle-label" data-period="yearly"><?php _e('Yearly', 'rental-gates'); ?></span>
                <span class="billing-save-badge">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <?php _e('Save 20%', 'rental-gates'); ?>
                </span>
            </div>
        </div>

        <?php if (empty($plans)): ?>
            <div class="empty-state" style="background: #fff; border: 1px solid #e7e5e4; border-radius: 20px;">
                <div class="empty-state-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                </div>
                <h3><?php _e('No Plans Configured', 'rental-gates'); ?></h3>
                <p><?php _e('Plans have not been configured yet. Please contact support.', 'rental-gates'); ?></p>
            </div>
        <?php else: ?>
            <div class="plans-grid-modern">
                <?php
                // Get pricing helper for discounts
                $pricing_helper = function_exists('rental_gates_pricing') ? rental_gates_pricing() : null;
                $has_active_discount = $pricing_helper && $pricing_helper->is_discount_active();

                // Feature display configuration - organized by category
                $feature_categories = array(
                    'limits' => array(
                        'buildings' => array('label' => __('Buildings', 'rental-gates'), 'icon' => 'building'),
                        'units' => array('label' => __('Units', 'rental-gates'), 'icon' => 'unit'),
                        'staff' => array('label' => __('Staff members', 'rental-gates'), 'icon' => 'staff'),
                        'vendors' => array('label' => __('Vendors', 'rental-gates'), 'icon' => 'vendor'),
                        'tenants' => array('label' => __('Tenants', 'rental-gates'), 'icon' => 'tenant'),
                        'storage_gb' => array('label' => __('Storage', 'rental-gates'), 'icon' => 'storage'),
                    ),
                    'modules' => array(
                        'tenant_portal' => array('label' => __('Tenant portal', 'rental-gates'), 'icon' => 'portal'),
                        'online_payments' => array('label' => __('Online payments', 'rental-gates'), 'icon' => 'payment'),
                        'maintenance' => array('label' => __('Maintenance tracking', 'rental-gates'), 'icon' => 'maintenance'),
                        'lease_management' => array('label' => __('Lease management', 'rental-gates'), 'icon' => 'lease'),
                        'ai_screening' => array('label' => __('AI-powered tools', 'rental-gates'), 'icon' => 'ai'),
                        'marketing_qr' => array('label' => __('Marketing & QR codes', 'rental-gates'), 'icon' => 'qr'),
                        'vendor_management' => array('label' => __('Vendor management', 'rental-gates'), 'icon' => 'vendor'),
                        'chat_messaging' => array('label' => __('Chat & messaging', 'rental-gates'), 'icon' => 'chat'),
                        'advanced_reports' => array('label' => __('Advanced reports', 'rental-gates'), 'icon' => 'report'),
                        'bulk_operations' => array('label' => __('Bulk operations', 'rental-gates'), 'icon' => 'bulk'),
                        'api_access' => array('label' => __('API access', 'rental-gates'), 'icon' => 'api'),
                        'white_label' => array('label' => __('White label', 'rental-gates'), 'icon' => 'label'),
                    ),
                );

                foreach ($plans as $plan_id => $plan):
                    $is_current = ($current_plan['id'] ?? 'free') === $plan_id;

                    // Skip hidden/inactive plans (but show if it's the current plan)
                    if (!$is_current && !Rental_Gates_Pricing::is_plan_visible($plan))
                        continue;

                    $is_featured = !empty($plan['is_featured']);

                    // Use unified pricing helper for consistent calculations
                    $plan['id'] = $plan_id;

                    if ($pricing_helper) {
                        $pricing = $pricing_helper->get_plan_pricing($plan);
                    } else {
                        // Fallback if pricing helper not available
                        $monthly = floatval($plan['price_monthly'] ?? 0);
                        $yearly = floatval($plan['price_yearly'] ?? 0);

                        // Default yearly to 80% of monthly * 12 if not set
                        if ($yearly <= 0 && $monthly > 0) {
                            $yearly = round($monthly * 12 * 0.8, 0);
                        }

                        $yearly_monthly = $yearly > 0 ? round($yearly / 12, 0) : 0;
                        $savings_pct = ($monthly > 0 && $yearly > 0)
                            ? round((1 - ($yearly / ($monthly * 12))) * 100)
                            : 0;

                        $pricing = array(
                            'is_free' => !empty($plan['is_free']) || empty($plan['price_monthly']),
                            'monthly_original' => $monthly,
                            'monthly_discounted' => $monthly,
                            'monthly_has_discount' => false,
                            'yearly_monthly_original' => $yearly_monthly,
                            'yearly_monthly_discounted' => $yearly_monthly,
                            'yearly_plan_savings_pct' => $savings_pct,
                        );
                    }

                    $is_free = $pricing['is_free'];
                    $price_monthly = intval($pricing['monthly_original']);
                    $monthly_discounted = intval($pricing['monthly_discounted']);
                    $yearly_monthly_discounted = intval($pricing['yearly_monthly_discounted']);
                    $yearly_savings_pct = intval($pricing['yearly_plan_savings_pct']);
                    $has_promo_discount = !empty($pricing['monthly_has_discount']);

                    // Determine plan style
                    $plan_class = '';
                    if ($is_current)
                        $plan_class = 'current';
                    elseif ($is_featured)
                        $plan_class = 'featured';

                    // Plan color scheme
                    $plan_colors = array(
                        'free' => array('bg' => '#f5f5f4', 'text' => '#57534e', 'accent' => '#78716c'),
                        'basic' => array('bg' => 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)', 'text' => '#fff', 'accent' => '#3b82f6'),
                        'starter' => array('bg' => 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)', 'text' => '#fff', 'accent' => '#3b82f6'),
                        'silver' => array('bg' => 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)', 'text' => '#fff', 'accent' => '#8b5cf6'),
                        'professional' => array('bg' => 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)', 'text' => '#fff', 'accent' => '#8b5cf6'),
                        'gold' => array('bg' => 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', 'text' => '#fff', 'accent' => '#f59e0b'),
                        'enterprise' => array('bg' => 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', 'text' => '#fff', 'accent' => '#f59e0b'),
                    );
                    $colors = $plan_colors[$plan_id] ?? $plan_colors['basic'];
                    ?>
                    <div class="plan-card-modern <?php echo esc_attr($plan_class); ?>"
                        data-plan="<?php echo esc_attr($plan_id); ?>">
                        <?php if ($is_current): ?>
                            <div class="plan-badge plan-badge-current">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                <?php _e('Current Plan', 'rental-gates'); ?>
                            </div>
                        <?php elseif ($is_featured): ?>
                            <div class="plan-badge plan-badge-popular">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                                </svg>
                                <?php _e('Most Popular', 'rental-gates'); ?>
                            </div>
                        <?php elseif ($has_promo_discount && $has_active_discount):
                            $discount_settings = $pricing_helper->get_discount_settings();
                            if (!empty($discount_settings['badge_text'])): ?>
                                <div class="plan-badge plan-badge-promo">
                                    <?php echo esc_html($discount_settings['badge_text']); ?>
                                </div>
                            <?php endif; endif; ?>

                        <!-- Plan Header -->
                        <div class="plan-header">
                            <h3 class="plan-name"><?php echo esc_html($plan['name']); ?></h3>
                            <p class="plan-description"><?php echo esc_html($plan['description'] ?? ''); ?></p>
                        </div>

                        <!-- Price Section -->
                        <div class="plan-price-section">
                            <?php if ($is_free): ?>
                                <div class="plan-price plan-price-free">
                                    <span class="price-amount">$0</span>
                                    <span class="price-period"><?php _e('forever', 'rental-gates'); ?></span>
                                </div>
                            <?php else: ?>
                                <?php if ($has_promo_discount): ?>
                                    <div class="plan-price-original">$<?php echo intval($price_monthly); ?>/mo</div>
                                <?php endif; ?>
                                <div class="plan-price" data-monthly="<?php echo intval($monthly_discounted); ?>"
                                    data-yearly="<?php echo intval($yearly_monthly_discounted); ?>">
                                    <span class="price-currency">$</span>
                                    <span class="price-amount"><?php echo intval($monthly_discounted); ?></span>
                                    <span class="price-period">/mo</span>
                                </div>
                                <div class="plan-price-period-text">
                                    <span class="period-label"><?php _e('Billed monthly', 'rental-gates'); ?></span>
                                </div>
                                <?php if ($yearly_savings_pct > 0): ?>
                                    <div class="plan-savings yearly-only" style="display: none;">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        <?php printf(__('Save %d%% yearly', 'rental-gates'), $yearly_savings_pct); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <!-- Features Section -->
                        <div class="plan-features-section">
                            <div class="plan-features-title"><?php _e("What's included", 'rental-gates'); ?></div>

                            <!-- Resource Limits - Buildings first, then Units -->
                            <div class="plan-features-group">
                                <?php
                                // Define order: buildings first, then units, then others
                                $limits_order = array('buildings', 'units', 'staff', 'vendors', 'tenants', 'storage_gb');
                                foreach ($limits_order as $limit_key):
                                    if (!isset($feature_categories['limits'][$limit_key]))
                                        continue;
                                    $limit_config = $feature_categories['limits'][$limit_key];
                                    $value = $plan['limits'][$limit_key] ?? 0;
                                    if ($value == 0)
                                        continue;

                                    // Format the value
                                    if ($value == -1) {
                                        $display_value = '<strong>' . __('Unlimited', 'rental-gates') . '</strong> ' . strtolower($limit_config['label']);
                                    } elseif ($limit_key === 'storage_gb') {
                                        $display_value = '<strong>' . $value . ' GB</strong> ' . strtolower($limit_config['label']);
                                    } else {
                                        $display_value = __('Up to', 'rental-gates') . ' <strong>' . $value . '</strong> ' . strtolower($limit_config['label']);
                                    }
                                    ?>
                                    <div class="plan-feature">
                                        <svg class="feature-icon feature-icon-check" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        <span><?php echo $display_value; ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Module Features -->
                            <div class="plan-features-group">
                                <?php
                                foreach ($feature_categories['modules'] as $mod_key => $mod_config):
                                    $enabled = !empty($plan['modules'][$mod_key]);
                                    // Skip showing disabled features for cleaner display
                                    if (!$enabled)
                                        continue;
                                    ?>
                                    <div class="plan-feature">
                                        <svg class="feature-icon feature-icon-check" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        <span><?php echo esc_html($mod_config['label']); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Custom Features -->
                            <?php if (!empty($plan['custom_features'])): ?>
                                <div class="plan-features-group">
                                    <?php foreach ($plan['custom_features'] as $feature): ?>
                                        <div class="plan-feature plan-feature-custom">
                                            <svg class="feature-icon feature-icon-star" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                                            </svg>
                                            <span><?php echo esc_html($feature); ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Action Button -->
                        <div class="plan-action">
                            <?php if ($is_current): ?>
                                <button class="plan-btn plan-btn-current" disabled>
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                    </svg>
                                    <?php _e('Current Plan', 'rental-gates'); ?>
                                </button>
                            <?php elseif ($is_free): ?>
                                <button type="button" class="plan-btn plan-btn-downgrade"
                                    onclick="showDowngradeModal('<?php echo esc_attr($plan_id); ?>', '<?php echo esc_attr($plan['name']); ?>', true)">
                                    <?php _e('Downgrade to Free', 'rental-gates'); ?>
                                </button>
                            <?php elseif ($subscription && !empty($subscription['stripe_subscription_id']) && ($plan['price_monthly'] ?? 0) < ($current_plan['price_monthly'] ?? 0)): ?>
                                <button type="button" class="plan-btn plan-btn-downgrade"
                                    onclick="showDowngradeModal('<?php echo esc_attr($plan_id); ?>', '<?php echo esc_attr($plan['name']); ?>', false)">
                                    <?php _e('Downgrade', 'rental-gates'); ?>
                                </button>
                            <?php else: ?>
                                <a href="<?php echo esc_url(add_query_arg(array('plan' => $plan_id, 'billing_cycle' => 'monthly'), home_url('/rental-gates/dashboard/billing'))); ?>"
                                    class="plan-btn plan-btn-upgrade <?php echo $is_featured ? 'plan-btn-featured' : ''; ?>">
                                    <?php echo esc_html($plan['cta_text'] ?? __('Get Started', 'rental-gates')); ?>
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                    </svg>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Money Back Guarantee -->
            <div class="plans-guarantee">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                <div>
                    <strong><?php _e('30-day money-back guarantee', 'rental-gates'); ?></strong>
                    <span><?php _e('Not satisfied? Get a full refund within 30 days, no questions asked.', 'rental-gates'); ?></span>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php elseif ($view === 'invoices'): ?>
    <!-- Invoices View -->
    <div class="invoices-section">
        <div class="invoices-section-header">
            <h2 class="invoices-section-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <?php _e('Invoice History', 'rental-gates'); ?>
            </h2>
            <p class="invoices-section-subtitle">
                <?php _e('View and download your subscription invoices', 'rental-gates'); ?>
            </p>
        </div>

        <?php if (empty($invoices)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <h3><?php _e('No Invoices Yet', 'rental-gates'); ?></h3>
                <p><?php _e('Your invoice history will appear here once you subscribe to a paid plan.', 'rental-gates'); ?></p>
            </div>
        <?php else: ?>
            <div class="invoices-grid">
                <?php foreach ($invoices as $invoice):
                    $invoice_items = json_decode($invoice['items'] ?? '[]', true) ?: array();
                    $invoice_meta = json_decode($invoice['meta_data'] ?? '{}', true) ?: array();
                    $plan_name = $invoice_meta['plan']['name'] ?? 'Subscription';
                    ?>
                    <div class="invoice-card">
                        <div class="invoice-card-header">
                            <div class="invoice-card-number">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                </svg>
                                <span>#<?php echo esc_html($invoice['invoice_number']); ?></span>
                            </div>
                            <span class="invoice-status-badge <?php echo esc_attr($invoice['status'] ?? 'pending'); ?>">
                                <?php echo esc_html(ucfirst($invoice['status'] ?? 'pending')); ?>
                            </span>
                        </div>

                        <div class="invoice-card-body">
                            <div class="invoice-card-plan"><?php echo esc_html($plan_name); ?></div>
                            <div class="invoice-card-amount">
                                $<?php echo esc_html(number_format($invoice['total'] ?? $invoice['amount'] ?? 0, 2)); ?></div>
                            <div class="invoice-card-date">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <?php echo esc_html(date_i18n('M j, Y', strtotime($invoice['created_at']))); ?>
                            </div>
                        </div>

                        <div class="invoice-card-actions">
                            <a href="<?php echo esc_url(home_url('/rental-gates/invoice/' . $invoice['id'])); ?>"
                                class="invoice-action-btn" target="_blank">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                                <?php _e('View', 'rental-gates'); ?>
                            </a>
                            <?php
                            // Keep download link as legacy for now, or update if we implement download handler in public class
                            // For now, let's keep it but perhaps we can route it through the public URL with ?download=1 later
                            ?>
                            <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=rental_gates_download_subscription_invoice&id=' . $invoice['id'] . '&format=pdf&nonce=' . wp_create_nonce('download_subscription_invoice'))); ?>"
                                class="invoice-action-btn primary">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                </svg>
                                <?php _e('Download', 'rental-gates'); ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<?php elseif ($view === 'payment'): ?>
    <!-- Payment Methods Management View -->
    <?php
    // Get current user and organization
    $current_user_id = get_current_user_id();
    $org_id = rg_feature_gate()->get_user_org_id();
    
    // Get Stripe customer ID
    $customer_id = Rental_Gates_Billing::get_or_create_customer($org_id);
    if (is_wp_error($customer_id)) {
        $customer_id = null;
    }
    
    // Get saved payment methods from database
    $saved_methods = array();
    if ($current_user_id && class_exists('Rental_Gates_Stripe')) {
        $saved_methods = Rental_Gates_Stripe::get_user_payment_methods($current_user_id);
        
        // Also sync from Stripe to ensure we have the latest
        if ($customer_id && !is_wp_error($customer_id)) {
            $stripe_methods = Rental_Gates_Stripe::list_payment_methods($customer_id, 'card');
            if (!is_wp_error($stripe_methods) && isset($stripe_methods['data'])) {
                // Sync Stripe payment methods to local database
                foreach ($stripe_methods['data'] as $stripe_pm) {
                    // Check if already exists in local DB
                    global $wpdb;
                    $tables = Rental_Gates_Database::get_table_names();
                    $existing = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$tables['payment_methods']} WHERE stripe_payment_method_id = %s AND user_id = %d",
                        $stripe_pm['id'],
                        $current_user_id
                    ));
                    
                    if (!$existing) {
                        // Save new payment method from Stripe
                        Rental_Gates_Stripe::save_payment_method($current_user_id, $stripe_pm);
                    } else {
                        // Update existing payment method with latest info from Stripe
                        $update_data = array();
                        if ($stripe_pm['type'] === 'card' && isset($stripe_pm['card'])) {
                            $card = $stripe_pm['card'];
                            $update_data['card_brand'] = $card['brand'];
                            $update_data['card_last4'] = $card['last4'];
                            $update_data['card_exp_month'] = $card['exp_month'];
                            $update_data['card_exp_year'] = $card['exp_year'];
                        }
                        if (!empty($update_data)) {
                            $update_data['updated_at'] = current_time('mysql');
                            $wpdb->update(
                                $tables['payment_methods'],
                                $update_data,
                                array('id' => $existing),
                                array('%s', '%s', '%d', '%d', '%s'),
                                array('%d')
                            );
                        }
                    }
                }
                // Refresh saved methods
                $saved_methods = Rental_Gates_Stripe::get_user_payment_methods($current_user_id);
            }
        }
    }
    
    // Get current subscription to show which payment method is being used
    $subscription = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}rg_subscriptions 
         WHERE organization_id = %d 
         AND (status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete', 'incomplete_expired', 'pending_payment') 
              OR status IS NULL 
              OR status = ''
              OR cancel_at_period_end = 1
              OR (status = 'cancelled' AND current_period_end > %s))
         ORDER BY created_at DESC LIMIT 1",
        $org_id,
        current_time('mysql')
    ), ARRAY_A);
    
    $subscription_pm_id = null;
    if ($subscription && !empty($subscription['stripe_subscription_id']) && $customer_id) {
        // Get subscription from Stripe to see default payment method
        $stripe_sub = Rental_Gates_Stripe::api_request(
            "subscriptions/{$subscription['stripe_subscription_id']}",
            'GET'
        );
        if (!is_wp_error($stripe_sub) && !empty($stripe_sub['default_payment_method'])) {
            $subscription_pm_id = $stripe_sub['default_payment_method'];
        } elseif (!is_wp_error($stripe_sub) && !empty($stripe_sub['default_source'])) {
            // Legacy support for sources
            $subscription_pm_id = $stripe_sub['default_source'];
        }
    }
    ?>
    <div class="payment-methods-section">
        <div class="payment-methods-header">
            <div>
                <h2 class="payment-methods-title">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                    <?php _e('Payment Methods', 'rental-gates'); ?>
                </h2>
                <p class="payment-methods-subtitle">
                    <?php _e('Manage your saved payment methods and billing information', 'rental-gates'); ?>
                </p>
            </div>
            <a href="<?php echo esc_url(add_query_arg('view', 'overview', home_url('/rental-gates/dashboard/billing'))); ?>"
                class="btn btn-secondary">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                <?php _e('Back to Billing', 'rental-gates'); ?>
            </a>
        </div>

        <!-- Saved Payment Methods -->
        <div class="payment-methods-list">
            <h3 class="section-subtitle"><?php _e('Saved Payment Methods', 'rental-gates'); ?></h3>
            
            <?php if (empty($saved_methods)): ?>
                <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="48" height="48" style="opacity: 0.3;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                    <p><?php _e('No payment methods saved yet', 'rental-gates'); ?></p>
                </div>
            <?php else: ?>
                <div class="payment-methods-grid">
                    <?php foreach ($saved_methods as $method): ?>
                        <?php
                        $is_default = !empty($method['is_default']);
                        $is_subscription_pm = ($method['stripe_payment_method_id'] === $subscription_pm_id);
                        $card_brand = $method['card_brand'] ?? 'card';
                        $card_last4 = $method['card_last4'] ?? '****';
                        $card_exp = '';
                        if (!empty($method['card_exp_month']) && !empty($method['card_exp_year'])) {
                            $card_exp = sprintf('%02d/%d', $method['card_exp_month'], $method['card_exp_year']);
                        }
                        ?>
                        <div class="payment-method-card <?php echo $is_default ? 'default' : ''; ?>">
                            <div class="payment-method-header">
                                <div class="payment-method-brand">
                                    <?php if ($card_brand === 'visa'): ?>
                                        <svg width="40" height="24" viewBox="0 0 40 24">
                                            <rect width="40" height="24" rx="4" fill="#1A1F71"/>
                                            <path d="M16.5 8.5h-3l-1.9 7h3l1.9-7zm8.5 4.5c0-1.5-2-2.5-2-3.5 0-.5.5-1 1.5-1 .5 0 1 .2 1.5.5l.5-2.5c-.5-.2-1.2-.5-2-.5-2 0-3.5 1-3.5 2.5 0 2 2.5 2.5 2.5 3.5 0 .5-.5 1-1.5 1-.8 0-1.5-.3-2-.8l-.5 2.5c.5.3 1.2.5 2 .5 2.2 0 3.8-1 3.8-2.7zm7.5 2.5h-2.5l2-7h2.5l-2 7z" fill="#fff"/>
                                        </svg>
                                    <?php elseif ($card_brand === 'mastercard'): ?>
                                        <svg width="40" height="24" viewBox="0 0 40 24">
                                            <rect width="40" height="24" rx="4" fill="#EB001B"/>
                                            <circle cx="15" cy="12" r="6" fill="#F79E1B"/>
                                            <circle cx="25" cy="12" r="6" fill="#FF5F00"/>
                                        </svg>
                                    <?php elseif ($card_brand === 'amex'): ?>
                                        <svg width="40" height="24" viewBox="0 0 40 24">
                                            <rect width="40" height="24" rx="4" fill="#006FCF"/>
                                            <text x="20" y="16" text-anchor="middle" fill="#fff" font-size="10" font-weight="bold">AMEX</text>
                                        </svg>
                                    <?php else: ?>
                                        <div class="generic-card-icon">
                                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                                            </svg>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="payment-method-badges">
                                    <?php if ($is_default): ?>
                                        <span class="badge badge-default"><?php _e('Default', 'rental-gates'); ?></span>
                                    <?php endif; ?>
                                    <?php if ($is_subscription_pm): ?>
                                        <span class="badge badge-active"><?php _e('Active', 'rental-gates'); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="payment-method-details">
                                <div class="payment-method-number">
                                    <?php echo esc_html(ucfirst($card_brand)); ?> •••• <?php echo esc_html($card_last4); ?>
                                </div>
                                <?php if ($card_exp): ?>
                                    <div class="payment-method-expiry">
                                        <?php _e('Expires', 'rental-gates'); ?>: <?php echo esc_html($card_exp); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="payment-method-actions">
                                <?php if (!$is_default): ?>
                                    <button type="button" class="btn btn-sm btn-secondary set-default-pm" 
                                        data-method-id="<?php echo esc_attr($method['id']); ?>">
                                        <?php _e('Set as Default', 'rental-gates'); ?>
                                    </button>
                                <?php endif; ?>
                                <?php if ($has_paid_subscription && !$is_subscription_pm): ?>
                                    <button type="button" class="btn btn-sm btn-primary update-subscription-pm" 
                                        data-method-id="<?php echo esc_attr($method['id']); ?>"
                                        data-stripe-pm-id="<?php echo esc_attr($method['stripe_payment_method_id']); ?>">
                                        <?php _e('Use for Subscription', 'rental-gates'); ?>
                                    </button>
                                <?php endif; ?>
                                <button type="button" class="btn btn-sm btn-danger delete-pm" 
                                    data-method-id="<?php echo esc_attr($method['id']); ?>"
                                    data-last4="<?php echo esc_attr($card_last4); ?>">
                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="14" height="14">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                    <?php _e('Delete', 'rental-gates'); ?>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Add New Payment Method -->
        <div class="add-payment-method-section">
            <h3 class="section-subtitle"><?php _e('Add New Payment Method', 'rental-gates'); ?></h3>
            <div class="add-payment-method-card">
                <?php if ($stripe_enabled): ?>
                    <div id="card-element-container">
                        <div id="card-element"></div>
                        <div id="card-errors" role="alert"></div>
                    </div>
                    <button type="button" id="add-payment-method-btn" class="btn btn-primary">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="18" height="18">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                        </svg>
                        <?php _e('Add Payment Method', 'rental-gates'); ?>
                    </button>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <?php _e('Payment processing is not configured. Please contact support.', 'rental-gates'); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        /* Payment Methods Section Styles */
        .payment-methods-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 32px 20px;
        }

        .payment-methods-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .payment-methods-title {
            font-size: 32px;
            font-weight: 700;
            color: #1c1917;
            margin: 0 0 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .payment-methods-subtitle {
            font-size: 16px;
            color: #78716c;
            margin: 0;
        }

        .section-subtitle {
            font-size: 20px;
            font-weight: 600;
            color: #1c1917;
            margin: 0 0 20px;
        }

        .payment-methods-list {
            margin-bottom: 48px;
        }

        .payment-methods-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 20px;
        }

        .payment-method-card {
            background: #fff;
            border: 2px solid #e7e5e4;
            border-radius: 16px;
            padding: 24px;
            transition: all 0.3s ease;
        }

        .payment-method-card:hover {
            border-color: #0d9488;
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.1);
        }

        .payment-method-card.default {
            border-color: #0d9488;
            background: linear-gradient(135deg, #f0fdfa 0%, #ffffff 100%);
        }

        .payment-method-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .payment-method-brand {
            display: flex;
            align-items: center;
        }

        .generic-card-icon {
            width: 40px;
            height: 24px;
            background: #e7e5e4;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #78716c;
        }

        .payment-method-badges {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .badge {
            padding: 4px 10px;
            border-radius: 100px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-default {
            background: #0d9488;
            color: #fff;
        }

        .badge-active {
            background: #22c55e;
            color: #fff;
        }

        .payment-method-details {
            margin-bottom: 20px;
        }

        .payment-method-number {
            font-size: 18px;
            font-weight: 600;
            color: #1c1917;
            margin-bottom: 8px;
        }

        .payment-method-expiry {
            font-size: 14px;
            color: #78716c;
        }

        .payment-method-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .add-payment-method-section {
            margin-top: 48px;
        }

        .add-payment-method-card {
            background: #fff;
            border: 2px dashed #d6d3d1;
            border-radius: 16px;
            padding: 32px;
            text-align: center;
        }

        #card-element-container {
            margin-bottom: 20px;
        }

        #card-element {
            padding: 16px;
            border: 1px solid #d6d3d1;
            border-radius: 8px;
            background: #fff;
        }

        #card-errors {
            color: #ef4444;
            font-size: 14px;
            margin-top: 8px;
            min-height: 20px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #78716c;
        }

        .empty-state svg {
            margin-bottom: 16px;
        }

        .empty-state p {
            font-size: 16px;
            margin: 0;
        }

        @media (max-width: 768px) {
            .payment-methods-grid {
                grid-template-columns: 1fr;
            }

            .payment-methods-header {
                flex-direction: column;
            }
        }
    </style>

    <?php if ($stripe_enabled): ?>
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        (function() {
            var stripe = Stripe('<?php echo esc_js($stripe_pk); ?>');
            var elements = stripe.elements();
            var cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#1c1917',
                        '::placeholder': { color: '#a8a29e' }
                    }
                }
            });
            cardElement.mount('#card-element');

            cardElement.on('change', function(event) {
                var displayError = document.getElementById('card-errors');
                displayError.textContent = event.error ? event.error.message : '';
            });

            // Add payment method
            document.getElementById('add-payment-method-btn').addEventListener('click', async function() {
                var btn = this;
                btn.disabled = true;
                btn.innerHTML = '<svg class="animate-spin" width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> Processing...';

                try {
                    // Create setup intent
                    var setupIntentResponse = await fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'rental_gates_stripe_setup_intent',
                            nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>'
                        })
                    });
                    var setupIntentData = await setupIntentResponse.json();

                    if (!setupIntentData.success) {
                        throw new Error(setupIntentData.data.message || 'Failed to create setup intent');
                    }

                    // Confirm setup intent
                    var { error: confirmError, setupIntent } = await stripe.confirmCardSetup(
                        setupIntentData.data.client_secret,
                        { payment_method: { card: cardElement } }
                    );

                    if (confirmError) {
                        document.getElementById('card-errors').textContent = confirmError.message;
                        btn.disabled = false;
                        btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="18" height="18"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> <?php _e('Add Payment Method', 'rental-gates'); ?>';
                        return;
                    }

                    // Save payment method
                    var saveResponse = await fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'rental_gates_stripe_save_payment_method',
                            nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                            payment_method_id: setupIntent.payment_method
                        })
                    });
                    var saveData = await saveResponse.json();

                    if (saveData.success) {
                        showToast('<?php _e('Payment method added successfully!', 'rental-gates'); ?>', 'success');
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    } else {
                        throw new Error(saveData.data.message || 'Failed to save payment method');
                    }
                } catch (error) {
                    document.getElementById('card-errors').textContent = error.message;
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="18" height="18"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg> <?php _e('Add Payment Method', 'rental-gates'); ?>';
                }
            });

            // Set default payment method
            document.querySelectorAll('.set-default-pm').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var methodId = this.dataset.methodId;
                    var btn = this;
                    btn.disabled = true;

                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'rental_gates_stripe_set_default_method',
                            nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                            method_id: methodId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('<?php _e('Default payment method updated', 'rental-gates'); ?>', 'success');
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            showToast(data.data.message || '<?php _e('Failed to update default payment method', 'rental-gates'); ?>', 'error');
                            btn.disabled = false;
                        }
                    })
                    .catch(error => {
                        showToast('<?php _e('An error occurred', 'rental-gates'); ?>', 'error');
                        btn.disabled = false;
                    });
                });
            });

            // Update subscription payment method
            document.querySelectorAll('.update-subscription-pm').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var methodId = this.dataset.methodId;
                    var stripePmId = this.dataset.stripePmId;
                    var btn = this;
                    btn.disabled = true;
                    btn.innerHTML = '<svg class="animate-spin" width="14" height="14" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> Updating...';

                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'rental_gates_update_subscription_payment_method',
                            nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                            payment_method_id: stripePmId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('<?php _e('Subscription payment method updated successfully!', 'rental-gates'); ?>', 'success');
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            showToast(data.data.message || '<?php _e('Failed to update subscription payment method', 'rental-gates'); ?>', 'error');
                            btn.disabled = false;
                            btn.innerHTML = '<?php _e('Use for Subscription', 'rental-gates'); ?>';
                        }
                    })
                    .catch(error => {
                        showToast('<?php _e('An error occurred', 'rental-gates'); ?>', 'error');
                        btn.disabled = false;
                        btn.innerHTML = '<?php _e('Use for Subscription', 'rental-gates'); ?>';
                    });
                });
            });

            // Delete payment method
            document.querySelectorAll('.delete-pm').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var methodId = this.dataset.methodId;
                    var last4 = this.dataset.last4;
                    
                    if (!confirm('<?php _e('Are you sure you want to delete this payment method ending in', 'rental-gates'); ?> ' + last4 + '?')) {
                        return;
                    }

                    var btn = this;
                    btn.disabled = true;
                    btn.innerHTML = '<svg class="animate-spin" width="14" height="14" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> Deleting...';

                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'rental_gates_stripe_delete_payment_method',
                            nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                            method_id: methodId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('<?php _e('Payment method deleted', 'rental-gates'); ?>', 'success');
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            var errorMsg = data.data.message || '<?php _e('Failed to delete payment method', 'rental-gates'); ?>';
                            // Check if it's the "in use" error and provide helpful message
                            if (errorMsg.indexOf('currently being used') !== -1) {
                                showToast(errorMsg, 'warning', 8000);
                            } else {
                                showToast(errorMsg, 'error');
                            }
                            btn.disabled = false;
                            btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg> <?php _e('Delete', 'rental-gates'); ?>';
                        }
                    })
                    .catch(error => {
                        showToast('<?php _e('An error occurred', 'rental-gates'); ?>', 'error');
                        btn.disabled = false;
                        btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg> <?php _e('Delete', 'rental-gates'); ?>';
                    });
                });
            });
        })();
    </script>
    <?php endif; ?>

<?php else: ?>
    <!-- Overview View -->

    <!-- Current Plan Card -->
    <div class="current-plan-card">
        <div class="current-plan-header">
            <div class="current-plan-info">
                <h2><?php _e('Current Plan', 'rental-gates'); ?></h2>
                <p class="current-plan-name">
                    <?php echo esc_html($current_plan['name'] ?? 'Free'); ?>
                    <span class="plan-badge-inline <?php echo esc_attr($current_plan['id'] ?? 'free'); ?>">
                        <?php if (!empty($current_plan['is_free'])): ?>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="12" height="12">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <?php _e('Free', 'rental-gates'); ?>
                        <?php else: ?>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="12" height="12">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <?php _e('Paid', 'rental-gates'); ?>
                        <?php endif; ?>
                    </span>
                </p>
            </div>

            <div class="current-plan-price">
                <?php if (empty($current_plan['is_free']) && $subscription && !empty($subscription['amount'])): ?>
                    <?php
                    // Use actual subscription amount from Stripe (more accurate than plan prices)
                    $display_price = number_format(floatval($subscription['amount']), 2);
                    // Remove trailing zeros for whole numbers (e.g., 99.00 -> 99)
                    $display_price = (floor(floatval($subscription['amount'])) == floatval($subscription['amount'])) 
                        ? intval($subscription['amount']) 
                        : $display_price;
                    $display_period = $sub_billing_cycle === 'yearly' ? __('/year', 'rental-gates') : __('/month', 'rental-gates');
                    ?>
                    <div class="price-amount"><sup>$</sup><?php echo esc_html($display_price); ?></div>
                    <div class="price-period"><?php echo esc_html($display_period); ?></div>
                <?php elseif (empty($current_plan['is_free']) && !empty($current_plan['price_monthly'])): ?>
                    <?php
                    // Fallback to plan prices if no subscription amount
                    if ($sub_billing_cycle === 'yearly') {
                        $display_price = intval($current_plan['price_yearly'] ?? $current_plan['price_monthly'] * 12);
                        $display_period = __('/year', 'rental-gates');
                    } else {
                        $display_price = intval($current_plan['price_monthly']);
                        $display_period = __('/month', 'rental-gates');
                    }
                    ?>
                    <div class="price-amount"><sup>$</sup><?php echo esc_html($display_price); ?></div>
                    <div class="price-period"><?php echo esc_html($display_period); ?></div>
                <?php else: ?>
                    <div class="price-amount" style="color: #22c55e;">Free</div>
                    <div class="price-period"><?php _e('forever', 'rental-gates'); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="plan-status">
            <div class="plan-status-item">
                <span class="plan-status-label"><?php _e('Status', 'rental-gates'); ?></span>
                <span class="plan-status-value">
                    <?php if ($is_past_due): ?>
                        <span class="status-dot past_due"></span>
                        <?php _e('Past Due', 'rental-gates'); ?>
                    <?php elseif ($is_cancelling): ?>
                        <span class="status-dot cancelling"></span>
                        <?php _e('Cancelling', 'rental-gates'); ?>
                    <?php elseif ($is_trialing): ?>
                        <span class="status-dot trialing"></span>
                        <?php _e('Trial', 'rental-gates'); ?>
                        <?php if ($trial_end_date): ?>
                            <span class="trial-badge">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="12" height="12">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                                <?php printf(__('Ends %s', 'rental-gates'), $trial_end_date); ?>
                            </span>
                        <?php endif; ?>
                    <?php elseif ($is_pending): ?>
                        <span class="status-dot pending_payment"></span>
                        <?php _e('Pending Payment', 'rental-gates'); ?>
                    <?php elseif (!empty($current_plan['is_free']) || ($current_plan['id'] ?? 'free') === 'free'): ?>
                        <span class="status-dot active"></span>
                        <?php _e('Free Plan', 'rental-gates'); ?>
                    <?php elseif ($has_stripe_sub): ?>
                        <span class="status-dot <?php echo esc_attr($subscription['status'] ?? 'active'); ?>"></span>
                        <?php echo esc_html(ucfirst($subscription['status'] ?? 'Active')); ?>
                    <?php else: ?>
                        <span class="status-dot active"></span>
                        <?php _e('Active', 'rental-gates'); ?>
                    <?php endif; ?>
                </span>
            </div>

            <?php if ($is_past_due): ?>
                <!-- Past Due - Show payment required message -->
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Action Required', 'rental-gates'); ?></span>
                    <span class="plan-status-value" style="color: #fca5a5;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <?php _e('Update Payment', 'rental-gates'); ?>
                    </span>
                </div>
            <?php elseif ($is_trialing && $trial_end_date): ?>
                <!-- Trial - Show when trial ends -->
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Trial Ends', 'rental-gates'); ?></span>
                    <span class="plan-status-value" style="color: #a78bfa;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <?php echo esc_html($trial_end_date); ?>
                    </span>
                </div>
            <?php elseif ($is_cancelling && $cancel_date): ?>
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Access Until', 'rental-gates'); ?></span>
                    <span class="plan-status-value" style="color: #fbbf24;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <?php echo esc_html($cancel_date); ?>
                    </span>
                </div>
            <?php elseif ($subscription && !empty($subscription['current_period_end']) && $has_stripe_sub): ?>
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Renews On', 'rental-gates'); ?></span>
                    <span class="plan-status-value">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <?php echo esc_html(date('M j, Y', strtotime($subscription['current_period_end']))); ?>
                    </span>
                </div>
            <?php endif; ?>

            <?php if ($subscription && !empty($subscription['stripe_subscription_id'])): ?>
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Billing Cycle', 'rental-gates'); ?></span>
                    <span class="plan-status-value">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <?php echo $sub_billing_cycle === 'yearly' ? __('Yearly', 'rental-gates') : __('Monthly', 'rental-gates'); ?>
                    </span>
                </div>
            <?php endif; ?>

            <?php if ($subscription && !empty($subscription['created_at'])): ?>
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Member Since', 'rental-gates'); ?></span>
                    <span class="plan-status-value">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        <?php echo esc_html(date('M Y', strtotime($subscription['created_at']))); ?>
                    </span>
                </div>
            <?php elseif ($organization && !empty($organization['created_at'])): ?>
                <div class="plan-status-item">
                    <span class="plan-status-label"><?php _e('Member Since', 'rental-gates'); ?></span>
                    <span class="plan-status-value">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        <?php echo esc_html(date('M Y', strtotime($organization['created_at']))); ?>
                    </span>
                </div>
            <?php endif; ?>

            <?php if ($is_past_due && $has_stripe_sub): ?>
                <!-- Past Due Alert -->
                <div class="past-due-alert">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span><?php _e('Your payment failed. Please update your payment method to continue using premium features.', 'rental-gates'); ?></span>
                </div>
            <?php endif; ?>

            <?php if ($scheduled_downgrade): ?>
                <!-- Scheduled Downgrade Alert -->
                <div class="past-due-alert" style="background: rgba(245, 158, 11, 0.15); border-color: rgba(245, 158, 11, 0.3); color: #fcd34d;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20" style="color: #f59e0b;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span><?php printf(__('Your plan will change to %s at the end of your billing period.', 'rental-gates'), ucfirst($scheduled_downgrade)); ?></span>
                </div>
            <?php endif; ?>

            <div class="plan-actions">
                <?php
                $is_free_plan = !empty($current_plan['is_free']) || ($current_plan['id'] ?? 'free') === 'free';
                $has_paid_subscription = $subscription && $has_stripe_sub;
                ?>

                <?php if ($is_past_due && $has_paid_subscription): ?>
                    <!-- Past due - show update payment button prominently -->
                    <a href="<?php echo esc_url(add_query_arg('view', 'payment', home_url('/rental-gates/dashboard/billing'))); ?>"
                        class="btn btn-sm"
                        style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: #fff; border: none;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                        </svg>
                        <?php _e('Update Payment Method', 'rental-gates'); ?>
                    </a>

                <?php elseif ($is_cancelling && $has_paid_subscription): ?>
                    <!-- Subscription is set to cancel - show Resume button -->
                    <button type="button" class="btn btn-sm"
                        style="background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3);"
                        onclick="resumeSubscription()" id="resume-btn">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg>
                        <?php _e('Resume Subscription', 'rental-gates'); ?>
                    </button>

                    <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
                        class="btn btn-sm"
                        style="background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(10px);">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                        <?php _e('Change Plan', 'rental-gates'); ?>
                    </a>

                <?php elseif ($is_free_plan): ?>
                    <!-- Free plan - only show upgrade button -->
                    <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
                        class="btn btn-sm btn-upgrade"
                        style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: #fff; border: none;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M5 10l7-7m0 0l7 7m-7-7v18" />
                        </svg>
                        <?php _e('Upgrade Plan', 'rental-gates'); ?>
                    </a>

                <?php else: ?>
                    <!-- Paid plan - show change and cancel -->
                    <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
                        class="btn btn-sm"
                        style="background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(10px);">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg>
                        <?php _e('Change Plan', 'rental-gates'); ?>
                    </a>

                    <?php if ($has_paid_subscription): ?>
                        <a href="<?php echo esc_url(add_query_arg('view', 'payment', home_url('/rental-gates/dashboard/billing'))); ?>"
                            class="btn btn-sm"
                            style="background: rgba(255,255,255,0.15); color: #fff; border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(10px);">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                            </svg>
                            <?php _e('Manage Payment', 'rental-gates'); ?>
                        </a>
                        
                        <?php if ($subscription['status'] !== 'cancelled'): ?>
                            <button type="button" class="btn btn-sm"
                                style="background: rgba(254,202,202,0.1); color: #fca5a5; border: 1px solid rgba(252,165,165,0.2);"
                                onclick="document.getElementById('cancel-modal').classList.add('active');">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                                <?php _e('Cancel', 'rental-gates'); ?>
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Usage Section -->
    <div class="usage-section">
        <div class="usage-section-header">
            <h3 class="usage-section-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                <?php _e('Resource Usage', 'rental-gates'); ?>
            </h3>
        </div>

        <div class="usage-grid">
            <?php foreach ($usage as $resource => $data):
                if ($data['disabled'])
                    continue;

                $status = 'good';
                if (!$data['unlimited']) {
                    if ($data['percentage'] >= 90)
                        $status = 'critical';
                    elseif ($data['percentage'] >= 70)
                        $status = 'warning';
                } else {
                    $status = 'unlimited';
                }
                ?>
                <div class="usage-item">
                    <div class="usage-item-header">
                        <span class="usage-item-label"><?php echo esc_html($data['label']); ?></span>
                        <span class="usage-item-value">
                            <?php if ($data['unlimited']): ?>
                                <?php echo esc_html($data['current']); ?> / ∞
                            <?php else: ?>
                                <?php echo esc_html($data['current']); ?> / <?php echo esc_html($data['limit']); ?>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="usage-bar">
                        <div class="usage-bar-fill <?php echo esc_attr($status); ?>"
                            style="width: <?php echo $data['unlimited'] ? '15' : $data['percentage']; ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Modules Section -->
    <div class="modules-section">
        <div class="usage-section-header">
            <h3 class="usage-section-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                </svg>
                <?php _e('Available Features', 'rental-gates'); ?>
            </h3>
        </div>

        <div class="modules-grid">
            <?php foreach ($modules as $module): ?>
                <div class="module-chip <?php echo $module['enabled'] ? 'enabled' : 'disabled'; ?>">
                    <?php if ($module['enabled']): ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                    <?php else: ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                    <?php endif; ?>
                    <?php echo esc_html($module['label']); ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php
        $disabled_modules = array_filter($modules, function ($m) {
            return !$m['enabled'];
        });
        if (!empty($disabled_modules)):
            ?>
            <div style="margin-top: 16px; text-align: center;">
                <a href="<?php echo esc_url(add_query_arg('view', 'plans', home_url('/rental-gates/dashboard/billing'))); ?>"
                    style="font-size: 13px; color: #0d9488; text-decoration: none;">
                    <?php _e('Upgrade to unlock more features', 'rental-gates'); ?> →
                </a>
            </div>
        <?php endif; ?>
    </div>

<?php endif; ?>
<!-- End of view conditionals -->

<!-- Cancel Modal -->
<div class="modal-overlay" id="cancel-modal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-icon warning">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>
            <h3 class="modal-title"><?php _e('Cancel Subscription?', 'rental-gates'); ?></h3>
        </div>

        <div class="modal-body">
            <p><?php _e('Are you sure you want to cancel your subscription?', 'rental-gates'); ?></p>
            <ul style="font-size: 14px; color: #57534e; margin: 12px 0; padding-left: 20px;">
                <li><?php _e('Your subscription will remain active until the end of your billing period', 'rental-gates'); ?>
                </li>
                <li><?php _e('You can resume anytime before the period ends', 'rental-gates'); ?></li>
                <li><?php _e('After that, you\'ll be downgraded to the Free plan', 'rental-gates'); ?></li>
                <li><?php _e('Your data will be kept, but some features may be restricted', 'rental-gates'); ?></li>
            </ul>
            <?php if ($subscription && !empty($subscription['current_period_end'])): ?>
                <p style="font-size: 13px; color: #78716c; margin-top: 12px;">
                    <?php printf(
                        __('Your current billing period ends on <strong>%s</strong>.', 'rental-gates'),
                        esc_html(date_i18n(get_option('date_format'), strtotime($subscription['current_period_end'])))
                    ); ?>
                </p>
            <?php endif; ?>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary"
                onclick="document.getElementById('cancel-modal').classList.remove('active');">
                <?php _e('Keep Subscription', 'rental-gates'); ?>
            </button>
            <button type="button" class="btn btn-danger" id="confirm-cancel-btn" onclick="cancelSubscription()">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
                <?php _e('Cancel at Period End', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Downgrade Confirmation Modal -->
<div class="modal-overlay" id="downgrade-modal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-icon warning">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
            </div>
            <h3 class="modal-title"><?php _e('Confirm Downgrade', 'rental-gates'); ?></h3>
        </div>

        <div class="modal-body">
            <p id="downgrade-message"><?php _e('Are you sure you want to downgrade your plan?', 'rental-gates'); ?></p>
            <div id="downgrade-details" style="background: #fef3c7; border-radius: 8px; padding: 16px; margin: 16px 0;">
                <div
                    style="display: flex; align-items: center; gap: 8px; color: #92400e; font-weight: 600; margin-bottom: 8px;">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <?php _e('Important Information', 'rental-gates'); ?>
                </div>
                <ul style="font-size: 14px; color: #78350f; margin: 0; padding-left: 20px;">
                    <li><?php _e('You\'ll keep your current features until the end of your billing period', 'rental-gates'); ?>
                    </li>
                    <li><?php _e('Your data will be preserved, but access to some features may be limited', 'rental-gates'); ?>
                    </li>
                    <li><?php _e('You can upgrade again at any time', 'rental-gates'); ?></li>
                </ul>
            </div>
            <?php if ($subscription && !empty($subscription['current_period_end'])): ?>
                <p style="font-size: 13px; color: #78716c; margin-top: 12px;">
                    <strong><?php _e('Change effective:', 'rental-gates'); ?></strong>
                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($subscription['current_period_end']))); ?>
                </p>
            <?php endif; ?>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeDowngradeModal()">
                <?php _e('Keep Current Plan', 'rental-gates'); ?>
            </button>
            <button type="button" class="btn btn-warning" id="confirm-downgrade-btn" onclick="confirmDowngrade()">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                <?php _e('Confirm Downgrade', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Upgrade Confirmation Modal -->
<div class="modal-overlay" id="upgrade-modal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-icon success">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M5 10l7-7m0 0l7 7m-7-7v18" />
                </svg>
            </div>
            <h3 class="modal-title"><?php _e('Upgrade Plan', 'rental-gates'); ?></h3>
        </div>

        <div class="modal-body">
            <p id="upgrade-message"><?php _e('You\'re about to upgrade your plan.', 'rental-gates'); ?></p>
            <div id="upgrade-details" style="background: #dcfce7; border-radius: 8px; padding: 16px; margin: 16px 0;">
                <div
                    style="display: flex; align-items: center; gap: 8px; color: #166534; font-weight: 600; margin-bottom: 8px;">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <?php _e('What Happens Next', 'rental-gates'); ?>
                </div>
                <ul style="font-size: 14px; color: #14532d; margin: 0; padding-left: 20px;">
                    <li><?php _e('Your upgrade takes effect immediately', 'rental-gates'); ?></li>
                    <li><?php _e('You\'ll be charged the prorated difference for the rest of this billing period', 'rental-gates'); ?>
                    </li>
                    <li><?php _e('New features will be available right away', 'rental-gates'); ?></li>
                </ul>
            </div>
            <div id="proration-preview"
                style="display: none; background: #f5f5f4; border-radius: 8px; padding: 16px; margin: 16px 0;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="color: #57534e;"><?php _e('Amount due today:', 'rental-gates'); ?></span>
                    <span id="proration-amount"
                        style="font-size: 1.25rem; font-weight: 700; color: #1c1917;">$0.00</span>
                </div>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeUpgradeModal()">
                <?php _e('Cancel', 'rental-gates'); ?>
            </button>
            <button type="button" class="btn btn-primary" id="confirm-upgrade-btn" onclick="confirmUpgrade()">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                <?php _e('Confirm Upgrade', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<script>
    // Store pending plan change
    var pendingPlanChange = null;

    /**
     * Show toast notification
     * @param {string} message - Message to display
     * @param {string} type - 'success', 'error', 'warning', 'info'
     * @param {number} duration - Duration in ms (default 5000)
     */
    function showToast(message, type = 'info', duration = 5000) {
        // Remove existing toasts
        var existingToasts = document.querySelectorAll('.billing-toast');
        existingToasts.forEach(function(t) { t.remove(); });

        var toast = document.createElement('div');
        toast.className = 'billing-toast billing-toast-' + type;
        
        var icons = {
            success: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
            error: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
            warning: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>',
            info: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'
        };

        toast.innerHTML = icons[type] + '<span>' + message + '</span><button onclick="this.parentElement.remove()" class="billing-toast-close">&times;</button>';
        document.body.appendChild(toast);

        // Animate in
        setTimeout(function() { toast.classList.add('show'); }, 10);

        // Auto remove
        if (duration > 0) {
            setTimeout(function() {
                toast.classList.remove('show');
                setTimeout(function() { toast.remove(); }, 300);
            }, duration);
        }
    }

    function cancelSubscription() {
        var btn = document.getElementById('confirm-cancel-btn');
        btn.disabled = true;
        btn.innerHTML = '<svg class="animate-spin" width="16" height="16" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> <?php _e('Cancelling...', 'rental-gates'); ?>';

        var formData = new FormData();
        formData.append('action', 'rental_gates_cancel_subscription');
        formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_cancel'); ?>');

        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.data.message || '<?php _e('Subscription cancelled successfully', 'rental-gates'); ?>', 'success');
                    setTimeout(function() {
                        window.location.href = data.data.redirect || '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?cancelled=1')); ?>';
                    }, 1500);
                } else {
                    showToast(data.data.message || '<?php _e('Failed to cancel subscription', 'rental-gates'); ?>', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg> <?php _e('Cancel at Period End', 'rental-gates'); ?>';
                }
            })
            .catch(error => {
                console.error('Cancel subscription error:', error);
                showToast('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>', 'error');
                btn.disabled = false;
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg> <?php _e('Cancel at Period End', 'rental-gates'); ?>';
            });
    }

    function resumeSubscription() {
        var btn = document.getElementById('resume-btn');
        if (!btn) return;

        btn.disabled = true;
        btn.innerHTML = '<svg class="animate-spin" width="16" height="16" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> <?php _e('Resuming...', 'rental-gates'); ?>';

        var formData = new FormData();
        formData.append('action', 'rental_gates_resume_subscription');
        formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_resume'); ?>');

        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.data.message || '<?php _e('Subscription resumed successfully', 'rental-gates'); ?>', 'success');
                    setTimeout(function() {
                        window.location.href = data.data.redirect || '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?resumed=1')); ?>';
                    }, 1500);
                } else {
                    showToast(data.data.message || '<?php _e('Failed to resume subscription', 'rental-gates'); ?>', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> <?php _e('Resume Subscription', 'rental-gates'); ?>';
                }
            })
            .catch(error => {
                console.error('Resume subscription error:', error);
                showToast('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>', 'error');
                btn.disabled = false;
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> <?php _e('Resume Subscription', 'rental-gates'); ?>';
            });
    }

    // Show downgrade confirmation modal
    function showDowngradeModal(planId, planName, isFree) {
        pendingPlanChange = { planId: planId, planName: planName, isFree: isFree, type: 'downgrade' };

        var message = isFree
            ? '<?php echo esc_js(__('You\'re about to downgrade to the Free plan.', 'rental-gates')); ?>'
            : '<?php echo esc_js(sprintf(__('You\'re about to downgrade to the %s plan.', 'rental-gates'), '___PLAN_NAME___')); ?>'.replace('___PLAN_NAME___', planName);

        document.getElementById('downgrade-message').innerText = message;
        document.getElementById('downgrade-modal').classList.add('active');
    }

    function closeDowngradeModal() {
        document.getElementById('downgrade-modal').classList.remove('active');
        pendingPlanChange = null;
    }

    function confirmDowngrade() {
        if (!pendingPlanChange) return;

        var btn = document.getElementById('confirm-downgrade-btn');
        btn.disabled = true;
        btn.innerHTML = '<svg class="animate-spin" width="16" height="16" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> <?php _e('Processing...', 'rental-gates'); ?>';

        var formData = new FormData();
        formData.append('action', 'rental_gates_change_plan');
        formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_change_plan'); ?>');
        formData.append('plan_id', pendingPlanChange.planId);

        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeDowngradeModal();
                    showToast(data.data.message || '<?php _e('Plan change scheduled successfully', 'rental-gates'); ?>', 'success');
                    setTimeout(function() {
                        window.location.href = data.data.redirect || '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?changed=1')); ?>';
                    }, 1500);
                } else {
                    showToast(data.data.message || '<?php _e('Failed to change plan', 'rental-gates'); ?>', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php _e('Confirm Downgrade', 'rental-gates'); ?>';
                }
            })
            .catch(error => {
                console.error('Downgrade error:', error);
                showToast('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>', 'error');
                btn.disabled = false;
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php _e('Confirm Downgrade', 'rental-gates'); ?>';
            });
    }

    // Show upgrade confirmation modal for existing subscribers changing between paid plans
    function showUpgradeModal(planId, planName, planPrice) {
        pendingPlanChange = { planId: planId, planName: planName, price: planPrice, type: 'upgrade' };

        var message = '<?php echo esc_js(sprintf(__('You\'re about to upgrade to the %s plan at $%s/month.', 'rental-gates'), '___PLAN_NAME___', '___PLAN_PRICE___')); ?>';
        document.getElementById('upgrade-message').innerText = message.replace('___PLAN_NAME___', planName).replace('___PLAN_PRICE___', planPrice);
        document.getElementById('upgrade-modal').classList.add('active');
    }

    function closeUpgradeModal() {
        document.getElementById('upgrade-modal').classList.remove('active');
        pendingPlanChange = null;
    }

    function confirmUpgrade() {
        if (!pendingPlanChange) return;

        var btn = document.getElementById('confirm-upgrade-btn');
        btn.disabled = true;
        btn.innerHTML = '<svg class="animate-spin" width="16" height="16" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> <?php _e('Processing...', 'rental-gates'); ?>';

        var formData = new FormData();
        formData.append('action', 'rental_gates_change_plan');
        formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_change_plan'); ?>');
        formData.append('plan_id', pendingPlanChange.planId);

        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.data.requires_action) {
                        // 3D Secure required - handle with Stripe
                        handleStripeAction(data.data);
                    } else {
                        closeUpgradeModal();
                        showToast(data.data.message || '<?php _e('Plan upgraded successfully!', 'rental-gates'); ?>', 'success');
                        setTimeout(function() {
                            window.location.href = data.data.redirect || '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?changed=1')); ?>';
                        }, 1500);
                    }
                } else {
                    if (data.data.require_payment) {
                        // No existing payment method - redirect to checkout
                        showToast('<?php _e('Payment method required. Redirecting...', 'rental-gates'); ?>', 'info');
                        setTimeout(function() {
                            window.location.href = '<?php echo esc_url(home_url('/rental-gates/dashboard/billing')); ?>?plan=' + pendingPlanChange.planId;
                        }, 1500);
                    } else {
                        showToast(data.data.message || '<?php _e('Failed to change plan', 'rental-gates'); ?>', 'error');
                        btn.disabled = false;
                        btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php _e('Confirm Upgrade', 'rental-gates'); ?>';
                    }
                }
            })
            .catch(error => {
                console.error('Upgrade error:', error);
                showToast('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>', 'error');
                btn.disabled = false;
                btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php _e('Confirm Upgrade', 'rental-gates'); ?>';
            });
    }

    // Handle Stripe 3D Secure if needed
    function handleStripeAction(data) {
        if (typeof Stripe === 'undefined') {
            showToast('<?php _e('Payment processor not loaded. Please refresh and try again.', 'rental-gates'); ?>', 'error');
            return;
        }

        var stripe = Stripe('<?php echo esc_js($stripe_pk); ?>');
        stripe.confirmCardPayment(data.client_secret).then(function (result) {
            if (result.error) {
                showToast(result.error.message, 'error');
                var btn = document.getElementById('confirm-upgrade-btn');
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> <?php _e('Confirm Upgrade', 'rental-gates'); ?>';
                }
            } else {
                showToast('<?php _e('Payment confirmed! Redirecting...', 'rental-gates'); ?>', 'success');
                setTimeout(function() {
                    window.location.href = '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?changed=1')); ?>';
                }, 1000);
            }
        });
    }

    // Close modals on escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.getElementById('cancel-modal').classList.remove('active');
            document.getElementById('downgrade-modal').classList.remove('active');
            document.getElementById('upgrade-modal').classList.remove('active');
        }
    });

    // Close modals when clicking outside
    ['cancel-modal', 'downgrade-modal', 'upgrade-modal'].forEach(function (id) {
        var modal = document.getElementById(id);
        if (modal) {
            modal.addEventListener('click', function (e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        }
    });
</script>

<?php if ($stripe_enabled && $show_checkout && empty($checkout_plan['is_free'])): ?>
    <?php
    // Calculate button text based on billing cycle
    $btn_price = $billing_cycle === 'yearly'
        ? ($checkout_plan['price_yearly'] ?? $checkout_plan['price_monthly'] * 12)
        : $checkout_plan['price_monthly'];
    $btn_period = $billing_cycle === 'yearly' ? '/year' : '/month';
    $btn_text = sprintf(__('Subscribe - $%s%s', 'rental-gates'), esc_html($btn_price), $btn_period);
    ?>
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        (function () {
            var stripe = Stripe('<?php echo esc_js($stripe_pk); ?>');
            var elements = stripe.elements();
            var defaultBtnText = '<?php echo esc_js($btn_text); ?>';
            var cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#1c1917',
                        '::placeholder': { color: '#a8a29e' }
                    }
                }
            });
            cardElement.mount('#card-element');

            cardElement.on('change', function (event) {
                var displayError = document.getElementById('card-errors');
                displayError.textContent = event.error ? event.error.message : '';
            });

            var form = document.getElementById('checkout-form');
            form.addEventListener('submit', async function (event) {
                event.preventDefault();

                var submitBtn = document.getElementById('submit-btn');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<svg class="animate-spin" width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> Processing...';

                // Create payment method
                var { paymentMethod, error } = await stripe.createPaymentMethod({
                    type: 'card',
                    card: cardElement
                });

                if (error) {
                    document.getElementById('card-errors').textContent = error.message;
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = defaultBtnText;
                    return;
                }

                // Send to server
                var formData = new FormData();
                formData.append('action', 'rental_gates_subscribe');
                formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_subscribe'); ?>');
                formData.append('plan_id', '<?php echo esc_js($selected_plan); ?>');
                formData.append('billing_cycle', '<?php echo esc_js($billing_cycle); ?>');
                formData.append('payment_method_id', paymentMethod.id);

                try {
                    var response = await fetch(ajaxurl, {
                        method: 'POST',
                        body: formData
                    });
                    var data = await response.json();

                    if (data.success) {
                        // Check if 3D Secure authentication is required
                        if (data.data.requires_action && data.data.client_secret) {
                            submitBtn.innerHTML = '<svg class="animate-spin" width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> Authenticating...';

                            // Handle 3D Secure
                            var { error: confirmError, paymentIntent } = await stripe.confirmCardPayment(data.data.client_secret);

                            if (confirmError) {
                                document.getElementById('card-errors').textContent = confirmError.message;
                                submitBtn.disabled = false;
                                submitBtn.innerHTML = defaultBtnText;
                                return;
                            }

                            // Payment confirmed, redirect
                            if (paymentIntent.status === 'succeeded') {
                                window.location.href = data.data.redirect || '<?php echo esc_url(add_query_arg('subscribed', '1', home_url('/rental-gates/dashboard/billing'))); ?>';
                                return;
                            }
                        }

                        // Normal success - redirect
                        window.location.href = data.data.redirect || '<?php echo esc_url(add_query_arg('subscribed', '1', home_url('/rental-gates/dashboard/billing'))); ?>';
                    } else {
                        document.getElementById('card-errors').textContent = data.data.message || 'Subscription failed';
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = defaultBtnText;
                    }
                } catch (error) {
                    document.getElementById('card-errors').textContent = 'An error occurred. Please try again.';
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = defaultBtnText;
                }
            });
        })();
    </script>
<?php endif; ?>

<?php if ($show_checkout && !empty($checkout_plan['is_free'])): ?>
    <!-- Free Plan Form Handler -->
    <script>
        (function () {
            var form = document.getElementById('free-plan-form');
            if (!form) return;

            form.addEventListener('submit', async function (event) {
                event.preventDefault();

                var submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<svg class="animate-spin" width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> <?php _e('Switching...', 'rental-gates'); ?>';

                var formData = new FormData();
                formData.append('action', 'rental_gates_subscribe');
                formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_subscribe'); ?>');
                formData.append('plan_id', '<?php echo esc_js($selected_plan); ?>');

                try {
                    var response = await fetch(ajaxurl, {
                        method: 'POST',
                        body: formData
                    });
                    var data = await response.json();

                    if (data.success) {
                        window.location.href = data.data.redirect || '<?php echo esc_url(home_url('/rental-gates/dashboard/billing?changed=1')); ?>';
                    } else {
                        alert(data.data.message || '<?php _e('Failed to switch plan', 'rental-gates'); ?>');
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = '<?php _e('Switch to Free Plan', 'rental-gates'); ?>';
                    }
                } catch (error) {
                    alert('<?php _e('An error occurred. Please try again.', 'rental-gates'); ?>');
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<?php _e('Switch to Free Plan', 'rental-gates'); ?>';
                }
            });
        })();
    </script>
<?php endif; ?>

<?php if ($view === 'plans'): ?>
    <!-- Billing Period Toggle Script -->
    <script>
        (function () {
            var toggle = document.getElementById('billing-period-toggle');
            if (!toggle) return;

            var isYearly = false;

            toggle.addEventListener('click', function () {
                isYearly = !isYearly;
                this.classList.toggle('yearly', isYearly);

                // Update labels
                document.querySelectorAll('.billing-toggle-label').forEach(function (label) {
                    label.classList.toggle('active', label.dataset.period === (isYearly ? 'yearly' : 'monthly'));
                });

                // Update prices - old style cards
                document.querySelectorAll('.plan-card-amount[data-monthly]').forEach(function (amount) {
                    var priceValue = amount.querySelector('.price-value');
                    if (priceValue) {
                        var newValue = isYearly ? amount.dataset.yearly : amount.dataset.monthly;

                        // Animate the price change
                        amount.style.transform = 'scale(0.9)';
                        amount.style.opacity = '0.5';

                        setTimeout(function () {
                            priceValue.textContent = newValue;
                            amount.style.transform = 'scale(1)';
                            amount.style.opacity = '1';
                        }, 150);
                    }
                });

                // Update prices - modern plan cards
                document.querySelectorAll('.plan-card-modern .plan-price[data-monthly]').forEach(function (priceContainer) {
                    var priceAmount = priceContainer.querySelector('.price-amount');
                    if (priceAmount) {
                        var newValue = isYearly ? priceContainer.dataset.yearly : priceContainer.dataset.monthly;

                        // Animate the price change
                        priceContainer.style.transform = 'scale(0.95)';
                        priceContainer.style.opacity = '0.5';

                        setTimeout(function () {
                            priceAmount.textContent = newValue;
                            priceContainer.style.transform = 'scale(1)';
                            priceContainer.style.opacity = '1';
                        }, 150);
                    }
                });

                // Update period text - old style
                document.querySelectorAll('.period-text').forEach(function (period) {
                    period.textContent = isYearly ? '<?php _e('/month, billed yearly', 'rental-gates'); ?>' : '<?php _e('/month', 'rental-gates'); ?>';
                });

                // Update period text - modern style
                document.querySelectorAll('.plan-card-modern .period-label').forEach(function (period) {
                    period.textContent = isYearly ? '<?php _e('Billed yearly', 'rental-gates'); ?>' : '<?php _e('Billed monthly', 'rental-gates'); ?>';
                });

                // Show/hide yearly-only elements
                document.querySelectorAll('.yearly-only').forEach(function (el) {
                    el.style.display = isYearly ? 'inline-flex' : 'none';
                });

                // Update checkout links - old style
                document.querySelectorAll('.plan-card-action a').forEach(function (link) {
                    var href = link.getAttribute('href');
                    if (href) {
                        href = href.replace(/&billing_cycle=(monthly|yearly)/, '');
                        link.setAttribute('href', href + '&billing_cycle=' + (isYearly ? 'yearly' : 'monthly'));
                    }
                });

                // Update checkout links - modern style
                document.querySelectorAll('.plan-card-modern .plan-btn-upgrade').forEach(function (link) {
                    var href = link.getAttribute('href');
                    if (href) {
                        href = href.replace(/&billing_cycle=(monthly|yearly)/, '');
                        href = href.replace(/billing_cycle=(monthly|yearly)/, '');
                        if (href.indexOf('?') > -1) {
                            link.setAttribute('href', href + '&billing_cycle=' + (isYearly ? 'yearly' : 'monthly'));
                        } else {
                            link.setAttribute('href', href + '?billing_cycle=' + (isYearly ? 'yearly' : 'monthly'));
                        }
                    }
                });
            });
        })();
    </script>
<?php endif; ?>