<?php
/**
 * Application Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get application ID from URL - PRIMARY method: parse REQUEST_URI directly
$application_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/applications/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $application_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$application_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    $application_id = isset($parts[1]) ? intval($parts[1]) : 0;
}

if (!$application_id) {
    wp_redirect(home_url('/rental-gates/dashboard/applications'));
    exit;
}

$application = Rental_Gates_Application::get_with_details($application_id);

if (!$application || $application['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/applications'));
    exit;
}

// Status config
$status_config = array(
    'new' => array('label' => __('New', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'screening' => array('label' => __('Screening', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'approved' => array('label' => __('Approved', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'withdrawn' => array('label' => __('Withdrawn', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'invited' => array('label' => __('Invited', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
);

$status = $status_config[$application['status']] ?? $status_config['new'];

// Initials
$name_parts = explode(' ', $application['applicant_name']);
$initials = '';
foreach ($name_parts as $part) {
    $initials .= strtoupper(substr($part, 0, 1));
}
$initials = substr($initials, 0, 2);
?>

<style>
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    .rg-app-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-app-title-row { display: flex; align-items: center; gap: 16px; }
    .rg-app-avatar { width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 20px; }
    .rg-app-title h1 { font-size: 24px; font-weight: 700; margin: 0 0 4px 0; }
    .rg-app-subtitle { display: flex; align-items: center; gap: 12px; color: var(--gray-500); font-size: 14px; }
    .rg-header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-status-badge .dot { width: 8px; height: 8px; border-radius: 50%; }
    .rg-app-grid { display: grid; grid-template-columns: 1fr 360px; gap: 24px; }
    .rg-app-main { min-width: 0; }
    .rg-app-aside { min-width: 0; }
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); }
    .rg-card-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .rg-card-body { padding: 20px; }
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-value { font-size: 14px; color: var(--gray-900); font-weight: 500; }
    .rg-info-value a { color: var(--primary); text-decoration: none; }
    .rg-unit-card { display: flex; gap: 16px; padding: 16px; background: var(--gray-50); border-radius: 10px; }
    .rg-unit-image { width: 80px; height: 80px; border-radius: 8px; background: var(--gray-200); display: flex; align-items: center; justify-content: center; color: var(--gray-400); flex-shrink: 0; }
    .rg-unit-details h4 { margin: 0 0 4px 0; font-size: 16px; }
    .rg-unit-details h4 a { color: inherit; text-decoration: none; }
    .rg-unit-details p { margin: 0; color: var(--gray-500); font-size: 14px; }
    .rg-unit-meta { display: flex; gap: 12px; margin-top: 8px; font-size: 13px; color: var(--gray-600); }
    .rg-timeline { display: flex; flex-direction: column; }
    .rg-timeline-item { display: flex; gap: 12px; padding: 12px 0; }
    .rg-timeline-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--primary); margin-top: 5px; flex-shrink: 0; }
    .rg-timeline-dot.success { background: #10b981; }
    .rg-timeline-dot.error { background: #ef4444; }
    .rg-timeline-dot.warning { background: #f59e0b; }
    .rg-timeline-content { flex: 1; border-bottom: 1px solid var(--gray-100); padding-bottom: 12px; }
    .rg-timeline-item:last-child .rg-timeline-content { border-bottom: none; }
    .rg-timeline-title { font-size: 14px; font-weight: 500; }
    .rg-timeline-date { font-size: 12px; color: var(--gray-500); }
    .rg-notes-text { white-space: pre-wrap; color: var(--gray-700); line-height: 1.6; }
    .rg-btn-success { background: #10b981; color: #fff; border-color: #10b981; }
    .rg-btn-success:hover { background: #059669; }
    .rg-btn-danger { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }
    .rg-btn-danger:hover { background: #fecaca; }
    .rg-btn-warning { background: #f59e0b; color: #fff; border-color: #f59e0b; }
    .rg-btn-warning:hover { background: #d97706; }
    .rg-decline-reason { margin-top: 12px; padding: 12px; background: #fee2e2; border-radius: 8px; font-size: 14px; color: #991b1b; }
    .rg-modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .rg-modal-content { background: #fff; border-radius: 12px; padding: 24px; max-width: 400px; width: 90%; }
    .rg-modal h3 { margin: 0 0 16px 0; }
    .rg-modal-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
    @media (max-width: 992px) { .rg-app-grid { grid-template-columns: 1fr; } .rg-app-aside { order: -1; } }
    @media (max-width: 576px) { .rg-info-grid { grid-template-columns: 1fr; } }
</style>

<a href="<?php echo home_url('/rental-gates/dashboard/applications'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    <?php _e('Back to Applications', 'rental-gates'); ?>
</a>

<div class="rg-app-header">
    <div class="rg-app-title-row">
        <div class="rg-app-avatar"><?php echo $initials; ?></div>
        <div class="rg-app-title">
            <h1><?php echo esc_html($application['applicant_name']); ?></h1>
            <div class="rg-app-subtitle">
                <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                    <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                    <?php echo $status['label']; ?>
                </span>
                <span><?php _e('Application', 'rental-gates'); ?> #<?php echo $application['id']; ?></span>
            </div>
        </div>
    </div>
    <div class="rg-header-actions">
        <?php if (in_array($application['status'], array('new', 'screening'))): ?>
            <?php if ($application['status'] === 'new'): ?>
            <button type="button" class="rg-btn rg-btn-warning" onclick="startScreening(<?php echo $application['id']; ?>)">
                <?php _e('Start Screening', 'rental-gates'); ?>
            </button>
            <?php endif; ?>
            <button type="button" class="rg-btn rg-btn-success" onclick="showApproveModal()">
                <?php _e('Approve', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-danger" onclick="showDeclineModal()">
                <?php _e('Decline', 'rental-gates'); ?>
            </button>
        <?php endif; ?>
    </div>
</div>

<div class="rg-app-grid">
    <div class="rg-app-main">
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Contact Information', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Full Name', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($application['applicant_name']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Phone', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><a href="tel:<?php echo esc_attr($application['applicant_phone']); ?>"><?php echo esc_html($application['applicant_phone']); ?></a></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Email', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><a href="mailto:<?php echo esc_attr($application['applicant_email']); ?>"><?php echo esc_html($application['applicant_email']); ?></a></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Current Address', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($application['current_address'] ?: '—'); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Employment & Income', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Employer', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($application['employer'] ?: '—'); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Annual Income', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($application['income_label'] ?: '—'); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Desired Move-in', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo $application['desired_move_in'] ? date('F j, Y', strtotime($application['desired_move_in'])) : '—'; ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (!empty($application['notes'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Applicant Notes', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <p class="rg-notes-text"><?php echo esc_html($application['notes']); ?></p>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($application['status'] === 'declined' && !empty($application['decline_reason'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Decline Reason', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-decline-reason"><?php echo esc_html($application['decline_reason']); ?></div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="rg-app-aside">
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Unit Applied For', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-unit-card">
                    <div class="rg-unit-image">
                        <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    </div>
                    <div class="rg-unit-details">
                        <h4><a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $application['building_id'] . '/units/' . $application['unit_id']); ?>"><?php echo esc_html($application['unit_name']); ?></a></h4>
                        <p><?php echo esc_html($application['building_name']); ?></p>
                        <div class="rg-unit-meta">
                            <?php if (!empty($application['bedrooms'])): ?><span><?php echo $application['bedrooms']; ?> bed</span><?php endif; ?>
                            <?php if (!empty($application['bathrooms'])): ?><span><?php echo $application['bathrooms']; ?> bath</span><?php endif; ?>
                            <?php if (!empty($application['unit_rent'])): ?><span>$<?php echo number_format($application['unit_rent']); ?>/mo</span><?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Timeline', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-timeline">
                    <?php if ($application['decision_at']): ?>
                    <div class="rg-timeline-item">
                        <div class="rg-timeline-dot <?php echo $application['status'] === 'approved' ? 'success' : 'error'; ?>"></div>
                        <div class="rg-timeline-content">
                            <div class="rg-timeline-title"><?php echo $application['status'] === 'approved' ? __('Approved', 'rental-gates') : __('Declined', 'rental-gates'); ?></div>
                            <div class="rg-timeline-date"><?php echo date('M j, Y g:i A', strtotime($application['decision_at'])); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="rg-timeline-item">
                        <div class="rg-timeline-dot"></div>
                        <div class="rg-timeline-content">
                            <div class="rg-timeline-title"><?php _e('Submitted', 'rental-gates'); ?></div>
                            <div class="rg-timeline-date"><?php echo $application['submitted_at'] ? date('M j, Y g:i A', strtotime($application['submitted_at'])) : '—'; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Quick Info', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Application ID', 'rental-gates'); ?></div>
                    <div class="rg-info-value">#<?php echo $application['id']; ?></div>
                </div>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Days Pending', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo $application['days_pending']; ?> days</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="approve-modal" class="rg-modal">
    <div class="rg-modal-content">
        <h3><?php _e('Approve Application', 'rental-gates'); ?></h3>
        <p style="color: var(--gray-600);"><?php _e('Do you also want to create a tenant record?', 'rental-gates'); ?></p>
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
            <input type="checkbox" id="create-tenant-checkbox" checked style="width: 18px; height: 18px;">
            <span><?php _e('Create tenant record', 'rental-gates'); ?></span>
        </label>
        <div class="rg-modal-actions">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="hideApproveModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
            <button type="button" class="rg-btn rg-btn-success" onclick="approveApplication()"><?php _e('Approve', 'rental-gates'); ?></button>
        </div>
    </div>
</div>

<div id="decline-modal" class="rg-modal">
    <div class="rg-modal-content">
        <h3><?php _e('Decline Application', 'rental-gates'); ?></h3>
        <div style="margin-bottom: 16px;">
            <label style="display: block; margin-bottom: 6px; font-weight: 500;"><?php _e('Reason (optional)', 'rental-gates'); ?></label>
            <textarea id="decline-reason" style="width: 100%; padding: 10px; border: 1px solid var(--gray-300); border-radius: 8px; min-height: 80px;"></textarea>
        </div>
        <div class="rg-modal-actions">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="hideDeclineModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
            <button type="button" class="rg-btn rg-btn-danger" onclick="declineApplication()"><?php _e('Decline', 'rental-gates'); ?></button>
        </div>
    </div>
</div>

<script>
function showApproveModal() { document.getElementById('approve-modal').style.display = 'flex'; }
function hideApproveModal() { document.getElementById('approve-modal').style.display = 'none'; }
function showDeclineModal() { document.getElementById('decline-modal').style.display = 'flex'; }
function hideDeclineModal() { document.getElementById('decline-modal').style.display = 'none'; }

function startScreening(appId) {
    const formData = new FormData();
    formData.append('action', 'rental_gates_screen_application');
    formData.append('application_id', appId);
    formData.append('nonce', rentalGatesData.nonce);
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function approveApplication() {
    const formData = new FormData();
    formData.append('action', 'rental_gates_approve_application');
    formData.append('application_id', <?php echo $application['id']; ?>);
    formData.append('create_tenant', document.getElementById('create-tenant-checkbox').checked ? '1' : '0');
    formData.append('nonce', rentalGatesData.nonce);
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function declineApplication() {
    const formData = new FormData();
    formData.append('action', 'rental_gates_decline_application');
    formData.append('application_id', <?php echo $application['id']; ?>);
    formData.append('reason', document.getElementById('decline-reason').value);
    formData.append('nonce', rentalGatesData.nonce);
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}
</script>
