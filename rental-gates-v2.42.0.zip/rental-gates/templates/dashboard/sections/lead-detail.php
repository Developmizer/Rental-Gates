<?php
/**
 * Lead Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get lead ID from URL
$lead_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/leads/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $lead_id = intval($matches[1]);
    }
}

if (!$lead_id) {
    wp_redirect(home_url('/rental-gates/dashboard/leads'));
    exit;
}

$lead = Rental_Gates_Lead::get_with_details($lead_id);

if (!$lead || $lead['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/leads'));
    exit;
}

$stages = Rental_Gates_Lead::get_stages();
$sources = Rental_Gates_Lead::get_sources();
$staff = Rental_Gates_Organization::get_members($org_id);
$buildings = Rental_Gates_Building::get_for_organization($org_id, array('limit' => 100));
?>

<style>
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    
    .rg-lead-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-lead-header-left { display: flex; gap: 20px; align-items: flex-start; }
    .rg-lead-avatar-lg { width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 28px; flex-shrink: 0; }
    .rg-lead-header-info h1 { font-size: 24px; font-weight: 700; margin: 0 0 8px; }
    .rg-lead-header-meta { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
    .rg-lead-header-meta a { color: var(--gray-600); text-decoration: none; font-size: 14px; display: flex; align-items: center; gap: 6px; }
    .rg-lead-header-meta a:hover { color: var(--primary); }
    .rg-lead-header-meta svg { width: 16px; height: 16px; }
    .rg-header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
    
    .rg-stage-badge-lg { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 24px; font-size: 14px; font-weight: 600; }
    
    .rg-lead-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; }
    .rg-lead-main { min-width: 0; }
    .rg-lead-aside { min-width: 0; }
    
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-card-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .rg-card-body { padding: 20px; }
    
    /* Stage Pipeline */
    .rg-stage-pipeline { display: flex; gap: 8px; margin-bottom: 24px; }
    .rg-stage-step { flex: 1; text-align: center; padding: 12px 8px; border-radius: 8px; background: var(--gray-100); cursor: pointer; transition: all 0.2s; }
    .rg-stage-step:hover { background: var(--gray-200); }
    .rg-stage-step.active { color: #fff; }
    .rg-stage-step.completed { background: #d1fae5; color: #065f46; }
    .rg-stage-step-label { font-size: 12px; font-weight: 600; }
    .rg-stage-step-dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; margin: 0 auto 6px; }
    
    /* Quick Actions */
    .rg-quick-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
    .rg-quick-action { display: flex; align-items: center; gap: 8px; padding: 10px 16px; background: #fff; border: 1px solid var(--gray-200); border-radius: 8px; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.2s; }
    .rg-quick-action:hover { border-color: var(--primary); background: #f5f3ff; }
    .rg-quick-action svg { width: 18px; height: 18px; color: var(--gray-500); }
    
    /* Notes Section */
    .rg-notes-container { max-height: 400px; overflow-y: auto; }
    .rg-note-item { padding: 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-note-item:last-child { border-bottom: none; }
    .rg-note-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .rg-note-date { font-size: 12px; color: var(--gray-400); }
    .rg-note-text { white-space: pre-wrap; font-size: 14px; line-height: 1.6; color: var(--gray-700); }
    .rg-note-empty { text-align: center; padding: 30px; color: var(--gray-400); }
    
    .rg-add-note { padding: 16px; border-top: 1px solid var(--gray-100); }
    .rg-add-note textarea { width: 100%; padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; min-height: 80px; resize: vertical; font-family: inherit; font-size: 14px; }
    .rg-add-note textarea:focus { outline: none; border-color: var(--primary); }
    .rg-add-note-actions { display: flex; justify-content: flex-end; margin-top: 12px; }
    
    /* Activity Timeline */
    .rg-activity-item { display: flex; gap: 12px; padding: 12px 0; }
    .rg-activity-icon { width: 32px; height: 32px; border-radius: 50%; background: var(--gray-100); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-activity-icon svg { width: 16px; height: 16px; color: var(--gray-500); }
    .rg-activity-content { flex: 1; }
    .rg-activity-text { font-size: 14px; color: var(--gray-700); }
    .rg-activity-time { font-size: 12px; color: var(--gray-400); margin-top: 2px; }
    
    /* Interests */
    .rg-interest-item { display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--gray-50); border-radius: 8px; margin-bottom: 8px; }
    .rg-interest-item:last-child { margin-bottom: 0; }
    .rg-interest-icon { width: 36px; height: 36px; background: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; }
    .rg-interest-icon svg { width: 20px; height: 20px; color: var(--primary); }
    .rg-interest-info { flex: 1; }
    .rg-interest-name { font-weight: 600; font-size: 14px; }
    .rg-interest-type { font-size: 12px; color: var(--gray-500); }
    
    /* Info Grid */
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-value { font-size: 14px; color: var(--gray-900); font-weight: 500; }
    
    /* Modal */
    .rg-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; padding: 20px; }
    .rg-modal-overlay.open { display: flex; }
    .rg-modal { background: #fff; border-radius: 16px; max-width: 500px; width: 100%; max-height: 90vh; overflow-y: auto; }
    .rg-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-header h3 { margin: 0; font-size: 18px; }
    .rg-modal-close { background: none; border: none; cursor: pointer; padding: 8px; color: var(--gray-400); }
    .rg-modal-body { padding: 24px; }
    .rg-form-group { margin-bottom: 20px; }
    .rg-form-group label { display: block; font-size: 14px; font-weight: 500; margin-bottom: 6px; }
    .rg-form-group input, .rg-form-group select, .rg-form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-100); }
    
    .rg-btn-danger { background: #dc2626; color: #fff; }
    .rg-btn-danger:hover { background: #b91c1c; }
    
    @media (max-width: 1024px) {
        .rg-lead-grid { grid-template-columns: 1fr; }
    }
    @media (max-width: 768px) {
        .rg-lead-header-left { flex-direction: column; align-items: center; text-align: center; }
        .rg-lead-header-meta { justify-content: center; }
        .rg-stage-pipeline { flex-wrap: wrap; }
        .rg-info-grid { grid-template-columns: 1fr; }
    }
</style>

<a href="<?php echo home_url('/rental-gates/dashboard/leads'); ?>" class="rg-back-link">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
    <?php _e('Back to Leads', 'rental-gates'); ?>
</a>

<div class="rg-lead-header">
    <div class="rg-lead-header-left">
        <div class="rg-lead-avatar-lg"><?php echo esc_html($lead['initials']); ?></div>
        <div class="rg-lead-header-info">
            <h1><?php echo esc_html($lead['name']); ?></h1>
            <div class="rg-lead-header-meta">
                <a href="mailto:<?php echo esc_attr($lead['email']); ?>">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    <?php echo esc_html($lead['email']); ?>
                </a>
                <?php if ($lead['phone']): ?>
                <a href="tel:<?php echo esc_attr($lead['phone']); ?>">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    <?php echo esc_html($lead['phone']); ?>
                </a>
                <?php endif; ?>
                <span class="rg-stage-badge-lg" style="background: <?php echo $lead['stage_bg']; ?>; color: <?php echo $lead['stage_color']; ?>;">
                    <?php echo esc_html($lead['stage_label']); ?>
                </span>
            </div>
        </div>
    </div>
    <div class="rg-header-actions">
        <button class="rg-btn rg-btn-secondary" onclick="openEditModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
            <?php _e('Edit', 'rental-gates'); ?>
        </button>
        <button class="rg-btn rg-btn-secondary" style="color: #dc2626;" onclick="openDeleteModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            <?php _e('Delete', 'rental-gates'); ?>
        </button>
    </div>
</div>

<!-- Stage Pipeline -->
<div class="rg-stage-pipeline">
    <?php 
    $stage_order = array('new', 'contacted', 'touring', 'applied', 'won');
    $current_index = array_search($lead['stage'], $stage_order);
    if ($current_index === false) $current_index = -1;
    
    foreach ($stage_order as $index => $stage): 
        $stage_config = $stages[$stage];
        $is_active = ($stage === $lead['stage']);
        $is_completed = ($index < $current_index);
    ?>
    <div class="rg-stage-step <?php echo $is_active ? 'active' : ''; ?> <?php echo $is_completed ? 'completed' : ''; ?>"
         style="<?php echo $is_active ? 'background: ' . $stage_config['color'] . ';' : ''; ?>"
         onclick="updateStage('<?php echo $stage; ?>')">
        <div class="rg-stage-step-dot"></div>
        <div class="rg-stage-step-label"><?php echo $stage_config['label']; ?></div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Quick Actions -->
<div class="rg-quick-actions">
    <button class="rg-quick-action" onclick="openScheduleModal()">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        <?php _e('Schedule Follow-up', 'rental-gates'); ?>
    </button>
    <a href="mailto:<?php echo esc_attr($lead['email']); ?>" class="rg-quick-action">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
        <?php _e('Send Email', 'rental-gates'); ?>
    </a>
    <?php if ($lead['phone']): ?>
    <a href="tel:<?php echo esc_attr($lead['phone']); ?>" class="rg-quick-action">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
        <?php _e('Call', 'rental-gates'); ?>
    </a>
    <?php endif; ?>
    <?php if ($lead['stage'] !== 'lost'): ?>
    <button class="rg-quick-action" onclick="openLostModal()" style="color: #dc2626;">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
        <?php _e('Mark as Lost', 'rental-gates'); ?>
    </button>
    <?php endif; ?>
</div>

<div class="rg-lead-grid">
    <div class="rg-lead-main">
        <!-- Notes -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Notes & Activity', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-notes-container">
                <?php if (!empty($lead['notes'])): ?>
                <div class="rg-note-item">
                    <div class="rg-note-text"><?php echo nl2br(esc_html($lead['notes'])); ?></div>
                </div>
                <?php else: ?>
                <div class="rg-note-empty"><?php _e('No notes yet. Add your first note below.', 'rental-gates'); ?></div>
                <?php endif; ?>
            </div>
            <div class="rg-add-note">
                <textarea id="newNote" placeholder="<?php esc_attr_e('Add a note...', 'rental-gates'); ?>"></textarea>
                <div class="rg-add-note-actions">
                    <button class="rg-btn rg-btn-primary" onclick="addNote()"><?php _e('Add Note', 'rental-gates'); ?></button>
                </div>
            </div>
        </div>
        
        <!-- Activity Log -->
        <?php if (!empty($lead['activity'])): ?>
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Activity Log', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <?php foreach ($lead['activity'] as $activity): ?>
                <div class="rg-activity-item">
                    <div class="rg-activity-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <div class="rg-activity-content">
                        <div class="rg-activity-text">
                            <?php 
                            switch ($activity['action']) {
                                case 'stage_change':
                                    $from = $stages[$activity['details']['from']]['label'] ?? $activity['details']['from'];
                                    $to = $stages[$activity['details']['to']]['label'] ?? $activity['details']['to'];
                                    printf(__('Stage changed from %s to %s', 'rental-gates'), '<strong>' . $from . '</strong>', '<strong>' . $to . '</strong>');
                                    break;
                                case 'note_added':
                                    _e('Note added', 'rental-gates');
                                    break;
                                case 'converted':
                                    _e('Converted to tenant', 'rental-gates');
                                    break;
                                default:
                                    echo esc_html($activity['action']);
                            }
                            ?>
                            <?php if ($activity['user_name']): ?>
                                <span style="color: var(--gray-500);"> — <?php echo esc_html($activity['user_name']); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="rg-activity-time"><?php echo date_i18n('M j, Y g:i a', strtotime($activity['created_at'])); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="rg-lead-aside">
        <!-- Details -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Details', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Source', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($lead['source_label']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Created', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo $lead['created_at_formatted']; ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Assigned To', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($lead['assigned_name'] ?? __('Unassigned', 'rental-gates')); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Follow-up', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <?php if (!empty($lead['follow_up_date'])): ?>
                                <span style="<?php echo !empty($lead['follow_up_overdue']) ? 'color: #dc2626;' : ''; ?>">
                                    <?php echo $lead['follow_up_formatted']; ?>
                                    <?php if (!empty($lead['follow_up_overdue'])): ?>
                                        <span style="font-size: 11px;">(<?php _e('Overdue', 'rental-gates'); ?>)</span>
                                    <?php endif; ?>
                                </span>
                            <?php else: ?>
                                <?php _e('Not set', 'rental-gates'); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Interests -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Interested In', 'rental-gates'); ?></h3>
                <button class="rg-btn rg-btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="openAddInterestModal()">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                    <?php _e('Add', 'rental-gates'); ?>
                </button>
            </div>
            <div class="rg-card-body">
                <?php if (!empty($lead['interests'])): ?>
                    <?php foreach ($lead['interests'] as $interest): ?>
                    <div class="rg-interest-item">
                        <div class="rg-interest-icon">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                        </div>
                        <div class="rg-interest-info">
                            <div class="rg-interest-name"><?php echo esc_html($interest['unit_name'] ?? $interest['building_name'] ?? __('Property', 'rental-gates')); ?></div>
                            <div class="rg-interest-type"><?php echo $interest['unit_id'] ? __('Unit', 'rental-gates') : __('Building', 'rental-gates'); ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 20px; color: var(--gray-400); font-size: 13px;">
                        <?php _e('No properties added yet', 'rental-gates'); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($lead['stage'] === 'lost' && $lead['lost_reason']): ?>
        <div class="rg-card" style="border-color: #fecaca; background: #fef2f2;">
            <div class="rg-card-header">
                <h3 style="color: #dc2626;"><?php _e('Lost Reason', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <p style="margin: 0; color: var(--gray-700);"><?php echo esc_html($lead['lost_reason']); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Edit Modal -->
<div class="rg-modal-overlay" id="editModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3><?php _e('Edit Lead', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeEditModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="editLeadForm" class="rg-modal-body">
            <div class="rg-form-group">
                <label><?php _e('Name', 'rental-gates'); ?></label>
                <input type="text" name="name" value="<?php echo esc_attr($lead['name']); ?>" required>
            </div>
            <div class="rg-form-group">
                <label><?php _e('Email', 'rental-gates'); ?></label>
                <input type="email" name="email" value="<?php echo esc_attr($lead['email']); ?>" required>
            </div>
            <div class="rg-form-group">
                <label><?php _e('Phone', 'rental-gates'); ?></label>
                <input type="tel" name="phone" value="<?php echo esc_attr($lead['phone']); ?>">
            </div>
            <div class="rg-form-group">
                <label><?php _e('Assigned To', 'rental-gates'); ?></label>
                <select name="assigned_to">
                    <option value=""><?php _e('Unassigned', 'rental-gates'); ?></option>
                    <?php foreach ($staff as $member): ?>
                        <option value="<?php echo $member['user_id']; ?>" <?php selected($lead['assigned_to'], $member['user_id']); ?>><?php echo esc_html($member['display_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="rg-form-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeEditModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Save Changes', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Schedule Follow-up Modal -->
<div class="rg-modal-overlay" id="scheduleModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3><?php _e('Schedule Follow-up', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeScheduleModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="scheduleForm" class="rg-modal-body">
            <div class="rg-form-group">
                <label><?php _e('Follow-up Date', 'rental-gates'); ?></label>
                <input type="date" name="follow_up_date" value="<?php echo esc_attr($lead['follow_up_date'] ? date('Y-m-d', strtotime($lead['follow_up_date'])) : ''); ?>" min="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="rg-form-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeScheduleModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Schedule', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Mark as Lost Modal -->
<div class="rg-modal-overlay" id="lostModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3><?php _e('Mark as Lost', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeLostModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="lostForm" class="rg-modal-body">
            <div class="rg-form-group">
                <label><?php _e('Reason for losing this lead', 'rental-gates'); ?></label>
                <textarea name="lost_reason" rows="3" placeholder="<?php esc_attr_e('e.g., Found another property, Budget constraints, etc.', 'rental-gates'); ?>"></textarea>
            </div>
            <div class="rg-form-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeLostModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-danger"><?php _e('Mark as Lost', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="rg-modal-overlay" id="deleteModal">
    <div class="rg-modal" style="max-width: 400px;">
        <div class="rg-modal-header">
            <h3><?php _e('Delete Lead', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeDeleteModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="rg-modal-body" style="text-align: center;">
            <svg width="48" height="48" fill="none" stroke="#dc2626" stroke-width="1.5" viewBox="0 0 24 24" style="margin-bottom: 16px;"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
            <h4 style="margin: 0 0 8px;"><?php _e('Are you sure?', 'rental-gates'); ?></h4>
            <p style="color: var(--gray-500); margin: 0 0 24px;"><?php printf(__('This will permanently delete "%s"', 'rental-gates'), esc_html($lead['name'])); ?></p>
            <div style="display: flex; gap: 12px; justify-content: center;">
                <button class="rg-btn rg-btn-secondary" onclick="closeDeleteModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button class="rg-btn rg-btn-danger" onclick="deleteLead()"><?php _e('Delete', 'rental-gates'); ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Add Interest Modal -->
<div class="rg-modal-overlay" id="addInterestModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3><?php _e('Add Interest', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeAddInterestModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="addInterestForm" class="rg-modal-body">
            <div class="rg-form-group">
                <label><?php _e('Property', 'rental-gates'); ?></label>
                <select name="building_id" required>
                    <option value=""><?php _e('Select a property', 'rental-gates'); ?></option>
                    <?php foreach ($buildings as $building): ?>
                        <option value="<?php echo $building['id']; ?>"><?php echo esc_html($building['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="rg-form-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeAddInterestModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Add Interest', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
const leadId = <?php echo $lead_id; ?>;
const nonce = '<?php echo wp_create_nonce('rental_gates_nonce'); ?>';

// Modal functions
function openEditModal() { document.getElementById('editModal').classList.add('open'); }
function closeEditModal() { document.getElementById('editModal').classList.remove('open'); }
function openScheduleModal() { document.getElementById('scheduleModal').classList.add('open'); }
function closeScheduleModal() { document.getElementById('scheduleModal').classList.remove('open'); }
function openLostModal() { document.getElementById('lostModal').classList.add('open'); }
function closeLostModal() { document.getElementById('lostModal').classList.remove('open'); }
function openDeleteModal() { document.getElementById('deleteModal').classList.add('open'); }
function closeDeleteModal() { document.getElementById('deleteModal').classList.remove('open'); }
function openAddInterestModal() { document.getElementById('addInterestModal').classList.add('open'); }
function closeAddInterestModal() { document.getElementById('addInterestModal').classList.remove('open'); }

// Update stage
async function updateStage(stage) {
    const formData = new FormData();
    formData.append('action', 'rental_gates_update_lead');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    formData.append('stage', stage);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error updating stage');
        }
    } catch (error) {
        alert('Error updating stage');
    }
}

// Add note
async function addNote() {
    const note = document.getElementById('newNote').value.trim();
    if (!note) return;
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_add_lead_note');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    formData.append('note', note);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error adding note');
        }
    } catch (error) {
        alert('Error adding note');
    }
}

// Edit form
document.getElementById('editLeadForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_update_lead');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error updating lead');
        }
    } catch (error) {
        alert('Error updating lead');
    }
});

// Schedule form
document.getElementById('scheduleForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_update_lead');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error scheduling follow-up');
        }
    } catch (error) {
        alert('Error scheduling follow-up');
    }
});

// Lost form
document.getElementById('lostForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_update_lead');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    formData.append('stage', 'lost');
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error updating lead');
        }
    } catch (error) {
        alert('Error updating lead');
    }
});

// Delete lead
async function deleteLead() {
    const formData = new FormData();
    formData.append('action', 'rental_gates_delete_lead');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/leads'); ?>';
        } else {
            alert(result.data?.message || 'Error deleting lead');
        }
    } catch (error) {
        alert('Error deleting lead');
    }
}

// Add interest form
document.getElementById('addInterestForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_add_lead_interest');
    formData.append('nonce', nonce);
    formData.append('lead_id', leadId);
    
    try {
        const response = await fetch(ajaxurl, { method: 'POST', body: formData });
        const result = await response.json();
        if (result.success) {
            location.reload();
        } else {
            alert(result.data?.message || 'Error adding interest');
        }
    } catch (error) {
        alert('Error adding interest');
    }
});

// Close modals on outside click and escape
document.querySelectorAll('.rg-modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.rg-modal-overlay.open').forEach(m => m.classList.remove('open'));
    }
});
</script>
