<?php
/**
 * Vendor Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get vendor ID from URL
$vendor_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/vendors/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $vendor_id = intval($matches[1]);
    }
}

if (!$vendor_id) {
    wp_redirect(home_url('/rental-gates/dashboard/vendors'));
    exit;
}

$vendor = Rental_Gates_Vendor::get_with_stats($vendor_id);

if (!$vendor || $vendor['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/vendors'));
    exit;
}

// Get recent assignments
$assignments = Rental_Gates_Vendor::get_assignments($vendor_id, null, 10);

// Status config
$status_config = array(
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'paused' => array('label' => __('Paused', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'inactive' => array('label' => __('Inactive', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

$assignment_status_config = array(
    'assigned' => array('label' => __('Assigned', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'accepted' => array('label' => __('Accepted', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'completed' => array('label' => __('Completed', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
);

$priority_config = array(
    'emergency' => array('label' => __('Emergency', 'rental-gates'), 'color' => '#dc2626'),
    'high' => array('label' => __('High', 'rental-gates'), 'color' => '#f59e0b'),
    'medium' => array('label' => __('Medium', 'rental-gates'), 'color' => '#3b82f6'),
    'low' => array('label' => __('Low', 'rental-gates'), 'color' => '#6b7280'),
);

$categories = Rental_Gates_Vendor::get_service_categories();
$status_style = $status_config[$vendor['status']] ?? $status_config['inactive'];
$initials = strtoupper(substr($vendor['company_name'], 0, 1) . (isset($vendor['company_name'][strpos($vendor['company_name'], ' ') + 1]) ? $vendor['company_name'][strpos($vendor['company_name'], ' ') + 1] : substr($vendor['company_name'], 1, 1)));
?>

<style>
    .rg-vendor-detail-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-vendor-title-row { display: flex; align-items: center; gap: 16px; }
    .rg-vendor-avatar-lg { width: 64px; height: 64px; border-radius: 16px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 24px; flex-shrink: 0; }
    .rg-vendor-title h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0 0 4px 0; display: flex; align-items: center; gap: 12px; }
    .rg-vendor-subtitle { font-size: 15px; color: var(--gray-500); }
    .rg-header-actions { display: flex; gap: 8px; }
    
    .rg-status-badge { display: inline-flex; align-items: center; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    
    .rg-detail-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; }
    
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
    .rg-card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .rg-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    
    .rg-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 20px; }
    .rg-stat-box { background: var(--gray-50); border-radius: 10px; padding: 16px; text-align: center; }
    .rg-stat-box-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-box-label { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; font-weight: 500; color: var(--gray-500); margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
    .rg-info-value { font-size: 15px; color: var(--gray-900); }
    .rg-info-value a { color: #3b82f6; text-decoration: none; }
    .rg-info-value a:hover { text-decoration: underline; }
    
    .rg-category-tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .rg-category-tag { display: inline-flex; align-items: center; padding: 5px 12px; background: #eff6ff; color: #3b82f6; border-radius: 6px; font-size: 13px; font-weight: 500; }
    
    .rg-assignments-list { }
    .rg-assignment-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--gray-100); }
    .rg-assignment-item:last-child { border-bottom: none; }
    .rg-assignment-info { display: flex; flex-direction: column; gap: 4px; }
    .rg-assignment-title { font-weight: 500; color: var(--gray-900); }
    .rg-assignment-title a { color: inherit; text-decoration: none; }
    .rg-assignment-title a:hover { color: #3b82f6; }
    .rg-assignment-meta { font-size: 13px; color: var(--gray-500); }
    .rg-assignment-status { display: flex; align-items: center; gap: 8px; }
    
    .rg-notes-content { white-space: pre-wrap; font-size: 14px; color: var(--gray-700); line-height: 1.6; }
    
    .rg-danger-zone { border-color: #fecaca; background: #fef2f2; }
    .rg-danger-zone .rg-card-title { color: #dc2626; }
    
    .rg-action-btn { padding: 8px 16px; border: 1px solid var(--gray-300); background: #fff; border-radius: 8px; font-size: 14px; color: var(--gray-700); cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }
    .rg-action-btn:hover { background: var(--gray-50); border-color: var(--gray-400); }
    .rg-action-btn.primary { background: #3b82f6; border-color: #3b82f6; color: #fff; }
    .rg-action-btn.primary:hover { background: #2563eb; }
    .rg-action-btn.danger { background: #dc2626; border-color: #dc2626; color: #fff; }
    .rg-action-btn.danger:hover { background: #b91c1c; }
    .rg-action-btn.outline-danger { border-color: #dc2626; color: #dc2626; }
    .rg-action-btn.outline-danger:hover { background: #fef2f2; }
    
    .rg-back-link { display: inline-flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--gray-700); }
    
    .rg-empty-assignments { text-align: center; padding: 40px 20px; color: var(--gray-500); }
    
    @media (max-width: 900px) {
        .rg-detail-grid { grid-template-columns: 1fr; }
        .rg-stats-grid { grid-template-columns: repeat(2, 1fr); }
        .rg-info-grid { grid-template-columns: 1fr; }
    }
</style>

<a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors')); ?>" class="rg-back-link">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M19 12H5M12 19l-7-7 7-7"/>
    </svg>
    <?php _e('Back to Vendors', 'rental-gates'); ?>
</a>

<div class="rg-vendor-detail-header">
    <div class="rg-vendor-title-row">
        <div class="rg-vendor-avatar-lg"><?php echo esc_html($initials); ?></div>
        <div class="rg-vendor-title">
            <h1>
                <?php echo esc_html($vendor['company_name']); ?>
                <span class="rg-status-badge" style="background: <?php echo esc_attr($status_style['bg']); ?>; color: <?php echo esc_attr($status_style['color']); ?>;">
                    <?php echo esc_html($status_style['label']); ?>
                </span>
            </h1>
            <div class="rg-vendor-subtitle"><?php echo esc_html($vendor['contact_name']); ?></div>
        </div>
    </div>
    <div class="rg-header-actions">
        <?php if ($vendor['user_id']): ?>
            <span class="rg-action-btn" style="background: #d1fae5; color: #065f46; cursor: default;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                <?php _e('Portal Access Granted', 'rental-gates'); ?>
            </span>
        <?php else: ?>
            <button onclick="inviteVendor(<?php echo $vendor['id']; ?>)" class="rg-action-btn rg-action-btn-primary" id="inviteBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
                </svg>
                <?php _e('Invite to Portal', 'rental-gates'); ?>
            </button>
        <?php endif; ?>
        <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors/' . $vendor['id'] . '/edit')); ?>" class="rg-action-btn">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
            <?php _e('Edit', 'rental-gates'); ?>
        </a>
    </div>
</div>

<!-- Stats -->
<div class="rg-stats-grid">
    <div class="rg-stat-box">
        <div class="rg-stat-box-value"><?php echo intval($vendor['total_assignments'] ?? 0); ?></div>
        <div class="rg-stat-box-label"><?php _e('Total Jobs', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-box">
        <div class="rg-stat-box-value" style="color: #10b981;"><?php echo intval($vendor['completed_jobs'] ?? 0); ?></div>
        <div class="rg-stat-box-label"><?php _e('Completed', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-box">
        <div class="rg-stat-box-value" style="color: #8b5cf6;"><?php echo intval($vendor['active_jobs'] ?? 0); ?></div>
        <div class="rg-stat-box-label"><?php _e('Active Jobs', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-box">
        <div class="rg-stat-box-value" style="color: #3b82f6;">$<?php echo number_format($vendor['total_earnings'] ?? 0, 0); ?></div>
        <div class="rg-stat-box-label"><?php _e('Total Earnings', 'rental-gates'); ?></div>
    </div>
</div>

<div class="rg-detail-grid">
    <!-- Main Content -->
    <div class="rg-detail-main">
        <!-- Contact Information -->
        <div class="rg-card">
            <h3 class="rg-card-title"><?php _e('Contact Information', 'rental-gates'); ?></h3>
            <div class="rg-info-grid">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Email', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><a href="mailto:<?php echo esc_attr($vendor['email']); ?>"><?php echo esc_html($vendor['email']); ?></a></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Phone', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><a href="tel:<?php echo esc_attr($vendor['phone']); ?>"><?php echo esc_html($vendor['phone']); ?></a></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Contact Person', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo esc_html($vendor['contact_name']); ?></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Hourly Rate', 'rental-gates'); ?></div>
                    <div class="rg-info-value">
                        <?php if ($vendor['hourly_rate']): ?>
                            $<?php echo number_format($vendor['hourly_rate'], 2); ?>/hr
                        <?php else: ?>
                            <span style="color: var(--gray-400);">—</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Service Categories -->
        <div class="rg-card">
            <h3 class="rg-card-title"><?php _e('Service Categories', 'rental-gates'); ?></h3>
            <?php if (!empty($vendor['service_categories'])): ?>
                <div class="rg-category-tags">
                    <?php foreach ($vendor['service_categories_labels'] as $cat): ?>
                        <span class="rg-category-tag"><?php echo esc_html($cat); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: var(--gray-500); margin: 0;"><?php _e('No service categories specified.', 'rental-gates'); ?></p>
            <?php endif; ?>
        </div>
        
        <!-- Recent Assignments -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3 class="rg-card-title"><?php _e('Work Order History', 'rental-gates'); ?></h3>
            </div>
            
            <?php if (empty($assignments)): ?>
                <div class="rg-empty-assignments">
                    <p><?php _e('No work orders assigned yet.', 'rental-gates'); ?></p>
                </div>
            <?php else: ?>
                <div class="rg-assignments-list">
                    <?php foreach ($assignments as $assignment): 
                        $a_status = $assignment_status_config[$assignment['status']] ?? $assignment_status_config['assigned'];
                        $p_config = $priority_config[$assignment['work_order_priority']] ?? $priority_config['medium'];
                    ?>
                        <div class="rg-assignment-item">
                            <div class="rg-assignment-info">
                                <div class="rg-assignment-title">
                                    <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/maintenance/' . $assignment['work_order_id'])); ?>">
                                        <?php echo esc_html($assignment['work_order_title']); ?>
                                    </a>
                                </div>
                                <div class="rg-assignment-meta">
                                    <?php if ($assignment['unit_name']): ?>
                                        <?php echo esc_html($assignment['unit_name']); ?> • 
                                    <?php endif; ?>
                                    <?php echo esc_html($assignment['building_name'] ?? ''); ?> • 
                                    <?php echo date_i18n(get_option('date_format'), strtotime($assignment['assigned_at'])); ?>
                                </div>
                            </div>
                            <div class="rg-assignment-status">
                                <span class="rg-status-badge" style="background: <?php echo esc_attr($a_status['bg']); ?>; color: <?php echo esc_attr($a_status['color']); ?>;">
                                    <?php echo esc_html($a_status['label']); ?>
                                </span>
                                <?php if ($assignment['cost']): ?>
                                    <span style="font-weight: 600; color: var(--gray-700);">$<?php echo number_format($assignment['cost'], 2); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="rg-detail-aside">
        <!-- Notes -->
        <?php if ($vendor['notes']): ?>
            <div class="rg-card">
                <h3 class="rg-card-title"><?php _e('Notes', 'rental-gates'); ?></h3>
                <div class="rg-notes-content"><?php echo esc_html($vendor['notes']); ?></div>
            </div>
        <?php endif; ?>
        
        <!-- Quick Info -->
        <div class="rg-card">
            <h3 class="rg-card-title"><?php _e('Quick Info', 'rental-gates'); ?></h3>
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Vendor ID', 'rental-gates'); ?></div>
                    <div class="rg-info-value">#<?php echo esc_html($vendor['id']); ?></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Added', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date_i18n(get_option('date_format'), strtotime($vendor['created_at'])); ?></div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Last Updated', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date_i18n(get_option('date_format'), strtotime($vendor['updated_at'])); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Danger Zone -->
        <div class="rg-card rg-danger-zone">
            <h3 class="rg-card-title"><?php _e('Danger Zone', 'rental-gates'); ?></h3>
            <p style="font-size: 13px; color: var(--gray-600); margin: 0 0 12px 0;">
                <?php _e('Deleting this vendor cannot be undone. All assignment history will also be deleted.', 'rental-gates'); ?>
            </p>
            <button type="button" class="rg-action-btn outline-danger" onclick="deleteVendor(<?php echo intval($vendor['id']); ?>)">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
                <?php _e('Delete Vendor', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<script>
function deleteVendor(vendorId, vendorName) {
    RentalGates.confirmDelete({
        title: '<?php echo esc_js(__('Delete Vendor', 'rental-gates')); ?>',
        message: '<?php echo esc_js(__('Are you sure you want to delete this vendor? This action cannot be undone.', 'rental-gates')); ?>',
        itemName: vendorName || '<?php echo esc_js($vendor['company_name'] ?? ''); ?>',
        ajaxAction: 'rental_gates_delete_vendor',
        ajaxData: { vendor_id: vendorId },
        redirectUrl: '<?php echo esc_url(home_url('/rental-gates/dashboard/vendors')); ?>'
    });
}

function inviteVendor(vendorId) {
    RentalGates.confirmDelete({
        title: '<?php echo esc_js(__('Send Portal Invitation', 'rental-gates')); ?>',
        message: '<?php echo esc_js(__('Send portal invitation to this vendor? They will receive an email with login credentials.', 'rental-gates')); ?>',
        ajaxAction: 'rental_gates_invite_vendor',
        ajaxData: { vendor_id: vendorId },
        onConfirm: function() {
            RentalGates.showToast('<?php echo esc_js(__('Invitation sent successfully!', 'rental-gates')); ?>', 'success');
            location.reload();
        }
    });
}
</script>
