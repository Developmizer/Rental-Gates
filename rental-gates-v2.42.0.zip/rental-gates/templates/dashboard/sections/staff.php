<?php
/**
 * Staff Management - List View
 * Allows property managers to view, add, and manage staff members
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Ensure org_id is set
if (empty($org_id)) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Check for success messages
$show_invited_toast = isset($_GET['invited']) && $_GET['invited'] == '1';
$show_updated_toast = isset($_GET['updated']) && $_GET['updated'] == '1';
$show_removed_toast = isset($_GET['removed']) && $_GET['removed'] == '1';

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Build query
$where = array("om.organization_id = %d", "om.role = 'staff'");
$params = array($org_id);

if ($status_filter) {
    $where[] = "om.status = %s";
    $params[] = $status_filter;
}

if ($search) {
    $where[] = "(u.display_name LIKE %s OR u.user_email LIKE %s)";
    $search_like = '%' . $wpdb->esc_like($search) . '%';
    $params[] = $search_like;
    $params[] = $search_like;
}

$where_sql = implode(' AND ', $where);

// Get staff members
$staff_members = $wpdb->get_results($wpdb->prepare(
    "SELECT om.*, u.display_name, u.user_email, u.user_registered,
            um_phone.meta_value as phone
     FROM {$tables['organization_members']} om
     JOIN {$wpdb->users} u ON om.user_id = u.ID
     LEFT JOIN {$wpdb->usermeta} um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'phone'
     WHERE {$where_sql}
     ORDER BY om.created_at DESC",
    $params
), ARRAY_A);

// Get stats
$stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive
     FROM {$tables['organization_members']}
     WHERE organization_id = %d AND role = 'staff'",
    $org_id
), ARRAY_A);

// Module definitions for permission display
$modules = array(
    'buildings' => array('label' => 'Buildings & Units', 'icon' => '🏢'),
    'tenants' => array('label' => 'Tenants', 'icon' => '👥'),
    'leases' => array('label' => 'Leases', 'icon' => '📋'),
    'applications' => array('label' => 'Applications', 'icon' => '📝'),
    'maintenance' => array('label' => 'Maintenance', 'icon' => '🔧'),
    'payments' => array('label' => 'Payments', 'icon' => '💳'),
    'vendors' => array('label' => 'Vendors', 'icon' => '🏪'),
    'leads' => array('label' => 'Leads', 'icon' => '🎯'),
);
?>

<style>
    /* Toast Notifications */
    .rg-toast { position: fixed; top: 24px; right: 24px; z-index: 9999; display: flex; align-items: center; gap: 12px; padding: 16px 20px; background: #fff; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border-left: 4px solid #10b981; animation: slideIn 0.3s ease, fadeOut 0.3s ease 4.7s forwards; max-width: 400px; }
    .rg-toast.success { border-left-color: #10b981; }
    .rg-toast-icon { width: 24px; height: 24px; border-radius: 50%; background: #d1fae5; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-toast-icon svg { width: 14px; height: 14px; color: #10b981; }
    .rg-toast-content h4 { margin: 0 0 2px; font-size: 14px; font-weight: 600; color: var(--gray-900); }
    .rg-toast-content p { margin: 0; font-size: 13px; color: var(--gray-500); }
    .rg-toast-close { background: none; border: none; color: var(--gray-400); cursor: pointer; padding: 4px; margin-left: 8px; }
    .rg-toast-close:hover { color: var(--gray-600); }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; visibility: hidden; } }
    
    .rg-page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-page-title { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; text-align: center; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-bottom: 8px; }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-value.success { color: #10b981; }
    .rg-stat-value.warning { color: #f59e0b; }
    
    .rg-filters { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }
    .rg-search-box { flex: 1; min-width: 200px; position: relative; }
    .rg-search-box input { width: 100%; padding: 10px 12px 10px 40px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); }
    .rg-filter-select { padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background: #fff; }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
    .rg-btn-secondary:hover { background: var(--gray-200); }
    .rg-btn-sm { padding: 6px 12px; font-size: 13px; }
    
    .rg-staff-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 20px; }
    
    .rg-staff-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; transition: box-shadow 0.2s; }
    .rg-staff-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    
    .rg-staff-header { display: flex; align-items: center; gap: 16px; padding: 20px; border-bottom: 1px solid var(--gray-100); }
    .rg-staff-avatar { width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; font-weight: 600; flex-shrink: 0; }
    .rg-staff-info { flex: 1; min-width: 0; }
    .rg-staff-name { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0 0 4px; }
    .rg-staff-email { font-size: 13px; color: var(--gray-500); margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    
    .rg-staff-status { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-staff-status.active { background: #d1fae5; color: #065f46; }
    .rg-staff-status.pending { background: #fef3c7; color: #92400e; }
    .rg-staff-status.inactive { background: #fee2e2; color: #991b1b; }
    
    .rg-staff-permissions { padding: 16px 20px; background: var(--gray-50); }
    .rg-permissions-title { font-size: 11px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; margin-bottom: 10px; }
    .rg-permissions-list { display: flex; flex-wrap: wrap; gap: 6px; }
    .rg-permission-badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 8px; background: #fff; border: 1px solid var(--gray-200); border-radius: 6px; font-size: 12px; color: var(--gray-700); }
    .rg-permission-badge.view { border-color: #93c5fd; background: #eff6ff; }
    .rg-permission-badge.edit { border-color: #86efac; background: #f0fdf4; }
    .rg-permission-badge.full { border-color: #c4b5fd; background: #f5f3ff; }
    .rg-permission-badge.none { opacity: 0.5; }
    
    .rg-staff-actions { display: flex; gap: 8px; padding: 16px 20px; border-top: 1px solid var(--gray-100); }
    .rg-staff-actions .rg-btn { flex: 1; justify-content: center; }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; background: #fff; border-radius: 12px; border: 1px solid var(--gray-200); }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { color: var(--gray-900); margin: 0 0 8px; }
    .rg-empty-state p { color: var(--gray-500); margin: 0 0 20px; }
    
    @media (max-width: 1024px) {
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 768px) {
        .rg-stats-row { grid-template-columns: 1fr 1fr; }
        .rg-staff-grid { grid-template-columns: 1fr; }
    }
</style>

<?php if ($show_invited_toast): ?>
<div class="rg-toast success" id="successToast">
    <div class="rg-toast-icon">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    </div>
    <div class="rg-toast-content">
        <h4><?php _e('Invitation Sent!', 'rental-gates'); ?></h4>
        <p><?php _e('The staff member will receive an email with login instructions.', 'rental-gates'); ?></p>
    </div>
    <button class="rg-toast-close" onclick="this.parentElement.remove()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
</div>
<?php endif; ?>

<?php if ($show_updated_toast): ?>
<div class="rg-toast success" id="successToast">
    <div class="rg-toast-icon">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    </div>
    <div class="rg-toast-content">
        <h4><?php _e('Staff Updated', 'rental-gates'); ?></h4>
        <p><?php _e('The staff member\'s permissions have been saved.', 'rental-gates'); ?></p>
    </div>
    <button class="rg-toast-close" onclick="this.parentElement.remove()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
</div>
<?php endif; ?>

<?php if ($show_removed_toast): ?>
<div class="rg-toast success" id="successToast">
    <div class="rg-toast-icon">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    </div>
    <div class="rg-toast-content">
        <h4><?php _e('Staff Removed', 'rental-gates'); ?></h4>
        <p><?php _e('The staff member has been removed from your organization.', 'rental-gates'); ?></p>
    </div>
    <button class="rg-toast-close" onclick="this.parentElement.remove()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
</div>
<?php endif; ?>

<script>
// Auto-remove toast after 5 seconds and clean URL
setTimeout(function() {
    var toast = document.getElementById('successToast');
    if (toast) toast.remove();
    // Clean URL parameters
    if (window.history.replaceState) {
        var url = window.location.href.split('?')[0];
        window.history.replaceState({}, document.title, url);
    }
}, 5000);
</script>

<!-- Page Header -->
<div class="rg-page-header">
    <h1 class="rg-page-title"><?php _e('Staff Members', 'rental-gates'); ?></h1>
    <a href="<?php echo home_url('/rental-gates/dashboard/staff/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
        <?php _e('Invite Staff', 'rental-gates'); ?>
    </a>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Total Staff', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo intval($stats['total']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Active', 'rental-gates'); ?></div>
        <div class="rg-stat-value success"><?php echo intval($stats['active']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Pending Invites', 'rental-gates'); ?></div>
        <div class="rg-stat-value warning"><?php echo intval($stats['pending']); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Inactive', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo intval($stats['inactive']); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" class="rg-filters">
    <div class="rg-search-box">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Search by name or email...', 'rental-gates'); ?>">
    </div>
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
        <option value="pending" <?php selected($status_filter, 'pending'); ?>><?php _e('Pending', 'rental-gates'); ?></option>
        <option value="inactive" <?php selected($status_filter, 'inactive'); ?>><?php _e('Inactive', 'rental-gates'); ?></option>
    </select>
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
</form>

<!-- Staff Grid -->
<?php if (empty($staff_members)): ?>
<div class="rg-empty-state">
    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
    <h3><?php _e('No staff members yet', 'rental-gates'); ?></h3>
    <p><?php _e('Invite team members to help manage your properties. You can control exactly what each person can access.', 'rental-gates'); ?></p>
    <a href="<?php echo home_url('/rental-gates/dashboard/staff/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
        <?php _e('Invite Your First Staff Member', 'rental-gates'); ?>
    </a>
</div>
<?php else: ?>
<div class="rg-staff-grid">
    <?php foreach ($staff_members as $staff): 
        $permissions = json_decode($staff['permissions'] ?? '{}', true) ?: array();
        $initials = strtoupper(substr($staff['display_name'], 0, 1) . substr(strstr($staff['display_name'], ' '), 1, 1));
        if (strlen($initials) < 2) $initials = strtoupper(substr($staff['display_name'], 0, 2));
    ?>
    <div class="rg-staff-card">
        <div class="rg-staff-header">
            <div class="rg-staff-avatar"><?php echo esc_html($initials); ?></div>
            <div class="rg-staff-info">
                <h3 class="rg-staff-name"><?php echo esc_html($staff['display_name']); ?></h3>
                <p class="rg-staff-email"><?php echo esc_html($staff['user_email']); ?></p>
            </div>
            <span class="rg-staff-status <?php echo esc_attr($staff['status']); ?>">
                <?php 
                $status_labels = array(
                    'active' => __('Active', 'rental-gates'),
                    'pending' => __('Invite Pending', 'rental-gates'),
                    'inactive' => __('Inactive', 'rental-gates'),
                );
                echo esc_html($status_labels[$staff['status']] ?? ucfirst($staff['status'])); 
                ?>
            </span>
        </div>
        
        <div class="rg-staff-permissions">
            <div class="rg-permissions-title"><?php _e('Permissions', 'rental-gates'); ?></div>
            <div class="rg-permissions-list">
                <?php 
                $has_any = false;
                foreach ($modules as $key => $module): 
                    $perm = $permissions[$key] ?? 'none';
                    if ($perm !== 'none') $has_any = true;
                ?>
                    <?php if ($perm !== 'none'): ?>
                    <span class="rg-permission-badge <?php echo esc_attr($perm); ?>">
                        <?php echo $module['icon']; ?> <?php echo esc_html($module['label']); ?>
                        <small>(<?php echo esc_html($perm); ?>)</small>
                    </span>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php if (!$has_any): ?>
                <span class="rg-permission-badge none"><?php _e('No permissions assigned', 'rental-gates'); ?></span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="rg-staff-actions">
            <a href="<?php echo home_url('/rental-gates/dashboard/staff/' . $staff['id']); ?>" class="rg-btn rg-btn-secondary rg-btn-sm">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                <?php _e('View', 'rental-gates'); ?>
            </a>
            <a href="<?php echo home_url('/rental-gates/dashboard/staff/' . $staff['id'] . '/edit'); ?>" class="rg-btn rg-btn-primary rg-btn-sm">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                <?php _e('Edit', 'rental-gates'); ?>
            </a>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
