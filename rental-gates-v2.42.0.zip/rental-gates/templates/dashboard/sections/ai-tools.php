<?php
/**
 * AI Tools Section - Dashboard
 * Comprehensive AI-powered tools for property management.
 * @since 2.14.0
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
$user_id = get_current_user_id();

// Handle purchase success/cancelled from Stripe redirect
$purchase_status = isset($_GET['purchase']) ? sanitize_key($_GET['purchase']) : '';
$session_id = isset($_GET['session_id']) ? sanitize_text_field($_GET['session_id']) : '';
$purchase_message = '';
$purchase_error = '';

if ($purchase_status === 'success' && $session_id) {
    // Verify and complete the purchase
    if (class_exists('Rental_Gates_Stripe')) {
        $result = Rental_Gates_Stripe::complete_credit_purchase_from_session($session_id);
        if (is_wp_error($result)) {
            $purchase_error = $result->get_error_message();
        } else {
            $purchase_message = __('AI credits purchased successfully! Your balance has been updated.', 'rental-gates');
        }
    }
} elseif ($purchase_status === 'cancelled') {
    $purchase_error = __('Purchase was cancelled. No charges were made.', 'rental-gates');
}

// Safety check - ensure AI class exists
if (!class_exists('Rental_Gates_AI')) {
    echo '<div class="rg-alert error">AI module not loaded. Please contact support.</div>';
    return;
}

// Check if AI is enabled
$ai_enabled = Rental_Gates_AI::is_enabled();
$has_access = $org_id ? Rental_Gates_AI::org_has_access($org_id) : false;
$ai = rental_gates_ai();
$is_configured = $ai->is_configured();

// Get usage stats (with safety check) - refresh after potential purchase
$usage_stats = $org_id ? Rental_Gates_AI::get_usage_stats($org_id) : array(
    'monthly_limit' => 0,
    'used' => 0,
    'remaining' => 0,
    'reset_date' => date('Y-m-01', strtotime('+1 month')),
    'by_tool' => array(),
);
$history = $org_id ? Rental_Gates_AI::get_history($org_id, 10) : array();

// Tool definitions
$tools = array(
    'description' => array(
        'name' => __('Property Descriptions', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>',
        'description' => __('Generate compelling listing descriptions', 'rental-gates'),
        'credits' => 1,
        'color' => '#3b82f6',
    ),
    'marketing' => array(
        'name' => __('Marketing Copy', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>',
        'description' => __('Create ads, social posts, and flyers', 'rental-gates'),
        'credits' => 1,
        'color' => '#8b5cf6',
    ),
    'screening' => array(
        'name' => __('Tenant Screening', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>',
        'description' => __('AI risk assessment for applicants', 'rental-gates'),
        'credits' => 3,
        'color' => '#10b981',
    ),
    'maintenance' => array(
        'name' => __('Maintenance Triage', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>',
        'description' => __('Smart categorization and prioritization', 'rental-gates'),
        'credits' => 1,
        'color' => '#f59e0b',
    ),
    'message' => array(
        'name' => __('Message Drafts', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>',
        'description' => __('Professional tenant communications', 'rental-gates'),
        'credits' => 1,
        'color' => '#ec4899',
    ),
    'insights' => array(
        'name' => __('Portfolio Insights', 'rental-gates'),
        'icon' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>',
        'description' => __('AI-driven analytics and recommendations', 'rental-gates'),
        'credits' => 2,
        'color' => '#06b6d4',
    ),
);

// Get buildings and units for dynamic entity selection
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// Debug: Check org_id and query results
$debug_info = array(
    'org_id' => $org_id,
    'user_id' => $user_id,
    'tables_set' => !empty($tables),
    'buildings_table' => $tables['buildings'] ?? 'not set',
    'units_table' => $tables['units'] ?? 'not set',
);

$org_buildings = array();
$org_units = array();

if ($org_id && !empty($tables)) {
    // Get buildings
    $buildings_sql = $wpdb->prepare(
        "SELECT b.*, 
                (SELECT COUNT(*) FROM {$tables['units']} WHERE building_id = b.id) as unit_count
         FROM {$tables['buildings']} b 
         WHERE b.organization_id = %d 
         ORDER BY b.name",
        $org_id
    );
    $org_buildings = $wpdb->get_results($buildings_sql, ARRAY_A) ?: array();
    
    $debug_info['buildings_count'] = count($org_buildings);
    $debug_info['buildings_query_error'] = $wpdb->last_error;
    
    // Get units
    $units_sql = $wpdb->prepare(
        "SELECT u.*, b.name as building_name, b.derived_address as building_address
         FROM {$tables['units']} u
         JOIN {$tables['buildings']} b ON u.building_id = b.id
         WHERE b.organization_id = %d
         ORDER BY b.name, u.name",
        $org_id
    );
    $org_units = $wpdb->get_results($units_sql, ARRAY_A) ?: array();
    
    $debug_info['units_count'] = count($org_units);
    $debug_info['units_query_error'] = $wpdb->last_error;
} else {
    $debug_info['skip_reason'] = !$org_id ? 'no_org_id' : 'no_tables';
}

// Handle POST
$result = null;
$error = null;
$active_tool = isset($_GET['tool']) ? sanitize_key($_GET['tool']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ai_action'])) {
    if (!wp_verify_nonce($_POST['ai_nonce'] ?? '', 'ai_tools')) {
        $error = __('Security check failed.', 'rental-gates');
    } elseif (!$has_access) {
        $error = __('Your plan does not include AI tools.', 'rental-gates');
    } elseif (!$is_configured) {
        $error = __('AI provider not configured.', 'rental-gates');
    } else {
        $action = sanitize_key($_POST['ai_action']);
        
        switch ($action) {
            case 'generate_description':
                $result = $ai->generate_description(array(
                    'name' => sanitize_text_field($_POST['property_name'] ?? ''),
                    'unit_type' => sanitize_text_field($_POST['unit_type'] ?? ''),
                    'bedrooms' => intval($_POST['bedrooms'] ?? 0),
                    'bathrooms' => floatval($_POST['bathrooms'] ?? 0),
                    'sqft' => intval($_POST['sqft'] ?? 0),
                    'rent' => floatval($_POST['rent'] ?? 0),
                    'address' => sanitize_text_field($_POST['address'] ?? ''),
                    'features' => sanitize_textarea_field($_POST['features'] ?? ''),
                    'style' => sanitize_key($_POST['style'] ?? 'professional'),
                ));
                $active_tool = 'description';
                break;
                
            case 'generate_marketing':
                $result = $ai->generate_marketing(array(
                    'name' => sanitize_text_field($_POST['property_name'] ?? ''),
                    'rent' => floatval($_POST['rent'] ?? 0),
                    'bedrooms' => intval($_POST['bedrooms'] ?? 0),
                    'address' => sanitize_text_field($_POST['address'] ?? ''),
                    'highlights' => sanitize_textarea_field($_POST['highlights'] ?? ''),
                    'format' => sanitize_key($_POST['format'] ?? 'flyer'),
                ));
                $active_tool = 'marketing';
                break;
                
            case 'triage_maintenance':
                $result = $ai->triage_maintenance(array(
                    'title' => sanitize_text_field($_POST['title'] ?? ''),
                    'description' => sanitize_textarea_field($_POST['description'] ?? ''),
                    'location' => sanitize_text_field($_POST['location'] ?? ''),
                ));
                $active_tool = 'maintenance';
                break;
                
            case 'draft_message':
                $result = $ai->draft_message(array(
                    'type' => sanitize_key($_POST['message_type'] ?? 'general'),
                    'tone' => sanitize_key($_POST['tone'] ?? 'professional'),
                    'tenant_name' => sanitize_text_field($_POST['tenant_name'] ?? ''),
                    'property' => sanitize_text_field($_POST['property'] ?? ''),
                    'context' => sanitize_textarea_field($_POST['context'] ?? ''),
                    'specific_details' => sanitize_textarea_field($_POST['specific_details'] ?? ''),
                ));
                $active_tool = 'message';
                break;
                
            case 'portfolio_insights':
                $result = $ai->get_portfolio_insights();
                $active_tool = 'insights';
                break;
        }
        
        if (is_wp_error($result)) {
            $error = $result->get_error_message();
            $result = null;
        }
        
        // Refresh stats
        $usage_stats = Rental_Gates_AI::get_usage_stats($org_id);
    }
}
?>

<style>
/* AI Tools Styles */
.ai-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 24px;
    margin-bottom: 32px;
}
.ai-title h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 8px;
    display: flex;
    align-items: center;
    gap: 12px;
}
.ai-title p {
    color: var(--gray-600);
    margin: 0;
}
.ai-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    background: linear-gradient(135deg, #8b5cf6, #6366f1);
    color: #fff;
    border-radius: 100px;
    font-size: 12px;
    font-weight: 600;
}

/* Credits Card */
.credits-card {
    background: linear-gradient(135deg, #1e1b4b, #312e81);
    border-radius: 16px;
    padding: 20px 24px;
    color: #fff;
    min-width: 280px;
}
.credits-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}
.credits-label {
    font-size: 13px;
    opacity: 0.8;
}
.credits-reset {
    font-size: 11px;
    opacity: 0.6;
}
.credits-value {
    font-size: 36px;
    font-weight: 700;
    line-height: 1;
}
.credits-value span {
    font-size: 16px;
    opacity: 0.7;
}
.credits-bar {
    height: 6px;
    background: rgba(255,255,255,0.2);
    border-radius: 3px;
    margin-top: 16px;
    overflow: hidden;
}
.credits-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #34d399, #10b981);
    border-radius: 3px;
    transition: width 0.3s;
}
.credits-breakdown {
    display: flex;
    gap: 12px;
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px solid rgba(255,255,255,0.15);
}
.credit-pool {
    flex: 1;
    text-align: center;
}
.pool-label {
    display: block;
    font-size: 10px;
    text-transform: uppercase;
    opacity: 0.7;
    margin-bottom: 2px;
}
.pool-value {
    font-size: 16px;
    font-weight: 600;
}
.btn-buy-credits {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    width: 100%;
    margin-top: 12px;
    padding: 8px 16px;
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.3);
    border-radius: 8px;
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
}
.btn-buy-credits:hover {
    background: rgba(255,255,255,0.25);
}

/* Purchase Modal */
.credit-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s;
}
.credit-modal-overlay.active {
    opacity: 1;
    visibility: visible;
}
.credit-modal {
    background: #fff;
    border-radius: 16px;
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.95);
    transition: transform 0.2s;
}
.credit-modal-overlay.active .credit-modal {
    transform: scale(1);
}
.credit-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    border-bottom: 1px solid var(--gray-200);
}
.credit-modal-header h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.credit-modal-close {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    background: var(--gray-100);
    border-radius: 8px;
    cursor: pointer;
    color: var(--gray-600);
}
.credit-modal-close:hover {
    background: var(--gray-200);
}
.credit-modal-body {
    padding: 24px;
}
.credit-packs-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 20px;
}
.credit-pack {
    border: 2px solid var(--gray-200);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
}
.credit-pack:hover {
    border-color: var(--primary);
}
.credit-pack.selected {
    border-color: var(--primary);
    background: var(--primary-50);
}
.credit-pack-badge {
    position: absolute;
    top: -10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 12px;
    background: var(--primary);
    color: #fff;
    font-size: 11px;
    font-weight: 600;
    border-radius: 100px;
    white-space: nowrap;
}
.credit-pack-name {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--gray-900);
}
.credit-pack-credits {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 4px;
}
.credit-pack-credits span {
    font-size: 14px;
    font-weight: 400;
    color: var(--gray-600);
}
.credit-pack-price {
    font-size: 18px;
    font-weight: 600;
    color: var(--gray-900);
    margin-bottom: 4px;
}
.credit-pack-unit {
    font-size: 12px;
    color: var(--gray-500);
}
.credit-pack-savings {
    margin-top: 8px;
    font-size: 12px;
    color: #059669;
    font-weight: 500;
}
.credit-modal-features {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 16px;
    background: var(--gray-50);
    border-radius: 10px;
    margin-bottom: 20px;
}
.credit-modal-features span {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: var(--gray-600);
}
.credit-modal-features svg {
    width: 16px;
    height: 16px;
    color: #10b981;
}
.credit-modal-footer {
    padding: 16px 24px;
    border-top: 1px solid var(--gray-200);
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

/* Alert Warning State */
.ai-alert.warning {
    background: #fffbeb;
    border: 1px solid #fde68a;
    color: #92400e;
}

/* Tools Grid */
.tools-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 32px;
}
.tool-card {
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 16px;
    padding: 24px;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    color: inherit;
}
.tool-card:hover {
    border-color: var(--primary);
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transform: translateY(-2px);
}
.tool-card.active {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-100);
}
.tool-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 16px;
}
.tool-icon svg {
    width: 24px;
    height: 24px;
    color: #fff;
}
.tool-name {
    font-size: 16px;
    font-weight: 600;
    margin: 0 0 6px;
}
.tool-desc {
    font-size: 13px;
    color: var(--gray-600);
    margin: 0 0 12px;
}
.tool-credits {
    font-size: 12px;
    color: var(--gray-500);
    display: flex;
    align-items: center;
    gap: 4px;
}
.tool-credits svg {
    width: 14px;
    height: 14px;
}

/* Tool Panel */
.tool-panel {
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 16px;
    overflow: hidden;
    margin-bottom: 32px;
}
.tool-panel-header {
    padding: 20px 24px;
    border-bottom: 1px solid var(--gray-200);
    background: var(--gray-50);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.tool-panel-header h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}
.tool-panel-body {
    padding: 24px;
}

/* Form Styles */
.ai-form {
    display: grid;
    gap: 20px;
}
.ai-form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
}
.ai-form-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.ai-form-group label {
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-700);
}
.ai-form-group input,
.ai-form-group select,
.ai-form-group textarea {
    padding: 10px 14px;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s;
}
.ai-form-group input:focus,
.ai-form-group select:focus,
.ai-form-group textarea:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-100);
}
.ai-form-group textarea {
    min-height: 100px;
    resize: vertical;
}
.ai-form-actions {
    display: flex;
    gap: 12px;
    padding-top: 8px;
}

/* Result Styles */
.ai-result {
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}
.ai-result-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}
.ai-result-header h3 {
    font-size: 14px;
    font-weight: 600;
    margin: 0;
    color: var(--gray-700);
}
.ai-result-content {
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    padding: 16px;
    font-size: 14px;
    line-height: 1.7;
    white-space: pre-wrap;
}
.ai-result-meta {
    display: flex;
    gap: 16px;
    margin-top: 12px;
    font-size: 12px;
    color: var(--gray-500);
}

/* Insights Results */
.insights-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 16px;
    margin-bottom: 20px;
}
.insight-card {
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 12px;
    padding: 16px;
}
.insight-card h4 {
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-600);
    margin: 0 0 8px;
}
.insight-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--gray-900);
}
.health-score {
    text-align: center;
    padding: 24px;
}
.health-score-value {
    font-size: 64px;
    font-weight: 700;
    background: linear-gradient(135deg, #10b981, #059669);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.health-score-label {
    font-size: 14px;
    color: var(--gray-600);
}

/* Screening Results */
.screening-result {
    display: grid;
    gap: 20px;
}
.screening-header {
    display: flex;
    gap: 24px;
    align-items: center;
}
.risk-badge {
    padding: 8px 20px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
}
.risk-badge.low {
    background: #dcfce7;
    color: #166534;
}
.risk-badge.medium {
    background: #fef3c7;
    color: #92400e;
}
.risk-badge.high {
    background: #fee2e2;
    color: #991b1b;
}
.recommendation-badge {
    padding: 6px 14px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
}
.recommendation-badge.approve {
    background: #d1fae5;
    color: #065f46;
}
.recommendation-badge.review {
    background: #fef3c7;
    color: #92400e;
}
.recommendation-badge.decline {
    background: #fee2e2;
    color: #991b1b;
}
.factors-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}
.factors-card {
    padding: 16px;
    border-radius: 10px;
}
.factors-card.strengths {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
}
.factors-card.concerns {
    background: #fef2f2;
    border: 1px solid #fecaca;
}
.factors-card h4 {
    font-size: 13px;
    font-weight: 600;
    margin: 0 0 10px;
}
.factors-card ul {
    margin: 0;
    padding-left: 20px;
    font-size: 13px;
}
.factors-card li {
    margin-bottom: 6px;
}

/* Triage Results */
.triage-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
}
.triage-item {
    background: var(--gray-50);
    border-radius: 10px;
    padding: 14px;
}
.triage-item label {
    font-size: 11px;
    font-weight: 500;
    color: var(--gray-500);
    text-transform: uppercase;
    display: block;
    margin-bottom: 4px;
}
.triage-item .value {
    font-size: 15px;
    font-weight: 600;
    color: var(--gray-900);
}
.priority-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
}
.priority-badge.emergency {
    background: #fee2e2;
    color: #991b1b;
}
.priority-badge.high {
    background: #ffedd5;
    color: #9a3412;
}
.priority-badge.medium {
    background: #fef3c7;
    color: #92400e;
}
.priority-badge.low {
    background: #dcfce7;
    color: #166534;
}

/* History */
.history-section {
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 16px;
    overflow: hidden;
}
.history-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--gray-200);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.history-header h3 {
    font-size: 15px;
    font-weight: 600;
    margin: 0;
}
.history-list {
    max-height: 400px;
    overflow-y: auto;
}
.history-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 14px 20px;
    border-bottom: 1px solid var(--gray-100);
}
.history-item:last-child {
    border-bottom: none;
}
.history-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.history-icon svg {
    width: 18px;
    height: 18px;
    color: #fff;
}
.history-info {
    flex: 1;
}
.history-tool {
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-900);
}
.history-meta {
    font-size: 12px;
    color: var(--gray-500);
}
.history-credits {
    font-size: 12px;
    color: var(--gray-500);
}

/* Not Available State */
.ai-not-available {
    text-align: center;
    padding: 60px 40px;
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 16px;
}
.ai-not-available svg {
    width: 64px;
    height: 64px;
    color: var(--gray-400);
    margin-bottom: 20px;
}
.ai-not-available h2 {
    font-size: 20px;
    font-weight: 600;
    margin: 0 0 10px;
}
.ai-not-available p {
    color: var(--gray-600);
    margin: 0 0 24px;
    max-width: 400px;
    margin-left: auto;
    margin-right: auto;
}

/* Alert */
.ai-alert {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
}
.ai-alert svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
}
.ai-alert.error {
    background: #fef2f2;
    border: 1px solid #fecaca;
    color: #991b1b;
}
.ai-alert.success {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    color: #166534;
}

/* Copy Button */
.btn-copy {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: var(--gray-100);
    border: 1px solid var(--gray-300);
    border-radius: 6px;
    font-size: 12px;
    color: var(--gray-700);
    cursor: pointer;
    transition: all 0.2s;
}
.btn-copy:hover {
    background: var(--gray-200);
}
.btn-copy.copied {
    background: #d1fae5;
    border-color: #6ee7b7;
    color: #065f46;
}

@media (max-width: 768px) {
    .ai-header {
        flex-direction: column;
    }
    .credits-card {
        width: 100%;
        min-width: auto;
    }
    .tools-grid {
        grid-template-columns: 1fr;
    }
    .factors-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php if (!$ai_enabled): ?>
<!-- AI Not Enabled -->
<div class="ai-not-available">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
    </svg>
    <h2><?php _e('AI Tools Not Enabled', 'rental-gates'); ?></h2>
    <p><?php _e('AI features are currently disabled. Please contact your administrator.', 'rental-gates'); ?></p>
</div>

<?php elseif (!$has_access): ?>
<!-- No Access -->
<div class="ai-not-available">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
    </svg>
    <h2><?php _e('Upgrade to Access AI Tools', 'rental-gates'); ?></h2>
    <p><?php _e('AI-powered features are available on Silver and Gold plans.', 'rental-gates'); ?></p>
    <a href="<?php echo home_url('/rental-gates/dashboard/billing'); ?>" class="btn btn-primary"><?php _e('Upgrade Plan', 'rental-gates'); ?></a>
</div>

<?php elseif (!$is_configured): ?>
<!-- Not Configured -->
<div class="ai-not-available">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/>
    </svg>
    <h2><?php _e('AI Provider Not Configured', 'rental-gates'); ?></h2>
    <p><?php _e('The AI provider has not been configured yet. Please contact support.', 'rental-gates'); ?></p>
</div>

<?php else: ?>
<!-- AI Tools Dashboard -->

<?php
// Get credit packs for purchase modal
$credit_packs = array();
if (class_exists('Rental_Gates_AI_Credits')) {
    $credit_packs = rg_ai_credits()->get_credit_packs();
}

// Get enhanced balance info
$credit_status = $usage_stats['status'] ?? 'healthy';
$status_color = match($credit_status) {
    'empty' => '#ef4444',
    'low' => '#f59e0b',
    'warning' => '#eab308',
    default => '#10b981',
};
?>

<!-- Purchase Success/Error Notifications -->
<?php if (!empty($purchase_message)): ?>
<div class="ai-alert success" style="margin-bottom: 20px;">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <span><?php echo esc_html($purchase_message); ?></span>
</div>
<?php endif; ?>

<?php if (!empty($purchase_error)): ?>
<div class="ai-alert error" style="margin-bottom: 20px;">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <span><?php echo esc_html($purchase_error); ?></span>
</div>
<?php endif; ?>

<!-- Header -->
<div class="ai-header">
    <div class="ai-title">
        <h1>
            <?php _e('AI Tools', 'rental-gates'); ?>
            <span class="ai-badge">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                <?php _e('Powered by AI', 'rental-gates'); ?>
            </span>
        </h1>
        <p><?php _e('AI-powered tools to streamline your property management', 'rental-gates'); ?> <small style="color: #94a3b8;">(v2.16.1)</small></p>
    </div>
    
    <?php // Temporary debug banner - remove after fixing ?>
    <?php if (empty($org_units) && current_user_can('manage_options')): ?>
    <div style="background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px; font-size: 13px;">
        <strong style="color: #92400e;">🔍 Debug Info (admin only):</strong>
        <br>org_id: <code><?php echo $debug_info['org_id'] ?? 'null'; ?></code>
        | user_id: <code><?php echo $debug_info['user_id'] ?? 'null'; ?></code>
        | buildings: <code><?php echo $debug_info['buildings_count'] ?? 0; ?></code>
        | units: <code><?php echo $debug_info['units_count'] ?? 0; ?></code>
        <?php if (!empty($debug_info['skip_reason'])): ?>
        | skip: <code><?php echo $debug_info['skip_reason']; ?></code>
        <?php endif; ?>
        <?php if (!empty($debug_info['buildings_query_error'])): ?>
        <br>buildings error: <code><?php echo esc_html($debug_info['buildings_query_error']); ?></code>
        <?php endif; ?>
        <?php if (!empty($debug_info['units_query_error'])): ?>
        <br>units error: <code><?php echo esc_html($debug_info['units_query_error']); ?></code>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <div class="credits-card">
        <div class="credits-header">
            <span class="credits-label"><?php _e('AI Credits', 'rental-gates'); ?></span>
            <?php if (!empty($usage_stats['days_until_refresh'])): ?>
            <span class="credits-reset"><?php printf(__('Resets in %d days', 'rental-gates'), $usage_stats['days_until_refresh']); ?></span>
            <?php else: ?>
            <span class="credits-reset"><?php printf(__('Resets %s', 'rental-gates'), date_i18n('M j', strtotime($usage_stats['reset_date']))); ?></span>
            <?php endif; ?>
        </div>
        <div class="credits-value">
            <?php echo number_format($usage_stats['remaining']); ?>
            <span>/ <?php echo number_format($usage_stats['monthly_limit']); ?></span>
        </div>
        <div class="credits-bar">
            <div class="credits-bar-fill" style="width: <?php echo $usage_stats['monthly_limit'] > 0 ? min(100, (($usage_stats['monthly_limit'] - $usage_stats['used']) / $usage_stats['monthly_limit']) * 100) : 0; ?>%; background: <?php echo $status_color; ?>;"></div>
        </div>
        
        <?php if (isset($usage_stats['subscription_credits']) || isset($usage_stats['purchased_credits']) || isset($usage_stats['bonus_credits'])): ?>
        <div class="credits-breakdown">
            <div class="credit-pool">
                <span class="pool-label"><?php _e('Plan', 'rental-gates'); ?></span>
                <span class="pool-value"><?php echo number_format($usage_stats['subscription_credits'] ?? 0); ?></span>
            </div>
            <?php if (($usage_stats['purchased_credits'] ?? 0) > 0): ?>
            <div class="credit-pool">
                <span class="pool-label"><?php _e('Extra', 'rental-gates'); ?></span>
                <span class="pool-value"><?php echo number_format($usage_stats['purchased_credits']); ?></span>
            </div>
            <?php endif; ?>
            <?php if (($usage_stats['bonus_credits'] ?? 0) > 0): ?>
            <div class="credit-pool">
                <span class="pool-label"><?php _e('Bonus', 'rental-gates'); ?></span>
                <span class="pool-value"><?php echo number_format($usage_stats['bonus_credits']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($credit_packs)): ?>
        <button type="button" class="btn-buy-credits" onclick="openCreditPurchaseModal()">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <?php _e('Buy Credits', 'rental-gates'); ?>
        </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($credit_status === 'low' || $credit_status === 'empty'): ?>
<div class="ai-alert <?php echo $credit_status === 'empty' ? 'error' : 'warning'; ?>">
    <?php if ($credit_status === 'empty'): ?>
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
    <span><?php _e('No AI credits remaining! Purchase credits or wait for your monthly refresh.', 'rental-gates'); ?></span>
    <?php else: ?>
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <span><?php printf(__('Running low on credits! Only %d remaining.', 'rental-gates'), $usage_stats['remaining']); ?></span>
    <?php endif; ?>
    <?php if (!empty($credit_packs)): ?>
    <button type="button" class="btn btn-sm btn-primary" onclick="openCreditPurchaseModal()" style="margin-left: auto;"><?php _e('Buy Credits', 'rental-gates'); ?></button>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="ai-alert error">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <span><?php echo esc_html($error); ?></span>
</div>
<?php endif; ?>

<!-- Tools Grid -->
<div class="tools-grid">
    <?php foreach ($tools as $tool_id => $tool): ?>
    <a href="?tool=<?php echo esc_attr($tool_id); ?>" class="tool-card <?php echo $active_tool === $tool_id ? 'active' : ''; ?>">
        <div class="tool-icon" style="background: <?php echo esc_attr($tool['color']); ?>">
            <?php echo $tool['icon']; ?>
        </div>
        <h3 class="tool-name"><?php echo esc_html($tool['name']); ?></h3>
        <p class="tool-desc"><?php echo esc_html($tool['description']); ?></p>
        <span class="tool-credits">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <?php printf(_n('%d credit', '%d credits', $tool['credits'], 'rental-gates'), $tool['credits']); ?>
        </span>
    </a>
    <?php endforeach; ?>
</div>

<?php if ($active_tool && isset($tools[$active_tool])): ?>
<!-- Active Tool Panel -->
<div class="tool-panel">
    <div class="tool-panel-header">
        <h2>
            <?php echo $tools[$active_tool]['icon']; ?>
            <?php echo esc_html($tools[$active_tool]['name']); ?>
        </h2>
        <a href="?" class="btn btn-secondary btn-sm"><?php _e('Close', 'rental-gates'); ?></a>
    </div>
    <div class="tool-panel-body">
        <?php
        // Include tool-specific form
        switch ($active_tool):
            case 'description':
        ?>
        <form method="post" class="ai-form" id="descriptionForm">
            <?php wp_nonce_field('ai_tools', 'ai_nonce'); ?>
            <input type="hidden" name="ai_action" value="generate_description">
            
            <!-- Quick Unit Selector - v2.16.0 Feature -->
            <div class="ai-form-group" style="margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #e2e8f0; background: #f0f9ff; padding: 16px; border-radius: 8px; border: 1px solid #bae6fd;">
                <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-weight: 600; color: #0369a1;">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <?php _e('⚡ Quick Fill from Unit', 'rental-gates'); ?>
                    <span style="font-size: 10px; background: #0ea5e9; color: white; padding: 2px 6px; border-radius: 4px; font-weight: 700;">NEW</span>
                </label>
                <?php if (!empty($org_units)): ?>
                <select id="unitSelector" style="width: 100%; padding: 10px 12px; border: 1px solid #7dd3fc; border-radius: 6px; font-size: 14px;" onchange="fillFromUnit(this.value)">
                    <option value=""><?php _e('— Select a unit to auto-fill details —', 'rental-gates'); ?></option>
                    <?php foreach ($org_units as $unit): ?>
                    <option value="<?php echo esc_attr($unit['id']); ?>" 
                            data-name="<?php echo esc_attr($unit['name']); ?>"
                            data-bedrooms="<?php echo esc_attr($unit['bedrooms'] ?? ''); ?>"
                            data-bathrooms="<?php echo esc_attr($unit['bathrooms'] ?? ''); ?>"
                            data-sqft="<?php echo esc_attr($unit['square_footage'] ?? ''); ?>"
                            data-rent="<?php echo esc_attr($unit['rent_amount'] ?? ''); ?>"
                            data-address="<?php echo esc_attr($unit['building_address'] ?? ''); ?>"
                            data-amenities="<?php echo esc_attr($unit['amenities'] ?? ''); ?>">
                        <?php echo esc_html($unit['name'] . ' — ' . $unit['building_name']); ?>
                        <?php if ($unit['availability'] === 'available'): ?> ✓<?php endif; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p style="font-size: 12px; color: #0369a1; margin-top: 8px; margin-bottom: 0;"><?php _e('Select a unit to automatically fill in the form below, or enter details manually.', 'rental-gates'); ?></p>
                <?php elseif (!empty($org_buildings)): ?>
                <p style="font-size: 13px; color: #64748b; margin: 0; padding: 8px 12px; background: white; border-radius: 6px; border: 1px dashed #cbd5e1;">
                    <?php printf(__('You have %d building(s) but no units yet.', 'rental-gates'), count($org_buildings)); ?>
                    <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" style="color: #0369a1; font-weight: 500;"><?php _e('Add units to your buildings →', 'rental-gates'); ?></a>
                </p>
                <?php else: ?>
                <p style="font-size: 13px; color: #64748b; margin: 0; padding: 8px 12px; background: white; border-radius: 6px; border: 1px dashed #cbd5e1;">
                    <?php _e('No properties found.', 'rental-gates'); ?>
                    <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" style="color: #0369a1; font-weight: 500;"><?php _e('Add your first building →', 'rental-gates'); ?></a>
                    <?php if (isset($debug_info)): ?>
                    <br><small style="color: #94a3b8; font-size: 10px;">Debug: org=<?php echo $debug_info['org_id'] ?? 'null'; ?>, b=<?php echo $debug_info['buildings_count'] ?? 0; ?>, u=<?php echo $debug_info['units_count'] ?? 0; ?><?php if (!empty($debug_info['skip_reason'])): ?>, skip=<?php echo $debug_info['skip_reason']; ?><?php endif; ?></small>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Property Name', 'rental-gates'); ?></label>
                    <input type="text" name="property_name" id="prop_name" placeholder="e.g., Sunny Corner Unit">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Unit Type', 'rental-gates'); ?></label>
                    <select name="unit_type" id="prop_type">
                        <option value="apartment"><?php _e('Apartment', 'rental-gates'); ?></option>
                        <option value="studio"><?php _e('Studio', 'rental-gates'); ?></option>
                        <option value="house"><?php _e('House', 'rental-gates'); ?></option>
                        <option value="condo"><?php _e('Condo', 'rental-gates'); ?></option>
                        <option value="townhouse"><?php _e('Townhouse', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Bedrooms', 'rental-gates'); ?></label>
                    <input type="number" name="bedrooms" id="prop_bedrooms" min="0" max="10" value="1">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Bathrooms', 'rental-gates'); ?></label>
                    <input type="number" name="bathrooms" id="prop_bathrooms" min="0" max="10" step="0.5" value="1">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Square Feet', 'rental-gates'); ?></label>
                    <input type="number" name="sqft" id="prop_sqft" min="0">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Monthly Rent', 'rental-gates'); ?></label>
                    <input type="number" name="rent" id="prop_rent" min="0" step="1">
                </div>
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Address/Location', 'rental-gates'); ?></label>
                <input type="text" name="address" id="prop_address" placeholder="e.g., Downtown, near transit">
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Key Features & Amenities', 'rental-gates'); ?></label>
                <textarea name="features" id="prop_features" placeholder="e.g., hardwood floors, in-unit laundry, rooftop deck, pet-friendly"></textarea>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Writing Style', 'rental-gates'); ?></label>
                    <select name="style">
                        <option value="professional"><?php _e('Professional', 'rental-gates'); ?></option>
                        <option value="casual"><?php _e('Casual & Friendly', 'rental-gates'); ?></option>
                        <option value="luxury"><?php _e('Luxury & Upscale', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            
            <div class="ai-form-actions">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Generate Description', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <?php if ($result && isset($result['description'])): ?>
        <div class="ai-result">
            <div class="ai-result-header">
                <h3><?php _e('Generated Description', 'rental-gates'); ?></h3>
                <button type="button" class="btn-copy" onclick="copyToClipboard(this, '<?php echo esc_attr(addslashes($result['description'])); ?>')">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    <?php _e('Copy', 'rental-gates'); ?>
                </button>
            </div>
            <div class="ai-result-content"><?php echo esc_html($result['description']); ?></div>
            <div class="ai-result-meta">
                <span><?php printf(__('%d credit used', 'rental-gates'), $result['credits_used']); ?></span>
                <span><?php printf(__('%d credits remaining', 'rental-gates'), $result['credits_remaining']); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <?php
            break;
            
            case 'marketing':
        ?>
        <form method="post" class="ai-form">
            <?php wp_nonce_field('ai_tools', 'ai_nonce'); ?>
            <input type="hidden" name="ai_action" value="generate_marketing">
            
            <!-- Quick Unit Selector - v2.16.0 Feature -->
            <div class="ai-form-group" style="margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #e2e8f0; background: #f0f9ff; padding: 16px; border-radius: 8px; border: 1px solid #bae6fd;">
                <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-weight: 600; color: #0369a1;">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <?php _e('⚡ Quick Fill from Unit', 'rental-gates'); ?>
                    <span style="font-size: 10px; background: #0ea5e9; color: white; padding: 2px 6px; border-radius: 4px; font-weight: 700;">NEW</span>
                </label>
                <?php if (!empty($org_units)): ?>
                <select id="marketingUnitSelector" style="width: 100%; padding: 10px 12px; border: 1px solid #7dd3fc; border-radius: 6px; font-size: 14px;" onchange="fillMarketingFromUnit(this.value)">
                    <option value=""><?php _e('— Select a unit to auto-fill details —', 'rental-gates'); ?></option>
                    <?php foreach ($org_units as $unit): ?>
                    <option value="<?php echo esc_attr($unit['id']); ?>" 
                            data-name="<?php echo esc_attr($unit['name']); ?>"
                            data-bedrooms="<?php echo esc_attr($unit['bedrooms'] ?? ''); ?>"
                            data-rent="<?php echo esc_attr($unit['rent_amount'] ?? ''); ?>"
                            data-address="<?php echo esc_attr($unit['building_address'] ?? ''); ?>">
                        <?php echo esc_html($unit['name'] . ' — ' . $unit['building_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p style="font-size: 12px; color: #0369a1; margin-top: 8px; margin-bottom: 0;"><?php _e('Select a unit to auto-fill, or enter details manually.', 'rental-gates'); ?></p>
                <?php elseif (!empty($org_buildings)): ?>
                <p style="font-size: 13px; color: #64748b; margin: 0; padding: 8px 12px; background: white; border-radius: 6px; border: 1px dashed #cbd5e1;">
                    <?php printf(__('You have %d building(s) but no units yet.', 'rental-gates'), count($org_buildings)); ?>
                    <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" style="color: #0369a1; font-weight: 500;"><?php _e('Add units →', 'rental-gates'); ?></a>
                </p>
                <?php else: ?>
                <p style="font-size: 13px; color: #64748b; margin: 0; padding: 8px 12px; background: white; border-radius: 6px; border: 1px dashed #cbd5e1;">
                    <?php _e('No properties found.', 'rental-gates'); ?>
                    <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" style="color: #0369a1; font-weight: 500;"><?php _e('Add building →', 'rental-gates'); ?></a>
                    <?php if (isset($debug_info)): ?>
                    <br><small style="color: #94a3b8; font-size: 10px;">Debug: org=<?php echo $debug_info['org_id'] ?? 'null'; ?>, b=<?php echo $debug_info['buildings_count'] ?? 0; ?>, u=<?php echo $debug_info['units_count'] ?? 0; ?><?php if (!empty($debug_info['skip_reason'])): ?>, skip=<?php echo $debug_info['skip_reason']; ?><?php endif; ?></small>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Property Name', 'rental-gates'); ?></label>
                    <input type="text" name="property_name" id="mkt_property_name" required>
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Monthly Rent', 'rental-gates'); ?></label>
                    <input type="number" name="rent" id="mkt_rent" min="0">
                </div>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Bedrooms', 'rental-gates'); ?></label>
                    <input type="number" name="bedrooms" id="mkt_bedrooms" min="0" max="10">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Format', 'rental-gates'); ?></label>
                    <select name="format">
                        <option value="flyer"><?php _e('Flyer Copy', 'rental-gates'); ?></option>
                        <option value="social"><?php _e('Social Media Post', 'rental-gates'); ?></option>
                        <option value="email"><?php _e('Email Announcement', 'rental-gates'); ?></option>
                        <option value="ad"><?php _e('Ad Copy', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Address/Location', 'rental-gates'); ?></label>
                <input type="text" name="address" id="mkt_address">
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Key Highlights', 'rental-gates'); ?></label>
                <textarea name="highlights" placeholder="What makes this property special?"></textarea>
            </div>
            
            <div class="ai-form-actions">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Generate Marketing Copy', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <?php if ($result && isset($result['content'])): ?>
        <div class="ai-result">
            <div class="ai-result-header">
                <h3><?php printf(__('Generated %s', 'rental-gates'), ucfirst($result['format'])); ?></h3>
                <button type="button" class="btn-copy" onclick="copyToClipboard(this, '<?php echo esc_attr(addslashes($result['content'])); ?>')">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    <?php _e('Copy', 'rental-gates'); ?>
                </button>
            </div>
            <div class="ai-result-content"><?php echo esc_html($result['content']); ?></div>
        </div>
        <?php endif; ?>
        
        <?php
            break;
            
            case 'maintenance':
        ?>
        <form method="post" class="ai-form">
            <?php wp_nonce_field('ai_tools', 'ai_nonce'); ?>
            <input type="hidden" name="ai_action" value="triage_maintenance">
            
            <div class="ai-form-group">
                <label><?php _e('Issue Title', 'rental-gates'); ?></label>
                <input type="text" name="title" required placeholder="e.g., Bathroom faucet leaking">
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Description', 'rental-gates'); ?></label>
                <textarea name="description" required placeholder="Describe the issue in detail..."></textarea>
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Location in Property', 'rental-gates'); ?></label>
                <input type="text" name="location" placeholder="e.g., Master bathroom, kitchen">
            </div>
            
            <div class="ai-form-actions">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Analyze Request', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <?php if ($result && isset($result['category'])): ?>
        <div class="ai-result">
            <div class="ai-result-header">
                <h3><?php _e('Triage Results', 'rental-gates'); ?></h3>
            </div>
            
            <div class="triage-grid">
                <div class="triage-item">
                    <label><?php _e('Category', 'rental-gates'); ?></label>
                    <span class="value"><?php echo esc_html(ucfirst($result['category'])); ?></span>
                </div>
                <div class="triage-item">
                    <label><?php _e('Priority', 'rental-gates'); ?></label>
                    <span class="priority-badge <?php echo esc_attr($result['priority']); ?>"><?php echo esc_html(ucfirst($result['priority'])); ?></span>
                </div>
                <?php if (!empty($result['estimated_cost_range'])): ?>
                <div class="triage-item">
                    <label><?php _e('Est. Cost', 'rental-gates'); ?></label>
                    <span class="value"><?php echo esc_html($result['estimated_cost_range']); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($result['suggested_vendor_type'])): ?>
                <div class="triage-item">
                    <label><?php _e('Vendor Type', 'rental-gates'); ?></label>
                    <span class="value"><?php echo esc_html($result['suggested_vendor_type']); ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($result['tenant_instructions'])): ?>
            <div style="margin-top: 16px; padding: 14px; background: #eff6ff; border-radius: 8px;">
                <strong style="font-size: 13px;"><?php _e('Tenant Instructions:', 'rental-gates'); ?></strong>
                <p style="margin: 8px 0 0; font-size: 14px;"><?php echo esc_html($result['tenant_instructions']); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($result['safety_concerns'])): ?>
            <div style="margin-top: 16px; padding: 14px; background: #fef2f2; border-radius: 8px;">
                <strong style="font-size: 13px; color: #991b1b;"><?php _e('Safety Concerns:', 'rental-gates'); ?></strong>
                <ul style="margin: 8px 0 0; padding-left: 20px; font-size: 14px;">
                    <?php foreach ($result['safety_concerns'] as $concern): ?>
                    <li><?php echo esc_html($concern); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($result['summary'])): ?>
            <div style="margin-top: 16px;">
                <strong style="font-size: 13px;"><?php _e('Summary:', 'rental-gates'); ?></strong>
                <p style="margin: 8px 0 0; font-size: 14px;"><?php echo esc_html($result['summary']); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php
            break;
            
            case 'message':
        ?>
        <form method="post" class="ai-form">
            <?php wp_nonce_field('ai_tools', 'ai_nonce'); ?>
            <input type="hidden" name="ai_action" value="draft_message">
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Message Type', 'rental-gates'); ?></label>
                    <select name="message_type">
                        <option value="general"><?php _e('General Communication', 'rental-gates'); ?></option>
                        <option value="late_rent"><?php _e('Late Rent Reminder', 'rental-gates'); ?></option>
                        <option value="maintenance"><?php _e('Maintenance Update', 'rental-gates'); ?></option>
                        <option value="lease_renewal"><?php _e('Lease Renewal', 'rental-gates'); ?></option>
                        <option value="welcome"><?php _e('Welcome Message', 'rental-gates'); ?></option>
                        <option value="notice"><?php _e('Important Notice', 'rental-gates'); ?></option>
                    </select>
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Tone', 'rental-gates'); ?></label>
                    <select name="tone">
                        <option value="professional"><?php _e('Professional', 'rental-gates'); ?></option>
                        <option value="friendly"><?php _e('Friendly', 'rental-gates'); ?></option>
                        <option value="formal"><?php _e('Formal', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            
            <div class="ai-form-row">
                <div class="ai-form-group">
                    <label><?php _e('Tenant Name', 'rental-gates'); ?></label>
                    <input type="text" name="tenant_name" placeholder="Optional">
                </div>
                <div class="ai-form-group">
                    <label><?php _e('Property', 'rental-gates'); ?></label>
                    <input type="text" name="property" placeholder="e.g., Unit 204">
                </div>
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Context / What to Communicate', 'rental-gates'); ?></label>
                <textarea name="context" required placeholder="What do you need to tell the tenant?"></textarea>
            </div>
            
            <div class="ai-form-group">
                <label><?php _e('Specific Details to Include', 'rental-gates'); ?></label>
                <textarea name="specific_details" placeholder="Any dates, amounts, or specific information..."></textarea>
            </div>
            
            <div class="ai-form-actions">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Draft Message', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <?php if ($result && isset($result['message'])): ?>
        <div class="ai-result">
            <div class="ai-result-header">
                <h3><?php _e('Draft Message', 'rental-gates'); ?></h3>
                <button type="button" class="btn-copy" onclick="copyToClipboard(this, '<?php echo esc_attr(addslashes($result['message'])); ?>')">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    <?php _e('Copy', 'rental-gates'); ?>
                </button>
            </div>
            <div class="ai-result-content"><?php echo esc_html($result['message']); ?></div>
        </div>
        <?php endif; ?>
        
        <?php
            break;
            
            case 'insights':
        ?>
        <form method="post" class="ai-form">
            <?php wp_nonce_field('ai_tools', 'ai_nonce'); ?>
            <input type="hidden" name="ai_action" value="portfolio_insights">
            
            <p style="color: var(--gray-600); margin: 0 0 20px;">
                <?php _e('Generate AI-powered insights and recommendations for your property portfolio based on current metrics.', 'rental-gates'); ?>
            </p>
            
            <div class="ai-form-actions">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Generate Portfolio Insights', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <?php if ($result && isset($result['health_score'])): ?>
        <div class="ai-result">
            <div class="health-score">
                <div class="health-score-value"><?php echo intval($result['health_score']); ?></div>
                <div class="health-score-label"><?php _e('Portfolio Health Score', 'rental-gates'); ?></div>
            </div>
            
            <div class="insights-grid">
                <?php if (!empty($result['portfolio_stats'])): 
                    $stats = $result['portfolio_stats'];
                ?>
                <div class="insight-card">
                    <h4><?php _e('Total Units', 'rental-gates'); ?></h4>
                    <div class="insight-value"><?php echo intval($stats['total_units']); ?></div>
                </div>
                <div class="insight-card">
                    <h4><?php _e('Occupancy Rate', 'rental-gates'); ?></h4>
                    <div class="insight-value"><?php echo 100 - floatval($stats['vacancy_rate']); ?>%</div>
                </div>
                <div class="insight-card">
                    <h4><?php _e('Collected This Month', 'rental-gates'); ?></h4>
                    <div class="insight-value">$<?php echo number_format($stats['collected_this_month']); ?></div>
                </div>
                <div class="insight-card">
                    <h4><?php _e('Open Maintenance', 'rental-gates'); ?></h4>
                    <div class="insight-value"><?php echo intval($stats['open_maintenance']); ?></div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($result['recommendations'])): ?>
            <div style="margin-top: 20px;">
                <h4 style="font-size: 15px; font-weight: 600; margin: 0 0 12px;"><?php _e('Recommendations', 'rental-gates'); ?></h4>
                <?php foreach ($result['recommendations'] as $rec): ?>
                <div style="padding: 14px; background: #f0fdf4; border-radius: 8px; margin-bottom: 10px;">
                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
                        <span class="priority-badge <?php echo esc_attr($rec['priority'] ?? 'medium'); ?>"><?php echo esc_html(ucfirst($rec['priority'] ?? 'Medium')); ?></span>
                        <strong style="font-size: 14px;"><?php echo esc_html($rec['action'] ?? ''); ?></strong>
                    </div>
                    <?php if (!empty($rec['impact'])): ?>
                    <p style="margin: 0; font-size: 13px; color: var(--gray-600);"><?php echo esc_html($rec['impact']); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($result['risks'])): ?>
            <div style="margin-top: 20px;">
                <h4 style="font-size: 15px; font-weight: 600; margin: 0 0 12px; color: #991b1b;"><?php _e('Risks to Monitor', 'rental-gates'); ?></h4>
                <ul style="margin: 0; padding-left: 20px;">
                    <?php foreach ($result['risks'] as $risk): ?>
                    <li style="margin-bottom: 6px;"><?php echo esc_html($risk); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($result['opportunities'])): ?>
            <div style="margin-top: 20px;">
                <h4 style="font-size: 15px; font-weight: 600; margin: 0 0 12px; color: #059669;"><?php _e('Opportunities', 'rental-gates'); ?></h4>
                <ul style="margin: 0; padding-left: 20px;">
                    <?php foreach ($result['opportunities'] as $opp): ?>
                    <li style="margin-bottom: 6px;"><?php echo esc_html($opp); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php
            break;
            
            case 'screening':
        ?>
        <p style="color: var(--gray-600); margin: 0 0 20px;">
            <?php _e('AI Screening is available from the Applications page. Select an application and click "AI Screen" to analyze.', 'rental-gates'); ?>
        </p>
        <a href="<?php echo home_url('/rental-gates/dashboard/applications'); ?>" class="btn btn-primary">
            <?php _e('Go to Applications', 'rental-gates'); ?>
        </a>
        <?php
            break;
        endswitch;
        ?>
    </div>
</div>
<?php endif; ?>

<!-- Usage History -->
<?php if (!empty($history)): ?>
<div class="history-section">
    <div class="history-header">
        <h3><?php _e('Recent AI Usage', 'rental-gates'); ?></h3>
    </div>
    <div class="history-list">
        <?php foreach ($history as $item): 
            $tool_info = $tools[$item['tool']] ?? array('name' => ucfirst($item['tool']), 'color' => '#6b7280', 'icon' => '');
        ?>
        <div class="history-item">
            <div class="history-icon" style="background: <?php echo esc_attr($tool_info['color']); ?>">
                <?php echo $tool_info['icon']; ?>
            </div>
            <div class="history-info">
                <div class="history-tool"><?php echo esc_html($tool_info['name']); ?></div>
                <div class="history-meta">
                    <?php echo esc_html($item['user_name'] ?? 'Unknown'); ?> &bull;
                    <?php echo human_time_diff(strtotime($item['created_at']), current_time('timestamp')); ?> ago
                </div>
            </div>
            <div class="history-credits">
                <?php printf(_n('%d credit', '%d credits', $item['credits_used'], 'rental-gates'), $item['credits_used']); ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Credit Purchase Modal -->
<?php if (!empty($credit_packs)): ?>
<div class="credit-modal-overlay" id="creditPurchaseModal">
    <div class="credit-modal">
        <div class="credit-modal-header">
            <h2>
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                <?php _e('Buy AI Credits', 'rental-gates'); ?>
            </h2>
            <button type="button" class="credit-modal-close" onclick="closeCreditPurchaseModal()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="credit-modal-body">
            <p style="color: var(--gray-600); margin: 0 0 20px;">
                <?php printf(__('Current Balance: %s credits', 'rental-gates'), '<strong>' . number_format($usage_stats['remaining']) . '</strong>'); ?>
            </p>
            
            <div class="credit-packs-grid">
                <?php 
                $base_price_per_credit = 0.20; // For calculating savings
                foreach ($credit_packs as $pack): 
                    $price_per_credit = $pack['price'] / $pack['credits'];
                    $savings = round((1 - ($price_per_credit / $base_price_per_credit)) * 100);
                ?>
                <div class="credit-pack" data-pack-id="<?php echo esc_attr($pack['id'] ?? $pack['slug']); ?>" data-credits="<?php echo esc_attr($pack['credits']); ?>" data-price="<?php echo esc_attr($pack['price']); ?>" onclick="selectCreditPack(this)">
                    <?php if (!empty($pack['badge_text'])): ?>
                    <div class="credit-pack-badge"><?php echo esc_html($pack['badge_text']); ?></div>
                    <?php endif; ?>
                    <div class="credit-pack-name"><?php echo esc_html($pack['name']); ?></div>
                    <div class="credit-pack-credits"><?php echo number_format($pack['credits']); ?> <span><?php _e('credits', 'rental-gates'); ?></span></div>
                    <div class="credit-pack-price">$<?php echo number_format($pack['price'], 2); ?></div>
                    <div class="credit-pack-unit">$<?php echo number_format($price_per_credit, 2); ?>/<?php _e('credit', 'rental-gates'); ?></div>
                    <?php if ($savings > 0): ?>
                    <div class="credit-pack-savings"><?php printf(__('Save %d%%', 'rental-gates'), $savings); ?></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="credit-modal-features">
                <span>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Credits never expire', 'rental-gates'); ?>
                </span>
                <span>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Use across all AI tools', 'rental-gates'); ?>
                </span>
                <span>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Shared with your team', 'rental-gates'); ?>
                </span>
            </div>
        </div>
        <div class="credit-modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeCreditPurchaseModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
            <button type="button" class="btn btn-primary" id="purchaseCreditsBtn" disabled onclick="purchaseCredits()">
                <?php _e('Purchase Credits', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function copyToClipboard(btn, text) {
    navigator.clipboard.writeText(text).then(function() {
        btn.classList.add('copied');
        btn.innerHTML = '<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg> Copied!';
        setTimeout(function() {
            btn.classList.remove('copied');
            btn.innerHTML = '<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg> Copy';
        }, 2000);
    });
}

// Credit Purchase Modal Functions
let selectedPack = null;

function openCreditPurchaseModal() {
    document.getElementById('creditPurchaseModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCreditPurchaseModal() {
    document.getElementById('creditPurchaseModal').classList.remove('active');
    document.body.style.overflow = '';
    // Reset selection
    document.querySelectorAll('.credit-pack').forEach(p => p.classList.remove('selected'));
    document.getElementById('purchaseCreditsBtn').disabled = true;
    selectedPack = null;
}

function selectCreditPack(element) {
    // Remove selection from all packs
    document.querySelectorAll('.credit-pack').forEach(p => p.classList.remove('selected'));
    // Select this pack
    element.classList.add('selected');
    selectedPack = {
        id: element.dataset.packId,
        credits: parseInt(element.dataset.credits),
        price: parseFloat(element.dataset.price)
    };
    // Enable purchase button
    document.getElementById('purchaseCreditsBtn').disabled = false;
    document.getElementById('purchaseCreditsBtn').textContent = 'Purchase ' + selectedPack.credits.toLocaleString() + ' Credits - $' + selectedPack.price.toFixed(2);
}

function purchaseCredits() {
    if (!selectedPack) return;
    
    const btn = document.getElementById('purchaseCreditsBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Processing...';
    
    // AJAX call to create payment intent
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'rg_purchase_ai_credits',
            pack_id: selectedPack.id,
            nonce: '<?php echo wp_create_nonce('ai_credit_purchase'); ?>'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to payment or show success
            if (data.data.redirect_url) {
                window.location.href = data.data.redirect_url;
            } else if (data.data.client_secret) {
                // Handle Stripe Elements payment
                handleStripePayment(data.data.client_secret);
            } else {
                alert('Credits purchased successfully!');
                window.location.reload();
            }
        } else {
            alert(data.data.message || 'Purchase failed. Please try again.');
            btn.disabled = false;
            btn.textContent = 'Purchase ' + selectedPack.credits.toLocaleString() + ' Credits - $' + selectedPack.price.toFixed(2);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
        btn.disabled = false;
        btn.textContent = 'Purchase ' + selectedPack.credits.toLocaleString() + ' Credits - $' + selectedPack.price.toFixed(2);
    });
}

// Close modal on overlay click
document.getElementById('creditPurchaseModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeCreditPurchaseModal();
    }
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeCreditPurchaseModal();
    }
});

// Fill form from unit selector
function fillFromUnit(unitId) {
    if (!unitId) return;
    
    const selector = document.getElementById('unitSelector');
    if (!selector) return;
    
    const option = selector.querySelector('option[value="' + unitId + '"]');
    if (!option) return;
    
    // Get data attributes
    const name = option.dataset.name || '';
    const bedrooms = option.dataset.bedrooms || '';
    const bathrooms = option.dataset.bathrooms || '';
    const sqft = option.dataset.sqft || '';
    const rent = option.dataset.rent || '';
    const address = option.dataset.address || '';
    const amenities = option.dataset.amenities || '';
    
    // Fill form fields
    const nameField = document.getElementById('prop_name');
    const bedroomsField = document.getElementById('prop_bedrooms');
    const bathroomsField = document.getElementById('prop_bathrooms');
    const sqftField = document.getElementById('prop_sqft');
    const rentField = document.getElementById('prop_rent');
    const addressField = document.getElementById('prop_address');
    const featuresField = document.getElementById('prop_features');
    
    if (nameField) nameField.value = name;
    if (bedroomsField && bedrooms) bedroomsField.value = bedrooms;
    if (bathroomsField && bathrooms) bathroomsField.value = bathrooms;
    if (sqftField && sqft) sqftField.value = sqft;
    if (rentField && rent) rentField.value = rent;
    if (addressField) addressField.value = address;
    if (featuresField && amenities) featuresField.value = amenities;
    
    // Visual feedback
    selector.style.borderColor = '#10b981';
    setTimeout(() => {
        selector.style.borderColor = '';
    }, 1000);
}

// Fill marketing form from unit selector
function fillMarketingFromUnit(unitId) {
    if (!unitId) return;
    
    const selector = document.getElementById('marketingUnitSelector');
    if (!selector) return;
    
    const option = selector.querySelector('option[value="' + unitId + '"]');
    if (!option) return;
    
    // Get data attributes
    const name = option.dataset.name || '';
    const bedrooms = option.dataset.bedrooms || '';
    const rent = option.dataset.rent || '';
    const address = option.dataset.address || '';
    
    // Fill form fields
    const nameField = document.getElementById('mkt_property_name');
    const bedroomsField = document.getElementById('mkt_bedrooms');
    const rentField = document.getElementById('mkt_rent');
    const addressField = document.getElementById('mkt_address');
    
    if (nameField) nameField.value = name;
    if (bedroomsField && bedrooms) bedroomsField.value = bedrooms;
    if (rentField && rent) rentField.value = rent;
    if (addressField) addressField.value = address;
    
    // Visual feedback
    selector.style.borderColor = '#10b981';
    setTimeout(() => {
        selector.style.borderColor = '';
    }, 1000);
}
</script>

<?php endif; ?>
