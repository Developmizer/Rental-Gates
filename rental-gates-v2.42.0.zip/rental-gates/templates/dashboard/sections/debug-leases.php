<?php
/**
 * Debug Leases - Diagnostic Tool
 * Access via: /rental-gates/dashboard/debug-leases
 */
if (!defined('ABSPATH')) exit;

if (!current_user_can('manage_options')) {
    echo '<p>Admin access required</p>';
    return;
}

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();
$org_id = Rental_Gates_Roles::get_organization_id();

echo '<style>
    .debug-section { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
    .debug-section h3 { margin-top: 0; color: #1e40af; border-bottom: 2px solid #1e40af; padding-bottom: 10px; }
    .debug-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .debug-table th, .debug-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    .debug-table th { background: #f3f4f6; }
    .debug-table tr:nth-child(even) { background: #f9fafb; }
    .status-active { color: #059669; font-weight: bold; }
    .status-draft { color: #6b7280; }
    .status-ended { color: #dc2626; }
    .debug-alert { background: #fef3c7; border: 1px solid #f59e0b; padding: 12px; border-radius: 6px; margin: 10px 0; }
    .debug-success { background: #d1fae5; border: 1px solid #10b981; padding: 12px; border-radius: 6px; margin: 10px 0; }
    .debug-error { background: #fee2e2; border: 1px solid #ef4444; padding: 12px; border-radius: 6px; margin: 10px 0; }
</style>';

echo '<h1>🔍 Lease System Diagnostic</h1>';
echo '<p>Organization ID: <strong>' . $org_id . '</strong></p>';

// 1. Check all leases in organization
echo '<div class="debug-section">';
echo '<h3>1. All Leases in Organization</h3>';
$all_leases = $wpdb->get_results($wpdb->prepare(
    "SELECT l.*, u.name as unit_name, b.name as building_name
     FROM {$tables['leases']} l
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     WHERE l.organization_id = %d
     ORDER BY l.created_at DESC",
    $org_id
), ARRAY_A);

if (empty($all_leases)) {
    echo '<div class="debug-error">❌ No leases found in this organization!</div>';
} else {
    echo '<p>Found <strong>' . count($all_leases) . '</strong> lease(s)</p>';
    echo '<table class="debug-table">';
    echo '<tr><th>ID</th><th>Unit</th><th>Building</th><th>Status</th><th>Start</th><th>End</th><th>Rent</th><th>Created</th></tr>';
    foreach ($all_leases as $lease) {
        $status_class = 'status-' . $lease['status'];
        echo '<tr>';
        echo '<td>' . $lease['id'] . '</td>';
        echo '<td>' . esc_html($lease['unit_name'] ?: 'N/A') . '</td>';
        echo '<td>' . esc_html($lease['building_name'] ?: 'N/A') . '</td>';
        echo '<td class="' . $status_class . '">' . strtoupper($lease['status']) . '</td>';
        echo '<td>' . $lease['start_date'] . '</td>';
        echo '<td>' . ($lease['end_date'] ?: 'Month-to-Month') . '</td>';
        echo '<td>$' . number_format($lease['rent_amount'], 2) . '</td>';
        echo '<td>' . $lease['created_at'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}
echo '</div>';

// 2. Check all tenants in organization
echo '<div class="debug-section">';
echo '<h3>2. All Tenants in Organization</h3>';
$all_tenants = $wpdb->get_results($wpdb->prepare(
    "SELECT t.*, u.user_email as wp_email
     FROM {$tables['tenants']} t
     LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
     WHERE t.organization_id = %d
     ORDER BY t.created_at DESC",
    $org_id
), ARRAY_A);

if (empty($all_tenants)) {
    echo '<div class="debug-error">❌ No tenants found in this organization!</div>';
} else {
    echo '<p>Found <strong>' . count($all_tenants) . '</strong> tenant(s)</p>';
    echo '<table class="debug-table">';
    echo '<tr><th>Tenant ID</th><th>Name</th><th>Email</th><th>WP User ID</th><th>WP Email</th><th>Status</th><th>Created</th></tr>';
    foreach ($all_tenants as $tenant) {
        echo '<tr>';
        echo '<td><strong>' . $tenant['id'] . '</strong></td>';
        echo '<td>' . esc_html($tenant['first_name'] . ' ' . $tenant['last_name']) . '</td>';
        echo '<td>' . esc_html($tenant['email']) . '</td>';
        echo '<td>' . ($tenant['user_id'] ?: '<span style="color:red">NOT LINKED</span>') . '</td>';
        echo '<td>' . esc_html($tenant['wp_email'] ?: 'N/A') . '</td>';
        echo '<td>' . $tenant['status'] . '</td>';
        echo '<td>' . $tenant['created_at'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}
echo '</div>';

// 3. Check lease_tenants junction table
echo '<div class="debug-section">';
echo '<h3>3. Lease-Tenant Relationships (lease_tenants table)</h3>';
$lease_tenant_links = $wpdb->get_results($wpdb->prepare(
    "SELECT lt.*, l.status as lease_status, l.organization_id,
            t.first_name, t.last_name, t.email as tenant_email,
            u.name as unit_name
     FROM {$tables['lease_tenants']} lt
     LEFT JOIN {$tables['leases']} l ON lt.lease_id = l.id
     LEFT JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     WHERE l.organization_id = %d
     ORDER BY lt.added_at DESC",
    $org_id
), ARRAY_A);

if (empty($lease_tenant_links)) {
    echo '<div class="debug-error">❌ NO RECORDS in lease_tenants table! This is the problem!</div>';
    echo '<div class="debug-alert">';
    echo '<strong>Issue:</strong> Leases exist but no tenants are linked to them.<br>';
    echo '<strong>Solution:</strong> When creating/editing a lease, tenants must be added via the tenant selector.';
    echo '</div>';
} else {
    echo '<p>Found <strong>' . count($lease_tenant_links) . '</strong> lease-tenant link(s)</p>';
    echo '<table class="debug-table">';
    echo '<tr><th>Link ID</th><th>Lease ID</th><th>Tenant ID</th><th>Tenant Name</th><th>Role</th><th>Lease Status</th><th>Unit</th><th>Added</th><th>Removed</th></tr>';
    foreach ($lease_tenant_links as $link) {
        $removed = $link['removed_at'] ? '<span style="color:red">' . $link['removed_at'] . '</span>' : '<span style="color:green">Active</span>';
        echo '<tr>';
        echo '<td>' . $link['id'] . '</td>';
        echo '<td>' . $link['lease_id'] . '</td>';
        echo '<td>' . $link['tenant_id'] . '</td>';
        echo '<td>' . esc_html($link['first_name'] . ' ' . $link['last_name']) . '</td>';
        echo '<td>' . $link['role'] . '</td>';
        echo '<td class="status-' . $link['lease_status'] . '">' . strtoupper($link['lease_status']) . '</td>';
        echo '<td>' . esc_html($link['unit_name'] ?: 'N/A') . '</td>';
        echo '<td>' . $link['added_at'] . '</td>';
        echo '<td>' . $removed . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}
echo '</div>';

// 4. Check for orphaned leases (leases without tenants)
echo '<div class="debug-section">';
echo '<h3>4. Orphaned Leases (No Tenant Linked)</h3>';
$orphaned_leases = $wpdb->get_results($wpdb->prepare(
    "SELECT l.*, u.name as unit_name
     FROM {$tables['leases']} l
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.removed_at IS NULL
     WHERE l.organization_id = %d
     AND lt.id IS NULL
     ORDER BY l.created_at DESC",
    $org_id
), ARRAY_A);

if (empty($orphaned_leases)) {
    echo '<div class="debug-success">✅ All leases have tenants linked!</div>';
} else {
    echo '<div class="debug-error">❌ Found <strong>' . count($orphaned_leases) . '</strong> lease(s) WITHOUT tenants!</div>';
    echo '<table class="debug-table">';
    echo '<tr><th>Lease ID</th><th>Unit</th><th>Status</th><th>Rent</th><th>Action</th></tr>';
    foreach ($orphaned_leases as $lease) {
        echo '<tr>';
        echo '<td>' . $lease['id'] . '</td>';
        echo '<td>' . esc_html($lease['unit_name'] ?: 'N/A') . '</td>';
        echo '<td>' . $lease['status'] . '</td>';
        echo '<td>$' . number_format($lease['rent_amount'], 2) . '</td>';
        echo '<td><a href="' . home_url('/rental-gates/dashboard/leases/' . $lease['id'] . '/edit') . '">Edit & Add Tenant</a></td>';
        echo '</tr>';
    }
    echo '</table>';
}
echo '</div>';

// 5. Test query that tenant portal uses
echo '<div class="debug-section">';
echo '<h3>5. Simulate Tenant Portal Query</h3>';

if (!empty($all_tenants)) {
    foreach ($all_tenants as $tenant) {
        $tenant_id = $tenant['id'];
        echo '<h4>Testing for Tenant: ' . esc_html($tenant['first_name'] . ' ' . $tenant['last_name']) . ' (ID: ' . $tenant_id . ')</h4>';
        
        // This is the exact query the tenant portal uses
        $tenant_leases = Rental_Gates_Lease::get_for_tenant($tenant_id, array(
            'status' => array('active', 'ending', 'draft'),
            'org_id' => $org_id,
        ));
        
        if (empty($tenant_leases)) {
            echo '<div class="debug-alert">⚠️ No leases found for this tenant via get_for_tenant()</div>';
            
            // Debug: Check raw query
            $raw_check = $wpdb->get_results($wpdb->prepare(
                "SELECT lt.lease_id, lt.role, lt.removed_at, l.status 
                 FROM {$tables['lease_tenants']} lt
                 JOIN {$tables['leases']} l ON lt.lease_id = l.id
                 WHERE lt.tenant_id = %d",
                $tenant_id
            ), ARRAY_A);
            
            if (empty($raw_check)) {
                echo '<div class="debug-error">❌ No records in lease_tenants for tenant_id = ' . $tenant_id . '</div>';
            } else {
                echo '<p>Raw lease_tenants records:</p>';
                echo '<pre>' . print_r($raw_check, true) . '</pre>';
            }
        } else {
            echo '<div class="debug-success">✅ Found ' . count($tenant_leases) . ' lease(s)</div>';
            foreach ($tenant_leases as $lease) {
                echo '<p>- Lease #' . $lease['id'] . ': ' . $lease['unit_name'] . ' (' . $lease['status'] . ')</p>';
            }
        }
    }
}
echo '</div>';

// 6. Quick Fix Tool
echo '<div class="debug-section">';
echo '<h3>6. Quick Fix: Link Tenant to Lease</h3>';

if (!empty($orphaned_leases) && !empty($all_tenants)) {
    echo '<form method="post" style="display: flex; gap: 10px; align-items: center;">';
    echo '<input type="hidden" name="action" value="link_tenant_to_lease">';
    wp_nonce_field('debug_link_tenant', 'debug_nonce');
    
    echo '<select name="lease_id" required>';
    echo '<option value="">Select Lease...</option>';
    foreach ($orphaned_leases as $lease) {
        echo '<option value="' . $lease['id'] . '">Lease #' . $lease['id'] . ' - ' . esc_html($lease['unit_name']) . ' (' . $lease['status'] . ')</option>';
    }
    echo '</select>';
    
    echo '<select name="tenant_id" required>';
    echo '<option value="">Select Tenant...</option>';
    foreach ($all_tenants as $tenant) {
        echo '<option value="' . $tenant['id'] . '">' . esc_html($tenant['first_name'] . ' ' . $tenant['last_name']) . '</option>';
    }
    echo '</select>';
    
    echo '<select name="role">';
    echo '<option value="primary">Primary</option>';
    echo '<option value="co_tenant">Co-Tenant</option>';
    echo '</select>';
    
    echo '<button type="submit" style="padding: 8px 16px; background: #2563eb; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Link Tenant to Lease</button>';
    echo '</form>';
    
    // Process the form
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'link_tenant_to_lease') {
        if (wp_verify_nonce($_POST['debug_nonce'], 'debug_link_tenant')) {
            $link_lease_id = intval($_POST['lease_id']);
            $link_tenant_id = intval($_POST['tenant_id']);
            $link_role = sanitize_text_field($_POST['role']);
            
            $result = Rental_Gates_Lease::add_tenant($link_lease_id, $link_tenant_id, $link_role);
            
            if (is_wp_error($result)) {
                echo '<div class="debug-error">❌ Error: ' . $result->get_error_message() . '</div>';
            } else {
                echo '<div class="debug-success">✅ Successfully linked tenant #' . $link_tenant_id . ' to lease #' . $link_lease_id . '!</div>';
                echo '<script>setTimeout(() => window.location.reload(), 1500);</script>';
            }
        }
    }
} else {
    echo '<p>No orphaned leases or no tenants available.</p>';
}
echo '</div>';

echo '<p style="margin-top: 30px; color: #6b7280;"><em>This diagnostic page helps identify issues with the lease-tenant relationship system.</em></p>';
