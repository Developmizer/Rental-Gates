<?php
/**
 * Lease Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get lease ID from URL - PRIMARY method: parse REQUEST_URI directly
$lease_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/leases/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $lease_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$lease_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    $lease_id = isset($parts[1]) ? intval($parts[1]) : 0;
}

if (!$lease_id) {
    wp_redirect(home_url('/rental-gates/dashboard/leases'));
    exit;
}

$lease = Rental_Gates_Lease::get_with_details($lease_id);

if (!$lease || $lease['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/leases'));
    exit;
}

// Status config
$status_config = array(
    'draft' => array('label' => __('Draft', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'ending' => array('label' => __('Ending', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'ended' => array('label' => __('Ended', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'renewed' => array('label' => __('Renewed', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
);

$status = $status_config[$lease['status']] ?? $status_config['draft'];

// Get available tenants for adding
$available_tenants = Rental_Gates_Tenant::get_for_organization($org_id, array('status' => null));
$current_tenant_ids = array_column($lease['tenants'], 'tenant_id');
?>

<style>
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    
    .rg-lease-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; }
    .rg-lease-title h1 { font-size: 24px; font-weight: 700; margin: 0 0 8px 0; }
    .rg-lease-subtitle { display: flex; align-items: center; gap: 12px; color: var(--gray-500); font-size: 14px; }
    .rg-header-actions { display: flex; gap: 12px; }
    
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-status-badge .dot { width: 8px; height: 8px; border-radius: 50%; }
    
    .rg-lease-grid { display: grid; grid-template-columns: 1fr 360px; gap: 24px; }
    .rg-lease-main { min-width: 0; }
    .rg-lease-aside { min-width: 0; }
    
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-card-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .rg-card-body { padding: 20px; }
    
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-value { font-size: 14px; color: var(--gray-900); font-weight: 500; }
    .rg-info-value.large { font-size: 24px; font-weight: 700; }
    
    .rg-tenant-list { display: flex; flex-direction: column; gap: 12px; }
    .rg-tenant-item { display: flex; align-items: center; justify-content: space-between; padding: 12px; background: var(--gray-50); border-radius: 8px; }
    .rg-tenant-info { display: flex; align-items: center; gap: 12px; }
    .rg-tenant-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--primary); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 14px; }
    .rg-tenant-details strong { display: block; font-size: 14px; }
    .rg-tenant-details span { font-size: 13px; color: var(--gray-500); }
    .rg-role-badge { padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 500; text-transform: uppercase; }
    .rg-role-badge.primary { background: #dbeafe; color: #1d4ed8; }
    .rg-role-badge.co_tenant { background: #e0e7ff; color: #4338ca; }
    .rg-role-badge.occupant { background: var(--gray-200); color: var(--gray-600); }
    
    .rg-add-tenant-form { display: flex; gap: 10px; margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-200); }
    .rg-add-tenant-form select { flex: 1; padding: 8px 12px; border: 1px solid var(--gray-300); border-radius: 6px; font-size: 14px; }
    
    .rg-timeline { display: flex; flex-direction: column; gap: 0; }
    .rg-timeline-item { display: flex; gap: 12px; padding: 12px 0; }
    .rg-timeline-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--primary); margin-top: 5px; flex-shrink: 0; }
    .rg-timeline-content { flex: 1; border-bottom: 1px solid var(--gray-100); padding-bottom: 12px; }
    .rg-timeline-item:last-child .rg-timeline-content { border-bottom: none; }
    .rg-timeline-title { font-size: 14px; font-weight: 500; }
    .rg-timeline-date { font-size: 12px; color: var(--gray-500); }
    
    .rg-expiring-alert { display: flex; align-items: center; gap: 12px; padding: 16px; background: #fef3c7; border: 1px solid #fcd34d; border-radius: 10px; margin-bottom: 24px; }
    .rg-expiring-alert svg { color: #f59e0b; flex-shrink: 0; }
    .rg-expiring-alert-content strong { display: block; color: #92400e; }
    .rg-expiring-alert-content span { font-size: 14px; color: #a16207; }
    
    .rg-btn-success { background: #10b981; color: #fff; border-color: #10b981; }
    .rg-btn-success:hover { background: #059669; }
    .rg-btn-warning { background: #f59e0b; color: #fff; border-color: #f59e0b; }
    .rg-btn-warning:hover { background: #d97706; }
    .rg-btn-danger { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }
    .rg-btn-danger:hover { background: #fecaca; }
    
    .rg-empty-section { text-align: center; padding: 30px; color: var(--gray-500); }
    
    @media (max-width: 992px) {
        .rg-lease-grid { grid-template-columns: 1fr; }
        .rg-lease-aside { order: -1; }
    }
    
    @media (max-width: 576px) {
        .rg-lease-header { flex-direction: column; gap: 16px; }
        .rg-header-actions { width: 100%; flex-wrap: wrap; }
        .rg-header-actions .rg-btn { flex: 1; min-width: 100px; }
        .rg-info-grid { grid-template-columns: 1fr; }
    }
</style>

<!-- Back Link -->
<a href="<?php echo home_url('/rental-gates/dashboard/leases'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
    </svg>
    <?php _e('Back to Leases', 'rental-gates'); ?>
</a>

<?php if ($lease['is_expiring_soon']): ?>
<!-- Expiring Alert -->
<div class="rg-expiring-alert">
    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
    </svg>
    <div class="rg-expiring-alert-content">
        <strong><?php _e('Lease Expiring Soon', 'rental-gates'); ?></strong>
        <span><?php echo sprintf(__('This lease expires in %d days on %s', 'rental-gates'), $lease['days_until_end'], date('F j, Y', strtotime($lease['end_date']))); ?></span>
    </div>
</div>
<?php endif; ?>

<!-- Header -->
<div class="rg-lease-header">
    <div class="rg-lease-title">
        <h1><?php echo esc_html($lease['unit_name']); ?> - <?php echo esc_html($lease['building_name']); ?></h1>
        <div class="rg-lease-subtitle">
            <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                <?php echo $status['label']; ?>
            </span>
            <span><?php _e('Lease', 'rental-gates'); ?> #<?php echo $lease['id']; ?></span>
        </div>
    </div>
    <div class="rg-header-actions">
        <?php if ($lease['status'] === 'draft'): ?>
            <a href="<?php echo home_url('/rental-gates/dashboard/leases/' . $lease['id'] . '/edit'); ?>" class="rg-btn rg-btn-secondary">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
                <?php _e('Edit', 'rental-gates'); ?>
            </a>
            <button type="button" class="rg-btn rg-btn-success" onclick="activateLease(<?php echo $lease['id']; ?>)">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
                <?php _e('Activate', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-danger" onclick="deleteLease(<?php echo $lease['id']; ?>)">
                <?php _e('Delete', 'rental-gates'); ?>
            </button>
        <?php elseif ($lease['status'] === 'active'): ?>
            <button type="button" class="rg-btn rg-btn-primary" onclick="showRenewModal()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                </svg>
                <?php _e('Renew', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-warning" onclick="endLease(<?php echo $lease['id']; ?>)">
                <?php _e('End Lease', 'rental-gates'); ?>
            </button>
        <?php endif; ?>
    </div>
</div>

<div class="rg-lease-grid">
    <div class="rg-lease-main">
        <!-- Tenants -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Tenants', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <?php if (empty($lease['tenants'])): ?>
                <div class="rg-empty-section">
                    <?php _e('No tenants assigned to this lease', 'rental-gates'); ?>
                </div>
                <?php else: ?>
                <div class="rg-tenant-list">
                    <?php foreach ($lease['tenants'] as $tenant): 
                        $initials = strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1));
                    ?>
                    <div class="rg-tenant-item">
                        <div class="rg-tenant-info">
                            <div class="rg-tenant-avatar"><?php echo $initials; ?></div>
                            <div class="rg-tenant-details">
                                <strong>
                                    <a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $tenant['tenant_id']); ?>" style="color: inherit; text-decoration: none;">
                                        <?php echo esc_html($tenant['full_name']); ?>
                                    </a>
                                </strong>
                                <span><?php echo esc_html($tenant['email']); ?> • <?php echo esc_html($tenant['phone']); ?></span>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="rg-role-badge <?php echo $tenant['role']; ?>">
                                <?php echo $tenant['role'] === 'primary' ? __('Primary', 'rental-gates') : ($tenant['role'] === 'co_tenant' ? __('Co-Tenant', 'rental-gates') : __('Occupant', 'rental-gates')); ?>
                            </span>
                            <?php if ($lease['status'] === 'draft'): ?>
                            <button type="button" class="rg-btn rg-btn-sm" style="padding: 4px 8px; font-size: 12px;" onclick="removeTenant(<?php echo $lease['id']; ?>, <?php echo $tenant['tenant_id']; ?>)">
                                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($lease['status'] === 'draft'): ?>
                <form class="rg-add-tenant-form" onsubmit="addTenant(event, <?php echo $lease['id']; ?>)">
                    <select name="tenant_id" id="add-tenant-select" required>
                        <option value=""><?php _e('Select a tenant to add...', 'rental-gates'); ?></option>
                        <?php foreach ($available_tenants as $t): 
                            if (in_array($t['id'], $current_tenant_ids)) continue;
                        ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo esc_html($t['full_name']); ?> (<?php echo esc_html($t['email']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <select name="role" id="add-tenant-role">
                        <option value="primary"><?php _e('Primary', 'rental-gates'); ?></option>
                        <option value="co_tenant"><?php _e('Co-Tenant', 'rental-gates'); ?></option>
                        <option value="occupant"><?php _e('Occupant', 'rental-gates'); ?></option>
                    </select>
                    <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Add', 'rental-gates'); ?></button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Lease Terms -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Lease Terms', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Start Date', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo date('F j, Y', strtotime($lease['start_date'])); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('End Date', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <?php 
                            if ($lease['end_date']) {
                                echo date('F j, Y', strtotime($lease['end_date']));
                            } elseif ($lease['is_month_to_month']) {
                                echo __('Month-to-Month', 'rental-gates');
                            } else {
                                echo '—';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Lease Duration', 'rental-gates'); ?></div>
                        <div class="rg-info-value">
                            <?php 
                            if ($lease['duration_months']) {
                                echo sprintf(_n('%d month', '%d months', $lease['duration_months'], 'rental-gates'), $lease['duration_months']);
                            } elseif ($lease['is_month_to_month']) {
                                echo __('Ongoing', 'rental-gates');
                            } else {
                                echo '—';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Notice Period', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo sprintf(_n('%d day', '%d days', $lease['notice_period_days'], 'rental-gates'), $lease['notice_period_days']); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Notes -->
        <?php if (!empty($lease['notes'])): ?>
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Notes', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <p style="white-space: pre-wrap; margin: 0;"><?php echo esc_html($lease['notes']); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="rg-lease-aside">
        <!-- Financial Summary -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Financial', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-item" style="margin-bottom: 16px;">
                    <div class="rg-info-label"><?php _e('Monthly Rent', 'rental-gates'); ?></div>
                    <div class="rg-info-value large" style="color: var(--success);">$<?php echo number_format($lease['rent_amount'], 2); ?></div>
                </div>
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Deposit', 'rental-gates'); ?></div>
                        <div class="rg-info-value">$<?php echo number_format($lease['deposit_amount'] ?: 0, 2); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Billing Day', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo $lease['billing_day']; ?><?php echo $lease['billing_day'] == 1 ? 'st' : ($lease['billing_day'] == 2 ? 'nd' : ($lease['billing_day'] == 3 ? 'rd' : 'th')); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Unit Info -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Unit', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-item" style="margin-bottom: 12px;">
                    <div class="rg-info-label"><?php _e('Unit', 'rental-gates'); ?></div>
                    <div class="rg-info-value">
                        <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $lease['building_id'] . '/units/' . $lease['unit_id']); ?>" style="color: var(--primary); text-decoration: none;">
                            <?php echo esc_html($lease['unit_name']); ?>
                        </a>
                    </div>
                </div>
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Building', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo esc_html($lease['building_name']); ?></div>
                </div>
                <?php if (!empty($lease['derived_address'])): ?>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Address', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo esc_html($lease['derived_address']); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Info -->
        <div class="rg-card">
            <div class="rg-card-header">
                <h3><?php _e('Quick Info', 'rental-gates'); ?></h3>
            </div>
            <div class="rg-card-body">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Lease ID', 'rental-gates'); ?></div>
                    <div class="rg-info-value">#<?php echo $lease['id']; ?></div>
                </div>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Created', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('F j, Y', strtotime($lease['created_at'])); ?></div>
                </div>
                <?php if ($lease['signed_at']): ?>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Signed', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('F j, Y', strtotime($lease['signed_at'])); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Documents Widget -->
        <?php 
        $entity_type = 'lease';
        $entity_id = $lease['id'];
        include RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/partials/documents-widget.php';
        ?>
    </div>
</div>

<!-- Renew Modal -->
<div id="renew-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div style="background: #fff; border-radius: 12px; padding: 24px; max-width: 400px; width: 90%;">
        <h3 style="margin: 0 0 16px 0;"><?php _e('Renew Lease', 'rental-gates'); ?></h3>
        <form id="renew-form">
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 500;"><?php _e('New End Date', 'rental-gates'); ?></label>
                <input type="date" name="new_end_date" required style="width: 100%; padding: 10px; border: 1px solid var(--gray-300); border-radius: 8px;" min="<?php echo date('Y-m-d', strtotime($lease['end_date'] ?: '+1 day')); ?>">
            </div>
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 500;"><?php _e('New Monthly Rent (optional)', 'rental-gates'); ?></label>
                <input type="number" name="new_rent_amount" step="0.01" placeholder="<?php echo $lease['rent_amount']; ?>" style="width: 100%; padding: 10px; border: 1px solid var(--gray-300); border-radius: 8px;">
            </div>
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="hideRenewModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Renew Lease', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function activateLease(leaseId) {
    RentalGates.confirmDelete({
        title: '<?php _e('Activate Lease', 'rental-gates'); ?>',
        message: '<?php _e('Activate this lease? This will mark the unit as occupied and tenant(s) as active.', 'rental-gates'); ?>',
        ajaxAction: 'rental_gates_activate_lease',
        ajaxData: { lease_id: leaseId },
        onConfirm: function() {
            window.location.reload();
        }
    });
}

function deleteLease(leaseId) {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Lease', 'rental-gates'); ?>',
        message: '<?php _e('Delete this draft lease? This cannot be undone.', 'rental-gates'); ?>',
        ajaxAction: 'rental_gates_delete_lease',
        ajaxData: { lease_id: leaseId },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/leases'); ?>'
    });
}

function endLease(leaseId) {
    RentalGates.confirmDelete({
        title: '<?php _e('End Lease', 'rental-gates'); ?>',
        message: '<?php _e('End this lease? This will mark the unit as available and tenant(s) as former.', 'rental-gates'); ?>',
        ajaxAction: 'rental_gates_end_lease',
        ajaxData: { lease_id: leaseId },
        onConfirm: function() {
            window.location.reload();
        }
    });
}

function showRenewModal() {
    document.getElementById('renew-modal').style.display = 'flex';
}

function hideRenewModal() {
    document.getElementById('renew-modal').style.display = 'none';
}

document.getElementById('renew-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_renew_lease');
    formData.append('lease_id', <?php echo $lease['id']; ?>);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.href = '<?php echo home_url('/rental-gates/dashboard/leases/'); ?>' + data.data.id;
            } else {
                alert(data.data || '<?php _e('Error renewing lease', 'rental-gates'); ?>');
            }
        });
});

function addTenant(e, leaseId) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData();
    formData.append('action', 'rental_gates_add_lease_tenant');
    formData.append('lease_id', leaseId);
    formData.append('tenant_id', form.tenant_id.value);
    formData.append('role', form.role.value);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.data || '<?php _e('Error adding tenant', 'rental-gates'); ?>');
            }
        });
}

function removeTenant(leaseId, tenantId, tenantName) {
    RentalGates.confirmDelete({
        title: '<?php _e('Remove Tenant', 'rental-gates'); ?>',
        message: '<?php _e('Remove this tenant from the lease?', 'rental-gates'); ?>',
        itemName: tenantName || '',
        ajaxAction: 'rental_gates_remove_lease_tenant',
        ajaxData: { lease_id: leaseId, tenant_id: tenantId },
        onConfirm: function() {
            window.location.reload();
        }
    });
}
</script>
