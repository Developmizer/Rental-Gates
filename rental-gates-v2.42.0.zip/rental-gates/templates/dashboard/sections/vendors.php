<?php
/**
 * Vendors List Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Get vendors
$args = array(
    'status' => $status_filter ?: null,
    'category' => $category_filter ?: null,
    'search' => $search ?: null,
    'per_page' => 50,
);

$result = Rental_Gates_Vendor::get_for_organization($org_id, $args);
$vendors = $result['items'];
$stats = Rental_Gates_Vendor::get_stats($org_id);

// Get categories for filter
$categories = Rental_Gates_Vendor::get_service_categories();

// Status config
$status_config = array(
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'paused' => array('label' => __('Paused', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'inactive' => array('label' => __('Inactive', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);
?>

<style>
    .rg-vendors-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-vendors-header h1 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 16px 20px; }
    .rg-stat-card.highlight { border-color: #3b82f6; background: linear-gradient(135deg, #eff6ff 0%, #fff 100%); }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-filters-row { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .rg-search-box { flex: 1; min-width: 200px; position: relative; }
    .rg-search-box input { width: 100%; padding: 10px 14px 10px 40px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background-color: #fff; }
    .rg-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); }
    .rg-filter-select { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background-color: #fff; min-width: 140px; }
    
    .rg-vendors-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-vendors-table th { text-align: left; padding: 14px 16px; background: var(--gray-50); font-weight: 600; font-size: 13px; color: var(--gray-600); border-bottom: 1px solid var(--gray-200); }
    .rg-vendors-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); vertical-align: middle; }
    .rg-vendors-table tr:last-child td { border-bottom: none; }
    .rg-vendors-table tr:hover td { background-color: var(--gray-50); }
    
    .rg-vendor-info { display: flex; align-items: center; gap: 12px; }
    .rg-vendor-avatar { width: 40px; height: 40px; border-radius: 10px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 14px; flex-shrink: 0; }
    .rg-vendor-name { font-weight: 600; color: var(--gray-900); }
    .rg-vendor-contact { font-size: 13px; color: var(--gray-500); }
    
    .rg-category-tags { display: flex; flex-wrap: wrap; gap: 4px; }
    .rg-category-tag { display: inline-flex; align-items: center; padding: 3px 8px; background: var(--gray-100); color: var(--gray-700); border-radius: 4px; font-size: 11px; font-weight: 500; }
    .rg-category-tag.more { background: var(--gray-200); color: var(--gray-600); }
    
    .rg-vendor-rate { font-weight: 600; color: var(--gray-900); }
    .rg-vendor-rate small { font-weight: 400; color: var(--gray-500); }
    
    .rg-status-badge { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    
    .rg-action-btn { padding: 6px 12px; border: 1px solid var(--gray-300); background: #fff; border-radius: 6px; font-size: 13px; color: var(--gray-700); cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 4px; }
    .rg-action-btn:hover { background: var(--gray-50); border-color: var(--gray-400); }
    .rg-action-btn.primary { background: #3b82f6; border-color: #3b82f6; color: #fff; }
    .rg-action-btn.primary:hover { background: #2563eb; }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; background: #fff; border-radius: 12px; border: 1px solid var(--gray-200); }
    .rg-empty-state svg { width: 64px; height: 64px; color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { font-size: 18px; font-weight: 600; color: var(--gray-900); margin: 0 0 8px 0; }
    .rg-empty-state p { color: var(--gray-500); margin: 0 0 20px 0; }
    
    @media (max-width: 768px) {
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
        .rg-vendors-table { display: block; overflow-x: auto; }
    }
</style>

<div class="rg-vendors-header">
    <h1><?php _e('Vendors', 'rental-gates'); ?></h1>
    <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors/add')); ?>" class="rg-action-btn primary">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
        </svg>
        <?php _e('Add Vendor', 'rental-gates'); ?>
    </a>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card highlight">
        <div class="rg-stat-value"><?php echo intval($stats['total']); ?></div>
        <div class="rg-stat-label"><?php _e('Total Vendors', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value" style="color: #10b981;"><?php echo intval($stats['active']); ?></div>
        <div class="rg-stat-label"><?php _e('Active', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value" style="color: #8b5cf6;"><?php echo intval($stats['with_active_jobs']); ?></div>
        <div class="rg-stat-label"><?php _e('Working on Jobs', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value" style="color: #6b7280;"><?php echo intval($stats['inactive'] + $stats['paused']); ?></div>
        <div class="rg-stat-label"><?php _e('Inactive/Paused', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" class="rg-filters-row">
    <div class="rg-search-box">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <input type="text" name="search" placeholder="<?php esc_attr_e('Search vendors...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
    </div>
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
        <option value="paused" <?php selected($status_filter, 'paused'); ?>><?php _e('Paused', 'rental-gates'); ?></option>
        <option value="inactive" <?php selected($status_filter, 'inactive'); ?>><?php _e('Inactive', 'rental-gates'); ?></option>
    </select>
    <select name="category" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Categories', 'rental-gates'); ?></option>
        <?php foreach ($categories as $key => $label): ?>
            <option value="<?php echo esc_attr($key); ?>" <?php selected($category_filter, $key); ?>><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
    </select>
</form>

<?php if (empty($vendors)): ?>
    <div class="rg-empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
            <circle cx="9" cy="7" r="4"></circle>
            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
        </svg>
        <h3><?php _e('No Vendors Yet', 'rental-gates'); ?></h3>
        <p><?php _e('Add vendors to assign them to maintenance work orders.', 'rental-gates'); ?></p>
        <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors/add')); ?>" class="rg-action-btn primary">
            <?php _e('Add Your First Vendor', 'rental-gates'); ?>
        </a>
    </div>
<?php else: ?>
    <table class="rg-vendors-table">
        <thead>
            <tr>
                <th><?php _e('Vendor', 'rental-gates'); ?></th>
                <th><?php _e('Services', 'rental-gates'); ?></th>
                <th><?php _e('Contact', 'rental-gates'); ?></th>
                <th><?php _e('Rate', 'rental-gates'); ?></th>
                <th><?php _e('Status', 'rental-gates'); ?></th>
                <th><?php _e('Actions', 'rental-gates'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($vendors as $vendor): 
                $initials = strtoupper(substr($vendor['company_name'], 0, 1) . (isset($vendor['company_name'][strpos($vendor['company_name'], ' ') + 1]) ? $vendor['company_name'][strpos($vendor['company_name'], ' ') + 1] : substr($vendor['company_name'], 1, 1)));
                $status_style = $status_config[$vendor['status']] ?? $status_config['inactive'];
                $cats = array_slice($vendor['service_categories_labels'], 0, 2);
                $more_cats = count($vendor['service_categories']) - 2;
            ?>
                <tr>
                    <td>
                        <div class="rg-vendor-info">
                            <div class="rg-vendor-avatar"><?php echo esc_html($initials); ?></div>
                            <div>
                                <div class="rg-vendor-name"><?php echo esc_html($vendor['company_name']); ?></div>
                                <div class="rg-vendor-contact"><?php echo esc_html($vendor['contact_name']); ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="rg-category-tags">
                            <?php foreach ($cats as $cat): ?>
                                <span class="rg-category-tag"><?php echo esc_html($cat); ?></span>
                            <?php endforeach; ?>
                            <?php if ($more_cats > 0): ?>
                                <span class="rg-category-tag more">+<?php echo $more_cats; ?></span>
                            <?php endif; ?>
                            <?php if (empty($vendor['service_categories'])): ?>
                                <span class="rg-category-tag" style="color: var(--gray-400);">—</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div style="font-size: 14px;"><?php echo esc_html($vendor['email']); ?></div>
                        <div style="font-size: 13px; color: var(--gray-500);"><?php echo esc_html($vendor['phone']); ?></div>
                    </td>
                    <td>
                        <?php if ($vendor['hourly_rate']): ?>
                            <span class="rg-vendor-rate">$<?php echo number_format($vendor['hourly_rate'], 2); ?><small>/hr</small></span>
                        <?php else: ?>
                            <span style="color: var(--gray-400);">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="rg-status-badge" style="background: <?php echo esc_attr($status_style['bg']); ?>; color: <?php echo esc_attr($status_style['color']); ?>;">
                            <?php echo esc_html($status_style['label']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?php echo esc_url(home_url('/rental-gates/dashboard/vendors/' . $vendor['id'])); ?>" class="rg-action-btn">
                            <?php _e('View', 'rental-gates'); ?>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
