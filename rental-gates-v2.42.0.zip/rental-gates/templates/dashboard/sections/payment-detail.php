<?php
/**
 * Payment Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get payment ID from URL - PRIMARY method: parse REQUEST_URI directly
$payment_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/payments/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $payment_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$payment_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    $payment_id = isset($parts[1]) ? intval($parts[1]) : 0;
}

if (!$payment_id) {
    wp_redirect(home_url('/rental-gates/dashboard/payments'));
    exit;
}

$payment = Rental_Gates_Payment::get_with_details($payment_id);

if (!$payment || $payment['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/payments'));
    exit;
}

// Status config
$status_config = array(
    'pending' => array('label' => __('Pending', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'processing' => array('label' => __('Processing', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'succeeded' => array('label' => __('Paid', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'partially_paid' => array('label' => __('Partial', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'failed' => array('label' => __('Failed', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'refunded' => array('label' => __('Refunded', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'cancelled' => array('label' => __('Cancelled', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

$status = $status_config[$payment['status']] ?? $status_config['pending'];

// Tenant initials
$initials = '';
if (!empty($payment['tenant_name'])) {
    $name_parts = explode(' ', $payment['tenant_name']);
    foreach ($name_parts as $part) {
        $initials .= strtoupper(substr($part, 0, 1));
    }
    $initials = substr($initials, 0, 2);
}
?>

<style>
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    .rg-payment-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-payment-title h1 { font-size: 24px; font-weight: 700; margin: 0 0 8px 0; }
    .rg-payment-meta { display: flex; align-items: center; gap: 12px; color: var(--gray-500); font-size: 14px; }
    .rg-header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-status-badge .dot { width: 8px; height: 8px; border-radius: 50%; }
    
    .rg-payment-grid { display: grid; grid-template-columns: 1fr 360px; gap: 24px; }
    .rg-payment-main { min-width: 0; }
    .rg-payment-aside { min-width: 0; }
    
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); }
    .rg-card-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .rg-card-body { padding: 20px; }
    
    .rg-amount-display { text-align: center; padding: 24px; }
    .rg-amount-value { font-size: 42px; font-weight: 700; color: var(--gray-900); }
    .rg-amount-value.refund { color: #ef4444; }
    .rg-amount-label { font-size: 14px; color: var(--gray-500); margin-top: 4px; }
    .rg-amount-balance { margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-100); font-size: 14px; }
    .rg-amount-balance span { color: var(--gray-500); }
    .rg-amount-balance strong { color: #f59e0b; }
    
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-value { font-size: 14px; color: var(--gray-900); font-weight: 500; }
    .rg-info-value a { color: var(--primary); text-decoration: none; }
    
    .rg-tenant-card { display: flex; gap: 16px; padding: 16px; background: var(--gray-50); border-radius: 10px; }
    .rg-tenant-avatar { width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px; flex-shrink: 0; }
    .rg-tenant-details h4 { margin: 0 0 4px 0; font-size: 16px; }
    .rg-tenant-details h4 a { color: inherit; text-decoration: none; }
    .rg-tenant-details p { margin: 0; color: var(--gray-500); font-size: 14px; }
    
    .rg-unit-link { display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--gray-50); border-radius: 8px; text-decoration: none; color: inherit; }
    .rg-unit-link:hover { background: var(--gray-100); }
    .rg-unit-link svg { color: var(--gray-400); }
    .rg-unit-link span { color: var(--gray-900); font-weight: 500; }
    
    .rg-overdue-alert { display: flex; align-items: center; gap: 12px; padding: 16px; background: #fee2e2; border: 1px solid #fca5a5; border-radius: 10px; margin-bottom: 24px; }
    .rg-overdue-alert svg { color: #dc2626; flex-shrink: 0; }
    .rg-overdue-alert strong { color: #991b1b; }
    .rg-overdue-alert span { color: #b91c1c; font-size: 14px; }
    
    .rg-notes-text { white-space: pre-wrap; color: var(--gray-700); line-height: 1.6; }
    
    .rg-btn-success { background: #10b981; color: #fff; border-color: #10b981; }
    .rg-btn-success:hover { background: #059669; }
    .rg-btn-danger { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }
    .rg-btn-danger:hover { background: #fecaca; }
    
    .rg-modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .rg-modal-content { background: #fff; border-radius: 12px; padding: 24px; max-width: 400px; width: 90%; }
    .rg-modal h3 { margin: 0 0 16px 0; }
    .rg-modal-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
    .rg-form-group { margin-bottom: 16px; }
    .rg-form-label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 14px; }
    .rg-form-select, .rg-form-input { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    
    @media (max-width: 992px) { .rg-payment-grid { grid-template-columns: 1fr; } }
    @media (max-width: 576px) { .rg-info-grid { grid-template-columns: 1fr; } }
</style>

<a href="<?php echo home_url('/rental-gates/dashboard/payments'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    <?php _e('Back to Payments', 'rental-gates'); ?>
</a>

<?php if ($payment['is_overdue']): ?>
<div class="rg-overdue-alert">
    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
    <div>
        <strong><?php _e('Overdue Payment', 'rental-gates'); ?></strong><br>
        <span><?php printf(__('This payment is %d days overdue.', 'rental-gates'), $payment['days_overdue']); ?></span>
    </div>
</div>
<?php endif; ?>

<div class="rg-payment-header">
    <div class="rg-payment-title">
        <h1><?php echo esc_html($payment['payment_number']); ?></h1>
        <div class="rg-payment-meta">
            <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                <?php echo $status['label']; ?>
            </span>
            <span><?php echo esc_html($payment['type_label']); ?></span>
            <span><?php echo date('M j, Y', strtotime($payment['created_at'])); ?></span>
        </div>
    </div>
    <div class="rg-header-actions">
        <?php if ($payment['status'] === 'pending'): ?>
            <button type="button" class="rg-btn rg-btn-success" onclick="showMarkPaidModal()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <?php _e('Mark as Paid', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-danger" onclick="cancelPayment()"><?php _e('Cancel', 'rental-gates'); ?></button>
        <?php endif; ?>
        <?php if (in_array($payment['status'], array('pending', 'cancelled'))): ?>
            <button type="button" class="rg-btn rg-btn-secondary" onclick="deletePayment()"><?php _e('Delete', 'rental-gates'); ?></button>
        <?php endif; ?>
    </div>
</div>

<div class="rg-payment-grid">
    <div class="rg-payment-main">
        <!-- Payment Details -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Payment Details', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Payment Number', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($payment['payment_number']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Type', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($payment['type_label']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Method', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($payment['method_label']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Due Date', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo $payment['due_date'] ? date('F j, Y', strtotime($payment['due_date'])) : '—'; ?></div>
                    </div>
                    <?php if ($payment['paid_at']): ?>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Paid At', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo date('F j, Y g:i A', strtotime($payment['paid_at'])); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($payment['period_start'] && $payment['period_end']): ?>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Period', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo date('M j', strtotime($payment['period_start'])); ?> - <?php echo date('M j, Y', strtotime($payment['period_end'])); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Tenant -->
        <?php if (!empty($payment['tenant_name'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Tenant', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-tenant-card">
                    <div class="rg-tenant-avatar"><?php echo $initials; ?></div>
                    <div class="rg-tenant-details">
                        <h4><a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $payment['tenant_id']); ?>"><?php echo esc_html($payment['tenant_name']); ?></a></h4>
                        <p><?php echo esc_html($payment['tenant_email'] ?? ''); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Unit -->
        <?php if (!empty($payment['unit_name'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Property', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $payment['building_id']); ?>" class="rg-unit-link">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <span><?php echo esc_html($payment['unit_name']); ?> • <?php echo esc_html($payment['building_name']); ?></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Notes -->
        <?php if (!empty($payment['description']) || !empty($payment['notes'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Notes', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <?php if (!empty($payment['description'])): ?>
                <p class="rg-notes-text"><?php echo esc_html($payment['description']); ?></p>
                <?php endif; ?>
                <?php if (!empty($payment['notes'])): ?>
                <p class="rg-notes-text" style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--gray-100);"><?php echo esc_html($payment['notes']); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Failure Reason -->
        <?php if ($payment['status'] === 'failed' && !empty($payment['failure_reason'])): ?>
        <div class="rg-card" style="border-color: #fca5a5;">
            <div class="rg-card-header" style="background: #fee2e2;"><h3 style="color: #991b1b;"><?php _e('Failure Reason', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <p style="color: #b91c1c;"><?php echo esc_html($payment['failure_reason']); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="rg-payment-aside">
        <!-- Amount -->
        <div class="rg-card">
            <div class="rg-card-body">
                <div class="rg-amount-display">
                    <div class="rg-amount-value <?php echo $payment['type'] === 'refund' ? 'refund' : ''; ?>">
                        <?php echo $payment['type'] === 'refund' ? '-' : ''; ?>$<?php echo number_format($payment['amount'], 2); ?>
                    </div>
                    <div class="rg-amount-label"><?php echo esc_html($payment['type_label']); ?></div>
                    
                    <?php if ($payment['balance'] > 0 && $payment['status'] !== 'succeeded'): ?>
                    <div class="rg-amount-balance">
                        <span><?php _e('Paid:', 'rental-gates'); ?></span> $<?php echo number_format($payment['amount_paid'], 2); ?><br>
                        <span><?php _e('Balance:', 'rental-gates'); ?></span> <strong>$<?php echo number_format($payment['balance'], 2); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Quick Info -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Quick Info', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Status', 'rental-gates'); ?></div>
                    <div class="rg-info-value">
                        <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                            <?php echo $status['label']; ?>
                        </span>
                    </div>
                </div>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Created', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('M j, Y g:i A', strtotime($payment['created_at'])); ?></div>
                </div>
                <?php if ($payment['lease_id']): ?>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Lease', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><a href="<?php echo home_url('/rental-gates/dashboard/leases/' . $payment['lease_id']); ?>"><?php _e('View Lease', 'rental-gates'); ?> →</a></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Mark Paid Modal -->
<div id="mark-paid-modal" class="rg-modal">
    <div class="rg-modal-content">
        <h3><?php _e('Mark as Paid', 'rental-gates'); ?></h3>
        <div class="rg-form-group">
            <label class="rg-form-label"><?php _e('Payment Method', 'rental-gates'); ?></label>
            <select id="payment-method" class="rg-form-select">
                <option value="cash"><?php _e('Cash', 'rental-gates'); ?></option>
                <option value="check"><?php _e('Check', 'rental-gates'); ?></option>
                <option value="stripe_card"><?php _e('Credit Card', 'rental-gates'); ?></option>
                <option value="stripe_ach"><?php _e('Bank Transfer', 'rental-gates'); ?></option>
                <option value="money_order"><?php _e('Money Order', 'rental-gates'); ?></option>
                <option value="other"><?php _e('Other', 'rental-gates'); ?></option>
            </select>
        </div>
        <div class="rg-form-group">
            <label class="rg-form-label"><?php _e('Notes (optional)', 'rental-gates'); ?></label>
            <input type="text" id="payment-notes" class="rg-form-input" placeholder="<?php _e('e.g., Check #1234', 'rental-gates'); ?>">
        </div>
        <div class="rg-modal-actions">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="hideMarkPaidModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
            <button type="button" class="rg-btn rg-btn-success" onclick="markPaid()"><?php _e('Mark as Paid', 'rental-gates'); ?></button>
        </div>
    </div>
</div>

<script>
function showMarkPaidModal() { document.getElementById('mark-paid-modal').style.display = 'flex'; }
function hideMarkPaidModal() { document.getElementById('mark-paid-modal').style.display = 'none'; }

function markPaid() {
    const formData = new FormData();
    formData.append('action', 'rental_gates_mark_payment_paid');
    formData.append('payment_id', <?php echo $payment['id']; ?>);
    formData.append('method', document.getElementById('payment-method').value);
    formData.append('notes', document.getElementById('payment-notes').value);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function cancelPayment() {
    RentalGates.confirmDelete({
        title: '<?php _e('Cancel Payment', 'rental-gates'); ?>',
        message: '<?php _e('Cancel this payment?', 'rental-gates'); ?>',
        ajaxAction: 'rental_gates_cancel_payment',
        ajaxData: { payment_id: <?php echo $payment['id']; ?> },
        onConfirm: function() {
            window.location.reload();
        }
    });
}

function deletePayment() {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Payment', 'rental-gates'); ?>',
        message: '<?php _e('Delete this payment? This cannot be undone.', 'rental-gates'); ?>',
        itemName: '$<?php echo number_format($payment['amount'], 2); ?>',
        ajaxAction: 'rental_gates_delete_payment',
        ajaxData: { payment_id: <?php echo $payment['id']; ?> },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/payments'); ?>'
    });
}
</script>
