<?php
/**
 * Maintenance Detail Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get work order ID from URL - PRIMARY method: parse REQUEST_URI directly
$work_order_id = 0;
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/maintenance/(\d+)(?:/|$|\?)#', $uri, $matches)) {
        $work_order_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$work_order_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    $work_order_id = isset($parts[1]) ? intval($parts[1]) : 0;
}

if (!$work_order_id) {
    wp_redirect(home_url('/rental-gates/dashboard/maintenance'));
    exit;
}

$wo = Rental_Gates_Maintenance::get_with_details($work_order_id);

if (!$wo || $wo['organization_id'] !== $org_id) {
    wp_redirect(home_url('/rental-gates/dashboard/maintenance'));
    exit;
}

// Status config
$status_config = array(
    'open' => array('label' => __('Open', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'assigned' => array('label' => __('Assigned', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'in_progress' => array('label' => __('In Progress', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'on_hold' => array('label' => __('On Hold', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'completed' => array('label' => __('Completed', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'cancelled' => array('label' => __('Cancelled', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'declined' => array('label' => __('Declined', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
);

$priority_config = array(
    'emergency' => array('label' => __('Emergency', 'rental-gates'), 'color' => '#dc2626', 'bg' => '#fee2e2'),
    'high' => array('label' => __('High', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'medium' => array('label' => __('Medium', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'low' => array('label' => __('Low', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

$status = $status_config[$wo['status']] ?? $status_config['open'];
$priority = $priority_config[$wo['priority']] ?? $priority_config['medium'];

// Tenant initials
$tenant_initials = '';
if (!empty($wo['tenant_name'])) {
    $name_parts = explode(' ', $wo['tenant_name']);
    foreach ($name_parts as $part) {
        $tenant_initials .= strtoupper(substr($part, 0, 1));
    }
    $tenant_initials = substr($tenant_initials, 0, 2);
}
?>

<style>
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    
    .rg-wo-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-wo-title h1 { font-size: 24px; font-weight: 700; margin: 0 0 8px 0; }
    .rg-wo-meta { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
    .rg-header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
    
    .rg-priority-badge { display: inline-flex; align-items: center; gap: 4px; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-priority-badge.emergency { animation: pulse 2s infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
    .rg-status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: 500; }
    .rg-status-badge .dot { width: 8px; height: 8px; border-radius: 50%; }
    
    .rg-wo-grid { display: grid; grid-template-columns: 1fr 360px; gap: 24px; }
    .rg-wo-main { min-width: 0; }
    .rg-wo-aside { min-width: 0; }
    
    .rg-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-card-header h3 { font-size: 16px; font-weight: 600; margin: 0; }
    .rg-card-body { padding: 20px; }
    
    .rg-description { white-space: pre-wrap; color: var(--gray-700); line-height: 1.6; }
    
    .rg-photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px; }
    .rg-photo-item { display: block; border-radius: 8px; overflow: hidden; aspect-ratio: 1; border: 1px solid var(--gray-200); transition: all 0.2s; }
    .rg-photo-item:hover { transform: scale(1.02); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .rg-photo-item img { width: 100%; height: 100%; object-fit: cover; }
    
    .rg-info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .rg-info-item { }
    .rg-info-label { font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-value { font-size: 14px; color: var(--gray-900); font-weight: 500; }
    .rg-info-value a { color: var(--primary); text-decoration: none; }
    
    .rg-tenant-card { display: flex; gap: 16px; padding: 16px; background: var(--gray-50); border-radius: 10px; }
    .rg-tenant-avatar { width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px; flex-shrink: 0; }
    .rg-tenant-details h4 { margin: 0 0 4px 0; font-size: 16px; }
    .rg-tenant-details p { margin: 0; color: var(--gray-500); font-size: 14px; }
    
    .rg-location-card { display: flex; align-items: center; gap: 12px; padding: 16px; background: var(--gray-50); border-radius: 10px; }
    .rg-location-card svg { color: var(--gray-400); flex-shrink: 0; }
    .rg-location-card strong { display: block; color: var(--gray-900); }
    .rg-location-card span { font-size: 13px; color: var(--gray-500); }
    
    .rg-notes-section { }
    .rg-note-item { padding: 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-note-item:last-child { border-bottom: none; }
    .rg-note-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .rg-note-author { font-weight: 600; font-size: 14px; }
    .rg-note-date { font-size: 12px; color: var(--gray-500); }
    .rg-note-text { color: var(--gray-700); line-height: 1.5; }
    .rg-note-internal { background: #fef3c7; border-radius: 4px; padding: 2px 6px; font-size: 11px; color: #92400e; margin-left: 8px; }
    
    .rg-add-note { padding: 16px; border-top: 1px solid var(--gray-100); }
    .rg-add-note textarea { width: 100%; padding: 10px; border: 1px solid var(--gray-300); border-radius: 8px; min-height: 80px; resize: vertical; font-family: inherit; }
    .rg-add-note-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 12px; }
    
    .rg-status-actions { display: flex; flex-wrap: wrap; gap: 8px; }
    .rg-status-btn { padding: 8px 16px; border: 1px solid var(--gray-300); border-radius: 8px; background: #fff; font-size: 13px; cursor: pointer; }
    .rg-status-btn:hover { background: var(--gray-50); }
    .rg-status-btn.active { border-color: var(--primary); background: var(--primary); color: #fff; }
    .rg-status-btn.complete { border-color: #10b981; color: #10b981; }
    .rg-status-btn.complete:hover { background: #d1fae5; }
    
    .rg-btn-danger { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }
    .rg-btn-danger:hover { background: #fecaca; }
    
    .rg-modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .rg-modal-content { background: #fff; border-radius: 12px; padding: 24px; max-width: 450px; width: 90%; }
    .rg-modal h3 { margin: 0 0 16px 0; }
    .rg-modal-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
    .rg-form-group { margin-bottom: 16px; }
    .rg-form-label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 14px; }
    .rg-form-select, .rg-form-input { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background-color: #fff; }
    
    @media (max-width: 992px) { .rg-wo-grid { grid-template-columns: 1fr; } }
    @media (max-width: 576px) { .rg-info-grid { grid-template-columns: 1fr; } }
</style>

<a href="<?php echo home_url('/rental-gates/dashboard/maintenance'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    <?php _e('Back to Maintenance', 'rental-gates'); ?>
</a>

<div class="rg-wo-header">
    <div class="rg-wo-title">
        <h1><?php echo esc_html($wo['title']); ?></h1>
        <div class="rg-wo-meta">
            <span class="rg-priority-badge <?php echo $wo['priority']; ?>" style="background: <?php echo $priority['bg']; ?>; color: <?php echo $priority['color']; ?>;">
                <?php echo $priority['label']; ?>
            </span>
            <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                <?php echo $status['label']; ?>
            </span>
            <span style="color: var(--gray-500);"><?php echo esc_html($wo['category_label']); ?></span>
        </div>
    </div>
    <div class="rg-header-actions">
        <?php if (!in_array($wo['status'], array('completed', 'cancelled'))): ?>
            <a href="<?php echo home_url('/rental-gates/dashboard/maintenance/' . $wo['id'] . '/edit'); ?>" class="rg-btn rg-btn-secondary"><?php _e('Edit', 'rental-gates'); ?></a>
            <button type="button" class="rg-btn rg-btn-primary" onclick="showCompleteModal()"><?php _e('Mark Complete', 'rental-gates'); ?></button>
        <?php endif; ?>
    </div>
</div>

<div class="rg-wo-grid">
    <div class="rg-wo-main">
        <!-- Description -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Description', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <p class="rg-description"><?php echo esc_html($wo['description']); ?></p>
            </div>
        </div>
        
        <?php 
        // Parse photos from JSON
        $photos = array();
        if (!empty($wo['photos'])) {
            $photos = is_array($wo['photos']) ? $wo['photos'] : json_decode($wo['photos'], true);
        }
        if (!empty($photos)): 
        ?>
        <!-- Photos -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Photos', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-photo-grid">
                    <?php foreach ($photos as $photo): ?>
                    <a href="<?php echo esc_url($photo); ?>" target="_blank" class="rg-photo-item">
                        <img src="<?php echo esc_url($photo); ?>" alt="<?php _e('Maintenance photo', 'rental-gates'); ?>">
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Details -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Details', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-grid">
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Category', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($wo['category_label']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Priority', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo esc_html($wo['priority_label']); ?></div>
                    </div>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Permission to Enter', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo $wo['permission_to_enter'] ? __('Yes', 'rental-gates') : __('No', 'rental-gates'); ?></div>
                    </div>
                    <?php if ($wo['scheduled_date']): ?>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Scheduled Date', 'rental-gates'); ?></div>
                        <div class="rg-info-value"><?php echo date('F j, Y', strtotime($wo['scheduled_date'])); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($wo['cost_estimate']): ?>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Cost Estimate', 'rental-gates'); ?></div>
                        <div class="rg-info-value">$<?php echo number_format($wo['cost_estimate'], 2); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($wo['final_cost']): ?>
                    <div class="rg-info-item">
                        <div class="rg-info-label"><?php _e('Final Cost', 'rental-gates'); ?></div>
                        <div class="rg-info-value">$<?php echo number_format($wo['final_cost'], 2); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if (!empty($wo['access_instructions'])): ?>
                <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--gray-100);">
                    <div class="rg-info-label"><?php _e('Access Instructions', 'rental-gates'); ?></div>
                    <p class="rg-description" style="margin-top: 8px;"><?php echo esc_html($wo['access_instructions']); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Status Update -->
        <?php if (!in_array($wo['status'], array('completed', 'cancelled'))): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Update Status', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-status-actions">
                    <?php
                    $statuses = array('open', 'assigned', 'in_progress', 'on_hold');
                    foreach ($statuses as $s):
                        $sc = $status_config[$s];
                    ?>
                    <button type="button" class="rg-status-btn <?php echo $wo['status'] === $s ? 'active' : ''; ?>" 
                            onclick="updateStatus('<?php echo $s; ?>')" <?php echo $wo['status'] === $s ? 'disabled' : ''; ?>>
                        <?php echo $sc['label']; ?>
                    </button>
                    <?php endforeach; ?>
                    <button type="button" class="rg-status-btn complete" onclick="showCompleteModal()"><?php _e('Complete', 'rental-gates'); ?></button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Notes -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Notes & Updates', 'rental-gates'); ?></h3></div>
            <div class="rg-notes-section">
                <?php if (!empty($wo['notes'])): ?>
                    <?php foreach ($wo['notes'] as $note): 
                        $note_attachments = array();
                        if (!empty($note['attachments'])) {
                            $note_attachments = is_array($note['attachments']) ? $note['attachments'] : json_decode($note['attachments'], true);
                        }
                    ?>
                    <div class="rg-note-item">
                        <div class="rg-note-header">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span class="rg-note-author"><?php echo esc_html($note['user_name'] ?: 'Unknown'); ?></span>
                                <?php if ($note['user_type'] === 'tenant'): ?>
                                <span style="background: #d1fae5; border-radius: 4px; padding: 2px 6px; font-size: 11px; color: #065f46;"><?php _e('Tenant', 'rental-gates'); ?></span>
                                <?php elseif ($note['user_type'] === 'vendor'): ?>
                                <span style="background: #fef3c7; border-radius: 4px; padding: 2px 6px; font-size: 11px; color: #92400e;"><?php _e('Vendor', 'rental-gates'); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($note['is_internal'])): ?>
                                <span class="rg-note-internal"><?php _e('Internal', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="rg-note-date"><?php echo date('M j, Y g:i A', strtotime($note['created_at'])); ?></span>
                        </div>
                        <p class="rg-note-text"><?php echo nl2br(esc_html($note['note'])); ?></p>
                        <?php if (!empty($note_attachments)): ?>
                        <div class="rg-note-attachments" style="display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap;">
                            <?php foreach ($note_attachments as $att): ?>
                            <a href="<?php echo esc_url($att); ?>" target="_blank" style="display: block; width: 80px; height: 80px; border-radius: 6px; overflow: hidden; border: 1px solid var(--gray-200);">
                                <img src="<?php echo esc_url($att); ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                            </a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="rg-note-item" style="text-align: center; color: var(--gray-500);">
                        <?php _e('No notes yet', 'rental-gates'); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="rg-add-note">
                <textarea id="new-note" placeholder="<?php _e('Add a note...', 'rental-gates'); ?>"></textarea>
                <div class="rg-add-note-actions">
                    <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 13px;">
                        <input type="checkbox" id="note-internal" style="width: 16px; height: 16px;">
                        <?php _e('Internal note (not visible to tenants)', 'rental-gates'); ?>
                    </label>
                    <button type="button" class="rg-btn rg-btn-primary" onclick="addNote()"><?php _e('Add Note', 'rental-gates'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="rg-wo-aside">
        <!-- Location -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Location', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $wo['building_id']); ?>" class="rg-location-card" style="text-decoration: none;">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <div>
                        <strong><?php echo esc_html($wo['unit_name'] ?: $wo['building_name']); ?></strong>
                        <?php if ($wo['unit_name']): ?>
                        <span><?php echo esc_html($wo['building_name']); ?></span>
                        <?php endif; ?>
                    </div>
                </a>
            </div>
        </div>
        
        <!-- Tenant -->
        <?php if (!empty($wo['tenant_name'])): ?>
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Reported By', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-tenant-card">
                    <div class="rg-tenant-avatar"><?php echo $tenant_initials; ?></div>
                    <div class="rg-tenant-details">
                        <h4><a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $wo['tenant_id']); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html($wo['tenant_name']); ?></a></h4>
                        <?php if ($wo['tenant_phone']): ?>
                        <p><a href="tel:<?php echo esc_attr($wo['tenant_phone']); ?>"><?php echo esc_html($wo['tenant_phone']); ?></a></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Quick Info -->
        <div class="rg-card">
            <div class="rg-card-header"><h3><?php _e('Quick Info', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <div class="rg-info-item">
                    <div class="rg-info-label"><?php _e('Work Order ID', 'rental-gates'); ?></div>
                    <div class="rg-info-value">#<?php echo $wo['id']; ?></div>
                </div>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Created', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('M j, Y g:i A', strtotime($wo['created_at'])); ?></div>
                </div>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Days Open', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo $wo['days_open']; ?> days</div>
                </div>
                <?php if ($wo['completed_at']): ?>
                <div class="rg-info-item" style="margin-top: 12px;">
                    <div class="rg-info-label"><?php _e('Completed', 'rental-gates'); ?></div>
                    <div class="rg-info-value"><?php echo date('M j, Y g:i A', strtotime($wo['completed_at'])); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Danger Zone -->
        <?php if (!in_array($wo['status'], array('completed'))): ?>
        <div class="rg-card" style="border-color: #fca5a5;">
            <div class="rg-card-header" style="background: #fef2f2;"><h3 style="color: #991b1b;"><?php _e('Danger Zone', 'rental-gates'); ?></h3></div>
            <div class="rg-card-body">
                <button type="button" class="rg-btn rg-btn-danger" style="width: 100%;" onclick="deleteWorkOrder()"><?php _e('Delete Work Order', 'rental-gates'); ?></button>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Complete Modal -->
<div id="complete-modal" class="rg-modal">
    <div class="rg-modal-content">
        <h3><?php _e('Mark as Complete', 'rental-gates'); ?></h3>
        <div class="rg-form-group">
            <label class="rg-form-label"><?php _e('Final Cost (optional)', 'rental-gates'); ?></label>
            <input type="number" id="final-cost" class="rg-form-input" step="0.01" min="0" placeholder="0.00" value="<?php echo $wo['cost_estimate'] ?: ''; ?>">
        </div>
        <div class="rg-form-group">
            <label class="rg-form-label"><?php _e('Cause', 'rental-gates'); ?></label>
            <select id="cause" class="rg-form-select">
                <option value=""><?php _e('Select cause...', 'rental-gates'); ?></option>
                <option value="normal_wear"><?php _e('Normal Wear & Tear', 'rental-gates'); ?></option>
                <option value="tenant_responsibility"><?php _e('Tenant Responsibility', 'rental-gates'); ?></option>
                <option value="external"><?php _e('External Factor', 'rental-gates'); ?></option>
                <option value="unknown"><?php _e('Unknown', 'rental-gates'); ?></option>
            </select>
        </div>
        <div class="rg-modal-actions">
            <button type="button" class="rg-btn rg-btn-secondary" onclick="hideCompleteModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
            <button type="button" class="rg-btn rg-btn-primary" onclick="completeWorkOrder()"><?php _e('Mark Complete', 'rental-gates'); ?></button>
        </div>
    </div>
</div>

<script>
function showCompleteModal() { document.getElementById('complete-modal').style.display = 'flex'; }
function hideCompleteModal() { document.getElementById('complete-modal').style.display = 'none'; }

function updateStatus(status) {
    const formData = new FormData();
    formData.append('action', 'rental_gates_update_maintenance_status');
    formData.append('work_order_id', <?php echo $wo['id']; ?>);
    formData.append('status', status);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function completeWorkOrder() {
    const formData = new FormData();
    formData.append('action', 'rental_gates_complete_maintenance');
    formData.append('work_order_id', <?php echo $wo['id']; ?>);
    formData.append('final_cost', document.getElementById('final-cost').value);
    formData.append('cause', document.getElementById('cause').value);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function addNote() {
    const note = document.getElementById('new-note').value.trim();
    if (!note) return;
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_add_maintenance_note');
    formData.append('work_order_id', <?php echo $wo['id']; ?>);
    formData.append('note', note);
    formData.append('is_internal', document.getElementById('note-internal').checked ? '1' : '0');
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.success) window.location.reload(); else alert(data.data); });
}

function deleteWorkOrder() {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Work Order', 'rental-gates'); ?>',
        message: '<?php _e('Delete this work order? This cannot be undone.', 'rental-gates'); ?>',
        itemName: '#<?php echo $wo['id']; ?> - <?php echo esc_js($wo['title']); ?>',
        ajaxAction: 'rental_gates_delete_maintenance',
        ajaxData: { work_order_id: <?php echo $wo['id']; ?> },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/maintenance'); ?>'
    });
}
</script>
