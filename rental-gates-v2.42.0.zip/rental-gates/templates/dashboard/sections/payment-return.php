<?php
/**
 * Payment Return Page - Stripe Checkout
 * 
 * Handles the return from Stripe Embedded or Hosted Checkout.
 * Syncs payment status directly with Stripe (fallback for webhook).
 */
if (!defined('ABSPATH')) exit;

$session_id = isset($_GET['session_id']) ? sanitize_text_field($_GET['session_id']) : '';
$payment_id = isset($_GET['payment_id']) ? intval($_GET['payment_id']) : 0;
$status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';

// Determine if current user is a tenant or owner/PM
$current_user_id = get_current_user_id();
$is_tenant_user = false;
$base_url = '/rental-gates/dashboard';

if ($current_user_id) {
    global $wpdb;
    $tables = Rental_Gates_Database::get_table_names();
    $tenant_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$tables['tenants']} WHERE user_id = %d AND status = 'active'",
        $current_user_id
    ));
    if ($tenant_count > 0) {
        $is_tenant_user = true;
        $base_url = '/rental-gates/tenant';
    }
}

// Initialize variables
$session_status = null;
$session_data = null;
$sync_result = null;
$receipt_url = '';

// If we have a session_id, sync the payment directly from Stripe
// This is the fallback when webhooks haven't fired yet
if ($session_id && Rental_Gates_Stripe::is_configured()) {
    // Sync payment from Stripe session (this updates the database)
    $sync_result = Rental_Gates_Stripe::sync_payment_from_session($session_id);
    
    // Get session details for display
    $session = Rental_Gates_Stripe::get_checkout_session($session_id);
    if (!is_wp_error($session)) {
        $session_status = $session['status'];
        $session_data = array(
            'payment_status' => $session['payment_status'] ?? '',
            'amount_total' => isset($session['amount_total']) ? $session['amount_total'] / 100 : 0,
            'customer_email' => $session['customer_details']['email'] ?? '',
        );
        
        // Get payment_id from session if not in URL
        if (!$payment_id && isset($session['metadata']['payment_id'])) {
            $payment_id = intval($session['metadata']['payment_id']);
        }
    }
    
    // Get receipt URL from sync result
    if (!is_wp_error($sync_result) && isset($sync_result['receipt_url'])) {
        $receipt_url = $sync_result['receipt_url'];
    }
}

// Get payment details for additional info
$payment = null;
if ($payment_id) {
    $payment = Rental_Gates_Payment::get_with_details($payment_id);
    
    // Get receipt URL from payment meta if not from sync
    if (!$receipt_url && $payment && !empty($payment['meta_data'])) {
        $meta = is_array($payment['meta_data']) ? $payment['meta_data'] : json_decode($payment['meta_data'], true);
        if (isset($meta['stripe_details']['receipt_url'])) {
            $receipt_url = $meta['stripe_details']['receipt_url'];
        }
    }
}

// Determine display state
$is_success = ($session_status === 'complete' && ($session_data['payment_status'] ?? '') === 'paid');
$is_processing = ($session_status === 'complete' && ($session_data['payment_status'] ?? '') === 'unpaid');
$is_open = ($session_status === 'open');
$is_cancelled = ($status === 'cancelled');

// Also check if sync was successful even if session check failed
if (!$is_success && !is_wp_error($sync_result) && isset($sync_result['status']) && $sync_result['status'] === 'synced') {
    $is_success = true;
    $session_data = array(
        'amount_total' => $sync_result['amount'] ?? 0,
        'customer_email' => '',
    );
}
?>

<style>
    .payment-return-container {
        max-width: 500px;
        margin: 40px auto;
        text-align: center;
        padding: 0 20px;
    }
    
    .payment-return-card {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
        padding: 48px 32px;
    }
    
    .payment-return-icon {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 24px;
    }
    
    .payment-return-icon.success { background: #d1fae5; }
    .payment-return-icon.processing { background: #dbeafe; }
    .payment-return-icon.error { background: #fee2e2; }
    .payment-return-icon.cancelled { background: #f3f4f6; }
    
    .payment-return-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0 0 12px;
    }
    
    .payment-return-message {
        font-size: 15px;
        color: var(--gray-600);
        margin: 0 0 24px;
        line-height: 1.6;
    }
    
    .payment-return-amount {
        font-size: 32px;
        font-weight: 700;
        color: #059669;
        margin-bottom: 8px;
    }
    
    .payment-return-email {
        font-size: 14px;
        color: var(--gray-500);
        margin-bottom: 24px;
    }
    
    .payment-return-actions {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    
    .payment-return-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        text-decoration: none;
        transition: all 0.2s;
        border: none;
        cursor: pointer;
    }
    
    .payment-return-btn.primary {
        background: var(--primary);
        color: #fff;
    }
    .payment-return-btn.primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
    }
    
    .payment-return-btn.secondary {
        background: var(--gray-100);
        color: var(--gray-700);
        border: 1px solid var(--gray-200);
    }
    .payment-return-btn.secondary:hover {
        background: var(--gray-200);
    }
    
    .payment-return-details {
        margin-top: 24px;
        padding-top: 24px;
        border-top: 1px solid var(--gray-200);
        text-align: left;
    }
    
    .payment-return-detail-row {
        display: flex;
        justify-content: space-between;
        font-size: 14px;
        padding: 8px 0;
    }
    
    .payment-return-detail-label {
        color: var(--gray-500);
    }
    
    .payment-return-detail-value {
        color: var(--gray-900);
        font-weight: 500;
    }
</style>

<div class="payment-return-container">
    <div class="payment-return-card">
        <?php if ($is_success): 
            // Try to get internal receipt
            $internal_receipt = null;
            if ($payment_id) {
                $internal_receipt = Rental_Gates_Invoice::get_by_payment($payment_id);
            }
        ?>
            <!-- Payment Successful -->
            <div class="payment-return-icon success">
                <svg width="40" height="40" fill="none" stroke="#059669" stroke-width="3" viewBox="0 0 24 24">
                    <path d="M20 6L9 17l-5-5"/>
                </svg>
            </div>
            <h1 class="payment-return-title"><?php _e('Payment Successful!', 'rental-gates'); ?></h1>
            <p class="payment-return-message"><?php _e('Thank you for your payment. A confirmation email will be sent shortly.', 'rental-gates'); ?></p>
            
            <?php if (!empty($session_data['amount_total'])): ?>
                <div class="payment-return-amount">$<?php echo number_format($session_data['amount_total'], 2); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($session_data['customer_email'])): ?>
                <div class="payment-return-email">
                    <?php printf(__('Receipt sent to %s', 'rental-gates'), esc_html($session_data['customer_email'])); ?>
                </div>
            <?php endif; ?>
            
            <div class="payment-return-actions">
                <?php if ($internal_receipt): ?>
                <a href="<?php echo esc_url(home_url($base_url . '/invoice?id=' . $internal_receipt['id'])); ?>" class="payment-return-btn primary" style="background: #10b981;">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                        <line x1="16" y1="13" x2="8" y2="13"/>
                        <line x1="16" y1="17" x2="8" y2="17"/>
                    </svg>
                    <?php _e('View Receipt', 'rental-gates'); ?>
                </a>
                <?php elseif ($receipt_url): ?>
                <a href="<?php echo esc_url($receipt_url); ?>" target="_blank" class="payment-return-btn primary" style="background: #10b981;">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                        <line x1="16" y1="13" x2="8" y2="13"/>
                        <line x1="16" y1="17" x2="8" y2="17"/>
                    </svg>
                    <?php _e('View Stripe Receipt', 'rental-gates'); ?>
                </a>
                <?php endif; ?>
                <a href="<?php echo esc_url(home_url($base_url . '/payments')); ?>" class="payment-return-btn primary">
                    <?php _e('View Payment History', 'rental-gates'); ?>
                </a>
                <a href="<?php echo esc_url(home_url($base_url)); ?>" class="payment-return-btn secondary">
                    <?php _e('Return to Dashboard', 'rental-gates'); ?>
                </a>
            </div>
            
        <?php elseif ($is_processing): ?>
            <!-- Payment Processing (ACH/Bank Transfer) -->
            <div class="payment-return-icon processing">
                <svg width="40" height="40" fill="none" stroke="#2563eb" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                </svg>
            </div>
            <h1 class="payment-return-title"><?php _e('Payment Processing', 'rental-gates'); ?></h1>
            <p class="payment-return-message"><?php _e('Your payment is being processed. Bank transfers typically take 3-5 business days to complete. You will receive a confirmation email once the payment is successful.', 'rental-gates'); ?></p>
            
            <?php if ($session_data['amount_total']): ?>
                <div class="payment-return-amount" style="color: #2563eb;">$<?php echo number_format($session_data['amount_total'], 2); ?></div>
            <?php endif; ?>
            
            <div class="payment-return-actions">
                <a href="<?php echo esc_url(home_url($base_url . '/payments')); ?>" class="payment-return-btn primary">
                    <?php _e('View Payment History', 'rental-gates'); ?>
                </a>
            </div>
            
        <?php elseif ($is_open): ?>
            <!-- Session Still Open (Payment not completed) -->
            <div class="payment-return-icon error">
                <svg width="40" height="40" fill="none" stroke="#dc2626" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 8v4M12 16h.01"/>
                </svg>
            </div>
            <h1 class="payment-return-title"><?php _e('Payment Not Completed', 'rental-gates'); ?></h1>
            <p class="payment-return-message"><?php _e('Your payment was not completed. Please try again or contact support if you continue to experience issues.', 'rental-gates'); ?></p>
            
            <div class="payment-return-actions">
                <a href="<?php echo esc_url(home_url($base_url . '/payments')); ?>" class="payment-return-btn primary">
                    <?php _e('Try Again', 'rental-gates'); ?>
                </a>
            </div>
            
        <?php elseif ($is_cancelled): ?>
            <!-- Payment Cancelled -->
            <div class="payment-return-icon cancelled">
                <svg width="40" height="40" fill="none" stroke="#6b7280" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M15 9l-6 6M9 9l6 6"/>
                </svg>
            </div>
            <h1 class="payment-return-title"><?php _e('Payment Cancelled', 'rental-gates'); ?></h1>
            <p class="payment-return-message"><?php _e('Your payment was cancelled. No charges have been made to your account.', 'rental-gates'); ?></p>
            
            <div class="payment-return-actions">
                <a href="<?php echo esc_url(home_url($base_url . '/payments')); ?>" class="payment-return-btn primary">
                    <?php _e('Return to Payments', 'rental-gates'); ?>
                </a>
            </div>
            
        <?php else: ?>
            <!-- Unknown State -->
            <div class="payment-return-icon cancelled">
                <svg width="40" height="40" fill="none" stroke="#6b7280" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 8v4M12 16h.01"/>
                </svg>
            </div>
            <h1 class="payment-return-title"><?php _e('Payment Status Unknown', 'rental-gates'); ?></h1>
            <p class="payment-return-message"><?php _e('We could not determine the status of your payment. Please check your payment history or contact support.', 'rental-gates'); ?></p>
            
            <div class="payment-return-actions">
                <a href="<?php echo esc_url(home_url($base_url . '/payments')); ?>" class="payment-return-btn primary">
                    <?php _e('View Payment History', 'rental-gates'); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($is_success): ?>
<script>
// Auto-redirect after 5 seconds
setTimeout(function() {
    window.location.href = '<?php echo esc_url(home_url($base_url . '/payments')); ?>';
}, 5000);
</script>
<?php endif; ?>
