<?php
/**
 * Messages Section - Communication Hub
 * Displays conversations with tenants, staff, and vendors
 */
if (!defined('ABSPATH')) exit;

// Ensure org_id is set
if (empty($org_id)) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

$current_user_id = get_current_user_id();
$current_user_type = 'staff';

// Get threads
$threads = Rental_Gates_Message::get_user_threads($org_id, $current_user_id, $current_user_type, 50);

// Get unread count
$unread_count = Rental_Gates_Message::get_unread_count($org_id, $current_user_id, $current_user_type);

// Check if viewing a specific thread
$active_thread_id = null;
$active_thread = null;
$active_messages = array();

if (preg_match('#/messages/(\d+)#', $_SERVER['REQUEST_URI'], $matches)) {
    $active_thread_id = intval($matches[1]);
    $active_thread = Rental_Gates_Message::get_thread($active_thread_id);
    
    if ($active_thread && $active_thread['organization_id'] == $org_id) {
        $active_messages = Rental_Gates_Message::get_thread_messages($active_thread_id);
        Rental_Gates_Message::mark_as_read($active_thread_id, $current_user_id, $current_user_type);
        
        if ($active_thread['participant_1_id'] == $current_user_id && $active_thread['participant_1_type'] == $current_user_type) {
            $active_thread['other_participant'] = Rental_Gates_Message::get_participant_info($active_thread['participant_2_id'], $active_thread['participant_2_type']);
        } else {
            $active_thread['other_participant'] = Rental_Gates_Message::get_participant_info($active_thread['participant_1_id'], $active_thread['participant_1_type']);
        }
    } else {
        $active_thread = null;
    }
}

$contacts = Rental_Gates_Message::get_contacts($org_id);
?>

<style>
    .rg-messages-container { display: flex; height: calc(100vh - 140px); background: #fff; border-radius: 12px; overflow: hidden; border: 1px solid var(--gray-200); }
    .rg-messages-sidebar { width: 340px; border-right: 1px solid var(--gray-200); display: flex; flex-direction: column; flex-shrink: 0; }
    .rg-messages-header { padding: 20px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .rg-messages-title { font-size: 18px; font-weight: 700; color: var(--gray-900); margin: 0; display: flex; align-items: center; gap: 8px; }
    .rg-unread-badge { background: var(--primary); color: #fff; font-size: 12px; padding: 2px 8px; border-radius: 10px; }
    .rg-threads-list { flex: 1; overflow-y: auto; }
    .rg-thread-item { display: flex; gap: 12px; padding: 16px 20px; border-bottom: 1px solid var(--gray-100); cursor: pointer; transition: background 0.2s; text-decoration: none; }
    .rg-thread-item:hover { background: var(--gray-50); }
    .rg-thread-item.active { background: #eff6ff; border-left: 3px solid var(--primary); }
    .rg-thread-item.unread { background: #fefce8; }
    .rg-thread-item.unread .rg-thread-name { font-weight: 700; }
    .rg-thread-avatar { width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 16px; flex-shrink: 0; overflow: hidden; }
    .rg-thread-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .rg-thread-content { flex: 1; min-width: 0; }
    .rg-thread-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
    .rg-thread-name { font-weight: 600; color: var(--gray-900); font-size: 14px; }
    .rg-thread-time { font-size: 12px; color: var(--gray-400); }
    .rg-thread-preview { font-size: 13px; color: var(--gray-500); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rg-thread-type { font-size: 11px; color: var(--gray-400); text-transform: uppercase; letter-spacing: 0.5px; }
    .rg-chat-area { flex: 1; display: flex; flex-direction: column; }
    .rg-chat-header { padding: 16px 24px; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; gap: 12px; }
    .rg-chat-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; overflow: hidden; }
    .rg-chat-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .rg-chat-info h3 { margin: 0; font-size: 16px; font-weight: 600; color: var(--gray-900); }
    .rg-chat-info p { margin: 0; font-size: 13px; color: var(--gray-500); }
    .rg-messages-area { flex: 1; padding: 24px; overflow-y: auto; background: var(--gray-50); }
    .rg-message { display: flex; gap: 12px; margin-bottom: 16px; max-width: 75%; }
    .rg-message.sent { margin-left: auto; flex-direction: row-reverse; }
    .rg-message-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--gray-300); display: flex; align-items: center; justify-content: center; font-size: 12px; color: #fff; flex-shrink: 0; overflow: hidden; }
    .rg-message-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .rg-message-bubble { background: #fff; padding: 12px 16px; border-radius: 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    .rg-message.sent .rg-message-bubble { background: var(--primary); color: #fff; }
    .rg-message-text { font-size: 14px; line-height: 1.5; margin: 0; word-wrap: break-word; }
    .rg-message-time { font-size: 11px; color: var(--gray-400); margin-top: 4px; }
    .rg-message.sent .rg-message-time { color: rgba(255,255,255,0.7); }
    .rg-chat-input { padding: 16px 24px; border-top: 1px solid var(--gray-200); background: #fff; }
    .rg-chat-form { display: flex; gap: 12px; }
    .rg-chat-form textarea { flex: 1; padding: 12px 16px; border: 1px solid var(--gray-300); border-radius: 24px; font-size: 14px; resize: none; max-height: 120px; font-family: inherit; }
    .rg-chat-form textarea:focus { outline: none; border-color: var(--primary); }
    .rg-send-btn { width: 48px; height: 48px; border-radius: 50%; background: var(--primary); color: #fff; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s; flex-shrink: 0; }
    .rg-send-btn:hover { background: var(--primary-dark); }
    .rg-send-btn:disabled { background: var(--gray-300); cursor: not-allowed; }
    .rg-chat-empty { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--gray-400); }
    .rg-chat-empty svg { width: 64px; height: 64px; margin-bottom: 16px; }
    .rg-chat-empty h3 { color: var(--gray-600); margin: 0 0 8px; }
    .rg-chat-empty p { margin: 0; }
    .rg-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; }
    .rg-modal-overlay.open { display: flex; }
    .rg-modal { background: #fff; border-radius: 16px; width: 500px; max-width: 90vw; max-height: 80vh; overflow: hidden; display: flex; flex-direction: column; }
    .rg-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-header h2 { margin: 0; font-size: 18px; }
    .rg-modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--gray-400); }
    .rg-modal-body { padding: 24px; flex: 1; overflow-y: auto; }
    .rg-contact-search { width: 100%; padding: 12px 16px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; margin-bottom: 16px; }
    .rg-contacts-section { margin-bottom: 20px; }
    .rg-contacts-section h4 { font-size: 12px; text-transform: uppercase; color: var(--gray-500); margin: 0 0 8px; letter-spacing: 0.5px; }
    .rg-contact-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; cursor: pointer; transition: background 0.2s; }
    .rg-contact-item:hover { background: var(--gray-100); }
    .rg-contact-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--gray-300); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; overflow: hidden; }
    .rg-contact-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .rg-contact-info { flex: 1; }
    .rg-contact-name { font-weight: 500; color: var(--gray-900); }
    .rg-contact-email { font-size: 12px; color: var(--gray-500); }
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    @media (max-width: 768px) {
        .rg-messages-container { flex-direction: column; height: auto; }
        .rg-messages-sidebar { width: 100%; max-height: 300px; }
        .rg-chat-area { min-height: 400px; }
    }
</style>

<div class="rg-messages-container">
    <div class="rg-messages-sidebar">
        <div class="rg-messages-header">
            <h2 class="rg-messages-title">
                <?php _e('Messages', 'rental-gates'); ?>
                <?php if ($unread_count > 0): ?>
                <span class="rg-unread-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </h2>
            <button class="rg-btn rg-btn-primary" onclick="openNewMessageModal()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <?php _e('New', 'rental-gates'); ?>
            </button>
        </div>
        
        <div class="rg-threads-list">
            <?php if (empty($threads)): ?>
            <div style="padding: 40px 20px; text-align: center; color: var(--gray-400);">
                <p><?php _e('No conversations yet', 'rental-gates'); ?></p>
            </div>
            <?php else: ?>
                <?php foreach ($threads as $thread): 
                    $is_active = $active_thread_id == $thread['id'];
                    $is_unread = $thread['unread_count'] > 0;
                    $other = $thread['other_participant'];
                    $initials = strtoupper(substr($other['name'], 0, 1) . substr(strstr($other['name'] . ' ', ' '), 1, 1));
                    $last_msg = $thread['last_message'];
                ?>
                <a href="<?php echo home_url('/rental-gates/dashboard/messages/' . $thread['id']); ?>" class="rg-thread-item <?php echo $is_active ? 'active' : ''; ?> <?php echo $is_unread ? 'unread' : ''; ?>">
                    <div class="rg-thread-avatar">
                        <?php if ($other['avatar']): ?><img src="<?php echo esc_url($other['avatar']); ?>" alt=""><?php else: echo esc_html($initials); endif; ?>
                    </div>
                    <div class="rg-thread-content">
                        <div class="rg-thread-header">
                            <span class="rg-thread-name"><?php echo esc_html($other['name']); ?></span>
                            <?php if ($last_msg): ?><span class="rg-thread-time"><?php echo human_time_diff(strtotime($last_msg['created_at'])); ?></span><?php endif; ?>
                        </div>
                        <div class="rg-thread-type"><?php echo esc_html(ucfirst($other['type'])); ?></div>
                        <?php if ($last_msg): ?><div class="rg-thread-preview"><?php echo esc_html(wp_trim_words($last_msg['message'], 10)); ?></div><?php endif; ?>
                    </div>
                </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="rg-chat-area">
        <?php if ($active_thread): 
            $other = $active_thread['other_participant'];
            $initials = strtoupper(substr($other['name'], 0, 1) . substr(strstr($other['name'] . ' ', ' '), 1, 1));
        ?>
        <div class="rg-chat-header">
            <div class="rg-chat-avatar">
                <?php if ($other['avatar']): ?><img src="<?php echo esc_url($other['avatar']); ?>" alt=""><?php else: echo esc_html($initials); endif; ?>
            </div>
            <div class="rg-chat-info">
                <h3><?php echo esc_html($other['name']); ?></h3>
                <p><?php echo esc_html(ucfirst($other['type'])); ?> • <?php echo esc_html($other['email']); ?></p>
            </div>
        </div>
        
        <div class="rg-messages-area" id="messagesArea">
            <?php foreach ($active_messages as $msg): 
                $is_sent = ($msg['sender_id'] == $current_user_id && $msg['sender_type'] == $current_user_type);
                $sender = $msg['sender'];
                $s_init = strtoupper(substr($sender['name'], 0, 1));
            ?>
            <div class="rg-message <?php echo $is_sent ? 'sent' : 'received'; ?>">
                <?php if (!$is_sent): ?>
                <div class="rg-message-avatar">
                    <?php if ($sender['avatar']): ?><img src="<?php echo esc_url($sender['avatar']); ?>" alt=""><?php else: echo esc_html($s_init); endif; ?>
                </div>
                <?php endif; ?>
                <div class="rg-message-bubble">
                    <p class="rg-message-text"><?php echo nl2br(esc_html($msg['message'])); ?></p>
                    <div class="rg-message-time"><?php echo date_i18n('M j, g:i a', strtotime($msg['created_at'])); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="rg-chat-input">
            <form class="rg-chat-form" id="messageForm">
                <input type="hidden" name="thread_id" value="<?php echo $active_thread_id; ?>">
                <textarea name="message" placeholder="<?php _e('Type a message...', 'rental-gates'); ?>" rows="1" required></textarea>
                <button type="submit" class="rg-send-btn">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                </button>
            </form>
        </div>
        <?php else: ?>
        <div class="rg-chat-empty">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
            <h3><?php _e('Select a conversation', 'rental-gates'); ?></h3>
            <p><?php _e('Choose from your existing conversations or start a new one', 'rental-gates'); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- New Message Modal -->
<div class="rg-modal-overlay" id="newMessageModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h2><?php _e('New Message', 'rental-gates'); ?></h2>
            <button class="rg-modal-close" onclick="closeNewMessageModal()">&times;</button>
        </div>
        <div class="rg-modal-body">
            <input type="text" class="rg-contact-search" placeholder="<?php _e('Search contacts...', 'rental-gates'); ?>" id="contactSearch" oninput="filterContacts(this.value)">
            
            <?php if (!empty($contacts['staff'])): ?>
            <div class="rg-contacts-section" data-section="staff">
                <h4><?php _e('Staff', 'rental-gates'); ?></h4>
                <?php foreach ($contacts['staff'] as $c): if ($c['id'] == $current_user_id) continue; $ini = strtoupper(substr($c['name'], 0, 1) . substr(strstr($c['name'].' ', ' '), 1, 1)); ?>
                <div class="rg-contact-item" onclick="startConversation(<?php echo $c['id']; ?>, 'staff')" data-name="<?php echo esc_attr(strtolower($c['name'])); ?>">
                    <div class="rg-contact-avatar" style="background: linear-gradient(135deg, #3b82f6, #1d4ed8);"><?php if ($c['avatar']): ?><img src="<?php echo esc_url($c['avatar']); ?>" alt=""><?php else: echo $ini; endif; ?></div>
                    <div class="rg-contact-info"><div class="rg-contact-name"><?php echo esc_html($c['name']); ?></div><div class="rg-contact-email"><?php echo esc_html($c['email']); ?></div></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($contacts['tenants'])): ?>
            <div class="rg-contacts-section" data-section="tenants">
                <h4><?php _e('Tenants', 'rental-gates'); ?></h4>
                <?php foreach ($contacts['tenants'] as $c): $ini = strtoupper(substr($c['name'], 0, 1) . substr(strstr($c['name'].' ', ' '), 1, 1)); ?>
                <div class="rg-contact-item" onclick="startConversation(<?php echo $c['id']; ?>, 'tenant')" data-name="<?php echo esc_attr(strtolower($c['name'])); ?>">
                    <div class="rg-contact-avatar" style="background: linear-gradient(135deg, #10b981, #059669);"><?php if (!empty($c['avatar'])): ?><img src="<?php echo esc_url($c['avatar']); ?>" alt=""><?php else: echo $ini; endif; ?></div>
                    <div class="rg-contact-info"><div class="rg-contact-name"><?php echo esc_html($c['name']); ?></div><div class="rg-contact-email"><?php echo esc_html($c['email']); ?></div></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($contacts['vendors'])): ?>
            <div class="rg-contacts-section" data-section="vendors">
                <h4><?php _e('Vendors', 'rental-gates'); ?></h4>
                <?php foreach ($contacts['vendors'] as $c): $ini = strtoupper(substr($c['name'], 0, 2)); ?>
                <div class="rg-contact-item" onclick="startConversation(<?php echo $c['id']; ?>, 'vendor')" data-name="<?php echo esc_attr(strtolower($c['name'])); ?>">
                    <div class="rg-contact-avatar" style="background: linear-gradient(135deg, #f59e0b, #d97706);"><?php echo $ini; ?></div>
                    <div class="rg-contact-info"><div class="rg-contact-name"><?php echo esc_html($c['name']); ?></div><div class="rg-contact-email"><?php echo esc_html($c['email']); ?></div></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if (empty($contacts['staff']) && empty($contacts['tenants']) && empty($contacts['vendors'])): ?>
            <p style="text-align: center; color: var(--gray-500); padding: 40px 0;"><?php _e('No contacts available.', 'rental-gates'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Define ajaxurl for frontend
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

var messagesArea = document.getElementById('messagesArea');
if (messagesArea) messagesArea.scrollTop = messagesArea.scrollHeight;

var messageForm = document.getElementById('messageForm');
if (messageForm) {
    messageForm.addEventListener('submit', function(e) {
        e.preventDefault();
        var textarea = this.querySelector('textarea');
        var message = textarea.value.trim();
        if (!message) return;
        
        var threadId = this.querySelector('input[name="thread_id"]').value;
        if (!threadId) {
            alert('No conversation selected');
            return;
        }
        
        var formData = new FormData();
        formData.append('action', 'rental_gates_send_message');
        formData.append('thread_id', threadId);
        formData.append('message', message);
        formData.append('message_nonce', '<?php echo wp_create_nonce('rental_gates_message'); ?>');
        
        var sendBtn = this.querySelector('.rg-send-btn');
        sendBtn.disabled = true;
        
        fetch(ajaxurl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                // Get message text from response
                var msgText = '';
                if (data.data && data.data.message) {
                    msgText = data.data.message.message || data.data.message.content || message;
                } else {
                    msgText = message;
                }
                
                var html = '<div class="rg-message sent"><div class="rg-message-bubble"><p class="rg-message-text">' + 
                    escapeHtml(msgText).replace(/\n/g, '<br>') + '</p><div class="rg-message-time"><?php _e('Just now', 'rental-gates'); ?></div></div></div>';
                messagesArea.insertAdjacentHTML('beforeend', html);
                messagesArea.scrollTop = messagesArea.scrollHeight;
                textarea.value = '';
            } else {
                var errorMsg = (typeof data.data === 'string') ? data.data : (data.data?.message || '<?php _e('Failed to send message', 'rental-gates'); ?>');
                alert(errorMsg);
            }
            sendBtn.disabled = false;
        })
        .catch(function(err) { 
            console.error('Send error:', err);
            alert('<?php _e('Error sending message. Please try again.', 'rental-gates'); ?>'); 
            sendBtn.disabled = false; 
        });
    });
    
    // Submit on Enter (Shift+Enter for new line)
    var textarea = messageForm.querySelector('textarea');
    if (textarea) {
        textarea.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                messageForm.querySelector('.rg-send-btn').click();
            }
        });
    }
}

function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function openNewMessageModal() { document.getElementById('newMessageModal').classList.add('open'); }
function closeNewMessageModal() { document.getElementById('newMessageModal').classList.remove('open'); }

function filterContacts(query) {
    query = query.toLowerCase();
    document.querySelectorAll('.rg-contact-item').forEach(function(item) {
        var name = item.dataset.name || '';
        item.style.display = name.indexOf(query) > -1 ? '' : 'none';
    });
}

function startConversation(contactId, contactType) {
    var formData = new FormData();
    formData.append('action', 'rental_gates_start_conversation');
    formData.append('contact_id', contactId);
    formData.append('contact_type', contactType);
    formData.append('message_nonce', '<?php echo wp_create_nonce('rental_gates_message'); ?>');
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/messages/'); ?>' + data.data.thread_id;
        } else {
            var errorMsg = (typeof data.data === 'string') ? data.data : (data.data?.message || '<?php _e('Failed to start conversation', 'rental-gates'); ?>');
            alert(errorMsg);
        }
    })
    .catch(function(err) {
        console.error('Start conversation error:', err);
        alert('<?php _e('Error starting conversation', 'rental-gates'); ?>');
    });
}

// Poll for new messages
<?php if ($active_thread_id): ?>
var lastMsgId = <?php 
    $last_id = 0;
    if (!empty($active_messages)) {
        $last = end($active_messages);
        $last_id = $last['id'] ?? 0;
    }
    echo $last_id;
?>;
var currentThreadId = <?php echo $active_thread_id; ?>;

function pollMessages() {
    var formData = new FormData();
    formData.append('action', 'rental_gates_get_new_messages');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
    formData.append('thread_id', currentThreadId);
    formData.append('after_id', lastMsgId);
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success && data.data.messages && data.data.messages.length > 0) {
            data.data.messages.forEach(function(msg) {
                // Skip our own messages (already added optimistically)
                if (msg.sender_type === 'staff' && msg.sender_id == <?php echo $current_user_id; ?>) return;
                
                var html = '<div class="rg-message received"><div class="rg-message-avatar">' + 
                    (msg.sender_name ? msg.sender_name.charAt(0).toUpperCase() : 'U') + '</div>' +
                    '<div class="rg-message-bubble"><p class="rg-message-text">' + 
                    escapeHtml(msg.content || msg.message).replace(/\n/g, '<br>') + 
                    '</p><div class="rg-message-time">' + (msg.time_formatted || '<?php _e('Just now', 'rental-gates'); ?>') + '</div></div></div>';
                messagesArea.insertAdjacentHTML('beforeend', html);
                messagesArea.scrollTop = messagesArea.scrollHeight;
                lastMsgId = Math.max(lastMsgId, msg.id);
            });
        }
    })
    .catch(function(err) { console.error('Poll error:', err); });
}

setInterval(pollMessages, 10000);
<?php endif; ?>

document.getElementById('newMessageModal').addEventListener('click', function(e) {
    if (e.target === this) closeNewMessageModal();
});
</script>
