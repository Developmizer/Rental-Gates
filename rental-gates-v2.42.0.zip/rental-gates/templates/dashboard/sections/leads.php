<?php
/**
 * Leads/CRM Dashboard Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$current_stage = isset($_GET['stage']) ? sanitize_text_field($_GET['stage']) : '';
$current_source = isset($_GET['source']) ? sanitize_text_field($_GET['source']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$view_mode = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'pipeline';

// Get stage counts
$stage_counts = Rental_Gates_Lead::get_stage_counts($org_id);
$total_active = $stage_counts['new'] + $stage_counts['contacted'] + $stage_counts['touring'] + $stage_counts['applied'];

// Get leads based on filters
$filter_args = array('limit' => 100);
if ($current_stage) {
    $filter_args['stage'] = $current_stage;
}
if ($current_source) {
    $filter_args['source'] = $current_source;
}
if ($search) {
    $filter_args['search'] = $search;
}

$leads = Rental_Gates_Lead::get_for_organization($org_id, $filter_args);

// Get leads by stage for pipeline view
$leads_by_stage = array();
foreach (Rental_Gates_Lead::get_stages() as $stage => $config) {
    $leads_by_stage[$stage] = array();
}
foreach ($leads as $lead) {
    $leads_by_stage[$lead['stage']][] = $lead;
}

// Get staff for assignment dropdown
$staff = Rental_Gates_Organization::get_members($org_id);

// Get buildings for interest selection
$buildings = Rental_Gates_Building::get_for_organization($org_id, array('limit' => 100));

$stages = Rental_Gates_Lead::get_stages();
$sources = Rental_Gates_Lead::get_sources();
?>

<style>
    .rg-leads-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-leads-title h1 { font-size: 24px; font-weight: 700; margin: 0; }
    .rg-leads-title p { color: var(--gray-500); margin: 4px 0 0; }
    .rg-header-actions { display: flex; gap: 12px; align-items: center; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; text-align: center; transition: all 0.2s; cursor: pointer; text-decoration: none; color: inherit; }
    .rg-stat-card:hover { border-color: var(--primary); }
    .rg-stat-card.active { border-color: var(--primary); background: #f5f3ff; }
    .rg-stat-value { font-size: 32px; font-weight: 700; margin-bottom: 4px; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); }
    
    .rg-filters { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center; }
    .rg-filter-group { display: flex; align-items: center; gap: 8px; }
    .rg-filter-group label { font-size: 13px; color: var(--gray-500); }
    .rg-filter-group select { padding: 8px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; min-width: 150px; }
    .rg-search-box { flex: 1; min-width: 200px; max-width: 300px; }
    .rg-search-box input { width: 100%; padding: 8px 12px 8px 36px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'/%3E%3C/svg%3E") no-repeat 10px center; background-size: 18px; }
    .rg-view-toggle { display: flex; border: 1px solid var(--gray-300); border-radius: 8px; overflow: hidden; }
    .rg-view-btn { padding: 8px 16px; background: #fff; border: none; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 6px; }
    .rg-view-btn:not(:last-child) { border-right: 1px solid var(--gray-300); }
    .rg-view-btn.active { background: var(--primary); color: #fff; }
    .rg-view-btn svg { width: 16px; height: 16px; }
    
    .rg-pipeline { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; min-height: 500px; }
    .rg-pipeline-column { background: var(--gray-50); border-radius: 12px; padding: 16px; min-height: 400px; }
    .rg-pipeline-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid var(--gray-200); }
    .rg-pipeline-title { font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px; }
    .rg-pipeline-title .dot { width: 10px; height: 10px; border-radius: 50%; }
    .rg-pipeline-count { background: var(--gray-200); padding: 2px 8px; border-radius: 10px; font-size: 12px; font-weight: 600; }
    .rg-pipeline-cards { display: flex; flex-direction: column; gap: 12px; }
    
    .rg-lead-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 14px; cursor: pointer; transition: all 0.2s; }
    .rg-lead-card:hover { border-color: var(--primary); box-shadow: 0 4px 12px rgba(0,0,0,0.08); transform: translateY(-2px); }
    .rg-lead-card-header { display: flex; gap: 12px; margin-bottom: 10px; }
    .rg-lead-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 14px; flex-shrink: 0; }
    .rg-lead-info { flex: 1; min-width: 0; }
    .rg-lead-name { font-weight: 600; font-size: 14px; margin: 0 0 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rg-lead-email { font-size: 12px; color: var(--gray-500); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rg-lead-meta { display: flex; gap: 8px; flex-wrap: wrap; font-size: 11px; }
    .rg-lead-tag { padding: 2px 8px; border-radius: 4px; background: var(--gray-100); color: var(--gray-600); }
    .rg-lead-tag.source { background: #dbeafe; color: #1d4ed8; }
    .rg-lead-tag.follow-up { background: #fef3c7; color: #92400e; }
    .rg-lead-tag.overdue { background: #fee2e2; color: #dc2626; }
    
    .rg-leads-table { width: 100%; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    .rg-leads-table th { background: var(--gray-50); padding: 12px 16px; text-align: left; font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; }
    .rg-leads-table td { padding: 14px 16px; border-top: 1px solid var(--gray-100); }
    .rg-leads-table tr:hover td { background: var(--gray-50); }
    .rg-leads-table .lead-cell { display: flex; align-items: center; gap: 12px; }
    .rg-stage-badge { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    
    .rg-empty { text-align: center; padding: 60px 20px; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; }
    .rg-empty svg { width: 64px; height: 64px; color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty h3 { font-size: 18px; margin: 0 0 8px; }
    .rg-empty p { color: var(--gray-500); margin: 0 0 20px; }
    
    .rg-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; padding: 20px; }
    .rg-modal-overlay.open { display: flex; }
    .rg-modal { background: #fff; border-radius: 16px; max-width: 500px; width: 100%; max-height: 90vh; overflow-y: auto; }
    .rg-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-header h3 { margin: 0; font-size: 18px; }
    .rg-modal-close { background: none; border: none; cursor: pointer; padding: 8px; color: var(--gray-400); border-radius: 8px; }
    .rg-modal-close:hover { background: var(--gray-100); }
    .rg-modal-body { padding: 24px; }
    
    .rg-form-group { margin-bottom: 20px; }
    .rg-form-group label { display: block; font-size: 14px; font-weight: 500; margin-bottom: 6px; }
    .rg-form-group .required { color: #dc2626; }
    .rg-form-group input, .rg-form-group select, .rg-form-group textarea { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-form-group input:focus, .rg-form-group select:focus, .rg-form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1); }
    .rg-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .rg-form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-100); }
    
    @media (max-width: 1024px) {
        .rg-pipeline { grid-template-columns: repeat(2, 1fr); }
        .rg-stats-row { grid-template-columns: repeat(3, 1fr); }
    }
    @media (max-width: 768px) {
        .rg-pipeline { grid-template-columns: 1fr; }
        .rg-stats-row { grid-template-columns: repeat(2, 1fr); }
        .rg-form-row { grid-template-columns: 1fr; }
    }
</style>

<div class="rg-leads-header">
    <div class="rg-leads-title">
        <h1><?php _e('Leads & CRM', 'rental-gates'); ?></h1>
        <p><?php _e('Manage your prospects and track conversions', 'rental-gates'); ?></p>
    </div>
    <div class="rg-header-actions">
        <button class="rg-btn rg-btn-primary" onclick="openAddLeadModal()">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            <?php _e('Add Lead', 'rental-gates'); ?>
        </button>
    </div>
</div>

<div class="rg-stats-row">
    <a href="?stage=" class="rg-stat-card <?php echo empty($current_stage) ? 'active' : ''; ?>">
        <div class="rg-stat-value" style="color: var(--primary);"><?php echo $total_active; ?></div>
        <div class="rg-stat-label"><?php _e('Active Leads', 'rental-gates'); ?></div>
    </a>
    <a href="?stage=new" class="rg-stat-card <?php echo $current_stage === 'new' ? 'active' : ''; ?>">
        <div class="rg-stat-value" style="color: #3b82f6;"><?php echo $stage_counts['new']; ?></div>
        <div class="rg-stat-label"><?php _e('New', 'rental-gates'); ?></div>
    </a>
    <a href="?stage=contacted" class="rg-stat-card <?php echo $current_stage === 'contacted' ? 'active' : ''; ?>">
        <div class="rg-stat-value" style="color: #8b5cf6;"><?php echo $stage_counts['contacted']; ?></div>
        <div class="rg-stat-label"><?php _e('Contacted', 'rental-gates'); ?></div>
    </a>
    <a href="?stage=touring" class="rg-stat-card <?php echo $current_stage === 'touring' ? 'active' : ''; ?>">
        <div class="rg-stat-value" style="color: #f59e0b;"><?php echo $stage_counts['touring']; ?></div>
        <div class="rg-stat-label"><?php _e('Touring', 'rental-gates'); ?></div>
    </a>
    <a href="?stage=won" class="rg-stat-card <?php echo $current_stage === 'won' ? 'active' : ''; ?>">
        <div class="rg-stat-value" style="color: #10b981;"><?php echo $stage_counts['won']; ?></div>
        <div class="rg-stat-label"><?php _e('Won', 'rental-gates'); ?></div>
    </a>
</div>

<div class="rg-filters">
    <div class="rg-filter-group">
        <label><?php _e('Source:', 'rental-gates'); ?></label>
        <select onchange="applyFilter('source', this.value)">
            <option value=""><?php _e('All Sources', 'rental-gates'); ?></option>
            <?php foreach ($sources as $key => $label): ?>
                <option value="<?php echo esc_attr($key); ?>" <?php selected($current_source, $key); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div class="rg-search-box">
        <input type="text" placeholder="<?php esc_attr_e('Search leads...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>" onkeyup="if(event.key==='Enter')applyFilter('search', this.value)">
    </div>
    
    <div style="margin-left: auto;">
        <div class="rg-view-toggle">
            <button class="rg-view-btn <?php echo $view_mode === 'pipeline' ? 'active' : ''; ?>" onclick="applyFilter('view', 'pipeline')">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/></svg>
                <?php _e('Pipeline', 'rental-gates'); ?>
            </button>
            <button class="rg-view-btn <?php echo $view_mode === 'list' ? 'active' : ''; ?>" onclick="applyFilter('view', 'list')">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
                <?php _e('List', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<?php if (empty($leads) && empty($current_stage) && empty($search)): ?>
    <div class="rg-empty">
        <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
            <path d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
        </svg>
        <h3><?php _e('No Leads Yet', 'rental-gates'); ?></h3>
        <p><?php _e('Start building your pipeline by adding leads manually or sharing your QR codes', 'rental-gates'); ?></p>
        <button class="rg-btn rg-btn-primary" onclick="openAddLeadModal()"><?php _e('Add Your First Lead', 'rental-gates'); ?></button>
    </div>
<?php elseif ($view_mode === 'pipeline'): ?>
    <div class="rg-pipeline">
        <?php 
        $pipeline_stages = array('new', 'contacted', 'touring', 'applied');
        foreach ($pipeline_stages as $stage): 
            $stage_config = $stages[$stage];
            $stage_leads = $leads_by_stage[$stage];
        ?>
        <div class="rg-pipeline-column">
            <div class="rg-pipeline-header">
                <div class="rg-pipeline-title">
                    <span class="dot" style="background: <?php echo $stage_config['color']; ?>;"></span>
                    <?php echo $stage_config['label']; ?>
                </div>
                <span class="rg-pipeline-count"><?php echo count($stage_leads); ?></span>
            </div>
            <div class="rg-pipeline-cards" data-stage="<?php echo $stage; ?>">
                <?php foreach ($stage_leads as $lead): ?>
                <div class="rg-lead-card" onclick="viewLead(<?php echo $lead['id']; ?>)" data-lead-id="<?php echo $lead['id']; ?>">
                    <div class="rg-lead-card-header">
                        <div class="rg-lead-avatar"><?php echo esc_html($lead['initials']); ?></div>
                        <div class="rg-lead-info">
                            <h4 class="rg-lead-name"><?php echo esc_html($lead['name']); ?></h4>
                            <p class="rg-lead-email"><?php echo esc_html($lead['email']); ?></p>
                        </div>
                    </div>
                    <div class="rg-lead-meta">
                        <span class="rg-lead-tag source"><?php echo esc_html($lead['source_label']); ?></span>
                        <?php if (!empty($lead['follow_up_date'])): ?>
                            <span class="rg-lead-tag <?php echo !empty($lead['follow_up_overdue']) ? 'overdue' : 'follow-up'; ?>">
                                <?php echo !empty($lead['follow_up_overdue']) ? '⚠️ ' : '📅 '; ?>
                                <?php echo $lead['follow_up_formatted']; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($stage_leads)): ?>
                <div style="text-align: center; padding: 20px; color: var(--gray-400); font-size: 13px;">
                    <?php _e('No leads in this stage', 'rental-gates'); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <?php if (empty($leads)): ?>
        <div class="rg-empty">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            <h3><?php _e('No Leads Found', 'rental-gates'); ?></h3>
            <p><?php _e('Try adjusting your filters or search criteria', 'rental-gates'); ?></p>
        </div>
    <?php else: ?>
    <table class="rg-leads-table">
        <thead>
            <tr>
                <th><?php _e('Lead', 'rental-gates'); ?></th>
                <th><?php _e('Phone', 'rental-gates'); ?></th>
                <th><?php _e('Source', 'rental-gates'); ?></th>
                <th><?php _e('Stage', 'rental-gates'); ?></th>
                <th><?php _e('Follow-up', 'rental-gates'); ?></th>
                <th><?php _e('Created', 'rental-gates'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($leads as $lead): ?>
            <tr onclick="viewLead(<?php echo $lead['id']; ?>)" style="cursor: pointer;">
                <td>
                    <div class="lead-cell">
                        <div class="rg-lead-avatar"><?php echo esc_html($lead['initials']); ?></div>
                        <div>
                            <div style="font-weight: 600;"><?php echo esc_html($lead['name']); ?></div>
                            <div style="font-size: 13px; color: var(--gray-500);"><?php echo esc_html($lead['email']); ?></div>
                        </div>
                    </div>
                </td>
                <td><?php echo esc_html($lead['phone'] ?: '-'); ?></td>
                <td><span class="rg-lead-tag source"><?php echo esc_html($lead['source_label']); ?></span></td>
                <td>
                    <span class="rg-stage-badge" style="background: <?php echo $lead['stage_bg']; ?>; color: <?php echo $lead['stage_color']; ?>;">
                        <?php echo esc_html($lead['stage_label']); ?>
                    </span>
                </td>
                <td>
                    <?php if (!empty($lead['follow_up_date'])): ?>
                        <span class="rg-lead-tag <?php echo !empty($lead['follow_up_overdue']) ? 'overdue' : 'follow-up'; ?>">
                            <?php echo $lead['follow_up_formatted']; ?>
                        </span>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td style="color: var(--gray-500); font-size: 13px;"><?php echo $lead['created_at_relative']; ?></td>
                <td onclick="event.stopPropagation();">
                    <button class="rg-btn rg-btn-secondary" style="padding: 6px 12px; font-size: 12px;" onclick="viewLead(<?php echo $lead['id']; ?>)">
                        <?php _e('View', 'rental-gates'); ?>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
<?php endif; ?>

<!-- Add Lead Modal -->
<div class="rg-modal-overlay" id="addLeadModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3><?php _e('Add New Lead', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeAddLeadModal()">
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="addLeadForm" class="rg-modal-body">
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label><?php _e('Name', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="text" name="name" required placeholder="<?php esc_attr_e('Full name', 'rental-gates'); ?>">
                </div>
                <div class="rg-form-group">
                    <label><?php _e('Email', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="email" name="email" required placeholder="<?php esc_attr_e('email@example.com', 'rental-gates'); ?>">
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label><?php _e('Phone', 'rental-gates'); ?></label>
                    <input type="tel" name="phone" placeholder="<?php esc_attr_e('Phone number', 'rental-gates'); ?>">
                </div>
                <div class="rg-form-group">
                    <label><?php _e('Source', 'rental-gates'); ?></label>
                    <select name="source">
                        <?php foreach ($sources as $key => $label): ?>
                            <option value="<?php echo esc_attr($key); ?>" <?php selected($key, 'manual'); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="rg-form-group">
                <label><?php _e('Interested In', 'rental-gates'); ?></label>
                <select name="building_id">
                    <option value=""><?php _e('Select a property (optional)', 'rental-gates'); ?></option>
                    <?php foreach ($buildings as $building): ?>
                        <option value="<?php echo $building['id']; ?>"><?php echo esc_html($building['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label><?php _e('Assign To', 'rental-gates'); ?></label>
                    <select name="assigned_to">
                        <option value=""><?php _e('Unassigned', 'rental-gates'); ?></option>
                        <?php foreach ($staff as $member): ?>
                            <option value="<?php echo $member['user_id']; ?>"><?php echo esc_html($member['display_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="rg-form-group">
                    <label><?php _e('Follow-up Date', 'rental-gates'); ?></label>
                    <input type="date" name="follow_up_date" min="<?php echo date('Y-m-d'); ?>">
                </div>
            </div>
            
            <div class="rg-form-group">
                <label><?php _e('Notes', 'rental-gates'); ?></label>
                <textarea name="notes" rows="3" placeholder="<?php esc_attr_e('Add any notes about this lead...', 'rental-gates'); ?>"></textarea>
            </div>
            
            <div class="rg-form-actions">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeAddLeadModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary" id="addLeadBtn"><?php _e('Add Lead', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function applyFilter(key, value) {
    const url = new URL(window.location);
    if (value) {
        url.searchParams.set(key, value);
    } else {
        url.searchParams.delete(key);
    }
    window.location = url;
}

function openAddLeadModal() {
    document.getElementById('addLeadModal').classList.add('open');
}

function closeAddLeadModal() {
    document.getElementById('addLeadModal').classList.remove('open');
    document.getElementById('addLeadForm').reset();
}

function viewLead(id) {
    window.location.href = '<?php echo home_url('/rental-gates/dashboard/leads/'); ?>' + id;
}

document.getElementById('addLeadForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('addLeadBtn');
    btn.disabled = true;
    btn.textContent = '<?php echo esc_js(__('Adding...', 'rental-gates')); ?>';
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_create_lead');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
    
    try {
        const response = await fetch(ajaxurl, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.location.href = '<?php echo home_url('/rental-gates/dashboard/leads/'); ?>' + result.data.lead_id;
        } else {
            alert(result.data?.message || '<?php echo esc_js(__('Error adding lead', 'rental-gates')); ?>');
            btn.disabled = false;
            btn.textContent = '<?php echo esc_js(__('Add Lead', 'rental-gates')); ?>';
        }
    } catch (error) {
        alert('<?php echo esc_js(__('Error adding lead', 'rental-gates')); ?>');
        btn.disabled = false;
        btn.textContent = '<?php echo esc_js(__('Add Lead', 'rental-gates')); ?>';
    }
});

document.getElementById('addLeadModal').addEventListener('click', function(e) {
    if (e.target === this) closeAddLeadModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeAddLeadModal();
});
</script>
