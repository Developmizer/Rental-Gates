<?php
/**
 * Tenants List Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

// Get tenants
$args = array(
    'status' => $status_filter ?: null,
    'search' => $search ?: null,
    'orderby' => 'last_name',
    'order' => 'ASC',
);

$tenants = Rental_Gates_Tenant::get_for_organization($org_id, $args);
$stats = Rental_Gates_Tenant::get_stats($org_id);

// Status labels and colors
$status_config = array(
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'former' => array('label' => __('Former', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'prospect' => array('label' => __('Prospect', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
);
?>

<style>
    .rg-tenants-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    
    .rg-tenants-header h1 {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0;
    }
    
    .rg-stats-row {
        display: flex;
        gap: 16px;
        margin-bottom: 24px;
    }
    
    .rg-stat-card {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 16px 20px;
        flex: 1;
    }
    
    .rg-stat-value {
        font-size: 28px;
        font-weight: 700;
        color: var(--gray-900);
    }
    
    .rg-stat-label {
        font-size: 13px;
        color: var(--gray-500);
        margin-top: 4px;
    }
    
    .rg-filters-row {
        display: flex;
        gap: 12px;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }
    
    .rg-search-box {
        flex: 1;
        min-width: 200px;
        position: relative;
    }
    
    .rg-search-box input {
        width: 100%;
        padding: 10px 14px 10px 40px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
    }
    
    .rg-search-box svg {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray-400);
    }
    
    .rg-filter-select {
        padding: 10px 14px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
        min-width: 150px;
    }
    
    .rg-tenants-table {
        background: #fff;
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        overflow: hidden;
    }
    
    .rg-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .rg-table th {
        text-align: left;
        padding: 12px 16px;
        background: var(--gray-50);
        font-weight: 600;
        font-size: 12px;
        text-transform: uppercase;
        color: var(--gray-500);
        border-bottom: 1px solid var(--gray-200);
    }
    
    .rg-table td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--gray-100);
        font-size: 14px;
    }
    
    .rg-table tr:last-child td {
        border-bottom: none;
    }
    
    .rg-table tr:hover {
        background: var(--gray-50);
    }
    
    .rg-tenant-name {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .rg-tenant-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--primary);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 14px;
    }
    
    .rg-tenant-info strong {
        display: block;
        color: var(--gray-900);
    }
    
    .rg-tenant-info span {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .rg-status-badge .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
    }
    
    .rg-portal-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 12px;
    }
    
    .rg-portal-badge.active {
        color: #10b981;
    }
    
    .rg-portal-badge.inactive {
        color: var(--gray-400);
    }
    
    .rg-table-actions {
        display: flex;
        gap: 8px;
    }
    
    .rg-table-action {
        padding: 6px 10px;
        border: 1px solid var(--gray-300);
        border-radius: 6px;
        background: #fff;
        color: var(--gray-600);
        font-size: 12px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    .rg-table-action:hover {
        background: var(--gray-50);
        border-color: var(--gray-400);
    }
    
    .rg-table-action.primary {
        background: var(--primary);
        border-color: var(--primary);
        color: #fff;
    }
    
    .rg-table-action.primary:hover {
        background: var(--primary-dark);
    }
    
    .rg-empty-state {
        text-align: center;
        padding: 60px 20px;
    }
    
    .rg-empty-state svg {
        color: var(--gray-300);
        margin-bottom: 16px;
    }
    
    .rg-empty-state h3 {
        font-size: 18px;
        color: var(--gray-700);
        margin-bottom: 8px;
    }
    
    .rg-empty-state p {
        color: var(--gray-500);
        margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
        .rg-stats-row {
            flex-wrap: wrap;
        }
        
        .rg-stat-card {
            min-width: calc(50% - 8px);
        }
        
        .rg-table-responsive {
            overflow-x: auto;
        }
        
        .rg-table {
            min-width: 700px;
        }
    }
</style>

<!-- Header -->
<div class="rg-tenants-header">
    <h1><?php _e('Tenants', 'rental-gates'); ?></h1>
    <a href="<?php echo home_url('/rental-gates/dashboard/tenants/add'); ?>" class="rg-btn rg-btn-primary">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        <?php _e('Add Tenant', 'rental-gates'); ?>
    </a>
</div>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['total']; ?></div>
        <div class="rg-stat-label"><?php _e('Total Tenants', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['active']; ?></div>
        <div class="rg-stat-label"><?php _e('Active', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['prospect']; ?></div>
        <div class="rg-stat-label"><?php _e('Prospects', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-value"><?php echo $stats['with_portal']; ?></div>
        <div class="rg-stat-label"><?php _e('With Portal Access', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<form method="get" action="" class="rg-filters-row">
    <div class="rg-search-box">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <input type="text" name="search" placeholder="<?php _e('Search tenants...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
    </div>
    
    <select name="status" class="rg-filter-select" onchange="this.form.submit()">
        <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
        <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
        <option value="prospect" <?php selected($status_filter, 'prospect'); ?>><?php _e('Prospect', 'rental-gates'); ?></option>
        <option value="former" <?php selected($status_filter, 'former'); ?>><?php _e('Former', 'rental-gates'); ?></option>
    </select>
    
    <button type="submit" class="rg-btn rg-btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
</form>

<!-- Tenants Table -->
<div class="rg-tenants-table">
    <?php if (empty($tenants)): ?>
    <div class="rg-empty-state">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
        </svg>
        <h3><?php _e('No tenants found', 'rental-gates'); ?></h3>
        <p><?php _e('Get started by adding your first tenant.', 'rental-gates'); ?></p>
        <a href="<?php echo home_url('/rental-gates/dashboard/tenants/add'); ?>" class="rg-btn rg-btn-primary">
            <?php _e('Add Tenant', 'rental-gates'); ?>
        </a>
    </div>
    <?php else: ?>
    <div class="rg-table-responsive">
        <table class="rg-table">
            <thead>
                <tr>
                    <th><?php _e('Tenant', 'rental-gates'); ?></th>
                    <th><?php _e('Phone', 'rental-gates'); ?></th>
                    <th><?php _e('Status', 'rental-gates'); ?></th>
                    <th><?php _e('Portal Access', 'rental-gates'); ?></th>
                    <th><?php _e('Added', 'rental-gates'); ?></th>
                    <th><?php _e('Actions', 'rental-gates'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tenants as $tenant): 
                    $initials = strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1));
                    $status = $status_config[$tenant['status']] ?? $status_config['prospect'];
                ?>
                <tr>
                    <td>
                        <div class="rg-tenant-name">
                            <div class="rg-tenant-avatar"><?php echo $initials; ?></div>
                            <div class="rg-tenant-info">
                                <strong><?php echo esc_html($tenant['full_name']); ?></strong>
                                <span><?php echo esc_html($tenant['email']); ?></span>
                            </div>
                        </div>
                    </td>
                    <td><?php echo esc_html($tenant['phone']); ?></td>
                    <td>
                        <span class="rg-status-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                            <?php echo $status['label']; ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($tenant['has_portal_access']): ?>
                        <span class="rg-portal-badge active">
                            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                            <?php _e('Active', 'rental-gates'); ?>
                        </span>
                        <?php else: ?>
                        <span class="rg-portal-badge inactive">
                            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                            <?php _e('None', 'rental-gates'); ?>
                        </span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date('M j, Y', strtotime($tenant['created_at'])); ?></td>
                    <td>
                        <div class="rg-table-actions">
                            <a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $tenant['id']); ?>" class="rg-table-action">
                                <?php _e('View', 'rental-gates'); ?>
                            </a>
                            <a href="<?php echo home_url('/rental-gates/dashboard/tenants/' . $tenant['id'] . '/edit'); ?>" class="rg-table-action">
                                <?php _e('Edit', 'rental-gates'); ?>
                            </a>
                            <?php if (!$tenant['has_portal_access']): ?>
                            <button type="button" class="rg-table-action primary" onclick="inviteToPortal(<?php echo $tenant['id']; ?>)">
                                <?php _e('Invite', 'rental-gates'); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
function inviteToPortal(tenantId) {
    if (!confirm('<?php _e('Send portal invitation to this tenant? They will receive an email with login credentials.', 'rental-gates'); ?>')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'rental_gates_invite_tenant');
    formData.append('tenant_id', tenantId);
    formData.append('nonce', rentalGatesData.nonce);
    
    fetch(rentalGatesData.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('<?php _e('Invitation sent successfully!', 'rental-gates'); ?>');
            window.location.reload();
        } else {
            alert(data.data || '<?php _e('Error sending invitation', 'rental-gates'); ?>');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('<?php _e('Error sending invitation', 'rental-gates'); ?>');
    });
}
</script>
