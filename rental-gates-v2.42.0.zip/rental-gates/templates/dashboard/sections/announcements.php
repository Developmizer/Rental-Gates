<?php
/**
 * Announcements Section - Broadcast Messages
 * Create and manage announcements to tenants, staff, and vendors
 */
if (!defined('ABSPATH')) exit;

if (empty($org_id)) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Get announcements
$announcements = Rental_Gates_Announcement::get_all($org_id, array('limit' => 50));
$total_count = Rental_Gates_Announcement::count($org_id);
$sent_count = Rental_Gates_Announcement::count($org_id, 'sent');
$scheduled_count = Rental_Gates_Announcement::count($org_id, 'scheduled');

// Check if viewing specific announcement
$view_id = null;
$view_announcement = null;
if (preg_match('#/announcements/(\d+)$#', $_SERVER['REQUEST_URI'], $matches)) {
    $view_id = intval($matches[1]);
    $view_announcement = Rental_Gates_Announcement::get($view_id);
    if ($view_announcement && $view_announcement['organization_id'] != $org_id) {
        $view_announcement = null;
    }
}

// Get buildings and tenants for audience selection
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();
$buildings = $wpdb->get_results($wpdb->prepare(
    "SELECT id, name FROM {$tables['buildings']} WHERE organization_id = %d ORDER BY name",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .rg-page-title { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0; }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; text-align: center; }
    .rg-stat-label { font-size: 13px; color: var(--gray-500); margin-bottom: 8px; }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-value.success { color: #10b981; }
    .rg-stat-value.warning { color: #f59e0b; }
    
    .rg-announcements-list { display: flex; flex-direction: column; gap: 16px; }
    .rg-announcement-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; transition: box-shadow 0.2s; }
    .rg-announcement-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .rg-announcement-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 20px; border-bottom: 1px solid var(--gray-100); }
    .rg-announcement-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0 0 4px; }
    .rg-announcement-meta { font-size: 13px; color: var(--gray-500); }
    .rg-announcement-status { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .rg-announcement-status.sent { background: #d1fae5; color: #065f46; }
    .rg-announcement-status.scheduled { background: #fef3c7; color: #92400e; }
    .rg-announcement-status.draft { background: var(--gray-100); color: var(--gray-600); }
    .rg-announcement-body { padding: 20px; }
    .rg-announcement-preview { color: var(--gray-600); font-size: 14px; line-height: 1.6; }
    .rg-announcement-footer { padding: 16px 20px; background: var(--gray-50); display: flex; justify-content: space-between; align-items: center; }
    .rg-announcement-stats { display: flex; gap: 16px; font-size: 13px; color: var(--gray-500); }
    .rg-announcement-actions { display: flex; gap: 8px; }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: none; cursor: pointer; transition: all 0.2s; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
    .rg-btn-secondary:hover { background: var(--gray-200); }
    .rg-btn-sm { padding: 6px 12px; font-size: 13px; }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; background: #fff; border-radius: 12px; border: 1px solid var(--gray-200); }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { color: var(--gray-900); margin: 0 0 8px; }
    .rg-empty-state p { color: var(--gray-500); margin: 0 0 20px; }
    
    /* Modal Styles */
    .rg-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; overflow-y: auto; padding: 20px; }
    .rg-modal-overlay.open { display: flex; }
    .rg-modal { background: #fff; border-radius: 16px; width: 600px; max-width: 100%; max-height: 90vh; overflow: hidden; display: flex; flex-direction: column; }
    .rg-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-header h2 { margin: 0; font-size: 18px; }
    .rg-modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--gray-400); }
    .rg-modal-body { padding: 24px; flex: 1; overflow-y: auto; }
    .rg-modal-footer { padding: 16px 24px; border-top: 1px solid var(--gray-200); display: flex; justify-content: flex-end; gap: 12px; }
    
    .rg-form-group { margin-bottom: 20px; }
    .rg-form-group label { display: block; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .rg-form-group input, .rg-form-group textarea, .rg-form-group select { width: 100%; padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; font-family: inherit; }
    .rg-form-group input:focus, .rg-form-group textarea:focus, .rg-form-group select:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
    .rg-form-group textarea { min-height: 120px; resize: vertical; }
    .rg-form-hint { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-radio-group { display: flex; flex-wrap: wrap; gap: 12px; }
    .rg-radio-option { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border: 1px solid var(--gray-300); border-radius: 8px; cursor: pointer; transition: all 0.2s; }
    .rg-radio-option:hover { border-color: var(--primary); }
    .rg-radio-option.selected { border-color: var(--primary); background: #eff6ff; }
    .rg-radio-option input { display: none; }
    
    .rg-checkbox-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px; max-height: 200px; overflow-y: auto; padding: 12px; border: 1px solid var(--gray-200); border-radius: 8px; }
    .rg-checkbox-item { display: flex; align-items: center; gap: 8px; font-size: 13px; }
    
    /* Detail View */
    .rg-detail-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    .rg-detail-header { padding: 24px; border-bottom: 1px solid var(--gray-200); }
    .rg-detail-title { font-size: 20px; font-weight: 700; color: var(--gray-900); margin: 0 0 8px; }
    .rg-detail-body { padding: 24px; }
    .rg-detail-content { color: var(--gray-700); font-size: 15px; line-height: 1.7; }
    .rg-detail-info { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 20px 24px; background: var(--gray-50); }
    .rg-info-item label { display: block; font-size: 12px; color: var(--gray-500); margin-bottom: 4px; }
    .rg-info-item span { font-weight: 500; color: var(--gray-900); }
    
    @media (max-width: 768px) {
        .rg-stats-row { grid-template-columns: 1fr; }
        .rg-detail-info { grid-template-columns: 1fr; }
    }
</style>

<?php if ($view_announcement): ?>
<!-- Detail View -->
<div class="rg-page-header">
    <a href="<?php echo home_url('/rental-gates/dashboard/announcements'); ?>" class="rg-btn rg-btn-secondary">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        <?php _e('Back', 'rental-gates'); ?>
    </a>
</div>

<div class="rg-detail-card">
    <div class="rg-detail-header">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
                <h1 class="rg-detail-title"><?php echo esc_html($view_announcement['title']); ?></h1>
                <span class="rg-announcement-meta">
                    <?php _e('Created by', 'rental-gates'); ?> <?php echo esc_html($view_announcement['created_by_name'] ?? __('Unknown', 'rental-gates')); ?>
                    • <?php echo date_i18n('M j, Y g:i a', strtotime($view_announcement['created_at'])); ?>
                </span>
            </div>
            <span class="rg-announcement-status <?php echo $view_announcement['sent_at'] ? 'sent' : ($view_announcement['delivery'] === 'scheduled' ? 'scheduled' : 'draft'); ?>">
                <?php 
                if ($view_announcement['sent_at']) {
                    _e('Sent', 'rental-gates');
                } elseif ($view_announcement['delivery'] === 'scheduled') {
                    _e('Scheduled', 'rental-gates');
                } else {
                    _e('Draft', 'rental-gates');
                }
                ?>
            </span>
        </div>
    </div>
    
    <div class="rg-detail-body">
        <div class="rg-detail-content">
            <?php echo wpautop(esc_html($view_announcement['message'])); ?>
        </div>
    </div>
    
    <div class="rg-detail-info">
        <div class="rg-info-item">
            <label><?php _e('Audience', 'rental-gates'); ?></label>
            <span><?php echo esc_html(ucfirst($view_announcement['audience_type'])); ?></span>
        </div>
        <div class="rg-info-item">
            <label><?php _e('Delivery', 'rental-gates'); ?></label>
            <span>
                <?php 
                if ($view_announcement['sent_at']) {
                    echo date_i18n('M j, Y g:i a', strtotime($view_announcement['sent_at']));
                } elseif ($view_announcement['scheduled_at']) {
                    echo date_i18n('M j, Y g:i a', strtotime($view_announcement['scheduled_at']));
                } else {
                    _e('Immediate', 'rental-gates');
                }
                ?>
            </span>
        </div>
        <div class="rg-info-item">
            <label><?php _e('Channels', 'rental-gates'); ?></label>
            <span><?php echo esc_html(ucfirst(str_replace('_', ' ', $view_announcement['channels']))); ?></span>
        </div>
    </div>
</div>

<?php else: ?>
<!-- List View -->
<div class="rg-page-header">
    <h1 class="rg-page-title"><?php _e('Announcements', 'rental-gates'); ?></h1>
    <button class="rg-btn rg-btn-primary" onclick="openAnnouncementModal()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        <?php _e('New Announcement', 'rental-gates'); ?>
    </button>
</div>

<div class="rg-stats-row">
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Total', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo $total_count; ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Sent', 'rental-gates'); ?></div>
        <div class="rg-stat-value success"><?php echo $sent_count; ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Scheduled', 'rental-gates'); ?></div>
        <div class="rg-stat-value warning"><?php echo $scheduled_count; ?></div>
    </div>
</div>

<?php if (empty($announcements)): ?>
<div class="rg-empty-state">
    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
    <h3><?php _e('No announcements yet', 'rental-gates'); ?></h3>
    <p><?php _e('Create your first announcement to broadcast messages to your tenants, staff, or vendors.', 'rental-gates'); ?></p>
    <button class="rg-btn rg-btn-primary" onclick="openAnnouncementModal()">
        <?php _e('Create Announcement', 'rental-gates'); ?>
    </button>
</div>
<?php else: ?>
<div class="rg-announcements-list">
    <?php foreach ($announcements as $ann): ?>
    <div class="rg-announcement-card">
        <div class="rg-announcement-header">
            <div>
                <h3 class="rg-announcement-title"><?php echo esc_html($ann['title']); ?></h3>
                <span class="rg-announcement-meta">
                    <?php echo date_i18n('M j, Y', strtotime($ann['created_at'])); ?>
                    • <?php echo esc_html(ucfirst($ann['audience_type'])); ?>
                </span>
            </div>
            <span class="rg-announcement-status <?php echo $ann['sent_at'] ? 'sent' : ($ann['delivery'] === 'scheduled' ? 'scheduled' : 'draft'); ?>">
                <?php 
                if ($ann['sent_at']) {
                    _e('Sent', 'rental-gates');
                } elseif ($ann['delivery'] === 'scheduled') {
                    _e('Scheduled', 'rental-gates');
                } else {
                    _e('Draft', 'rental-gates');
                }
                ?>
            </span>
        </div>
        <div class="rg-announcement-body">
            <p class="rg-announcement-preview"><?php echo esc_html(wp_trim_words($ann['message'], 30)); ?></p>
        </div>
        <div class="rg-announcement-footer">
            <div class="rg-announcement-stats">
                <?php if ($ann['sent_at']): ?>
                <span>📤 <?php echo intval($ann['recipient_count']); ?> <?php _e('recipients', 'rental-gates'); ?></span>
                <span>👁 <?php echo intval($ann['read_count']); ?> <?php _e('read', 'rental-gates'); ?></span>
                <?php elseif ($ann['scheduled_at']): ?>
                <span>🕐 <?php echo date_i18n('M j, g:i a', strtotime($ann['scheduled_at'])); ?></span>
                <?php endif; ?>
            </div>
            <div class="rg-announcement-actions">
                <a href="<?php echo home_url('/rental-gates/dashboard/announcements/' . $ann['id']); ?>" class="rg-btn rg-btn-secondary rg-btn-sm"><?php _e('View', 'rental-gates'); ?></a>
                <?php if (!$ann['sent_at']): ?>
                <button class="rg-btn rg-btn-primary rg-btn-sm" onclick="sendAnnouncement(<?php echo $ann['id']; ?>)"><?php _e('Send Now', 'rental-gates'); ?></button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Create Announcement Modal -->
<div class="rg-modal-overlay" id="announcementModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h2><?php _e('New Announcement', 'rental-gates'); ?></h2>
            <button class="rg-modal-close" onclick="closeAnnouncementModal()">&times;</button>
        </div>
        <form id="announcementForm">
            <div class="rg-modal-body">
                <div class="rg-form-group">
                    <label><?php _e('Title', 'rental-gates'); ?> *</label>
                    <input type="text" name="title" required placeholder="<?php _e('Enter announcement title', 'rental-gates'); ?>">
                </div>
                
                <div class="rg-form-group">
                    <label><?php _e('Message', 'rental-gates'); ?> *</label>
                    <textarea name="message" required placeholder="<?php _e('Write your announcement message...', 'rental-gates'); ?>"></textarea>
                </div>
                
                <div class="rg-form-group">
                    <label><?php _e('Audience', 'rental-gates'); ?></label>
                    <div class="rg-radio-group">
                        <label class="rg-radio-option selected" data-value="all">
                            <input type="radio" name="audience_type" value="all" checked>
                            <span>👥 <?php _e('Everyone', 'rental-gates'); ?></span>
                        </label>
                        <label class="rg-radio-option" data-value="tenants">
                            <input type="radio" name="audience_type" value="tenants">
                            <span>🏠 <?php _e('Tenants', 'rental-gates'); ?></span>
                        </label>
                        <label class="rg-radio-option" data-value="staff">
                            <input type="radio" name="audience_type" value="staff">
                            <span>👔 <?php _e('Staff', 'rental-gates'); ?></span>
                        </label>
                        <label class="rg-radio-option" data-value="buildings">
                            <input type="radio" name="audience_type" value="buildings">
                            <span>🏢 <?php _e('By Building', 'rental-gates'); ?></span>
                        </label>
                    </div>
                </div>
                
                <div class="rg-form-group" id="buildingsSelect" style="display: none;">
                    <label><?php _e('Select Buildings', 'rental-gates'); ?></label>
                    <div class="rg-checkbox-grid">
                        <?php foreach ($buildings as $b): ?>
                        <label class="rg-checkbox-item">
                            <input type="checkbox" name="audience_ids[]" value="<?php echo $b['id']; ?>">
                            <?php echo esc_html($b['name']); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="rg-form-group">
                    <label><?php _e('Delivery Channels', 'rental-gates'); ?></label>
                    <select name="channels">
                        <option value="both"><?php _e('In-App + Email', 'rental-gates'); ?></option>
                        <option value="in_app"><?php _e('In-App Only', 'rental-gates'); ?></option>
                        <option value="email"><?php _e('Email Only', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div class="rg-form-group">
                    <label><?php _e('Delivery Time', 'rental-gates'); ?></label>
                    <div class="rg-radio-group">
                        <label class="rg-radio-option selected" data-value="immediate">
                            <input type="radio" name="delivery" value="immediate" checked>
                            <span><?php _e('Send Now', 'rental-gates'); ?></span>
                        </label>
                        <label class="rg-radio-option" data-value="scheduled">
                            <input type="radio" name="delivery" value="scheduled">
                            <span><?php _e('Schedule', 'rental-gates'); ?></span>
                        </label>
                    </div>
                </div>
                
                <div class="rg-form-group" id="scheduleTime" style="display: none;">
                    <label><?php _e('Scheduled Time', 'rental-gates'); ?></label>
                    <input type="datetime-local" name="scheduled_at">
                </div>
            </div>
            <div class="rg-modal-footer">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeAnnouncementModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Create Announcement', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function openAnnouncementModal() { document.getElementById('announcementModal').classList.add('open'); }
function closeAnnouncementModal() { document.getElementById('announcementModal').classList.remove('open'); }

document.querySelectorAll('.rg-radio-option').forEach(function(opt) {
    opt.addEventListener('click', function() {
        var group = this.parentElement;
        group.querySelectorAll('.rg-radio-option').forEach(function(o) { o.classList.remove('selected'); });
        this.classList.add('selected');
        this.querySelector('input').checked = true;
        
        // Show/hide buildings select
        var value = this.dataset.value;
        if (this.closest('.rg-form-group').querySelector('[name="audience_type"]')) {
            document.getElementById('buildingsSelect').style.display = value === 'buildings' ? 'block' : 'none';
        }
        if (this.closest('.rg-form-group').querySelector('[name="delivery"]')) {
            document.getElementById('scheduleTime').style.display = value === 'scheduled' ? 'block' : 'none';
        }
    });
});

document.getElementById('announcementForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    var formData = new FormData(this);
    formData.append('action', 'rental_gates_create_announcement');
    formData.append('announcement_nonce', '<?php echo wp_create_nonce('rental_gates_announcement'); ?>');
    
    var submitBtn = this.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = '<?php _e('Creating...', 'rental-gates'); ?>';
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            window.location.reload();
        } else {
            alert(data.data || 'Failed to create announcement');
            submitBtn.disabled = false;
            submitBtn.textContent = '<?php _e('Create Announcement', 'rental-gates'); ?>';
        }
    });
});

function sendAnnouncement(id) {
    if (!confirm('<?php _e('Send this announcement now?', 'rental-gates'); ?>')) return;
    
    var formData = new FormData();
    formData.append('action', 'rental_gates_send_announcement');
    formData.append('announcement_id', id);
    formData.append('announcement_nonce', '<?php echo wp_create_nonce('rental_gates_announcement'); ?>');
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('<?php _e('Announcement sent to', 'rental-gates'); ?> ' + data.data.recipients + ' <?php _e('recipients', 'rental-gates'); ?>');
            window.location.reload();
        } else {
            alert(data.data || 'Failed to send announcement');
        }
    });
}

document.getElementById('announcementModal').addEventListener('click', function(e) {
    if (e.target === this) closeAnnouncementModal();
});
</script>
