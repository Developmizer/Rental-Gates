<?php
/**
 * Dashboard Section: Building Detail View
 * 
 * Shows building details and lists all units within this building.
 * Per Rule 2: Units exist only inside buildings.
 */
if (!defined('ABSPATH')) exit;

// Get organization ID
$org_id = null;
if (class_exists('Rental_Gates_Roles')) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Get building ID from URL
$building_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$building = null;
$units = array();

if ($building_id && class_exists('Rental_Gates_Building')) {
    $building = Rental_Gates_Building::get($building_id);
    
    // Verify ownership
    if (!$building || $building['organization_id'] != $org_id) {
        wp_redirect(home_url('/rental-gates/dashboard/buildings'));
        exit;
    }
    
    // Get units
    if (class_exists('Rental_Gates_Unit')) {
        $units = Rental_Gates_Unit::get_by_building($building_id);
    }
}

if (!$building) {
    wp_redirect(home_url('/rental-gates/dashboard/buildings'));
    exit;
}

// Calculate unit stats
$unit_stats = array(
    'total' => count($units),
    'available' => 0,
    'occupied' => 0,
    'coming_soon' => 0,
    'renewal_pending' => 0,
    'unlisted' => 0
);

foreach ($units as $unit) {
    if (isset($unit_stats[$unit['availability']])) {
        $unit_stats[$unit['availability']]++;
    }
}

// Filter
$filter = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : 'all';

// Get gallery - already decoded by format_building()
$gallery = !empty($building['gallery']) ? $building['gallery'] : array();
if (!is_array($gallery)) $gallery = array();
?>

<style>
    .rg-building-header {
        display: flex;
        gap: 24px;
        margin-bottom: 24px;
    }
    
    .rg-building-hero {
        width: 280px;
        flex-shrink: 0;
    }
    
    .rg-building-hero-image {
        width: 100%;
        height: 200px;
        border-radius: 12px;
        overflow: hidden;
        background: var(--gray-200);
    }
    
    .rg-building-hero-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .rg-building-hero-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-400);
    }
    
    .rg-building-info {
        flex: 1;
    }
    
    .rg-building-title-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 12px;
    }
    
    .rg-building-title {
        font-size: 28px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0;
    }
    
    .rg-building-status-badge {
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .rg-building-status-badge.active {
        background: #d1fae5;
        color: #065f46;
    }
    
    .rg-building-status-badge.inactive {
        background: var(--gray-200);
        color: var(--gray-600);
    }
    
    .rg-building-address {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        font-size: 15px;
        color: var(--gray-600);
        margin-bottom: 20px;
    }
    
    .rg-building-address svg {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
        margin-top: 2px;
    }
    
    .rg-building-stats {
        display: flex;
        gap: 24px;
        margin-bottom: 20px;
    }
    
    .rg-building-stat {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .rg-building-stat-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    
    .rg-building-stat-dot.available { background: var(--success); }
    .rg-building-stat-dot.occupied { background: var(--primary); }
    .rg-building-stat-dot.coming-soon { background: var(--warning); }
    .rg-building-stat-dot.unlisted { background: var(--gray-400); }
    
    .rg-building-stat-value {
        font-size: 18px;
        font-weight: 700;
        color: var(--gray-900);
    }
    
    .rg-building-stat-label {
        font-size: 14px;
        color: var(--gray-500);
    }
    
    .rg-building-actions {
        display: flex;
        gap: 12px;
    }
    
    /* Units Section */
    .rg-units-section {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
    }
    
    .rg-units-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 24px;
        border-bottom: 1px solid var(--gray-100);
    }
    
    .rg-units-title {
        font-size: 18px;
        font-weight: 600;
        color: var(--gray-900);
    }
    
    .rg-units-filters {
        display: flex;
        gap: 8px;
    }
    
    .rg-filter-btn {
        padding: 6px 14px;
        border: 1px solid var(--gray-200);
        border-radius: 6px;
        background: #fff;
        font-size: 13px;
        color: var(--gray-600);
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
    }
    
    .rg-filter-btn:hover {
        border-color: var(--primary);
        color: var(--primary);
    }
    
    .rg-filter-btn.active {
        background: var(--primary);
        border-color: var(--primary);
        color: #fff;
    }
    
    .rg-units-list {
        padding: 0;
    }
    
    .rg-unit-row {
        display: grid;
        grid-template-columns: 1fr 120px 120px 140px 100px;
        align-items: center;
        padding: 16px 24px;
        border-bottom: 1px solid var(--gray-100);
        transition: background 0.2s;
    }
    
    .rg-unit-row:hover {
        background: var(--gray-50);
    }
    
    .rg-unit-row:last-child {
        border-bottom: none;
    }
    
    .rg-unit-name {
        font-weight: 600;
        color: var(--gray-900);
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .rg-unit-thumb {
        width: 48px;
        height: 48px;
        border-radius: 8px;
        background: var(--gray-200);
        overflow: hidden;
        flex-shrink: 0;
    }
    
    .rg-unit-thumb img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .rg-unit-details {
        color: var(--gray-500);
        font-size: 13px;
    }
    
    .rg-unit-rent {
        font-weight: 600;
        color: var(--gray-900);
    }
    
    .rg-unit-features {
        display: flex;
        gap: 12px;
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-unit-feature {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .rg-availability-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .rg-availability-badge.available {
        background: #d1fae5;
        color: #065f46;
    }
    
    .rg-availability-badge.occupied {
        background: #dbeafe;
        color: #1e40af;
    }
    
    .rg-availability-badge.coming_soon {
        background: #fef3c7;
        color: #92400e;
    }
    
    .rg-availability-badge.renewal_pending {
        background: #ede9fe;
        color: #5b21b6;
    }
    
    .rg-availability-badge.unlisted {
        background: var(--gray-200);
        color: var(--gray-600);
    }
    
    .rg-unit-actions {
        display: flex;
        gap: 8px;
        justify-content: flex-end;
    }
    
    .rg-unit-action {
        width: 32px;
        height: 32px;
        border: 1px solid var(--gray-200);
        border-radius: 6px;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-500);
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
    }
    
    .rg-unit-action:hover {
        border-color: var(--primary);
        color: var(--primary);
    }
    
    /* Empty units state */
    .rg-units-empty {
        padding: 60px 24px;
        text-align: center;
    }
    
    .rg-units-empty-icon {
        width: 64px;
        height: 64px;
        margin: 0 auto 16px;
        background: var(--gray-100);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-400);
    }
    
    .rg-units-empty-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .rg-units-empty-text {
        font-size: 14px;
        color: var(--gray-500);
        margin-bottom: 20px;
    }
    
    /* Description card */
    .rg-description-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        padding: 24px;
        margin-bottom: 24px;
    }
    
    .rg-description-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 12px;
    }
    
    .rg-description-text {
        font-size: 15px;
        color: var(--gray-700);
        line-height: 1.6;
    }
    
    @media (max-width: 992px) {
        .rg-building-header {
            flex-direction: column;
        }
        
        .rg-building-hero {
            width: 100%;
        }
        
        .rg-unit-row {
            grid-template-columns: 1fr;
            gap: 12px;
        }
        
        .rg-unit-actions {
            justify-content: flex-start;
        }
    }
    
    .rg-btn-danger {
        background: #fee2e2;
        border: 1px solid #fecaca;
        color: #dc2626;
    }
    
    .rg-btn-danger:hover {
        background: #fecaca;
        border-color: #fca5a5;
    }
    
    .rg-unit-action-delete {
        background: none;
        border: none;
        padding: 6px;
        cursor: pointer;
    }
    
    .rg-unit-action-delete:hover {
        color: #dc2626;
    }
    
    /* QR Modal Styles */
    #qr-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .qr-modal-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
    }
    
    .qr-modal-content {
        position: relative;
        background: #fff;
        border-radius: 16px;
        padding: 32px;
        max-width: 420px;
        width: 90%;
        box-shadow: 0 20px 50px rgba(0,0,0,0.2);
    }
    
    .qr-modal-close {
        position: absolute;
        top: 16px;
        right: 16px;
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--gray-400);
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
    }
    
    .qr-modal-close:hover {
        background: var(--gray-100);
        color: var(--gray-600);
    }
    
    .qr-modal-body h3 {
        text-align: center;
        margin-bottom: 20px;
        font-size: 18px;
        color: var(--gray-900);
    }
    
    .qr-image {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .qr-image img {
        max-width: 200px;
        border-radius: 8px;
        border: 1px solid var(--gray-200);
    }
    
    .qr-url {
        margin-bottom: 20px;
    }
    
    .qr-url label {
        display: block;
        font-size: 12px;
        color: var(--gray-500);
        margin-bottom: 4px;
    }
    
    .qr-url input {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 13px;
        color: var(--gray-700);
        background: var(--gray-50);
    }
    
    .qr-actions {
        display: flex;
        gap: 12px;
        margin-bottom: 16px;
    }
    
    .qr-actions .rg-btn {
        flex: 1;
        justify-content: center;
    }
    
    .qr-hint {
        font-size: 13px;
        color: var(--gray-500);
        text-align: center;
        line-height: 1.5;
    }
    
    .qr-loading, .qr-error {
        text-align: center;
        padding: 40px 20px;
    }
    
    .qr-loading p, .qr-error p {
        margin-top: 16px;
        color: var(--gray-600);
    }
</style>

<?php
// Helper to extract URL from gallery item (handles both string and object format)
function rg_get_gallery_url($item) {
    if (empty($item)) return null;
    if (is_string($item)) return $item;
    if (is_array($item)) return $item['url'] ?? $item['thumbnail'] ?? null;
    return null;
}
?>

<!-- Building Header -->
<div class="rg-building-header">
    <div class="rg-building-hero">
        <div class="rg-building-hero-image">
            <?php 
            $hero_image = !empty($gallery[0]) ? rg_get_gallery_url($gallery[0]) : null;
            if ($hero_image): ?>
                <img src="<?php echo esc_url($hero_image); ?>" alt="<?php echo esc_attr($building['name']); ?>">
            <?php else: ?>
                <div class="rg-building-hero-placeholder">
                    <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="rg-building-info">
        <div class="rg-building-title-row">
            <h1 class="rg-building-title"><?php echo esc_html($building['name']); ?></h1>
            <span class="rg-building-status-badge <?php echo esc_attr($building['status']); ?>">
                <?php echo esc_html($building['status']); ?>
            </span>
        </div>
        
        <div class="rg-building-address">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <span><?php echo esc_html($building['derived_address']); ?></span>
        </div>
        
        <div class="rg-building-stats">
            <div class="rg-building-stat">
                <span class="rg-building-stat-value"><?php echo $unit_stats['total']; ?></span>
                <span class="rg-building-stat-label"><?php _e('Total Units', 'rental-gates'); ?></span>
            </div>
            <?php if ($unit_stats['available'] > 0): ?>
            <div class="rg-building-stat">
                <span class="rg-building-stat-dot available"></span>
                <span class="rg-building-stat-value"><?php echo $unit_stats['available']; ?></span>
                <span class="rg-building-stat-label"><?php _e('Available', 'rental-gates'); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($unit_stats['occupied'] > 0): ?>
            <div class="rg-building-stat">
                <span class="rg-building-stat-dot occupied"></span>
                <span class="rg-building-stat-value"><?php echo $unit_stats['occupied']; ?></span>
                <span class="rg-building-stat-label"><?php _e('Occupied', 'rental-gates'); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($unit_stats['coming_soon'] > 0): ?>
            <div class="rg-building-stat">
                <span class="rg-building-stat-dot coming-soon"></span>
                <span class="rg-building-stat-value"><?php echo $unit_stats['coming_soon']; ?></span>
                <span class="rg-building-stat-label"><?php _e('Coming Soon', 'rental-gates'); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="rg-building-actions">
            <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/edit'); ?>" class="rg-btn rg-btn-secondary">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
                <?php _e('Edit Building', 'rental-gates'); ?>
            </a>
            <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/units/add'); ?>" class="rg-btn rg-btn-primary">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                <?php _e('Add Unit', 'rental-gates'); ?>
            </a>
            <button type="button" class="rg-btn rg-btn-secondary" onclick="openBulkAddModal()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                </svg>
                <?php _e('Bulk Add', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-secondary" onclick="generateQR()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/>
                </svg>
                <?php _e('QR Code', 'rental-gates'); ?>
            </button>
            <button type="button" class="rg-btn rg-btn-danger" onclick="deleteBuilding(<?php echo $building['id']; ?>)">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
                <?php _e('Delete', 'rental-gates'); ?>
            </button>
        </div>
    </div>
</div>

<?php if (!empty($building['description'])): ?>
<div class="rg-description-card">
    <h3 class="rg-description-title"><?php _e('Description', 'rental-gates'); ?></h3>
    <p class="rg-description-text"><?php echo nl2br(esc_html($building['description'])); ?></p>
</div>
<?php endif; ?>

<!-- Units Section -->
<div class="rg-units-section">
    <div class="rg-units-header">
        <h2 class="rg-units-title"><?php _e('Units', 'rental-gates'); ?></h2>
        
        <div class="rg-units-filters">
            <a href="?id=<?php echo $building_id; ?>&filter=all" class="rg-filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">
                <?php _e('All', 'rental-gates'); ?>
            </a>
            <a href="?id=<?php echo $building_id; ?>&filter=available" class="rg-filter-btn <?php echo $filter === 'available' ? 'active' : ''; ?>">
                <?php _e('Available', 'rental-gates'); ?>
            </a>
            <a href="?id=<?php echo $building_id; ?>&filter=occupied" class="rg-filter-btn <?php echo $filter === 'occupied' ? 'active' : ''; ?>">
                <?php _e('Occupied', 'rental-gates'); ?>
            </a>
            <a href="?id=<?php echo $building_id; ?>&filter=coming_soon" class="rg-filter-btn <?php echo $filter === 'coming_soon' ? 'active' : ''; ?>">
                <?php _e('Coming Soon', 'rental-gates'); ?>
            </a>
        </div>
    </div>
    
    <?php if (empty($units)): ?>
    <div class="rg-units-empty">
        <div class="rg-units-empty-icon">
            <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
            </svg>
        </div>
        <h3 class="rg-units-empty-title"><?php _e('No units yet', 'rental-gates'); ?></h3>
        <p class="rg-units-empty-text"><?php _e('Add your first unit to this building to start accepting applications.', 'rental-gates'); ?></p>
        <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/units/add'); ?>" class="rg-btn rg-btn-primary">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            <?php _e('Add First Unit', 'rental-gates'); ?>
        </a>
    </div>
    
    <?php else: ?>
    <div class="rg-units-list">
        <?php foreach ($units as $unit): 
            // Apply filter
            if ($filter !== 'all' && $unit['availability'] !== $filter) continue;
            
            // Get first image - gallery already decoded by format_unit()
            $unit_gallery = !empty($unit['gallery']) && is_array($unit['gallery']) ? $unit['gallery'] : array();
            $unit_image = !empty($unit_gallery[0]) ? rg_get_gallery_url($unit_gallery[0]) : null;
        ?>
        <div class="rg-unit-row" data-unit-id="<?php echo $unit['id']; ?>">
            <div class="rg-unit-name">
                <div class="rg-unit-thumb">
                    <?php if ($unit_image): ?>
                        <img src="<?php echo esc_url($unit_image); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div>
                    <div><?php echo esc_html($unit['name']); ?></div>
                    <div class="rg-unit-details">
                        <?php if (!empty($unit['unit_type'])): ?>
                            <?php echo esc_html(ucfirst($unit['unit_type'])); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="rg-unit-rent">
                $<?php echo number_format($unit['rent_amount']); ?>/mo
            </div>
            
            <div class="rg-unit-features">
                <?php if ($unit['bedrooms'] > 0): ?>
                <span class="rg-unit-feature">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    <?php echo $unit['bedrooms']; ?> <?php _e('bed', 'rental-gates'); ?>
                </span>
                <?php endif; ?>
                <?php if ($unit['bathrooms'] > 0): ?>
                <span class="rg-unit-feature">
                    <svg width="14" height="14" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 3a1 1 0 00-1 1v12a1 1 0 001 1h2a1 1 0 001-1V4a1 1 0 00-1-1H4z"/></svg>
                    <?php echo $unit['bathrooms']; ?> <?php _e('bath', 'rental-gates'); ?>
                </span>
                <?php endif; ?>
                <?php if ($unit['square_footage'] > 0): ?>
                <span class="rg-unit-feature">
                    <?php echo number_format($unit['square_footage']); ?> <?php _e('sqft', 'rental-gates'); ?>
                </span>
                <?php endif; ?>
            </div>
            
            <div>
                <span class="rg-availability-badge <?php echo esc_attr($unit['availability']); ?>">
                    <?php 
                    $availability_labels = array(
                        'available' => __('Available', 'rental-gates'),
                        'occupied' => __('Occupied', 'rental-gates'),
                        'coming_soon' => __('Coming Soon', 'rental-gates'),
                        'renewal_pending' => __('Renewal Pending', 'rental-gates'),
                        'unlisted' => __('Unlisted', 'rental-gates'),
                    );
                    echo esc_html($availability_labels[$unit['availability']] ?? $unit['availability']);
                    ?>
                </span>
                <?php if ($unit['availability'] === 'coming_soon' && !empty($unit['available_from'])): ?>
                    <div style="font-size: 11px; color: var(--gray-500); margin-top: 4px;">
                        <?php echo date('M j, Y', strtotime($unit['available_from'])); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="rg-unit-actions">
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/units/' . $unit['id']); ?>" class="rg-unit-action" title="<?php _e('View', 'rental-gates'); ?>">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id'] . '/units/' . $unit['id'] . '/edit'); ?>" class="rg-unit-action" title="<?php _e('Edit', 'rental-gates'); ?>">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                </a>
                <button type="button" class="rg-unit-action rg-unit-action-delete" onclick="deleteUnit(<?php echo $unit['id']; ?>, '<?php echo esc_js($unit['name']); ?>')" title="<?php _e('Delete', 'rental-gates'); ?>">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
function generateQR() {
    // Show loading
    const modal = document.createElement('div');
    modal.id = 'qr-modal';
    modal.innerHTML = `
        <div class="qr-modal-overlay" onclick="closeQRModal()"></div>
        <div class="qr-modal-content">
            <button class="qr-modal-close" onclick="closeQRModal()">&times;</button>
            <div class="qr-modal-body">
                <div class="qr-loading">
                    <svg width="40" height="40" viewBox="0 0 24 24" style="animation: spin 1s linear infinite;">
                        <style>@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }</style>
                        <circle cx="12" cy="12" r="10" stroke="#6366f1" stroke-width="3" fill="none" stroke-dasharray="31.4 31.4" stroke-linecap="round"/>
                    </svg>
                    <p><?php _e('Generating QR Code...', 'rental-gates'); ?></p>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    // Generate QR
    const formData = new FormData();
    formData.append('action', 'rental_gates_generate_qr');
    formData.append('nonce', rentalGatesData.nonce);
    formData.append('type', 'building');
    formData.append('id', <?php echo $building['id']; ?>);
    
    fetch(rentalGatesData.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const qrData = data.data;
            // Store QR image URL globally for download
            window.currentQRImage = qrData.qr_image;
            
            document.querySelector('.qr-modal-body').innerHTML = `
                <h3><?php _e('QR Code for', 'rental-gates'); ?> <?php echo esc_js($building['name']); ?></h3>
                <div class="qr-image">
                    <img src="${qrData.qr_image}" alt="QR Code" id="qr-code-img" crossorigin="anonymous">
                </div>
                <div class="qr-url">
                    <label><?php _e('Destination URL:', 'rental-gates'); ?></label>
                    <input type="text" value="${qrData.url}" readonly onclick="this.select()">
                </div>
                <div class="qr-actions">
                    <button type="button" class="rg-btn rg-btn-primary" onclick="downloadQRCode('<?php echo esc_attr(sanitize_title($building['name'])); ?>-qr.png')">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                        </svg>
                        <?php _e('Download QR', 'rental-gates'); ?>
                    </button>
                    <button type="button" class="rg-btn rg-btn-secondary" onclick="copyToClipboard('${qrData.url}')">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                        </svg>
                        <?php _e('Copy URL', 'rental-gates'); ?>
                    </button>
                </div>
                <p class="qr-hint"><?php _e('Print this QR code and place it at your property entrance. Visitors can scan to view listing details.', 'rental-gates'); ?></p>
            `;
        } else {
            document.querySelector('.qr-modal-body').innerHTML = `
                <div class="qr-error">
                    <p>${data.data || '<?php _e('Error generating QR code', 'rental-gates'); ?>'}</p>
                    <button class="rg-btn rg-btn-secondary" onclick="closeQRModal()"><?php _e('Close', 'rental-gates'); ?></button>
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.querySelector('.qr-modal-body').innerHTML = `
            <div class="qr-error">
                <p><?php _e('Error generating QR code', 'rental-gates'); ?></p>
                <button class="rg-btn rg-btn-secondary" onclick="closeQRModal()"><?php _e('Close', 'rental-gates'); ?></button>
            </div>
        `;
    });
}

function closeQRModal() {
    const modal = document.getElementById('qr-modal');
    if (modal) modal.remove();
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('<?php _e('URL copied to clipboard!', 'rental-gates'); ?>');
    });
}

function downloadQRCode(filename) {
    const img = document.getElementById('qr-code-img');
    
    // Create a canvas and draw the image
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || 300;
    canvas.height = img.naturalHeight || 300;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    
    // Convert to blob and download
    canvas.toBlob(function(blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 'image/png');
}

function deleteBuilding(buildingId) {
    <?php if ($unit_stats['total'] > 0): ?>
    const message = '<?php _e('This building has units. All units will also be deleted. This action cannot be undone.', 'rental-gates'); ?>';
    <?php else: ?>
    const message = '<?php _e('Are you sure you want to delete this building? This action cannot be undone.', 'rental-gates'); ?>';
    <?php endif; ?>
    
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Building', 'rental-gates'); ?>',
        message: message,
        itemName: '<?php echo esc_js($building['name']); ?>',
        ajaxAction: 'rental_gates_delete_building',
        ajaxData: { building_id: buildingId },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/buildings'); ?>'
    });
}

function deleteUnit(unitId, unitName) {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Unit', 'rental-gates'); ?>',
        message: '<?php _e('Are you sure you want to delete this unit? This action cannot be undone.', 'rental-gates'); ?>',
        itemName: unitName || '',
        ajaxAction: 'rental_gates_delete_unit',
        ajaxData: { unit_id: unitId },
        onConfirm: function() {
            // Remove the unit card from DOM
            const unitCard = document.querySelector(`[data-unit-id="${unitId}"]`);
            if (unitCard) {
                unitCard.style.transition = 'opacity 0.3s, transform 0.3s';
                unitCard.style.opacity = '0';
                unitCard.style.transform = 'scale(0.95)';
                setTimeout(() => unitCard.remove(), 300);
            } else {
                window.location.reload();
            }
        }
    });
}

// Bulk Add Units Modal
function openBulkAddModal() {
    const modal = document.createElement('div');
    modal.id = 'bulk-add-modal';
    modal.innerHTML = `
        <div class="bulk-modal-overlay" onclick="closeBulkAddModal()"></div>
        <div class="bulk-modal-content">
            <button class="bulk-modal-close" onclick="closeBulkAddModal()">×</button>
            <div class="bulk-modal-header">
                <h3><?php _e('Bulk Add Units', 'rental-gates'); ?></h3>
                <p><?php _e('Quickly create multiple units with the same base settings.', 'rental-gates'); ?></p>
            </div>
            <div class="bulk-modal-body">
                <div class="bulk-form-group">
                    <label><?php _e('Unit Number Pattern', 'rental-gates'); ?></label>
                    <div class="bulk-pattern-row">
                        <input type="text" id="bulk-prefix" placeholder="<?php esc_attr_e('Prefix (e.g., Apt)', 'rental-gates'); ?>" class="bulk-input">
                        <span class="bulk-pattern-sep">+</span>
                        <input type="number" id="bulk-start" value="1" min="1" class="bulk-input bulk-input-sm">
                        <span class="bulk-pattern-sep"><?php _e('to', 'rental-gates'); ?></span>
                        <input type="number" id="bulk-end" value="10" min="1" class="bulk-input bulk-input-sm">
                    </div>
                    <div class="bulk-preview" id="bulk-preview"><?php _e('Preview: Apt 1, Apt 2, ... Apt 10', 'rental-gates'); ?></div>
                </div>
                
                <div class="bulk-form-row">
                    <div class="bulk-form-group">
                        <label><?php _e('Bedrooms', 'rental-gates'); ?></label>
                        <select id="bulk-bedrooms" class="bulk-select">
                            <option value="0"><?php _e('Studio', 'rental-gates'); ?></option>
                            <option value="1" selected>1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4+</option>
                        </select>
                    </div>
                    <div class="bulk-form-group">
                        <label><?php _e('Bathrooms', 'rental-gates'); ?></label>
                        <select id="bulk-bathrooms" class="bulk-select">
                            <option value="1" selected>1</option>
                            <option value="1.5">1.5</option>
                            <option value="2">2</option>
                            <option value="2.5">2.5</option>
                            <option value="3">3+</option>
                        </select>
                    </div>
                </div>
                
                <div class="bulk-form-row">
                    <div class="bulk-form-group">
                        <label><?php _e('Monthly Rent ($)', 'rental-gates'); ?></label>
                        <input type="number" id="bulk-rent" value="1500" min="0" step="50" class="bulk-input">
                    </div>
                    <div class="bulk-form-group">
                        <label><?php _e('Square Feet', 'rental-gates'); ?></label>
                        <input type="number" id="bulk-sqft" value="750" min="0" class="bulk-input">
                    </div>
                </div>
                
                <div class="bulk-form-group">
                    <label><?php _e('Initial Availability', 'rental-gates'); ?></label>
                    <select id="bulk-availability" class="bulk-select">
                        <option value="available"><?php _e('Available', 'rental-gates'); ?></option>
                        <option value="coming_soon"><?php _e('Coming Soon', 'rental-gates'); ?></option>
                        <option value="unlisted"><?php _e('Unlisted', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            <div class="bulk-modal-footer">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeBulkAddModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="button" class="rg-btn rg-btn-primary" onclick="submitBulkAdd()" id="bulk-submit-btn">
                    <span class="bulk-btn-text"><?php _e('Create Units', 'rental-gates'); ?></span>
                    <span class="bulk-btn-loading" style="display:none;">
                        <svg class="rg-spinner" width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity="0.3"/><path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/></path></svg>
                        <?php _e('Creating...', 'rental-gates'); ?>
                    </span>
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Update preview on input change
    ['bulk-prefix', 'bulk-start', 'bulk-end'].forEach(id => {
        document.getElementById(id).addEventListener('input', updateBulkPreview);
    });
    updateBulkPreview();
}

function closeBulkAddModal() {
    const modal = document.getElementById('bulk-add-modal');
    if (modal) modal.remove();
    document.body.style.overflow = '';
}

function updateBulkPreview() {
    const prefix = document.getElementById('bulk-prefix').value || '';
    const start = parseInt(document.getElementById('bulk-start').value) || 1;
    const end = parseInt(document.getElementById('bulk-end').value) || 1;
    const count = Math.max(0, end - start + 1);
    
    let preview = '';
    if (count > 0 && count <= 100) {
        const sep = prefix ? ' ' : '';
        const examples = [];
        for (let i = start; i <= Math.min(start + 2, end); i++) {
            examples.push(prefix + sep + i);
        }
        if (end > start + 2) {
            examples.push('...');
            examples.push(prefix + sep + end);
        }
        preview = `<?php _e('Preview:', 'rental-gates'); ?> ${examples.join(', ')} (${count} <?php _e('units', 'rental-gates'); ?>)`;
    } else if (count > 100) {
        preview = '<?php _e('Maximum 100 units at a time', 'rental-gates'); ?>';
    } else {
        preview = '<?php _e('Invalid range', 'rental-gates'); ?>';
    }
    
    document.getElementById('bulk-preview').textContent = preview;
}

function submitBulkAdd() {
    const prefix = document.getElementById('bulk-prefix').value || '';
    const start = parseInt(document.getElementById('bulk-start').value) || 1;
    const end = parseInt(document.getElementById('bulk-end').value) || 1;
    const count = end - start + 1;
    
    if (count <= 0 || count > 100) {
        alert('<?php _e('Please enter a valid range (1-100 units)', 'rental-gates'); ?>');
        return;
    }
    
    const btn = document.getElementById('bulk-submit-btn');
    btn.querySelector('.bulk-btn-text').style.display = 'none';
    btn.querySelector('.bulk-btn-loading').style.display = 'inline-flex';
    btn.disabled = true;
    
    const data = {
        action: 'rental_gates_bulk_add_units',
        nonce: '<?php echo wp_create_nonce('rental_gates_bulk_units'); ?>',
        building_id: <?php echo $building['id']; ?>,
        prefix: prefix,
        start: start,
        end: end,
        bedrooms: document.getElementById('bulk-bedrooms').value,
        bathrooms: document.getElementById('bulk-bathrooms').value,
        rent: document.getElementById('bulk-rent').value,
        sqft: document.getElementById('bulk-sqft').value,
        availability: document.getElementById('bulk-availability').value
    };
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            closeBulkAddModal();
            window.location.reload();
        } else {
            alert(result.data || '<?php _e('Error creating units', 'rental-gates'); ?>');
            btn.querySelector('.bulk-btn-text').style.display = 'inline';
            btn.querySelector('.bulk-btn-loading').style.display = 'none';
            btn.disabled = false;
        }
    })
    .catch(error => {
        alert('<?php _e('Error creating units', 'rental-gates'); ?>');
        btn.querySelector('.bulk-btn-text').style.display = 'inline';
        btn.querySelector('.bulk-btn-loading').style.display = 'none';
        btn.disabled = false;
    });
}
</script>

<style>
/* Bulk Add Modal Styles */
#bulk-add-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.bulk-modal-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
}

.bulk-modal-content {
    position: relative;
    background: #fff;
    border-radius: 16px;
    max-width: 520px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 50px rgba(0,0,0,0.2);
}

.bulk-modal-close {
    position: absolute;
    top: 16px;
    right: 16px;
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: var(--gray-400);
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
}

.bulk-modal-close:hover {
    background: var(--gray-100);
    color: var(--gray-600);
}

.bulk-modal-header {
    padding: 24px 24px 0;
}

.bulk-modal-header h3 {
    font-size: 20px;
    font-weight: 700;
    margin: 0 0 8px;
    color: var(--gray-900);
}

.bulk-modal-header p {
    color: var(--gray-500);
    margin: 0;
    font-size: 14px;
}

.bulk-modal-body {
    padding: 24px;
}

.bulk-form-group {
    margin-bottom: 20px;
}

.bulk-form-group label {
    display: block;
    font-size: 14px;
    font-weight: 500;
    color: var(--gray-700);
    margin-bottom: 8px;
}

.bulk-form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.bulk-pattern-row {
    display: flex;
    align-items: center;
    gap: 8px;
}

.bulk-pattern-sep {
    color: var(--gray-400);
    font-size: 14px;
}

.bulk-input, .bulk-select {
    padding: 10px 14px;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    width: 100%;
}

.bulk-input:focus, .bulk-select:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.bulk-input-sm {
    width: 80px;
    text-align: center;
}

.bulk-preview {
    margin-top: 8px;
    font-size: 13px;
    color: var(--gray-500);
    padding: 8px 12px;
    background: var(--gray-50);
    border-radius: 6px;
}

.bulk-modal-footer {
    padding: 16px 24px;
    border-top: 1px solid var(--gray-200);
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.bulk-btn-loading {
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.bulk-btn-loading svg {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}
</style>
