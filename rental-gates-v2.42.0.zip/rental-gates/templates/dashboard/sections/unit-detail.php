<?php
/**
 * Dashboard Section: Unit Detail
 * 
 * Shows unit information with options to edit or manage.
 */
if (!defined('ABSPATH')) exit;

// Get organization ID
$org_id = null;
if (class_exists('Rental_Gates_Roles')) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Get building ID and unit ID from URL
$building_id = isset($_GET['building_id']) ? intval($_GET['building_id']) : 0;
$unit_id = isset($_GET['unit_id']) ? intval($_GET['unit_id']) : 0;

$building = null;
$unit = null;

if ($building_id && class_exists('Rental_Gates_Building')) {
    $building = Rental_Gates_Building::get($building_id);
    if (!$building || $building['organization_id'] != $org_id) {
        wp_redirect(home_url('/rental-gates/dashboard/buildings'));
        exit;
    }
}

if ($unit_id && class_exists('Rental_Gates_Unit')) {
    $unit = Rental_Gates_Unit::get($unit_id);
    if (!$unit || $unit['building_id'] != $building_id) {
        wp_redirect(home_url('/rental-gates/dashboard/buildings/' . $building_id));
        exit;
    }
}

if (!$building || !$unit) {
    wp_redirect(home_url('/rental-gates/dashboard/buildings'));
    exit;
}

// Gallery and amenities are already decoded by format_unit()
$gallery = !empty($unit['gallery']) ? $unit['gallery'] : array();
if (!is_array($gallery)) $gallery = array();

$amenities = !empty($unit['amenities']) ? $unit['amenities'] : array();
if (!is_array($amenities)) $amenities = array();

// Availability colors
$availability_colors = array(
    'available' => '#10b981',
    'coming_soon' => '#f59e0b',
    'occupied' => '#6b7280',
    'renewal_pending' => '#8b5cf6',
    'unlisted' => '#ef4444',
);

$availability_labels = array(
    'available' => __('Available', 'rental-gates'),
    'coming_soon' => __('Coming Soon', 'rental-gates'),
    'occupied' => __('Occupied', 'rental-gates'),
    'renewal_pending' => __('Renewal Pending', 'rental-gates'),
    'unlisted' => __('Unlisted', 'rental-gates'),
);
?>

<style>
    .rg-unit-detail {
        max-width: 900px;
    }
    
    .rg-breadcrumb {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        margin-bottom: 16px;
    }
    
    .rg-breadcrumb a {
        color: var(--gray-500);
        text-decoration: none;
    }
    
    .rg-breadcrumb a:hover {
        color: var(--primary);
    }
    
    .rg-breadcrumb-separator {
        color: var(--gray-400);
    }
    
    .rg-breadcrumb-current {
        color: var(--gray-900);
        font-weight: 500;
    }
    
    .rg-detail-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 24px;
    }
    
    .rg-detail-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0 0 8px 0;
    }
    
    .rg-detail-subtitle {
        font-size: 14px;
        color: var(--gray-500);
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .rg-availability-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
        background: var(--badge-bg);
        color: var(--badge-color);
    }
    
    .rg-availability-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: currentColor;
    }
    
    .rg-header-actions {
        display: flex;
        gap: 12px;
    }
    
    .rg-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        margin-bottom: 24px;
        overflow: hidden;
    }
    
    .rg-card-header {
        padding: 16px 20px;
        border-bottom: 1px solid var(--gray-100);
        font-weight: 600;
        color: var(--gray-900);
    }
    
    .rg-card-body {
        padding: 20px;
    }
    
    /* Gallery */
    .rg-gallery-preview {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 12px;
    }
    
    .rg-gallery-preview img {
        width: 100%;
        aspect-ratio: 1;
        object-fit: cover;
        border-radius: 8px;
    }
    
    .rg-gallery-empty {
        grid-column: 1 / -1;
        padding: 40px;
        text-align: center;
        color: var(--gray-400);
    }
    
    /* Info Grid */
    .rg-info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 20px;
    }
    
    .rg-info-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    
    .rg-info-label {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .rg-info-value {
        font-size: 15px;
        font-weight: 500;
        color: var(--gray-900);
    }
    
    /* Room Counts */
    .rg-room-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 24px;
    }
    
    .rg-room-item {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .rg-room-icon {
        width: 36px;
        height: 36px;
        background: var(--gray-100);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-600);
    }
    
    .rg-room-count {
        font-size: 18px;
        font-weight: 600;
        color: var(--gray-900);
    }
    
    .rg-room-label {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    /* Amenities */
    .rg-amenities-list {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }
    
    .rg-amenity-tag {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background: var(--gray-100);
        border-radius: 6px;
        font-size: 14px;
        color: var(--gray-700);
    }
    
    .rg-amenity-tag svg {
        width: 16px;
        height: 16px;
        color: var(--primary);
    }
    
    /* Description */
    .rg-description {
        color: var(--gray-700);
        line-height: 1.6;
    }
    
    .rg-description-empty {
        color: var(--gray-400);
        font-style: italic;
    }
    
    @media (max-width: 768px) {
        .rg-detail-header {
            flex-direction: column;
            gap: 16px;
        }
        
        .rg-header-actions {
            width: 100%;
        }
        
        .rg-header-actions .rg-btn {
            flex: 1;
        }
    }
    
    .rg-btn-danger {
        background: #fee2e2;
        border: 1px solid #fecaca;
        color: #dc2626;
    }
    
    .rg-btn-danger:hover {
        background: #fecaca;
        border-color: #fca5a5;
    }
</style>

<div class="rg-unit-detail">
    <!-- Breadcrumb -->
    <nav class="rg-breadcrumb">
        <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>"><?php _e('Buildings', 'rental-gates'); ?></a>
        <span class="rg-breadcrumb-separator">/</span>
        <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building['id']); ?>"><?php echo esc_html($building['name']); ?></a>
        <span class="rg-breadcrumb-separator">/</span>
        <span class="rg-breadcrumb-current"><?php echo esc_html($unit['name']); ?></span>
    </nav>
    
    <!-- Header -->
    <div class="rg-detail-header">
        <div>
            <h1 class="rg-detail-title"><?php echo esc_html($unit['name']); ?></h1>
            <div class="rg-detail-subtitle">
                <?php if (!empty($unit['unit_type'])): ?>
                    <span><?php echo esc_html(ucfirst($unit['unit_type'])); ?></span>
                    <span>•</span>
                <?php endif; ?>
                <span 
                    class="rg-availability-badge" 
                    style="--badge-bg: <?php echo $availability_colors[$unit['availability']] ?? '#6b7280'; ?>20; --badge-color: <?php echo $availability_colors[$unit['availability']] ?? '#6b7280'; ?>;"
                >
                    <span class="rg-availability-dot"></span>
                    <?php echo $availability_labels[$unit['availability']] ?? ucfirst($unit['availability']); ?>
                </span>
            </div>
        </div>
        <div class="rg-header-actions">
            <a href="<?php echo home_url('/rental-gates/dashboard/buildings/' . $building_id . '/units/' . $unit_id . '/edit'); ?>" class="rg-btn rg-btn-primary">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
                <?php _e('Edit Unit', 'rental-gates'); ?>
            </a>
            <button type="button" class="rg-btn rg-btn-danger" onclick="deleteUnit()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
                <?php _e('Delete', 'rental-gates'); ?>
            </button>
        </div>
    </div>
    
    <!-- Gallery -->
    <div class="rg-card">
        <div class="rg-card-header"><?php _e('Photos', 'rental-gates'); ?></div>
        <div class="rg-card-body">
            <div class="rg-gallery-preview">
                <?php if (!empty($gallery)): ?>
                    <?php foreach ($gallery as $img): 
                        $image_url = is_array($img) ? ($img['url'] ?? $img['thumbnail'] ?? '') : $img;
                        if (empty($image_url)) continue;
                    ?>
                        <img src="<?php echo esc_url($image_url); ?>" alt="">
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="rg-gallery-empty">
                        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin: 0 auto 12px;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        <p><?php _e('No photos uploaded yet', 'rental-gates'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Pricing & Details -->
    <div class="rg-card">
        <div class="rg-card-header"><?php _e('Pricing & Details', 'rental-gates'); ?></div>
        <div class="rg-card-body">
            <div class="rg-info-grid">
                <div class="rg-info-item">
                    <span class="rg-info-label"><?php _e('Monthly Rent', 'rental-gates'); ?></span>
                    <span class="rg-info-value">$<?php echo number_format($unit['rent_amount'], 2); ?></span>
                </div>
                <div class="rg-info-item">
                    <span class="rg-info-label"><?php _e('Security Deposit', 'rental-gates'); ?></span>
                    <span class="rg-info-value">
                        <?php echo $unit['deposit_amount'] ? '$' . number_format($unit['deposit_amount'], 2) : '—'; ?>
                    </span>
                </div>
                <div class="rg-info-item">
                    <span class="rg-info-label"><?php _e('Square Footage', 'rental-gates'); ?></span>
                    <span class="rg-info-value">
                        <?php echo $unit['square_footage'] ? number_format($unit['square_footage']) . ' sq ft' : '—'; ?>
                    </span>
                </div>
                <?php if ($unit['availability'] === 'coming_soon' && $unit['available_from']): ?>
                <div class="rg-info-item">
                    <span class="rg-info-label"><?php _e('Available From', 'rental-gates'); ?></span>
                    <span class="rg-info-value"><?php echo date('M j, Y', strtotime($unit['available_from'])); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Room Counts -->
    <div class="rg-card">
        <div class="rg-card-header"><?php _e('Room Counts', 'rental-gates'); ?></div>
        <div class="rg-card-body">
            <div class="rg-room-grid">
                <div class="rg-room-item">
                    <div class="rg-room-icon">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                        </svg>
                    </div>
                    <div>
                        <div class="rg-room-count"><?php echo intval($unit['bedrooms']); ?></div>
                        <div class="rg-room-label"><?php _e('Bedrooms', 'rental-gates'); ?></div>
                    </div>
                </div>
                
                <div class="rg-room-item">
                    <div class="rg-room-icon">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                        </svg>
                    </div>
                    <div>
                        <div class="rg-room-count"><?php echo number_format($unit['bathrooms'], $unit['bathrooms'] == floor($unit['bathrooms']) ? 0 : 1); ?></div>
                        <div class="rg-room-label"><?php _e('Bathrooms', 'rental-gates'); ?></div>
                    </div>
                </div>
                
                <div class="rg-room-item">
                    <div class="rg-room-icon">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                        </svg>
                    </div>
                    <div>
                        <div class="rg-room-count"><?php echo intval($unit['living_rooms']); ?></div>
                        <div class="rg-room-label"><?php _e('Living Rooms', 'rental-gates'); ?></div>
                    </div>
                </div>
                
                <div class="rg-room-item">
                    <div class="rg-room-icon">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                        </svg>
                    </div>
                    <div>
                        <div class="rg-room-count"><?php echo intval($unit['kitchens']); ?></div>
                        <div class="rg-room-label"><?php _e('Kitchens', 'rental-gates'); ?></div>
                    </div>
                </div>
                
                <div class="rg-room-item">
                    <div class="rg-room-icon">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                        </svg>
                    </div>
                    <div>
                        <div class="rg-room-count"><?php echo intval($unit['parking_spots']); ?></div>
                        <div class="rg-room-label"><?php _e('Parking Spots', 'rental-gates'); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Amenities -->
    <?php if (!empty($amenities)): ?>
    <div class="rg-card">
        <div class="rg-card-header"><?php _e('Amenities', 'rental-gates'); ?></div>
        <div class="rg-card-body">
            <div class="rg-amenities-list">
                <?php foreach ($amenities as $amenity): ?>
                <span class="rg-amenity-tag">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    <?php echo esc_html($amenity); ?>
                </span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Description -->
    <div class="rg-card">
        <div class="rg-card-header"><?php _e('Description', 'rental-gates'); ?></div>
        <div class="rg-card-body">
            <?php if (!empty($unit['description'])): ?>
                <div class="rg-description"><?php echo wpautop(esc_html($unit['description'])); ?></div>
            <?php else: ?>
                <p class="rg-description-empty"><?php _e('No description provided', 'rental-gates'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function deleteUnit() {
    RentalGates.confirmDelete({
        title: '<?php _e('Delete Unit', 'rental-gates'); ?>',
        message: '<?php _e('Are you sure you want to delete this unit? This action cannot be undone.', 'rental-gates'); ?>',
        itemName: '<?php echo esc_js($unit['name'] ?? ''); ?>',
        ajaxAction: 'rental_gates_delete_unit',
        ajaxData: { unit_id: <?php echo $unit_id; ?> },
        redirectUrl: '<?php echo home_url('/rental-gates/dashboard/buildings/' . $building_id); ?>'
    });
}
</script>
