<?php
/**
 * Dashboard Section: Settings
 * 
 * Organization settings and configuration.
 */
if (!defined('ABSPATH')) exit;

// Get organization ID
$org_id = null;
if (class_exists('Rental_Gates_Roles')) {
    $org_id = Rental_Gates_Roles::get_organization_id();
}

// Get organization data
$organization = null;
if ($org_id && class_exists('Rental_Gates_Organization')) {
    $organization = Rental_Gates_Organization::get($org_id);
}

if (!$organization) {
    wp_redirect(home_url('/rental-gates/dashboard'));
    exit;
}

// Get current settings
$map_provider = get_option('rental_gates_map_provider', 'google');
$google_api_key = get_option('rental_gates_google_maps_api_key', '');

// Timezone list
$timezones = array(
    'America/New_York' => 'Eastern Time (US & Canada)',
    'America/Chicago' => 'Central Time (US & Canada)',
    'America/Denver' => 'Mountain Time (US & Canada)',
    'America/Los_Angeles' => 'Pacific Time (US & Canada)',
    'America/Anchorage' => 'Alaska',
    'Pacific/Honolulu' => 'Hawaii',
    'Europe/London' => 'London',
    'Europe/Paris' => 'Paris',
    'Europe/Berlin' => 'Berlin',
    'Asia/Dubai' => 'Dubai',
    'Asia/Riyadh' => 'Riyadh',
    'Asia/Tokyo' => 'Tokyo',
    'Asia/Shanghai' => 'Shanghai',
    'Australia/Sydney' => 'Sydney',
);

// Currency list
$currencies = array(
    'USD' => 'US Dollar ($)',
    'EUR' => 'Euro (€)',
    'GBP' => 'British Pound (£)',
    'CAD' => 'Canadian Dollar (C$)',
    'AUD' => 'Australian Dollar (A$)',
    'SAR' => 'Saudi Riyal (﷼)',
    'AED' => 'UAE Dirham (د.إ)',
);
?>

<style>
    .rg-settings-container {
        max-width: 900px;
    }
    
    .rg-settings-header {
        margin-bottom: 24px;
    }
    
    .rg-settings-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--gray-900);
        margin: 0 0 8px 0;
    }
    
    .rg-settings-subtitle {
        font-size: 14px;
        color: var(--gray-500);
    }
    
    .rg-settings-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        margin-bottom: 24px;
    }
    
    .rg-settings-section {
        padding: 24px;
    }
    
    .rg-settings-section + .rg-settings-section {
        border-top: 1px solid var(--gray-100);
    }
    
    .rg-section-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .rg-section-description {
        font-size: 14px;
        color: var(--gray-500);
        margin-bottom: 20px;
    }
    
    .rg-form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .rg-form-row.full {
        grid-template-columns: 1fr;
    }
    
    .rg-form-row.three-col {
        grid-template-columns: 1fr 1fr 1fr;
    }
    
    .rg-form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    
    .rg-form-label {
        font-size: 14px;
        font-weight: 500;
        color: var(--gray-700);
    }
    
    .rg-form-label .required {
        color: #ef4444;
    }
    
    .rg-form-input,
    .rg-form-select,
    .rg-form-textarea {
        padding: 10px 12px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 14px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    
    .rg-form-input:focus,
    .rg-form-select:focus,
    .rg-form-textarea:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }
    
    .rg-form-textarea {
        min-height: 80px;
        resize: vertical;
    }
    
    .rg-form-hint {
        font-size: 12px;
        color: var(--gray-500);
    }
    
    .rg-form-checkbox {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .rg-form-checkbox input {
        width: 18px;
        height: 18px;
        accent-color: var(--primary);
    }
    
    .rg-form-checkbox label {
        font-size: 14px;
        color: var(--gray-700);
        cursor: pointer;
    }
    
    /* Radio Group */
    .rg-radio-group {
        display: flex;
        gap: 16px;
    }
    
    .rg-radio-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 16px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .rg-radio-item:hover {
        border-color: var(--gray-400);
    }
    
    .rg-radio-item.selected {
        border-color: var(--primary);
        background: #eff6ff;
    }
    
    .rg-radio-item input {
        display: none;
    }
    
    .rg-radio-dot {
        width: 18px;
        height: 18px;
        border: 2px solid var(--gray-300);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .rg-radio-item.selected .rg-radio-dot {
        border-color: var(--primary);
    }
    
    .rg-radio-dot::after {
        content: '';
        width: 10px;
        height: 10px;
        background: var(--primary);
        border-radius: 50%;
        display: none;
    }
    
    .rg-radio-item.selected .rg-radio-dot::after {
        display: block;
    }
    
    .rg-radio-label {
        font-size: 14px;
        font-weight: 500;
        color: var(--gray-700);
    }
    
    /* Form Actions */
    .rg-form-actions {
        display: flex;
        gap: 12px;
        justify-content: flex-end;
        padding: 20px 24px;
        background: var(--gray-50);
        border-top: 1px solid var(--gray-200);
        border-radius: 0 0 12px 12px;
    }
    
    /* Alert */
    .rg-alert {
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: none;
    }
    
    .rg-alert.success {
        background: #d1fae5;
        color: #065f46;
        display: block;
    }
    
    .rg-alert.error {
        background: #fee2e2;
        color: #991b1b;
        display: block;
    }
    
    @media (max-width: 768px) {
        .rg-form-row {
            grid-template-columns: 1fr;
        }
        
        .rg-form-row.three-col {
            grid-template-columns: 1fr;
        }
        
        .rg-radio-group {
            flex-direction: column;
        }
    }
</style>

<div class="rg-settings-container">
    <div class="rg-settings-header">
        <h1 class="rg-settings-title"><?php _e('Settings', 'rental-gates'); ?></h1>
        <p class="rg-settings-subtitle"><?php _e('Manage your organization settings and preferences.', 'rental-gates'); ?></p>
    </div>
    
    <div id="settings-alert" class="rg-alert"></div>
    
    <form id="settings-form" method="post">
        <?php wp_nonce_field('rental_gates_settings', 'settings_nonce'); ?>
        <input type="hidden" name="action" value="rental_gates_save_settings">
        
        <div class="rg-settings-card">
            <!-- Organization Info -->
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Organization Information', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Basic information about your organization.', 'rental-gates'); ?></p>
                
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="org-name">
                            <?php _e('Organization Name', 'rental-gates'); ?> <span class="required">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="org-name" 
                            name="org_name" 
                            class="rg-form-input" 
                            value="<?php echo esc_attr($organization['name']); ?>"
                            required
                        >
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="contact-email">
                            <?php _e('Contact Email', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="email" 
                            id="contact-email" 
                            name="contact_email" 
                            class="rg-form-input" 
                            value="<?php echo esc_attr($organization['contact_email'] ?? ''); ?>"
                        >
                    </div>
                </div>
                
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="contact-phone">
                            <?php _e('Contact Phone', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="tel" 
                            id="contact-phone" 
                            name="contact_phone" 
                            class="rg-form-input" 
                            value="<?php echo esc_attr($organization['contact_phone'] ?? ''); ?>"
                        >
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="website">
                            <?php _e('Website', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="url" 
                            id="website" 
                            name="website" 
                            class="rg-form-input" 
                            value="<?php echo esc_attr($organization['website'] ?? ''); ?>"
                            placeholder="https://"
                        >
                    </div>
                </div>
                
                <div class="rg-form-row full">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="address">
                            <?php _e('Address', 'rental-gates'); ?>
                        </label>
                        <textarea 
                            id="address" 
                            name="address" 
                            class="rg-form-textarea"
                            rows="2"
                        ><?php echo esc_textarea($organization['address'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            
            <!-- Regional Settings -->
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Regional Settings', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Set your timezone and currency preferences.', 'rental-gates'); ?></p>
                
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="timezone">
                            <?php _e('Timezone', 'rental-gates'); ?>
                        </label>
                        <select id="timezone" name="timezone" class="rg-form-select">
                            <?php foreach ($timezones as $tz_value => $tz_label): ?>
                                <option value="<?php echo esc_attr($tz_value); ?>" <?php selected($organization['timezone'] ?? 'America/New_York', $tz_value); ?>>
                                    <?php echo esc_html($tz_label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="currency">
                            <?php _e('Currency', 'rental-gates'); ?>
                        </label>
                        <select id="currency" name="currency" class="rg-form-select">
                            <?php foreach ($currencies as $currency_code => $currency_label): ?>
                                <option value="<?php echo esc_attr($currency_code); ?>" <?php selected($organization['currency'] ?? 'USD', $currency_code); ?>>
                                    <?php echo esc_html($currency_label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <!-- Late Fee Settings -->
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Late Fee Settings', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Configure how late fees are calculated for overdue rent.', 'rental-gates'); ?></p>
                
                <div class="rg-form-row three-col">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="late-fee-grace-days">
                            <?php _e('Grace Period (Days)', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="number" 
                            id="late-fee-grace-days" 
                            name="late_fee_grace_days" 
                            class="rg-form-input" 
                            value="<?php echo intval($organization['late_fee_grace_days'] ?? 5); ?>"
                            min="0"
                            max="30"
                        >
                        <span class="rg-form-hint"><?php _e('Days after due date before late fee applies', 'rental-gates'); ?></span>
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="late-fee-type">
                            <?php _e('Fee Type', 'rental-gates'); ?>
                        </label>
                        <select id="late-fee-type" name="late_fee_type" class="rg-form-select">
                            <option value="flat" <?php selected($organization['late_fee_type'] ?? 'flat', 'flat'); ?>>
                                <?php _e('Flat Amount', 'rental-gates'); ?>
                            </option>
                            <option value="percentage" <?php selected($organization['late_fee_type'] ?? 'flat', 'percentage'); ?>>
                                <?php _e('Percentage of Rent', 'rental-gates'); ?>
                            </option>
                        </select>
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="late-fee-amount">
                            <?php _e('Fee Amount', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="number" 
                            id="late-fee-amount" 
                            name="late_fee_amount" 
                            class="rg-form-input" 
                            value="<?php echo floatval($organization['late_fee_amount'] ?? 0); ?>"
                            min="0"
                            step="0.01"
                        >
                        <span class="rg-form-hint"><?php _e('$ or % depending on type', 'rental-gates'); ?></span>
                    </div>
                </div>
                
                <div class="rg-form-row">
                    <div class="rg-form-checkbox">
                        <input 
                            type="checkbox" 
                            id="allow-partial-payments" 
                            name="allow_partial_payments"
                            <?php checked($organization['allow_partial_payments'] ?? 1, 1); ?>
                        >
                        <label for="allow-partial-payments"><?php _e('Allow partial rent payments', 'rental-gates'); ?></label>
                    </div>
                </div>
            </div>
            
            <!-- Availability Settings -->
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Availability Settings', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Configure how unit availability is managed.', 'rental-gates'); ?></p>
                
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="coming-soon-window">
                            <?php _e('Coming Soon Window (Days)', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="number" 
                            id="coming-soon-window" 
                            name="coming_soon_window_days" 
                            class="rg-form-input" 
                            value="<?php echo intval($organization['coming_soon_window_days'] ?? 30); ?>"
                            min="0"
                            max="365"
                        >
                        <span class="rg-form-hint"><?php _e('Days before availability to show "Coming Soon"', 'rental-gates'); ?></span>
                    </div>
                    
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="renewal-notice-days">
                            <?php _e('Renewal Notice (Days)', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="number" 
                            id="renewal-notice-days" 
                            name="renewal_notice_days" 
                            class="rg-form-input" 
                            value="<?php echo intval($organization['renewal_notice_days'] ?? 60); ?>"
                            min="0"
                            max="180"
                        >
                        <span class="rg-form-hint"><?php _e('Days before lease end to send renewal notice', 'rental-gates'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Map Settings -->
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Map Settings', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Choose your preferred map provider for location services.', 'rental-gates'); ?></p>
                
                <div class="rg-form-row full">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Map Provider', 'rental-gates'); ?></label>
                        <div class="rg-radio-group">
                            <label class="rg-radio-item <?php echo $map_provider === 'google' ? 'selected' : ''; ?>" onclick="selectMapProvider(this, 'google')">
                                <input type="radio" name="map_provider" value="google" <?php checked($map_provider, 'google'); ?>>
                                <span class="rg-radio-dot"></span>
                                <span class="rg-radio-label"><?php _e('Google Maps', 'rental-gates'); ?></span>
                            </label>
                            <label class="rg-radio-item <?php echo $map_provider === 'openstreetmap' ? 'selected' : ''; ?>" onclick="selectMapProvider(this, 'openstreetmap')">
                                <input type="radio" name="map_provider" value="openstreetmap" <?php checked($map_provider, 'openstreetmap'); ?>>
                                <span class="rg-radio-dot"></span>
                                <span class="rg-radio-label"><?php _e('OpenStreetMap (Free)', 'rental-gates'); ?></span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="rg-form-row full" id="google-api-key-field" style="<?php echo $map_provider !== 'google' ? 'display: none;' : ''; ?>">
                    <div class="rg-form-group">
                        <label class="rg-form-label" for="google-maps-api-key">
                            <?php _e('Google Maps API Key', 'rental-gates'); ?>
                        </label>
                        <input 
                            type="text" 
                            id="google-maps-api-key" 
                            name="google_maps_api_key" 
                            class="rg-form-input" 
                            value="<?php echo esc_attr($google_api_key); ?>"
                            placeholder="AIza..."
                        >
                        <span class="rg-form-hint">
                            <?php _e('Required for Google Maps. Get your API key from', 'rental-gates'); ?> 
                            <a href="https://console.cloud.google.com/google/maps-apis" target="_blank">Google Cloud Console</a>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Stripe Connect Section -->
            <?php 
            $stripe_configured = Rental_Gates_Stripe::is_configured();
            $stripe_account = Rental_Gates_Stripe::get_connected_account($org_id);
            ?>
            <div class="rg-settings-section">
                <h2 class="rg-section-title"><?php _e('Payment Processing', 'rental-gates'); ?></h2>
                <p class="rg-section-description"><?php _e('Connect your Stripe account to receive rent payments directly to your bank.', 'rental-gates'); ?></p>
                
                <?php if (!$stripe_configured): ?>
                <div style="background: #fef3c7; border: 1px solid #fcd34d; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                    <p style="margin: 0; color: #92400e; font-size: 14px;">
                        <strong><?php _e('Stripe Not Configured', 'rental-gates'); ?></strong><br>
                        <?php _e('Platform Stripe keys must be configured by the administrator before you can connect your account.', 'rental-gates'); ?>
                    </p>
                </div>
                <?php else: ?>
                
                <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 24px;">
                    <?php if (!$stripe_account): ?>
                    <!-- Not Connected State -->
                    <div style="text-align: center; padding: 20px 0;">
                        <svg width="64" height="64" viewBox="0 0 32 32" fill="none" style="margin-bottom: 16px;">
                            <rect width="32" height="32" rx="6" fill="#635bff"/>
                            <path d="M15.3 12.7c0-.8.7-1.1 1.8-1.1 1.6 0 3.7.5 5.3 1.4V9.2c-1.8-.7-3.5-1-5.3-1-4.3 0-7.2 2.3-7.2 6.1 0 6 8.2 5 8.2 7.6 0 .9-.8 1.2-1.9 1.2-1.7 0-3.9-.7-5.6-1.6v3.9c1.9.8 3.8 1.2 5.6 1.2 4.4 0 7.4-2.2 7.4-6.1 0-6.4-8.3-5.3-8.3-7.8z" fill="#fff"/>
                        </svg>
                        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: var(--gray-900);">
                            <?php _e('Connect with Stripe', 'rental-gates'); ?>
                        </h3>
                        <p style="color: var(--gray-500); margin: 0 0 20px; font-size: 14px;">
                            <?php _e('Receive rent payments directly to your bank account. Stripe handles all payment processing securely.', 'rental-gates'); ?>
                        </p>
                        <button type="button" onclick="connectStripe('create')" class="rg-btn rg-btn-primary" style="background: #635bff;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                                <path d="M12 5v14M5 12h14"/>
                            </svg>
                            <?php _e('Connect Stripe Account', 'rental-gates'); ?>
                        </button>
                    </div>
                    
                    <?php elseif ($stripe_account['status'] === 'pending' || !$stripe_account['details_submitted']): ?>
                    <!-- Onboarding Incomplete -->
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="width: 48px; height: 48px; background: #fef3c7; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <svg width="24" height="24" fill="none" stroke="#d97706" stroke-width="2" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="M12 8v4M12 16h.01"/>
                            </svg>
                        </div>
                        <div style="flex: 1;">
                            <h3 style="margin: 0 0 4px; font-size: 16px; font-weight: 600; color: var(--gray-900);">
                                <?php _e('Complete Your Setup', 'rental-gates'); ?>
                            </h3>
                            <p style="color: var(--gray-500); margin: 0; font-size: 14px;">
                                <?php _e('Your Stripe account setup is incomplete. Please finish the onboarding process.', 'rental-gates'); ?>
                            </p>
                        </div>
                        <button type="button" onclick="connectStripe('onboarding')" class="rg-btn rg-btn-primary" style="background: #d97706;">
                            <?php _e('Continue Setup', 'rental-gates'); ?>
                        </button>
                    </div>
                    
                    <?php elseif ($stripe_account['status'] === 'active'): ?>
                    <!-- Connected State -->
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="width: 48px; height: 48px; background: #d1fae5; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <svg width="24" height="24" fill="none" stroke="#059669" stroke-width="2" viewBox="0 0 24 24">
                                <path d="M20 6L9 17l-5-5"/>
                            </svg>
                        </div>
                        <div style="flex: 1;">
                            <h3 style="margin: 0 0 4px; font-size: 16px; font-weight: 600; color: var(--gray-900);">
                                <?php _e('Stripe Connected', 'rental-gates'); ?>
                                <span style="display: inline-block; background: #d1fae5; color: #059669; font-size: 11px; padding: 2px 8px; border-radius: 10px; margin-left: 8px; font-weight: 500;">
                                    <?php _e('Active', 'rental-gates'); ?>
                                </span>
                            </h3>
                            <p style="color: var(--gray-500); margin: 0; font-size: 14px;">
                                <?php 
                                if ($stripe_account['business_name']) {
                                    echo esc_html($stripe_account['business_name']);
                                } else {
                                    _e('Your account is ready to receive payments', 'rental-gates');
                                }
                                ?>
                            </p>
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button type="button" onclick="connectStripe('dashboard')" class="rg-btn rg-btn-secondary">
                                <?php _e('View Dashboard', 'rental-gates'); ?>
                            </button>
                            <button type="button" onclick="connectStripe('refresh')" class="rg-btn rg-btn-secondary" title="<?php _e('Refresh Status', 'rental-gates'); ?>">
                                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    
                    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-200);">
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; text-align: center;">
                            <div>
                                <div style="font-size: 12px; color: var(--gray-500); margin-bottom: 4px;"><?php _e('Charges', 'rental-gates'); ?></div>
                                <div style="font-weight: 600; color: <?php echo $stripe_account['charges_enabled'] ? '#059669' : '#dc2626'; ?>;">
                                    <?php echo $stripe_account['charges_enabled'] ? __('Enabled', 'rental-gates') : __('Disabled', 'rental-gates'); ?>
                                </div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: var(--gray-500); margin-bottom: 4px;"><?php _e('Payouts', 'rental-gates'); ?></div>
                                <div style="font-weight: 600; color: <?php echo $stripe_account['payouts_enabled'] ? '#059669' : '#dc2626'; ?>;">
                                    <?php echo $stripe_account['payouts_enabled'] ? __('Enabled', 'rental-gates') : __('Disabled', 'rental-gates'); ?>
                                </div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: var(--gray-500); margin-bottom: 4px;"><?php _e('Currency', 'rental-gates'); ?></div>
                                <div style="font-weight: 600; color: var(--gray-900);">
                                    <?php echo strtoupper($stripe_account['default_currency'] ?? 'USD'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php else: ?>
                    <!-- Restricted/Error State -->
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="width: 48px; height: 48px; background: #fee2e2; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <svg width="24" height="24" fill="none" stroke="#dc2626" stroke-width="2" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="M15 9l-6 6M9 9l6 6"/>
                            </svg>
                        </div>
                        <div style="flex: 1;">
                            <h3 style="margin: 0 0 4px; font-size: 16px; font-weight: 600; color: var(--gray-900);">
                                <?php _e('Account Restricted', 'rental-gates'); ?>
                            </h3>
                            <p style="color: var(--gray-500); margin: 0; font-size: 14px;">
                                <?php _e('There is an issue with your Stripe account. Please visit the Stripe dashboard to resolve.', 'rental-gates'); ?>
                            </p>
                        </div>
                        <button type="button" onclick="connectStripe('dashboard')" class="rg-btn rg-btn-primary" style="background: #dc2626;">
                            <?php _e('Fix Issues', 'rental-gates'); ?>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php endif; ?>
            
            <!-- Form Actions -->
            <div class="rg-form-actions">
                <button type="submit" class="rg-btn rg-btn-primary" id="save-settings-btn">
                    <?php _e('Save Settings', 'rental-gates'); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<script>
function selectMapProvider(element, value) {
    document.querySelectorAll('.rg-radio-item').forEach(item => {
        item.classList.remove('selected');
    });
    element.classList.add('selected');
    element.querySelector('input').checked = true;
    
    // Show/hide Google API key field
    const apiKeyField = document.getElementById('google-api-key-field');
    if (value === 'google') {
        apiKeyField.style.display = '';
    } else {
        apiKeyField.style.display = 'none';
    }
}

// Form submission
document.getElementById('settings-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = document.getElementById('save-settings-btn');
    const alert = document.getElementById('settings-alert');
    
    submitBtn.disabled = true;
    submitBtn.textContent = '<?php _e('Saving...', 'rental-gates'); ?>';
    
    fetch(rentalGatesData.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert.className = 'rg-alert success';
            alert.textContent = data.data.message || '<?php _e('Settings saved successfully', 'rental-gates'); ?>';
        } else {
            alert.className = 'rg-alert error';
            alert.textContent = data.data || '<?php _e('Error saving settings', 'rental-gates'); ?>';
        }
        
        submitBtn.disabled = false;
        submitBtn.textContent = '<?php _e('Save Settings', 'rental-gates'); ?>';
        
        // Scroll to top to show alert
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        alert.className = 'rg-alert error';
        alert.textContent = '<?php _e('Error saving settings', 'rental-gates'); ?>';
        
        submitBtn.disabled = false;
        submitBtn.textContent = '<?php _e('Save Settings', 'rental-gates'); ?>';
    });
});

// Stripe Connect function
function connectStripe(action) {
    const formData = new FormData();
    formData.append('action', 'rental_gates_stripe_connect');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_stripe'); ?>');
    formData.append('stripe_action', action);
    
    // Show loading state
    const alert = document.getElementById('settings-alert');
    alert.className = 'rg-alert';
    alert.style.display = 'none';
    
    fetch(rentalGatesData.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.data.redirect_url) {
                // Redirect to Stripe
                window.location.href = data.data.redirect_url;
            } else if (data.data.message) {
                alert.className = 'rg-alert success';
                alert.textContent = data.data.message;
                alert.style.display = 'block';
                // Reload to show updated status
                setTimeout(() => window.location.reload(), 1500);
            }
        } else {
            alert.className = 'rg-alert error';
            alert.textContent = data.data.message || '<?php _e('Error connecting to Stripe', 'rental-gates'); ?>';
            alert.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert.className = 'rg-alert error';
        alert.textContent = '<?php _e('Error connecting to Stripe', 'rental-gates'); ?>';
        alert.style.display = 'block';
    });
}
</script>
