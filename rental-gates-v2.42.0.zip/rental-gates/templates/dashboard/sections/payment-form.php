<?php
/**
 * Payment Form Section
 */
if (!defined('ABSPATH')) exit;

$org_id = Rental_Gates_Roles::get_organization_id();
if (!$org_id) {
    wp_redirect(home_url('/rental-gates/login'));
    exit;
}

// Check if editing - PRIMARY method: parse REQUEST_URI directly
$payment_id = 0;
$payment = null;
$is_edit = false;

if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/payments/(\d+)(?:/edit)?(?:/|$|\?)#', $uri, $matches)) {
        $payment_id = intval($matches[1]);
    }
}

// FALLBACK: try query var if URL parsing failed
if (!$payment_id) {
    $section = get_query_var('rental_gates_section');
    $parts = explode('/', $section);
    if (isset($parts[1]) && is_numeric($parts[1])) {
        $payment_id = intval($parts[1]);
    }
}

if ($payment_id) {
    $payment = Rental_Gates_Payment::get_with_details($payment_id);
    if ($payment && $payment['organization_id'] === $org_id) {
        $is_edit = true;
    }
}

// Get active leases for selection
$leases = Rental_Gates_Lease::get_for_organization($org_id, array('status' => 'active'));

// Get tenants for selection
$tenants_result = Rental_Gates_Tenant::get_for_organization($org_id, array('status' => array('active', 'prospect')));
$tenants = $tenants_result['tenants'] ?? array();

// Pre-select lease if provided
$preselect_lease_id = isset($_GET['lease_id']) ? intval($_GET['lease_id']) : 0;

$page_title = $is_edit ? __('Edit Payment', 'rental-gates') : __('Record Payment', 'rental-gates');
?>

<style>
    .rg-form-container { max-width: 700px; }
    .rg-back-link { display: flex; align-items: center; gap: 6px; color: var(--gray-500); text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    .rg-back-link:hover { color: var(--primary); }
    .rg-form-header { margin-bottom: 24px; }
    .rg-form-header h1 { font-size: 24px; font-weight: 700; margin: 0; }
    
    .rg-form-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 24px; }
    .rg-form-section { padding: 24px; border-bottom: 1px solid var(--gray-100); }
    .rg-form-section:last-child { border-bottom: none; }
    .rg-form-section-title { font-size: 16px; font-weight: 600; margin-bottom: 20px; color: var(--gray-900); }
    
    .rg-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .rg-form-row:last-child { margin-bottom: 0; }
    .rg-form-row.three-col { grid-template-columns: 1fr 1fr 1fr; }
    .rg-form-row.full { grid-template-columns: 1fr; }
    
    .rg-form-group { display: flex; flex-direction: column; gap: 6px; }
    .rg-form-label { font-size: 14px; font-weight: 500; color: var(--gray-700); }
    .rg-form-label .required { color: #ef4444; }
    
    .rg-form-input, .rg-form-select, .rg-form-textarea { 
        width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; 
        font-size: 14px; font-family: inherit; transition: border-color 0.2s, box-shadow 0.2s;
        background-color: #fff;
    }
    .rg-form-input:focus, .rg-form-select:focus, .rg-form-textarea:focus { 
        outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1); 
    }
    .rg-form-textarea { min-height: 80px; resize: vertical; }
    .rg-form-hint { font-size: 12px; color: var(--gray-500); }
    
    .rg-form-actions { 
        display: flex; justify-content: flex-end; gap: 12px; padding: 20px 24px; 
        background: var(--gray-50); border-top: 1px solid var(--gray-100); border-radius: 0 0 12px 12px; 
    }
    
    .rg-lease-preview { 
        background: var(--gray-50); border-radius: 8px; padding: 16px; margin-top: 16px;
        display: none; 
    }
    .rg-lease-preview.visible { display: block; }
    .rg-lease-preview-title { font-weight: 600; margin-bottom: 8px; }
    .rg-lease-preview-info { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; font-size: 13px; }
    .rg-lease-preview-item span { color: var(--gray-500); display: block; }
    
    .rg-alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .rg-alert-error { background: #fee2e2; color: #991b1b; }
    .rg-alert-success { background: #d1fae5; color: #065f46; }
    
    @media (max-width: 768px) {
        .rg-form-row { grid-template-columns: 1fr; }
        .rg-form-row.three-col { grid-template-columns: 1fr; }
    }
</style>

<a href="<?php echo home_url('/rental-gates/dashboard/payments'); ?>" class="rg-back-link">
    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    <?php _e('Back to Payments', 'rental-gates'); ?>
</a>

<div class="rg-form-container">
    <div class="rg-form-header">
        <h1><?php echo $page_title; ?></h1>
    </div>
    
    <div id="form-message"></div>
    
    <form id="payment-form" class="rg-form-card">
        <input type="hidden" name="payment_id" value="<?php echo $payment_id; ?>">
        
        <!-- Lease Selection -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Lease & Tenant', 'rental-gates'); ?></h3>
            
            <div class="rg-form-row full">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="lease_id"><?php _e('Lease', 'rental-gates'); ?></label>
                    <select id="lease_id" name="lease_id" class="rg-form-select" onchange="updateLeasePreview()">
                        <option value=""><?php _e('Select lease (optional)...', 'rental-gates'); ?></option>
                        <?php foreach ($leases as $lease): ?>
                        <option value="<?php echo $lease['id']; ?>" 
                                data-unit="<?php echo esc_attr($lease['unit_name'] ?? ''); ?>"
                                data-building="<?php echo esc_attr($lease['building_name'] ?? ''); ?>"
                                data-rent="<?php echo $lease['rent_amount']; ?>"
                                data-tenant="<?php echo esc_attr(!empty($lease['tenants']) ? $lease['tenants'][0]['full_name'] ?? '' : ''); ?>"
                                data-tenant-id="<?php echo !empty($lease['tenants']) ? $lease['tenants'][0]['tenant_id'] ?? '' : ''; ?>"
                                <?php selected($is_edit ? ($payment['lease_id'] ?? 0) : $preselect_lease_id, $lease['id']); ?>>
                            <?php echo esc_html(($lease['unit_name'] ?? '') . ' - ' . ($lease['building_name'] ?? '')); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="rg-form-hint"><?php _e('Select a lease to auto-fill tenant and amount', 'rental-gates'); ?></span>
                </div>
            </div>
            
            <div id="lease-preview" class="rg-lease-preview">
                <div class="rg-lease-preview-title"><?php _e('Lease Details', 'rental-gates'); ?></div>
                <div class="rg-lease-preview-info">
                    <div class="rg-lease-preview-item"><span><?php _e('Unit', 'rental-gates'); ?></span><strong id="preview-unit">—</strong></div>
                    <div class="rg-lease-preview-item"><span><?php _e('Tenant', 'rental-gates'); ?></span><strong id="preview-tenant">—</strong></div>
                    <div class="rg-lease-preview-item"><span><?php _e('Monthly Rent', 'rental-gates'); ?></span><strong id="preview-rent">—</strong></div>
                </div>
            </div>
            
            <div class="rg-form-row full" style="margin-top: 20px;">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="tenant_id"><?php _e('Tenant', 'rental-gates'); ?></label>
                    <select id="tenant_id" name="tenant_id" class="rg-form-select">
                        <option value=""><?php _e('Select tenant (optional)...', 'rental-gates'); ?></option>
                        <?php foreach ($tenants as $tenant): ?>
                        <option value="<?php echo $tenant['id']; ?>" <?php selected($is_edit ? ($payment['tenant_id'] ?? 0) : 0, $tenant['id']); ?>>
                            <?php echo esc_html($tenant['full_name'] . ' (' . $tenant['email'] . ')'); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>
        
        <!-- Payment Details -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Payment Details', 'rental-gates'); ?></h3>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="type"><?php _e('Type', 'rental-gates'); ?> <span class="required">*</span></label>
                    <select id="type" name="type" class="rg-form-select" required>
                        <option value="rent" <?php selected($payment['type'] ?? 'rent', 'rent'); ?>><?php _e('Rent', 'rental-gates'); ?></option>
                        <option value="deposit" <?php selected($payment['type'] ?? '', 'deposit'); ?>><?php _e('Deposit', 'rental-gates'); ?></option>
                        <option value="late_fee" <?php selected($payment['type'] ?? '', 'late_fee'); ?>><?php _e('Late Fee', 'rental-gates'); ?></option>
                        <option value="damage" <?php selected($payment['type'] ?? '', 'damage'); ?>><?php _e('Damage', 'rental-gates'); ?></option>
                        <option value="other" <?php selected($payment['type'] ?? '', 'other'); ?>><?php _e('Other', 'rental-gates'); ?></option>
                        <option value="refund" <?php selected($payment['type'] ?? '', 'refund'); ?>><?php _e('Refund', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label" for="amount"><?php _e('Amount', 'rental-gates'); ?> <span class="required">*</span></label>
                    <input type="number" id="amount" name="amount" class="rg-form-input" step="0.01" min="0" required
                           value="<?php echo esc_attr($payment['amount'] ?? ''); ?>" placeholder="0.00">
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="method"><?php _e('Payment Method', 'rental-gates'); ?></label>
                    <select id="method" name="method" class="rg-form-select">
                        <option value="other" <?php selected($payment['method'] ?? 'other', 'other'); ?>><?php _e('Other', 'rental-gates'); ?></option>
                        <option value="cash" <?php selected($payment['method'] ?? '', 'cash'); ?>><?php _e('Cash', 'rental-gates'); ?></option>
                        <option value="check" <?php selected($payment['method'] ?? '', 'check'); ?>><?php _e('Check', 'rental-gates'); ?></option>
                        <option value="stripe_card" <?php selected($payment['method'] ?? '', 'stripe_card'); ?>><?php _e('Credit Card', 'rental-gates'); ?></option>
                        <option value="stripe_ach" <?php selected($payment['method'] ?? '', 'stripe_ach'); ?>><?php _e('Bank Transfer', 'rental-gates'); ?></option>
                        <option value="money_order" <?php selected($payment['method'] ?? '', 'money_order'); ?>><?php _e('Money Order', 'rental-gates'); ?></option>
                        <option value="external" <?php selected($payment['method'] ?? '', 'external'); ?>><?php _e('External', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label" for="status"><?php _e('Status', 'rental-gates'); ?></label>
                    <select id="status" name="status" class="rg-form-select">
                        <option value="pending" <?php selected($payment['status'] ?? 'pending', 'pending'); ?>><?php _e('Pending', 'rental-gates'); ?></option>
                        <option value="succeeded" <?php selected($payment['status'] ?? '', 'succeeded'); ?>><?php _e('Paid', 'rental-gates'); ?></option>
                        <option value="partially_paid" <?php selected($payment['status'] ?? '', 'partially_paid'); ?>><?php _e('Partially Paid', 'rental-gates'); ?></option>
                    </select>
                </div>
            </div>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="due_date"><?php _e('Due Date', 'rental-gates'); ?></label>
                    <input type="date" id="due_date" name="due_date" class="rg-form-input"
                           value="<?php echo esc_attr($payment['due_date'] ?? ''); ?>">
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label" for="paid_at"><?php _e('Paid Date', 'rental-gates'); ?></label>
                    <input type="date" id="paid_at" name="paid_at" class="rg-form-input"
                           value="<?php echo !empty($payment['paid_at']) ? date('Y-m-d', strtotime($payment['paid_at'])) : ''; ?>">
                </div>
            </div>
        </div>
        
        <!-- Period -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Billing Period (Optional)', 'rental-gates'); ?></h3>
            
            <div class="rg-form-row">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="period_start"><?php _e('Period Start', 'rental-gates'); ?></label>
                    <input type="date" id="period_start" name="period_start" class="rg-form-input"
                           value="<?php echo esc_attr($payment['period_start'] ?? ''); ?>">
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label" for="period_end"><?php _e('Period End', 'rental-gates'); ?></label>
                    <input type="date" id="period_end" name="period_end" class="rg-form-input"
                           value="<?php echo esc_attr($payment['period_end'] ?? ''); ?>">
                </div>
            </div>
        </div>
        
        <!-- Notes -->
        <div class="rg-form-section">
            <h3 class="rg-form-section-title"><?php _e('Notes', 'rental-gates'); ?></h3>
            
            <div class="rg-form-row full">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="description"><?php _e('Description', 'rental-gates'); ?></label>
                    <input type="text" id="description" name="description" class="rg-form-input"
                           value="<?php echo esc_attr($payment['description'] ?? ''); ?>"
                           placeholder="<?php _e('e.g., December 2024 Rent', 'rental-gates'); ?>">
                </div>
            </div>
            
            <div class="rg-form-row full">
                <div class="rg-form-group">
                    <label class="rg-form-label" for="notes"><?php _e('Internal Notes', 'rental-gates'); ?></label>
                    <textarea id="notes" name="notes" class="rg-form-textarea"
                              placeholder="<?php _e('Additional notes...', 'rental-gates'); ?>"><?php echo esc_textarea($payment['notes'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>
        
        <div class="rg-form-actions">
            <a href="<?php echo home_url('/rental-gates/dashboard/payments'); ?>" class="rg-btn rg-btn-secondary"><?php _e('Cancel', 'rental-gates'); ?></a>
            <button type="submit" class="rg-btn rg-btn-primary"><?php echo $is_edit ? __('Update Payment', 'rental-gates') : __('Record Payment', 'rental-gates'); ?></button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const leaseSelect = document.getElementById('lease_id');
    if (leaseSelect.value) {
        updateLeasePreview();
    }
});

function updateLeasePreview() {
    const select = document.getElementById('lease_id');
    const preview = document.getElementById('lease-preview');
    const option = select.options[select.selectedIndex];
    
    if (!select.value) {
        preview.classList.remove('visible');
        return;
    }
    
    document.getElementById('preview-unit').textContent = option.dataset.unit + ' - ' + option.dataset.building;
    document.getElementById('preview-tenant').textContent = option.dataset.tenant || '—';
    document.getElementById('preview-rent').textContent = '$' + parseFloat(option.dataset.rent || 0).toLocaleString();
    preview.classList.add('visible');
    
    // Auto-fill tenant
    if (option.dataset.tenantId) {
        document.getElementById('tenant_id').value = option.dataset.tenantId;
    }
    
    // Auto-fill amount if empty
    const amountInput = document.getElementById('amount');
    if (!amountInput.value && option.dataset.rent) {
        amountInput.value = option.dataset.rent;
    }
}

document.getElementById('payment-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const paymentId = parseInt(formData.get('payment_id')) || 0;
    formData.append('action', paymentId > 0 ? 'rental_gates_update_payment' : 'rental_gates_create_payment');
    formData.append('nonce', rentalGatesData.nonce);
    
    const messageDiv = document.getElementById('form-message');
    messageDiv.innerHTML = '';
    
    fetch(rentalGatesData.ajaxUrl, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.href = '<?php echo home_url('/rental-gates/dashboard/payments/'); ?>' + data.data.payment.id;
            } else {
                messageDiv.innerHTML = '<div class="rg-alert rg-alert-error">' + (data.data || '<?php _e('Error saving payment', 'rental-gates'); ?>') + '</div>';
                window.scrollTo(0, 0);
            }
        });
});
</script>
