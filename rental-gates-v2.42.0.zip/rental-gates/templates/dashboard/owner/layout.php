<!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <title><?php echo esc_html($page_title ?? __('Dashboard', 'rental-gates')); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php echo RENTAL_GATES_PLUGIN_URL; ?>assets/css/mobile.css?v=<?php echo RENTAL_GATES_VERSION; ?>">
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #1e3a5f;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
            --sidebar-width: 260px;
            --header-height: 64px;
        }
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            color: var(--gray-800);
            line-height: 1.5;
        }
        
        /* Sidebar */
        .rg-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: var(--sidebar-width);
            background: var(--secondary);
            color: #fff;
            display: flex;
            flex-direction: column;
            z-index: 100;
            transition: transform 0.3s ease;
        }
        
        .rg-sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .rg-sidebar-logo {
            font-size: 20px;
            font-weight: 700;
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .rg-sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 16px 0;
        }
        
        .rg-nav-section {
            padding: 0 12px;
            margin-bottom: 24px;
        }
        
        .rg-nav-section-title {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: rgba(255,255,255,0.5);
            padding: 0 12px;
            margin-bottom: 8px;
        }
        
        .rg-nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .rg-nav-item:hover {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }
        
        .rg-nav-item.active {
            background: var(--primary);
            color: #fff;
        }
        
        .rg-nav-item svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }
        
        .rg-nav-badge {
            margin-left: auto;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 600;
            padding: 2px 8px;
            border-radius: 10px;
        }
        
        .rg-sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        /* Main Content */
        .rg-main {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }
        
        /* Header */
        .rg-header {
            position: sticky;
            top: 0;
            height: var(--header-height);
            background: #fff;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            z-index: 50;
        }
        
        .rg-header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .rg-header-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gray-900);
        }
        
        .rg-header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .rg-search-box {
            display: flex;
            align-items: center;
            background: var(--gray-100);
            border-radius: 8px;
            padding: 8px 12px;
            gap: 8px;
            width: 280px;
        }
        
        .rg-search-box input {
            border: none;
            background: none;
            outline: none;
            font-size: 14px;
            width: 100%;
        }
        
        .rg-header-btn {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            border: none;
            background: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            position: relative;
            transition: background 0.2s;
            text-decoration: none;
        }
        
        .rg-header-btn:hover {
            background: var(--gray-100);
            color: var(--primary);
        }
        
        .rg-notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: var(--danger);
            border-radius: 50%;
        }
        
        .rg-notification-badge {
            position: absolute;
            top: 2px;
            right: 2px;
            min-width: 18px;
            height: 18px;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 600;
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
        }
        
        .rg-user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 8px;
            transition: background 0.2s;
        }
        
        .rg-user-menu:hover {
            background: var(--gray-100);
        }
        
        .rg-user-menu-toggle {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .rg-user-menu-toggle svg {
            width: 16px;
            height: 16px;
            color: var(--gray-400);
            transition: transform 0.2s;
        }
        
        .rg-user-menu.open .rg-user-menu-toggle svg {
            transform: rotate(180deg);
        }
        
        .rg-user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            min-width: 220px;
            background: #fff;
            border: 1px solid var(--gray-200);
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.12);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s;
            z-index: 1000;
        }
        
        .rg-user-menu.open .rg-user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .rg-dropdown-header {
            padding: 16px;
            border-bottom: 1px solid var(--gray-100);
        }
        
        .rg-dropdown-header-name {
            font-weight: 600;
            color: var(--gray-900);
            font-size: 14px;
        }
        
        .rg-dropdown-header-email {
            font-size: 12px;
            color: var(--gray-500);
            margin-top: 2px;
            word-break: break-all;
        }
        
        .rg-dropdown-menu {
            padding: 8px;
        }
        
        .rg-dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 8px;
            color: var(--gray-700);
            text-decoration: none;
            font-size: 14px;
            transition: background 0.15s;
        }
        
        .rg-dropdown-item:hover {
            background: var(--gray-50);
        }
        
        .rg-dropdown-item svg {
            width: 18px;
            height: 18px;
            color: var(--gray-400);
        }
        
        .rg-dropdown-divider {
            height: 1px;
            background: var(--gray-100);
            margin: 8px 0;
        }
        
        .rg-dropdown-item-danger {
            color: #dc2626;
        }
        
        .rg-dropdown-item-danger:hover {
            background: #fef2f2;
        }
        
        .rg-dropdown-item-danger svg {
            color: #dc2626;
        }
        
        .rg-user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--primary);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
        }
        
        .rg-user-info {
            text-align: left;
        }
        
        .rg-user-name {
            font-size: 14px;
            font-weight: 600;
            color: var(--gray-900);
        }
        
        .rg-user-role {
            font-size: 12px;
            color: var(--gray-500);
        }
        
        /* Content Area */
        .rg-content {
            padding: 24px;
        }
        
        /* Cards */
        .rg-card {
            background: #fff;
            border-radius: 12px;
            border: 1px solid var(--gray-200);
            padding: 24px;
        }
        
        .rg-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }
        
        .rg-card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-900);
        }
        
        /* Stat Cards */
        .rg-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .rg-stat-card {
            background: #fff;
            border-radius: 12px;
            border: 1px solid var(--gray-200);
            padding: 20px;
            display: flex;
            align-items: flex-start;
            gap: 16px;
        }
        
        .rg-stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .rg-stat-icon.blue { background: #dbeafe; color: var(--primary); }
        .rg-stat-icon.green { background: #d1fae5; color: var(--success); }
        .rg-stat-icon.yellow { background: #fef3c7; color: var(--warning); }
        .rg-stat-icon.red { background: #fee2e2; color: var(--danger); }
        
        .rg-stat-value {
            font-size: 28px;
            font-weight: 700;
            color: var(--gray-900);
            line-height: 1;
        }
        
        .rg-stat-label {
            font-size: 14px;
            color: var(--gray-500);
            margin-top: 4px;
        }
        
        /* Buttons */
        .rg-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            text-decoration: none;
        }
        
        .rg-btn-primary {
            background: var(--primary);
            color: #fff;
        }
        
        .rg-btn-primary:hover {
            background: var(--primary-dark);
        }
        
        .rg-btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
        }
        
        .rg-btn-secondary:hover {
            background: var(--gray-200);
        }
        
        /* Mobile toggle */
        .rg-mobile-toggle {
            display: none;
            background: none;
            border: none;
            padding: 8px;
            cursor: pointer;
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .rg-sidebar {
                transform: translateX(-100%);
                box-shadow: none;
            }
            
            .rg-sidebar.open {
                transform: translateX(0);
                box-shadow: 4px 0 20px rgba(0, 0, 0, 0.2);
            }
            
            .rg-main {
                margin-left: 0;
            }
            
            .rg-mobile-toggle {
                display: flex;
            }
            
            .rg-search-box {
                display: none;
            }
            
            .rg-header {
                padding: 12px 16px;
            }
        }
        
        @media (max-width: 768px) {
            .rg-content {
                padding: 16px;
            }
            
            .rg-user-info {
                display: none;
            }
            
            .rg-header-right {
                gap: 8px;
            }
        }
        
        @media (max-width: 375px) {
            .rg-content {
                padding: 12px;
            }
            
            .rg-sidebar-logo span:not(:first-child) {
                display: none;
            }
        }
        
        /* Sidebar Overlay */
        .rg-sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 99;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .rg-sidebar-overlay.active {
            display: block;
            opacity: 1;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="rg-sidebar" id="sidebar">
        <div class="rg-sidebar-header">
            <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="rg-sidebar-logo">
                <svg width="32" height="32" viewBox="0 0 32 32" fill="none"><rect width="32" height="32" rx="8" fill="#2563eb"/><path d="M8 14L16 8L24 14V24H8V14Z" stroke="white" stroke-width="2" stroke-linejoin="round"/><path d="M12 24V18H20V24" stroke="white" stroke-width="2"/></svg>
                <?php _e('Rental Gates', 'rental-gates'); ?>
            </a>
        </div>
        
        <nav class="rg-sidebar-nav">
            <div class="rg-nav-section">
                <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'dashboard' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    <?php _e('Dashboard', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Property Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Property', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" class="rg-nav-item <?php echo in_array(($current_page ?? ''), ['buildings', 'building', 'unit']) ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <?php _e('Buildings & Units', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Tenants Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Tenants', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/tenants'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'tenants') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                    <?php _e('Tenants', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/leases'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'leases') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
                    <?php _e('Leases', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/applications'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'applications') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <?php _e('Applications', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Financial Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Financial', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/payments'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'payments') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                    <?php _e('Payments', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Operations Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Operations', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/maintenance'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'maintenance') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <?php _e('Maintenance', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/vendors'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'vendors') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    <?php _e('Vendors', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Team Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Team', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/staff'); ?>" class="rg-nav-item <?php echo strpos(($current_page ?? ''), 'staff') === 0 ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    <?php _e('Staff Members', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- CRM Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('CRM', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/leads'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'leads' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    <?php _e('Leads', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- Tools Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('Tools', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/marketing'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'marketing' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
                    <?php _e('Marketing', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/reports'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'reports' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                    <?php _e('Reports', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/documents'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'documents' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <?php _e('Documents', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/ai-tools'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'ai-tools' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
                    <?php _e('AI Tools', 'rental-gates'); ?>
                </a>
            </div>
            
            <!-- System Section -->
            <div class="rg-nav-section">
                <div class="rg-nav-section-title"><?php _e('System', 'rental-gates'); ?></div>
                <a href="<?php echo home_url('/rental-gates/dashboard/billing'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'billing' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                    <?php _e('Billing', 'rental-gates'); ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/notifications'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'notifications' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                    <?php _e('Notifications', 'rental-gates'); ?>
                    <?php 
                    $unread = Rental_Gates_Notification::get_unread_count(get_current_user_id());
                    if ($unread > 0): ?>
                    <span style="background: #ef4444; color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 10px; margin-left: auto;"><?php echo $unread; ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?php echo home_url('/rental-gates/dashboard/automation-settings'); ?>" class="rg-nav-item <?php echo ($current_page ?? '') === 'automation-settings' ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    <?php _e('Automation', 'rental-gates'); ?>
                </a>
            </div>
        </nav>
        
        <div class="rg-sidebar-footer">
            <a href="<?php echo home_url('/rental-gates/dashboard/settings'); ?>" class="rg-nav-item">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <?php _e('Settings', 'rental-gates'); ?>
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="rg-main">
        <!-- Header -->
        <header class="rg-header">
            <div class="rg-header-left">
                <button class="rg-mobile-toggle" onclick="toggleMobileSidebar()" aria-label="<?php _e('Toggle menu', 'rental-gates'); ?>">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
                </button>
                <h1 class="rg-header-title"><?php echo esc_html($page_title ?? __('Dashboard', 'rental-gates')); ?></h1>
            </div>
            
            <div class="rg-header-right">
                <div class="rg-search-box">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input type="text" placeholder="<?php _e('Search...', 'rental-gates'); ?>">
                </div>
                
                <!-- Messages -->
                <?php 
                $header_org_id = Rental_Gates_Roles::get_organization_id();
                $messages_unread = Rental_Gates_Message::get_unread_count($header_org_id, get_current_user_id(), 'staff');
                ?>
                <a href="<?php echo home_url('/rental-gates/dashboard/messages'); ?>" class="rg-header-btn" style="position: relative;" title="<?php _e('Messages', 'rental-gates'); ?>">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                    <?php if ($messages_unread > 0): ?>
                    <span class="rg-notification-badge"><?php echo $messages_unread > 9 ? '9+' : $messages_unread; ?></span>
                    <?php endif; ?>
                </a>
                
                <!-- Announcements -->
                <a href="<?php echo home_url('/rental-gates/dashboard/announcements'); ?>" class="rg-header-btn" style="position: relative;" title="<?php _e('Announcements', 'rental-gates'); ?>">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
                </a>
                
                <!-- Notifications -->
                <a href="<?php echo home_url('/rental-gates/dashboard/notifications'); ?>" class="rg-header-btn" style="position: relative;" title="<?php _e('Notifications', 'rental-gates'); ?>">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                    <?php 
                    $header_unread = Rental_Gates_Notification::get_unread_count(get_current_user_id());
                    if ($header_unread > 0): ?>
                    <span class="rg-notification-badge"><?php echo $header_unread > 9 ? '9+' : $header_unread; ?></span>
                    <?php endif; ?>
                </a>
                
                <div class="rg-user-menu" id="userMenu" onclick="toggleUserMenu()">
                    <div class="rg-user-menu-toggle">
                        <div class="rg-user-avatar">
                            <?php echo strtoupper(substr(wp_get_current_user()->display_name, 0, 1)); ?>
                        </div>
                        <div class="rg-user-info">
                            <div class="rg-user-name"><?php echo esc_html(wp_get_current_user()->display_name); ?></div>
                            <div class="rg-user-role"><?php echo esc_html($organization['name'] ?? ''); ?></div>
                        </div>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="6 9 12 15 18 9"/>
                        </svg>
                    </div>
                    
                    <div class="rg-user-dropdown">
                        <div class="rg-dropdown-header">
                            <div class="rg-dropdown-header-name"><?php echo esc_html(wp_get_current_user()->display_name); ?></div>
                            <div class="rg-dropdown-header-email"><?php echo esc_html(wp_get_current_user()->user_email); ?></div>
                        </div>
                        <div class="rg-dropdown-menu">
                            <a href="<?php echo home_url('/rental-gates/dashboard/settings'); ?>" class="rg-dropdown-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="3"/>
                                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                                </svg>
                                <?php _e('Settings', 'rental-gates'); ?>
                            </a>
                            <a href="https://docs.rentalgates.com" target="_blank" class="rg-dropdown-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"/>
                                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                                </svg>
                                <?php _e('Help & Support', 'rental-gates'); ?>
                            </a>
                            <div class="rg-dropdown-divider"></div>
                            <a href="<?php echo wp_logout_url(home_url('/rental-gates/login')); ?>" class="rg-dropdown-item rg-dropdown-item-danger">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                                    <polyline points="16 17 21 12 16 7"/>
                                    <line x1="21" y1="12" x2="9" y2="12"/>
                                </svg>
                                <?php _e('Sign Out', 'rental-gates'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Page Content -->
        <div class="rg-content">
            <?php 
            // Include page-specific content
            if (!empty($content_template) && file_exists($content_template)) {
                include $content_template;
            } else {
                // Default dashboard content - use absolute path to templates
                $overview_path = RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/sections/overview.php';
                if (file_exists($overview_path)) {
                    include $overview_path;
                } else {
                    echo '<div class="rg-card"><p>' . __('Welcome to your dashboard!', 'rental-gates') . '</p></div>';
                }
            }
            ?>
        </div>
    </main>
    
    <!-- Sidebar Overlay (Mobile) -->
    <div class="rg-sidebar-overlay" id="sidebarOverlay" onclick="closeMobileSidebar()"></div>
    
    <!-- Bottom Navigation (Mobile) -->
    <nav class="rg-bottom-nav" id="bottomNav">
        <a href="<?php echo home_url('/rental-gates/dashboard'); ?>" class="rg-bottom-nav-item <?php echo ($current_page ?? '') === 'dashboard' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            <span><?php _e('Home', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/dashboard/buildings'); ?>" class="rg-bottom-nav-item <?php echo in_array(($current_page ?? ''), ['buildings', 'building', 'unit']) ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
            <span><?php _e('Buildings', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/dashboard/payments'); ?>" class="rg-bottom-nav-item <?php echo strpos(($current_page ?? ''), 'payments') === 0 ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <span><?php _e('Payments', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/dashboard/messages'); ?>" class="rg-bottom-nav-item <?php echo ($current_page ?? '') === 'messages' ? 'active' : ''; ?>" style="position: relative;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
            <span><?php _e('Messages', 'rental-gates'); ?></span>
            <?php if ($messages_unread > 0): ?>
            <span class="rg-bottom-nav-badge"><?php echo $messages_unread > 9 ? '9+' : $messages_unread; ?></span>
            <?php endif; ?>
        </a>
        <button class="rg-bottom-nav-item" onclick="toggleMobileSidebar()">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            <span><?php _e('More', 'rental-gates'); ?></span>
        </button>
    </nav>
    
    <script>
    // User menu toggle
    function toggleUserMenu() {
        document.getElementById('userMenu').classList.toggle('open');
    }
    
    // Mobile sidebar functions
    function toggleMobileSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const isOpen = sidebar.classList.contains('open');
        
        if (isOpen) {
            closeMobileSidebar();
        } else {
            sidebar.classList.add('open');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }
    
    function closeMobileSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const menu = document.getElementById('userMenu');
        if (menu && !menu.contains(e.target)) {
            menu.classList.remove('open');
        }
    });
    
    // Handle escape key for mobile menu
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeMobileSidebar();
            document.getElementById('userMenu')?.classList.remove('open');
        }
    });
    
    // Handle swipe to close sidebar
    (function() {
        let touchStartX = 0;
        let touchEndX = 0;
        const sidebar = document.getElementById('sidebar');
        
        if (!sidebar) return;
        
        sidebar.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        sidebar.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            if (touchStartX - touchEndX > 50) {
                closeMobileSidebar();
            }
        }, { passive: true });
    })();
    
    // Hide/show bottom nav on scroll
    (function() {
        let lastScroll = 0;
        const bottomNav = document.getElementById('bottomNav');
        if (!bottomNav) return;
        
        window.addEventListener('scroll', function() {
            const currentScroll = window.pageYOffset;
            
            if (currentScroll > lastScroll && currentScroll > 100) {
                bottomNav.style.transform = 'translateY(100%)';
            } else {
                bottomNav.style.transform = 'translateY(0)';
            }
            
            lastScroll = currentScroll;
        }, { passive: true });
    })();
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>
