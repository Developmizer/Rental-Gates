<?php
/**
 * Staff Portal Layout
 */
if (!defined('ABSPATH')) exit;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

// Get staff's organization membership
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$membership = $wpdb->get_row($wpdb->prepare(
    "SELECT om.*, o.name as organization_name, o.logo, o.contact_email, o.contact_phone
     FROM {$tables['organization_members']} om
     JOIN {$tables['organizations']} o ON om.organization_id = o.id
     WHERE om.user_id = %d AND om.status = 'active'
     ORDER BY om.created_at DESC
     LIMIT 1",
    $user_id
), ARRAY_A);

if (!$membership) {
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php _e('Staff Portal', 'rental-gates'); ?></title>
        <?php wp_head(); ?>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f3f4f6; margin: 0; padding: 40px 20px; }
            .error-box { max-width: 500px; margin: 0 auto; background: #fff; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .error-box h1 { color: #1f2937; margin: 0 0 16px; }
            .error-box p { color: #6b7280; margin: 0 0 24px; }
            .error-box a { display: inline-block; padding: 12px 24px; background: #3b82f6; color: #fff; border-radius: 8px; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="error-box">
            <h1><?php _e('Staff Account Not Found', 'rental-gates'); ?></h1>
            <p><?php _e('Your account is not linked to any organization. Please contact your property manager.', 'rental-gates'); ?></p>
            <a href="<?php echo wp_logout_url(home_url('/rental-gates/login')); ?>"><?php _e('Sign Out', 'rental-gates'); ?></a>
        </div>
        <?php wp_footer(); ?>
    </body>
    </html>
    <?php
    exit;
}

$org_id = intval($membership['organization_id']);
$org_name = $membership['organization_name'];

// Get staff permissions
$permissions = Rental_Gates_Roles::get_staff_permissions($user_id, $org_id);

// Get current page section
$current_page = '';
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/rental-gates/staff/([^?/]+)#', $uri, $matches)) {
        $current_page = $matches[1];
    }
}
if (empty($current_page)) {
    $current_page = 'dashboard';
}

// Build navigation based on permissions
$nav_items = array();

// Dashboard always visible
$nav_items['dashboard'] = array(
    'label' => __('Dashboard', 'rental-gates'),
    'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>'
);

// Check each module permission
$module_nav = array(
    'buildings' => array(
        'label' => __('Buildings', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>'
    ),
    'tenants' => array(
        'label' => __('Tenants', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>'
    ),
    'leases' => array(
        'label' => __('Leases', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>'
    ),
    'applications' => array(
        'label' => __('Applications', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>'
    ),
    'maintenance' => array(
        'label' => __('Maintenance', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>'
    ),
    'payments' => array(
        'label' => __('Payments', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>'
    ),
    'vendors' => array(
        'label' => __('Vendors', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>'
    ),
    'leads' => array(
        'label' => __('Leads', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>'
    ),
);

// Add nav items based on permissions
foreach ($module_nav as $module => $item) {
    $perm = $permissions[$module] ?? 'none';
    if ($perm !== 'none') {
        $nav_items[$module] = $item;
        $nav_items[$module]['permission'] = $perm;
    }
}

// Profile always at the end
$nav_items['profile'] = array(
    'label' => __('Profile', 'rental-gates'),
    'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>'
);

// Check if user can access current page
$can_access = true;
if ($current_page !== 'dashboard' && $current_page !== 'profile') {
    $perm = $permissions[$current_page] ?? 'none';
    if ($perm === 'none') {
        $can_access = false;
    }
}

// Get unread notifications
$unread_notifications = Rental_Gates_Notification::get_unread_count($user_id);

// Get logo
$logo_url = '';
if (!empty($membership['logo'])) {
    $logo_url = wp_get_attachment_url($membership['logo']);
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php _e('Staff Portal', 'rental-gates'); ?> - <?php echo esc_html($org_name); ?></title>
    <?php wp_head(); ?>
    <style>
        :root {
            --primary: #0ea5e9;
            --primary-dark: #0284c7;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background: var(--gray-100); color: var(--gray-800); }
        
        .rg-staff-layout { display: flex; min-height: 100vh; }
        
        /* Sidebar */
        .rg-sidebar { width: 260px; background: linear-gradient(180deg, #0c4a6e 0%, #075985 100%); display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 100; transition: transform 0.3s; }
        .rg-sidebar-header { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .rg-sidebar-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
        .rg-sidebar-logo img { height: 40px; width: auto; border-radius: 8px; }
        .rg-sidebar-logo-text { color: #fff; font-size: 18px; font-weight: 700; }
        .rg-sidebar-org { color: rgba(255,255,255,0.7); font-size: 12px; margin-top: 8px; }
        
        .rg-sidebar-nav { flex: 1; overflow-y: auto; padding: 16px 12px; }
        .rg-nav-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 8px; margin-bottom: 4px; transition: all 0.2s; font-size: 14px; }
        .rg-nav-item:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .rg-nav-item.active { background: rgba(255,255,255,0.15); color: #fff; font-weight: 500; }
        .rg-nav-item svg { width: 20px; height: 20px; flex-shrink: 0; }
        .rg-nav-badge { margin-left: auto; background: #ef4444; color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 10px; }
        .rg-nav-perm { margin-left: auto; font-size: 10px; padding: 2px 6px; border-radius: 4px; background: rgba(255,255,255,0.2); color: rgba(255,255,255,0.8); text-transform: uppercase; }
        
        .rg-sidebar-footer { padding: 16px; border-top: 1px solid rgba(255,255,255,0.1); }
        .rg-user-info { display: flex; align-items: center; gap: 12px; padding: 8px; }
        .rg-user-avatar { width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; }
        .rg-user-details { flex: 1; min-width: 0; }
        .rg-user-name { color: #fff; font-size: 14px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .rg-user-role { color: rgba(255,255,255,0.6); font-size: 12px; }
        .rg-logout-btn { display: block; width: 100%; padding: 10px; background: rgba(255,255,255,0.1); border: none; border-radius: 6px; color: rgba(255,255,255,0.8); font-size: 13px; cursor: pointer; margin-top: 12px; transition: background 0.2s; text-align: center; text-decoration: none; }
        .rg-logout-btn:hover { background: rgba(255,255,255,0.2); color: #fff; }
        
        /* Main Content */
        .rg-main { flex: 1; margin-left: 260px; display: flex; flex-direction: column; min-height: 100vh; }
        
        .rg-header { background: #fff; padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--gray-200); position: sticky; top: 0; z-index: 50; }
        .rg-header-left { display: flex; align-items: center; gap: 16px; }
        .rg-mobile-toggle { display: none; background: none; border: none; cursor: pointer; padding: 8px; border-radius: 6px; }
        .rg-mobile-toggle:hover { background: var(--gray-100); }
        .rg-header-title { font-size: 20px; font-weight: 600; color: var(--gray-900); }
        
        .rg-header-right { display: flex; align-items: center; gap: 12px; }
        .rg-header-btn { position: relative; width: 40px; height: 40px; border-radius: 8px; border: 1px solid var(--gray-200); background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--gray-600); text-decoration: none; }
        .rg-header-btn:hover { background: var(--gray-50); color: var(--gray-900); }
        .rg-notification-dot { position: absolute; top: 6px; right: 6px; width: 8px; height: 8px; background: #ef4444; border-radius: 50%; }
        
        .rg-content { flex: 1; padding: 24px; }
        
        /* Access Denied */
        .rg-access-denied { max-width: 500px; margin: 60px auto; background: #fff; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .rg-access-denied svg { color: #ef4444; margin-bottom: 16px; }
        .rg-access-denied h2 { color: var(--gray-900); margin-bottom: 8px; }
        .rg-access-denied p { color: var(--gray-600); margin-bottom: 24px; }
        .rg-access-denied a { display: inline-block; padding: 10px 20px; background: var(--primary); color: #fff; border-radius: 8px; text-decoration: none; }
        
        /* Mobile */
        @media (max-width: 1024px) {
            .rg-sidebar { transform: translateX(-100%); }
            .rg-sidebar.open { transform: translateX(0); }
            .rg-main { margin-left: 0; }
            .rg-mobile-toggle { display: block; }
            .rg-sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 99; }
            .rg-sidebar.open + .rg-sidebar-overlay { display: block; }
        }
        
        @media (max-width: 640px) {
            .rg-content { padding: 16px; }
            .rg-header { padding: 12px 16px; }
        }
    </style>
</head>
<body>
    <div class="rg-staff-layout">
        <!-- Sidebar -->
        <aside class="rg-sidebar" id="sidebar">
            <div class="rg-sidebar-header">
                <a href="<?php echo home_url('/rental-gates/staff'); ?>" class="rg-sidebar-logo">
                    <?php if ($logo_url): ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="">
                    <?php else: ?>
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none"><rect width="40" height="40" rx="8" fill="#fff"/><path d="M12 28V16l8-6 8 6v12H12z" stroke="#0ea5e9" stroke-width="2"/><rect x="17" y="22" width="6" height="6" stroke="#0ea5e9" stroke-width="2"/></svg>
                    <?php endif; ?>
                    <span class="rg-sidebar-logo-text"><?php _e('Staff Portal', 'rental-gates'); ?></span>
                </a>
                <div class="rg-sidebar-org"><?php echo esc_html($org_name); ?></div>
            </div>
            
            <nav class="rg-sidebar-nav">
                <?php foreach ($nav_items as $key => $item): ?>
                <a href="<?php echo home_url('/rental-gates/staff/' . ($key === 'dashboard' ? '' : $key)); ?>" 
                   class="rg-nav-item <?php echo $current_page === $key ? 'active' : ''; ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><?php echo $item['icon']; ?></svg>
                    <?php echo esc_html($item['label']); ?>
                    <?php if (isset($item['permission']) && $item['permission'] === 'view'): ?>
                        <span class="rg-nav-perm"><?php _e('View', 'rental-gates'); ?></span>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </nav>
            
            <div class="rg-sidebar-footer">
                <div class="rg-user-info">
                    <div class="rg-user-avatar"><?php echo strtoupper(substr($current_user->display_name, 0, 1)); ?></div>
                    <div class="rg-user-details">
                        <div class="rg-user-name"><?php echo esc_html($current_user->display_name); ?></div>
                        <div class="rg-user-role"><?php _e('Staff Member', 'rental-gates'); ?></div>
                    </div>
                </div>
                <a href="<?php echo wp_logout_url(home_url('/rental-gates/login')); ?>" class="rg-logout-btn">
                    <?php _e('Sign Out', 'rental-gates'); ?>
                </a>
            </div>
        </aside>
        <div class="rg-sidebar-overlay" onclick="document.getElementById('sidebar').classList.remove('open')"></div>
        
        <!-- Main Content -->
        <main class="rg-main">
            <header class="rg-header">
                <div class="rg-header-left">
                    <button class="rg-mobile-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
                    </button>
                    <h1 class="rg-header-title">
                        <?php 
                        $titles = array(
                            'dashboard' => __('Dashboard', 'rental-gates'),
                            'buildings' => __('Buildings', 'rental-gates'),
                            'tenants' => __('Tenants', 'rental-gates'),
                            'leases' => __('Leases', 'rental-gates'),
                            'applications' => __('Applications', 'rental-gates'),
                            'maintenance' => __('Maintenance', 'rental-gates'),
                            'payments' => __('Payments', 'rental-gates'),
                            'vendors' => __('Vendors', 'rental-gates'),
                            'leads' => __('Leads', 'rental-gates'),
                            'profile' => __('My Profile', 'rental-gates'),
                        );
                        echo esc_html($titles[$current_page] ?? ucfirst($current_page));
                        ?>
                    </h1>
                </div>
                
                <div class="rg-header-right">
                    <a href="<?php echo home_url('/rental-gates/staff/notifications'); ?>" class="rg-header-btn" title="<?php _e('Notifications', 'rental-gates'); ?>">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                        <?php if ($unread_notifications > 0): ?>
                        <span class="rg-notification-dot"></span>
                        <?php endif; ?>
                    </a>
                </div>
            </header>
            
            <div class="rg-content">
                <?php if (!$can_access): ?>
                <div class="rg-access-denied">
                    <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                    <h2><?php _e('Access Denied', 'rental-gates'); ?></h2>
                    <p><?php _e('You do not have permission to access this section. Contact your property manager if you need access.', 'rental-gates'); ?></p>
                    <a href="<?php echo home_url('/rental-gates/staff'); ?>"><?php _e('Go to Dashboard', 'rental-gates'); ?></a>
                </div>
                <?php else:
                    // Load section content
                    $section_file = RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/staff/sections/' . $current_page . '.php';
                    if (file_exists($section_file)) {
                        include $section_file;
                    } else {
                        echo '<div class="rg-access-denied"><h2>' . __('Page Not Found', 'rental-gates') . '</h2><p>' . __('This page is under construction.', 'rental-gates') . '</p></div>';
                    }
                endif; ?>
            </div>
        </main>
    </div>
    
    <?php wp_footer(); ?>
</body>
</html>
