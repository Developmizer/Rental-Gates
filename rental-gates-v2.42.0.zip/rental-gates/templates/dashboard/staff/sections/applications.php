<?php
/**
 * Staff Applications Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['applications'] ?? 'view';
$can_edit = $perm_level === 'full';

// Filters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'pending';

// Build query
$where = "WHERE a.organization_id = %d";
$params = array($org_id);

if ($status_filter && $status_filter !== 'all') {
    $where .= " AND a.status = %s";
    $params[] = $status_filter;
}

$applications = $wpdb->get_results($wpdb->prepare(
    "SELECT a.*, u.name as unit_name, b.name as building_name, u.rent as unit_rent
     FROM {$tables['applications']} a
     JOIN {$tables['units']} u ON a.unit_id = u.id
     JOIN {$tables['buildings']} b ON u.building_id = b.id
     {$where}
     ORDER BY a.created_at DESC",
    ...$params
), ARRAY_A);

// Stats
$app_stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'in_review' THEN 1 END) as in_review,
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
        COUNT(CASE WHEN status = 'declined' THEN 1 END) as declined
     FROM {$tables['applications']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-apps-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 16px; }
    
    .rg-filter-tabs { display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: 8px; }
    .rg-filter-tab { padding: 8px 14px; border-radius: 6px; font-size: 13px; text-decoration: none; color: var(--gray-600); transition: all 0.2s; }
    .rg-filter-tab:hover { color: var(--gray-900); }
    .rg-filter-tab.active { background: #fff; color: var(--gray-900); box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    .rg-filter-count { margin-left: 6px; padding: 2px 6px; background: var(--gray-200); border-radius: 10px; font-size: 11px; }
    
    .rg-apps-table { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-apps-table table { width: 100%; border-collapse: collapse; }
    .rg-apps-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; border-bottom: 1px solid var(--gray-200); }
    .rg-apps-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-apps-table tr:last-child td { border-bottom: none; }
    .rg-apps-table tr:hover { background: var(--gray-50); }
    
    .rg-applicant-info { display: flex; align-items: center; gap: 12px; }
    .rg-applicant-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--gray-200); display: flex; align-items: center; justify-content: center; color: var(--gray-600); font-weight: 600; font-size: 14px; }
    .rg-applicant-name { font-weight: 500; color: var(--gray-900); margin-bottom: 2px; }
    .rg-applicant-email { font-size: 12px; color: var(--gray-500); }
    
    .rg-badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .rg-badge-pending { background: #fef3c7; color: #b45309; }
    .rg-badge-in_review { background: #dbeafe; color: #1d4ed8; }
    .rg-badge-approved { background: #dcfce7; color: #16a34a; }
    .rg-badge-declined { background: #fef2f2; color: #dc2626; }
    
    .rg-action-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; display: inline-flex; align-items: center; gap: 4px; }
    .rg-action-btn-primary { background: var(--primary); color: #fff; }
    .rg-action-btn-success { background: #16a34a; color: #fff; }
    .rg-action-btn-danger { background: #dc2626; color: #fff; }
    
    .rg-empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
    
    .rg-unit-info { font-size: 14px; color: var(--gray-900); }
    .rg-unit-building { font-size: 12px; color: var(--gray-500); }
</style>

<!-- Filters -->
<div class="rg-apps-header">
    <div class="rg-filter-tabs">
        <a href="?status=pending" class="rg-filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>">
            <?php _e('Pending', 'rental-gates'); ?>
            <span class="rg-filter-count"><?php echo $app_stats['pending']; ?></span>
        </a>
        <a href="?status=in_review" class="rg-filter-tab <?php echo $status_filter === 'in_review' ? 'active' : ''; ?>">
            <?php _e('In Review', 'rental-gates'); ?>
            <span class="rg-filter-count"><?php echo $app_stats['in_review']; ?></span>
        </a>
        <a href="?status=approved" class="rg-filter-tab <?php echo $status_filter === 'approved' ? 'active' : ''; ?>">
            <?php _e('Approved', 'rental-gates'); ?>
        </a>
        <a href="?status=declined" class="rg-filter-tab <?php echo $status_filter === 'declined' ? 'active' : ''; ?>">
            <?php _e('Declined', 'rental-gates'); ?>
        </a>
        <a href="?status=all" class="rg-filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
            <?php _e('All', 'rental-gates'); ?>
        </a>
    </div>
</div>

<!-- Table -->
<div class="rg-apps-table">
    <?php if (empty($applications)): ?>
    <div class="rg-empty">
        <p><?php _e('No applications found', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th><?php _e('Applicant', 'rental-gates'); ?></th>
                <th><?php _e('Unit', 'rental-gates'); ?></th>
                <th><?php _e('Desired Move-In', 'rental-gates'); ?></th>
                <th><?php _e('Status', 'rental-gates'); ?></th>
                <th><?php _e('Applied', 'rental-gates'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($applications as $app): 
                $initials = strtoupper(substr($app['first_name'], 0, 1) . substr($app['last_name'], 0, 1));
            ?>
            <tr>
                <td>
                    <div class="rg-applicant-info">
                        <div class="rg-applicant-avatar"><?php echo $initials; ?></div>
                        <div>
                            <div class="rg-applicant-name"><?php echo esc_html($app['first_name'] . ' ' . $app['last_name']); ?></div>
                            <div class="rg-applicant-email"><?php echo esc_html($app['email']); ?></div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="rg-unit-info"><?php echo esc_html($app['unit_name']); ?></div>
                    <div class="rg-unit-building"><?php echo esc_html($app['building_name']); ?> · $<?php echo number_format($app['unit_rent']); ?>/mo</div>
                </td>
                <td>
                    <?php echo $app['desired_move_in'] ? date('M j, Y', strtotime($app['desired_move_in'])) : '—'; ?>
                </td>
                <td>
                    <span class="rg-badge rg-badge-<?php echo esc_attr($app['status']); ?>">
                        <?php echo esc_html(ucwords(str_replace('_', ' ', $app['status']))); ?>
                    </span>
                </td>
                <td style="color: var(--gray-500); font-size: 13px;">
                    <?php echo date('M j, Y', strtotime($app['created_at'])); ?>
                </td>
                <td style="text-align: right;">
                    <a href="<?php echo home_url('/rental-gates/staff/applications/' . $app['id']); ?>" class="rg-action-btn rg-action-btn-primary">
                        <?php _e('View', 'rental-gates'); ?>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
