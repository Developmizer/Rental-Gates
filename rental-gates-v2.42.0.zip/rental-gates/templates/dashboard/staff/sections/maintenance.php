<?php
/**
 * Staff Maintenance Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['maintenance'] ?? 'view';
$can_edit = $perm_level === 'full';

// Handle status update
if ($can_edit && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status']) && wp_verify_nonce($_POST['_wpnonce'], 'update_maintenance_status')) {
    $work_order_id = intval($_POST['work_order_id']);
    $new_status = sanitize_text_field($_POST['new_status']);
    
    $valid_statuses = array('new', 'assigned', 'in_progress', 'completed', 'cancelled');
    if (in_array($new_status, $valid_statuses)) {
        $wpdb->update(
            $tables['work_orders'],
            array('status' => $new_status, 'updated_at' => current_time('mysql')),
            array('id' => $work_order_id, 'organization_id' => $org_id)
        );
        
        // Add note
        if (!empty($_POST['status_note'])) {
            Rental_Gates_Maintenance::add_note($work_order_id, $user_id, 'staff', sanitize_textarea_field($_POST['status_note']), false);
        }
    }
}

// Filters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'open';
$priority_filter = isset($_GET['priority']) ? sanitize_text_field($_GET['priority']) : '';

// Build query
$where = "WHERE w.organization_id = %d";
$params = array($org_id);

if ($status_filter === 'open') {
    $where .= " AND w.status IN ('new', 'assigned', 'in_progress')";
} elseif ($status_filter === 'completed') {
    $where .= " AND w.status = 'completed'";
} elseif ($status_filter && $status_filter !== 'all') {
    $where .= " AND w.status = %s";
    $params[] = $status_filter;
}

if ($priority_filter) {
    $where .= " AND w.priority = %s";
    $params[] = $priority_filter;
}

$work_orders = $wpdb->get_results($wpdb->prepare(
    "SELECT w.*, u.name as unit_name, b.name as building_name,
            t.first_name, t.last_name, t.phone as tenant_phone,
            v.company_name as vendor_name
     FROM {$tables['work_orders']} w
     LEFT JOIN {$tables['units']} u ON w.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     LEFT JOIN {$tables['tenants']} t ON w.tenant_id = t.id
     LEFT JOIN {$tables['vendors']} v ON w.vendor_id = v.id
     {$where}
     ORDER BY 
        CASE w.priority WHEN 'emergency' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 WHEN 'low' THEN 4 END,
        w.created_at DESC",
    ...$params
), ARRAY_A);

// Stats
$stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(CASE WHEN status = 'new' THEN 1 END) as new_count,
        COUNT(CASE WHEN status = 'assigned' THEN 1 END) as assigned_count,
        COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress_count,
        COUNT(CASE WHEN status = 'completed' AND completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as completed_month
     FROM {$tables['work_orders']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-maint-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 16px; }
    .rg-filter-bar { display: flex; gap: 12px; flex-wrap: wrap; }
    .rg-filter-btn { padding: 8px 16px; border-radius: 8px; font-size: 13px; text-decoration: none; color: var(--gray-600); background: #fff; border: 1px solid var(--gray-200); transition: all 0.2s; }
    .rg-filter-btn:hover { background: var(--gray-50); }
    .rg-filter-btn.active { background: var(--primary); color: #fff; border-color: var(--primary); }
    
    .rg-stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
    @media (max-width: 768px) { .rg-stats-row { grid-template-columns: repeat(2, 1fr); } }
    .rg-mini-stat { background: #fff; border-radius: 10px; padding: 16px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-mini-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-mini-stat-label { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    
    .rg-maint-table { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-maint-table table { width: 100%; border-collapse: collapse; }
    .rg-maint-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; border-bottom: 1px solid var(--gray-200); }
    .rg-maint-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-maint-table tr:last-child td { border-bottom: none; }
    .rg-maint-table tr:hover { background: var(--gray-50); }
    
    .rg-badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .rg-badge-new { background: #dbeafe; color: #1d4ed8; }
    .rg-badge-assigned { background: #fef3c7; color: #b45309; }
    .rg-badge-in_progress { background: #f3e8ff; color: #7c3aed; }
    .rg-badge-completed { background: #dcfce7; color: #16a34a; }
    .rg-badge-cancelled { background: #f3f4f6; color: #6b7280; }
    
    .rg-priority { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; }
    .rg-priority-emergency { background: #fef2f2; color: #dc2626; }
    .rg-priority-high { background: #fef3c7; color: #d97706; }
    .rg-priority-normal { background: #f3f4f6; color: #6b7280; }
    .rg-priority-low { background: #f0fdf4; color: #16a34a; }
    
    .rg-maint-title { font-weight: 500; color: var(--gray-900); margin-bottom: 2px; }
    .rg-maint-meta { font-size: 12px; color: var(--gray-500); }
    
    .rg-action-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; background: var(--primary); color: #fff; display: inline-block; }
    .rg-action-btn:hover { background: var(--primary-dark); }
    
    .rg-status-select { padding: 6px 10px; border: 1px solid var(--gray-300); border-radius: 6px; font-size: 12px; background: #fff; cursor: pointer; }
    
    .rg-empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
    
    /* Modal */
    .rg-modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .rg-modal-overlay.active { display: flex; }
    .rg-modal { background: #fff; border-radius: 12px; width: 100%; max-width: 500px; margin: 20px; }
    .rg-modal-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .rg-modal-title { font-size: 18px; font-weight: 600; color: var(--gray-900); }
    .rg-modal-close { background: none; border: none; cursor: pointer; color: var(--gray-400); padding: 4px; }
    .rg-modal-body { padding: 20px; }
    .rg-modal-footer { padding: 16px 20px; border-top: 1px solid var(--gray-200); display: flex; justify-content: flex-end; gap: 12px; }
    
    .rg-form-group { margin-bottom: 16px; }
    .rg-form-label { display: block; font-size: 13px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .rg-form-control { width: 100%; padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.1); }
    
    .rg-btn { padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-secondary { background: var(--gray-100); color: var(--gray-700); }
</style>

<!-- Stats -->
<div class="rg-stats-row">
    <div class="rg-mini-stat">
        <div class="rg-mini-stat-value" style="color: #1d4ed8;"><?php echo $stats['new_count']; ?></div>
        <div class="rg-mini-stat-label"><?php _e('New', 'rental-gates'); ?></div>
    </div>
    <div class="rg-mini-stat">
        <div class="rg-mini-stat-value" style="color: #b45309;"><?php echo $stats['assigned_count']; ?></div>
        <div class="rg-mini-stat-label"><?php _e('Assigned', 'rental-gates'); ?></div>
    </div>
    <div class="rg-mini-stat">
        <div class="rg-mini-stat-value" style="color: #7c3aed;"><?php echo $stats['in_progress_count']; ?></div>
        <div class="rg-mini-stat-label"><?php _e('In Progress', 'rental-gates'); ?></div>
    </div>
    <div class="rg-mini-stat">
        <div class="rg-mini-stat-value" style="color: #16a34a;"><?php echo $stats['completed_month']; ?></div>
        <div class="rg-mini-stat-label"><?php _e('Completed (30d)', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<div class="rg-maint-header">
    <div class="rg-filter-bar">
        <a href="?status=open" class="rg-filter-btn <?php echo $status_filter === 'open' ? 'active' : ''; ?>"><?php _e('Open', 'rental-gates'); ?></a>
        <a href="?status=new" class="rg-filter-btn <?php echo $status_filter === 'new' ? 'active' : ''; ?>"><?php _e('New', 'rental-gates'); ?></a>
        <a href="?status=assigned" class="rg-filter-btn <?php echo $status_filter === 'assigned' ? 'active' : ''; ?>"><?php _e('Assigned', 'rental-gates'); ?></a>
        <a href="?status=in_progress" class="rg-filter-btn <?php echo $status_filter === 'in_progress' ? 'active' : ''; ?>"><?php _e('In Progress', 'rental-gates'); ?></a>
        <a href="?status=completed" class="rg-filter-btn <?php echo $status_filter === 'completed' ? 'active' : ''; ?>"><?php _e('Completed', 'rental-gates'); ?></a>
        <a href="?status=all" class="rg-filter-btn <?php echo $status_filter === 'all' ? 'active' : ''; ?>"><?php _e('All', 'rental-gates'); ?></a>
    </div>
</div>

<!-- Table -->
<div class="rg-maint-table">
    <?php if (empty($work_orders)): ?>
    <div class="rg-empty">
        <p><?php _e('No maintenance requests found', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th><?php _e('Request', 'rental-gates'); ?></th>
                <th><?php _e('Location', 'rental-gates'); ?></th>
                <th><?php _e('Priority', 'rental-gates'); ?></th>
                <th><?php _e('Status', 'rental-gates'); ?></th>
                <th><?php _e('Vendor', 'rental-gates'); ?></th>
                <th><?php _e('Date', 'rental-gates'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($work_orders as $wo): ?>
            <tr>
                <td>
                    <div class="rg-maint-title"><?php echo esc_html($wo['title']); ?></div>
                    <div class="rg-maint-meta"><?php echo esc_html(ucfirst($wo['category'])); ?></div>
                </td>
                <td>
                    <div class="rg-maint-title"><?php echo esc_html($wo['unit_name']); ?></div>
                    <div class="rg-maint-meta"><?php echo esc_html($wo['building_name']); ?></div>
                </td>
                <td>
                    <span class="rg-priority rg-priority-<?php echo esc_attr($wo['priority']); ?>">
                        <?php echo esc_html(ucfirst($wo['priority'])); ?>
                    </span>
                </td>
                <td>
                    <?php if ($can_edit && !in_array($wo['status'], array('completed', 'cancelled'))): ?>
                    <select class="rg-status-select" onchange="openStatusModal(<?php echo $wo['id']; ?>, this.value, '<?php echo esc_js($wo['title']); ?>')">
                        <option value="new" <?php selected($wo['status'], 'new'); ?>><?php _e('New', 'rental-gates'); ?></option>
                        <option value="assigned" <?php selected($wo['status'], 'assigned'); ?>><?php _e('Assigned', 'rental-gates'); ?></option>
                        <option value="in_progress" <?php selected($wo['status'], 'in_progress'); ?>><?php _e('In Progress', 'rental-gates'); ?></option>
                        <option value="completed" <?php selected($wo['status'], 'completed'); ?>><?php _e('Completed', 'rental-gates'); ?></option>
                    </select>
                    <?php else: ?>
                    <span class="rg-badge rg-badge-<?php echo esc_attr($wo['status']); ?>">
                        <?php echo esc_html(ucwords(str_replace('_', ' ', $wo['status']))); ?>
                    </span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($wo['vendor_name']): ?>
                        <?php echo esc_html($wo['vendor_name']); ?>
                    <?php else: ?>
                        <span style="color: var(--gray-400);">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="rg-maint-meta"><?php echo date('M j, Y', strtotime($wo['created_at'])); ?></div>
                </td>
                <td>
                    <a href="<?php echo home_url('/rental-gates/staff/maintenance/' . $wo['id']); ?>" class="rg-action-btn"><?php _e('View', 'rental-gates'); ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<!-- Status Update Modal -->
<?php if ($can_edit): ?>
<div class="rg-modal-overlay" id="statusModal">
    <div class="rg-modal">
        <div class="rg-modal-header">
            <h3 class="rg-modal-title"><?php _e('Update Status', 'rental-gates'); ?></h3>
            <button class="rg-modal-close" onclick="closeStatusModal()">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <form method="post">
            <?php wp_nonce_field('update_maintenance_status'); ?>
            <input type="hidden" name="update_status" value="1">
            <input type="hidden" name="work_order_id" id="modalWorkOrderId">
            <input type="hidden" name="new_status" id="modalNewStatus">
            
            <div class="rg-modal-body">
                <p id="modalMessage"></p>
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Add Note (optional)', 'rental-gates'); ?></label>
                    <textarea name="status_note" class="rg-form-control" rows="3" placeholder="<?php _e('Add any notes about this status change...', 'rental-gates'); ?>"></textarea>
                </div>
            </div>
            
            <div class="rg-modal-footer">
                <button type="button" class="rg-btn rg-btn-secondary" onclick="closeStatusModal()"><?php _e('Cancel', 'rental-gates'); ?></button>
                <button type="submit" class="rg-btn rg-btn-primary"><?php _e('Update Status', 'rental-gates'); ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function openStatusModal(id, status, title) {
    document.getElementById('modalWorkOrderId').value = id;
    document.getElementById('modalNewStatus').value = status;
    document.getElementById('modalMessage').textContent = 'Update "' + title + '" to ' + status.replace('_', ' ') + '?';
    document.getElementById('statusModal').classList.add('active');
}

function closeStatusModal() {
    document.getElementById('statusModal').classList.remove('active');
    // Reset select to original value
    location.reload();
}

document.getElementById('statusModal').addEventListener('click', function(e) {
    if (e.target === this) closeStatusModal();
});
</script>
<?php endif; ?>
