<?php
/**
 * Staff Tenants Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['tenants'] ?? 'view';
$can_edit = $perm_level === 'full';

// Search and filters
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'active';

// Build query
$where = "WHERE t.organization_id = %d";
$params = array($org_id);

if ($status_filter && $status_filter !== 'all') {
    $where .= " AND t.status = %s";
    $params[] = $status_filter;
}

if ($search) {
    $where .= " AND (t.first_name LIKE %s OR t.last_name LIKE %s OR t.email LIKE %s OR t.phone LIKE %s)";
    $search_like = '%' . $wpdb->esc_like($search) . '%';
    $params = array_merge($params, array($search_like, $search_like, $search_like, $search_like));
}

$tenants = $wpdb->get_results($wpdb->prepare(
    "SELECT t.*, 
            l.id as lease_id, l.start_date, l.end_date, l.rent_amount,
            u.name as unit_name, b.name as building_name
     FROM {$tables['tenants']} t
     LEFT JOIN {$tables['lease_tenants']} lt ON t.id = lt.tenant_id AND lt.removed_at IS NULL
     LEFT JOIN {$tables['leases']} l ON lt.lease_id = l.id AND l.status = 'active'
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     {$where}
     GROUP BY t.id
     ORDER BY t.last_name, t.first_name ASC",
    ...$params
), ARRAY_A);

// Stats
$tenant_stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
        COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending
     FROM {$tables['tenants']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-tenants-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 16px; }
    
    .rg-search-form { display: flex; gap: 12px; flex-wrap: wrap; }
    .rg-search-input { padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; width: 250px; }
    .rg-search-input:focus { outline: none; border-color: var(--primary); }
    .rg-search-btn { padding: 10px 16px; background: var(--primary); color: #fff; border: none; border-radius: 8px; cursor: pointer; }
    
    .rg-filter-tabs { display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: 8px; }
    .rg-filter-tab { padding: 8px 14px; border-radius: 6px; font-size: 13px; text-decoration: none; color: var(--gray-600); transition: all 0.2s; }
    .rg-filter-tab:hover { color: var(--gray-900); }
    .rg-filter-tab.active { background: #fff; color: var(--gray-900); box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    
    .rg-stats-mini { display: flex; gap: 16px; margin-bottom: 20px; }
    .rg-stat-mini { background: #fff; border-radius: 8px; padding: 12px 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 12px; }
    .rg-stat-mini-value { font-size: 20px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-mini-label { font-size: 12px; color: var(--gray-500); }
    
    .rg-tenants-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 16px; }
    
    .rg-tenant-card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-tenant-header { display: flex; align-items: center; gap: 14px; padding: 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-tenant-avatar { width: 50px; height: 50px; border-radius: 50%; background: var(--primary); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600; flex-shrink: 0; }
    .rg-tenant-info { flex: 1; min-width: 0; }
    .rg-tenant-name { font-size: 16px; font-weight: 600; color: var(--gray-900); margin-bottom: 2px; }
    .rg-tenant-status { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; text-transform: uppercase; }
    .rg-tenant-status.active { background: #dcfce7; color: #16a34a; }
    .rg-tenant-status.inactive { background: #f3f4f6; color: #6b7280; }
    .rg-tenant-status.pending { background: #fef3c7; color: #d97706; }
    
    .rg-tenant-body { padding: 16px; }
    .rg-tenant-detail { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; font-size: 13px; color: var(--gray-600); }
    .rg-tenant-detail:last-child { margin-bottom: 0; }
    .rg-tenant-detail svg { width: 16px; height: 16px; color: var(--gray-400); flex-shrink: 0; }
    .rg-tenant-detail a { color: var(--primary); text-decoration: none; }
    
    .rg-tenant-lease { background: var(--gray-50); border-radius: 8px; padding: 12px; margin-top: 12px; }
    .rg-tenant-lease-title { font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; margin-bottom: 6px; }
    .rg-tenant-lease-unit { font-size: 14px; font-weight: 500; color: var(--gray-900); margin-bottom: 4px; }
    .rg-tenant-lease-dates { font-size: 12px; color: var(--gray-500); }
    
    .rg-tenant-footer { display: flex; gap: 8px; padding: 12px 16px; background: var(--gray-50); border-top: 1px solid var(--gray-100); }
    .rg-tenant-btn { flex: 1; padding: 8px; border-radius: 6px; font-size: 12px; text-align: center; text-decoration: none; transition: all 0.2s; }
    .rg-tenant-btn-primary { background: var(--primary); color: #fff; }
    .rg-tenant-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; background: #fff; border-radius: 12px; }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
</style>

<!-- Stats -->
<div class="rg-stats-mini">
    <div class="rg-stat-mini">
        <div>
            <div class="rg-stat-mini-value"><?php echo $tenant_stats['total']; ?></div>
            <div class="rg-stat-mini-label"><?php _e('Total Tenants', 'rental-gates'); ?></div>
        </div>
    </div>
    <div class="rg-stat-mini">
        <div>
            <div class="rg-stat-mini-value" style="color: #16a34a;"><?php echo $tenant_stats['active']; ?></div>
            <div class="rg-stat-mini-label"><?php _e('Active', 'rental-gates'); ?></div>
        </div>
    </div>
    <div class="rg-stat-mini">
        <div>
            <div class="rg-stat-mini-value" style="color: #d97706;"><?php echo $tenant_stats['pending']; ?></div>
            <div class="rg-stat-mini-label"><?php _e('Pending', 'rental-gates'); ?></div>
        </div>
    </div>
</div>

<!-- Header -->
<div class="rg-tenants-header">
    <form method="get" class="rg-search-form">
        <input type="hidden" name="status" value="<?php echo esc_attr($status_filter); ?>">
        <input type="text" name="search" class="rg-search-input" placeholder="<?php _e('Search by name, email, phone...', 'rental-gates'); ?>" value="<?php echo esc_attr($search); ?>">
        <button type="submit" class="rg-search-btn"><?php _e('Search', 'rental-gates'); ?></button>
    </form>
    
    <div class="rg-filter-tabs">
        <a href="?status=active" class="rg-filter-tab <?php echo $status_filter === 'active' ? 'active' : ''; ?>"><?php _e('Active', 'rental-gates'); ?></a>
        <a href="?status=pending" class="rg-filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>"><?php _e('Pending', 'rental-gates'); ?></a>
        <a href="?status=inactive" class="rg-filter-tab <?php echo $status_filter === 'inactive' ? 'active' : ''; ?>"><?php _e('Inactive', 'rental-gates'); ?></a>
        <a href="?status=all" class="rg-filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>"><?php _e('All', 'rental-gates'); ?></a>
    </div>
</div>

<!-- Tenants Grid -->
<?php if (empty($tenants)): ?>
<div class="rg-empty-state">
    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
    <h3><?php _e('No Tenants Found', 'rental-gates'); ?></h3>
    <p><?php _e('No tenants match your search criteria.', 'rental-gates'); ?></p>
</div>
<?php else: ?>
<div class="rg-tenants-grid">
    <?php foreach ($tenants as $tenant): 
        $initials = strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1));
    ?>
    <div class="rg-tenant-card">
        <div class="rg-tenant-header">
            <div class="rg-tenant-avatar"><?php echo $initials; ?></div>
            <div class="rg-tenant-info">
                <div class="rg-tenant-name"><?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></div>
                <span class="rg-tenant-status <?php echo esc_attr($tenant['status']); ?>"><?php echo ucfirst($tenant['status']); ?></span>
            </div>
        </div>
        
        <div class="rg-tenant-body">
            <div class="rg-tenant-detail">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                <a href="mailto:<?php echo esc_attr($tenant['email']); ?>"><?php echo esc_html($tenant['email']); ?></a>
            </div>
            <?php if ($tenant['phone']): ?>
            <div class="rg-tenant-detail">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <a href="tel:<?php echo esc_attr($tenant['phone']); ?>"><?php echo esc_html($tenant['phone']); ?></a>
            </div>
            <?php endif; ?>
            
            <?php if ($tenant['lease_id']): ?>
            <div class="rg-tenant-lease">
                <div class="rg-tenant-lease-title"><?php _e('Current Lease', 'rental-gates'); ?></div>
                <div class="rg-tenant-lease-unit"><?php echo esc_html($tenant['unit_name'] . ' - ' . $tenant['building_name']); ?></div>
                <div class="rg-tenant-lease-dates">
                    <?php echo date('M j, Y', strtotime($tenant['start_date'])); ?> - <?php echo date('M j, Y', strtotime($tenant['end_date'])); ?>
                    · $<?php echo number_format($tenant['rent_amount']); ?>/mo
                </div>
            </div>
            <?php else: ?>
            <div class="rg-tenant-detail" style="color: var(--gray-400); font-style: italic;">
                <?php _e('No active lease', 'rental-gates'); ?>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="rg-tenant-footer">
            <a href="<?php echo home_url('/rental-gates/staff/tenants/' . $tenant['id']); ?>" class="rg-tenant-btn rg-tenant-btn-primary">
                <?php _e('View Profile', 'rental-gates'); ?>
            </a>
            <?php if ($tenant['lease_id']): ?>
            <a href="<?php echo home_url('/rental-gates/staff/leases/' . $tenant['lease_id']); ?>" class="rg-tenant-btn rg-tenant-btn-secondary">
                <?php _e('View Lease', 'rental-gates'); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
