<?php
/**
 * Staff Payments Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['payments'] ?? 'view';
$can_edit = $perm_level === 'full';

// Filters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
$type_filter = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';

// Build query
$where = "WHERE p.organization_id = %d";
$params = array($org_id);

if ($status_filter && $status_filter !== 'all') {
    $where .= " AND p.status = %s";
    $params[] = $status_filter;
}

if ($type_filter) {
    $where .= " AND p.type = %s";
    $params[] = $type_filter;
}

$payments = $wpdb->get_results($wpdb->prepare(
    "SELECT p.*, t.first_name, t.last_name, t.email as tenant_email,
            u.name as unit_name, b.name as building_name, l.id as lease_id
     FROM {$tables['payments']} p
     LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id
     LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     {$where}
     ORDER BY p.due_date DESC, p.created_at DESC
     LIMIT 100",
    ...$params
), ARRAY_A);

// Stats
$payment_stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        SUM(CASE WHEN status = 'paid' AND MONTH(paid_at) = MONTH(CURDATE()) AND YEAR(paid_at) = YEAR(CURDATE()) THEN amount ELSE 0 END) as collected_this_month,
        SUM(CASE WHEN status = 'pending' AND due_date < CURDATE() THEN amount ELSE 0 END) as overdue_amount,
        COUNT(CASE WHEN status = 'pending' AND due_date < CURDATE() THEN 1 END) as overdue_count,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count
     FROM {$tables['payments']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-payments-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-stat-label { font-size: 12px; color: var(--gray-500); text-transform: uppercase; font-weight: 600; margin-bottom: 8px; }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-value.success { color: #16a34a; }
    .rg-stat-value.warning { color: #d97706; }
    .rg-stat-value.danger { color: #dc2626; }
    
    .rg-payments-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 16px; }
    .rg-filter-tabs { display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: 8px; }
    .rg-filter-tab { padding: 8px 14px; border-radius: 6px; font-size: 13px; text-decoration: none; color: var(--gray-600); }
    .rg-filter-tab.active { background: #fff; color: var(--gray-900); }
    
    .rg-payments-table { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-payments-table table { width: 100%; border-collapse: collapse; }
    .rg-payments-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; }
    .rg-payments-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-payments-table tr:last-child td { border-bottom: none; }
    .rg-payments-table tr:hover { background: var(--gray-50); }
    
    .rg-badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .rg-badge-paid { background: #dcfce7; color: #16a34a; }
    .rg-badge-pending { background: #fef3c7; color: #b45309; }
    .rg-badge-overdue { background: #fef2f2; color: #dc2626; }
    .rg-badge-failed { background: #fef2f2; color: #dc2626; }
    
    .rg-type-badge { padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 500; background: var(--gray-100); color: var(--gray-600); text-transform: uppercase; }
    
    .rg-action-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; background: var(--primary); color: #fff; }
    
    .rg-empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
</style>

<!-- Stats -->
<div class="rg-payments-stats">
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Collected This Month', 'rental-gates'); ?></div>
        <div class="rg-stat-value success">$<?php echo number_format($payment_stats['collected_this_month'] ?? 0); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Overdue Amount', 'rental-gates'); ?></div>
        <div class="rg-stat-value danger">$<?php echo number_format($payment_stats['overdue_amount'] ?? 0); ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Overdue Payments', 'rental-gates'); ?></div>
        <div class="rg-stat-value warning"><?php echo $payment_stats['overdue_count'] ?? 0; ?></div>
    </div>
    <div class="rg-stat-card">
        <div class="rg-stat-label"><?php _e('Pending Payments', 'rental-gates'); ?></div>
        <div class="rg-stat-value"><?php echo $payment_stats['pending_count'] ?? 0; ?></div>
    </div>
</div>

<!-- Filters -->
<div class="rg-payments-header">
    <div class="rg-filter-tabs">
        <a href="?status=all" class="rg-filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>"><?php _e('All', 'rental-gates'); ?></a>
        <a href="?status=pending" class="rg-filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>"><?php _e('Pending', 'rental-gates'); ?></a>
        <a href="?status=paid" class="rg-filter-tab <?php echo $status_filter === 'paid' ? 'active' : ''; ?>"><?php _e('Paid', 'rental-gates'); ?></a>
        <a href="?status=failed" class="rg-filter-tab <?php echo $status_filter === 'failed' ? 'active' : ''; ?>"><?php _e('Failed', 'rental-gates'); ?></a>
    </div>
</div>

<!-- Table -->
<div class="rg-payments-table">
    <?php if (empty($payments)): ?>
    <div class="rg-empty">
        <p><?php _e('No payments found', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th><?php _e('Tenant', 'rental-gates'); ?></th>
                <th><?php _e('Type', 'rental-gates'); ?></th>
                <th><?php _e('Amount', 'rental-gates'); ?></th>
                <th><?php _e('Due Date', 'rental-gates'); ?></th>
                <th><?php _e('Status', 'rental-gates'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($payments as $payment): 
                $is_overdue = $payment['status'] === 'pending' && strtotime($payment['due_date']) < time();
            ?>
            <tr>
                <td>
                    <div style="font-weight: 500; color: var(--gray-900);">
                        <?php echo esc_html(($payment['first_name'] ?? '') . ' ' . ($payment['last_name'] ?? '')); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--gray-500);">
                        <?php echo esc_html($payment['unit_name'] ?? ''); ?>
                    </div>
                </td>
                <td>
                    <span class="rg-type-badge"><?php echo esc_html(ucfirst($payment['type'])); ?></span>
                </td>
                <td style="font-weight: 600; font-size: 15px;">
                    $<?php echo number_format($payment['amount'], 2); ?>
                </td>
                <td style="font-size: 13px;">
                    <?php echo date('M j, Y', strtotime($payment['due_date'])); ?>
                    <?php if ($is_overdue): ?>
                    <span style="color: #dc2626; font-size: 11px; display: block;"><?php _e('Overdue', 'rental-gates'); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="rg-badge rg-badge-<?php echo $is_overdue ? 'overdue' : esc_attr($payment['status']); ?>">
                        <?php echo $is_overdue ? __('Overdue', 'rental-gates') : esc_html(ucfirst($payment['status'])); ?>
                    </span>
                </td>
                <td>
                    <a href="<?php echo home_url('/rental-gates/staff/payments/' . $payment['id']); ?>" class="rg-action-btn">
                        <?php _e('View', 'rental-gates'); ?>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
