<?php
/**
 * Staff Buildings Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['buildings'] ?? 'view';
$can_edit = $perm_level === 'full';
$building_ids = isset($permissions['building_ids']) ? array_filter(explode(',', $permissions['building_ids'])) : null;

// Get buildings
$where = "WHERE b.organization_id = %d";
$params = array($org_id);

if ($building_ids && !empty($building_ids)) {
    $placeholders = implode(',', array_fill(0, count($building_ids), '%d'));
    $where .= " AND b.id IN ($placeholders)";
    $params = array_merge($params, $building_ids);
}

$buildings = $wpdb->get_results($wpdb->prepare(
    "SELECT b.*, 
            (SELECT COUNT(*) FROM {$tables['units']} WHERE building_id = b.id) as unit_count,
            (SELECT COUNT(*) FROM {$tables['units']} WHERE building_id = b.id AND status = 'available') as available_count,
            (SELECT COUNT(*) FROM {$tables['units']} WHERE building_id = b.id AND status = 'occupied') as occupied_count
     FROM {$tables['buildings']} b
     {$where}
     ORDER BY b.name ASC",
    ...$params
), ARRAY_A);
?>

<style>
    .rg-buildings-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px; }
    
    .rg-building-card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: box-shadow 0.2s; }
    .rg-building-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    
    .rg-building-image { height: 160px; background: linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%); position: relative; }
    .rg-building-image img { width: 100%; height: 100%; object-fit: cover; }
    .rg-building-status { position: absolute; top: 12px; right: 12px; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 500; background: rgba(255,255,255,0.95); }
    .rg-building-status.active { color: #16a34a; }
    .rg-building-status.inactive { color: #dc2626; }
    
    .rg-building-content { padding: 16px; }
    .rg-building-name { font-size: 18px; font-weight: 600; color: var(--gray-900); margin-bottom: 4px; }
    .rg-building-address { font-size: 13px; color: var(--gray-500); margin-bottom: 12px; display: flex; align-items: flex-start; gap: 6px; }
    .rg-building-address svg { width: 16px; height: 16px; flex-shrink: 0; margin-top: 1px; }
    
    .rg-building-stats { display: flex; gap: 16px; padding-top: 12px; border-top: 1px solid var(--gray-100); }
    .rg-building-stat { text-align: center; flex: 1; }
    .rg-building-stat-value { font-size: 20px; font-weight: 700; color: var(--gray-900); }
    .rg-building-stat-label { font-size: 11px; color: var(--gray-500); text-transform: uppercase; }
    
    .rg-building-actions { display: flex; gap: 8px; padding: 12px 16px; background: var(--gray-50); border-top: 1px solid var(--gray-100); }
    .rg-building-btn { flex: 1; padding: 8px 12px; border-radius: 6px; font-size: 13px; text-align: center; text-decoration: none; transition: all 0.2s; }
    .rg-building-btn-primary { background: var(--primary); color: #fff; }
    .rg-building-btn-primary:hover { background: var(--primary-dark); }
    .rg-building-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
    .rg-building-btn-secondary:hover { background: var(--gray-100); }
    
    .rg-empty-state { text-align: center; padding: 60px 20px; }
    .rg-empty-state svg { color: var(--gray-300); margin-bottom: 16px; }
    .rg-empty-state h3 { color: var(--gray-700); margin-bottom: 8px; }
    .rg-empty-state p { color: var(--gray-500); }
</style>

<?php if (empty($buildings)): ?>
<div class="rg-empty-state">
    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
    <h3><?php _e('No Buildings', 'rental-gates'); ?></h3>
    <p><?php _e('No buildings have been assigned to your account.', 'rental-gates'); ?></p>
</div>
<?php else: ?>

<div class="rg-buildings-grid">
    <?php foreach ($buildings as $building): 
        $image_url = '';
        if (!empty($building['featured_image'])) {
            $image_url = wp_get_attachment_url($building['featured_image']);
        }
        $occupancy = $building['unit_count'] > 0 ? round(($building['occupied_count'] / $building['unit_count']) * 100) : 0;
    ?>
    <div class="rg-building-card">
        <div class="rg-building-image">
            <?php if ($image_url): ?>
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($building['name']); ?>">
            <?php else: ?>
                <div style="display: flex; align-items: center; justify-content: center; height: 100%;">
                    <svg width="48" height="48" fill="none" stroke="#a5b4fc" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                </div>
            <?php endif; ?>
            <span class="rg-building-status <?php echo $building['status'] === 'active' ? 'active' : 'inactive'; ?>">
                <?php echo ucfirst($building['status']); ?>
            </span>
        </div>
        
        <div class="rg-building-content">
            <div class="rg-building-name"><?php echo esc_html($building['name']); ?></div>
            <div class="rg-building-address">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <?php echo esc_html($building['address'] . ', ' . $building['city'] . ', ' . $building['state']); ?>
            </div>
            
            <div class="rg-building-stats">
                <div class="rg-building-stat">
                    <div class="rg-building-stat-value"><?php echo $building['unit_count']; ?></div>
                    <div class="rg-building-stat-label"><?php _e('Units', 'rental-gates'); ?></div>
                </div>
                <div class="rg-building-stat">
                    <div class="rg-building-stat-value" style="color: #16a34a;"><?php echo $building['available_count']; ?></div>
                    <div class="rg-building-stat-label"><?php _e('Available', 'rental-gates'); ?></div>
                </div>
                <div class="rg-building-stat">
                    <div class="rg-building-stat-value"><?php echo $occupancy; ?>%</div>
                    <div class="rg-building-stat-label"><?php _e('Occupied', 'rental-gates'); ?></div>
                </div>
            </div>
        </div>
        
        <div class="rg-building-actions">
            <a href="<?php echo home_url('/rental-gates/staff/buildings/' . $building['id']); ?>" class="rg-building-btn rg-building-btn-primary">
                <?php _e('View Details', 'rental-gates'); ?>
            </a>
            <a href="<?php echo home_url('/rental-gates/staff/buildings/' . $building['id'] . '/units'); ?>" class="rg-building-btn rg-building-btn-secondary">
                <?php _e('View Units', 'rental-gates'); ?>
            </a>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php endif; ?>
