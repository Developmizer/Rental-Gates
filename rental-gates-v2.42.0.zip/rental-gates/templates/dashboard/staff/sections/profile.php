<?php
/**
 * Staff Profile Section
 */
if (!defined('ABSPATH')) exit;

$success_message = '';
$error_message = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile']) && wp_verify_nonce($_POST['_wpnonce'], 'update_staff_profile')) {
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $display_name = sanitize_text_field($_POST['display_name']);
    $phone = sanitize_text_field($_POST['phone']);
    
    // Update WordPress user
    wp_update_user(array(
        'ID' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'display_name' => $display_name,
    ));
    
    // Update phone in user meta
    update_user_meta($user_id, 'phone', $phone);
    
    $success_message = __('Profile updated successfully!', 'rental-gates');
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password']) && wp_verify_nonce($_POST['_wpnonce'], 'change_staff_password')) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (!wp_check_password($current_password, $current_user->user_pass, $user_id)) {
        $error_message = __('Current password is incorrect.', 'rental-gates');
    } elseif (strlen($new_password) < 8) {
        $error_message = __('New password must be at least 8 characters.', 'rental-gates');
    } elseif ($new_password !== $confirm_password) {
        $error_message = __('New passwords do not match.', 'rental-gates');
    } else {
        wp_set_password($new_password, $user_id);
        $success_message = __('Password changed successfully! Please log in again.', 'rental-gates');
    }
}

// Handle notification preferences
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_notifications']) && wp_verify_nonce($_POST['_wpnonce'], 'update_staff_notifications')) {
    $notification_types = $_POST['notifications'] ?? array();
    
    foreach (Rental_Gates_Notification::TYPES as $type => $label) {
        $channel = isset($notification_types[$type]) ? 'both' : 'none';
        Rental_Gates_Notification::update_preference($user_id, $type, $channel);
    }
    
    $success_message = __('Notification preferences saved!', 'rental-gates');
}

// Get current data
$first_name = get_user_meta($user_id, 'first_name', true);
$last_name = get_user_meta($user_id, 'last_name', true);
$phone = get_user_meta($user_id, 'phone', true);
$notification_prefs = Rental_Gates_Notification::get_preferences($user_id);
?>

<style>
    .rg-profile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    @media (max-width: 1024px) { .rg-profile-grid { grid-template-columns: 1fr; } }
    
    .rg-profile-card { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }
    .rg-profile-header { padding: 20px; border-bottom: 1px solid var(--gray-100); }
    .rg-profile-title { font-size: 18px; font-weight: 600; color: var(--gray-900); margin: 0; display: flex; align-items: center; gap: 10px; }
    .rg-profile-title svg { width: 20px; height: 20px; color: var(--gray-400); }
    .rg-profile-body { padding: 20px; }
    
    .rg-form-group { margin-bottom: 16px; }
    .rg-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    @media (max-width: 640px) { .rg-form-row { grid-template-columns: 1fr; } }
    .rg-form-label { display: block; font-size: 13px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .rg-form-control { width: 100%; padding: 10px 12px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .rg-form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.1); }
    .rg-form-control:disabled { background: var(--gray-100); color: var(--gray-500); }
    
    .rg-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; text-decoration: none; }
    .rg-btn-primary { background: var(--primary); color: #fff; }
    .rg-btn-primary:hover { background: var(--primary-dark); }
    .rg-btn svg { width: 16px; height: 16px; }
    
    .rg-alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .rg-alert-success { background: #dcfce7; color: #166534; }
    .rg-alert-error { background: #fef2f2; color: #991b1b; }
    
    .rg-perm-list { margin: 0; padding: 0; list-style: none; }
    .rg-perm-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--gray-100); }
    .rg-perm-item:last-child { border-bottom: none; }
    .rg-perm-label { font-size: 14px; color: var(--gray-700); }
    .rg-perm-value { padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 500; text-transform: uppercase; }
    .rg-perm-full { background: #dcfce7; color: #16a34a; }
    .rg-perm-view { background: #dbeafe; color: #2563eb; }
    .rg-perm-none { background: var(--gray-100); color: var(--gray-500); }
    
    .rg-notif-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
    @media (max-width: 640px) { .rg-notif-grid { grid-template-columns: 1fr; } }
    .rg-notif-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: var(--gray-50); border-radius: 6px; }
    .rg-notif-item input { width: 16px; height: 16px; accent-color: var(--primary); }
    .rg-notif-item label { font-size: 13px; color: var(--gray-700); cursor: pointer; }
</style>

<?php if ($success_message): ?>
<div class="rg-alert rg-alert-success">
    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <?php echo esc_html($success_message); ?>
</div>
<?php endif; ?>

<?php if ($error_message): ?>
<div class="rg-alert rg-alert-error">
    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    <?php echo esc_html($error_message); ?>
</div>
<?php endif; ?>

<div class="rg-profile-grid">
    <!-- Personal Information -->
    <div class="rg-profile-card">
        <div class="rg-profile-header">
            <h2 class="rg-profile-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                <?php _e('Personal Information', 'rental-gates'); ?>
            </h2>
        </div>
        <div class="rg-profile-body">
            <form method="post">
                <?php wp_nonce_field('update_staff_profile'); ?>
                <input type="hidden" name="update_profile" value="1">
                
                <div class="rg-form-row">
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('First Name', 'rental-gates'); ?></label>
                        <input type="text" name="first_name" class="rg-form-control" value="<?php echo esc_attr($first_name); ?>" required>
                    </div>
                    <div class="rg-form-group">
                        <label class="rg-form-label"><?php _e('Last Name', 'rental-gates'); ?></label>
                        <input type="text" name="last_name" class="rg-form-control" value="<?php echo esc_attr($last_name); ?>" required>
                    </div>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Display Name', 'rental-gates'); ?></label>
                    <input type="text" name="display_name" class="rg-form-control" value="<?php echo esc_attr($current_user->display_name); ?>" required>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Email Address', 'rental-gates'); ?></label>
                    <input type="email" class="rg-form-control" value="<?php echo esc_attr($current_user->user_email); ?>" disabled>
                    <small style="color: var(--gray-500); font-size: 12px;"><?php _e('Contact your manager to change your email.', 'rental-gates'); ?></small>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Phone Number', 'rental-gates'); ?></label>
                    <input type="tel" name="phone" class="rg-form-control" value="<?php echo esc_attr($phone); ?>">
                </div>
                
                <button type="submit" class="rg-btn rg-btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Save Changes', 'rental-gates'); ?>
                </button>
            </form>
        </div>
    </div>
    
    <!-- Change Password -->
    <div class="rg-profile-card">
        <div class="rg-profile-header">
            <h2 class="rg-profile-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                <?php _e('Change Password', 'rental-gates'); ?>
            </h2>
        </div>
        <div class="rg-profile-body">
            <form method="post">
                <?php wp_nonce_field('change_staff_password'); ?>
                <input type="hidden" name="change_password" value="1">
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Current Password', 'rental-gates'); ?></label>
                    <input type="password" name="current_password" class="rg-form-control" required>
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('New Password', 'rental-gates'); ?></label>
                    <input type="password" name="new_password" class="rg-form-control" required minlength="8">
                </div>
                
                <div class="rg-form-group">
                    <label class="rg-form-label"><?php _e('Confirm New Password', 'rental-gates'); ?></label>
                    <input type="password" name="confirm_password" class="rg-form-control" required minlength="8">
                </div>
                
                <button type="submit" class="rg-btn rg-btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                    <?php _e('Update Password', 'rental-gates'); ?>
                </button>
            </form>
        </div>
    </div>
    
    <!-- Permissions -->
    <div class="rg-profile-card">
        <div class="rg-profile-header">
            <h2 class="rg-profile-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                <?php _e('My Permissions', 'rental-gates'); ?>
            </h2>
        </div>
        <div class="rg-profile-body">
            <ul class="rg-perm-list">
                <?php foreach (Rental_Gates_Roles::STAFF_MODULES as $module => $label): 
                    $level = $permissions[$module] ?? 'none';
                ?>
                <li class="rg-perm-item">
                    <span class="rg-perm-label"><?php echo esc_html($label); ?></span>
                    <span class="rg-perm-value rg-perm-<?php echo $level; ?>">
                        <?php echo $level === 'full' ? __('Full Access', 'rental-gates') : ($level === 'view' ? __('View Only', 'rental-gates') : __('No Access', 'rental-gates')); ?>
                    </span>
                </li>
                <?php endforeach; ?>
            </ul>
            <p style="margin-top: 16px; font-size: 12px; color: var(--gray-500);">
                <?php _e('Contact your property manager to request permission changes.', 'rental-gates'); ?>
            </p>
        </div>
    </div>
    
    <!-- Notification Preferences -->
    <div class="rg-profile-card">
        <div class="rg-profile-header">
            <h2 class="rg-profile-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                <?php _e('Notification Preferences', 'rental-gates'); ?>
            </h2>
        </div>
        <div class="rg-profile-body">
            <form method="post">
                <?php wp_nonce_field('update_staff_notifications'); ?>
                <input type="hidden" name="update_notifications" value="1">
                
                <div class="rg-notif-grid">
                    <?php 
                    $relevant_types = array('maintenance_created', 'maintenance_updated', 'maintenance_completed', 'lease_expiring', 'application_received', 'payment_overdue', 'announcement');
                    foreach ($relevant_types as $type): 
                        $label = Rental_Gates_Notification::TYPES[$type] ?? $type;
                        $enabled = ($notification_prefs[$type]['channel'] ?? 'both') !== 'none';
                    ?>
                    <div class="rg-notif-item">
                        <input type="checkbox" name="notifications[<?php echo $type; ?>]" id="notif_<?php echo $type; ?>" <?php checked($enabled); ?>>
                        <label for="notif_<?php echo $type; ?>"><?php echo esc_html($label); ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="submit" class="rg-btn rg-btn-primary" style="margin-top: 16px;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Save Preferences', 'rental-gates'); ?>
                </button>
            </form>
        </div>
    </div>
</div>
