<?php
/**
 * Staff Dashboard
 */
if (!defined('ABSPATH')) exit;

// Get stats based on permissions
$stats = array();

// Buildings count (if has access)
if (($permissions['buildings'] ?? 'none') !== 'none') {
    $building_ids = $permissions['building_ids'] ?? null;
    if ($building_ids) {
        $building_count = count(explode(',', $building_ids));
    } else {
        $building_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = %d",
            $org_id
        ));
    }
    $stats['buildings'] = $building_count;
    
    // Units count
    if ($building_ids) {
        $unit_count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$tables['units']} WHERE building_id IN ({$building_ids})"
        );
    } else {
        $unit_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['units']} u 
             JOIN {$tables['buildings']} b ON u.building_id = b.id 
             WHERE b.organization_id = %d",
            $org_id
        ));
    }
    $stats['units'] = $unit_count;
}

// Active tenants (if has access)
if (($permissions['tenants'] ?? 'none') !== 'none') {
    $stats['tenants'] = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$tables['tenants']} WHERE organization_id = %d AND status = 'active'",
        $org_id
    ));
}

// Maintenance requests (if has access)
if (($permissions['maintenance'] ?? 'none') !== 'none') {
    $stats['open_maintenance'] = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$tables['work_orders']} WHERE organization_id = %d AND status IN ('new', 'assigned', 'in_progress')",
        $org_id
    ));
}

// Applications (if has access)
if (($permissions['applications'] ?? 'none') !== 'none') {
    $stats['pending_applications'] = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$tables['applications']} WHERE organization_id = %d AND status = 'pending'",
        $org_id
    ));
}

// Recent activity
$recent_activity = $wpdb->get_results($wpdb->prepare(
    "SELECT al.*, u.display_name as user_name
     FROM {$tables['activity_log']} al
     LEFT JOIN " . $wpdb->users . " u ON al.user_id = u.ID
     WHERE al.organization_id = %d
     ORDER BY al.created_at DESC
     LIMIT 10",
    $org_id
), ARRAY_A);

// Urgent maintenance requests
$urgent_maintenance = array();
if (($permissions['maintenance'] ?? 'none') !== 'none') {
    $urgent_maintenance = $wpdb->get_results($wpdb->prepare(
        "SELECT w.*, u.name as unit_name, b.name as building_name
         FROM {$tables['work_orders']} w
         LEFT JOIN {$tables['units']} u ON w.unit_id = u.id
         LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
         WHERE w.organization_id = %d 
         AND w.status IN ('new', 'assigned') 
         AND w.priority IN ('high', 'emergency')
         ORDER BY FIELD(w.priority, 'emergency', 'high'), w.created_at ASC
         LIMIT 5",
        $org_id
    ), ARRAY_A);
}

// Expiring leases this month
$expiring_leases = array();
if (($permissions['leases'] ?? 'none') !== 'none') {
    $expiring_leases = $wpdb->get_results($wpdb->prepare(
        "SELECT l.*, u.name as unit_name, b.name as building_name,
                t.first_name, t.last_name
         FROM {$tables['leases']} l
         JOIN {$tables['units']} u ON l.unit_id = u.id
         JOIN {$tables['buildings']} b ON u.building_id = b.id
         LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
         LEFT JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
         WHERE l.organization_id = %d 
         AND l.status = 'active'
         AND l.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
         ORDER BY l.end_date ASC
         LIMIT 5",
        $org_id
    ), ARRAY_A);
}
?>

<style>
    .rg-staff-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .rg-stat-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-stat-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 12px; }
    .rg-stat-icon svg { width: 24px; height: 24px; }
    .rg-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); margin-bottom: 4px; }
    .rg-stat-label { font-size: 14px; color: var(--gray-500); }
    
    .rg-dashboard-row { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
    @media (max-width: 1024px) { .rg-dashboard-row { grid-template-columns: 1fr; } }
    
    .rg-card { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }
    .rg-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
    .rg-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .rg-card-body { padding: 0; }
    
    .rg-list-item { display: flex; align-items: center; gap: 12px; padding: 12px 20px; border-bottom: 1px solid var(--gray-50); }
    .rg-list-item:last-child { border-bottom: none; }
    .rg-list-item:hover { background: var(--gray-50); }
    
    .rg-priority-badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .rg-priority-emergency { background: #fef2f2; color: #dc2626; }
    .rg-priority-high { background: #fef3c7; color: #d97706; }
    
    .rg-list-content { flex: 1; min-width: 0; }
    .rg-list-title { font-size: 14px; font-weight: 500; color: var(--gray-900); margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rg-list-meta { font-size: 12px; color: var(--gray-500); }
    
    .rg-list-action { flex-shrink: 0; }
    .rg-list-action a { display: inline-flex; align-items: center; gap: 4px; padding: 6px 12px; font-size: 12px; color: var(--primary); border: 1px solid var(--primary); border-radius: 6px; text-decoration: none; }
    .rg-list-action a:hover { background: var(--primary); color: #fff; }
    
    .rg-empty { padding: 40px 20px; text-align: center; color: var(--gray-400); }
    .rg-empty svg { margin-bottom: 12px; }
    
    .rg-activity-item { display: flex; gap: 12px; padding: 12px 20px; border-bottom: 1px solid var(--gray-50); }
    .rg-activity-item:last-child { border-bottom: none; }
    .rg-activity-icon { width: 32px; height: 32px; border-radius: 50%; background: var(--gray-100); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .rg-activity-icon svg { width: 16px; height: 16px; color: var(--gray-500); }
    .rg-activity-content { flex: 1; }
    .rg-activity-text { font-size: 13px; color: var(--gray-700); }
    .rg-activity-text strong { color: var(--gray-900); }
    .rg-activity-time { font-size: 12px; color: var(--gray-400); margin-top: 2px; }
    
    .rg-welcome-banner { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; color: #fff; }
    .rg-welcome-banner h2 { margin: 0 0 8px; font-size: 22px; }
    .rg-welcome-banner p { margin: 0; opacity: 0.9; }
</style>

<!-- Welcome Banner -->
<div class="rg-welcome-banner">
    <h2><?php printf(__('Welcome back, %s!', 'rental-gates'), esc_html($current_user->display_name)); ?></h2>
    <p><?php echo esc_html($org_name); ?> - <?php echo date_i18n('l, F j, Y'); ?></p>
</div>

<!-- Stats Grid -->
<div class="rg-staff-grid">
    <?php if (isset($stats['buildings'])): ?>
    <div class="rg-stat-card">
        <div class="rg-stat-icon" style="background: #dbeafe; color: #2563eb;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
        </div>
        <div class="rg-stat-value"><?php echo number_format($stats['buildings']); ?></div>
        <div class="rg-stat-label"><?php _e('Buildings', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($stats['units'])): ?>
    <div class="rg-stat-card">
        <div class="rg-stat-icon" style="background: #dcfce7; color: #16a34a;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
        </div>
        <div class="rg-stat-value"><?php echo number_format($stats['units']); ?></div>
        <div class="rg-stat-label"><?php _e('Units', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($stats['tenants'])): ?>
    <div class="rg-stat-card">
        <div class="rg-stat-icon" style="background: #fef3c7; color: #d97706;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
        </div>
        <div class="rg-stat-value"><?php echo number_format($stats['tenants']); ?></div>
        <div class="rg-stat-label"><?php _e('Active Tenants', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($stats['open_maintenance'])): ?>
    <div class="rg-stat-card">
        <div class="rg-stat-icon" style="background: #fef2f2; color: #dc2626;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <div class="rg-stat-value"><?php echo number_format($stats['open_maintenance']); ?></div>
        <div class="rg-stat-label"><?php _e('Open Requests', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($stats['pending_applications'])): ?>
    <div class="rg-stat-card">
        <div class="rg-stat-icon" style="background: #f3e8ff; color: #9333ea;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        </div>
        <div class="rg-stat-value"><?php echo number_format($stats['pending_applications']); ?></div>
        <div class="rg-stat-label"><?php _e('Pending Apps', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
</div>

<div class="rg-dashboard-row">
    <!-- Urgent Maintenance -->
    <?php if (($permissions['maintenance'] ?? 'none') !== 'none'): ?>
    <div class="rg-card">
        <div class="rg-card-header">
            <h3 class="rg-card-title"><?php _e('Urgent Maintenance', 'rental-gates'); ?></h3>
            <a href="<?php echo home_url('/rental-gates/staff/maintenance'); ?>" style="font-size: 13px; color: var(--primary); text-decoration: none;"><?php _e('View All', 'rental-gates'); ?> →</a>
        </div>
        <div class="rg-card-body">
            <?php if (empty($urgent_maintenance)): ?>
            <div class="rg-empty">
                <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <p><?php _e('No urgent requests', 'rental-gates'); ?></p>
            </div>
            <?php else: ?>
            <?php foreach ($urgent_maintenance as $request): ?>
            <div class="rg-list-item">
                <span class="rg-priority-badge rg-priority-<?php echo esc_attr($request['priority']); ?>">
                    <?php echo esc_html(ucfirst($request['priority'])); ?>
                </span>
                <div class="rg-list-content">
                    <div class="rg-list-title"><?php echo esc_html($request['title']); ?></div>
                    <div class="rg-list-meta"><?php echo esc_html($request['unit_name'] . ' - ' . $request['building_name']); ?></div>
                </div>
                <div class="rg-list-action">
                    <a href="<?php echo home_url('/rental-gates/staff/maintenance/' . $request['id']); ?>"><?php _e('View', 'rental-gates'); ?></a>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Expiring Leases -->
    <?php if (($permissions['leases'] ?? 'none') !== 'none'): ?>
    <div class="rg-card">
        <div class="rg-card-header">
            <h3 class="rg-card-title"><?php _e('Expiring Leases (30 days)', 'rental-gates'); ?></h3>
            <a href="<?php echo home_url('/rental-gates/staff/leases'); ?>" style="font-size: 13px; color: var(--primary); text-decoration: none;"><?php _e('View All', 'rental-gates'); ?> →</a>
        </div>
        <div class="rg-card-body">
            <?php if (empty($expiring_leases)): ?>
            <div class="rg-empty">
                <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <p><?php _e('No leases expiring soon', 'rental-gates'); ?></p>
            </div>
            <?php else: ?>
            <?php foreach ($expiring_leases as $lease): 
                $days_left = floor((strtotime($lease['end_date']) - time()) / 86400);
            ?>
            <div class="rg-list-item">
                <div class="rg-list-content">
                    <div class="rg-list-title"><?php echo esc_html($lease['first_name'] . ' ' . $lease['last_name']); ?></div>
                    <div class="rg-list-meta"><?php echo esc_html($lease['unit_name'] . ' - ' . $lease['building_name']); ?></div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 14px; font-weight: 600; color: <?php echo $days_left <= 7 ? '#dc2626' : '#d97706'; ?>;"><?php echo $days_left; ?> <?php _e('days', 'rental-gates'); ?></div>
                    <div style="font-size: 12px; color: var(--gray-500);"><?php echo date('M j', strtotime($lease['end_date'])); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Recent Activity -->
<div class="rg-card">
    <div class="rg-card-header">
        <h3 class="rg-card-title"><?php _e('Recent Activity', 'rental-gates'); ?></h3>
    </div>
    <div class="rg-card-body">
        <?php if (empty($recent_activity)): ?>
        <div class="rg-empty">
            <p><?php _e('No recent activity', 'rental-gates'); ?></p>
        </div>
        <?php else: ?>
        <?php foreach ($recent_activity as $activity): ?>
        <div class="rg-activity-item">
            <div class="rg-activity-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div class="rg-activity-content">
                <div class="rg-activity-text">
                    <strong><?php echo esc_html($activity['user_name'] ?? __('System', 'rental-gates')); ?></strong>
                    <?php echo esc_html(ucwords(str_replace('_', ' ', $activity['action']))); ?>
                    <?php if ($activity['entity_type']): ?>
                    <span style="color: var(--gray-500);"><?php echo esc_html($activity['entity_type']); ?></span>
                    <?php endif; ?>
                </div>
                <div class="rg-activity-time"><?php echo human_time_diff(strtotime($activity['created_at']), current_time('timestamp')); ?> <?php _e('ago', 'rental-gates'); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
