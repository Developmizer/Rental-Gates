<?php
/**
 * Staff Vendors Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['vendors'] ?? 'view';
$can_edit = $perm_level === 'full';

// Get vendors
$vendors = $wpdb->get_results($wpdb->prepare(
    "SELECT v.*,
            (SELECT COUNT(*) FROM {$tables['work_orders']} WHERE vendor_id = v.id AND status IN ('assigned', 'in_progress')) as active_jobs,
            (SELECT COUNT(*) FROM {$tables['work_orders']} WHERE vendor_id = v.id AND status = 'completed') as completed_jobs
     FROM {$tables['vendors']} v
     WHERE v.organization_id = %d AND v.status = 'active'
     ORDER BY v.company_name ASC",
    $org_id
), ARRAY_A);

// Service category labels
$category_labels = array(
    'plumbing' => __('Plumbing', 'rental-gates'),
    'electrical' => __('Electrical', 'rental-gates'),
    'hvac' => __('HVAC', 'rental-gates'),
    'appliance' => __('Appliance Repair', 'rental-gates'),
    'general' => __('General Maintenance', 'rental-gates'),
    'landscaping' => __('Landscaping', 'rental-gates'),
    'cleaning' => __('Cleaning', 'rental-gates'),
    'pest_control' => __('Pest Control', 'rental-gates'),
    'roofing' => __('Roofing', 'rental-gates'),
    'painting' => __('Painting', 'rental-gates'),
    'flooring' => __('Flooring', 'rental-gates'),
    'locksmith' => __('Locksmith', 'rental-gates'),
);
?>

<style>
    .rg-vendors-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px; }
    
    .rg-vendor-card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-vendor-header { padding: 20px; border-bottom: 1px solid var(--gray-100); display: flex; align-items: flex-start; gap: 14px; }
    .rg-vendor-avatar { width: 50px; height: 50px; border-radius: 10px; background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600; flex-shrink: 0; }
    .rg-vendor-info { flex: 1; min-width: 0; }
    .rg-vendor-name { font-size: 16px; font-weight: 600; color: var(--gray-900); margin-bottom: 4px; }
    .rg-vendor-contact { font-size: 13px; color: var(--gray-600); }
    
    .rg-vendor-body { padding: 16px 20px; }
    .rg-vendor-categories { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px; }
    .rg-category-tag { padding: 4px 10px; background: var(--gray-100); border-radius: 6px; font-size: 11px; font-weight: 500; color: var(--gray-600); }
    
    .rg-vendor-stats { display: flex; gap: 24px; }
    .rg-vendor-stat { text-align: center; }
    .rg-vendor-stat-value { font-size: 20px; font-weight: 700; color: var(--gray-900); }
    .rg-vendor-stat-label { font-size: 11px; color: var(--gray-500); text-transform: uppercase; }
    
    .rg-vendor-actions { display: flex; gap: 8px; padding: 12px 20px; background: var(--gray-50); border-top: 1px solid var(--gray-100); }
    .rg-vendor-btn { flex: 1; padding: 8px; border-radius: 6px; font-size: 12px; text-align: center; text-decoration: none; transition: all 0.2s; }
    .rg-vendor-btn-primary { background: var(--primary); color: #fff; }
    .rg-vendor-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
    
    .rg-empty { text-align: center; padding: 60px 20px; background: #fff; border-radius: 12px; }
    .rg-empty svg { color: var(--gray-300); margin-bottom: 16px; }
</style>

<?php if (empty($vendors)): ?>
<div class="rg-empty">
    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
    <h3><?php _e('No Vendors', 'rental-gates'); ?></h3>
    <p><?php _e('No vendors have been added yet.', 'rental-gates'); ?></p>
</div>
<?php else: ?>

<div class="rg-vendors-grid">
    <?php foreach ($vendors as $vendor): 
        $initials = strtoupper(substr($vendor['company_name'], 0, 2));
        $categories = !empty($vendor['service_categories']) ? json_decode($vendor['service_categories'], true) : array();
    ?>
    <div class="rg-vendor-card">
        <div class="rg-vendor-header">
            <div class="rg-vendor-avatar"><?php echo $initials; ?></div>
            <div class="rg-vendor-info">
                <div class="rg-vendor-name"><?php echo esc_html($vendor['company_name']); ?></div>
                <div class="rg-vendor-contact">
                    <?php if ($vendor['contact_name']): ?>
                        <?php echo esc_html($vendor['contact_name']); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="rg-vendor-body">
            <?php if (!empty($categories)): ?>
            <div class="rg-vendor-categories">
                <?php foreach (array_slice($categories, 0, 4) as $cat): ?>
                <span class="rg-category-tag"><?php echo esc_html($category_labels[$cat] ?? ucfirst($cat)); ?></span>
                <?php endforeach; ?>
                <?php if (count($categories) > 4): ?>
                <span class="rg-category-tag">+<?php echo count($categories) - 4; ?></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <div class="rg-vendor-stats">
                <div class="rg-vendor-stat">
                    <div class="rg-vendor-stat-value" style="color: #d97706;"><?php echo $vendor['active_jobs']; ?></div>
                    <div class="rg-vendor-stat-label"><?php _e('Active Jobs', 'rental-gates'); ?></div>
                </div>
                <div class="rg-vendor-stat">
                    <div class="rg-vendor-stat-value" style="color: #16a34a;"><?php echo $vendor['completed_jobs']; ?></div>
                    <div class="rg-vendor-stat-label"><?php _e('Completed', 'rental-gates'); ?></div>
                </div>
            </div>
        </div>
        
        <div class="rg-vendor-actions">
            <a href="<?php echo home_url('/rental-gates/staff/vendors/' . $vendor['id']); ?>" class="rg-vendor-btn rg-vendor-btn-primary">
                <?php _e('View Details', 'rental-gates'); ?>
            </a>
            <?php if ($vendor['phone']): ?>
            <a href="tel:<?php echo esc_attr($vendor['phone']); ?>" class="rg-vendor-btn rg-vendor-btn-secondary">
                <?php _e('Call', 'rental-gates'); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php endif; ?>
