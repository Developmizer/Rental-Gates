<?php
/**
 * Staff Leases Section
 */
if (!defined('ABSPATH')) exit;

$perm_level = $permissions['leases'] ?? 'view';
$can_edit = $perm_level === 'full';

// Filters
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'active';

// Build query
$where = "WHERE l.organization_id = %d";
$params = array($org_id);

if ($status_filter && $status_filter !== 'all') {
    $where .= " AND l.status = %s";
    $params[] = $status_filter;
}

$leases = $wpdb->get_results($wpdb->prepare(
    "SELECT l.*, u.name as unit_name, b.name as building_name,
            t.first_name, t.last_name, t.email as tenant_email
     FROM {$tables['leases']} l
     JOIN {$tables['units']} u ON l.unit_id = u.id
     JOIN {$tables['buildings']} b ON u.building_id = b.id
     LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
     LEFT JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
     {$where}
     ORDER BY l.end_date ASC",
    ...$params
), ARRAY_A);

// Stats
$lease_stats = $wpdb->get_row($wpdb->prepare(
    "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
        COUNT(CASE WHEN status = 'active' AND end_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as expiring,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending
     FROM {$tables['leases']}
     WHERE organization_id = %d",
    $org_id
), ARRAY_A);
?>

<style>
    .rg-leases-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 16px; }
    
    .rg-stats-mini { display: flex; gap: 16px; margin-bottom: 20px; }
    .rg-stat-mini { background: #fff; border-radius: 8px; padding: 12px 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-stat-mini-value { font-size: 24px; font-weight: 700; color: var(--gray-900); }
    .rg-stat-mini-label { font-size: 12px; color: var(--gray-500); margin-top: 2px; }
    
    .rg-filter-tabs { display: flex; gap: 4px; background: var(--gray-100); padding: 4px; border-radius: 8px; }
    .rg-filter-tab { padding: 8px 14px; border-radius: 6px; font-size: 13px; text-decoration: none; color: var(--gray-600); }
    .rg-filter-tab.active { background: #fff; color: var(--gray-900); }
    
    .rg-leases-table { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .rg-leases-table table { width: 100%; border-collapse: collapse; }
    .rg-leases-table th { text-align: left; padding: 12px 16px; background: var(--gray-50); font-size: 12px; font-weight: 600; color: var(--gray-500); text-transform: uppercase; }
    .rg-leases-table td { padding: 14px 16px; border-bottom: 1px solid var(--gray-100); }
    .rg-leases-table tr:last-child td { border-bottom: none; }
    .rg-leases-table tr:hover { background: var(--gray-50); }
    
    .rg-badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .rg-badge-active { background: #dcfce7; color: #16a34a; }
    .rg-badge-pending { background: #fef3c7; color: #b45309; }
    .rg-badge-ended { background: #f3f4f6; color: #6b7280; }
    .rg-badge-terminated { background: #fef2f2; color: #dc2626; }
    
    .rg-expiring-badge { display: inline-block; padding: 2px 6px; background: #fef3c7; color: #b45309; border-radius: 4px; font-size: 10px; font-weight: 600; margin-left: 6px; }
    
    .rg-action-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; text-decoration: none; background: var(--primary); color: #fff; }
    
    .rg-empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
</style>

<!-- Stats -->
<div class="rg-stats-mini">
    <div class="rg-stat-mini">
        <div class="rg-stat-mini-value"><?php echo $lease_stats['active']; ?></div>
        <div class="rg-stat-mini-label"><?php _e('Active Leases', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-mini">
        <div class="rg-stat-mini-value" style="color: #d97706;"><?php echo $lease_stats['expiring']; ?></div>
        <div class="rg-stat-mini-label"><?php _e('Expiring (30d)', 'rental-gates'); ?></div>
    </div>
    <div class="rg-stat-mini">
        <div class="rg-stat-mini-value" style="color: #2563eb;"><?php echo $lease_stats['pending']; ?></div>
        <div class="rg-stat-mini-label"><?php _e('Pending', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Filters -->
<div class="rg-leases-header">
    <div class="rg-filter-tabs">
        <a href="?status=active" class="rg-filter-tab <?php echo $status_filter === 'active' ? 'active' : ''; ?>"><?php _e('Active', 'rental-gates'); ?></a>
        <a href="?status=pending" class="rg-filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>"><?php _e('Pending', 'rental-gates'); ?></a>
        <a href="?status=ended" class="rg-filter-tab <?php echo $status_filter === 'ended' ? 'active' : ''; ?>"><?php _e('Ended', 'rental-gates'); ?></a>
        <a href="?status=all" class="rg-filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>"><?php _e('All', 'rental-gates'); ?></a>
    </div>
</div>

<!-- Table -->
<div class="rg-leases-table">
    <?php if (empty($leases)): ?>
    <div class="rg-empty">
        <p><?php _e('No leases found', 'rental-gates'); ?></p>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th><?php _e('Tenant', 'rental-gates'); ?></th>
                <th><?php _e('Unit', 'rental-gates'); ?></th>
                <th><?php _e('Lease Period', 'rental-gates'); ?></th>
                <th><?php _e('Rent', 'rental-gates'); ?></th>
                <th><?php _e('Status', 'rental-gates'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($leases as $lease): 
                $days_left = floor((strtotime($lease['end_date']) - time()) / 86400);
                $is_expiring = $lease['status'] === 'active' && $days_left <= 30 && $days_left > 0;
            ?>
            <tr>
                <td>
                    <div style="font-weight: 500; color: var(--gray-900);">
                        <?php echo esc_html(($lease['first_name'] ?? '') . ' ' . ($lease['last_name'] ?? '')); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--gray-500);">
                        <?php echo esc_html($lease['tenant_email'] ?? ''); ?>
                    </div>
                </td>
                <td>
                    <div style="font-weight: 500;"><?php echo esc_html($lease['unit_name']); ?></div>
                    <div style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($lease['building_name']); ?></div>
                </td>
                <td>
                    <div style="font-size: 13px;">
                        <?php echo date('M j, Y', strtotime($lease['start_date'])); ?> - <?php echo date('M j, Y', strtotime($lease['end_date'])); ?>
                    </div>
                    <?php if ($is_expiring): ?>
                    <span class="rg-expiring-badge"><?php echo $days_left; ?> <?php _e('days left', 'rental-gates'); ?></span>
                    <?php endif; ?>
                </td>
                <td style="font-weight: 600;">
                    $<?php echo number_format($lease['rent_amount']); ?>/mo
                </td>
                <td>
                    <span class="rg-badge rg-badge-<?php echo esc_attr($lease['status']); ?>">
                        <?php echo esc_html(ucfirst($lease['status'])); ?>
                    </span>
                </td>
                <td>
                    <a href="<?php echo home_url('/rental-gates/staff/leases/' . $lease['id']); ?>" class="rg-action-btn">
                        <?php _e('View', 'rental-gates'); ?>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
