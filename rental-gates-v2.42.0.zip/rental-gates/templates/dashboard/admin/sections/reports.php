<?php
/**
 * Site Admin - Reports Section
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$range = isset($_GET['range']) ? intval($_GET['range']) : 30;
$start_date = date('Y-m-d', strtotime("-{$range} days"));

// Summary stats
$stats = array(
    'revenue' => $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM {$tables['payments']} WHERE status = 'completed' AND created_at >= %s", $start_date)),
    'payments' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['payments']} WHERE status = 'completed' AND created_at >= %s", $start_date)),
    'new_orgs' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['organizations']} WHERE created_at >= %s", $start_date)),
    'new_tenants' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['tenants']} WHERE created_at >= %s", $start_date)),
    'new_leases' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['leases']} WHERE created_at >= %s", $start_date)),
    'work_orders' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tables['work_orders']} WHERE created_at >= %s", $start_date)),
);

// Top organizations
$top_orgs = $wpdb->get_results(
    "SELECT o.id, o.name,
            (SELECT COUNT(*) FROM {$tables['units']} u JOIN {$tables['buildings']} b ON u.building_id = b.id WHERE b.organization_id = o.id) as units,
            (SELECT COALESCE(SUM(p.amount), 0) FROM {$tables['payments']} p 
             JOIN {$tables['tenants']} t ON p.tenant_id = t.id
             JOIN {$tables['buildings']} b ON t.building_id = b.id
             WHERE b.organization_id = o.id AND p.status = 'completed') as revenue
     FROM {$tables['organizations']} o
     ORDER BY revenue DESC LIMIT 10",
    ARRAY_A
);
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Reports', 'rental-gates'); ?></h1>
    <div class="header-actions">
        <select onchange="window.location='?range='+this.value" class="form-select" style="width: auto;">
            <option value="7" <?php selected($range, 7); ?>><?php _e('Last 7 days', 'rental-gates'); ?></option>
            <option value="30" <?php selected($range, 30); ?>><?php _e('Last 30 days', 'rental-gates'); ?></option>
            <option value="90" <?php selected($range, 90); ?>><?php _e('Last 90 days', 'rental-gates'); ?></option>
            <option value="365" <?php selected($range, 365); ?>><?php _e('Last year', 'rental-gates'); ?></option>
        </select>
    </div>
</header>

<div class="admin-content">
    <div class="stats-grid mb-6" style="grid-template-columns: repeat(3, 1fr);">
        <div class="stat-card">
            <div class="stat-icon success">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V7m0 1v8m0 0v1"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value">$<?php echo number_format($stats['revenue']); ?></div>
                <div class="stat-label"><?php _e('Revenue', 'rental-gates'); ?></div>
                <div class="stat-change"><?php echo number_format($stats['payments']); ?> <?php _e('payments', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon primary">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['new_orgs']); ?></div>
                <div class="stat-label"><?php _e('New Organizations', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon warning">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['new_tenants']); ?></div>
                <div class="stat-label"><?php _e('New Tenants', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <div class="stats-grid mb-6" style="grid-template-columns: repeat(2, 1fr);">
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['new_leases']); ?></div>
                <div class="stat-label"><?php _e('New Leases', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['work_orders']); ?></div>
                <div class="stat-label"><?php _e('Work Orders', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <!-- Top Organizations -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><?php _e('Top Organizations by Revenue', 'rental-gates'); ?></h2>
        </div>
        <div class="card-body" style="padding: 0;">
            <?php if (empty($top_orgs)): ?>
            <div class="empty-state">
                <p><?php _e('No data available yet.', 'rental-gates'); ?></p>
            </div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php _e('Organization', 'rental-gates'); ?></th>
                        <th><?php _e('Units', 'rental-gates'); ?></th>
                        <th><?php _e('Total Revenue', 'rental-gates'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $rank = 1; foreach ($top_orgs as $org): ?>
                    <tr>
                        <td style="font-weight: 600; color: var(--gray-400);"><?php echo $rank++; ?></td>
                        <td>
                            <a href="<?php echo home_url('/rental-gates/admin/organizations?id=' . $org['id']); ?>" style="color: var(--primary); text-decoration: none; font-weight: 500;">
                                <?php echo esc_html($org['name']); ?>
                            </a>
                        </td>
                        <td><?php echo number_format($org['units']); ?></td>
                        <td style="font-weight: 600;">$<?php echo number_format($org['revenue']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>
