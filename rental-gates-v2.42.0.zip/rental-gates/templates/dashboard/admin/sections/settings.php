<?php
/**
 * Site Admin - Settings Section
 * 
 * Platform-wide settings and configuration.
 */
if (!defined('ABSPATH')) exit;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['settings_nonce'])) {
    if (wp_verify_nonce($_POST['settings_nonce'], 'admin_settings')) {
        $tab = sanitize_text_field($_POST['settings_tab'] ?? 'general');
        
        if ($tab === 'general') {
            update_option('rental_gates_platform_name', sanitize_text_field($_POST['platform_name']));
            update_option('rental_gates_support_email', sanitize_email($_POST['support_email']));
            update_option('rental_gates_support_phone', sanitize_text_field($_POST['support_phone']));
            update_option('rental_gates_terms_url', esc_url_raw($_POST['terms_url']));
            update_option('rental_gates_privacy_url', esc_url_raw($_POST['privacy_url']));
        }
        
        if ($tab === 'features') {
            update_option('rental_gates_enable_registration', isset($_POST['enable_registration']) ? '1' : '0');
            update_option('rental_gates_enable_trial', isset($_POST['enable_trial']) ? '1' : '0');
            update_option('rental_gates_trial_days', intval($_POST['trial_days']));
            update_option('rental_gates_enable_ai_tools', isset($_POST['enable_ai']) ? '1' : '0');
            update_option('rental_gates_enable_payments', isset($_POST['enable_payments']) ? '1' : '0');
        }
        
        if ($tab === 'email') {
            update_option('rental_gates_email_from_name', sanitize_text_field($_POST['email_from_name']));
            update_option('rental_gates_email_from_address', sanitize_email($_POST['email_from_address']));
            update_option('rental_gates_email_footer_text', wp_kses_post($_POST['email_footer_text']));
        }
        
        if ($tab === 'stripe') {
            update_option('rental_gates_stripe_mode', sanitize_text_field($_POST['stripe_mode']));
            if (!empty($_POST['stripe_test_pk'])) {
                update_option('rental_gates_stripe_test_pk', sanitize_text_field($_POST['stripe_test_pk']));
            }
            if (!empty($_POST['stripe_test_sk'])) {
                update_option('rental_gates_stripe_test_sk', sanitize_text_field($_POST['stripe_test_sk']));
            }
            if (!empty($_POST['stripe_live_pk'])) {
                update_option('rental_gates_stripe_live_pk', sanitize_text_field($_POST['stripe_live_pk']));
            }
            if (!empty($_POST['stripe_live_sk'])) {
                update_option('rental_gates_stripe_live_sk', sanitize_text_field($_POST['stripe_live_sk']));
            }
        }
        
        if ($tab === 'landing') {
            // Basic Configuration
            update_option('rental_gates_landing_page_id', intval($_POST['landing_page_id']));
            update_option('rental_gates_landing_full_page', isset($_POST['landing_full_page']) ? '1' : '0');
            update_option('rental_gates_landing_theme', sanitize_text_field($_POST['landing_theme'] ?? 'modern'));
            
            // Logo Settings
            update_option('rental_gates_landing_use_site_logo', isset($_POST['landing_use_site_logo']) ? '1' : '0');
            update_option('rental_gates_landing_logo_height', intval($_POST['landing_logo_height'] ?? 40));
            
            // Hero Section
            update_option('rental_gates_landing_hero_badge', sanitize_text_field($_POST['landing_hero_badge'] ?? ''));
            update_option('rental_gates_landing_hero_title', sanitize_text_field($_POST['landing_hero_title'] ?? ''));
            update_option('rental_gates_landing_hero_subtitle', sanitize_textarea_field($_POST['landing_hero_subtitle'] ?? ''));
            update_option('rental_gates_landing_hero_cta_text', sanitize_text_field($_POST['landing_hero_cta_text'] ?? ''));
            update_option('rental_gates_landing_hero_cta_secondary', sanitize_text_field($_POST['landing_hero_cta_secondary'] ?? ''));
            update_option('rental_gates_landing_hero_renter_title', sanitize_text_field($_POST['landing_hero_renter_title'] ?? ''));
            update_option('rental_gates_landing_hero_owner_title', sanitize_text_field($_POST['landing_hero_owner_title'] ?? ''));
            update_option('rental_gates_landing_map_cta_text', sanitize_text_field($_POST['landing_map_cta_text'] ?? ''));
            
            // Sections Visibility
            update_option('rental_gates_landing_show_logos', isset($_POST['landing_show_logos']) ? '1' : '0');
            update_option('rental_gates_landing_show_features', isset($_POST['landing_show_features']) ? '1' : '0');
            update_option('rental_gates_landing_show_steps', isset($_POST['landing_show_steps']) ? '1' : '0');
            update_option('rental_gates_landing_show_pricing', isset($_POST['landing_show_pricing']) ? '1' : '0');
            update_option('rental_gates_landing_show_testimonials', isset($_POST['landing_show_testimonials']) ? '1' : '0');
            update_option('rental_gates_landing_show_cta', isset($_POST['landing_show_cta']) ? '1' : '0');
            update_option('rental_gates_landing_show_renter_section', isset($_POST['landing_show_renter_section']) ? '1' : '0');
            
            // Social Proof / Logos
            update_option('rental_gates_landing_logos_title', sanitize_text_field($_POST['landing_logos_title'] ?? ''));
            $logos_text = sanitize_textarea_field($_POST['landing_logos_list'] ?? '');
            update_option('rental_gates_landing_logos_list', $logos_text);
            
            // SEO & Meta
            update_option('rental_gates_landing_meta_title', sanitize_text_field($_POST['landing_meta_title'] ?? ''));
            update_option('rental_gates_landing_meta_description', sanitize_textarea_field($_POST['landing_meta_description'] ?? ''));
            
            // Social Links
            update_option('rental_gates_landing_social_twitter', esc_url_raw($_POST['landing_social_twitter'] ?? ''));
            update_option('rental_gates_landing_social_facebook', esc_url_raw($_POST['landing_social_facebook'] ?? ''));
            update_option('rental_gates_landing_social_linkedin', esc_url_raw($_POST['landing_social_linkedin'] ?? ''));
            update_option('rental_gates_landing_social_instagram', esc_url_raw($_POST['landing_social_instagram'] ?? ''));
            
            // Brand Colors
            update_option('rental_gates_primary_color', sanitize_hex_color($_POST['primary_color'] ?? '#2563eb'));
        }
        
        wp_redirect(add_query_arg(array('tab' => $tab, 'saved' => '1'), home_url('/rental-gates/admin/settings')));
        exit;
    }
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';

// Get settings
$settings = array(
    'platform_name' => get_option('rental_gates_platform_name', 'Rental Gates'),
    'support_email' => get_option('rental_gates_support_email', get_option('admin_email')),
    'support_phone' => get_option('rental_gates_support_phone', ''),
    'terms_url' => get_option('rental_gates_terms_url', ''),
    'privacy_url' => get_option('rental_gates_privacy_url', ''),
    'enable_registration' => get_option('rental_gates_enable_registration', '1'),
    'enable_trial' => get_option('rental_gates_enable_trial', '1'),
    'trial_days' => get_option('rental_gates_trial_days', 14),
    'enable_ai' => get_option('rental_gates_enable_ai_tools', '0'),
    'enable_payments' => get_option('rental_gates_enable_payments', '1'),
    'email_from_name' => get_option('rental_gates_email_from_name', get_bloginfo('name')),
    'email_from_address' => get_option('rental_gates_email_from_address', get_option('admin_email')),
    'email_footer_text' => get_option('rental_gates_email_footer_text', ''),
    'stripe_mode' => get_option('rental_gates_stripe_mode', 'test'),
    'stripe_test_pk' => get_option('rental_gates_stripe_test_pk', ''),
    'stripe_test_sk' => get_option('rental_gates_stripe_test_sk', ''),
    'stripe_live_pk' => get_option('rental_gates_stripe_live_pk', ''),
    'stripe_live_sk' => get_option('rental_gates_stripe_live_sk', ''),
    'landing_page_id' => get_option('rental_gates_landing_page_id', 0),
    'landing_full_page' => get_option('rental_gates_landing_full_page', '1'),
    'landing_theme' => get_option('rental_gates_landing_theme', 'modern'),
    
    // Logo Settings
    'landing_use_site_logo' => get_option('rental_gates_landing_use_site_logo', '1'),
    'landing_logo_height' => get_option('rental_gates_landing_logo_height', 40),
    
    // Hero Section
    'landing_hero_badge' => get_option('rental_gates_landing_hero_badge', ''),
    'landing_hero_title' => get_option('rental_gates_landing_hero_title', ''),
    'landing_hero_subtitle' => get_option('rental_gates_landing_hero_subtitle', ''),
    'landing_hero_cta_text' => get_option('rental_gates_landing_hero_cta_text', ''),
    'landing_hero_cta_secondary' => get_option('rental_gates_landing_hero_cta_secondary', ''),
    'landing_hero_renter_title' => get_option('rental_gates_landing_hero_renter_title', ''),
    'landing_hero_owner_title' => get_option('rental_gates_landing_hero_owner_title', ''),
    'landing_map_cta_text' => get_option('rental_gates_landing_map_cta_text', ''),
    
    // Sections Visibility
    'landing_show_logos' => get_option('rental_gates_landing_show_logos', '1'),
    'landing_show_features' => get_option('rental_gates_landing_show_features', '1'),
    'landing_show_steps' => get_option('rental_gates_landing_show_steps', '1'),
    'landing_show_pricing' => get_option('rental_gates_landing_show_pricing', '1'),
    'landing_show_testimonials' => get_option('rental_gates_landing_show_testimonials', '1'),
    'landing_show_cta' => get_option('rental_gates_landing_show_cta', '1'),
    'landing_show_renter_section' => get_option('rental_gates_landing_show_renter_section', '1'),
    
    // Social Proof / Logos
    'landing_logos_title' => get_option('rental_gates_landing_logos_title', ''),
    'landing_logos_list' => get_option('rental_gates_landing_logos_list', ''),
    
    // SEO & Meta
    'landing_meta_title' => get_option('rental_gates_landing_meta_title', ''),
    'landing_meta_description' => get_option('rental_gates_landing_meta_description', ''),
    
    // Social Links
    'landing_social_twitter' => get_option('rental_gates_landing_social_twitter', ''),
    'landing_social_facebook' => get_option('rental_gates_landing_social_facebook', ''),
    'landing_social_linkedin' => get_option('rental_gates_landing_social_linkedin', ''),
    'landing_social_instagram' => get_option('rental_gates_landing_social_instagram', ''),
    
    'primary_color' => get_option('rental_gates_primary_color', '#2563eb'),
);

// Get pages for dropdown
$pages = get_pages(array('post_status' => 'publish'));
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Settings', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <?php if (isset($_GET['saved'])): ?>
    <div class="alert alert-success mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?php _e('Settings saved successfully.', 'rental-gates'); ?>
    </div>
    <?php endif; ?>
    
    <!-- Tabs -->
    <div class="tabs">
        <a href="<?php echo home_url('/rental-gates/admin/settings?tab=general'); ?>" class="tab <?php echo $current_tab === 'general' ? 'active' : ''; ?>">
            <?php _e('General', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/settings?tab=features'); ?>" class="tab <?php echo $current_tab === 'features' ? 'active' : ''; ?>">
            <?php _e('Features', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/settings?tab=landing'); ?>" class="tab <?php echo $current_tab === 'landing' ? 'active' : ''; ?>">
            <?php _e('Landing Page', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/settings?tab=email'); ?>" class="tab <?php echo $current_tab === 'email' ? 'active' : ''; ?>">
            <?php _e('Email', 'rental-gates'); ?>
        </a>
        <a href="<?php echo home_url('/rental-gates/admin/settings?tab=stripe'); ?>" class="tab <?php echo $current_tab === 'stripe' ? 'active' : ''; ?>">
            <?php _e('Stripe', 'rental-gates'); ?>
        </a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <?php if ($current_tab === 'general'): ?>
            <!-- General Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_settings', 'settings_nonce'); ?>
                <input type="hidden" name="settings_tab" value="general">
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Platform Name', 'rental-gates'); ?></label>
                    <input type="text" name="platform_name" class="form-input" value="<?php echo esc_attr($settings['platform_name']); ?>">
                    <div class="form-hint"><?php _e('The name displayed throughout the platform.', 'rental-gates'); ?></div>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Support Email', 'rental-gates'); ?></label>
                        <input type="email" name="support_email" class="form-input" value="<?php echo esc_attr($settings['support_email']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Support Phone', 'rental-gates'); ?></label>
                        <input type="text" name="support_phone" class="form-input" value="<?php echo esc_attr($settings['support_phone']); ?>">
                    </div>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Terms of Service URL', 'rental-gates'); ?></label>
                        <input type="url" name="terms_url" class="form-input" value="<?php echo esc_attr($settings['terms_url']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Privacy Policy URL', 'rental-gates'); ?></label>
                        <input type="url" name="privacy_url" class="form-input" value="<?php echo esc_attr($settings['privacy_url']); ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            
            <?php elseif ($current_tab === 'features'): ?>
            <!-- Feature Flags -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_settings', 'settings_nonce'); ?>
                <input type="hidden" name="settings_tab" value="features">
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="enable_registration" value="1" <?php checked($settings['enable_registration'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable Registration', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('Allow new organizations to register.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="enable_trial" value="1" <?php checked($settings['enable_trial'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable Trial Period', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('New organizations start with a free trial.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <div class="form-group" style="margin-left: 32px;">
                    <label class="form-label"><?php _e('Trial Period (Days)', 'rental-gates'); ?></label>
                    <input type="number" name="trial_days" class="form-input" value="<?php echo esc_attr($settings['trial_days']); ?>" min="1" max="90" style="max-width: 100px;">
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="enable_ai" value="1" <?php checked($settings['enable_ai'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable AI Features', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('AI-powered screening, suggestions, and insights.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                        <input type="checkbox" name="enable_payments" value="1" <?php checked($settings['enable_payments'], '1'); ?> style="width: 20px; height: 20px;">
                        <div>
                            <div style="font-weight: 500;"><?php _e('Enable Online Payments', 'rental-gates'); ?></div>
                            <div class="form-hint" style="margin-top: 2px;"><?php _e('Allow tenants to pay rent online via Stripe.', 'rental-gates'); ?></div>
                        </div>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            
            <?php elseif ($current_tab === 'email'): ?>
            <!-- Email Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_settings', 'settings_nonce'); ?>
                <input type="hidden" name="settings_tab" value="email">
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label"><?php _e('From Name', 'rental-gates'); ?></label>
                        <input type="text" name="email_from_name" class="form-input" value="<?php echo esc_attr($settings['email_from_name']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('From Email Address', 'rental-gates'); ?></label>
                        <input type="email" name="email_from_address" class="form-input" value="<?php echo esc_attr($settings['email_from_address']); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Email Footer Text', 'rental-gates'); ?></label>
                    <textarea name="email_footer_text" class="form-textarea" rows="3"><?php echo esc_textarea($settings['email_footer_text']); ?></textarea>
                    <div class="form-hint"><?php _e('Additional text to appear in email footers.', 'rental-gates'); ?></div>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            
            <?php elseif ($current_tab === 'stripe'): ?>
            <!-- Stripe Settings -->
            <form method="post" action="">
                <?php wp_nonce_field('admin_settings', 'settings_nonce'); ?>
                <input type="hidden" name="settings_tab" value="stripe">
                
                <div class="alert alert-info mb-6">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                        <?php _e('Get your API keys from the', 'rental-gates'); ?> 
                        <a href="https://dashboard.stripe.com/apikeys" target="_blank" style="color: inherit; font-weight: 500;">Stripe Dashboard</a>.
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Mode', 'rental-gates'); ?></label>
                    <select name="stripe_mode" class="form-select" style="max-width: 200px;">
                        <option value="test" <?php selected($settings['stripe_mode'], 'test'); ?>><?php _e('Test Mode', 'rental-gates'); ?></option>
                        <option value="live" <?php selected($settings['stripe_mode'], 'live'); ?>><?php _e('Live Mode', 'rental-gates'); ?></option>
                    </select>
                </div>
                
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600;"><?php _e('Test Keys', 'rental-gates'); ?></h3>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Publishable Key', 'rental-gates'); ?></label>
                        <input type="text" name="stripe_test_pk" class="form-input font-mono" value="<?php echo esc_attr($settings['stripe_test_pk']); ?>" placeholder="pk_test_...">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Secret Key', 'rental-gates'); ?></label>
                        <input type="password" name="stripe_test_sk" class="form-input font-mono" placeholder="<?php echo $settings['stripe_test_sk'] ? '••••••••••••••••' : 'sk_test_...'; ?>">
                    </div>
                </div>
                
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600;"><?php _e('Live Keys', 'rental-gates'); ?></h3>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Publishable Key', 'rental-gates'); ?></label>
                        <input type="text" name="stripe_live_pk" class="form-input font-mono" value="<?php echo esc_attr($settings['stripe_live_pk']); ?>" placeholder="pk_live_...">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Secret Key', 'rental-gates'); ?></label>
                        <input type="password" name="stripe_live_sk" class="form-input font-mono" placeholder="<?php echo $settings['stripe_live_sk'] ? '••••••••••••••••' : 'sk_live_...'; ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
            </form>
            
            <?php elseif ($current_tab === 'landing'): ?>
            <!-- Landing Page Settings -->
            <?php 
            // Get WordPress site logo
            $site_logo_id = get_theme_mod('custom_logo');
            $site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'medium') : '';
            ?>
            <form method="post" action="">
                <?php wp_nonce_field('admin_settings', 'settings_nonce'); ?>
                <input type="hidden" name="settings_tab" value="landing">
                
                <div class="alert alert-info mb-6">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                        <?php _e('Configure the premium landing page. Select a page to auto-render, or use the shortcode <code>[rental_gates_landing]</code> on any page.', 'rental-gates'); ?>
                    </div>
                </div>
                
                <!-- ==================== PAGE CONFIGURATION ==================== -->
                <h3 style="margin: 0 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <?php _e('Page Configuration', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Home/Landing Page', 'rental-gates'); ?></label>
                    <select name="landing_page_id" class="form-select">
                        <option value="0"><?php _e('— Select a page —', 'rental-gates'); ?></option>
                        <?php foreach ($pages as $page): ?>
                        <option value="<?php echo $page->ID; ?>" <?php selected($settings['landing_page_id'], $page->ID); ?>>
                            <?php echo esc_html($page->post_title); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-checkbox">
                        <input type="checkbox" name="landing_full_page" value="1" <?php checked($settings['landing_full_page'], '1'); ?>>
                        <span><?php _e('Use full-page template (replaces theme template)', 'rental-gates'); ?></span>
                    </label>
                </div>
                
                <!-- ==================== DESIGN THEME ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>
                    <?php _e('Design Theme', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; max-width: 600px;">
                        <label style="display: block; cursor: pointer;">
                            <input type="radio" name="landing_theme" value="modern" <?php checked($settings['landing_theme'], 'modern'); ?> style="position: absolute; opacity: 0; pointer-events: none;">
                            <div class="theme-card" style="border: 2px solid <?php echo $settings['landing_theme'] === 'modern' ? esc_attr($settings['primary_color']) : '#e5e7eb'; ?>; border-radius: 12px; padding: 16px; transition: all 0.2s; background: <?php echo $settings['landing_theme'] === 'modern' ? 'rgba(59,130,246,0.05)' : '#fff'; ?>;">
                                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #3b82f6, #8b5cf6); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                        <svg width="20" height="20" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 700; color: #111827;"><?php _e('Modern', 'rental-gates'); ?></div>
                                        <div style="font-size: 12px; color: #6b7280;"><?php _e('Bold & Animated', 'rental-gates'); ?></div>
                                    </div>
                                </div>
                                <p style="font-size: 13px; color: #6b7280; margin: 0; line-height: 1.5;"><?php _e('Gradient buttons, glassmorphism header, animated elements.', 'rental-gates'); ?></p>
                            </div>
                        </label>
                        
                        <label style="display: block; cursor: pointer;">
                            <input type="radio" name="landing_theme" value="minimal" <?php checked($settings['landing_theme'], 'minimal'); ?> style="position: absolute; opacity: 0; pointer-events: none;">
                            <div class="theme-card" style="border: 2px solid <?php echo $settings['landing_theme'] === 'minimal' ? esc_attr($settings['primary_color']) : '#e5e7eb'; ?>; border-radius: 12px; padding: 16px; transition: all 0.2s; background: <?php echo $settings['landing_theme'] === 'minimal' ? 'rgba(59,130,246,0.05)' : '#fff'; ?>;">
                                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                    <div style="width: 40px; height: 40px; background: #111827; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                        <svg width="20" height="20" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h7"/></svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 700; color: #111827;"><?php _e('Minimal', 'rental-gates'); ?></div>
                                        <div style="font-size: 12px; color: #6b7280;"><?php _e('Clean & Editorial', 'rental-gates'); ?></div>
                                    </div>
                                </div>
                                <p style="font-size: 13px; color: #6b7280; margin: 0; line-height: 1.5;"><?php _e('Simple layouts, clean typography, subtle animations.', 'rental-gates'); ?></p>
                            </div>
                        </label>
                    </div>
                </div>
                
                <style>
                .theme-card:hover { border-color: <?php echo esc_attr($settings['primary_color']); ?> !important; }
                input[type="radio"]:checked + .theme-card { border-color: <?php echo esc_attr($settings['primary_color']); ?> !important; background: rgba(59,130,246,0.05) !important; }
                </style>
                
                <!-- ==================== LOGO SETTINGS ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <?php _e('Logo Settings', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <label class="form-checkbox">
                        <input type="checkbox" name="landing_use_site_logo" value="1" <?php checked($settings['landing_use_site_logo'], '1'); ?>>
                        <span><?php _e('Use WordPress Site Logo', 'rental-gates'); ?></span>
                    </label>
                    <?php if ($site_logo_url): ?>
                    <div style="margin-top: 12px; padding: 16px; background: #f9fafb; border-radius: 8px; display: inline-flex; align-items: center; gap: 12px;">
                        <img src="<?php echo esc_url($site_logo_url); ?>" alt="Site Logo" style="max-height: 40px; width: auto;">
                        <span style="font-size: 13px; color: #6b7280;"><?php _e('Current site logo', 'rental-gates'); ?></span>
                    </div>
                    <?php else: ?>
                    <p class="form-help" style="color: #f59e0b;">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: inline; vertical-align: middle;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                        <?php _e('No site logo set. Go to Appearance → Customize → Site Identity to set one.', 'rental-gates'); ?>
                    </p>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Logo Height (px)', 'rental-gates'); ?></label>
                    <input type="number" name="landing_logo_height" value="<?php echo esc_attr($settings['landing_logo_height']); ?>" min="20" max="80" style="width: 100px;" class="form-input">
                    <p class="form-help"><?php _e('Height of the logo in the header. Width will scale proportionally.', 'rental-gates'); ?></p>
                </div>
                
                <!-- ==================== HERO SECTION ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    <?php _e('Hero Section Content', 'rental-gates'); ?>
                </h3>
                
                <p style="font-size: 13px; color: #6b7280; margin-bottom: 16px;"><?php _e('Leave fields empty to use default content.', 'rental-gates'); ?></p>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Badge Text', 'rental-gates'); ?></label>
                    <input type="text" name="landing_hero_badge" value="<?php echo esc_attr($settings['landing_hero_badge']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., Now with AI-Powered Tools', 'rental-gates'); ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Main Headline', 'rental-gates'); ?></label>
                    <input type="text" name="landing_hero_title" value="<?php echo esc_attr($settings['landing_hero_title']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., Property Management Made Simple', 'rental-gates'); ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Subtitle / Description', 'rental-gates'); ?></label>
                    <textarea name="landing_hero_subtitle" rows="2" class="form-textarea" placeholder="<?php esc_attr_e('e.g., Streamline your rental business with an all-in-one platform...', 'rental-gates'); ?>"><?php echo esc_textarea($settings['landing_hero_subtitle']); ?></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Primary CTA Button Text', 'rental-gates'); ?></label>
                        <input type="text" name="landing_hero_cta_text" value="<?php echo esc_attr($settings['landing_hero_cta_text']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., Start Free Trial', 'rental-gates'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Secondary CTA Button Text', 'rental-gates'); ?></label>
                        <input type="text" name="landing_hero_cta_secondary" value="<?php echo esc_attr($settings['landing_hero_cta_secondary']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., See Features', 'rental-gates'); ?>">
                    </div>
                </div>
                
                <div style="margin: 24px 0; padding: 16px; background: #f0f9ff; border-left: 4px solid #0ea5e9; border-radius: 4px;">
                    <p style="margin: 0 0 12px 0; font-weight: 600; color: #0c4a6e;"><?php _e('Dual-Audience Settings', 'rental-gates'); ?></p>
                    <p style="margin: 0 0 16px 0; font-size: 13px; color: #075985;"><?php _e('Customize the dual-audience hero cards for renters and property managers.', 'rental-gates'); ?></p>
                    
                    <div class="form-group" style="margin-bottom: 16px;">
                        <label class="form-label"><?php _e('Renter Card Title', 'rental-gates'); ?></label>
                        <input type="text" name="landing_hero_renter_title" value="<?php echo esc_attr($settings['landing_hero_renter_title']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., I\'m Looking for a Rental', 'rental-gates'); ?>">
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 16px;">
                        <label class="form-label"><?php _e('Owner Card Title', 'rental-gates'); ?></label>
                        <input type="text" name="landing_hero_owner_title" value="<?php echo esc_attr($settings['landing_hero_owner_title']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., I Manage Properties', 'rental-gates'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Map CTA Button Text', 'rental-gates'); ?></label>
                        <input type="text" name="landing_map_cta_text" value="<?php echo esc_attr($settings['landing_map_cta_text']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., Browse Map', 'rental-gates'); ?>">
                    </div>
                </div>
                
                <!-- ==================== SECTIONS VISIBILITY ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
                    <?php _e('Sections Visibility', 'rental-gates'); ?>
                </h3>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; max-width: 600px;">
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_logos" value="1" <?php checked($settings['landing_show_logos'], '1'); ?>>
                        <span><?php _e('Trust Badges', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_features" value="1" <?php checked($settings['landing_show_features'], '1'); ?>>
                        <span><?php _e('Features', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_steps" value="1" <?php checked($settings['landing_show_steps'], '1'); ?>>
                        <span><?php _e('How It Works', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_pricing" value="1" <?php checked($settings['landing_show_pricing'], '1'); ?>>
                        <span><?php _e('Pricing', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_testimonials" value="1" <?php checked($settings['landing_show_testimonials'], '1'); ?>>
                        <span><?php _e('Testimonials', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_cta" value="1" <?php checked($settings['landing_show_cta'], '1'); ?>>
                        <span><?php _e('Final CTA', 'rental-gates'); ?></span>
                    </label>
                    
                    <label class="form-checkbox" style="padding: 12px; background: #f9fafb; border-radius: 8px;">
                        <input type="checkbox" name="landing_show_renter_section" value="1" <?php checked($settings['landing_show_renter_section'], '1'); ?>>
                        <span><?php _e('Renter Section', 'rental-gates'); ?></span>
                    </label>
                </div>
                
                <!-- ==================== TRUST BADGES / LOGOS ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    <?php _e('Trust Badges / Company Logos', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Section Title', 'rental-gates'); ?></label>
                    <input type="text" name="landing_logos_title" value="<?php echo esc_attr($settings['landing_logos_title']); ?>" class="form-input" placeholder="<?php esc_attr_e('e.g., Trusted by property managers worldwide', 'rental-gates'); ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Company Names', 'rental-gates'); ?></label>
                    <textarea name="landing_logos_list" rows="3" class="form-textarea" placeholder="<?php esc_attr_e("Apex Properties\nUrban Living\nPrime Rentals\nMetro Housing\nSkyline Mgmt", 'rental-gates'); ?>"><?php echo esc_textarea($settings['landing_logos_list']); ?></textarea>
                    <p class="form-help"><?php _e('Enter one company name per line. These appear as text badges in the trust section.', 'rental-gates'); ?></p>
                </div>
                
                <!-- ==================== SOCIAL MEDIA LINKS ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                    <?php _e('Social Media Links', 'rental-gates'); ?>
                </h3>
                
                <p style="font-size: 13px; color: #6b7280; margin-bottom: 16px;"><?php _e('Add your social media profile URLs. Leave empty to hide the icon.', 'rental-gates'); ?></p>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label"><?php _e('Twitter / X', 'rental-gates'); ?></label>
                        <input type="url" name="landing_social_twitter" value="<?php echo esc_url($settings['landing_social_twitter']); ?>" class="form-input" placeholder="https://twitter.com/yourprofile">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Facebook', 'rental-gates'); ?></label>
                        <input type="url" name="landing_social_facebook" value="<?php echo esc_url($settings['landing_social_facebook']); ?>" class="form-input" placeholder="https://facebook.com/yourpage">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('LinkedIn', 'rental-gates'); ?></label>
                        <input type="url" name="landing_social_linkedin" value="<?php echo esc_url($settings['landing_social_linkedin']); ?>" class="form-input" placeholder="https://linkedin.com/company/yourcompany">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Instagram', 'rental-gates'); ?></label>
                        <input type="url" name="landing_social_instagram" value="<?php echo esc_url($settings['landing_social_instagram']); ?>" class="form-input" placeholder="https://instagram.com/yourprofile">
                    </div>
                </div>
                
                <!-- ==================== SEO & META ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <?php _e('SEO & Meta Tags', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Meta Title', 'rental-gates'); ?></label>
                    <input type="text" name="landing_meta_title" value="<?php echo esc_attr($settings['landing_meta_title']); ?>" class="form-input" placeholder="<?php echo esc_attr($settings['platform_name']); ?> - Modern Property Management" maxlength="70">
                    <p class="form-help"><?php _e('Recommended: 50-60 characters. Leave empty to use default.', 'rental-gates'); ?></p>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Meta Description', 'rental-gates'); ?></label>
                    <textarea name="landing_meta_description" rows="2" class="form-textarea" maxlength="160" placeholder="<?php esc_attr_e('Streamline your property management with modern tools for buildings, tenants, leases, and payments.', 'rental-gates'); ?>"><?php echo esc_textarea($settings['landing_meta_description']); ?></textarea>
                    <p class="form-help"><?php _e('Recommended: 150-160 characters. Leave empty to use default.', 'rental-gates'); ?></p>
                </div>
                
                <!-- ==================== BRAND COLORS ==================== -->
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>
                    <?php _e('Brand Colors', 'rental-gates'); ?>
                </h3>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Primary Color', 'rental-gates'); ?></label>
                    <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                        <input type="color" name="primary_color" id="primary_color" value="<?php echo esc_attr($settings['primary_color']); ?>" style="width: 60px; height: 40px; padding: 0; border: 1px solid #d1d5db; border-radius: 6px; cursor: pointer;">
                        <input type="text" id="primary_color_hex" value="<?php echo esc_attr($settings['primary_color']); ?>" style="width: 100px; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-family: monospace;" pattern="^#[0-9A-Fa-f]{6}$">
                        <div style="display: flex; gap: 8px;">
                            <button type="button" class="color-preset" data-color="#2563eb" style="width: 28px; height: 28px; background: #2563eb; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Blue"></button>
                            <button type="button" class="color-preset" data-color="#0d9488" style="width: 28px; height: 28px; background: #0d9488; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Teal"></button>
                            <button type="button" class="color-preset" data-color="#7c3aed" style="width: 28px; height: 28px; background: #7c3aed; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Purple"></button>
                            <button type="button" class="color-preset" data-color="#dc2626" style="width: 28px; height: 28px; background: #dc2626; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Red"></button>
                            <button type="button" class="color-preset" data-color="#ea580c" style="width: 28px; height: 28px; background: #ea580c; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Orange"></button>
                            <button type="button" class="color-preset" data-color="#059669" style="width: 28px; height: 28px; background: #059669; border: 2px solid #fff; border-radius: 50%; cursor: pointer; box-shadow: 0 0 0 1px #d1d5db;" title="Green"></button>
                        </div>
                    </div>
                    <p class="form-help"><?php _e('Primary brand color for buttons, links, and accents.', 'rental-gates'); ?></p>
                </div>
                
                <script>
                (function() {
                    var colorInput = document.getElementById('primary_color');
                    var hexInput = document.getElementById('primary_color_hex');
                    var presets = document.querySelectorAll('.color-preset');
                    
                    colorInput.addEventListener('input', function() {
                        hexInput.value = this.value;
                    });
                    
                    hexInput.addEventListener('input', function() {
                        if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                            colorInput.value = this.value;
                        }
                    });
                    
                    presets.forEach(function(btn) {
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                            var color = this.dataset.color;
                            colorInput.value = color;
                            hexInput.value = color;
                        });
                    });
                })();
                </script>
                
                <h3 style="margin: 32px 0 16px; font-size: 16px; font-weight: 600;"><?php _e('Available Shortcodes', 'rental-gates'); ?></h3>
                
                <div class="shortcode-list" style="background: #f9fafb; border-radius: 8px; padding: 16px;">
                    <div style="margin-bottom: 12px;">
                        <code style="background: #fff; padding: 4px 8px; border-radius: 4px; font-size: 13px;">[rental_gates_landing]</code>
                        <span style="margin-left: 12px; color: #6b7280; font-size: 14px;"><?php _e('Full landing page', 'rental-gates'); ?></span>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <code style="background: #fff; padding: 4px 8px; border-radius: 4px; font-size: 13px;">[rental_gates_search]</code>
                        <span style="margin-left: 12px; color: #6b7280; font-size: 14px;"><?php _e('Property search widget', 'rental-gates'); ?></span>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <code style="background: #fff; padding: 4px 8px; border-radius: 4px; font-size: 13px;">[rental_gates_property id="123" type="unit"]</code>
                        <span style="margin-left: 12px; color: #6b7280; font-size: 14px;"><?php _e('Single property card', 'rental-gates'); ?></span>
                    </div>
                    <div>
                        <code style="background: #fff; padding: 4px 8px; border-radius: 4px; font-size: 13px;">[rental_gates_apply unit_id="123"]</code>
                        <span style="margin-left: 12px; color: #6b7280; font-size: 14px;"><?php _e('Application button', 'rental-gates'); ?></span>
                    </div>
                </div>
                
                <div style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary"><?php _e('Save Settings', 'rental-gates'); ?></button>
                    
                    <?php if ($settings['landing_page_id']): ?>
                    <a href="<?php echo get_permalink($settings['landing_page_id']); ?>" class="btn btn-secondary" target="_blank" style="margin-left: 12px;">
                        <?php _e('Preview Landing Page', 'rental-gates'); ?>
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-left: 4px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    </a>
                    <?php endif; ?>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
