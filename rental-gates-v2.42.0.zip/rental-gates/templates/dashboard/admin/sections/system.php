<?php
/**
 * Site Admin - System Health Section
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

// System info
$system = array(
    'php_version' => phpversion(),
    'wp_version' => get_bloginfo('version'),
    'mysql_version' => $wpdb->db_version(),
    'plugin_version' => RENTAL_GATES_VERSION,
    'memory_limit' => ini_get('memory_limit'),
    'max_upload' => ini_get('upload_max_filesize'),
    'max_post' => ini_get('post_max_size'),
    'max_execution' => ini_get('max_execution_time'),
    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'php_sapi' => php_sapi_name(),
);

// Database stats
$db_stats = array();
foreach ($tables as $name => $table) {
    $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    $db_stats[$name] = intval($count);
}

// Health checks
$checks = array();

// PHP Version
$checks['php'] = array(
    'label' => __('PHP Version', 'rental-gates'),
    'value' => $system['php_version'],
    'status' => version_compare($system['php_version'], '8.0', '>=') ? 'success' : (version_compare($system['php_version'], '7.4', '>=') ? 'warning' : 'danger'),
    'message' => version_compare($system['php_version'], '8.0', '>=') ? __('Recommended version', 'rental-gates') : __('Consider upgrading', 'rental-gates'),
);

// Memory Limit
$memory_bytes = wp_convert_hr_to_bytes($system['memory_limit']);
$checks['memory'] = array(
    'label' => __('Memory Limit', 'rental-gates'),
    'value' => $system['memory_limit'],
    'status' => $memory_bytes >= 256 * MB_IN_BYTES ? 'success' : ($memory_bytes >= 128 * MB_IN_BYTES ? 'warning' : 'danger'),
    'message' => $memory_bytes >= 256 * MB_IN_BYTES ? __('Sufficient', 'rental-gates') : __('Recommend 256M+', 'rental-gates'),
);

// Upload Size
$upload_bytes = wp_convert_hr_to_bytes($system['max_upload']);
$checks['upload'] = array(
    'label' => __('Max Upload Size', 'rental-gates'),
    'value' => $system['max_upload'],
    'status' => $upload_bytes >= 32 * MB_IN_BYTES ? 'success' : ($upload_bytes >= 8 * MB_IN_BYTES ? 'warning' : 'danger'),
    'message' => $upload_bytes >= 32 * MB_IN_BYTES ? __('Sufficient', 'rental-gates') : __('Recommend 32M+', 'rental-gates'),
);

// Extensions
$required_extensions = array('gd', 'curl', 'json', 'mbstring', 'openssl');
$missing_extensions = array();
foreach ($required_extensions as $ext) {
    if (!extension_loaded($ext)) {
        $missing_extensions[] = $ext;
    }
}

$checks['extensions'] = array(
    'label' => __('PHP Extensions', 'rental-gates'),
    'value' => empty($missing_extensions) ? __('All installed', 'rental-gates') : implode(', ', $missing_extensions) . ' ' . __('missing', 'rental-gates'),
    'status' => empty($missing_extensions) ? 'success' : 'danger',
    'message' => empty($missing_extensions) ? __('All required extensions present', 'rental-gates') : __('Install missing extensions', 'rental-gates'),
);

// Directory Permissions
$upload_dir = wp_upload_dir();
$checks['uploads'] = array(
    'label' => __('Uploads Directory', 'rental-gates'),
    'value' => is_writable($upload_dir['basedir']) ? __('Writable', 'rental-gates') : __('Not Writable', 'rental-gates'),
    'status' => is_writable($upload_dir['basedir']) ? 'success' : 'danger',
    'message' => is_writable($upload_dir['basedir']) ? __('OK', 'rental-gates') : __('Fix permissions', 'rental-gates'),
);

// SSL
$checks['ssl'] = array(
    'label' => __('SSL Certificate', 'rental-gates'),
    'value' => is_ssl() ? __('Active', 'rental-gates') : __('Not Active', 'rental-gates'),
    'status' => is_ssl() ? 'success' : 'warning',
    'message' => is_ssl() ? __('Site is secure', 'rental-gates') : __('Recommend enabling SSL', 'rental-gates'),
);

// Database Connection
$db_check = $wpdb->get_var("SELECT 1");
$checks['database'] = array(
    'label' => __('Database Connection', 'rental-gates'),
    'value' => $db_check ? __('Connected', 'rental-gates') : __('Error', 'rental-gates'),
    'status' => $db_check ? 'success' : 'danger',
    'message' => $db_check ? __('Working properly', 'rental-gates') : __('Check database settings', 'rental-gates'),
);

// Cron
$checks['cron'] = array(
    'label' => __('WP Cron', 'rental-gates'),
    'value' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ? __('Disabled', 'rental-gates') : __('Enabled', 'rental-gates'),
    'status' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ? 'warning' : 'success',
    'message' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ? __('Use server cron instead', 'rental-gates') : __('OK', 'rental-gates'),
);

// Overall status
$has_errors = false;
$has_warnings = false;
foreach ($checks as $check) {
    if ($check['status'] === 'danger') $has_errors = true;
    if ($check['status'] === 'warning') $has_warnings = true;
}
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('System Health', 'rental-gates'); ?></h1>
    <div class="header-actions">
        <span class="badge badge-<?php echo $has_errors ? 'danger' : ($has_warnings ? 'warning' : 'success'); ?>" style="font-size: 14px; padding: 8px 16px;">
            <?php 
            if ($has_errors) {
                _e('Issues Found', 'rental-gates');
            } elseif ($has_warnings) {
                _e('Warnings', 'rental-gates');
            } else {
                _e('All Good', 'rental-gates');
            }
            ?>
        </span>
    </div>
</header>

<div class="admin-content">
    <!-- Health Checks -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title"><?php _e('Health Checks', 'rental-gates'); ?></h2>
        </div>
        <div class="card-body" style="padding: 0;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th><?php _e('Check', 'rental-gates'); ?></th>
                        <th><?php _e('Value', 'rental-gates'); ?></th>
                        <th><?php _e('Status', 'rental-gates'); ?></th>
                        <th><?php _e('Note', 'rental-gates'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($checks as $check): ?>
                    <tr>
                        <td style="font-weight: 500;"><?php echo esc_html($check['label']); ?></td>
                        <td><?php echo esc_html($check['value']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $check['status']; ?>">
                                <?php 
                                if ($check['status'] === 'success') echo '✓';
                                elseif ($check['status'] === 'warning') echo '!';
                                else echo '✗';
                                ?>
                            </span>
                        </td>
                        <td class="text-muted"><?php echo esc_html($check['message']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="grid-2">
        <!-- Server Info -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Server Information', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('Plugin Version', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500;"><?php echo esc_html($system['plugin_version']); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('WordPress', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500;"><?php echo esc_html($system['wp_version']); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('PHP', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500;"><?php echo esc_html($system['php_version']); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('MySQL', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500;"><?php echo esc_html($system['mysql_version']); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('Server', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500; font-size: 12px;"><?php echo esc_html($system['server_software']); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: var(--gray-500);"><?php _e('Max Execution Time', 'rental-gates'); ?></td>
                        <td style="padding: 8px 0; text-align: right; font-weight: 500;"><?php echo esc_html($system['max_execution']); ?>s</td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- Database Stats -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Database Statistics', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <?php foreach ($db_stats as $name => $count): ?>
                    <tr>
                        <td style="padding: 6px 0; color: var(--gray-500); font-size: 13px;"><?php echo esc_html(ucwords(str_replace('_', ' ', $name))); ?></td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 500;"><?php echo number_format($count); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
</div>
