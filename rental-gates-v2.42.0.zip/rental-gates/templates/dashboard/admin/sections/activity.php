<?php
/**
 * Site Admin - Activity Log Section
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$action_filter = isset($_GET['action_type']) ? sanitize_text_field($_GET['action_type']) : '';
$page_num = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 50;
$offset = ($page_num - 1) * $per_page;

// Build query
$where = array("1=1");
$params = array();

if ($search) {
    $where[] = "(u.display_name LIKE %s OR a.action LIKE %s)";
    $params[] = '%' . $wpdb->esc_like($search) . '%';
    $params[] = '%' . $wpdb->esc_like($search) . '%';
}

if ($action_filter) {
    $where[] = "a.action = %s";
    $params[] = $action_filter;
}

$where_clause = implode(' AND ', $where);

// Get total
$total_query = "SELECT COUNT(*) FROM {$tables['activity_log']} a LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID WHERE $where_clause";
$total = $wpdb->get_var($params ? $wpdb->prepare($total_query, $params) : $total_query);

// Get activities
$query = "SELECT a.*, u.display_name as user_name, u.user_email
          FROM {$tables['activity_log']} a
          LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
          WHERE $where_clause
          ORDER BY a.created_at DESC
          LIMIT %d OFFSET %d";

$all_params = array_merge($params, array($per_page, $offset));
$activities = $wpdb->get_results($wpdb->prepare($query, $all_params), ARRAY_A);

// Get unique actions for filter
$actions = $wpdb->get_col("SELECT DISTINCT action FROM {$tables['activity_log']} ORDER BY action ASC");
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Activity Log', 'rental-gates'); ?></h1>
    <div class="header-actions">
        <span class="text-muted"><?php printf(__('%s total entries', 'rental-gates'), number_format($total)); ?></span>
    </div>
</header>

<div class="admin-content">
    <!-- Filters -->
    <div class="card mb-6">
        <div class="card-body" style="padding: 16px 24px;">
            <form method="get" action="<?php echo home_url('/rental-gates/admin/activity'); ?>" style="display: flex; gap: 16px; align-items: center;">
                <div class="search-box" style="flex: 1;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search...', 'rental-gates'); ?>">
                </div>
                
                <select name="action_type" class="form-select" style="width: auto;">
                    <option value=""><?php _e('All Actions', 'rental-gates'); ?></option>
                    <?php foreach ($actions as $action): ?>
                    <option value="<?php echo esc_attr($action); ?>" <?php selected($action_filter, $action); ?>>
                        <?php echo esc_html(ucwords(str_replace('_', ' ', $action))); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <button type="submit" class="btn btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
            </form>
        </div>
    </div>
    
    <!-- Activity Table -->
    <div class="card">
        <div class="card-body" style="padding: 0;">
            <?php if (empty($activities)): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <h3><?php _e('No activity found', 'rental-gates'); ?></h3>
            </div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th><?php _e('Time', 'rental-gates'); ?></th>
                        <th><?php _e('User', 'rental-gates'); ?></th>
                        <th><?php _e('Action', 'rental-gates'); ?></th>
                        <th><?php _e('Entity', 'rental-gates'); ?></th>
                        <th><?php _e('IP Address', 'rental-gates'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($activities as $activity): ?>
                    <tr>
                        <td class="text-muted" style="white-space: nowrap;">
                            <?php echo date('M j, Y g:i A', strtotime($activity['created_at'])); ?>
                        </td>
                        <td>
                            <?php if ($activity['user_name']): ?>
                            <div style="font-weight: 500;"><?php echo esc_html($activity['user_name']); ?></div>
                            <div style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($activity['user_email']); ?></div>
                            <?php else: ?>
                            <span class="text-muted"><?php _e('System', 'rental-gates'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-gray">
                                <?php echo esc_html(ucwords(str_replace('_', ' ', $activity['action']))); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($activity['entity_type']): ?>
                            <?php echo esc_html(ucfirst($activity['entity_type'])); ?> #<?php echo esc_html($activity['entity_id']); ?>
                            <?php else: ?>
                            <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-muted font-mono" style="font-size: 12px;">
                            <?php echo esc_html($activity['ip_address'] ?? '—'); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($total > $per_page): ?>
            <div style="padding: 16px 24px; border-top: 1px solid var(--gray-200); display: flex; align-items: center; justify-content: space-between;">
                <div class="text-muted">
                    <?php printf(__('Page %d of %d', 'rental-gates'), $page_num, ceil($total / $per_page)); ?>
                </div>
                <div style="display: flex; gap: 8px;">
                    <?php if ($page_num > 1): ?>
                    <a href="<?php echo add_query_arg('paged', $page_num - 1); ?>" class="btn btn-sm btn-outline"><?php _e('Previous', 'rental-gates'); ?></a>
                    <?php endif; ?>
                    <?php if ($offset + $per_page < $total): ?>
                    <a href="<?php echo add_query_arg('paged', $page_num + 1); ?>" class="btn btn-sm btn-outline"><?php _e('Next', 'rental-gates'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
