<?php
/**
 * Site Admin - PWA Settings Section
 */
if (!defined('ABSPATH')) exit;

// Safety check for PWA class
if (!function_exists('rental_gates_pwa')) {
    echo '<div class="notice notice-error"><p>' . __('PWA module not loaded. Please deactivate and reactivate the plugin.', 'rental-gates') . '</p></div>';
    return;
}

$pwa = rental_gates_pwa();
$settings = get_option('rental_gates_pwa_settings', array());

// Handle form submission
if (isset($_POST['save_pwa_settings']) && wp_verify_nonce($_POST['pwa_nonce'] ?? '', 'rental_gates_pwa_settings')) {
    $new_settings = array(
        'enabled' => !empty($_POST['pwa_enabled']),
        'name' => sanitize_text_field($_POST['pwa_name'] ?? ''),
        'short_name' => sanitize_text_field($_POST['pwa_short_name'] ?? ''),
        'description' => sanitize_textarea_field($_POST['pwa_description'] ?? ''),
        'theme_color' => sanitize_hex_color($_POST['pwa_theme_color'] ?? '#2563eb'),
        'background_color' => sanitize_hex_color($_POST['pwa_background_color'] ?? '#ffffff'),
        'display' => sanitize_key($_POST['pwa_display'] ?? 'standalone'),
        'push_enabled' => !empty($_POST['push_enabled']),
    );
    
    // Generate VAPID keys if push is enabled and no keys exist
    if ($new_settings['push_enabled'] && empty($settings['vapid_public_key'])) {
        $keys = $pwa->generate_vapid_keys();
        if (!is_wp_error($keys)) {
            $new_settings['vapid_public_key'] = $keys['public'];
            $new_settings['vapid_private_key'] = $keys['private'];
        }
    }
    
    update_option('rental_gates_pwa_settings', array_merge($settings, $new_settings));
    $settings = get_option('rental_gates_pwa_settings', array());
    
    echo '<div class="notice notice-success"><p>' . __('PWA settings saved!', 'rental-gates') . '</p></div>';
}

// Defaults
$defaults = array(
    'enabled' => true,
    'name' => get_bloginfo('name') . ' - Rental Gates',
    'short_name' => 'Rental Gates',
    'description' => 'Professional property management platform',
    'theme_color' => '#2563eb',
    'background_color' => '#ffffff',
    'display' => 'standalone',
    'push_enabled' => false,
    'vapid_public_key' => '',
);
$settings = wp_parse_args($settings, $defaults);
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('PWA Settings', 'rental-gates'); ?></h1>
    <div class="header-actions">
        <span class="badge badge-<?php echo $settings['enabled'] ? 'success' : 'secondary'; ?>">
            <?php echo $settings['enabled'] ? __('Enabled', 'rental-gates') : __('Disabled', 'rental-gates'); ?>
        </span>
    </div>
</header>

<div class="admin-content">
    <form method="post">
        <?php wp_nonce_field('rental_gates_pwa_settings', 'pwa_nonce'); ?>
        
        <!-- Enable PWA -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Progressive Web App', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label class="toggle-switch">
                        <input type="checkbox" name="pwa_enabled" value="1" <?php checked($settings['enabled']); ?>>
                        <span class="toggle-slider"></span>
                        <span class="toggle-label"><?php _e('Enable PWA Features', 'rental-gates'); ?></span>
                    </label>
                    <p class="form-hint"><?php _e('Allow users to install the app on their devices and use it offline.', 'rental-gates'); ?></p>
                </div>
            </div>
        </div>
        
        <!-- App Information -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title"><?php _e('App Information', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label><?php _e('App Name', 'rental-gates'); ?></label>
                        <input type="text" name="pwa_name" value="<?php echo esc_attr($settings['name']); ?>" class="form-control">
                        <p class="form-hint"><?php _e('Full name shown on the home screen and app switcher.', 'rental-gates'); ?></p>
                    </div>
                    <div class="form-group col-md-6">
                        <label><?php _e('Short Name', 'rental-gates'); ?></label>
                        <input type="text" name="pwa_short_name" value="<?php echo esc_attr($settings['short_name']); ?>" class="form-control" maxlength="12">
                        <p class="form-hint"><?php _e('Short name for limited space (max 12 characters).', 'rental-gates'); ?></p>
                    </div>
                </div>
                
                <div class="form-group">
                    <label><?php _e('Description', 'rental-gates'); ?></label>
                    <textarea name="pwa_description" class="form-control" rows="2"><?php echo esc_textarea($settings['description']); ?></textarea>
                    <p class="form-hint"><?php _e('Brief description shown in app stores and install prompts.', 'rental-gates'); ?></p>
                </div>
            </div>
        </div>
        
        <!-- Appearance -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Appearance', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label><?php _e('Theme Color', 'rental-gates'); ?></label>
                        <div class="color-picker-wrapper">
                            <input type="color" name="pwa_theme_color" value="<?php echo esc_attr($settings['theme_color']); ?>" class="form-control-color">
                            <input type="text" value="<?php echo esc_attr($settings['theme_color']); ?>" class="form-control" readonly>
                        </div>
                        <p class="form-hint"><?php _e('Used for browser toolbar and status bar.', 'rental-gates'); ?></p>
                    </div>
                    <div class="form-group col-md-4">
                        <label><?php _e('Background Color', 'rental-gates'); ?></label>
                        <div class="color-picker-wrapper">
                            <input type="color" name="pwa_background_color" value="<?php echo esc_attr($settings['background_color']); ?>" class="form-control-color">
                            <input type="text" value="<?php echo esc_attr($settings['background_color']); ?>" class="form-control" readonly>
                        </div>
                        <p class="form-hint"><?php _e('Splash screen background color.', 'rental-gates'); ?></p>
                    </div>
                    <div class="form-group col-md-4">
                        <label><?php _e('Display Mode', 'rental-gates'); ?></label>
                        <select name="pwa_display" class="form-control">
                            <option value="standalone" <?php selected($settings['display'], 'standalone'); ?>><?php _e('Standalone (Recommended)', 'rental-gates'); ?></option>
                            <option value="fullscreen" <?php selected($settings['display'], 'fullscreen'); ?>><?php _e('Fullscreen', 'rental-gates'); ?></option>
                            <option value="minimal-ui" <?php selected($settings['display'], 'minimal-ui'); ?>><?php _e('Minimal UI', 'rental-gates'); ?></option>
                            <option value="browser" <?php selected($settings['display'], 'browser'); ?>><?php _e('Browser', 'rental-gates'); ?></option>
                        </select>
                        <p class="form-hint"><?php _e('How the app appears when launched.', 'rental-gates'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Push Notifications -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Push Notifications', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label class="toggle-switch">
                        <input type="checkbox" name="push_enabled" value="1" <?php checked($settings['push_enabled'] ?? false); ?>>
                        <span class="toggle-slider"></span>
                        <span class="toggle-label"><?php _e('Enable Push Notifications', 'rental-gates'); ?></span>
                    </label>
                    <p class="form-hint"><?php _e('Send notifications to users even when the app is closed. Requires HTTPS.', 'rental-gates'); ?></p>
                </div>
                
                <?php if (!empty($settings['vapid_public_key'])): ?>
                <div class="form-group">
                    <label><?php _e('VAPID Public Key', 'rental-gates'); ?></label>
                    <input type="text" value="<?php echo esc_attr($settings['vapid_public_key']); ?>" class="form-control" readonly>
                    <p class="form-hint"><?php _e('Use this key for push notification services.', 'rental-gates'); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- PWA Status -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Status & Diagnostics', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <tbody>
                        <tr>
                            <td><strong><?php _e('HTTPS', 'rental-gates'); ?></strong></td>
                            <td>
                                <?php if (is_ssl()): ?>
                                    <span class="badge badge-success"><?php _e('Enabled', 'rental-gates'); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-danger"><?php _e('Required for PWA', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Service Worker', 'rental-gates'); ?></strong></td>
                            <td>
                                <?php 
                                $sw_path = RENTAL_GATES_PLUGIN_DIR . 'assets/js/service-worker.js';
                                if (file_exists($sw_path)): ?>
                                    <span class="badge badge-success"><?php _e('Available', 'rental-gates'); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-danger"><?php _e('Missing', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Manifest', 'rental-gates'); ?></strong></td>
                            <td>
                                <span class="badge badge-success"><?php _e('Dynamic', 'rental-gates'); ?></span>
                                <a href="<?php echo home_url('/rental-gates-manifest.json'); ?>" target="_blank" class="ml-2"><?php _e('View', 'rental-gates'); ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('GD Library', 'rental-gates'); ?></strong></td>
                            <td>
                                <?php if (function_exists('imagecreatetruecolor')): ?>
                                    <span class="badge badge-success"><?php _e('Available', 'rental-gates'); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning"><?php _e('Not available (icons may not generate)', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('App Icons', 'rental-gates'); ?></strong></td>
                            <td>
                                <?php 
                                $icon_path = RENTAL_GATES_PLUGIN_DIR . 'assets/images/pwa/icon-192x192.png';
                                if (file_exists($icon_path)): ?>
                                    <span class="badge badge-success"><?php _e('Generated', 'rental-gates'); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning"><?php _e('Will generate on save', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" name="save_pwa_settings" class="btn btn-primary">
                <?php _e('Save Settings', 'rental-gates'); ?>
            </button>
        </div>
    </form>
</div>

<style>
    .color-picker-wrapper {
        display: flex;
        gap: 8px;
        align-items: center;
    }
    .form-control-color {
        width: 50px;
        height: 38px;
        padding: 4px;
        border: 1px solid var(--gray-300);
        border-radius: 6px;
        cursor: pointer;
    }
    .toggle-switch {
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
    }
    .toggle-slider {
        width: 44px;
        height: 24px;
        background: var(--gray-300);
        border-radius: 12px;
        position: relative;
        transition: background 0.2s;
    }
    .toggle-slider::after {
        content: '';
        position: absolute;
        width: 20px;
        height: 20px;
        background: white;
        border-radius: 50%;
        top: 2px;
        left: 2px;
        transition: transform 0.2s;
    }
    .toggle-switch input:checked + .toggle-slider {
        background: var(--primary);
    }
    .toggle-switch input:checked + .toggle-slider::after {
        transform: translateX(20px);
    }
    .toggle-switch input {
        display: none;
    }
    .toggle-label {
        font-weight: 500;
    }
    .form-row {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
    }
    .form-row .form-group {
        flex: 1;
        min-width: 200px;
    }
    .ml-2 {
        margin-left: 8px;
    }
</style>

<script>
document.querySelectorAll('.form-control-color').forEach(function(picker) {
    picker.addEventListener('change', function() {
        this.nextElementSibling.value = this.value;
    });
});
</script>
