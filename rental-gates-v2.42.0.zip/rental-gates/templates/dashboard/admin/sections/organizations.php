<?php
/**
 * Site Admin - Organizations Section
 * 
 * Manage all organizations on the platform.
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$org_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$page_num = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 20;
$offset = ($page_num - 1) * $per_page;

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_org_nonce'])) {
    if (wp_verify_nonce($_POST['admin_org_nonce'], 'admin_org_action')) {
        $post_action = sanitize_text_field($_POST['action_type'] ?? '');
        $target_id = intval($_POST['org_id'] ?? 0);
        
        if ($post_action === 'update_status' && $target_id) {
            $new_status = sanitize_text_field($_POST['status']);
            $wpdb->update($tables['organizations'], array('status' => $new_status), array('id' => $target_id));
            wp_redirect(add_query_arg(array('id' => $target_id, 'updated' => '1'), home_url('/rental-gates/admin/organizations')));
            exit;
        }
    }
}

// Build query
$where = array("1=1");
$params = array();

if ($search) {
    $where[] = "(name LIKE %s OR contact_email LIKE %s)";
    $params[] = '%' . $wpdb->esc_like($search) . '%';
    $params[] = '%' . $wpdb->esc_like($search) . '%';
}

if ($status_filter) {
    $where[] = "status = %s";
    $params[] = $status_filter;
}

$where_clause = implode(' AND ', $where);

// Get total
$total_query = "SELECT COUNT(*) FROM {$tables['organizations']} WHERE $where_clause";
$total = $wpdb->get_var($params ? $wpdb->prepare($total_query, $params) : $total_query);

// Get organizations
$query = "SELECT o.*, 
          (SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = o.id) as building_count,
          (SELECT COUNT(*) FROM {$tables['units']} u JOIN {$tables['buildings']} b ON u.building_id = b.id WHERE b.organization_id = o.id) as unit_count,
          (SELECT COUNT(*) FROM {$tables['tenants']} t JOIN {$tables['buildings']} b ON t.building_id = b.id WHERE b.organization_id = o.id) as tenant_count
          FROM {$tables['organizations']} o
          WHERE $where_clause
          ORDER BY o.created_at DESC
          LIMIT %d OFFSET %d";

$all_params = array_merge($params, array($per_page, $offset));
$organizations = $wpdb->get_results($wpdb->prepare($query, $all_params), ARRAY_A);

// Get single organization for detail view
$organization = null;
if ($org_id) {
    $organization = $wpdb->get_row($wpdb->prepare(
        "SELECT o.*,
                (SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = o.id) as building_count,
                (SELECT COUNT(*) FROM {$tables['units']} u JOIN {$tables['buildings']} b ON u.building_id = b.id WHERE b.organization_id = o.id) as unit_count,
                (SELECT COUNT(*) FROM {$tables['tenants']} t JOIN {$tables['buildings']} b ON t.building_id = b.id WHERE b.organization_id = o.id) as tenant_count,
                (SELECT COALESCE(SUM(amount), 0) FROM {$tables['payments']} p 
                 JOIN {$tables['tenants']} t ON p.tenant_id = t.id 
                 JOIN {$tables['buildings']} b ON t.building_id = b.id 
                 WHERE b.organization_id = o.id AND p.status = 'completed') as total_revenue
         FROM {$tables['organizations']} o
         WHERE o.id = %d",
        $org_id
    ), ARRAY_A);
    
    $org_members = $wpdb->get_results($wpdb->prepare(
        "SELECT om.*, u.user_email, u.display_name
         FROM {$tables['organization_members']} om
         JOIN {$wpdb->users} u ON om.user_id = u.ID
         WHERE om.organization_id = %d
         ORDER BY om.role ASC",
        $org_id
    ), ARRAY_A);
}

// Stats
$stats = array(
    'total' => $wpdb->get_var("SELECT COUNT(*) FROM {$tables['organizations']}"),
    'active' => $wpdb->get_var("SELECT COUNT(*) FROM {$tables['organizations']} WHERE status = 'active'"),
    'trial' => $wpdb->get_var("SELECT COUNT(*) FROM {$tables['organizations']} WHERE status = 'trial'"),
    'suspended' => $wpdb->get_var("SELECT COUNT(*) FROM {$tables['organizations']} WHERE status = 'suspended'"),
);
?>

<header class="admin-header">
    <h1 class="header-title">
        <?php if ($organization): ?>
            <a href="<?php echo home_url('/rental-gates/admin/organizations'); ?>" style="color: var(--gray-400); text-decoration: none;"><?php _e('Organizations', 'rental-gates'); ?></a>
            <span style="color: var(--gray-300); margin: 0 8px;">›</span>
            <?php echo esc_html($organization['name']); ?>
        <?php else: ?>
            <?php _e('Organizations', 'rental-gates'); ?>
        <?php endif; ?>
    </h1>
</header>

<div class="admin-content">
    <?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?php _e('Organization updated successfully.', 'rental-gates'); ?>
    </div>
    <?php endif; ?>
    
    <?php if ($organization): ?>
    <!-- Organization Detail View -->
    <div class="grid-3 mb-6">
        <div class="stat-card">
            <div class="stat-icon primary">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($organization['building_count']); ?></div>
                <div class="stat-label"><?php _e('Buildings', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon success">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($organization['unit_count']); ?></div>
                <div class="stat-label"><?php _e('Units', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon warning">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/></svg>
            </div>
            <div class="stat-content">
                <div class="stat-value">$<?php echo number_format($organization['total_revenue']); ?></div>
                <div class="stat-label"><?php _e('Total Revenue', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <div class="grid-2">
        <!-- Organization Details -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Organization Details', 'rental-gates'); ?></h2>
                <span class="badge badge-<?php echo $organization['status'] === 'active' ? 'success' : ($organization['status'] === 'suspended' ? 'danger' : 'warning'); ?>">
                    <?php echo ucfirst($organization['status']); ?>
                </span>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label"><?php _e('Name', 'rental-gates'); ?></label>
                    <div style="font-weight: 500;"><?php echo esc_html($organization['name']); ?></div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Contact Email', 'rental-gates'); ?></label>
                    <div><a href="mailto:<?php echo esc_attr($organization['contact_email']); ?>"><?php echo esc_html($organization['contact_email']); ?></a></div>
                </div>
                
                <?php if ($organization['contact_phone']): ?>
                <div class="form-group">
                    <label class="form-label"><?php _e('Contact Phone', 'rental-gates'); ?></label>
                    <div><?php echo esc_html($organization['contact_phone']); ?></div>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label class="form-label"><?php _e('Created', 'rental-gates'); ?></label>
                    <div><?php echo date('F j, Y', strtotime($organization['created_at'])); ?></div>
                </div>
                
                <hr style="margin: 20px 0; border: none; border-top: 1px solid var(--gray-200);">
                
                <form method="post" action="">
                    <?php wp_nonce_field('admin_org_action', 'admin_org_nonce'); ?>
                    <input type="hidden" name="action_type" value="update_status">
                    <input type="hidden" name="org_id" value="<?php echo $organization['id']; ?>">
                    
                    <div class="form-group">
                        <label class="form-label"><?php _e('Status', 'rental-gates'); ?></label>
                        <select name="status" class="form-select">
                            <option value="active" <?php selected($organization['status'], 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
                            <option value="trial" <?php selected($organization['status'], 'trial'); ?>><?php _e('Trial', 'rental-gates'); ?></option>
                            <option value="suspended" <?php selected($organization['status'], 'suspended'); ?>><?php _e('Suspended', 'rental-gates'); ?></option>
                            <option value="cancelled" <?php selected($organization['status'], 'cancelled'); ?>><?php _e('Cancelled', 'rental-gates'); ?></option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><?php _e('Update Status', 'rental-gates'); ?></button>
                </form>
            </div>
        </div>
        
        <!-- Organization Members -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title"><?php _e('Team Members', 'rental-gates'); ?></h2>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($org_members)): ?>
                <div class="empty-state">
                    <p><?php _e('No team members found.', 'rental-gates'); ?></p>
                </div>
                <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th><?php _e('User', 'rental-gates'); ?></th>
                            <th><?php _e('Role', 'rental-gates'); ?></th>
                            <th><?php _e('Joined', 'rental-gates'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($org_members as $member): ?>
                        <tr>
                            <td>
                                <div style="font-weight: 500;"><?php echo esc_html($member['display_name']); ?></div>
                                <div style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($member['user_email']); ?></div>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $member['role'] === 'owner' ? 'info' : 'gray'; ?>">
                                    <?php echo ucfirst($member['role']); ?>
                                </span>
                            </td>
                            <td class="text-muted">
                                <?php echo date('M j, Y', strtotime($member['created_at'])); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <!-- Organizations List View -->
    
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['total']); ?></div>
                <div class="stat-label"><?php _e('Total', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['active']); ?></div>
                <div class="stat-label"><?php _e('Active', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['trial']); ?></div>
                <div class="stat-label"><?php _e('Trial', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['suspended']); ?></div>
                <div class="stat-label"><?php _e('Suspended', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-6">
        <div class="card-body" style="padding: 16px 24px;">
            <form method="get" action="<?php echo home_url('/rental-gates/admin/organizations'); ?>" style="display: flex; gap: 16px; align-items: center;">
                <div class="search-box" style="flex: 1;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search organizations...', 'rental-gates'); ?>">
                </div>
                
                <select name="status" class="form-select" style="width: auto;">
                    <option value=""><?php _e('All Statuses', 'rental-gates'); ?></option>
                    <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'rental-gates'); ?></option>
                    <option value="trial" <?php selected($status_filter, 'trial'); ?>><?php _e('Trial', 'rental-gates'); ?></option>
                    <option value="suspended" <?php selected($status_filter, 'suspended'); ?>><?php _e('Suspended', 'rental-gates'); ?></option>
                </select>
                
                <button type="submit" class="btn btn-secondary"><?php _e('Filter', 'rental-gates'); ?></button>
            </form>
        </div>
    </div>
    
    <!-- Organizations Table -->
    <div class="card">
        <div class="card-body" style="padding: 0;">
            <?php if (empty($organizations)): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/></svg>
                <h3><?php _e('No organizations found', 'rental-gates'); ?></h3>
            </div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th><?php _e('Organization', 'rental-gates'); ?></th>
                        <th><?php _e('Contact', 'rental-gates'); ?></th>
                        <th><?php _e('Properties', 'rental-gates'); ?></th>
                        <th><?php _e('Status', 'rental-gates'); ?></th>
                        <th><?php _e('Created', 'rental-gates'); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($organizations as $org): ?>
                    <tr>
                        <td>
                            <a href="<?php echo home_url('/rental-gates/admin/organizations?id=' . $org['id']); ?>" style="color: var(--primary); text-decoration: none; font-weight: 500;">
                                <?php echo esc_html($org['name']); ?>
                            </a>
                        </td>
                        <td style="font-size: 13px;"><?php echo esc_html($org['contact_email']); ?></td>
                        <td><?php echo $org['building_count']; ?> / <?php echo $org['unit_count']; ?></td>
                        <td>
                            <span class="badge badge-<?php echo $org['status'] === 'active' ? 'success' : ($org['status'] === 'suspended' ? 'danger' : 'warning'); ?>">
                                <?php echo ucfirst($org['status']); ?>
                            </span>
                        </td>
                        <td class="text-muted"><?php echo date('M j, Y', strtotime($org['created_at'])); ?></td>
                        <td class="text-right">
                            <a href="<?php echo home_url('/rental-gates/admin/organizations?id=' . $org['id']); ?>" class="btn btn-sm btn-outline"><?php _e('View', 'rental-gates'); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
