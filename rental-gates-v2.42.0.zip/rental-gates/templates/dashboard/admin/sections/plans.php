<?php
/**
 * Site Admin - Plans & Pricing Section
 * 
 * Full CRUD for subscription plans with sorting, featuring, and module configuration.
 */
if (!defined('ABSPATH')) exit;

// Module definitions with labels and descriptions
$module_definitions = array(
    'tenant_portal' => array('label' => 'Tenant Portal', 'description' => 'Self-service portal for tenants'),
    'online_payments' => array('label' => 'Online Payments', 'description' => 'Accept rent via card/bank'),
    'maintenance' => array('label' => 'Maintenance Tracking', 'description' => 'Work order management'),
    'lease_management' => array('label' => 'Lease Management', 'description' => 'Create & track leases'),
    'ai_screening' => array('label' => 'AI Tenant Screening', 'description' => 'AI-powered analysis'),
    'marketing_qr' => array('label' => 'Marketing & QR Codes', 'description' => 'Flyers and lead capture'),
    'vendor_management' => array('label' => 'Vendor Management', 'description' => 'Contractor management'),
    'chat_messaging' => array('label' => 'Chat & Messaging', 'description' => 'In-app messaging'),
    'api_access' => array('label' => 'API Access', 'description' => 'REST API integration'),
    'advanced_reports' => array('label' => 'Advanced Reports', 'description' => 'Analytics & exports'),
    'bulk_operations' => array('label' => 'Bulk Operations', 'description' => 'Mass import/export'),
    'white_label' => array('label' => 'White Label', 'description' => 'Custom branding'),
);

// Limit definitions
$limit_definitions = array(
    'buildings' => array('label' => 'Buildings', 'suffix' => ''),
    'units' => array('label' => 'Units', 'suffix' => ''),
    'staff' => array('label' => 'Staff Members', 'suffix' => ''),
    'vendors' => array('label' => 'Vendors', 'suffix' => ''),
    'tenants' => array('label' => 'Tenants', 'suffix' => ''),
    'storage_gb' => array('label' => 'Storage (GB)', 'suffix' => 'GB'),
    'ai_credits' => array('label' => 'AI Credits/Month', 'suffix' => ''),
);

// Default plans
$default_plans = array(
    'free' => array(
        'id' => 'free',
        'name' => 'Free',
        'description' => 'Get started with basic features',
        'is_free' => true,
        'is_active' => true,
        'is_hidden' => false,
        'price_monthly' => 0,
        'price_yearly' => 0,
        'sort_order' => 0,
        'is_featured' => false,
        'limits' => array('buildings' => 1, 'units' => 3, 'staff' => 0, 'vendors' => 0, 'tenants' => 5, 'storage_gb' => 1, 'ai_credits' => 0),
        'modules' => array('tenant_portal' => true, 'maintenance' => true, 'lease_management' => true),
        'custom_features' => array('Community support'),
        'cta_text' => 'Get Started Free',
        'cta_style' => 'outline',
    ),
    'basic' => array(
        'id' => 'basic',
        'name' => 'Basic',
        'description' => 'Perfect for small landlords',
        'is_free' => false,
        'is_active' => true,
        'is_hidden' => false,
        'price_monthly' => 29,
        'price_yearly' => 278,  // Total annual (~$23/mo)
        'sort_order' => 1,
        'is_featured' => false,
        'limits' => array('buildings' => 5, 'units' => 15, 'staff' => 1, 'vendors' => 5, 'tenants' => 30, 'storage_gb' => 5, 'ai_credits' => 20),
        'modules' => array('tenant_portal' => true, 'online_payments' => true, 'maintenance' => true, 'lease_management' => true),
        'custom_features' => array('Email support'),
        'cta_text' => 'Start Free Trial',
        'cta_style' => 'outline',
    ),
    'silver' => array(
        'id' => 'silver',
        'name' => 'Silver',
        'description' => 'For growing property businesses',
        'is_free' => false,
        'is_active' => true,
        'is_hidden' => false,
        'price_monthly' => 79,
        'price_yearly' => 758,  // Total annual (~$63/mo)
        'sort_order' => 2,
        'is_featured' => true,
        'limits' => array('buildings' => 25, 'units' => 75, 'staff' => 5, 'vendors' => 25, 'tenants' => 150, 'storage_gb' => 25, 'ai_credits' => 100),
        'modules' => array('tenant_portal' => true, 'online_payments' => true, 'maintenance' => true, 'lease_management' => true, 'ai_screening' => true, 'marketing_qr' => true, 'vendor_management' => true, 'chat_messaging' => true, 'advanced_reports' => true, 'bulk_operations' => true),
        'custom_features' => array('Priority support', 'Phone support'),
        'cta_text' => 'Start Free Trial',
        'cta_style' => 'primary',
    ),
    'gold' => array(
        'id' => 'gold',
        'name' => 'Gold',
        'description' => 'Enterprise-grade for large portfolios',
        'is_free' => false,
        'is_active' => true,
        'is_hidden' => false,
        'price_monthly' => 199,
        'price_yearly' => 1910,  // Total annual (~$159/mo)
        'sort_order' => 3,
        'is_featured' => false,
        'limits' => array('buildings' => -1, 'units' => -1, 'staff' => -1, 'vendors' => -1, 'tenants' => -1, 'storage_gb' => 100, 'ai_credits' => 500),
        'modules' => array('tenant_portal' => true, 'online_payments' => true, 'maintenance' => true, 'lease_management' => true, 'ai_screening' => true, 'marketing_qr' => true, 'vendor_management' => true, 'chat_messaging' => true, 'api_access' => true, 'advanced_reports' => true, 'bulk_operations' => true, 'white_label' => true),
        'custom_features' => array('Dedicated account manager', 'Custom integrations', 'SLA guarantee', '24/7 support'),
        'cta_text' => 'Contact Sales',
        'cta_style' => 'outline',
    ),
);

// Get current plans or use defaults
$plans = get_option('rental_gates_plans', $default_plans);

// Ensure plans is an array
if (!is_array($plans) || empty($plans)) {
    $plans = $default_plans;
}

// Normalize plans to ensure all fields exist (migration for older data)
$needs_save = false;
foreach ($plans as $plan_id => &$plan) {
    // Ensure is_active exists (default to true)
    if (!isset($plan['is_active'])) {
        $plan['is_active'] = true;
        $needs_save = true;
    }
    // Ensure is_hidden exists (default to false)
    if (!isset($plan['is_hidden'])) {
        $plan['is_hidden'] = false;
        $needs_save = true;
    }
    // Ensure id is set
    if (!isset($plan['id'])) {
        $plan['id'] = $plan_id;
        $needs_save = true;
    }
}
unset($plan); // Break reference

// Save if we migrated old data
if ($needs_save) {
    update_option('rental_gates_plans', $plans);
}

// Sort plans by sort_order
uasort($plans, function($a, $b) {
    return ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0);
});

// Handle AJAX actions
if (isset($_POST['plans_action']) && wp_verify_nonce($_POST['plans_nonce'] ?? '', 'admin_plans')) {
    $action = sanitize_text_field($_POST['plans_action']);
    
    // Save plan
    if ($action === 'save') {
        $plan_id = sanitize_key($_POST['plan_id'] ?? '');
        $is_new = isset($_POST['is_new']) && $_POST['is_new'] === '1';
        
        // Generate ID for new plans
        if ($is_new || empty($plan_id)) {
            $plan_id = sanitize_key($_POST['plan_name'] ?? 'plan');
            $plan_id = preg_replace('/[^a-z0-9_-]/', '', strtolower($plan_id));
            if (empty($plan_id)) $plan_id = 'plan';
            
            // Ensure unique ID
            $base_id = $plan_id;
            $counter = 1;
            while (isset($plans[$plan_id])) {
                $plan_id = $base_id . '_' . $counter;
                $counter++;
            }
        }
        
        // Build plan data
        $plan_data = array(
            'id' => $plan_id,
            'name' => sanitize_text_field($_POST['plan_name'] ?? 'New Plan'),
            'description' => sanitize_text_field($_POST['plan_description'] ?? ''),
            'is_free' => isset($_POST['is_free']),
            'is_active' => isset($_POST['is_active']),
            'is_hidden' => isset($_POST['is_hidden']),
            'price_monthly' => floatval($_POST['price_monthly'] ?? 0),
            'price_yearly' => floatval($_POST['price_yearly'] ?? 0),
            'sort_order' => intval($_POST['sort_order'] ?? count($plans)),
            'is_featured' => isset($_POST['is_featured']),
            'cta_text' => sanitize_text_field($_POST['cta_text'] ?? 'Get Started'),
            'cta_style' => sanitize_text_field($_POST['cta_style'] ?? 'outline'),
            'limits' => array(),
            'modules' => array(),
            'custom_features' => array(),
        );
        
        // Limits
        foreach ($limit_definitions as $limit_key => $limit_def) {
            $plan_data['limits'][$limit_key] = intval($_POST['limit_' . $limit_key] ?? 0);
        }
        
        // Modules
        foreach ($module_definitions as $module_key => $module_def) {
            $plan_data['modules'][$module_key] = isset($_POST['module_' . $module_key]);
        }
        
        // Custom features
        $custom_features = array_filter(array_map('trim', explode("\n", $_POST['custom_features'] ?? '')));
        $plan_data['custom_features'] = array_map('sanitize_text_field', $custom_features);
        
        $plans[$plan_id] = $plan_data;
        update_option('rental_gates_plans', $plans);
        
        wp_redirect(add_query_arg('saved', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Delete plan
    if ($action === 'delete') {
        $plan_id = sanitize_key($_POST['delete_plan_id'] ?? '');
        if (!empty($plan_id) && isset($plans[$plan_id])) {
            unset($plans[$plan_id]);
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('deleted', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Duplicate plan
    if ($action === 'duplicate') {
        $plan_id = sanitize_key($_POST['duplicate_plan_id'] ?? '');
        if (!empty($plan_id) && isset($plans[$plan_id])) {
            $new_plan = $plans[$plan_id];
            $new_id = $plan_id . '_copy';
            $counter = 1;
            while (isset($plans[$new_id])) {
                $new_id = $plan_id . '_copy_' . $counter;
                $counter++;
            }
            $new_plan['id'] = $new_id;
            $new_plan['name'] = $new_plan['name'] . ' (Copy)';
            $new_plan['sort_order'] = count($plans);
            $new_plan['is_featured'] = false;
            $plans[$new_id] = $new_plan;
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('duplicated', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Update sort order
    if ($action === 'reorder') {
        $order = json_decode(stripslashes($_POST['plan_order'] ?? '[]'), true);
        if (is_array($order)) {
            foreach ($order as $index => $plan_id) {
                if (isset($plans[$plan_id])) {
                    $plans[$plan_id]['sort_order'] = $index;
                }
            }
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('reordered', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Toggle featured
    if ($action === 'toggle_featured') {
        $plan_id = sanitize_key($_POST['toggle_plan_id'] ?? '');
        if (!empty($plan_id) && isset($plans[$plan_id])) {
            $plans[$plan_id]['is_featured'] = !($plans[$plan_id]['is_featured'] ?? false);
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('updated', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Toggle active status
    if ($action === 'toggle_active') {
        $plan_id = sanitize_key($_POST['toggle_plan_id'] ?? '');
        if (!empty($plan_id) && isset($plans[$plan_id])) {
            // Default to active if not set
            $currently_active = $plans[$plan_id]['is_active'] ?? true;
            $plans[$plan_id]['is_active'] = !$currently_active;
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('updated', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Toggle hidden status
    if ($action === 'toggle_hidden') {
        $plan_id = sanitize_key($_POST['toggle_plan_id'] ?? '');
        if (!empty($plan_id) && isset($plans[$plan_id])) {
            $plans[$plan_id]['is_hidden'] = !($plans[$plan_id]['is_hidden'] ?? false);
            update_option('rental_gates_plans', $plans);
        }
        wp_redirect(add_query_arg('updated', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
    
    // Reset to default plans
    if ($action === 'reset_defaults') {
        update_option('rental_gates_plans', $default_plans);
        $plans = $default_plans;
        wp_redirect(add_query_arg('reset_done', '1', home_url('/rental-gates/admin/plans')));
        exit;
    }
}

// Reset to defaults
if (isset($_GET['reset']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'reset_plans')) {
    update_option('rental_gates_plans', $default_plans);
    wp_redirect(add_query_arg('reset_done', '1', home_url('/rental-gates/admin/plans')));
    exit;
}

// Check if editing a plan
$editing_plan = null;
$is_new_plan = false;
if (isset($_GET['edit'])) {
    $edit_id = sanitize_key($_GET['edit']);
    if ($edit_id === 'new') {
        $is_new_plan = true;
        $editing_plan = array(
            'id' => '',
            'name' => '',
            'description' => '',
            'is_free' => false,
            'is_active' => true,
            'is_hidden' => false,
            'price_monthly' => 0,
            'price_yearly' => 0,
            'sort_order' => count($plans),
            'is_featured' => false,
            'limits' => array_fill_keys(array_keys($limit_definitions), 0),
            'modules' => array_fill_keys(array_keys($module_definitions), false),
            'custom_features' => array(),
            'cta_text' => 'Get Started',
            'cta_style' => 'outline',
        );
    } elseif (isset($plans[$edit_id])) {
        $editing_plan = $plans[$edit_id];
    }
}

// Re-sort after any changes
uasort($plans, function($a, $b) {
    return ($a['sort_order'] ?? 0) - ($b['sort_order'] ?? 0);
});
?>

<style>
/* Plans List */
.plans-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24px;
}
.plans-actions {
    display: flex;
    gap: 12px;
}

.plans-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.plan-row {
    display: grid;
    grid-template-columns: 40px 1fr 120px 100px 120px 140px;
    gap: 16px;
    align-items: center;
    padding: 16px 20px;
    background: #fff;
    border: 1px solid #e7e5e4;
    border-radius: 12px;
    transition: all 0.2s;
}
.plan-row:hover {
    border-color: #d6d3d1;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.plan-row.featured {
    border-color: #0d9488;
    background: linear-gradient(135deg, #f0fdfa, #fff);
}

.plan-drag {
    cursor: grab;
    color: #a8a29e;
    display: flex;
    align-items: center;
    justify-content: center;
}
.plan-drag:active {
    cursor: grabbing;
}
.plan-drag svg {
    width: 20px;
    height: 20px;
}

.plan-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.plan-name {
    font-weight: 600;
    color: #1c1917;
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.plan-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    border-radius: 100px;
    font-size: 11px;
    font-weight: 600;
}
.plan-badge.featured {
    background: #0d9488;
    color: #fff;
}
.plan-badge.free {
    background: #dbeafe;
    color: #1e40af;
}
.plan-badge.inactive {
    background: #fef2f2;
    color: #dc2626;
}
.plan-badge.hidden {
    background: #fefce8;
    color: #ca8a04;
}
.plan-badge.active {
    background: #dcfce7;
    color: #16a34a;
}
.plan-desc {
    font-size: 13px;
    color: #78716c;
}

.plan-row.inactive {
    opacity: 0.6;
    background: #fafaf9;
}
.plan-row.hidden-plan {
    border-style: dashed;
}

.plan-price {
    font-weight: 600;
    color: #1c1917;
}
.plan-price-free {
    color: #059669;
}

.plan-limits {
    font-size: 12px;
    color: #78716c;
}

.plan-modules {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
}
.plan-module-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #d6d3d1;
}
.plan-module-dot.active {
    background: #0d9488;
}

.plan-actions {
    display: flex;
    gap: 8px;
    justify-content: flex-end;
}
.plan-action-btn {
    padding: 6px 10px;
    border: 1px solid #e7e5e4;
    border-radius: 6px;
    background: #fff;
    color: #57534e;
    font-size: 13px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    transition: all 0.2s;
}
.plan-action-btn:hover {
    border-color: #d6d3d1;
    background: #fafaf9;
}
.plan-action-btn.active-status {
    background: #dcfce7;
    border-color: #86efac;
    color: #16a34a;
}
.plan-action-btn.active-status:hover {
    background: #bbf7d0;
    border-color: #4ade80;
}
.plan-action-btn.inactive-status {
    background: #fef2f2;
    border-color: #fecaca;
    color: #dc2626;
}
.plan-action-btn.inactive-status:hover {
    background: #fee2e2;
    border-color: #f87171;
}
.plan-action-btn.hidden-status {
    background: #fefce8;
    border-color: #fef08a;
    color: #ca8a04;
}
.plan-action-btn.hidden-status:hover {
    background: #fef9c3;
    border-color: #facc15;
}
.plan-action-btn.visible-status {
    background: #f0f9ff;
    border-color: #bae6fd;
    color: #0284c7;
}
.plan-action-btn.visible-status:hover {
    background: #e0f2fe;
    border-color: #7dd3fc;
}
.plan-action-btn.delete:hover {
    border-color: #fecaca;
    background: #fef2f2;
    color: #dc2626;
}
.plan-action-btn svg {
    width: 14px;
    height: 14px;
}

/* Edit Form */
.plan-edit-form {
    background: #fff;
    border: 1px solid #e7e5e4;
    border-radius: 16px;
    overflow: hidden;
}
.plan-edit-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e7e5e4;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #fafaf9;
}
.plan-edit-header h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.plan-edit-body {
    padding: 24px;
}

.form-section {
    margin-bottom: 32px;
}
.form-section:last-child {
    margin-bottom: 0;
}
.form-section-title {
    font-size: 14px;
    font-weight: 600;
    color: #1c1917;
    margin-bottom: 16px;
    padding-bottom: 8px;
    border-bottom: 1px solid #f5f5f4;
    display: flex;
    align-items: center;
    gap: 8px;
}
.form-section-title svg {
    width: 18px;
    height: 18px;
    color: #0d9488;
}

.form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 16px;
}
.form-row:last-child {
    margin-bottom: 0;
}

.form-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.form-field label {
    font-size: 13px;
    font-weight: 500;
    color: #57534e;
}
.form-field input[type="text"],
.form-field input[type="number"],
.form-field select,
.form-field textarea {
    padding: 10px 12px;
    border: 1px solid #d6d3d1;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.2s;
}
.form-field input:focus,
.form-field select:focus,
.form-field textarea:focus {
    outline: none;
    border-color: #0d9488;
    box-shadow: 0 0 0 3px rgba(13,148,136,0.1);
}
.form-field textarea {
    min-height: 100px;
    resize: vertical;
    font-family: inherit;
}
.form-field .help-text {
    font-size: 12px;
    color: #78716c;
}

.checkbox-field {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: #fafaf9;
    border-radius: 8px;
    cursor: pointer;
}
.checkbox-field input {
    width: 18px;
    height: 18px;
    accent-color: #0d9488;
}
.checkbox-field span {
    font-size: 14px;
    color: #44403c;
}
.checkbox-field.highlighted {
    background: #f0fdfa;
    border: 1px solid #99f6e4;
}

.modules-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 10px;
}
.module-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    background: #fafaf9;
    border: 1px solid #e7e5e4;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s;
}
.module-toggle:hover {
    border-color: #d6d3d1;
}
.module-toggle.active {
    background: #f0fdfa;
    border-color: #99f6e4;
}
.module-toggle input {
    width: 16px;
    height: 16px;
    accent-color: #0d9488;
}
.module-toggle-info {
    flex: 1;
    min-width: 0;
}
.module-toggle-label {
    font-size: 13px;
    font-weight: 500;
    color: #1c1917;
}
.module-toggle-desc {
    font-size: 11px;
    color: #78716c;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.limits-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 12px;
}
.limit-field {
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.limit-field label {
    font-size: 12px;
    font-weight: 500;
    color: #57534e;
}
.limit-field input {
    padding: 8px 10px;
    border: 1px solid #d6d3d1;
    border-radius: 6px;
    font-size: 13px;
}

.form-footer {
    padding: 20px 24px;
    border-top: 1px solid #e7e5e4;
    background: #fafaf9;
    display: flex;
    align-items: center;
    gap: 12px;
}

/* Empty State */
.plans-empty {
    text-align: center;
    padding: 60px 20px;
    background: #fafaf9;
    border-radius: 12px;
    border: 2px dashed #e7e5e4;
}
.plans-empty svg {
    width: 48px;
    height: 48px;
    color: #d6d3d1;
    margin-bottom: 16px;
}
.plans-empty h3 {
    font-size: 16px;
    color: #57534e;
    margin-bottom: 8px;
}
.plans-empty p {
    font-size: 14px;
    color: #78716c;
    margin-bottom: 20px;
}

/* Preview */
.plan-preview {
    position: sticky;
    top: 24px;
}
.preview-title {
    font-size: 12px;
    font-weight: 600;
    color: #78716c;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
}
.preview-card {
    background: #fff;
    border: 1px solid #e7e5e4;
    border-radius: 16px;
    padding: 24px;
    text-align: center;
}
.preview-card.featured {
    border-color: #0d9488;
    border-width: 2px;
    box-shadow: 0 0 0 4px rgba(13,148,136,0.1);
}
.preview-badge {
    display: inline-block;
    padding: 4px 12px;
    background: #0d9488;
    color: #fff;
    border-radius: 100px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    margin-bottom: 12px;
}
.preview-name {
    font-size: 18px;
    font-weight: 600;
    color: #1c1917;
    margin-bottom: 4px;
}
.preview-desc {
    font-size: 13px;
    color: #78716c;
    margin-bottom: 16px;
}
.preview-price {
    font-size: 36px;
    font-weight: 700;
    color: #1c1917;
    margin-bottom: 4px;
}
.preview-price sup {
    font-size: 18px;
    vertical-align: super;
}
.preview-price-free {
    color: #059669;
}
.preview-period {
    font-size: 13px;
    color: #78716c;
    margin-bottom: 16px;
}
.preview-features {
    text-align: left;
    margin-bottom: 16px;
}
.preview-feature {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 0;
    font-size: 12px;
    color: #44403c;
}
.preview-feature svg {
    width: 14px;
    height: 14px;
    color: #059669;
    flex-shrink: 0;
}
.preview-btn {
    display: block;
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 13px;
    text-align: center;
    text-decoration: none;
}
.preview-btn.primary {
    background: #0d9488;
    color: #fff;
}
.preview-btn.outline {
    background: #fff;
    border: 2px solid #e7e5e4;
    color: #44403c;
}

/* Tabs */
.admin-tabs {
    display: flex;
    gap: 0;
    border-bottom: 2px solid #e7e5e4;
    margin-bottom: 24px;
}
.admin-tab {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 500;
    color: #78716c;
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    margin-bottom: -2px;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.admin-tab:hover {
    color: #44403c;
}
.admin-tab.active {
    color: #0d9488;
    border-bottom-color: #0d9488;
}
.admin-tab svg {
    width: 18px;
    height: 18px;
}
.admin-tab-content {
    display: none;
}
.admin-tab-content.active {
    display: block;
}

/* Discount Card */
.discount-card {
    background: #fff;
    border: 1px solid #e7e5e4;
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 24px;
}
.discount-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 20px;
    border-bottom: 1px solid #f5f5f4;
    margin-bottom: 24px;
}
.discount-card-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
    font-weight: 600;
    color: #1c1917;
    margin: 0;
}
.discount-card-title svg {
    width: 20px;
    height: 20px;
    color: #0d9488;
}

/* Toggle Switch */
.toggle-switch {
    display: flex;
    align-items: center;
    gap: 10px;
}
.toggle-switch-track {
    position: relative;
    width: 48px;
    height: 26px;
    background: #d6d3d1;
    border-radius: 13px;
    cursor: pointer;
    transition: background 0.2s;
}
.toggle-switch-track::after {
    content: '';
    position: absolute;
    top: 3px;
    left: 3px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
}
.toggle-switch input {
    display: none;
}
.toggle-switch input:checked + .toggle-switch-track {
    background: #0d9488;
}
.toggle-switch input:checked + .toggle-switch-track::after {
    transform: translateX(22px);
}
.toggle-switch-label {
    font-size: 14px;
    font-weight: 500;
    color: #1c1917;
}

/* Discount Form */
.discount-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}
.discount-form-group {
    margin-bottom: 0;
}
.discount-form-group label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: #78716c;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
}
.discount-form-group input[type="text"],
.discount-form-group input[type="number"],
.discount-form-group input[type="date"],
.discount-form-group select {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #e7e5e4;
    border-radius: 8px;
    font-size: 14px;
    color: #1c1917;
    transition: border-color 0.2s, box-shadow 0.2s;
}
.discount-form-group input:focus,
.discount-form-group select:focus {
    outline: none;
    border-color: #0d9488;
    box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
}
.discount-form-group .field-help {
    font-size: 12px;
    color: #a8a29e;
    margin-top: 6px;
}

/* Segmented Control */
.segmented-control {
    display: inline-flex;
    background: #f5f5f4;
    border-radius: 10px;
    padding: 4px;
    gap: 4px;
}
.segmented-option {
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    color: #78716c;
}
.segmented-option:hover {
    color: #44403c;
}
.segmented-control input {
    display: none;
}
.segmented-control input:checked + .segmented-option {
    background: #fff;
    color: #1c1917;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

/* Checkbox Pills */
.checkbox-pills {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}
.checkbox-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    background: #f5f5f4;
    border-radius: 100px;
    font-size: 13px;
    cursor: pointer;
    transition: all 0.2s;
    color: #44403c;
}
.checkbox-pill:hover {
    background: #e7e5e4;
}
.checkbox-pill input {
    display: none;
}
.checkbox-pill.checked {
    background: #f0fdfa;
    color: #0d9488;
}
.checkbox-pill input:checked + span::before {
    content: '✓ ';
}

/* Date Range */
.date-range {
    display: flex;
    align-items: center;
    gap: 12px;
}
.date-range-sep {
    color: #a8a29e;
    font-size: 13px;
}
.date-range .discount-form-group {
    flex: 1;
}

/* Discount Preview */
.discount-preview {
    background: linear-gradient(135deg, #fef3c7, #fde68a);
    border: 1px solid #f59e0b;
    border-radius: 12px;
    padding: 20px;
    margin-top: 28px;
}
.discount-preview-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    color: #92400e;
    margin: 0 0 16px;
}
.discount-preview-title svg {
    width: 18px;
    height: 18px;
}
.discount-preview-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px;
}
.discount-preview-item {
    background: rgba(255,255,255,0.85);
    padding: 14px;
    border-radius: 10px;
}
.discount-preview-plan {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #78350f;
    margin-bottom: 6px;
}
.discount-preview-original {
    font-size: 13px;
    color: #92400e;
    text-decoration: line-through;
}
.discount-preview-final {
    font-size: 20px;
    font-weight: 700;
    color: #166534;
}
.discount-preview-savings {
    font-size: 11px;
    color: #166534;
    margin-top: 4px;
}

/* Info Box */
.info-box {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 14px 18px;
    background: #f0fdfa;
    border: 1px solid #99f6e4;
    border-radius: 10px;
    margin-bottom: 24px;
}
.info-box svg {
    width: 20px;
    height: 20px;
    color: #0d9488;
    flex-shrink: 0;
    margin-top: 2px;
}
.info-box-content {
    font-size: 13px;
    color: #115e59;
    line-height: 1.5;
}
.info-box-content strong {
    display: block;
    margin-bottom: 4px;
}
</style>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Plans & Pricing', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <?php 
    // Get current tab
    $current_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'plans';
    
    // Get discount settings
    $discount = get_option('rental_gates_discount', array(
        'enabled' => false,
        'type' => 'percentage',
        'value' => 0,
        'applies_to_plans' => array(),
        'applies_to_period' => 'both',
        'label' => '',
        'badge_text' => '',
        'start_date' => '',
        'end_date' => '',
    ));
    
    // Handle discount form submission
    if (isset($_POST['discount_action']) && wp_verify_nonce($_POST['discount_nonce'] ?? '', 'admin_discount')) {
        $discount = array(
            'enabled' => isset($_POST['discount_enabled']),
            'type' => in_array($_POST['discount_type'] ?? '', array('percentage', 'fixed')) ? $_POST['discount_type'] : 'percentage',
            'value' => max(0, floatval($_POST['discount_value'] ?? 0)),
            'applies_to_plans' => array_map('sanitize_key', (array)($_POST['discount_plans'] ?? array())),
            'applies_to_period' => in_array($_POST['discount_period'] ?? '', array('monthly', 'yearly', 'both')) ? $_POST['discount_period'] : 'both',
            'label' => sanitize_text_field($_POST['discount_label'] ?? ''),
            'badge_text' => sanitize_text_field($_POST['discount_badge'] ?? ''),
            'start_date' => sanitize_text_field($_POST['discount_start'] ?? ''),
            'end_date' => sanitize_text_field($_POST['discount_end'] ?? ''),
        );
        
        // Validate percentage
        if ($discount['type'] === 'percentage' && $discount['value'] > 100) {
            $discount['value'] = 100;
        }
        
        update_option('rental_gates_discount', $discount);
        
        // Reload pricing helper cache
        if (function_exists('rental_gates_pricing')) {
            rental_gates_pricing()->reload();
        }
        
        wp_redirect(add_query_arg(array('tab' => 'discounts', 'saved' => '1'), home_url('/rental-gates/admin/plans')));
        exit;
    }
    ?>
    
    <!-- Tabs Navigation -->
    <div class="admin-tabs">
        <a href="<?php echo add_query_arg('tab', 'plans', home_url('/rental-gates/admin/plans')); ?>" 
           class="admin-tab <?php echo $current_tab === 'plans' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            <?php _e('Plans', 'rental-gates'); ?>
        </a>
        <a href="<?php echo add_query_arg('tab', 'discounts', home_url('/rental-gates/admin/plans')); ?>" 
           class="admin-tab <?php echo $current_tab === 'discounts' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
            <?php _e('Discounts', 'rental-gates'); ?>
            <?php if (!empty($discount['enabled'])): ?>
            <span style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; margin-left: 4px;"></span>
            <?php endif; ?>
        </a>
    </div>
    
    <?php if ($current_tab === 'discounts'): ?>
    <!-- Discounts Tab -->
    <div class="admin-tab-content active" id="tab-discounts">
        <?php if (isset($_GET['saved'])): ?>
        <div class="alert alert-success mb-6">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            <div><?php _e('Discount settings saved!', 'rental-gates'); ?></div>
        </div>
        <?php endif; ?>
        
        <div class="info-box">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <div class="info-box-content">
                <strong><?php _e('About Discounts', 'rental-gates'); ?></strong>
                <?php _e('Configure promotional discounts that apply automatically to your pricing pages, checkout, and invoices. You can target specific plans and billing periods.', 'rental-gates'); ?>
            </div>
        </div>
        
        <form method="post" action="" id="discount-form">
            <?php wp_nonce_field('admin_discount', 'discount_nonce'); ?>
            <input type="hidden" name="discount_action" value="save">
            
            <div class="discount-card">
                <div class="discount-card-header">
                    <h3 class="discount-card-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                        <?php _e('Discount Configuration', 'rental-gates'); ?>
                    </h3>
                    <label class="toggle-switch">
                        <input type="checkbox" name="discount_enabled" id="discount-enabled" value="1" <?php checked(!empty($discount['enabled'])); ?>>
                        <span class="toggle-switch-track"></span>
                        <span class="toggle-switch-label"><?php _e('Enable Discount', 'rental-gates'); ?></span>
                    </label>
                </div>
                
                <div id="discount-settings" style="<?php echo empty($discount['enabled']) ? 'opacity: 0.5; pointer-events: none;' : ''; ?>">
                    <div class="discount-form-grid">
                        <div class="discount-form-group">
                            <label><?php _e('Discount Type', 'rental-gates'); ?></label>
                            <div class="segmented-control">
                                <input type="radio" name="discount_type" id="type-percentage" value="percentage" <?php checked(($discount['type'] ?? 'percentage') === 'percentage'); ?>>
                                <label for="type-percentage" class="segmented-option"><?php _e('Percentage (%)', 'rental-gates'); ?></label>
                                <input type="radio" name="discount_type" id="type-fixed" value="fixed" <?php checked(($discount['type'] ?? '') === 'fixed'); ?>>
                                <label for="type-fixed" class="segmented-option"><?php _e('Fixed Amount ($)', 'rental-gates'); ?></label>
                            </div>
                        </div>
                        
                        <div class="discount-form-group">
                            <label for="discount-value"><?php _e('Discount Value', 'rental-gates'); ?></label>
                            <input type="number" name="discount_value" id="discount-value" 
                                   value="<?php echo esc_attr($discount['value'] ?? 0); ?>" 
                                   min="0" max="100" step="0.01">
                            <p class="field-help"><?php _e('Percentage: 0-100. Fixed: dollar amount off.', 'rental-gates'); ?></p>
                        </div>
                        
                        <div class="discount-form-group">
                            <label for="discount-label"><?php _e('Discount Label', 'rental-gates'); ?></label>
                            <input type="text" name="discount_label" id="discount-label" 
                                   value="<?php echo esc_attr($discount['label'] ?? ''); ?>" 
                                   placeholder="<?php esc_attr_e('e.g., Launch Special', 'rental-gates'); ?>">
                            <p class="field-help"><?php _e('Shown as a banner on pricing page.', 'rental-gates'); ?></p>
                        </div>
                        
                        <div class="discount-form-group">
                            <label for="discount-badge"><?php _e('Badge Text', 'rental-gates'); ?></label>
                            <input type="text" name="discount_badge" id="discount-badge" 
                                   value="<?php echo esc_attr($discount['badge_text'] ?? ''); ?>" 
                                   placeholder="<?php esc_attr_e('e.g., 20% OFF', 'rental-gates'); ?>">
                            <p class="field-help"><?php _e('Shown on discounted plan cards.', 'rental-gates'); ?></p>
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px;">
                        <div class="discount-form-group">
                            <label><?php _e('Apply to Plans', 'rental-gates'); ?></label>
                            <div class="checkbox-pills">
                                <?php foreach ($plans as $pid => $p): ?>
                                <?php if (!empty($p['is_free'])) continue; ?>
                                <label class="checkbox-pill <?php echo in_array($pid, (array)($discount['applies_to_plans'] ?? array())) ? 'checked' : ''; ?>">
                                    <input type="checkbox" name="discount_plans[]" value="<?php echo esc_attr($pid); ?>" 
                                           <?php checked(in_array($pid, (array)($discount['applies_to_plans'] ?? array()))); ?>>
                                    <span><?php echo esc_html($p['name']); ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <p class="field-help"><?php _e('Leave empty to apply to all paid plans.', 'rental-gates'); ?></p>
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px;">
                        <div class="discount-form-group">
                            <label><?php _e('Apply to Billing Period', 'rental-gates'); ?></label>
                            <div class="segmented-control">
                                <input type="radio" name="discount_period" id="period-both" value="both" <?php checked(($discount['applies_to_period'] ?? 'both') === 'both'); ?>>
                                <label for="period-both" class="segmented-option"><?php _e('Both', 'rental-gates'); ?></label>
                                <input type="radio" name="discount_period" id="period-monthly" value="monthly" <?php checked(($discount['applies_to_period'] ?? '') === 'monthly'); ?>>
                                <label for="period-monthly" class="segmented-option"><?php _e('Monthly Only', 'rental-gates'); ?></label>
                                <input type="radio" name="discount_period" id="period-yearly" value="yearly" <?php checked(($discount['applies_to_period'] ?? '') === 'yearly'); ?>>
                                <label for="period-yearly" class="segmented-option"><?php _e('Yearly Only', 'rental-gates'); ?></label>
                            </div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px;">
                        <div class="discount-form-group">
                            <label><?php _e('Schedule (Optional)', 'rental-gates'); ?></label>
                            <div class="date-range">
                                <div class="discount-form-group" style="margin-bottom: 0;">
                                    <input type="date" name="discount_start" value="<?php echo esc_attr($discount['start_date'] ?? ''); ?>">
                                </div>
                                <span class="date-range-sep"><?php _e('to', 'rental-gates'); ?></span>
                                <div class="discount-form-group" style="margin-bottom: 0;">
                                    <input type="date" name="discount_end" value="<?php echo esc_attr($discount['end_date'] ?? ''); ?>">
                                </div>
                            </div>
                            <p class="field-help"><?php _e('Leave empty for no time limit.', 'rental-gates'); ?></p>
                        </div>
                    </div>
                    
                    <!-- Live Preview -->
                    <div class="discount-preview" id="discount-preview">
                        <h4 class="discount-preview-title">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                            <?php _e('Live Preview', 'rental-gates'); ?>
                        </h4>
                        <div class="discount-preview-grid">
                            <?php foreach ($plans as $pid => $p): ?>
                            <?php if (!empty($p['is_free'])) continue; ?>
                            <div class="discount-preview-item" data-plan="<?php echo esc_attr($pid); ?>" 
                                 data-monthly="<?php echo esc_attr($p['price_monthly'] ?? 0); ?>" 
                                 data-yearly="<?php echo esc_attr(($p['price_yearly'] ?? 0) / 12); ?>">
                                <div class="discount-preview-plan"><?php echo esc_html($p['name']); ?></div>
                                <div class="discount-preview-original">$<?php echo esc_html($p['price_monthly'] ?? 0); ?>/mo</div>
                                <div class="discount-preview-final">$<?php echo esc_html($p['price_monthly'] ?? 0); ?>/mo</div>
                                <div class="discount-preview-savings"></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; justify-content: flex-end; gap: 12px;">
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php _e('Save Discount Settings', 'rental-gates'); ?>
                </button>
            </div>
        </form>
        
        <script>
        (function() {
            var enabledCheckbox = document.getElementById('discount-enabled');
            var settingsDiv = document.getElementById('discount-settings');
            var valueInput = document.getElementById('discount-value');
            var typeRadios = document.querySelectorAll('input[name="discount_type"]');
            var periodRadios = document.querySelectorAll('input[name="discount_period"]');
            var planCheckboxes = document.querySelectorAll('input[name="discount_plans[]"]');
            
            // Toggle settings visibility
            enabledCheckbox.addEventListener('change', function() {
                settingsDiv.style.opacity = this.checked ? '1' : '0.5';
                settingsDiv.style.pointerEvents = this.checked ? 'auto' : 'none';
            });
            
            // Update checkbox pill styling
            planCheckboxes.forEach(function(cb) {
                cb.addEventListener('change', function() {
                    this.closest('.checkbox-pill').classList.toggle('checked', this.checked);
                    updatePreview();
                });
            });
            
            // Update max value based on type
            typeRadios.forEach(function(radio) {
                radio.addEventListener('change', function() {
                    valueInput.max = this.value === 'percentage' ? 100 : 9999;
                    updatePreview();
                });
            });
            
            // Update preview on input changes
            valueInput.addEventListener('input', updatePreview);
            periodRadios.forEach(function(radio) {
                radio.addEventListener('change', updatePreview);
            });
            
            function updatePreview() {
                var type = document.querySelector('input[name="discount_type"]:checked').value;
                var value = parseFloat(valueInput.value) || 0;
                var period = document.querySelector('input[name="discount_period"]:checked').value;
                var selectedPlans = Array.from(planCheckboxes).filter(function(cb) { return cb.checked; }).map(function(cb) { return cb.value; });
                
                document.querySelectorAll('.discount-preview-item').forEach(function(item) {
                    var plan = item.dataset.plan;
                    var monthly = parseFloat(item.dataset.monthly);
                    
                    // Check if discount applies
                    var applies = selectedPlans.length === 0 || selectedPlans.indexOf(plan) !== -1;
                    
                    if (applies && value > 0) {
                        var discounted = monthly;
                        if (type === 'percentage') {
                            discounted = monthly * (1 - value / 100);
                        } else {
                            discounted = Math.max(0, monthly - value);
                        }
                        
                        item.querySelector('.discount-preview-original').style.display = 'block';
                        item.querySelector('.discount-preview-original').textContent = '$' + monthly.toFixed(0) + '/mo';
                        item.querySelector('.discount-preview-final').textContent = '$' + discounted.toFixed(0) + '/mo';
                        
                        var savings = monthly - discounted;
                        if (savings > 0) {
                            item.querySelector('.discount-preview-savings').style.display = 'block';
                            item.querySelector('.discount-preview-savings').textContent = 'Save $' + savings.toFixed(0) + '/mo';
                        } else {
                            item.querySelector('.discount-preview-savings').style.display = 'none';
                        }
                    } else {
                        item.querySelector('.discount-preview-original').style.display = 'none';
                        item.querySelector('.discount-preview-final').textContent = '$' + monthly.toFixed(0) + '/mo';
                        item.querySelector('.discount-preview-savings').style.display = 'none';
                    }
                });
            }
            
            // Initial preview update
            updatePreview();
        })();
        </script>
    </div>
    
    <?php else: ?>
    <!-- Plans Tab -->
    <div class="admin-tab-content active" id="tab-plans">
    <?php if (isset($_GET['saved'])): ?>
    <div class="alert alert-success mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <div><?php _e('Plan saved successfully!', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-info mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        <div><?php _e('Plan deleted.', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['reset_done'])): ?>
    <div class="alert alert-info mb-6">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
        <div><?php _e('Plans reset to defaults.', 'rental-gates'); ?></div>
    </div>
    <?php endif; ?>
    
    <?php if ($editing_plan): ?>
    <!-- Edit Plan Form -->
    <div style="display: grid; grid-template-columns: 1fr 300px; gap: 24px; align-items: start;">
        <form method="post" action="" class="plan-edit-form">
            <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
            <input type="hidden" name="plans_action" value="save">
            <input type="hidden" name="plan_id" value="<?php echo esc_attr($editing_plan['id'] ?? ''); ?>">
            <?php if ($is_new_plan): ?>
            <input type="hidden" name="is_new" value="1">
            <?php endif; ?>
            
            <div class="plan-edit-header">
                <h2>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    <?php echo $is_new_plan ? __('Create New Plan', 'rental-gates') : __('Edit Plan', 'rental-gates'); ?>
                </h2>
                <a href="<?php echo home_url('/rental-gates/admin/plans'); ?>" class="btn btn-secondary btn-sm">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    <?php _e('Cancel', 'rental-gates'); ?>
                </a>
            </div>
            
            <div class="plan-edit-body">
                <!-- Basic Info -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <?php _e('Basic Information', 'rental-gates'); ?>
                    </h3>
                    
                    <div class="form-row">
                        <div class="form-field">
                            <label><?php _e('Plan Name', 'rental-gates'); ?> *</label>
                            <input type="text" name="plan_name" value="<?php echo esc_attr($editing_plan['name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-field">
                            <label><?php _e('Description', 'rental-gates'); ?></label>
                            <input type="text" name="plan_description" value="<?php echo esc_attr($editing_plan['description'] ?? ''); ?>" placeholder="<?php esc_attr_e('Short tagline for this plan', 'rental-gates'); ?>">
                        </div>
                    </div>
                    
                    <div class="form-row" style="flex-wrap: wrap; gap: 12px;">
                        <label class="checkbox-field <?php echo ($editing_plan['is_active'] ?? true) ? 'highlighted' : ''; ?>" style="background: <?php echo ($editing_plan['is_active'] ?? true) ? '#dcfce7' : '#fef2f2'; ?>; border-color: <?php echo ($editing_plan['is_active'] ?? true) ? '#bbf7d0' : '#fecaca'; ?>;">
                            <input type="checkbox" name="is_active" value="1" <?php checked($editing_plan['is_active'] ?? true); ?>>
                            <span style="color: <?php echo ($editing_plan['is_active'] ?? true) ? '#166534' : '#dc2626'; ?>;">
                                <?php _e('Active (users can subscribe)', 'rental-gates'); ?>
                            </span>
                        </label>
                        <label class="checkbox-field <?php echo !empty($editing_plan['is_hidden']) ? 'highlighted' : ''; ?>" style="<?php echo !empty($editing_plan['is_hidden']) ? 'background: #fefce8; border-color: #fef08a;' : ''; ?>">
                            <input type="checkbox" name="is_hidden" value="1" <?php checked(!empty($editing_plan['is_hidden'])); ?>>
                            <span style="<?php echo !empty($editing_plan['is_hidden']) ? 'color: #854d0e;' : ''; ?>">
                                <?php _e('Hidden from pricing page', 'rental-gates'); ?>
                            </span>
                        </label>
                        <label class="checkbox-field <?php echo !empty($editing_plan['is_free']) ? 'highlighted' : ''; ?>">
                            <input type="checkbox" name="is_free" value="1" <?php checked(!empty($editing_plan['is_free'])); ?>>
                            <span><?php _e('Free plan (no payment)', 'rental-gates'); ?></span>
                        </label>
                        <label class="checkbox-field <?php echo !empty($editing_plan['is_featured']) ? 'highlighted' : ''; ?>">
                            <input type="checkbox" name="is_featured" value="1" <?php checked(!empty($editing_plan['is_featured'])); ?>>
                            <span><?php _e('Featured / Recommended', 'rental-gates'); ?></span>
                        </label>
                    </div>
                </div>
                
                <!-- Pricing -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <?php _e('Pricing', 'rental-gates'); ?>
                    </h3>
                    
                    <div class="form-row">
                        <div class="form-field">
                            <label><?php _e('Monthly Price ($)', 'rental-gates'); ?></label>
                            <input type="number" name="price_monthly" value="<?php echo esc_attr($editing_plan['price_monthly'] ?? 0); ?>" min="0" step="0.01">
                            <span class="help-text"><?php _e('Price per month for monthly billing', 'rental-gates'); ?></span>
                        </div>
                        <div class="form-field">
                            <label><?php _e('Yearly Price ($/year)', 'rental-gates'); ?></label>
                            <input type="number" name="price_yearly" value="<?php echo esc_attr($editing_plan['price_yearly'] ?? 0); ?>" min="0" step="0.01">
                            <span class="help-text"><?php _e('Total annual cost (e.g., $278/year = ~$23/mo)', 'rental-gates'); ?></span>
                        </div>
                        <div class="form-field">
                            <label><?php _e('Sort Order', 'rental-gates'); ?></label>
                            <input type="number" name="sort_order" value="<?php echo esc_attr($editing_plan['sort_order'] ?? 0); ?>" min="0">
                            <span class="help-text"><?php _e('Lower = displayed first', 'rental-gates'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Resource Limits -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                        <?php _e('Resource Limits', 'rental-gates'); ?>
                        <span style="font-weight: 400; font-size: 12px; color: #78716c; margin-left: 8px;">(<?php _e('-1 = unlimited, 0 = disabled', 'rental-gates'); ?>)</span>
                    </h3>
                    
                    <div class="limits-grid">
                        <?php foreach ($limit_definitions as $limit_key => $limit_def): ?>
                        <div class="limit-field">
                            <label><?php echo esc_html($limit_def['label']); ?></label>
                            <input type="number" name="limit_<?php echo esc_attr($limit_key); ?>" 
                                   value="<?php echo esc_attr($editing_plan['limits'][$limit_key] ?? 0); ?>" min="-1">
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Feature Modules -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                        <?php _e('Feature Modules', 'rental-gates'); ?>
                    </h3>
                    
                    <div class="modules-grid">
                        <?php foreach ($module_definitions as $module_key => $module_def): 
                            $enabled = !empty($editing_plan['modules'][$module_key]);
                        ?>
                        <label class="module-toggle <?php echo $enabled ? 'active' : ''; ?>">
                            <input type="checkbox" name="module_<?php echo esc_attr($module_key); ?>" value="1" <?php checked($enabled); ?>>
                            <div class="module-toggle-info">
                                <div class="module-toggle-label"><?php echo esc_html($module_def['label']); ?></div>
                                <div class="module-toggle-desc"><?php echo esc_html($module_def['description']); ?></div>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- CTA Button -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"/></svg>
                        <?php _e('Call to Action', 'rental-gates'); ?>
                    </h3>
                    
                    <div class="form-row">
                        <div class="form-field">
                            <label><?php _e('Button Text', 'rental-gates'); ?></label>
                            <input type="text" name="cta_text" value="<?php echo esc_attr($editing_plan['cta_text'] ?? 'Get Started'); ?>">
                        </div>
                        <div class="form-field">
                            <label><?php _e('Button Style', 'rental-gates'); ?></label>
                            <select name="cta_style">
                                <option value="primary" <?php selected(($editing_plan['cta_style'] ?? '') === 'primary'); ?>><?php _e('Primary (Filled)', 'rental-gates'); ?></option>
                                <option value="outline" <?php selected(($editing_plan['cta_style'] ?? 'outline') === 'outline'); ?>><?php _e('Outline', 'rental-gates'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Custom Features -->
                <div class="form-section">
                    <h3 class="form-section-title">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <?php _e('Additional Features', 'rental-gates'); ?>
                    </h3>
                    
                    <div class="form-field">
                        <label><?php _e('Custom bullet points (one per line)', 'rental-gates'); ?></label>
                        <textarea name="custom_features" placeholder="<?php esc_attr_e("Email support\nPriority support\nDedicated account manager", 'rental-gates'); ?>"><?php echo esc_textarea(implode("\n", $editing_plan['custom_features'] ?? array())); ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="form-footer">
                <button type="submit" class="btn btn-primary">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    <?php echo $is_new_plan ? __('Create Plan', 'rental-gates') : __('Save Changes', 'rental-gates'); ?>
                </button>
                <a href="<?php echo home_url('/rental-gates/admin/plans'); ?>" class="btn btn-secondary">
                    <?php _e('Cancel', 'rental-gates'); ?>
                </a>
            </div>
        </form>
        
        <!-- Live Preview -->
        <div class="plan-preview">
            <div class="preview-title"><?php _e('Card Preview', 'rental-gates'); ?></div>
            <div class="preview-card <?php echo !empty($editing_plan['is_featured']) ? 'featured' : ''; ?>">
                <?php if (!empty($editing_plan['is_featured'])): ?>
                <span class="preview-badge"><?php _e('Recommended', 'rental-gates'); ?></span>
                <?php endif; ?>
                
                <div class="preview-name"><?php echo esc_html($editing_plan['name'] ?: 'Plan Name'); ?></div>
                <div class="preview-desc"><?php echo esc_html($editing_plan['description'] ?: 'Plan description'); ?></div>
                
                <?php if (!empty($editing_plan['is_free'])): ?>
                <div class="preview-price preview-price-free">Free</div>
                <div class="preview-period"><?php _e('Forever', 'rental-gates'); ?></div>
                <?php else: ?>
                <div class="preview-price"><sup>$</sup><?php echo intval($editing_plan['price_monthly'] ?? 0); ?></div>
                <div class="preview-period">/month</div>
                <?php endif; ?>
                
                <div class="preview-features">
                    <?php 
                    $limit_labels = array(
                        'buildings' => 'buildings', 'units' => 'units', 'staff' => 'staff',
                        'vendors' => 'vendors', 'tenants' => 'tenants', 'storage_gb' => 'GB storage', 'ai_credits' => 'AI credits/mo'
                    );
                    foreach ($editing_plan['limits'] ?? array() as $key => $val):
                        if ($val == 0 || !isset($limit_labels[$key])) continue;
                    ?>
                    <div class="preview-feature">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <?php echo $val == -1 ? 'Unlimited ' . $limit_labels[$key] : $val . ' ' . $limit_labels[$key]; ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php foreach ($editing_plan['modules'] ?? array() as $key => $enabled):
                        if (!$enabled || !isset($module_definitions[$key])) continue;
                    ?>
                    <div class="preview-feature">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <?php echo esc_html($module_definitions[$key]['label']); ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php foreach ($editing_plan['custom_features'] ?? array() as $feature): ?>
                    <div class="preview-feature">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <?php echo esc_html($feature); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <span class="preview-btn <?php echo esc_attr($editing_plan['cta_style'] ?? 'outline'); ?>">
                    <?php echo esc_html($editing_plan['cta_text'] ?? 'Get Started'); ?>
                </span>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <!-- Plans List View -->
    <div class="plans-header">
        <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
            <p style="color: #78716c; margin: 0;"><?php printf(__('%d plans configured', 'rental-gates'), count($plans)); ?></p>
            <div style="display: flex; align-items: center; gap: 12px; font-size: 11px; color: #78716c;">
                <span style="display: flex; align-items: center; gap: 4px;">
                    <span style="width: 12px; height: 12px; background: #dcfce7; border: 1px solid #86efac; border-radius: 4px;"></span>
                    <?php _e('Active', 'rental-gates'); ?>
                </span>
                <span style="display: flex; align-items: center; gap: 4px;">
                    <span style="width: 12px; height: 12px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 4px;"></span>
                    <?php _e('Inactive', 'rental-gates'); ?>
                </span>
                <span style="display: flex; align-items: center; gap: 4px;">
                    <span style="width: 12px; height: 12px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 4px;"></span>
                    <?php _e('Visible', 'rental-gates'); ?>
                </span>
                <span style="display: flex; align-items: center; gap: 4px;">
                    <span style="width: 12px; height: 12px; background: #fefce8; border: 1px solid #fef08a; border-radius: 4px;"></span>
                    <?php _e('Hidden', 'rental-gates'); ?>
                </span>
            </div>
        </div>
        <div class="plans-actions">
            <form method="post" style="display: inline;" onsubmit="return confirm('<?php esc_attr_e('Reset all plans to defaults? This cannot be undone.', 'rental-gates'); ?>');">
                <input type="hidden" name="plans_action" value="reset_defaults">
                <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                <button type="submit" class="btn btn-secondary btn-sm">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                    <?php _e('Reset Defaults', 'rental-gates'); ?>
                </button>
            </form>
            <a href="<?php echo add_query_arg('edit', 'new', home_url('/rental-gates/admin/plans')); ?>" class="btn btn-primary btn-sm">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <?php _e('Add New Plan', 'rental-gates'); ?>
            </a>
        </div>
    </div>
    
    <?php if (empty($plans)): ?>
    <div class="plans-empty">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
        <h3><?php _e('No Plans Configured', 'rental-gates'); ?></h3>
        <p><?php _e('Create your first subscription plan to display on the pricing page.', 'rental-gates'); ?></p>
        <a href="<?php echo add_query_arg('edit', 'new', home_url('/rental-gates/admin/plans')); ?>" class="btn btn-primary">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <?php _e('Create First Plan', 'rental-gates'); ?>
        </a>
    </div>
    <?php else: ?>
    
    <div class="plans-list" id="plans-sortable">
        <?php foreach ($plans as $plan_id => $plan): 
            $enabled_modules = array_filter($plan['modules'] ?? array());
            $module_count = count($enabled_modules);
            $total_modules = count($module_definitions);
            $is_active = $plan['is_active'] ?? true; // Default to active
            $is_hidden = !empty($plan['is_hidden']);
        ?>
        <div class="plan-row <?php echo !empty($plan['is_featured']) ? 'featured' : ''; ?> <?php echo !$is_active ? 'inactive' : ''; ?> <?php echo $is_hidden ? 'hidden-plan' : ''; ?>" data-plan-id="<?php echo esc_attr($plan_id); ?>">
            <div class="plan-drag" title="<?php esc_attr_e('Drag to reorder', 'rental-gates'); ?>">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8h16M4 16h16"/></svg>
            </div>
            
            <div class="plan-info">
                <div class="plan-name">
                    <?php echo esc_html($plan['name']); ?>
                    <?php if (!$is_active): ?>
                    <span class="plan-badge inactive"><?php _e('Inactive', 'rental-gates'); ?></span>
                    <?php elseif ($is_hidden): ?>
                    <span class="plan-badge hidden"><?php _e('Hidden', 'rental-gates'); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($plan['is_featured'])): ?>
                    <span class="plan-badge featured">★ <?php _e('Featured', 'rental-gates'); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($plan['is_free'])): ?>
                    <span class="plan-badge free"><?php _e('Free', 'rental-gates'); ?></span>
                    <?php endif; ?>
                </div>
                <div class="plan-desc"><?php echo esc_html($plan['description']); ?></div>
            </div>
            
            <div class="plan-price">
                <?php if (!empty($plan['is_free'])): ?>
                <span class="plan-price-free">$0</span>
                <?php else: ?>
                $<?php echo esc_html($plan['price_monthly']); ?>/mo
                <?php endif; ?>
            </div>
            
            <div class="plan-limits">
                <?php 
                $units = $plan['limits']['units'] ?? 0;
                echo $units == -1 ? '∞ units' : $units . ' units';
                ?>
            </div>
            
            <div class="plan-modules" title="<?php echo esc_attr($module_count . '/' . $total_modules . ' modules enabled'); ?>">
                <?php foreach ($module_definitions as $mod_key => $mod_def): ?>
                <span class="plan-module-dot <?php echo !empty($plan['modules'][$mod_key]) ? 'active' : ''; ?>" 
                      title="<?php echo esc_attr($mod_def['label'] . ': ' . (!empty($plan['modules'][$mod_key]) ? 'Enabled' : 'Disabled')); ?>"></span>
                <?php endforeach; ?>
            </div>
            
            <div class="plan-actions">
                <!-- Toggle Active/Inactive -->
                <form method="post" action="" style="display: inline;">
                    <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                    <input type="hidden" name="plans_action" value="toggle_active">
                    <input type="hidden" name="toggle_plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <button type="submit" class="plan-action-btn <?php echo $is_active ? 'active-status' : 'inactive-status'; ?>" 
                            title="<?php echo $is_active ? esc_attr__('Click to Deactivate', 'rental-gates') : esc_attr__('Click to Activate', 'rental-gates'); ?>">
                        <?php if ($is_active): ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <?php else: ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <?php endif; ?>
                    </button>
                </form>
                
                <!-- Toggle Hidden -->
                <form method="post" action="" style="display: inline;">
                    <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                    <input type="hidden" name="plans_action" value="toggle_hidden">
                    <input type="hidden" name="toggle_plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <button type="submit" class="plan-action-btn <?php echo $is_hidden ? 'hidden-status' : 'visible-status'; ?>" 
                            title="<?php echo $is_hidden ? esc_attr__('Click to Show', 'rental-gates') : esc_attr__('Click to Hide', 'rental-gates'); ?>">
                        <?php if ($is_hidden): ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                        <?php else: ?>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                        <?php endif; ?>
                    </button>
                </form>
                
                <a href="<?php echo add_query_arg('edit', $plan_id, home_url('/rental-gates/admin/plans')); ?>" 
                   class="plan-action-btn" title="<?php esc_attr_e('Edit', 'rental-gates'); ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                </a>
                
                <form method="post" action="" style="display: inline;">
                    <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                    <input type="hidden" name="plans_action" value="duplicate">
                    <input type="hidden" name="duplicate_plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <button type="submit" class="plan-action-btn" title="<?php esc_attr_e('Duplicate', 'rental-gates'); ?>">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    </button>
                </form>
                
                <form method="post" action="" style="display: inline;">
                    <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                    <input type="hidden" name="plans_action" value="toggle_featured">
                    <input type="hidden" name="toggle_plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <button type="submit" class="plan-action-btn" title="<?php esc_attr_e('Toggle Featured', 'rental-gates'); ?>">
                        <svg fill="<?php echo !empty($plan['is_featured']) ? 'currentColor' : 'none'; ?>" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                    </button>
                </form>
                
                <form method="post" action="" style="display: inline;" onsubmit="return confirm('<?php esc_attr_e('Delete this plan? This cannot be undone.', 'rental-gates'); ?>');">
                    <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
                    <input type="hidden" name="plans_action" value="delete">
                    <input type="hidden" name="delete_plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <button type="submit" class="plan-action-btn delete" title="<?php esc_attr_e('Delete', 'rental-gates'); ?>">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Reorder form (hidden, submitted via JS) -->
    <form method="post" action="" id="reorder-form" style="display: none;">
        <?php wp_nonce_field('admin_plans', 'plans_nonce'); ?>
        <input type="hidden" name="plans_action" value="reorder">
        <input type="hidden" name="plan_order" id="plan-order-input" value="">
    </form>
    
    <script>
    // Simple drag & drop sorting
    (function() {
        var list = document.getElementById('plans-sortable');
        var dragging = null;
        
        list.querySelectorAll('.plan-row').forEach(function(row) {
            var handle = row.querySelector('.plan-drag');
            
            handle.addEventListener('mousedown', function(e) {
                dragging = row;
                row.style.opacity = '0.5';
            });
        });
        
        document.addEventListener('mouseup', function() {
            if (dragging) {
                dragging.style.opacity = '';
                
                // Get new order
                var order = [];
                list.querySelectorAll('.plan-row').forEach(function(row) {
                    order.push(row.dataset.planId);
                });
                
                // Submit reorder form
                document.getElementById('plan-order-input').value = JSON.stringify(order);
                document.getElementById('reorder-form').submit();
            }
            dragging = null;
        });
        
        list.addEventListener('mousemove', function(e) {
            if (!dragging) return;
            
            var rows = Array.from(list.querySelectorAll('.plan-row'));
            var draggingIndex = rows.indexOf(dragging);
            
            rows.forEach(function(row, index) {
                if (row === dragging) return;
                
                var rect = row.getBoundingClientRect();
                var midY = rect.top + rect.height / 2;
                
                if (e.clientY < midY && index < draggingIndex) {
                    list.insertBefore(dragging, row);
                } else if (e.clientY > midY && index > draggingIndex) {
                    list.insertBefore(dragging, row.nextSibling);
                }
            });
        });
    })();
    </script>
    <?php endif; ?>
    <?php endif; ?>
    </div><!-- end #tab-plans -->
    <?php endif; ?>
</div>
