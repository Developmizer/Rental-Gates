<?php
/**
 * Site Admin - Users Section
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$role_filter = isset($_GET['role']) ? sanitize_text_field($_GET['role']) : '';
$page_num = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$per_page = 25;
$offset = ($page_num - 1) * $per_page;

// Build query
$where = array("1=1");
$params = array();

if ($search) {
    $where[] = "(u.display_name LIKE %s OR u.user_email LIKE %s)";
    $params[] = '%' . $wpdb->esc_like($search) . '%';
    $params[] = '%' . $wpdb->esc_like($search) . '%';
}

$where_clause = implode(' AND ', $where);

// Get users with RG roles
$query = "SELECT u.ID, u.user_login, u.user_email, u.display_name, u.user_registered,
          (SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id = u.ID AND meta_key = '{$wpdb->prefix}capabilities' LIMIT 1) as capabilities
          FROM {$wpdb->users} u
          WHERE u.ID IN (
              SELECT DISTINCT user_id FROM {$wpdb->usermeta} 
              WHERE meta_key = '{$wpdb->prefix}capabilities' 
              AND meta_value LIKE '%rental_gates%'
          )
          AND $where_clause
          ORDER BY u.user_registered DESC
          LIMIT %d OFFSET %d";

$all_params = array_merge($params, array($per_page, $offset));
$users = $wpdb->get_results($wpdb->prepare($query, $all_params), ARRAY_A);

// Get total
$total_query = "SELECT COUNT(*) FROM {$wpdb->users} u
                WHERE u.ID IN (
                    SELECT DISTINCT user_id FROM {$wpdb->usermeta} 
                    WHERE meta_key = '{$wpdb->prefix}capabilities' 
                    AND meta_value LIKE '%rental_gates%'
                ) AND $where_clause";
$total = $wpdb->get_var($params ? $wpdb->prepare($total_query, $params) : $total_query);

// Parse roles
foreach ($users as &$user) {
    $caps = maybe_unserialize($user['capabilities']);
    $user['roles'] = array();
    if (is_array($caps)) {
        foreach ($caps as $cap => $active) {
            if (strpos($cap, 'rental_gates_') === 0 && $active) {
                $user['roles'][] = str_replace('rental_gates_', '', $cap);
            }
        }
    }
    
    // Get organization
    $user['organization'] = $wpdb->get_var($wpdb->prepare(
        "SELECT o.name FROM {$tables['organizations']} o
         JOIN {$tables['organization_members']} om ON o.id = om.organization_id
         WHERE om.user_id = %d LIMIT 1",
        $user['ID']
    ));
}
unset($user);

// Role stats
$role_stats = array(
    'site_admin' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_site_admin%'"),
    'owner' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_owner%'"),
    'manager' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_manager%'"),
    'staff' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_staff%'"),
    'tenant' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_tenant%'"),
    'vendor' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%rental_gates_vendor%'"),
);
?>

<header class="admin-header">
    <h1 class="header-title"><?php _e('Users', 'rental-gates'); ?></h1>
</header>

<div class="admin-content">
    <!-- Role Stats -->
    <div class="stats-grid mb-6" style="grid-template-columns: repeat(6, 1fr);">
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['site_admin']); ?></div>
                <div class="stat-label"><?php _e('Site Admins', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['owner']); ?></div>
                <div class="stat-label"><?php _e('Owners', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['manager']); ?></div>
                <div class="stat-label"><?php _e('Managers', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['staff']); ?></div>
                <div class="stat-label"><?php _e('Staff', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['tenant']); ?></div>
                <div class="stat-label"><?php _e('Tenants', 'rental-gates'); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($role_stats['vendor']); ?></div>
                <div class="stat-label"><?php _e('Vendors', 'rental-gates'); ?></div>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-6">
        <div class="card-body" style="padding: 16px 24px;">
            <form method="get" action="<?php echo home_url('/rental-gates/admin/users'); ?>" style="display: flex; gap: 16px; align-items: center;">
                <div class="search-box" style="flex: 1;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search users...', 'rental-gates'); ?>">
                </div>
                
                <button type="submit" class="btn btn-secondary"><?php _e('Search', 'rental-gates'); ?></button>
            </form>
        </div>
    </div>
    
    <!-- Users Table -->
    <div class="card">
        <div class="card-body" style="padding: 0;">
            <?php if (empty($users)): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                <h3><?php _e('No users found', 'rental-gates'); ?></h3>
            </div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th><?php _e('User', 'rental-gates'); ?></th>
                        <th><?php _e('Roles', 'rental-gates'); ?></th>
                        <th><?php _e('Organization', 'rental-gates'); ?></th>
                        <th><?php _e('Registered', 'rental-gates'); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 500;"><?php echo esc_html($user['display_name']); ?></div>
                            <div style="font-size: 12px; color: var(--gray-500);"><?php echo esc_html($user['user_email']); ?></div>
                        </td>
                        <td>
                            <?php foreach ($user['roles'] as $role): ?>
                            <span class="badge badge-<?php echo $role === 'site_admin' ? 'danger' : ($role === 'owner' ? 'info' : 'gray'); ?>" style="margin-right: 4px;">
                                <?php echo esc_html(ucfirst(str_replace('_', ' ', $role))); ?>
                            </span>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <?php echo $user['organization'] ? esc_html($user['organization']) : '<span class="text-muted">—</span>'; ?>
                        </td>
                        <td class="text-muted">
                            <?php echo date('M j, Y', strtotime($user['user_registered'])); ?>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo admin_url('user-edit.php?user_id=' . $user['ID']); ?>" class="btn btn-sm btn-outline" target="_blank">
                                <?php _e('Edit', 'rental-gates'); ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($total > $per_page): ?>
            <div style="padding: 16px 24px; border-top: 1px solid var(--gray-200); display: flex; align-items: center; justify-content: space-between;">
                <div class="text-muted">
                    <?php printf(__('Showing %d-%d of %d', 'rental-gates'), $offset + 1, min($offset + $per_page, $total), $total); ?>
                </div>
                <div style="display: flex; gap: 8px;">
                    <?php if ($page_num > 1): ?>
                    <a href="<?php echo add_query_arg('paged', $page_num - 1); ?>" class="btn btn-sm btn-outline"><?php _e('Previous', 'rental-gates'); ?></a>
                    <?php endif; ?>
                    <?php if ($offset + $per_page < $total): ?>
                    <a href="<?php echo add_query_arg('paged', $page_num + 1); ?>" class="btn btn-sm btn-outline"><?php _e('Next', 'rental-gates'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
