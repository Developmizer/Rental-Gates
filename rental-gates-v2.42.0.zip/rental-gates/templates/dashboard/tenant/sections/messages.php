<?php
/**
 * Tenant Messages Section
 * Communication between tenant and property management
 */
if (!defined('ABSPATH')) exit;

// $tenant, $tenant_id, $org_id are set in layout.php

$current_user_id = $tenant_id;
$current_user_type = 'tenant';

// Get threads for this tenant
$threads = Rental_Gates_Message::get_user_threads($org_id, $current_user_id, $current_user_type, 50);

// Get unread count
$unread_count = Rental_Gates_Message::get_unread_count($org_id, $current_user_id, $current_user_type);

// Check if viewing a specific thread
$active_thread_id = null;
$active_thread = null;
$active_messages = array();

if (preg_match('#/messages/(\d+)#', $_SERVER['REQUEST_URI'], $matches)) {
    $active_thread_id = intval($matches[1]);
    $active_thread = Rental_Gates_Message::get_thread($active_thread_id);
    
    // Verify tenant has access to this thread
    if ($active_thread && $active_thread['organization_id'] == $org_id) {
        $is_participant = (
            ($active_thread['participant_1_id'] == $current_user_id && $active_thread['participant_1_type'] == 'tenant') ||
            ($active_thread['participant_2_id'] == $current_user_id && $active_thread['participant_2_type'] == 'tenant')
        );
        
        if ($is_participant) {
            $active_messages = Rental_Gates_Message::get_thread_messages($active_thread_id);
            Rental_Gates_Message::mark_as_read($active_thread_id, $current_user_id, $current_user_type);
            
            // Get other participant info
            if ($active_thread['participant_1_id'] == $current_user_id && $active_thread['participant_1_type'] == 'tenant') {
                $active_thread['other_participant'] = Rental_Gates_Message::get_participant_info($active_thread['participant_2_id'], $active_thread['participant_2_type']);
            } else {
                $active_thread['other_participant'] = Rental_Gates_Message::get_participant_info($active_thread['participant_1_id'], $active_thread['participant_1_type']);
            }
        } else {
            $active_thread = null;
        }
    } else {
        $active_thread = null;
    }
}

// Get property management contacts (staff members)
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$staff_contacts = $wpdb->get_results($wpdb->prepare(
    "SELECT om.user_id, u.display_name, u.user_email, om.role_type
     FROM {$tables['organization_members']} om
     JOIN {$wpdb->users} u ON om.user_id = u.ID
     WHERE om.organization_id = %d
     AND om.status = 'active'
     AND om.role_type IN ('owner', 'manager', 'staff')
     ORDER BY FIELD(om.role_type, 'owner', 'manager', 'staff'), u.display_name ASC",
    $org_id
), ARRAY_A);
?>

<style>
    .tm-container { display: flex; height: calc(100vh - 140px); background: #fff; border-radius: 12px; overflow: hidden; border: 1px solid var(--gray-200); }
    
    /* Sidebar */
    .tm-sidebar { width: 320px; border-right: 1px solid var(--gray-200); display: flex; flex-direction: column; flex-shrink: 0; }
    .tm-sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
    .tm-sidebar-header h2 { margin: 0; font-size: 18px; font-weight: 700; color: var(--gray-900); display: flex; align-items: center; gap: 10px; }
    .tm-unread-badge { background: #ef4444; color: #fff; font-size: 12px; padding: 2px 10px; border-radius: 12px; }
    .tm-new-btn { margin-top: 12px; width: 100%; padding: 10px 16px; background: var(--primary); color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .tm-new-btn:hover { background: var(--primary-dark); }
    .tm-new-btn svg { width: 18px; height: 18px; }
    
    /* Thread List */
    .tm-threads { flex: 1; overflow-y: auto; }
    .tm-thread { display: flex; gap: 12px; padding: 16px 20px; border-bottom: 1px solid var(--gray-100); cursor: pointer; transition: background 0.2s; text-decoration: none; }
    .tm-thread:hover { background: var(--gray-50); }
    .tm-thread.active { background: #eff6ff; border-left: 3px solid var(--primary); }
    .tm-thread.unread { background: #fefce8; }
    .tm-thread.unread .tm-thread-name { font-weight: 700; }
    .tm-avatar { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), #8b5cf6); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 15px; flex-shrink: 0; }
    .tm-thread-content { flex: 1; min-width: 0; }
    .tm-thread-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
    .tm-thread-name { font-weight: 600; color: var(--gray-900); font-size: 14px; }
    .tm-thread-time { font-size: 12px; color: var(--gray-400); }
    .tm-thread-preview { font-size: 13px; color: var(--gray-500); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .tm-thread-role { font-size: 11px; color: var(--primary); text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px; }
    
    /* Chat Area */
    .tm-chat { flex: 1; display: flex; flex-direction: column; }
    .tm-chat-header { padding: 16px 24px; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; gap: 12px; }
    .tm-chat-header .tm-avatar { width: 40px; height: 40px; font-size: 14px; }
    .tm-chat-info h3 { margin: 0; font-size: 16px; font-weight: 600; color: var(--gray-900); }
    .tm-chat-info p { margin: 0; font-size: 13px; color: var(--gray-500); }
    
    /* Messages */
    .tm-messages { flex: 1; padding: 24px; overflow-y: auto; background: var(--gray-50); display: flex; flex-direction: column; }
    .tm-message { display: flex; gap: 10px; margin-bottom: 16px; max-width: 75%; }
    .tm-message.sent { margin-left: auto; flex-direction: row-reverse; }
    .tm-message-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--gray-300); display: flex; align-items: center; justify-content: center; font-size: 11px; color: #fff; flex-shrink: 0; }
    .tm-message-bubble { background: #fff; padding: 12px 16px; border-radius: 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    .tm-message.sent .tm-message-bubble { background: var(--primary); color: #fff; }
    .tm-message-text { font-size: 14px; line-height: 1.5; margin: 0; }
    .tm-message-time { font-size: 11px; color: var(--gray-400); margin-top: 4px; }
    .tm-message.sent .tm-message-time { color: rgba(255,255,255,0.7); }
    
    /* Compose */
    .tm-compose { padding: 16px 24px; border-top: 1px solid var(--gray-200); background: #fff; }
    .tm-compose-form { display: flex; gap: 12px; align-items: flex-end; }
    .tm-compose-input { flex: 1; padding: 12px 16px; border: 1px solid var(--gray-300); border-radius: 24px; font-size: 14px; resize: none; max-height: 120px; line-height: 1.5; }
    .tm-compose-input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
    .tm-send-btn { padding: 12px 20px; background: var(--primary); color: #fff; border: none; border-radius: 24px; font-size: 14px; font-weight: 500; cursor: pointer; display: flex; align-items: center; gap: 6px; }
    .tm-send-btn:hover { background: var(--primary-dark); }
    .tm-send-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .tm-send-btn svg { width: 18px; height: 18px; }
    
    /* Empty States */
    .tm-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--gray-400); text-align: center; padding: 40px; }
    .tm-empty svg { width: 64px; height: 64px; margin-bottom: 16px; opacity: 0.5; }
    .tm-empty h3 { margin: 0 0 8px; color: var(--gray-600); font-size: 18px; }
    .tm-empty p { margin: 0; font-size: 14px; }
    
    /* New Message Modal */
    .tm-modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 1000; align-items: center; justify-content: center; }
    .tm-modal.active { display: flex; }
    .tm-modal-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); }
    .tm-modal-content { position: relative; background: #fff; border-radius: 16px; width: 100%; max-width: 480px; max-height: 90vh; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    .tm-modal-header { padding: 20px 24px; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; justify-content: space-between; }
    .tm-modal-header h3 { margin: 0; font-size: 18px; font-weight: 600; }
    .tm-modal-close { background: none; border: none; font-size: 24px; color: var(--gray-400); cursor: pointer; padding: 0; line-height: 1; }
    .tm-modal-close:hover { color: var(--gray-600); }
    .tm-modal-body { padding: 24px; max-height: 400px; overflow-y: auto; }
    
    /* Contact List */
    .tm-contacts { list-style: none; margin: 0; padding: 0; }
    .tm-contact { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 8px; cursor: pointer; transition: background 0.2s; margin-bottom: 8px; }
    .tm-contact:hover { background: var(--gray-50); }
    .tm-contact .tm-avatar { width: 40px; height: 40px; font-size: 14px; }
    .tm-contact-info { flex: 1; }
    .tm-contact-name { font-weight: 600; color: var(--gray-900); font-size: 14px; }
    .tm-contact-role { font-size: 12px; color: var(--gray-500); text-transform: capitalize; }
    
    /* Responsive */
    @media (max-width: 768px) {
        .tm-container { flex-direction: column; height: auto; min-height: calc(100vh - 140px); }
        .tm-sidebar { width: 100%; max-height: 300px; border-right: none; border-bottom: 1px solid var(--gray-200); }
        .tm-chat { min-height: 400px; }
        .tm-message { max-width: 90%; }
    }
</style>

<div class="tm-container">
    <!-- Sidebar with threads -->
    <div class="tm-sidebar">
        <div class="tm-sidebar-header">
            <h2>
                <?php _e('Messages', 'rental-gates'); ?>
                <?php if ($unread_count > 0): ?>
                    <span class="tm-unread-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </h2>
            <button type="button" class="tm-new-btn" onclick="openNewMessageModal()">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                <?php _e('New Message', 'rental-gates'); ?>
            </button>
        </div>
        
        <div class="tm-threads">
            <?php if (empty($threads)): ?>
                <div class="tm-empty" style="height: auto; padding: 40px 20px;">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                    </svg>
                    <p><?php _e('No messages yet', 'rental-gates'); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($threads as $thread): 
                    $is_unread = $thread['unread_count'] > 0;
                    $is_active = $active_thread_id == $thread['id'];
                    
                    // Get other participant
                    if ($thread['participant_1_id'] == $current_user_id && $thread['participant_1_type'] == 'tenant') {
                        $other = Rental_Gates_Message::get_participant_info($thread['participant_2_id'], $thread['participant_2_type']);
                    } else {
                        $other = Rental_Gates_Message::get_participant_info($thread['participant_1_id'], $thread['participant_1_type']);
                    }
                    
                    $initials = strtoupper(substr($other['name'] ?? 'U', 0, 1));
                    if (strpos($other['name'] ?? '', ' ') !== false) {
                        $parts = explode(' ', $other['name']);
                        $initials = strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
                    }
                ?>
                <a href="<?php echo home_url('/rental-gates/tenant/messages/' . $thread['id']); ?>" 
                   class="tm-thread <?php echo $is_active ? 'active' : ''; ?> <?php echo $is_unread ? 'unread' : ''; ?>">
                    <div class="tm-avatar"><?php echo esc_html($initials); ?></div>
                    <div class="tm-thread-content">
                        <div class="tm-thread-header">
                            <span class="tm-thread-name"><?php echo esc_html($other['name'] ?? __('Unknown', 'rental-gates')); ?></span>
                            <span class="tm-thread-time">
                                <?php 
                                if ($thread['last_message_at']) {
                                    echo human_time_diff(strtotime($thread['last_message_at']));
                                }
                                ?>
                            </span>
                        </div>
                        <div class="tm-thread-preview">
                            <?php 
                            // Get message text - handle both object and string formats
                            $preview_text = '';
                            if (is_array($thread['last_message'])) {
                                $preview_text = $thread['last_message']['message'] ?? '';
                            } else {
                                $preview_text = $thread['last_message_text'] ?? $thread['last_message'] ?? '';
                            }
                            echo esc_html(wp_trim_words($preview_text, 10)); 
                            ?>
                        </div>
                        <div class="tm-thread-role"><?php echo esc_html(ucfirst($other['type'] ?? 'staff')); ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Chat Area -->
    <div class="tm-chat">
        <?php if ($active_thread): ?>
            <?php 
            $other = $active_thread['other_participant'];
            $initials = strtoupper(substr($other['name'] ?? 'U', 0, 1));
            if (strpos($other['name'] ?? '', ' ') !== false) {
                $parts = explode(' ', $other['name']);
                $initials = strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
            }
            ?>
            <div class="tm-chat-header">
                <div class="tm-avatar"><?php echo esc_html($initials); ?></div>
                <div class="tm-chat-info">
                    <h3><?php echo esc_html($other['name'] ?? __('Unknown', 'rental-gates')); ?></h3>
                    <p><?php echo esc_html(ucfirst($other['type'] ?? 'Staff')); ?></p>
                </div>
            </div>
            
            <div class="tm-messages" id="messagesContainer">
                <?php if (empty($active_messages)): ?>
                    <div class="tm-empty">
                        <p><?php _e('No messages in this conversation yet. Start the conversation below.', 'rental-gates'); ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($active_messages as $message): 
                        $is_sent = ($message['sender_id'] == $current_user_id && $message['sender_type'] == 'tenant');
                        $sender_initials = strtoupper(substr($message['sender_name'] ?? 'U', 0, 1));
                    ?>
                    <div class="tm-message <?php echo $is_sent ? 'sent' : ''; ?>">
                        <div class="tm-message-avatar"><?php echo esc_html($sender_initials); ?></div>
                        <div class="tm-message-bubble">
                            <p class="tm-message-text"><?php echo nl2br(esc_html($message['content'])); ?></p>
                            <div class="tm-message-time">
                                <?php echo date_i18n('M j, g:i a', strtotime($message['created_at'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="tm-compose">
                <form class="tm-compose-form" onsubmit="sendMessage(event)">
                    <textarea class="tm-compose-input" id="messageInput" placeholder="<?php esc_attr_e('Type your message...', 'rental-gates'); ?>" rows="1"></textarea>
                    <button type="submit" class="tm-send-btn" id="sendBtn">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                        </svg>
                        <?php _e('Send', 'rental-gates'); ?>
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="tm-empty">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                </svg>
                <h3><?php _e('Select a conversation', 'rental-gates'); ?></h3>
                <p><?php _e('Choose a conversation from the list or start a new one to contact your property manager.', 'rental-gates'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- New Message Modal -->
<div id="newMessageModal" class="tm-modal">
    <div class="tm-modal-overlay" onclick="closeNewMessageModal()"></div>
    <div class="tm-modal-content">
        <div class="tm-modal-header">
            <h3><?php _e('New Message', 'rental-gates'); ?></h3>
            <button type="button" class="tm-modal-close" onclick="closeNewMessageModal()">&times;</button>
        </div>
        <div class="tm-modal-body">
            <p style="margin: 0 0 16px; color: var(--gray-600);"><?php _e('Select a contact to start a conversation:', 'rental-gates'); ?></p>
            
            <?php if (empty($staff_contacts)): ?>
                <p style="color: var(--gray-500); text-align: center; padding: 20px;">
                    <?php _e('No contacts available', 'rental-gates'); ?>
                </p>
            <?php else: ?>
                <ul class="tm-contacts">
                    <?php foreach ($staff_contacts as $contact): 
                        $initials = strtoupper(substr($contact['display_name'], 0, 2));
                        $name_parts = explode(' ', $contact['display_name']);
                        if (count($name_parts) > 1) {
                            $initials = strtoupper(substr($name_parts[0], 0, 1) . substr(end($name_parts), 0, 1));
                        }
                    ?>
                    <li class="tm-contact" onclick="startConversation(<?php echo $contact['user_id']; ?>, 'staff', '<?php echo esc_js($contact['display_name']); ?>')">
                        <div class="tm-avatar"><?php echo esc_html($initials); ?></div>
                        <div class="tm-contact-info">
                            <div class="tm-contact-name"><?php echo esc_html($contact['display_name']); ?></div>
                            <div class="tm-contact-role"><?php echo esc_html(ucfirst($contact['role_type'])); ?></div>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
const nonce = '<?php echo wp_create_nonce('rental_gates_nonce'); ?>';
const currentThreadId = <?php echo $active_thread_id ? $active_thread_id : 'null'; ?>;
const tenantId = <?php echo $tenant_id; ?>;

function openNewMessageModal() {
    document.getElementById('newMessageModal').classList.add('active');
}

function closeNewMessageModal() {
    document.getElementById('newMessageModal').classList.remove('active');
}

async function startConversation(recipientId, recipientType, recipientName) {
    closeNewMessageModal();
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_start_thread',
                nonce: nonce,
                recipient_id: recipientId,
                recipient_type: recipientType,
                sender_type: 'tenant'
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.thread_id) {
            window.location.href = '<?php echo home_url('/rental-gates/tenant/messages/'); ?>' + result.data.thread_id;
        } else {
            alert(result.data?.message || '<?php _e('Error starting conversation', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Start conversation error:', error);
        alert('<?php _e('Error starting conversation', 'rental-gates'); ?>');
    }
}

async function sendMessage(e) {
    e.preventDefault();
    
    const input = document.getElementById('messageInput');
    const btn = document.getElementById('sendBtn');
    const message = input.value.trim();
    
    if (!message || !currentThreadId) return;
    
    btn.disabled = true;
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_send_message',
                nonce: nonce,
                thread_id: currentThreadId,
                content: message,
                sender_type: 'tenant'
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            input.value = '';
            
            // Add message to UI
            const container = document.getElementById('messagesContainer');
            const emptyState = container.querySelector('.tm-empty');
            if (emptyState) emptyState.remove();
            
            const msgDiv = document.createElement('div');
            msgDiv.className = 'tm-message sent';
            msgDiv.innerHTML = `
                <div class="tm-message-avatar"><?php echo strtoupper(substr($tenant['first_name'], 0, 1)); ?></div>
                <div class="tm-message-bubble">
                    <p class="tm-message-text">${escapeHtml(message)}</p>
                    <div class="tm-message-time"><?php _e('Just now', 'rental-gates'); ?></div>
                </div>
            `;
            container.appendChild(msgDiv);
            container.scrollTop = container.scrollHeight;
        } else {
            alert(result.data?.message || '<?php _e('Error sending message', 'rental-gates'); ?>');
        }
    } catch (error) {
        console.error('Send message error:', error);
        alert('<?php _e('Error sending message', 'rental-gates'); ?>');
    } finally {
        btn.disabled = false;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Auto-resize textarea
const textarea = document.getElementById('messageInput');
if (textarea) {
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    
    // Submit on Enter (but Shift+Enter for new line)
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            document.getElementById('sendBtn').click();
        }
    });
}

// Scroll to bottom on load
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('messagesContainer');
    if (container) {
        container.scrollTop = container.scrollHeight;
    }
});

// Poll for new messages every 10 seconds
let lastMessageId = <?php 
    $last_id = 0;
    if (!empty($active_messages)) {
        $last_msg = end($active_messages);
        $last_id = $last_msg['id'] ?? 0;
    }
    echo $last_id;
?>;

async function pollNewMessages() {
    if (!currentThreadId) return;
    
    try {
        const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'rental_gates_get_new_messages',
                nonce: nonce,
                thread_id: currentThreadId,
                after_id: lastMessageId
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.messages && result.data.messages.length > 0) {
            const container = document.getElementById('messagesContainer');
            const emptyState = container.querySelector('.tm-empty');
            if (emptyState) emptyState.remove();
            
            result.data.messages.forEach(msg => {
                // Skip messages from self (we already added them optimistically)
                if (msg.sender_type === 'tenant' && msg.sender_id == tenantId) return;
                
                // Check if message already exists
                if (document.querySelector(`[data-message-id="${msg.id}"]`)) return;
                
                const msgDiv = document.createElement('div');
                msgDiv.className = 'tm-message';
                msgDiv.setAttribute('data-message-id', msg.id);
                msgDiv.innerHTML = `
                    <div class="tm-message-avatar">${msg.sender_name ? msg.sender_name.charAt(0).toUpperCase() : 'U'}</div>
                    <div class="tm-message-bubble">
                        <p class="tm-message-text">${escapeHtml(msg.content || msg.message)}</p>
                        <div class="tm-message-time">${msg.time_formatted || '<?php _e('Just now', 'rental-gates'); ?>'}</div>
                    </div>
                `;
                container.appendChild(msgDiv);
                container.scrollTop = container.scrollHeight;
                
                lastMessageId = Math.max(lastMessageId, msg.id);
            });
        }
    } catch (error) {
        console.error('Poll error:', error);
    }
}

// Start polling if we have an active thread
if (currentThreadId) {
    setInterval(pollNewMessages, 10000); // Poll every 10 seconds
}

// Close modal on escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeNewMessageModal();
    }
});
</script>
