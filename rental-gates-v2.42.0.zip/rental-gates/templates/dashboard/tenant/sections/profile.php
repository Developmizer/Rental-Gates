<?php
/**
 * Tenant Profile Section
 */
if (!defined('ABSPATH')) exit;
?>

<style>
    .tp-profile-header { display: flex; align-items: center; gap: 20px; margin-bottom: 24px; padding: 24px; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; }
    .tp-profile-avatar { width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 28px; }
    .tp-profile-info h2 { margin: 0 0 4px 0; font-size: 22px; color: var(--gray-900); }
    .tp-profile-info p { margin: 0; color: var(--gray-500); font-size: 14px; }
    
    .tp-form-section { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 20px; }
    .tp-form-section-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); }
    .tp-form-section-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .tp-form-section-body { padding: 20px; }
    
    .tp-form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 16px; }
    .tp-form-row:last-child { margin-bottom: 0; }
    
    .tp-form-group { }
    .tp-form-group label { display: block; font-size: 14px; font-weight: 500; color: var(--gray-700); margin-bottom: 6px; }
    .tp-form-group input, .tp-form-group select { width: 100%; padding: 10px 14px; border: 1px solid var(--gray-300); border-radius: 8px; font-size: 14px; }
    .tp-form-group input:focus, .tp-form-group select:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
    .tp-form-group input:disabled { background: var(--gray-50); color: var(--gray-500); }
    .tp-form-hint { font-size: 12px; color: var(--gray-500); margin-top: 4px; }
    
    .tp-form-actions { display: flex; gap: 12px; justify-content: flex-end; padding-top: 20px; border-top: 1px solid var(--gray-100); margin-top: 20px; }
    
    .tp-success-message { background: #d1fae5; border: 1px solid #10b981; color: #065f46; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; display: none; }
    .tp-success-message.show { display: block; }
    
    .tp-emergency-contacts { }
    .tp-emergency-contact { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--gray-50); border-radius: 8px; margin-bottom: 8px; }
    .tp-emergency-contact-info { }
    .tp-emergency-contact-name { font-weight: 500; color: var(--gray-900); }
    .tp-emergency-contact-details { font-size: 13px; color: var(--gray-500); }
    
    @media (max-width: 768px) {
        .tp-form-row { grid-template-columns: 1fr; }
        .tp-profile-header { flex-direction: column; text-align: center; }
    }
</style>

<div class="tp-profile-header">
    <div class="tp-profile-avatar"><?php echo strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1)); ?></div>
    <div class="tp-profile-info">
        <h2><?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></h2>
        <p><?php echo esc_html($tenant['email']); ?></p>
    </div>
</div>

<div id="successMessage" class="tp-success-message">
    <?php _e('Your profile has been updated successfully.', 'rental-gates'); ?>
</div>

<form id="profileForm">
    <!-- Personal Information -->
    <div class="tp-form-section">
        <div class="tp-form-section-header">
            <h3 class="tp-form-section-title"><?php _e('Personal Information', 'rental-gates'); ?></h3>
        </div>
        <div class="tp-form-section-body">
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="first_name"><?php _e('First Name', 'rental-gates'); ?></label>
                    <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr($tenant['first_name']); ?>" disabled>
                    <div class="tp-form-hint"><?php _e('Contact your property manager to update your name.', 'rental-gates'); ?></div>
                </div>
                <div class="tp-form-group">
                    <label for="last_name"><?php _e('Last Name', 'rental-gates'); ?></label>
                    <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr($tenant['last_name']); ?>" disabled>
                </div>
            </div>
            
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="email"><?php _e('Email Address', 'rental-gates'); ?></label>
                    <input type="email" id="email" name="email" value="<?php echo esc_attr($tenant['email']); ?>" disabled>
                    <div class="tp-form-hint"><?php _e('Contact your property manager to update your email.', 'rental-gates'); ?></div>
                </div>
                <div class="tp-form-group">
                    <label for="phone"><?php _e('Phone Number', 'rental-gates'); ?></label>
                    <input type="tel" id="phone" name="phone" value="<?php echo esc_attr($tenant['phone']); ?>">
                </div>
            </div>
        </div>
    </div>
    
    <!-- Emergency Contact -->
    <div class="tp-form-section">
        <div class="tp-form-section-header">
            <h3 class="tp-form-section-title"><?php _e('Emergency Contact', 'rental-gates'); ?></h3>
        </div>
        <div class="tp-form-section-body">
            <?php 
            $emergency = $tenant['meta_data']['emergency_contact'] ?? array();
            ?>
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="emergency_name"><?php _e('Contact Name', 'rental-gates'); ?></label>
                    <input type="text" id="emergency_name" name="emergency_name" value="<?php echo esc_attr($emergency['name'] ?? ''); ?>" placeholder="<?php esc_attr_e('Full name', 'rental-gates'); ?>">
                </div>
                <div class="tp-form-group">
                    <label for="emergency_relationship"><?php _e('Relationship', 'rental-gates'); ?></label>
                    <input type="text" id="emergency_relationship" name="emergency_relationship" value="<?php echo esc_attr($emergency['relationship'] ?? ''); ?>" placeholder="<?php esc_attr_e('e.g., Spouse, Parent, Friend', 'rental-gates'); ?>">
                </div>
            </div>
            
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="emergency_phone"><?php _e('Phone Number', 'rental-gates'); ?></label>
                    <input type="tel" id="emergency_phone" name="emergency_phone" value="<?php echo esc_attr($emergency['phone'] ?? ''); ?>" placeholder="<?php esc_attr_e('(555) 123-4567', 'rental-gates'); ?>">
                </div>
                <div class="tp-form-group">
                    <label for="emergency_email"><?php _e('Email (Optional)', 'rental-gates'); ?></label>
                    <input type="email" id="emergency_email" name="emergency_email" value="<?php echo esc_attr($emergency['email'] ?? ''); ?>" placeholder="<?php esc_attr_e('email@example.com', 'rental-gates'); ?>">
                </div>
            </div>
        </div>
    </div>
    
    <!-- Vehicles (if applicable) -->
    <div class="tp-form-section">
        <div class="tp-form-section-header">
            <h3 class="tp-form-section-title"><?php _e('Vehicle Information', 'rental-gates'); ?></h3>
        </div>
        <div class="tp-form-section-body">
            <?php 
            $vehicle = $tenant['meta_data']['vehicle'] ?? array();
            ?>
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="vehicle_make"><?php _e('Make', 'rental-gates'); ?></label>
                    <input type="text" id="vehicle_make" name="vehicle_make" value="<?php echo esc_attr($vehicle['make'] ?? ''); ?>" placeholder="<?php esc_attr_e('e.g., Toyota', 'rental-gates'); ?>">
                </div>
                <div class="tp-form-group">
                    <label for="vehicle_model"><?php _e('Model', 'rental-gates'); ?></label>
                    <input type="text" id="vehicle_model" name="vehicle_model" value="<?php echo esc_attr($vehicle['model'] ?? ''); ?>" placeholder="<?php esc_attr_e('e.g., Camry', 'rental-gates'); ?>">
                </div>
            </div>
            
            <div class="tp-form-row">
                <div class="tp-form-group">
                    <label for="vehicle_color"><?php _e('Color', 'rental-gates'); ?></label>
                    <input type="text" id="vehicle_color" name="vehicle_color" value="<?php echo esc_attr($vehicle['color'] ?? ''); ?>" placeholder="<?php esc_attr_e('e.g., Silver', 'rental-gates'); ?>">
                </div>
                <div class="tp-form-group">
                    <label for="vehicle_plate"><?php _e('License Plate', 'rental-gates'); ?></label>
                    <input type="text" id="vehicle_plate" name="vehicle_plate" value="<?php echo esc_attr($vehicle['plate'] ?? ''); ?>" placeholder="<?php esc_attr_e('e.g., ABC 1234', 'rental-gates'); ?>">
                </div>
            </div>
            
            <div class="tp-form-hint" style="margin-top: 8px;">
                <?php _e('Vehicle information helps us manage parking and identify your car in emergencies.', 'rental-gates'); ?>
            </div>
        </div>
    </div>
    
    <!-- Communication Preferences -->
    <div class="tp-form-section">
        <div class="tp-form-section-header">
            <h3 class="tp-form-section-title"><?php _e('Communication Preferences', 'rental-gates'); ?></h3>
        </div>
        <div class="tp-form-section-body">
            <?php 
            $prefs = $tenant['meta_data']['communication_prefs'] ?? array();
            ?>
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" name="pref_email_reminders" value="1" <?php checked(!empty($prefs['email_reminders']) || empty($prefs)); ?> style="width: auto;">
                    <span><?php _e('Email reminders for rent due dates', 'rental-gates'); ?></span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" name="pref_email_maintenance" value="1" <?php checked(!empty($prefs['email_maintenance']) || empty($prefs)); ?> style="width: auto;">
                    <span><?php _e('Email updates on maintenance requests', 'rental-gates'); ?></span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" name="pref_email_announcements" value="1" <?php checked(!empty($prefs['email_announcements']) || empty($prefs)); ?> style="width: auto;">
                    <span><?php _e('Email announcements from property management', 'rental-gates'); ?></span>
                </label>
            </div>
        </div>
    </div>
    
    <div class="tp-form-actions">
        <button type="submit" class="tp-btn tp-btn-primary" id="saveBtn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                <polyline points="17 21 17 13 7 13 7 21"/>
                <polyline points="7 3 7 8 15 8"/>
            </svg>
            <?php _e('Save Changes', 'rental-gates'); ?>
        </button>
    </div>
</form>

<script>
document.getElementById('profileForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('saveBtn');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<?php echo esc_js(__('Saving...', 'rental-gates')); ?>';
    
    const formData = new FormData(this);
    formData.append('action', 'rental_gates_tenant_update_profile');
    formData.append('nonce', '<?php echo wp_create_nonce('rental_gates_nonce'); ?>');
    formData.append('tenant_id', '<?php echo intval($tenant_id); ?>');
    
    try {
        const response = await fetch(ajaxurl, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('successMessage').classList.add('show');
            setTimeout(() => {
                document.getElementById('successMessage').classList.remove('show');
            }, 3000);
        } else {
            alert(data.data?.message || '<?php echo esc_js(__('An error occurred', 'rental-gates')); ?>');
        }
    } catch (error) {
        alert('<?php echo esc_js(__('An error occurred', 'rental-gates')); ?>');
    }
    
    btn.disabled = false;
    btn.innerHTML = originalText;
});
</script>
