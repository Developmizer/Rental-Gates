<?php
/**
 * Tenant Dashboard Section
 */
if (!defined('ABSPATH')) exit;

// Collect all active lease IDs for queries
$active_lease_ids = array();
if (!empty($active_leases)) {
    foreach ($active_leases as $lease) {
        $active_lease_ids[] = intval($lease['id']);
    }
}
$lease_ids_sql = !empty($active_lease_ids) ? implode(',', $active_lease_ids) : '0';

// Get payment info - query by tenant_id for all payments across all leases
$next_payment = $wpdb->get_row($wpdb->prepare(
    "SELECT p.*, u.name as unit_name, b.name as building_name
     FROM {$tables['payments']} p
     LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
     WHERE p.organization_id = %d 
     AND p.tenant_id = %d 
     AND p.status IN ('pending', 'partially_paid')
     ORDER BY p.due_date ASC LIMIT 1",
    $org_id,
    $tenant_id
), ARRAY_A);

// Get recent payments across all leases
$recent_payments = $wpdb->get_results($wpdb->prepare(
    "SELECT p.*, u.name as unit_name
     FROM {$tables['payments']} p
     LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
     LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
     WHERE p.organization_id = %d 
     AND p.tenant_id = %d 
     ORDER BY p.created_at DESC LIMIT 5",
    $org_id,
    $tenant_id
), ARRAY_A);

// Get open maintenance requests
$open_maintenance = $wpdb->get_results($wpdb->prepare(
    "SELECT wo.*, b.name as building_name, u.name as unit_name 
     FROM {$tables['work_orders']} wo
     LEFT JOIN {$tables['buildings']} b ON wo.building_id = b.id
     LEFT JOIN {$tables['units']} u ON wo.unit_id = u.id
     WHERE wo.tenant_id = %d AND wo.status NOT IN ('completed', 'cancelled', 'declined')
     ORDER BY wo.created_at DESC LIMIT 5",
    $tenant_id
), ARRAY_A);

// Calculate totals across all active leases
$total_monthly_rent = 0;
$earliest_end_date = null;
$days_remaining = null;
$lease_progress = 0;

foreach ($active_leases as $lease) {
    $total_monthly_rent += floatval($lease['rent_amount']);
    
    // Track earliest ending lease for "days remaining"
    if (!empty($lease['end_date'])) {
        $end_ts = strtotime($lease['end_date']);
        if ($earliest_end_date === null || $end_ts < $earliest_end_date) {
            $earliest_end_date = $end_ts;
            $start = strtotime($lease['start_date']);
            $now = time();
            $total_days = max(1, ($end_ts - $start) / 86400);
            $elapsed_days = ($now - $start) / 86400;
            $lease_progress = min(100, max(0, ($elapsed_days / $total_days) * 100));
            $days_remaining = max(0, ceil(($end_ts - $now) / 86400));
        }
    }
}

$status_labels = array(
    'pending' => array('label' => __('Pending', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'succeeded' => array('label' => __('Paid', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'failed' => array('label' => __('Failed', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'partially_paid' => array('label' => __('Partial', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
);

$wo_status_labels = array(
    'open' => array('label' => __('Open', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe'),
    'assigned' => array('label' => __('Assigned', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe'),
    'in_progress' => array('label' => __('In Progress', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'on_hold' => array('label' => __('On Hold', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

// Helper function for ordinal numbers
if (!function_exists('rg_dash_ordinal')) {
    function rg_dash_ordinal($number) {
        $ends = array('th','st','nd','rd','th','th','th','th','th','th');
        if ((($number % 100) >= 11) && (($number % 100) <= 13)) {
            return $number . 'th';
        }
        return $number . $ends[$number % 10];
    }
}
?>

<style>
    .tp-welcome { margin-bottom: 24px; }
    .tp-welcome h2 { font-size: 24px; font-weight: 700; color: var(--gray-900); margin: 0 0 4px 0; }
    .tp-welcome p { color: var(--gray-500); margin: 0; }
    
    .tp-grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 20px; }
    .tp-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
    
    .tp-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; }
    .tp-stat-card.highlight { border-color: var(--primary); background: linear-gradient(135deg, #eff6ff 0%, #fff 100%); }
    .tp-stat-card.warning { border-color: #f59e0b; background: linear-gradient(135deg, #fffbeb 0%, #fff 100%); }
    .tp-stat-label { font-size: 13px; color: var(--gray-500); margin-bottom: 8px; }
    .tp-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .tp-stat-value.warning { color: #d97706; }
    .tp-stat-sub { font-size: 13px; color: var(--gray-500); margin-top: 4px; }
    
    .tp-payment-due { display: flex; justify-content: space-between; align-items: center; padding: 20px; background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%); border-radius: 12px; color: #fff; margin-bottom: 20px; }
    .tp-payment-due-info h3 { margin: 0 0 4px 0; font-size: 14px; font-weight: 500; opacity: 0.9; }
    .tp-payment-due-info .amount { font-size: 32px; font-weight: 700; }
    .tp-payment-due-info .due-date { font-size: 13px; opacity: 0.8; margin-top: 4px; }
    .tp-payment-due .tp-btn { background: #fff; color: #1e3a5f; }
    .tp-payment-due .tp-btn:hover { background: #f3f4f6; }
    
    .tp-list-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--gray-100); }
    .tp-list-item:last-child { border-bottom: none; }
    .tp-list-item-main { flex: 1; }
    .tp-list-item-title { font-weight: 500; color: var(--gray-900); }
    .tp-list-item-meta { font-size: 13px; color: var(--gray-500); margin-top: 2px; }
    
    .tp-badge { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    
    .tp-lease-progress { margin-top: 16px; }
    .tp-progress-bar { height: 8px; background: var(--gray-200); border-radius: 4px; overflow: hidden; }
    .tp-progress-fill { height: 100%; background: var(--primary); border-radius: 4px; transition: width 0.3s; }
    .tp-progress-labels { display: flex; justify-content: space-between; margin-top: 8px; font-size: 12px; color: var(--gray-500); }
    
    .tp-empty { text-align: center; padding: 30px; color: var(--gray-400); }
    .tp-empty svg { width: 40px; height: 40px; margin-bottom: 8px; opacity: 0.5; }
    
    .tp-quick-links { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .tp-quick-link { display: flex; align-items: center; gap: 12px; padding: 16px; background: var(--gray-50); border-radius: 10px; text-decoration: none; color: var(--gray-700); transition: all 0.2s; }
    .tp-quick-link:hover { background: #eff6ff; color: var(--primary); }
    .tp-quick-link svg { width: 24px; height: 24px; }
    .tp-quick-link span { font-weight: 500; }
    
    @media (max-width: 768px) {
        .tp-grid-2, .tp-grid-3 { grid-template-columns: 1fr; }
        .tp-payment-due { flex-direction: column; text-align: center; gap: 16px; }
        .tp-quick-links { grid-template-columns: 1fr; }
    }
</style>

<div class="tp-welcome">
    <h2><?php printf(__('Welcome back, %s', 'rental-gates'), esc_html($tenant['first_name'])); ?></h2>
    <p><?php _e('Here\'s an overview of your rental account.', 'rental-gates'); ?></p>
</div>

<?php if ($next_payment): 
    $is_overdue = strtotime($next_payment['due_date']) < time();
    $payment_unit_info = $next_payment['unit_name'] ?? '';
?>
<div class="tp-payment-due" <?php echo $is_overdue ? 'style="background: linear-gradient(135deg, #991b1b 0%, #dc2626 100%);"' : ''; ?>>
    <div class="tp-payment-due-info">
        <h3><?php echo $is_overdue ? __('Payment Overdue', 'rental-gates') : __('Next Payment Due', 'rental-gates'); ?></h3>
        <div class="amount">$<?php echo number_format($next_payment['amount'] - ($next_payment['amount_paid'] ?? 0), 2); ?></div>
        <div class="due-date">
            <?php echo $is_overdue ? __('Was due', 'rental-gates') : __('Due', 'rental-gates'); ?> 
            <?php echo date_i18n(get_option('date_format'), strtotime($next_payment['due_date'])); ?>
            <?php if ($payment_unit_info && count($active_leases) > 1): ?>
                <span style="opacity: 0.8;">• <?php echo esc_html($payment_unit_info); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <a href="<?php echo home_url('/rental-gates/tenant/payments'); ?>" class="tp-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
            <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
            <line x1="1" y1="10" x2="23" y2="10"/>
        </svg>
        <?php _e('Pay Now', 'rental-gates'); ?>
    </a>
</div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="tp-grid-3">
    <div class="tp-stat-card">
        <div class="tp-stat-label">
            <?php if (count($active_leases) > 1): ?>
                <?php _e('Total Monthly Rent', 'rental-gates'); ?>
            <?php else: ?>
                <?php _e('Monthly Rent', 'rental-gates'); ?>
            <?php endif; ?>
        </div>
        <div class="tp-stat-value">$<?php echo number_format($total_monthly_rent, 0); ?></div>
        <div class="tp-stat-sub">
            <?php if (count($active_leases) > 1): ?>
                <?php printf(__('%d active leases', 'rental-gates'), count($active_leases)); ?>
            <?php elseif ($current_lease): ?>
                <?php _e('Due on the', 'rental-gates'); ?> <?php echo rg_dash_ordinal(intval($current_lease['billing_day'] ?? $current_lease['rent_due_day'] ?? 1)); ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="tp-stat-card <?php echo ($days_remaining !== null && $days_remaining <= 60 && $days_remaining > 0) ? 'warning' : ''; ?>">
        <div class="tp-stat-label"><?php _e('Lease Status', 'rental-gates'); ?></div>
        <div class="tp-stat-value <?php echo ($days_remaining !== null && $days_remaining <= 60 && $days_remaining > 0) ? 'warning' : ''; ?>">
            <?php if ($days_remaining !== null && $days_remaining > 0): ?>
                <?php echo $days_remaining . ' ' . __('days', 'rental-gates'); ?>
            <?php elseif (!empty($active_leases)): ?>
                <?php _e('Active', 'rental-gates'); ?>
            <?php else: ?>
                <?php _e('No Lease', 'rental-gates'); ?>
            <?php endif; ?>
        </div>
        <div class="tp-stat-sub">
            <?php if ($earliest_end_date): ?>
                <?php _e('Until', 'rental-gates'); ?> <?php echo date_i18n('M j, Y', $earliest_end_date); ?>
            <?php elseif (!empty($active_leases)): ?>
                <?php _e('Month-to-month', 'rental-gates'); ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="tp-stat-card">
        <div class="tp-stat-label"><?php _e('Open Requests', 'rental-gates'); ?></div>
        <div class="tp-stat-value"><?php echo count($open_maintenance); ?></div>
        <div class="tp-stat-sub"><?php _e('Maintenance tickets', 'rental-gates'); ?></div>
    </div>
</div>

<!-- Lease Progress - show if at least one lease has an end date -->
<?php if ($earliest_end_date && $current_lease && !empty($current_lease['end_date'])): ?>
<div class="tp-card">
    <div class="tp-card-body">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <div style="font-weight: 600; color: var(--gray-900);">
                    <?php if (count($active_leases) > 1): ?>
                        <?php _e('Nearest Lease Expiration', 'rental-gates'); ?>
                    <?php else: ?>
                        <?php _e('Lease Progress', 'rental-gates'); ?>
                    <?php endif; ?>
                </div>
                <div style="font-size: 13px; color: var(--gray-500);">
                    <?php if (count($active_leases) > 1): ?>
                        <?php echo esc_html($current_lease['unit_name'] ?? ''); ?> - 
                    <?php endif; ?>
                    <?php echo date_i18n('M j, Y', strtotime($current_lease['start_date'])); ?> - <?php echo date_i18n('M j, Y', strtotime($current_lease['end_date'])); ?>
                </div>
            </div>
            <div style="font-size: 24px; font-weight: 700; color: var(--primary);"><?php echo round($lease_progress); ?>%</div>
        </div>
        <div class="tp-lease-progress">
            <div class="tp-progress-bar">
                <div class="tp-progress-fill" style="width: <?php echo $lease_progress; ?>%;"></div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="tp-grid-2">
    <!-- Recent Payments -->
    <div class="tp-card">
        <div class="tp-card-header">
            <h3 class="tp-card-title"><?php _e('Recent Payments', 'rental-gates'); ?></h3>
            <a href="<?php echo home_url('/rental-gates/tenant/payments'); ?>" style="font-size: 13px; color: var(--primary); text-decoration: none;">
                <?php _e('View All', 'rental-gates'); ?> →
            </a>
        </div>
        <div class="tp-card-body">
            <?php if (empty($recent_payments)): ?>
                <div class="tp-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                        <line x1="1" y1="10" x2="23" y2="10"/>
                    </svg>
                    <p><?php _e('No payment history yet', 'rental-gates'); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($recent_payments as $payment): 
                    $status = $status_labels[$payment['status']] ?? $status_labels['pending'];
                    $unit_info = $payment['unit_name'] ?? '';
                ?>
                    <div class="tp-list-item">
                        <div class="tp-list-item-main">
                            <div class="tp-list-item-title">$<?php echo number_format($payment['amount'], 2); ?></div>
                            <div class="tp-list-item-meta">
                                <?php echo date_i18n('M j, Y', strtotime($payment['due_date'] ?: $payment['created_at'])); ?>
                                <?php if ($unit_info && count($active_leases) > 1): ?>
                                    <span style="color: var(--gray-400);">•</span> <?php echo esc_html($unit_info); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <span class="tp-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                            <?php echo $status['label']; ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Maintenance Requests -->
    <div class="tp-card">
        <div class="tp-card-header">
            <h3 class="tp-card-title"><?php _e('Maintenance Requests', 'rental-gates'); ?></h3>
            <a href="<?php echo home_url('/rental-gates/tenant/maintenance'); ?>" style="font-size: 13px; color: var(--primary); text-decoration: none;">
                <?php _e('View All', 'rental-gates'); ?> →
            </a>
        </div>
        <div class="tp-card-body">
            <?php if (empty($open_maintenance)): ?>
                <div class="tp-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    <p><?php _e('No open maintenance requests', 'rental-gates'); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($open_maintenance as $wo): 
                    $wo_status = $wo_status_labels[$wo['status']] ?? $wo_status_labels['open'];
                ?>
                    <div class="tp-list-item">
                        <div class="tp-list-item-main">
                            <div class="tp-list-item-title"><?php echo esc_html($wo['title']); ?></div>
                            <div class="tp-list-item-meta"><?php echo date_i18n('M j', strtotime($wo['created_at'])); ?></div>
                        </div>
                        <span class="tp-badge" style="background: <?php echo $wo_status['bg']; ?>; color: <?php echo $wo_status['color']; ?>;">
                            <?php echo $wo_status['label']; ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Quick Links -->
<div class="tp-card">
    <div class="tp-card-header">
        <h3 class="tp-card-title"><?php _e('Quick Links', 'rental-gates'); ?></h3>
    </div>
    <div class="tp-card-body">
        <div class="tp-quick-links">
            <a href="<?php echo home_url('/rental-gates/tenant/maintenance'); ?>" class="tp-quick-link">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                </svg>
                <span><?php _e('Submit Maintenance Request', 'rental-gates'); ?></span>
            </a>
            <a href="<?php echo home_url('/rental-gates/tenant/payments'); ?>" class="tp-quick-link">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="1" x2="12" y2="23"/>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                </svg>
                <span><?php _e('Make a Payment', 'rental-gates'); ?></span>
            </a>
            <a href="<?php echo home_url('/rental-gates/tenant/lease'); ?>" class="tp-quick-link">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                </svg>
                <span><?php _e('View Lease Details', 'rental-gates'); ?></span>
            </a>
            <a href="<?php echo home_url('/rental-gates/tenant/profile'); ?>" class="tp-quick-link">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM12 14a7 7 0 0 0-7 7h14a7 7 0 0 0-7-7z"/>
                </svg>
                <span><?php _e('Update Contact Info', 'rental-gates'); ?></span>
            </a>
        </div>
    </div>
</div>

