<?php
/**
 * Tenant Payments Section - Stripe Embedded Checkout
 * 
 * Features:
 * - Embedded Checkout for in-site payments
 * - Auto-sync payment status from Stripe
 * - Receipt links and payment history
 * - Processing status for async payments
 */
if (!defined('ABSPATH')) exit;

// Get Stripe configuration
$stripe_configured = Rental_Gates_Stripe::is_configured();
$stripe_publishable_key = Rental_Gates_Stripe::get_publishable_key();

// Check if returning from payment - sync if needed
$synced_payment = null;
$sync_message = '';
if (isset($_GET['payment_synced']) && $_GET['payment_synced'] == '1') {
    $sync_message = 'success';
    // Try to get payment_id from URL for receipt link
    if (isset($_GET['payment_id'])) {
        $synced_payment = array('payment_id' => intval($_GET['payment_id']));
    }
} elseif (isset($_GET['session_id'])) {
    // Returning from Stripe - sync the payment
    $session_id = sanitize_text_field($_GET['session_id']);
    $sync_result = Rental_Gates_Stripe::sync_payment_from_session($session_id);
    
    // Get payment_id from URL if available
    $payment_id_from_url = isset($_GET['payment_id']) ? intval($_GET['payment_id']) : 0;
    
    if (!is_wp_error($sync_result) && isset($sync_result['status']) && $sync_result['status'] === 'synced') {
        $sync_message = 'success';
        $synced_payment = $sync_result;
    } elseif (!is_wp_error($sync_result) && isset($sync_result['status']) && $sync_result['status'] === 'already_synced') {
        $sync_message = 'success';
        // For already synced, use URL payment_id or try to get from sync result
        $synced_payment = array('payment_id' => $sync_result['payment_id'] ?? $payment_id_from_url);
    }
    
    // Redirect to clean URL after sync
    if ($sync_message === 'success') {
        $redirect_args = array('payment_synced' => '1');
        if (!empty($synced_payment['payment_id'])) {
            $redirect_args['payment_id'] = $synced_payment['payment_id'];
        }
        $redirect_url = add_query_arg($redirect_args, remove_query_arg(array('session_id', 'payment_id', 'status')));
        wp_redirect($redirect_url);
        exit;
    }
}

// Get all payments for this tenant - using tenant_id and lease relationships
// Note: Query via tenant_id OR through lease_tenants for complete coverage
$payments = array();

if ($tenant_id) {
    $payments = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT p.*, 
                l.rent_amount as lease_rent,
                u.name as unit_name,
                b.name as building_name,
                t.first_name as tenant_first_name, t.last_name as tenant_last_name
         FROM {$tables['payments']} p
         LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
         LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id
         LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
         LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
         LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id
         WHERE (p.tenant_id = %d OR lt.tenant_id = %d)
         AND p.organization_id = %d
         ORDER BY COALESCE(p.due_date, p.created_at) DESC, p.created_at DESC",
        $tenant_id,
        $tenant_id,
        $org_id
    ), ARRAY_A);
}

// If no payments exist, check if we should show a message about pending payments
$no_payments_message = '';
if (empty($payments) && $current_lease) {
    $no_payments_message = __('No payment records found. Your property manager will create payment records when rent is due.', 'rental-gates');
}

// Calculate totals
$total_paid = 0;
$total_pending = 0;
$total_overdue = 0;
$pending_count = 0;

foreach ($payments as $payment) {
    if ($payment['status'] === 'succeeded') {
        $total_paid += floatval($payment['amount_paid']);
    } elseif (in_array($payment['status'], array('pending', 'partially_paid', 'failed'))) {
        $remaining = floatval($payment['amount']) - floatval($payment['amount_paid']);
        if ($payment['due_date'] && strtotime($payment['due_date']) < time()) {
            $total_overdue += $remaining;
        } else {
            $total_pending += $remaining;
        }
        $pending_count++;
    } elseif ($payment['status'] === 'processing') {
        $total_pending += floatval($payment['amount']) - floatval($payment['amount_paid']);
    }
}

$status_config = array(
    'pending' => array('label' => __('Pending', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7', 'icon' => 'clock'),
    'processing' => array('label' => __('Processing', 'rental-gates'), 'color' => '#3b82f6', 'bg' => '#dbeafe', 'icon' => 'refresh'),
    'succeeded' => array('label' => __('Paid', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5', 'icon' => 'check'),
    'failed' => array('label' => __('Failed', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2', 'icon' => 'x'),
    'partially_paid' => array('label' => __('Partial', 'rental-gates'), 'color' => '#8b5cf6', 'bg' => '#ede9fe', 'icon' => 'minus'),
    'cancelled' => array('label' => __('Cancelled', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6', 'icon' => 'x'),
    'refunded' => array('label' => __('Refunded', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6', 'icon' => 'arrow-left'),
);

// Payment method labels
$method_labels = array(
    'stripe' => 'Card',
    'stripe_visa' => 'Visa',
    'stripe_mastercard' => 'Mastercard',
    'stripe_amex' => 'Amex',
    'stripe_discover' => 'Discover',
    'stripe_card' => 'Card',
    'cash' => 'Cash',
    'check' => 'Check',
    'bank_transfer' => 'Bank Transfer',
);
?>

<?php if ($stripe_configured): ?>
<script src="https://js.stripe.com/v3/"></script>
<?php endif; ?>

<style>
    .tp-success-banner {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: #fff;
        padding: 16px 20px;
        border-radius: 12px;
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        animation: slideDown 0.3s ease;
    }
    .tp-success-banner svg { flex-shrink: 0; }
    .tp-success-banner p { margin: 0; font-size: 14px; }
    @keyframes slideDown {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .tp-stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 24px; }
    .tp-stat-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 20px; }
    .tp-stat-card.success { border-color: #10b981; background: linear-gradient(135deg, #ecfdf5 0%, #fff 100%); }
    .tp-stat-card.warning { border-color: #f59e0b; background: linear-gradient(135deg, #fffbeb 0%, #fff 100%); }
    .tp-stat-card.danger { border-color: #ef4444; background: linear-gradient(135deg, #fef2f2 0%, #fff 100%); }
    .tp-stat-value { font-size: 28px; font-weight: 700; color: var(--gray-900); }
    .tp-stat-value.success { color: #059669; }
    .tp-stat-value.warning { color: #d97706; }
    .tp-stat-value.danger { color: #dc2626; }
    .tp-stat-label { font-size: 13px; color: var(--gray-500); margin-top: 4px; }
    
    .tp-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; overflow: hidden; }
    .tp-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
    .tp-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
    .tp-card-body { padding: 20px; }
    
    .tp-payment-info {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: #fff;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 24px;
    }
    .tp-payment-info h3 { margin: 0 0 8px; font-size: 16px; font-weight: 600; }
    .tp-payment-info p { margin: 0; opacity: 0.9; font-size: 14px; }
    
    .tp-payments-table { width: 100%; border-collapse: collapse; }
    .tp-payments-table th { 
        text-align: left; 
        padding: 12px 16px; 
        background: var(--gray-50); 
        font-weight: 600; 
        font-size: 12px; 
        text-transform: uppercase;
        color: var(--gray-500); 
        border-bottom: 1px solid var(--gray-200); 
    }
    .tp-payments-table td { padding: 16px; border-bottom: 1px solid var(--gray-100); vertical-align: middle; }
    .tp-payments-table tr:last-child td { border-bottom: none; }
    .tp-payments-table tr:hover td { background: var(--gray-50); }
    
    .tp-payment-amount { font-weight: 600; color: var(--gray-900); font-size: 15px; }
    .tp-payment-method { font-size: 12px; color: var(--gray-500); display: flex; align-items: center; gap: 4px; margin-top: 2px; }
    
    .tp-badge { 
        display: inline-flex; 
        align-items: center;
        gap: 6px;
        padding: 5px 12px; 
        border-radius: 20px; 
        font-size: 12px; 
        font-weight: 500; 
    }
    .tp-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
    
    .tp-overdue-badge { 
        display: inline-flex; 
        align-items: center; 
        gap: 4px; 
        padding: 3px 8px; 
        background: #fee2e2; 
        color: #dc2626; 
        border-radius: 4px; 
        font-size: 10px; 
        font-weight: 700; 
        margin-left: 8px;
        text-transform: uppercase;
    }
    
    .tp-pay-btn {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: #fff;
        border: none;
        padding: 8px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .tp-pay-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
    }
    .tp-pay-btn:disabled {
        background: var(--gray-300);
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    
    .tp-receipt-link {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        color: var(--primary);
        font-size: 12px;
        text-decoration: none;
        padding: 4px 8px;
        border-radius: 4px;
        transition: background 0.2s;
    }
    .tp-receipt-link:hover {
        background: var(--gray-100);
        text-decoration: none;
    }
    
    .tp-empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
    .tp-empty svg { width: 48px; height: 48px; margin-bottom: 12px; opacity: 0.5; }
    
    /* Processing indicator */
    .tp-processing-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 3px 10px;
        background: #dbeafe;
        color: #2563eb;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 500;
    }
    .tp-processing-badge .spinner-small {
        width: 12px;
        height: 12px;
        border: 2px solid #93c5fd;
        border-top-color: #2563eb;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    /* Checkout Modal Styles */
    .tp-checkout-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        padding: 20px;
        backdrop-filter: blur(4px);
    }
    .tp-checkout-overlay.active { display: flex; }
    
    .tp-checkout-modal {
        background: #fff;
        border-radius: 16px;
        max-width: 500px;
        width: 100%;
        max-height: 90vh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    }
    
    .tp-checkout-header {
        padding: 20px 24px;
        border-bottom: 1px solid var(--gray-200);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .tp-checkout-title { margin: 0; font-size: 18px; font-weight: 600; }
    .tp-checkout-close {
        background: none;
        border: none;
        font-size: 28px;
        cursor: pointer;
        color: var(--gray-400);
        padding: 0;
        line-height: 1;
        transition: color 0.2s;
    }
    .tp-checkout-close:hover { color: var(--gray-600); }
    
    .tp-checkout-body {
        flex: 1;
        overflow-y: auto;
        min-height: 400px;
    }
    
    .tp-checkout-loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 60px 20px;
        color: var(--gray-500);
    }
    .tp-checkout-loading .spinner {
        width: 48px;
        height: 48px;
        border: 4px solid var(--gray-200);
        border-top-color: #635bff;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 16px;
    }
    
    .tp-checkout-error {
        padding: 40px 24px;
        text-align: center;
    }
    .tp-checkout-error-icon {
        width: 64px;
        height: 64px;
        background: #fee2e2;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px;
    }
    .tp-checkout-error h3 { margin: 0 0 8px; color: var(--gray-900); }
    .tp-checkout-error p { margin: 0 0 20px; color: var(--gray-500); font-size: 14px; }
    
    .tp-fallback-btn {
        background: #635bff;
        color: #fff;
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.2s;
    }
    .tp-fallback-btn:hover { background: #4f46e5; }
    
    .tp-checkout-footer {
        padding: 12px 24px;
        border-top: 1px solid var(--gray-200);
        text-align: center;
        background: var(--gray-50);
    }
    .tp-secure-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: var(--gray-500);
    }
    
    #embedded-checkout-container {
        min-height: 400px;
    }
    
    @media (max-width: 768px) {
        .tp-stats-row { grid-template-columns: 1fr; }
        .tp-checkout-modal { max-width: 100%; border-radius: 12px 12px 0 0; max-height: 95vh; }
        .tp-checkout-overlay { padding: 0; align-items: flex-end; }
        .tp-payments-table { display: block; overflow-x: auto; }
    }
</style>

<?php if ($sync_message === 'success'): 
    // Try to get the most recent receipt
    $recent_receipt = null;
    if (!empty($synced_payment['payment_id'])) {
        $recent_receipt = Rental_Gates_Invoice::get_by_payment($synced_payment['payment_id']);
    }
?>
<div class="tp-success-banner">
    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
        <polyline points="22 4 12 14.01 9 11.01"/>
    </svg>
    <div style="flex: 1;">
        <p><strong><?php _e('Payment Successful!', 'rental-gates'); ?></strong> <?php _e('Your payment has been processed. Thank you!', 'rental-gates'); ?></p>
        <?php if ($recent_receipt): ?>
        <p style="margin-top: 4px; font-size: 13px; opacity: 0.9;">
            <a href="<?php echo home_url('/rental-gates/tenant/invoice?id=' . $recent_receipt['id']); ?>" style="color: #fff; text-decoration: underline;">
                <?php _e('View Receipt', 'rental-gates'); ?> →
            </a>
        </p>
        <?php endif; ?>
    </div>
    <button onclick="this.parentElement.remove()" style="background: transparent; border: none; color: #fff; opacity: 0.7; cursor: pointer; font-size: 20px; padding: 0 8px;">&times;</button>
</div>
<?php endif; ?>

<!-- Stats -->
<div class="tp-stats-row">
    <div class="tp-stat-card success">
        <div class="tp-stat-value success">$<?php echo number_format($total_paid, 2); ?></div>
        <div class="tp-stat-label"><?php _e('Total Paid', 'rental-gates'); ?></div>
    </div>
    <div class="tp-stat-card <?php echo $total_pending > 0 ? 'warning' : ''; ?>">
        <div class="tp-stat-value <?php echo $total_pending > 0 ? 'warning' : ''; ?>">$<?php echo number_format($total_pending, 2); ?></div>
        <div class="tp-stat-label"><?php _e('Pending', 'rental-gates'); ?></div>
    </div>
    <div class="tp-stat-card <?php echo $total_overdue > 0 ? 'danger' : ''; ?>">
        <div class="tp-stat-value <?php echo $total_overdue > 0 ? 'danger' : ''; ?>">$<?php echo number_format($total_overdue, 2); ?></div>
        <div class="tp-stat-label"><?php _e('Overdue', 'rental-gates'); ?></div>
    </div>
</div>

<?php if ($total_overdue > 0): ?>
<div class="tp-payment-info" style="background: linear-gradient(135deg, #991b1b 0%, #dc2626 100%);">
    <h3><?php _e('Payment Overdue', 'rental-gates'); ?></h3>
    <p><?php _e('You have overdue payments. Please make a payment as soon as possible to avoid late fees.', 'rental-gates'); ?></p>
</div>
<?php elseif (!$stripe_configured): ?>
<div class="tp-payment-info" style="background: linear-gradient(135deg, #92400e 0%, #d97706 100%);">
    <h3><?php _e('Online Payments Not Available', 'rental-gates'); ?></h3>
    <p><?php _e('Online payments are not currently enabled. Please contact your property manager for payment options.', 'rental-gates'); ?></p>
</div>
<?php elseif ($pending_count > 0): ?>
<div class="tp-payment-info">
    <h3><?php _e('Secure Online Payments', 'rental-gates'); ?></h3>
    <p><?php _e('Pay your rent securely with credit card, debit card, or bank transfer. All payments are processed through Stripe.', 'rental-gates'); ?></p>
</div>
<?php endif; ?>

<!-- Payments List -->
<div class="tp-card">
    <div class="tp-card-header">
        <h3 class="tp-card-title"><?php _e('Payment History', 'rental-gates'); ?></h3>
    </div>
    <?php if (empty($payments)): ?>
        <div class="tp-card-body">
            <div class="tp-empty">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                    <line x1="1" y1="10" x2="23" y2="10"/>
                </svg>
                <p><?php echo $no_payments_message ?: __('No payments found.', 'rental-gates'); ?></p>
                <?php if ($current_lease): ?>
                <p style="font-size: 13px; margin-top: 8px; color: var(--gray-400);">
                    <?php _e('When payments are due, they will appear here.', 'rental-gates'); ?>
                </p>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <table class="tp-payments-table">
            <thead>
                <tr>
                    <th><?php _e('Due Date', 'rental-gates'); ?></th>
                    <th><?php _e('Description', 'rental-gates'); ?></th>
                    <th><?php _e('Amount', 'rental-gates'); ?></th>
                    <th><?php _e('Paid', 'rental-gates'); ?></th>
                    <th><?php _e('Status', 'rental-gates'); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($payments as $payment): 
                    $status = $status_config[$payment['status']] ?? $status_config['pending'];
                    $is_overdue = in_array($payment['status'], array('pending', 'partially_paid', 'failed')) && $payment['due_date'] && strtotime($payment['due_date']) < time();
                    $can_pay = in_array($payment['status'], array('pending', 'partially_paid', 'failed'));
                    $balance = floatval($payment['amount']) - floatval($payment['amount_paid']);
                    
                    // Get Stripe details from meta
                    $meta = is_string($payment['meta_data']) ? json_decode($payment['meta_data'], true) : ($payment['meta_data'] ?: array());
                    $stripe_details = $meta['stripe_details'] ?? array();
                    $receipt_url = $stripe_details['receipt_url'] ?? '';
                    $card_last4 = $stripe_details['card_last4'] ?? '';
                    $card_brand = $stripe_details['card_brand'] ?? '';
                    
                    // Method label
                    $method_label = $method_labels[$payment['method']] ?? ucfirst($payment['method'] ?? '');
                    if ($card_brand) {
                        $method_label = ucfirst($card_brand);
                    }
                ?>
                    <tr>
                        <td>
                            <div style="color: var(--gray-900); font-weight: 500;">
                                <?php echo $payment['due_date'] ? date_i18n('M j, Y', strtotime($payment['due_date'])) : '—'; ?>
                            </div>
                        </td>
                        <td>
                            <div style="font-weight: 500; color: var(--gray-800);"><?php echo esc_html(ucfirst($payment['type'] ?? 'rent')); ?></div>
                            <?php if ($payment['period_start'] && $payment['period_end']): ?>
                                <div style="font-size: 12px; color: var(--gray-400);">
                                    <?php echo date_i18n('M j', strtotime($payment['period_start'])); ?> - <?php echo date_i18n('M j, Y', strtotime($payment['period_end'])); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="tp-payment-amount">$<?php echo number_format($payment['amount'], 2); ?></div>
                        </td>
                        <td>
                            <div class="tp-payment-amount" style="color: <?php echo floatval($payment['amount_paid']) > 0 ? '#059669' : 'var(--gray-400)'; ?>">
                                $<?php echo number_format($payment['amount_paid'], 2); ?>
                            </div>
                            <?php if ($payment['status'] === 'succeeded' && $method_label): ?>
                                <div class="tp-payment-method">
                                    <?php if ($card_last4): ?>
                                        •••• <?php echo esc_html($card_last4); ?>
                                    <?php else: ?>
                                        <?php echo esc_html($method_label); ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($payment['status'] === 'processing'): ?>
                                <span class="tp-processing-badge">
                                    <span class="spinner-small"></span>
                                    <?php _e('Processing', 'rental-gates'); ?>
                                </span>
                            <?php else: ?>
                                <span class="tp-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                                    <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                                    <?php echo $status['label']; ?>
                                </span>
                            <?php endif; ?>
                            <?php if ($is_overdue): ?>
                                <span class="tp-overdue-badge"><?php _e('OVERDUE', 'rental-gates'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">
                            <?php if ($payment['status'] === 'succeeded'): 
                                // Check for internal receipt
                                $internal_receipt = Rental_Gates_Invoice::get_by_payment($payment['id']);
                            ?>
                                <?php if ($internal_receipt): ?>
                                    <a href="<?php echo home_url('/rental-gates/tenant/invoice?id=' . $internal_receipt['id']); ?>" class="tp-receipt-link" style="margin-right: 8px;">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                            <polyline points="14 2 14 8 20 8"/>
                                        </svg>
                                        <?php _e('Receipt', 'rental-gates'); ?>
                                    </a>
                                <?php elseif ($receipt_url): ?>
                                    <a href="<?php echo esc_url($receipt_url); ?>" target="_blank" class="tp-receipt-link">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                            <polyline points="14 2 14 8 20 8"/>
                                        </svg>
                                        <?php _e('Stripe Receipt', 'rental-gates'); ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color: var(--gray-400); font-size: 12px;"><?php _e('Paid', 'rental-gates'); ?></span>
                                <?php endif; ?>
                            <?php elseif ($stripe_configured && $can_pay && $balance > 0): ?>
                                <button type="button" class="tp-pay-btn" onclick="openEmbeddedCheckout(<?php echo $payment['id']; ?>, <?php echo $balance; ?>)">
                                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                                        <line x1="1" y1="10" x2="23" y2="10"/>
                                    </svg>
                                    <?php _e('Pay Now', 'rental-gates'); ?>
                                </button>
                            <?php elseif ($payment['status'] === 'processing'): ?>
                                <span style="font-size: 12px; color: var(--gray-400);"><?php _e('3-5 business days', 'rental-gates'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php if ($stripe_configured): ?>
<!-- Embedded Checkout Modal -->
<div class="tp-checkout-overlay" id="checkout-modal">
    <div class="tp-checkout-modal">
        <div class="tp-checkout-header">
            <h3 class="tp-checkout-title"><?php _e('Complete Payment', 'rental-gates'); ?></h3>
            <button type="button" class="tp-checkout-close" onclick="closeCheckout()" aria-label="Close">&times;</button>
        </div>
        <div class="tp-checkout-body">
            <!-- Loading State -->
            <div id="checkout-loading" class="tp-checkout-loading">
                <div class="spinner"></div>
                <p><?php _e('Loading secure checkout...', 'rental-gates'); ?></p>
            </div>
            
            <!-- Embedded Checkout Container -->
            <div id="embedded-checkout-container" style="display: none;"></div>
            
            <!-- Error State with Fallback -->
            <div id="checkout-error" class="tp-checkout-error" style="display: none;">
                <div class="tp-checkout-error-icon">
                    <svg width="32" height="32" fill="none" stroke="#dc2626" stroke-width="2" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 8v4M12 16h.01"/>
                    </svg>
                </div>
                <h3><?php _e('Unable to Load Checkout', 'rental-gates'); ?></h3>
                <p id="checkout-error-message"><?php _e('There was an issue loading the checkout form.', 'rental-gates'); ?></p>
                <button type="button" class="tp-fallback-btn" onclick="useHostedCheckout()">
                    <?php _e('Continue to Stripe Checkout', 'rental-gates'); ?>
                </button>
            </div>
        </div>
        <div class="tp-checkout-footer">
            <span class="tp-secure-badge">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                <?php _e('Secured by Stripe', 'rental-gates'); ?>
            </span>
        </div>
    </div>
</div>

<script>
// Ensure rentalGatesData is available
const rgAjaxUrl = (typeof rentalGatesData !== 'undefined' && rentalGatesData.ajaxUrl) 
    ? rentalGatesData.ajaxUrl 
    : '<?php echo admin_url('admin-ajax.php'); ?>';

const stripe = Stripe('<?php echo esc_js($stripe_publishable_key); ?>');
let currentCheckout = null;
let currentPaymentId = null;

/**
 * Open Embedded Checkout for a payment
 */
async function openEmbeddedCheckout(paymentId, amount) {
    currentPaymentId = paymentId;
    
    // Show modal with loading state
    document.getElementById('checkout-modal').classList.add('active');
    document.getElementById('checkout-loading').style.display = 'flex';
    document.getElementById('embedded-checkout-container').style.display = 'none';
    document.getElementById('checkout-error').style.display = 'none';
    
    try {
        // Create Checkout Session (embedded mode)
        const response = await fetch(rgAjaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'rental_gates_stripe_create_payment_intent',
                nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                payment_id: paymentId,
                ui_mode: 'embedded'
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.data?.message || 'Failed to create checkout session');
        }
        
        // Initialize Embedded Checkout
        currentCheckout = await stripe.initEmbeddedCheckout({
            clientSecret: result.data.client_secret,
        });
        
        // Hide loading, show checkout
        document.getElementById('checkout-loading').style.display = 'none';
        document.getElementById('embedded-checkout-container').style.display = 'block';
        
        // Mount checkout
        currentCheckout.mount('#embedded-checkout-container');
        
    } catch (error) {
        console.error('Checkout error:', error);
        showCheckoutError(error.message);
    }
}

/**
 * Show error state with fallback option
 */
function showCheckoutError(message) {
    document.getElementById('checkout-loading').style.display = 'none';
    document.getElementById('embedded-checkout-container').style.display = 'none';
    document.getElementById('checkout-error').style.display = 'block';
    document.getElementById('checkout-error-message').textContent = message || '<?php _e('Unable to load embedded checkout.', 'rental-gates'); ?>';
}

/**
 * Fallback to hosted (redirect) checkout
 */
async function useHostedCheckout() {
    if (!currentPaymentId) return;
    
    document.getElementById('checkout-error').innerHTML = `
        <div class="tp-checkout-loading">
            <div class="spinner"></div>
            <p><?php _e('Redirecting to secure checkout...', 'rental-gates'); ?></p>
        </div>
    `;
    
    try {
        // Create Checkout Session (hosted mode)
        const response = await fetch(rgAjaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'rental_gates_stripe_create_payment_intent',
                nonce: '<?php echo wp_create_nonce('rental_gates_stripe'); ?>',
                payment_id: currentPaymentId,
                ui_mode: 'hosted'
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.data?.message || 'Failed to create checkout session');
        }
        
        // Redirect to Stripe hosted checkout
        window.location.href = result.data.redirect_url;
        
    } catch (error) {
        console.error('Hosted checkout error:', error);
        alert('<?php _e('Unable to process payment. Please try again later.', 'rental-gates'); ?>');
        closeCheckout();
    }
}

/**
 * Close checkout modal
 */
function closeCheckout() {
    document.getElementById('checkout-modal').classList.remove('active');
    
    // Destroy embedded checkout if it exists
    if (currentCheckout) {
        currentCheckout.destroy();
        currentCheckout = null;
    }
    
    // Reset container
    document.getElementById('embedded-checkout-container').innerHTML = '';
    
    currentPaymentId = null;
}

// Close modal on backdrop click
document.getElementById('checkout-modal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeCheckout();
    }
});

// Close on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && document.getElementById('checkout-modal').classList.contains('active')) {
        closeCheckout();
    }
});
</script>
<?php endif; ?>
