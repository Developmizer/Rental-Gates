<?php
/**
 * Tenant Lease Section - Supports Multiple Active Leases
 */
if (!defined('ABSPATH')) exit;

// Get past/ended leases for history using the model
$lease_history = Rental_Gates_Lease::get_for_tenant($tenant_id, array(
    'status' => array('ended', 'terminated', 'expired'),
    'org_id' => $org_id,
));

$status_config = array(
    'active' => array('label' => __('Active', 'rental-gates'), 'color' => '#10b981', 'bg' => '#d1fae5'),
    'draft' => array('label' => __('Draft', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'ending' => array('label' => __('Ending Soon', 'rental-gates'), 'color' => '#f59e0b', 'bg' => '#fef3c7'),
    'ended' => array('label' => __('Ended', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
    'terminated' => array('label' => __('Terminated', 'rental-gates'), 'color' => '#ef4444', 'bg' => '#fee2e2'),
    'expired' => array('label' => __('Expired', 'rental-gates'), 'color' => '#6b7280', 'bg' => '#f3f4f6'),
);

// Helper function for ordinal numbers
if (!function_exists('rg_ordinal')) {
    function rg_ordinal($number) {
        $ends = array('th','st','nd','rd','th','th','th','th','th','th');
        if ((($number % 100) >= 11) && (($number % 100) <= 13)) {
            return $number . 'th';
        }
        return $number . $ends[$number % 10];
    }
}
?>

<style>
    .tp-lease-section-title { font-size: 18px; font-weight: 700; color: var(--gray-900); margin: 0 0 16px 0; display: flex; align-items: center; gap: 8px; }
    .tp-lease-count { background: var(--primary); color: #fff; font-size: 12px; padding: 2px 8px; border-radius: 12px; font-weight: 600; }
    
    .tp-lease-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 16px; padding: 24px; margin-bottom: 20px; transition: all 0.2s; }
    .tp-lease-card.active-lease { border: 2px solid var(--primary); background: linear-gradient(135deg, #eff6ff 0%, #fff 100%); }
    .tp-lease-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    
    .tp-lease-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
    .tp-lease-card-title { font-size: 18px; font-weight: 700; color: var(--gray-900); margin: 0 0 4px 0; }
    .tp-lease-card-sub { font-size: 14px; color: var(--gray-500); }
    
    .tp-lease-details { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .tp-lease-detail { }
    .tp-lease-detail-label { font-size: 12px; font-weight: 500; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
    .tp-lease-detail-value { font-size: 15px; font-weight: 600; color: var(--gray-900); }
    .tp-lease-detail-value.highlight { color: var(--primary); }
    
    .tp-lease-progress { margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--gray-200); }
    .tp-progress-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .tp-progress-label { font-size: 13px; font-weight: 500; color: var(--gray-700); }
    .tp-progress-value { font-size: 13px; font-weight: 600; color: var(--primary); }
    .tp-progress-bar { height: 8px; background: var(--gray-200); border-radius: 4px; overflow: hidden; }
    .tp-progress-fill { height: 100%; background: linear-gradient(90deg, var(--primary), #60a5fa); border-radius: 4px; transition: width 0.3s; }
    .tp-progress-dates { display: flex; justify-content: space-between; margin-top: 8px; font-size: 12px; color: var(--gray-500); }
    
    .tp-badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .tp-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
    
    .tp-alert-box { border-radius: 10px; padding: 14px 16px; margin-top: 16px; display: flex; align-items: flex-start; gap: 12px; }
    .tp-alert-box.warning { background: #fef3c7; border: 1px solid #fcd34d; }
    .tp-alert-box.info { background: #dbeafe; border: 1px solid #93c5fd; }
    .tp-alert-box .alert-icon { flex-shrink: 0; width: 20px; height: 20px; }
    .tp-alert-box .alert-content h4 { margin: 0 0 4px; font-size: 14px; font-weight: 600; }
    .tp-alert-box .alert-content p { margin: 0; font-size: 13px; line-height: 1.5; }
    .tp-alert-box.warning .alert-content { color: #92400e; }
    .tp-alert-box.info .alert-content { color: #1e40af; }
    
    .tp-history-section { margin-top: 32px; }
    .tp-history-item { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; padding: 16px 20px; margin-bottom: 12px; }
    .tp-history-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .tp-history-title { font-weight: 600; color: var(--gray-900); font-size: 15px; }
    .tp-history-meta { display: flex; gap: 16px; font-size: 13px; color: var(--gray-500); flex-wrap: wrap; }
    .tp-history-meta span { display: flex; align-items: center; gap: 4px; }
    
    .tp-no-lease { text-align: center; padding: 60px 20px; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; }
    .tp-no-lease svg { width: 56px; height: 56px; color: var(--gray-300); margin-bottom: 16px; }
    .tp-no-lease h3 { color: var(--gray-900); margin: 0 0 8px; font-size: 18px; }
    .tp-no-lease p { color: var(--gray-500); margin: 0; max-width: 400px; margin: 0 auto; }
    
    .tp-info-card { background: var(--gray-50); border-radius: 12px; padding: 20px; margin-top: 24px; }
    .tp-info-card h4 { margin: 0 0 8px; font-size: 14px; font-weight: 600; color: var(--gray-700); }
    .tp-info-card p { margin: 0; font-size: 13px; color: var(--gray-500); line-height: 1.6; }
    
    @media (max-width: 768px) {
        .tp-lease-details { grid-template-columns: 1fr; }
        .tp-lease-card-header { flex-direction: column; gap: 12px; }
        .tp-history-meta { flex-direction: column; gap: 4px; }
    }
</style>

<?php if (!empty($active_leases)): ?>
    <!-- Active Leases Section -->
    <h2 class="tp-lease-section-title">
        <?php _e('Active Leases', 'rental-gates'); ?>
        <?php if (count($active_leases) > 1): ?>
            <span class="tp-lease-count"><?php echo count($active_leases); ?></span>
        <?php endif; ?>
    </h2>
    
    <?php foreach ($active_leases as $lease): 
        // Calculate lease progress
        $start = strtotime($lease['start_date']);
        $end = $lease['end_date'] ? strtotime($lease['end_date']) : null;
        $now = time();
        
        $lease_progress = 0;
        $days_remaining = null;
        $total_days = 0;
        if ($end) {
            $total_days = max(1, ($end - $start) / 86400);
            $elapsed_days = ($now - $start) / 86400;
            $lease_progress = min(100, max(0, ($elapsed_days / $total_days) * 100));
            $days_remaining = max(0, ceil(($end - $now) / 86400));
        }
        
        $status = $status_config[$lease['status']] ?? $status_config['active'];
        $unit_display = $lease['unit_name'] ?? 'Unit';
        $billing_day = intval($lease['billing_day'] ?? $lease['rent_due_day'] ?? 1);
    ?>
    <div class="tp-lease-card active-lease">
        <div class="tp-lease-card-header">
            <div>
                <h3 class="tp-lease-card-title"><?php echo esc_html($unit_display); ?></h3>
                <div class="tp-lease-card-sub"><?php echo esc_html($lease['building_name']); ?></div>
            </div>
            <span class="tp-badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;">
                <span class="dot" style="background: <?php echo $status['color']; ?>;"></span>
                <?php echo $status['label']; ?>
            </span>
        </div>
        
        <div class="tp-lease-details">
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Monthly Rent', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value highlight">$<?php echo number_format($lease['rent_amount'], 2); ?></div>
            </div>
            
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Due Date', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value"><?php echo rg_ordinal($billing_day); ?> <?php _e('of each month', 'rental-gates'); ?></div>
            </div>
            
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Lease Start', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value"><?php echo date_i18n('F j, Y', $start); ?></div>
            </div>
            
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Lease End', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value">
                    <?php if ($lease['end_date']): ?>
                        <?php echo date_i18n('F j, Y', strtotime($lease['end_date'])); ?>
                    <?php elseif (!empty($lease['is_month_to_month'])): ?>
                        <span style="color: var(--primary);"><?php _e('Month-to-Month', 'rental-gates'); ?></span>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if (!empty($lease['deposit_amount']) && floatval($lease['deposit_amount']) > 0): ?>
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Security Deposit', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value">$<?php echo number_format($lease['deposit_amount'], 2); ?></div>
            </div>
            <?php endif; ?>
            
            <div class="tp-lease-detail">
                <div class="tp-lease-detail-label"><?php _e('Lease Type', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value"><?php echo !empty($lease['is_month_to_month']) ? __('Month-to-Month', 'rental-gates') : __('Fixed Term', 'rental-gates'); ?></div>
            </div>
            
            <?php if (!empty($lease['building_address'])): ?>
            <div class="tp-lease-detail" style="grid-column: 1 / -1;">
                <div class="tp-lease-detail-label"><?php _e('Property Address', 'rental-gates'); ?></div>
                <div class="tp-lease-detail-value"><?php echo esc_html($lease['building_address']); ?></div>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if ($end && empty($lease['is_month_to_month'])): ?>
        <div class="tp-lease-progress">
            <div class="tp-progress-header">
                <span class="tp-progress-label"><?php _e('Lease Progress', 'rental-gates'); ?></span>
                <span class="tp-progress-value">
                    <?php if ($days_remaining !== null): ?>
                        <?php printf(__('%d days remaining', 'rental-gates'), $days_remaining); ?>
                    <?php else: ?>
                        <?php echo round($lease_progress); ?>%
                    <?php endif; ?>
                </span>
            </div>
            <div class="tp-progress-bar">
                <div class="tp-progress-fill" style="width: <?php echo $lease_progress; ?>%;"></div>
            </div>
            <div class="tp-progress-dates">
                <span><?php echo date_i18n('M j, Y', $start); ?></span>
                <span><?php echo date_i18n('M j, Y', $end); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($days_remaining !== null && $days_remaining <= 60 && $days_remaining > 0): ?>
        <div class="tp-alert-box warning">
            <svg class="alert-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
            </svg>
            <div class="alert-content">
                <h4><?php _e('Lease Expiring Soon', 'rental-gates'); ?></h4>
                <p><?php printf(__('Your lease for %s expires in %d days. Please contact your property manager to discuss renewal options.', 'rental-gates'), $unit_display, $days_remaining); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>

<?php else: ?>
    <!-- No Active Lease -->
    <div class="tp-no-lease">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
        </svg>
        <h3><?php _e('No Active Lease', 'rental-gates'); ?></h3>
        <p><?php _e('You don\'t have an active lease at this time. If you believe this is an error, please contact your property manager.', 'rental-gates'); ?></p>
    </div>
<?php endif; ?>

<!-- Lease History Section -->
<?php if (!empty($lease_history)): ?>
<div class="tp-history-section">
    <h2 class="tp-lease-section-title">
        <?php _e('Lease History', 'rental-gates'); ?>
        <span class="tp-lease-count" style="background: var(--gray-400);"><?php echo count($lease_history); ?></span>
    </h2>
    
    <?php foreach ($lease_history as $lease): 
        $h_status = $status_config[$lease['status']] ?? $status_config['ended'];
        $unit_display = $lease['unit_name'] ?? 'Unit';
    ?>
    <div class="tp-history-item">
        <div class="tp-history-header">
            <div class="tp-history-title"><?php echo esc_html($unit_display); ?> - <?php echo esc_html($lease['building_name']); ?></div>
            <span class="tp-badge" style="background: <?php echo $h_status['bg']; ?>; color: <?php echo $h_status['color']; ?>;">
                <?php echo $h_status['label']; ?>
            </span>
        </div>
        <div class="tp-history-meta">
            <span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
                <?php echo date_i18n('M j, Y', strtotime($lease['start_date'])); ?> - <?php echo $lease['end_date'] ? date_i18n('M j, Y', strtotime($lease['end_date'])) : __('N/A', 'rental-gates'); ?>
            </span>
            <span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                </svg>
                $<?php echo number_format($lease['rent_amount'], 2); ?>/mo
            </span>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Important Information -->
<div class="tp-info-card">
    <h4><?php _e('📋 Notice Requirements', 'rental-gates'); ?></h4>
    <p><?php 
        $notice_days = 30;
        if (!empty($active_leases)) {
            $notice_days = intval($active_leases[0]['notice_period_days'] ?? 30);
        }
        printf(__('You are required to provide %d days written notice before moving out. Contact your property manager for move-out procedures.', 'rental-gates'), $notice_days); 
    ?></p>
</div>

<div class="tp-info-card" style="margin-top: 12px;">
    <h4><?php _e('📄 Need a Copy of Your Lease?', 'rental-gates'); ?></h4>
    <p><?php _e('Contact your property manager to request a copy of your signed lease agreement or any other documents related to your tenancy.', 'rental-gates'); ?></p>
</div>
