<?php
/**
 * Tenant Portal Layout
 */
if (!defined('ABSPATH')) exit;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

// Get tenant record for this user
global $wpdb;
$tables = Rental_Gates_Database::get_table_names();

$tenant = $wpdb->get_row($wpdb->prepare(
    "SELECT t.*, o.name as organization_name, o.contact_email as org_email, o.contact_phone as org_phone
     FROM {$tables['tenants']} t
     JOIN {$tables['organizations']} o ON t.organization_id = o.id
     WHERE t.user_id = %d AND t.status = 'active'
     LIMIT 1",
    $user_id
), ARRAY_A);

if (!$tenant) {
    // No active tenant record found
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php _e('Tenant Portal', 'rental-gates'); ?></title>
        <?php wp_head(); ?>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f3f4f6; margin: 0; padding: 40px 20px; }
            .error-box { max-width: 500px; margin: 0 auto; background: #fff; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .error-box h1 { color: #1f2937; margin: 0 0 16px; }
            .error-box p { color: #6b7280; margin: 0 0 24px; }
            .error-box a { display: inline-block; padding: 12px 24px; background: #3b82f6; color: #fff; border-radius: 8px; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="error-box">
            <h1><?php _e('No Active Lease Found', 'rental-gates'); ?></h1>
            <p><?php _e('Your account is not currently linked to an active tenant record. Please contact your property manager for assistance.', 'rental-gates'); ?></p>
            <a href="<?php echo wp_logout_url(home_url('/rental-gates/login')); ?>"><?php _e('Sign Out', 'rental-gates'); ?></a>
        </div>
        <?php wp_footer(); ?>
    </body>
    </html>
    <?php
    exit;
}

$tenant_id = intval($tenant['id']);
$org_id = intval($tenant['organization_id']);

// Get ALL active leases for this tenant using the model method
$active_leases = Rental_Gates_Lease::get_for_tenant($tenant_id, array(
    'status' => array('active', 'ending', 'draft'),
    'org_id' => $org_id,
));

// For backward compatibility - current_lease is the most recent active lease
$current_lease = !empty($active_leases) ? $active_leases[0] : null;

// Get current page section
$current_page = '';
if (isset($_SERVER['REQUEST_URI'])) {
    $uri = urldecode($_SERVER['REQUEST_URI']);
    if (preg_match('#/rental-gates/tenant/([^?/]+)#', $uri, $matches)) {
        $current_page = $matches[1];
    }
}
if (empty($current_page)) {
    $current_page = 'dashboard';
}

// Navigation items
$nav_items = array(
    'dashboard' => array('label' => __('Dashboard', 'rental-gates'), 'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>'),
    'payments' => array('label' => __('Payments', 'rental-gates'), 'icon' => '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>'),
    'maintenance' => array('label' => __('Maintenance', 'rental-gates'), 'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>'),
    'messages' => array('label' => __('Messages', 'rental-gates'), 'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>'),
    'lease' => array('label' => __('My Lease', 'rental-gates'), 'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>'),
    'profile' => array('label' => __('My Profile', 'rental-gates'), 'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>'),
);

// Get unread message count for tenant
$unread_messages = Rental_Gates_Message::get_unread_count($org_id, $tenant_id, 'tenant');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <title><?php _e('Tenant Portal', 'rental-gates'); ?> - <?php echo esc_html($tenant['organization_name']); ?></title>
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php echo RENTAL_GATES_PLUGIN_URL; ?>assets/css/mobile.css?v=<?php echo RENTAL_GATES_VERSION; ?>">
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }
        
        * { box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background: var(--gray-100); color: var(--gray-900); }
        
        .tp-layout { display: flex; min-height: 100vh; }
        
        /* Sidebar */
        .tp-sidebar { width: 260px; background: #fff; border-right: 1px solid var(--gray-200); display: flex; flex-direction: column; position: fixed; height: 100vh; z-index: 100; }
        .tp-sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-100); }
        .tp-sidebar-logo { font-size: 18px; font-weight: 700; color: var(--gray-900); display: flex; align-items: center; gap: 10px; text-decoration: none; }
        .tp-sidebar-logo svg { width: 32px; height: 32px; color: var(--primary); }
        
        .tp-property-info { padding: 16px 20px; background: var(--gray-50); border-bottom: 1px solid var(--gray-100); }
        .tp-property-name { font-weight: 600; color: var(--gray-900); font-size: 14px; }
        .tp-property-unit { font-size: 13px; color: var(--gray-500); margin-top: 2px; }
        
        .tp-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .tp-nav-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 8px; color: var(--gray-600); text-decoration: none; font-size: 14px; font-weight: 500; margin-bottom: 4px; transition: all 0.2s; }
        .tp-nav-item:hover { background: var(--gray-50); color: var(--gray-900); }
        .tp-nav-item.active { background: #eff6ff; color: var(--primary); }
        .tp-nav-item svg { width: 20px; height: 20px; flex-shrink: 0; }
        .tp-nav-badge { margin-left: auto; background: #ef4444; color: #fff; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 10px; min-width: 20px; text-align: center; }
        
        .tp-sidebar-footer { padding: 12px; border-top: 1px solid var(--gray-100); }
        .tp-user-menu { position: relative; }
        .tp-user-menu-btn { display: flex; align-items: center; gap: 12px; width: 100%; padding: 10px 12px; border: none; background: none; cursor: pointer; border-radius: 10px; transition: background 0.2s; }
        .tp-user-menu-btn:hover { background: var(--gray-50); }
        .tp-user-avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 14px; flex-shrink: 0; }
        .tp-user-details { flex: 1; text-align: left; }
        .tp-user-name { font-size: 14px; font-weight: 500; color: var(--gray-900); }
        .tp-user-email { font-size: 12px; color: var(--gray-500); }
        .tp-user-menu-btn svg { width: 16px; height: 16px; color: var(--gray-400); transition: transform 0.2s; }
        .tp-user-menu.open .tp-user-menu-btn svg { transform: rotate(180deg); }
        
        .tp-user-dropdown { position: absolute; bottom: calc(100% + 8px); left: 0; right: 0; background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; box-shadow: 0 -10px 40px rgba(0,0,0,0.12); opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.2s; z-index: 1000; }
        .tp-user-menu.open .tp-user-dropdown { opacity: 1; visibility: visible; transform: translateY(0); }
        .tp-dropdown-menu { padding: 8px; }
        .tp-dropdown-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; color: var(--gray-700); text-decoration: none; font-size: 14px; transition: background 0.15s; }
        .tp-dropdown-item:hover { background: var(--gray-50); }
        .tp-dropdown-item svg { width: 18px; height: 18px; color: var(--gray-400); }
        .tp-dropdown-divider { height: 1px; background: var(--gray-100); margin: 8px 0; }
        .tp-dropdown-item-danger { color: #dc2626; }
        .tp-dropdown-item-danger:hover { background: #fef2f2; }
        .tp-dropdown-item-danger svg { color: #dc2626; }
        
        /* Main Content */
        .tp-main { flex: 1; margin-left: 260px; }
        .tp-header { background: #fff; border-bottom: 1px solid var(--gray-200); padding: 16px 32px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
        .tp-header-title { font-size: 20px; font-weight: 600; color: var(--gray-900); }
        .tp-header-actions { display: flex; gap: 12px; }
        
        .tp-content { padding: 32px; }
        
        /* Buttons */
        .tp-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; cursor: pointer; border: none; transition: all 0.2s; }
        .tp-btn-primary { background: var(--primary); color: #fff; }
        .tp-btn-primary:hover { background: var(--primary-dark); }
        .tp-btn-secondary { background: #fff; color: var(--gray-700); border: 1px solid var(--gray-300); }
        .tp-btn-secondary:hover { background: var(--gray-50); }
        .tp-btn svg { width: 18px; height: 18px; }
        
        /* Cards */
        .tp-card { background: #fff; border: 1px solid var(--gray-200); border-radius: 12px; margin-bottom: 20px; }
        .tp-card-header { padding: 16px 20px; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
        .tp-card-title { font-size: 16px; font-weight: 600; color: var(--gray-900); margin: 0; }
        .tp-card-body { padding: 20px; }
        
        /* Mobile menu toggle */
        .tp-mobile-toggle { display: none; padding: 8px; background: none; border: none; cursor: pointer; border-radius: 8px; }
        .tp-mobile-toggle svg { width: 24px; height: 24px; }
        .tp-mobile-toggle:hover { background: var(--gray-100); }
        
        /* Sidebar Overlay */
        .tp-sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 99;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .tp-sidebar-overlay.active {
            display: block;
            opacity: 1;
        }
        
        /* Bottom Navigation */
        .tp-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: calc(64px + env(safe-area-inset-bottom, 0px));
            padding-bottom: env(safe-area-inset-bottom, 0px);
            background: #fff;
            border-top: 1px solid var(--gray-200);
            z-index: 90;
            justify-content: space-around;
            align-items: center;
            box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }
        
        .tp-bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            height: 64px;
            padding: 8px 4px;
            text-decoration: none;
            color: var(--gray-500);
            background: none;
            border: none;
            cursor: pointer;
            position: relative;
            transition: color 0.2s;
        }
        
        .tp-bottom-nav-item.active { color: var(--primary); }
        .tp-bottom-nav-item svg { width: 24px; height: 24px; margin-bottom: 4px; }
        .tp-bottom-nav-item span { font-size: 10px; font-weight: 500; }
        
        .tp-bottom-nav-badge {
            position: absolute;
            top: 4px;
            right: 50%;
            transform: translateX(12px);
            min-width: 18px;
            height: 18px;
            padding: 0 5px;
            background: #ef4444;
            color: #fff;
            font-size: 10px;
            font-weight: 600;
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* Mobile Responsive */
        @media (max-width: 900px) {
            .tp-sidebar { transform: translateX(-100%); transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: none; }
            .tp-sidebar.open { transform: translateX(0); box-shadow: 4px 0 20px rgba(0, 0, 0, 0.2); }
            .tp-main { margin-left: 0; }
            .tp-mobile-toggle { display: flex; align-items: center; justify-content: center; width: 44px; height: 44px; }
            .tp-content { padding: 20px; padding-bottom: calc(84px + env(safe-area-inset-bottom, 0px)); }
            .tp-header { padding: 12px 16px; }
            .tp-bottom-nav { display: flex; }
        }
        
        @media (max-width: 768px) {
            .tp-content { padding: 16px; padding-bottom: calc(84px + env(safe-area-inset-bottom, 0px)); }
        }
        
        @media (max-width: 375px) {
            .tp-content { padding: 12px; padding-bottom: calc(84px + env(safe-area-inset-bottom, 0px)); }
        }
    </style>
</head>
<body>
    <div class="tp-layout">
        <!-- Sidebar -->
        <aside class="tp-sidebar" id="sidebar">
            <div class="tp-sidebar-header">
                <a href="<?php echo home_url('/rental-gates/tenant'); ?>" class="tp-sidebar-logo">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                    <?php echo esc_html($tenant['organization_name']); ?>
                </a>
            </div>
            
            <?php if (!empty($active_leases)): ?>
            <div class="tp-property-info">
                <?php if (count($active_leases) === 1): ?>
                    <div class="tp-property-name"><?php echo esc_html($current_lease['building_name']); ?></div>
                    <div class="tp-property-unit"><?php echo esc_html($current_lease['unit_name'] ?? ''); ?></div>
                <?php else: ?>
                    <div class="tp-property-name"><?php printf(__('%d Active Leases', 'rental-gates'), count($active_leases)); ?></div>
                    <div class="tp-property-unit"><?php _e('Multiple Properties', 'rental-gates'); ?></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <nav class="tp-nav">
                <?php foreach ($nav_items as $key => $item): ?>
                    <a href="<?php echo home_url('/rental-gates/tenant/' . ($key === 'dashboard' ? '' : $key)); ?>" 
                       class="tp-nav-item <?php echo $current_page === $key ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><?php echo $item['icon']; ?></svg>
                        <?php echo esc_html($item['label']); ?>
                        <?php if ($key === 'messages' && $unread_messages > 0): ?>
                            <span class="tp-nav-badge"><?php echo $unread_messages > 99 ? '99+' : $unread_messages; ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </nav>
            
            <div class="tp-sidebar-footer">
                <div class="tp-user-menu" id="userMenu">
                    <button class="tp-user-menu-btn" onclick="toggleUserMenu(event)">
                        <div class="tp-user-avatar"><?php echo strtoupper(substr($tenant['first_name'], 0, 1) . substr($tenant['last_name'], 0, 1)); ?></div>
                        <div class="tp-user-details">
                            <div class="tp-user-name"><?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></div>
                            <div class="tp-user-email"><?php echo esc_html($tenant['email']); ?></div>
                        </div>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="18 15 12 9 6 15"/>
                        </svg>
                    </button>
                    
                    <div class="tp-user-dropdown">
                        <div class="tp-dropdown-menu">
                            <a href="<?php echo home_url('/rental-gates/tenant/profile'); ?>" class="tp-dropdown-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                    <circle cx="12" cy="7" r="4"/>
                                </svg>
                                <?php _e('My Profile', 'rental-gates'); ?>
                            </a>
                            <a href="<?php echo home_url('/rental-gates/tenant/lease'); ?>" class="tp-dropdown-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                    <polyline points="14 2 14 8 20 8"/>
                                </svg>
                                <?php _e('My Lease', 'rental-gates'); ?>
                            </a>
                            <div class="tp-dropdown-divider"></div>
                            <a href="<?php echo wp_logout_url(home_url('/rental-gates/login')); ?>" class="tp-dropdown-item tp-dropdown-item-danger">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                                    <polyline points="16 17 21 12 16 7"/>
                                    <line x1="21" y1="12" x2="9" y2="12"/>
                                </svg>
                                <?php _e('Sign Out', 'rental-gates'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="tp-main">
            <header class="tp-header">
                <button class="tp-mobile-toggle" onclick="toggleMobileSidebar()" aria-label="<?php _e('Toggle menu', 'rental-gates'); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
                <h1 class="tp-header-title"><?php echo esc_html($nav_items[$current_page]['label'] ?? __('Tenant Portal', 'rental-gates')); ?></h1>
                <div class="tp-header-actions">
                    <?php if ($tenant['org_phone']): ?>
                        <a href="tel:<?php echo esc_attr($tenant['org_phone']); ?>" class="tp-btn tp-btn-secondary">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                            <?php _e('Contact', 'rental-gates'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </header>
            
            <div class="tp-content">
                <?php
                // Load the appropriate section
                $sections_dir = RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/tenant/sections/';
                $section_file = $sections_dir . $current_page . '.php';
                
                // Special case: invoice viewer is shared between owner and tenant
                if ($current_page === 'invoice') {
                    $section_file = RENTAL_GATES_PLUGIN_DIR . 'templates/dashboard/sections/invoice-view.php';
                }
                
                if (file_exists($section_file)) {
                    include $section_file;
                } else {
                    include $sections_dir . 'dashboard.php';
                }
                ?>
            </div>
        </main>
    </div>
    
    <!-- Sidebar Overlay (Mobile) -->
    <div class="tp-sidebar-overlay" id="sidebarOverlay" onclick="closeMobileSidebar()"></div>
    
    <!-- Bottom Navigation (Mobile) -->
    <nav class="tp-bottom-nav" id="bottomNav">
        <a href="<?php echo home_url('/rental-gates/tenant'); ?>" class="tp-bottom-nav-item <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            <span><?php _e('Home', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/tenant/payments'); ?>" class="tp-bottom-nav-item <?php echo $current_page === 'payments' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
            <span><?php _e('Payments', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/tenant/maintenance'); ?>" class="tp-bottom-nav-item <?php echo $current_page === 'maintenance' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg>
            <span><?php _e('Requests', 'rental-gates'); ?></span>
        </a>
        <a href="<?php echo home_url('/rental-gates/tenant/messages'); ?>" class="tp-bottom-nav-item <?php echo $current_page === 'messages' ? 'active' : ''; ?>" style="position: relative;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
            <span><?php _e('Messages', 'rental-gates'); ?></span>
            <?php if ($unread_messages > 0): ?>
            <span class="tp-bottom-nav-badge"><?php echo $unread_messages > 9 ? '9+' : $unread_messages; ?></span>
            <?php endif; ?>
        </a>
        <button class="tp-bottom-nav-item" onclick="toggleMobileSidebar()">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            <span><?php _e('More', 'rental-gates'); ?></span>
        </button>
    </nav>
    
    <script>
    function toggleUserMenu(e) {
        e.stopPropagation();
        document.getElementById('userMenu').classList.toggle('open');
    }
    
    // Mobile sidebar functions
    function toggleMobileSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const isOpen = sidebar.classList.contains('open');
        
        if (isOpen) {
            closeMobileSidebar();
        } else {
            sidebar.classList.add('open');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }
    
    function closeMobileSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const menu = document.getElementById('userMenu');
        if (menu && !menu.contains(e.target)) {
            menu.classList.remove('open');
        }
    });
    
    // Handle escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeMobileSidebar();
            document.getElementById('userMenu')?.classList.remove('open');
        }
    });
    
    // Swipe to close sidebar
    (function() {
        let touchStartX = 0;
        const sidebar = document.getElementById('sidebar');
        if (!sidebar) return;
        
        sidebar.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        sidebar.addEventListener('touchend', function(e) {
            const touchEndX = e.changedTouches[0].screenX;
            if (touchStartX - touchEndX > 50) {
                closeMobileSidebar();
            }
        }, { passive: true });
    })();
    
    // Hide/show bottom nav on scroll
    (function() {
        let lastScroll = 0;
        const bottomNav = document.getElementById('bottomNav');
        if (!bottomNav) return;
        
        window.addEventListener('scroll', function() {
            const currentScroll = window.pageYOffset;
            if (currentScroll > lastScroll && currentScroll > 100) {
                bottomNav.style.transform = 'translateY(100%)';
            } else {
                bottomNav.style.transform = 'translateY(0)';
            }
            lastScroll = currentScroll;
        }, { passive: true });
    })();
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>
