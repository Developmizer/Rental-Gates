<?php
/**
 * Rental Gates - FAQ Page
 */
if (!defined('ABSPATH')) exit;

$page_title = __('Frequently Asked Questions', 'rental-gates');
$page_subtitle = __('Find answers to common questions about Rental Gates', 'rental-gates');
$meta_description = __('Frequently asked questions about Rental Gates property management software. Get answers about features, pricing, security, and more.', 'rental-gates');
$current_page = 'faq';

// FAQ categories and questions
$faq_categories = array(
    'general' => array(
        'title' => __('General', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        'questions' => array(
            array(
                'q' => __('What is Rental Gates?', 'rental-gates'),
                'a' => __('Rental Gates is a modern property management platform designed for landlords, property managers, and real estate professionals. It helps you manage buildings, units, tenants, leases, payments, and maintenance requests all in one place.', 'rental-gates')
            ),
            array(
                'q' => __('Who is Rental Gates for?', 'rental-gates'),
                'a' => __('Rental Gates is perfect for independent landlords managing a few units, property management companies with large portfolios, and real estate investors looking to streamline their operations. Our platform scales from 1 to 1,000+ units.', 'rental-gates')
            ),
            array(
                'q' => __('Do I need to install any software?', 'rental-gates'),
                'a' => __('No installation required! Rental Gates is a cloud-based platform accessible from any web browser. You can access it from your computer, tablet, or smartphone anytime, anywhere.', 'rental-gates')
            )
        )
    ),
    'pricing' => array(
        'title' => __('Pricing & Plans', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        'questions' => array(
            array(
                'q' => __('How much does Rental Gates cost?', 'rental-gates'),
                'a' => __('We offer flexible pricing plans starting with a free tier for up to 5 units. Paid plans start at $29/month for Basic, $79/month for Pro, and custom pricing for Enterprise. All plans include a 14-day free trial.', 'rental-gates')
            ),
            array(
                'q' => __('Is there a free trial?', 'rental-gates'),
                'a' => __('Yes! All paid plans include a 14-day free trial with full access to all features. No credit card required to start.', 'rental-gates')
            ),
            array(
                'q' => __('Can I change plans later?', 'rental-gates'),
                'a' => __('Absolutely! You can upgrade or downgrade your plan at any time. Changes take effect immediately for upgrades and at the next billing cycle for downgrades.', 'rental-gates')
            )
        )
    ),
    'features' => array(
        'title' => __('Features', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>',
        'questions' => array(
            array(
                'q' => __('Can tenants pay rent online?', 'rental-gates'),
                'a' => __('Yes! Tenants can pay rent directly through their tenant portal using credit cards or bank transfers. Payments are securely processed through Stripe.', 'rental-gates')
            ),
            array(
                'q' => __('How do maintenance requests work?', 'rental-gates'),
                'a' => __('Tenants can submit maintenance requests through their portal with photos. You can assign vendors, track progress, and keep everyone updated automatically.', 'rental-gates')
            ),
            array(
                'q' => __('What is AI-powered tenant screening?', 'rental-gates'),
                'a' => __('Our AI screening analyzes rental applications and provides intelligent recommendations based on income, rental history, and other factors to help you make informed decisions.', 'rental-gates')
            )
        )
    ),
    'security' => array(
        'title' => __('Security & Privacy', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>',
        'questions' => array(
            array(
                'q' => __('Is my data secure?', 'rental-gates'),
                'a' => __('Absolutely. We use bank-level 256-bit SSL encryption for all data. Your data is hosted on secure, redundant servers with regular backups.', 'rental-gates')
            ),
            array(
                'q' => __('Do you sell my data?', 'rental-gates'),
                'a' => __('Never. Your data belongs to you. We do not sell, share, or monetize your data in any way.', 'rental-gates')
            )
        )
    )
);

$extra_css = '<style>
    .faq-layout { display: grid; grid-template-columns: 280px 1fr; gap: 48px; align-items: start; }
    .faq-sidebar { position: sticky; top: 100px; }
    .faq-nav { background: #fff; border-radius: var(--radius-lg); border: 1px solid var(--gray-200); overflow: hidden; }
    .faq-nav-title { padding: 16px 20px; font-size: 0.8125rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--gray-500); border-bottom: 1px solid var(--gray-200); }
    .faq-nav-link { display: flex; align-items: center; gap: 12px; padding: 14px 20px; color: var(--gray-600); font-weight: 500; transition: all 0.2s; border-left: 3px solid transparent; }
    .faq-nav-link:hover, .faq-nav-link.active { background: var(--primary-50); color: var(--primary); border-left-color: var(--primary); }
    .faq-nav-link svg { width: 20px; height: 20px; opacity: 0.7; }
    .faq-search { margin-bottom: 24px; }
    .faq-search-input { width: 100%; padding: 14px 16px 14px 44px; border: 1px solid var(--gray-300); border-radius: var(--radius-md); font-size: 1rem; background: #fff url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'%239ca3af\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z\'/%3E%3C/svg%3E") no-repeat 14px center; background-size: 20px; }
    .faq-search-input:focus { outline: none; border-color: var(--primary); box-shadow: var(--focus-ring); }
    .faq-category { margin-bottom: 48px; }
    .faq-category-header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 2px solid var(--primary); }
    .faq-category-icon { width: 40px; height: 40px; background: var(--primary); color: #fff; border-radius: 10px; display: flex; align-items: center; justify-content: center; }
    .faq-category-title { font-family: "DM Serif Display", serif; font-size: 1.5rem; color: var(--gray-900); }
    .faq-item { background: #fff; border: 1px solid var(--gray-200); border-radius: var(--radius-md); margin-bottom: 12px; overflow: hidden; }
    .faq-question { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 20px 24px; width: 100%; background: none; border: none; text-align: left; font-size: 1rem; font-weight: 600; color: var(--gray-900); cursor: pointer; transition: background 0.2s; }
    .faq-question:hover { background: var(--gray-50); }
    .faq-question svg { width: 20px; height: 20px; color: var(--gray-400); flex-shrink: 0; transition: transform 0.3s; }
    .faq-item.open .faq-question svg { transform: rotate(180deg); }
    .faq-answer { display: none; padding: 0 24px 20px; color: var(--gray-600); line-height: 1.7; }
    .faq-item.open .faq-answer { display: block; }
    .faq-contact-banner { background: linear-gradient(135deg, var(--primary-darker) 0%, var(--primary) 100%); color: #fff; border-radius: var(--radius-lg); padding: 40px; text-align: center; margin-top: 48px; }
    .faq-contact-banner h2 { font-family: "DM Serif Display", serif; font-size: 1.75rem; margin-bottom: 12px; }
    .faq-contact-banner p { opacity: 0.9; margin-bottom: 24px; }
    .faq-contact-banner .btn { background: #fff; color: var(--primary); }
    @media (max-width: 1024px) { .faq-layout { grid-template-columns: 1fr; } .faq-sidebar { position: static; } .faq-nav { display: none; } }
    @media (max-width: 768px) { .faq-question { padding: 16px 20px; } .faq-answer { padding: 0 20px 16px; } .faq-contact-banner { padding: 32px 24px; } }
</style>';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-header.php';
?>

<section class="content-section">
    <div class="container">
        <div class="faq-layout">
            <aside class="faq-sidebar">
                <div class="faq-search">
                    <input type="text" class="faq-search-input" id="faqSearch" placeholder="<?php _e('Search questions...', 'rental-gates'); ?>">
                </div>
                <nav class="faq-nav">
                    <div class="faq-nav-title"><?php _e('Categories', 'rental-gates'); ?></div>
                    <?php foreach ($faq_categories as $key => $category): ?>
                    <a href="#<?php echo esc_attr($key); ?>" class="faq-nav-link">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><?php echo $category['icon']; ?></svg>
                        <?php echo esc_html($category['title']); ?>
                    </a>
                    <?php endforeach; ?>
                </nav>
            </aside>
            
            <div class="faq-content">
                <?php foreach ($faq_categories as $key => $category): ?>
                <div class="faq-category" id="<?php echo esc_attr($key); ?>">
                    <header class="faq-category-header">
                        <div class="faq-category-icon">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><?php echo $category['icon']; ?></svg>
                        </div>
                        <h2 class="faq-category-title"><?php echo esc_html($category['title']); ?></h2>
                    </header>
                    <?php foreach ($category['questions'] as $qa): ?>
                    <div class="faq-item">
                        <button class="faq-question" onclick="this.closest('.faq-item').classList.toggle('open')">
                            <?php echo esc_html($qa['q']); ?>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                        </button>
                        <div class="faq-answer"><?php echo esc_html($qa['a']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>
                
                <div class="faq-contact-banner">
                    <h2><?php _e('Still have questions?', 'rental-gates'); ?></h2>
                    <p><?php _e('Our support team is here to help.', 'rental-gates'); ?></p>
                    <a href="<?php echo home_url('/rental-gates/contact'); ?>" class="btn"><?php _e('Contact Support', 'rental-gates'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-footer.php'; ?>
