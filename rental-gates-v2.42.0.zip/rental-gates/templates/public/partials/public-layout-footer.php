    </main>
    
    <!-- Footer -->
    <footer class="footer" role="contentinfo">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="footer-logo">
                        <div class="footer-logo-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                                <polyline points="9 22 9 12 15 12 15 22"/>
                            </svg>
                        </div>
                        <?php echo esc_html($platform_name); ?>
                    </div>
                    <p class="footer-desc"><?php _e('Modern property management software for landlords and property managers. Simplify your operations and grow your portfolio.', 'rental-gates'); ?></p>
                    <nav class="footer-social" aria-label="<?php _e('Social media links', 'rental-gates'); ?>">
                        <a href="#" aria-label="<?php _e('Follow us on Twitter', 'rental-gates'); ?>">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"/></svg>
                        </a>
                        <a href="#" aria-label="<?php _e('Connect on LinkedIn', 'rental-gates'); ?>">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2zM4 6a2 2 0 100-4 2 2 0 000 4z"/></svg>
                        </a>
                        <a href="#" aria-label="<?php _e('Like us on Facebook', 'rental-gates'); ?>">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
                        </a>
                    </nav>
                </div>
                
                <nav aria-label="<?php _e('Product links', 'rental-gates'); ?>">
                    <h3 class="footer-heading"><?php _e('Product', 'rental-gates'); ?></h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo home_url('/rental-gates'); ?>#features"><?php _e('Features', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates'); ?>#pricing"><?php _e('Pricing', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates/map'); ?>"><?php _e('Property Map', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('API', 'rental-gates'); ?></a></li>
                    </ul>
                </nav>
                
                <nav aria-label="<?php _e('Company links', 'rental-gates'); ?>">
                    <h3 class="footer-heading"><?php _e('Company', 'rental-gates'); ?></h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo home_url('/rental-gates/about'); ?>"><?php _e('About Us', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates/contact'); ?>"><?php _e('Contact', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('Careers', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('Blog', 'rental-gates'); ?></a></li>
                    </ul>
                </nav>
                
                <nav aria-label="<?php _e('Support links', 'rental-gates'); ?>">
                    <h3 class="footer-heading"><?php _e('Support', 'rental-gates'); ?></h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo home_url('/rental-gates/faq'); ?>"><?php _e('FAQ', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('Help Center', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('Documentation', 'rental-gates'); ?></a></li>
                        <li><a href="#"><?php _e('Status', 'rental-gates'); ?></a></li>
                    </ul>
                </nav>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo esc_html($platform_name); ?>. <?php _e('All rights reserved.', 'rental-gates'); ?></p>
                <nav class="footer-legal" aria-label="<?php _e('Legal links', 'rental-gates'); ?>">
                    <a href="<?php echo esc_url($terms_url); ?>"><?php _e('Terms of Service', 'rental-gates'); ?></a>
                    <a href="<?php echo esc_url($privacy_url); ?>"><?php _e('Privacy Policy', 'rental-gates'); ?></a>
                </nav>
            </div>
        </div>
    </footer>
    
    <script>
    function toggleMobileNav() {
        const nav = document.getElementById('mobileNav');
        nav.classList.toggle('open');
        document.body.style.overflow = nav.classList.contains('open') ? 'hidden' : '';
    }
    
    // Close on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const nav = document.getElementById('mobileNav');
            if (nav.classList.contains('open')) {
                toggleMobileNav();
            }
        }
    });
    
    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(function(a) {
        a.addEventListener('click', function(e) {
            var h = this.getAttribute('href');
            if (h.length > 1) {
                e.preventDefault();
                var el = document.querySelector(h);
                if (el) {
                    var y = el.getBoundingClientRect().top + window.pageYOffset - 80;
                    window.scrollTo({top: y, behavior: 'smooth'});
                }
            }
        });
    });
    </script>
    
    <?php if (isset($extra_js)) echo $extra_js; ?>
    <?php wp_footer(); ?>
</body>
</html>
