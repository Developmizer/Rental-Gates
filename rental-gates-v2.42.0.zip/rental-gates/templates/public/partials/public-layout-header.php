<?php
/**
 * Rental Gates - Public Page Layout
 * 
 * Shared layout for all public pages (About, Contact, Privacy, Terms, etc.)
 * Inherits colors and branding from landing page settings.
 * 
 * Usage:
 * $page_title = 'About Us';
 * $page_content = 'Your content here';
 * include 'partials/public-layout.php';
 */
if (!defined('ABSPATH')) exit;

// Get settings
$platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
$support_email = get_option('rental_gates_support_email', get_option('admin_email'));
$support_phone = get_option('rental_gates_support_phone', '');
$is_logged_in = is_user_logged_in();
$dashboard_url = home_url('/rental-gates/dashboard');
$login_url = home_url('/rental-gates/login');
$register_url = home_url('/rental-gates/register');
$terms_url = get_option('rental_gates_terms_url', home_url('/rental-gates/terms'));
$privacy_url = get_option('rental_gates_privacy_url', home_url('/rental-gates/privacy'));

// Get primary color from settings
$primary_color = get_option('rental_gates_primary_color', '#2563eb');

// Generate color variants from primary color
if (!function_exists('rg_public_hex_to_hsl')) {
    function rg_public_hex_to_hsl($hex) {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2)) / 255;
        $g = hexdec(substr($hex, 2, 2)) / 255;
        $b = hexdec(substr($hex, 4, 2)) / 255;
        
        $max = max($r, $g, $b);
        $min = min($r, $g, $b);
        $l = ($max + $min) / 2;
        
        if ($max == $min) {
            $h = $s = 0;
        } else {
            $d = $max - $min;
            $s = $l > 0.5 ? $d / (2 - $max - $min) : $d / ($max + $min);
            switch ($max) {
                case $r: $h = (($g - $b) / $d + ($g < $b ? 6 : 0)) / 6; break;
                case $g: $h = (($b - $r) / $d + 2) / 6; break;
                case $b: $h = (($r - $g) / $d + 4) / 6; break;
            }
        }
        
        return array($h * 360, $s * 100, $l * 100);
    }
}

if (!function_exists('rg_public_hsl_to_hex')) {
    function rg_public_hsl_to_hex($h, $s, $l) {
        $h /= 360; $s /= 100; $l /= 100;
        
        if ($s == 0) {
            $r = $g = $b = $l;
        } else {
            $q = $l < 0.5 ? $l * (1 + $s) : $l + $s - $l * $s;
            $p = 2 * $l - $q;
            $r = rg_public_hue_to_rgb($p, $q, $h + 1/3);
            $g = rg_public_hue_to_rgb($p, $q, $h);
            $b = rg_public_hue_to_rgb($p, $q, $h - 1/3);
        }
        
        return sprintf('#%02x%02x%02x', round($r * 255), round($g * 255), round($b * 255));
    }
}

if (!function_exists('rg_public_hue_to_rgb')) {
    function rg_public_hue_to_rgb($p, $q, $t) {
        if ($t < 0) $t += 1;
        if ($t > 1) $t -= 1;
        if ($t < 1/6) return $p + ($q - $p) * 6 * $t;
        if ($t < 1/2) return $q;
        if ($t < 2/3) return $p + ($q - $p) * (2/3 - $t) * 6;
        return $p;
    }
}

// Generate color palette
$hsl = rg_public_hex_to_hsl($primary_color);
$h = $hsl[0];
$s = $hsl[1];
$l = $hsl[2];

$colors = array(
    'primary' => $primary_color,
    'primary_dark' => rg_public_hsl_to_hex($h, $s, max(0, $l - 10)),
    'primary_darker' => rg_public_hsl_to_hex($h, $s, max(0, $l - 20)),
    'primary_light' => rg_public_hsl_to_hex($h, $s, min(100, $l + 10)),
    'primary_50' => rg_public_hsl_to_hex($h, max(0, $s - 30), 97),
    'primary_100' => rg_public_hsl_to_hex($h, max(0, $s - 20), 92),
);

// Get RGB for rgba usage
$rgb = array(
    hexdec(substr($primary_color, 1, 2)),
    hexdec(substr($primary_color, 3, 2)),
    hexdec(substr($primary_color, 5, 2))
);

// Page variables with defaults
$page_title = $page_title ?? 'Page';
$page_subtitle = $page_subtitle ?? '';
$show_breadcrumb = $show_breadcrumb ?? true;
$breadcrumb_parent = $breadcrumb_parent ?? '';
$meta_description = $meta_description ?? '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?php echo esc_html($page_title); ?> - <?php echo esc_html($platform_name); ?></title>
    <?php if ($meta_description): ?>
    <meta name="description" content="<?php echo esc_attr($meta_description); ?>">
    <?php endif; ?>
    <meta name="theme-color" content="<?php echo esc_attr($primary_color); ?>">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&display=swap" rel="stylesheet">
    
    <style>
        /* Reset & Base */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
        body {
            font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 1rem;
            line-height: 1.6;
            color: #44403c;
            background: #fff;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        img { max-width: 100%; height: auto; display: block; }
        a { color: inherit; text-decoration: none; }
        button { font-family: inherit; cursor: pointer; }
        
        /* Accessibility */
        .skip-link {
            position: absolute;
            top: -40px;
            left: 0;
            background: <?php echo esc_attr($colors['primary_darker']); ?>;
            color: #fff;
            padding: 8px 16px;
            z-index: 10000;
            transition: top .3s;
            font-weight: 600;
        }
        .skip-link:focus { top: 0; }
        
        /* CSS Variables */
        :root {
            --primary: <?php echo esc_attr($colors['primary']); ?>;
            --primary-dark: <?php echo esc_attr($colors['primary_dark']); ?>;
            --primary-darker: <?php echo esc_attr($colors['primary_darker']); ?>;
            --primary-light: <?php echo esc_attr($colors['primary_light']); ?>;
            --primary-50: <?php echo esc_attr($colors['primary_50']); ?>;
            --primary-100: <?php echo esc_attr($colors['primary_100']); ?>;
            --gray-50: #fafaf9;
            --gray-100: #f5f5f4;
            --gray-200: #e7e5e4;
            --gray-300: #d6d3d1;
            --gray-400: #a8a29e;
            --gray-500: #57534e;
            --gray-600: #44403c;
            --gray-700: #292524;
            --gray-900: #1c1917;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --focus-ring: 0 0 0 3px rgba(<?php echo $rgb[0]; ?>, <?php echo $rgb[1]; ?>, <?php echo $rgb[2]; ?>, 0.4);
            --container: 1200px;
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
        }
        
        /* Layout */
        .container {
            max-width: var(--container);
            margin: 0 auto;
            padding: 0 24px;
        }
        
        main { flex: 1; }
        
        /* ==========================================================================
           HEADER
           ========================================================================== */
        .header {
            position: sticky;
            top: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-bottom: 1px solid var(--gray-200);
            z-index: 100;
            padding-top: var(--safe-top);
        }
        
        .header-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 72px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            font-size: 1.25rem;
            color: var(--gray-900);
        }
        
        .logo-icon {
            width: 36px;
            height: 36px;
            background: var(--primary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        
        .nav-desktop {
            display: flex;
            align-items: center;
            gap: 32px;
        }
        
        .nav-links {
            display: flex;
            gap: 24px;
            list-style: none;
        }
        
        .nav-link {
            font-size: 0.9375rem;
            font-weight: 500;
            color: var(--gray-600);
            transition: color 0.2s;
            padding: 8px 0;
        }
        
        .nav-link:hover,
        .nav-link.active {
            color: var(--primary);
        }
        
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            font-size: 0.9375rem;
            font-weight: 600;
            border-radius: var(--radius-sm);
            border: none;
            transition: all 0.2s;
            cursor: pointer;
            min-height: 44px;
        }
        
        .btn:focus {
            outline: none;
            box-shadow: var(--focus-ring);
        }
        
        .btn-primary {
            background: var(--primary);
            color: #fff;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
        }
        
        .btn-secondary {
            background: transparent;
            color: var(--gray-700);
            border: 1px solid var(--gray-300);
        }
        
        .btn-secondary:hover {
            background: var(--gray-100);
            border-color: var(--gray-400);
        }
        
        .btn-ghost {
            background: transparent;
            color: var(--gray-600);
        }
        
        .btn-ghost:hover {
            color: var(--primary);
            background: var(--primary-50);
        }
        
        /* Mobile Menu */
        .mobile-toggle {
            display: none;
            width: 44px;
            height: 44px;
            align-items: center;
            justify-content: center;
            background: none;
            border: none;
            color: var(--gray-700);
        }
        
        .mobile-toggle svg {
            width: 24px;
            height: 24px;
        }
        
        .mobile-nav {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: #fff;
            z-index: 1000;
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            flex-direction: column;
        }
        
        .mobile-nav.open {
            display: flex;
        }
        
        .mobile-nav-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }
        
        .mobile-nav-links {
            list-style: none;
            flex: 1;
        }
        
        .mobile-nav-link {
            display: block;
            padding: 16px 0;
            font-size: 1.125rem;
            font-weight: 500;
            color: var(--gray-700);
            border-bottom: 1px solid var(--gray-100);
        }
        
        .mobile-nav-link.active {
            color: var(--primary);
        }
        
        .mobile-nav-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 24px;
        }
        
        /* ==========================================================================
           PAGE HEADER
           ========================================================================== */
        .page-header {
            background: linear-gradient(135deg, var(--primary-darker) 0%, var(--primary) 100%);
            color: #fff;
            padding: 64px 0;
            text-align: center;
        }
        
        .page-header-content {
            max-width: 700px;
            margin: 0 auto;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.875rem;
            opacity: 0.8;
            margin-bottom: 16px;
        }
        
        .breadcrumb a:hover {
            opacity: 1;
        }
        
        .breadcrumb-sep {
            opacity: 0.5;
        }
        
        .page-title {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(2rem, 5vw, 3rem);
            font-weight: 400;
            margin-bottom: 16px;
            line-height: 1.2;
        }
        
        .page-subtitle {
            font-size: 1.125rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
        }
        
        /* ==========================================================================
           CONTENT AREA
           ========================================================================== */
        .content-section {
            padding: 64px 0;
        }
        
        .content-section.gray {
            background: var(--gray-50);
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 48px;
        }
        
        .content-grid.two-col {
            grid-template-columns: 1fr 1fr;
        }
        
        .content-grid.sidebar {
            grid-template-columns: 2fr 1fr;
            gap: 64px;
        }
        
        /* Typography */
        .prose {
            max-width: 75ch;
        }
        
        .prose h2 {
            font-family: 'DM Serif Display', serif;
            font-size: 1.75rem;
            color: var(--gray-900);
            margin: 48px 0 16px;
        }
        
        .prose h2:first-child {
            margin-top: 0;
        }
        
        .prose h3 {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-900);
            margin: 32px 0 12px;
        }
        
        .prose p {
            margin-bottom: 16px;
            color: var(--gray-600);
        }
        
        .prose ul, .prose ol {
            margin: 16px 0;
            padding-left: 24px;
            color: var(--gray-600);
        }
        
        .prose li {
            margin-bottom: 8px;
        }
        
        .prose a {
            color: var(--primary);
            text-decoration: underline;
        }
        
        .prose a:hover {
            color: var(--primary-dark);
        }
        
        .prose strong {
            font-weight: 600;
            color: var(--gray-700);
        }
        
        .prose blockquote {
            border-left: 4px solid var(--primary);
            padding-left: 20px;
            margin: 24px 0;
            font-style: italic;
            color: var(--gray-500);
        }
        
        /* Cards */
        .card {
            background: #fff;
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
            padding: 24px;
        }
        
        .card-elevated {
            box-shadow: var(--shadow-md);
            border: none;
        }
        
        .card-icon {
            width: 56px;
            height: 56px;
            background: var(--primary-50);
            color: var(--primary);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
        }
        
        .card-title {
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--gray-900);
            margin-bottom: 8px;
        }
        
        .card-text {
            color: var(--gray-500);
            font-size: 0.9375rem;
        }
        
        /* Section Header */
        .section-header {
            text-align: center;
            max-width: 700px;
            margin: 0 auto 48px;
        }
        
        .section-label {
            display: inline-block;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }
        
        .section-title {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(1.75rem, 4vw, 2.5rem);
            color: var(--gray-900);
            margin-bottom: 16px;
        }
        
        .section-subtitle {
            font-size: 1.125rem;
            color: var(--gray-500);
        }
        
        /* ==========================================================================
           FORM ELEMENTS
           ========================================================================== */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--gray-700);
            margin-bottom: 6px;
        }
        
        .form-input,
        .form-textarea,
        .form-select {
            width: 100%;
            padding: 12px 16px;
            font-size: 1rem;
            font-family: inherit;
            border: 1px solid var(--gray-300);
            border-radius: var(--radius-sm);
            background: #fff;
            transition: all 0.2s;
            min-height: 48px;
        }
        
        .form-input:focus,
        .form-textarea:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: var(--focus-ring);
        }
        
        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-hint {
            font-size: 0.8125rem;
            color: var(--gray-500);
            margin-top: 6px;
        }
        
        .form-error {
            font-size: 0.8125rem;
            color: var(--danger);
            margin-top: 6px;
        }
        
        /* ==========================================================================
           FOOTER
           ========================================================================== */
        .footer {
            background: var(--gray-900);
            color: var(--gray-400);
            padding: 64px 0 32px;
            margin-top: auto;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: 2fr repeat(3, 1fr);
            gap: 48px;
            margin-bottom: 48px;
        }
        
        .footer-brand {
            max-width: 300px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            font-size: 1.25rem;
            color: #fff;
            margin-bottom: 16px;
        }
        
        .footer-logo-icon {
            width: 32px;
            height: 32px;
            background: var(--primary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .footer-desc {
            font-size: 0.9375rem;
            margin-bottom: 20px;
            line-height: 1.7;
        }
        
        .footer-social {
            display: flex;
            gap: 12px;
        }
        
        .footer-social a {
            width: 36px;
            height: 36px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        }
        
        .footer-social a:hover {
            background: var(--primary);
        }
        
        .footer-heading {
            font-size: 0.875rem;
            font-weight: 600;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 20px;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 12px;
        }
        
        .footer-links a {
            font-size: 0.9375rem;
            transition: color 0.2s;
        }
        
        .footer-links a:hover {
            color: #fff;
        }
        
        .footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 32px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.875rem;
        }
        
        .footer-legal {
            display: flex;
            gap: 24px;
        }
        
        .footer-legal a:hover {
            color: #fff;
        }
        
        /* ==========================================================================
           RESPONSIVE
           ========================================================================== */
        @media (max-width: 1024px) {
            .nav-desktop {
                display: none;
            }
            
            .mobile-toggle {
                display: flex;
            }
            
            .footer-grid {
                grid-template-columns: 1fr 1fr;
                gap: 32px;
            }
            
            .footer-brand {
                grid-column: span 2;
                max-width: none;
            }
        }
        
        @media (max-width: 768px) {
            .content-grid.two-col,
            .content-grid.sidebar {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                padding: 48px 0;
            }
            
            .content-section {
                padding: 48px 0;
            }
            
            .footer-grid {
                grid-template-columns: 1fr;
            }
            
            .footer-brand {
                grid-column: span 1;
            }
            
            .footer-bottom {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
        }
        
        @media (max-width: 375px) {
            .container {
                padding: 0 16px;
            }
            
            .page-header {
                padding: 32px 0;
            }
            
            .content-section {
                padding: 32px 0;
            }
        }
        
        /* Reduced Motion */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
    
    <?php if (isset($extra_css)) echo $extra_css; ?>
    <?php wp_head(); ?>
</head>
<body>
    <a href="#main-content" class="skip-link"><?php _e('Skip to main content', 'rental-gates'); ?></a>
    
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-inner">
                <a href="<?php echo home_url('/rental-gates'); ?>" class="logo">
                    <div class="logo-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                            <polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                    </div>
                    <?php echo esc_html($platform_name); ?>
                </a>
                
                <nav class="nav-desktop">
                    <ul class="nav-links">
                        <li><a href="<?php echo home_url('/rental-gates'); ?>#features" class="nav-link"><?php _e('Features', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates'); ?>#pricing" class="nav-link"><?php _e('Pricing', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates/about'); ?>" class="nav-link <?php echo (isset($current_page) && $current_page === 'about') ? 'active' : ''; ?>"><?php _e('About', 'rental-gates'); ?></a></li>
                        <li><a href="<?php echo home_url('/rental-gates/contact'); ?>" class="nav-link <?php echo (isset($current_page) && $current_page === 'contact') ? 'active' : ''; ?>"><?php _e('Contact', 'rental-gates'); ?></a></li>
                    </ul>
                    
                    <div class="nav-actions">
                        <?php if ($is_logged_in): ?>
                            <a href="<?php echo esc_url($dashboard_url); ?>" class="btn btn-primary"><?php _e('Dashboard', 'rental-gates'); ?></a>
                        <?php else: ?>
                            <a href="<?php echo esc_url($login_url); ?>" class="btn btn-ghost"><?php _e('Sign In', 'rental-gates'); ?></a>
                            <a href="<?php echo esc_url($register_url); ?>" class="btn btn-primary"><?php _e('Get Started', 'rental-gates'); ?></a>
                        <?php endif; ?>
                    </div>
                </nav>
                
                <button class="mobile-toggle" onclick="toggleMobileNav()" aria-label="<?php _e('Open menu', 'rental-gates'); ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
    </header>
    
    <!-- Mobile Nav -->
    <nav class="mobile-nav" id="mobileNav">
        <div class="mobile-nav-header">
            <a href="<?php echo home_url('/rental-gates'); ?>" class="logo">
                <div class="logo-icon">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                </div>
                <?php echo esc_html($platform_name); ?>
            </a>
            <button class="mobile-toggle" onclick="toggleMobileNav()" aria-label="<?php _e('Close menu', 'rental-gates'); ?>">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>
        
        <ul class="mobile-nav-links">
            <li><a href="<?php echo home_url('/rental-gates'); ?>#features" class="mobile-nav-link" onclick="toggleMobileNav()"><?php _e('Features', 'rental-gates'); ?></a></li>
            <li><a href="<?php echo home_url('/rental-gates'); ?>#pricing" class="mobile-nav-link" onclick="toggleMobileNav()"><?php _e('Pricing', 'rental-gates'); ?></a></li>
            <li><a href="<?php echo home_url('/rental-gates/about'); ?>" class="mobile-nav-link <?php echo (isset($current_page) && $current_page === 'about') ? 'active' : ''; ?>"><?php _e('About', 'rental-gates'); ?></a></li>
            <li><a href="<?php echo home_url('/rental-gates/contact'); ?>" class="mobile-nav-link <?php echo (isset($current_page) && $current_page === 'contact') ? 'active' : ''; ?>"><?php _e('Contact', 'rental-gates'); ?></a></li>
            <li><a href="<?php echo home_url('/rental-gates/faq'); ?>" class="mobile-nav-link <?php echo (isset($current_page) && $current_page === 'faq') ? 'active' : ''; ?>"><?php _e('FAQ', 'rental-gates'); ?></a></li>
        </ul>
        
        <div class="mobile-nav-actions">
            <?php if ($is_logged_in): ?>
                <a href="<?php echo esc_url($dashboard_url); ?>" class="btn btn-primary"><?php _e('Dashboard', 'rental-gates'); ?></a>
            <?php else: ?>
                <a href="<?php echo esc_url($login_url); ?>" class="btn btn-secondary"><?php _e('Sign In', 'rental-gates'); ?></a>
                <a href="<?php echo esc_url($register_url); ?>" class="btn btn-primary"><?php _e('Get Started Free', 'rental-gates'); ?></a>
            <?php endif; ?>
        </div>
    </nav>
    
    <!-- Page Header -->
    <?php if (!isset($hide_page_header) || !$hide_page_header): ?>
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <?php if ($show_breadcrumb): ?>
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <a href="<?php echo home_url('/rental-gates'); ?>"><?php _e('Home', 'rental-gates'); ?></a>
                    <span class="breadcrumb-sep">›</span>
                    <?php if ($breadcrumb_parent): ?>
                        <a href="<?php echo esc_url($breadcrumb_parent['url']); ?>"><?php echo esc_html($breadcrumb_parent['title']); ?></a>
                        <span class="breadcrumb-sep">›</span>
                    <?php endif; ?>
                    <span><?php echo esc_html($page_title); ?></span>
                </nav>
                <?php endif; ?>
                <h1 class="page-title"><?php echo esc_html($page_title); ?></h1>
                <?php if ($page_subtitle): ?>
                <p class="page-subtitle"><?php echo esc_html($page_subtitle); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Main Content -->
    <main id="main-content">
