<?php
/**
 * Rental Gates - Landing Page (Full Page Template)
 * 
 * This is the standalone full-page version of the landing page.
 * It includes the complete HTML document structure.
 */
if (!defined('ABSPATH')) exit;

// Get platform name and theme setting
$platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
$landing_theme = get_option('rental_gates_landing_theme', 'modern');

// Set font based on theme
$font_url = $landing_theme === 'minimal' 
    ? 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap'
    : 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap';

$font_family = $landing_theme === 'minimal'
    ? "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
    : "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($platform_name); ?> - Find Rentals & Manage Properties</title>
    <meta name="description" content="<?php _e('Discover available rental properties on our interactive map or streamline your property management with our all-in-one platform. Find your perfect rental or manage buildings, tenants, leases, and payments.', 'rental-gates'); ?>">
    <meta name="keywords" content="<?php _e('rental properties, property management, find apartments, rental search, property manager software, tenant portal, lease management', 'rental-gates'); ?>">
    <link rel="canonical" href="<?php echo esc_url(home_url('/rental-gates')); ?>">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo esc_url(home_url('/rental-gates')); ?>">
    <meta property="og:title" content="<?php echo esc_attr($platform_name); ?> - Find Rentals & Manage Properties">
    <meta property="og:description" content="<?php _e('Discover available rental properties on our interactive map or streamline your property management with our all-in-one platform.', 'rental-gates'); ?>">
    <meta property="og:site_name" content="<?php echo esc_attr($platform_name); ?>">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo esc_attr($platform_name); ?> - Find Rentals & Manage Properties">
    <meta name="twitter:description" content="<?php _e('Discover available rental properties on our interactive map or streamline your property management with our all-in-one platform.', 'rental-gates'); ?>">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="<?php echo esc_url($font_url); ?>" rel="stylesheet" media="print" onload="this.media='all'">
    <noscript><link href="<?php echo esc_url($font_url); ?>" rel="stylesheet"></noscript>
    
    <?php wp_head(); ?>
    
    <!-- Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "<?php echo esc_js($platform_name); ?>",
        "url": "<?php echo esc_url(home_url()); ?>",
        "logo": "<?php echo esc_url(home_url('/wp-content/uploads')); ?>",
        "description": "<?php _e('Modern property management software and rental property discovery platform.', 'rental-gates'); ?>",
        "sameAs": [
            <?php 
            $social_links = array_filter(array(
                get_option('rental_gates_landing_social_twitter', ''),
                get_option('rental_gates_landing_social_facebook', ''),
                get_option('rental_gates_landing_social_linkedin', ''),
                get_option('rental_gates_landing_social_instagram', '')
            ));
            if (!empty($social_links)) {
                echo '"' . implode('", "', array_map('esc_js', $social_links)) . '"';
            }
            ?>
        ]
    }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "<?php echo esc_js($platform_name); ?>",
        "url": "<?php echo esc_url(home_url()); ?>",
        "potentialAction": {
            "@type": "SearchAction",
            "target": "<?php echo esc_url(home_url('/rental-gates/map?search={search_term_string}')); ?>",
            "query-input": "required name=search_term_string"
        }
    }
    </script>
    
    <style>
        /* Reset for full-page mode */
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100%;
        }
        body {
            font-family: <?php echo $font_family; ?>;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        /* Hide admin bar if present */
        #wpadminbar { display: none !important; }
        html { margin-top: 0 !important; }
    </style>
</head>
<body <?php body_class('rg-landing-fullpage rg-theme-' . esc_attr($landing_theme)); ?>>
    <!-- Skip Link for Accessibility -->
    <a href="#rg-landing" class="skip-link" style="position: absolute; left: -9999px; z-index: 999999; padding: 1em; background: var(--rg-primary, #0ea5e9); color: white; text-decoration: none;"><?php _e('Skip to main content', 'rental-gates'); ?></a>
    <style>
        .skip-link:focus { left: 6px; top: 6px; }
    </style>

<?php
// Include the appropriate landing page content based on theme
$theme_file = $landing_theme === 'minimal' ? 'landing-content-minimal.php' : 'landing-content.php';
include RENTAL_GATES_PLUGIN_DIR . 'templates/public/' . $theme_file;
?>

<?php wp_footer(); ?>
</body>
</html>
