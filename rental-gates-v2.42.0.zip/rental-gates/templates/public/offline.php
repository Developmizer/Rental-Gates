<?php
/**
 * Offline Page Template
 * Displayed when user is offline and page is not cached
 */
if (!defined('ABSPATH')) exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?php _e('Offline', 'rental-gates'); ?> - <?php bloginfo('name'); ?></title>
    <meta name="theme-color" content="#2563eb">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            height: 100%;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
            min-height: 100vh;
            min-height: -webkit-fill-available;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            padding-top: calc(20px + env(safe-area-inset-top, 0px));
            padding-bottom: calc(20px + env(safe-area-inset-bottom, 0px));
            padding-left: calc(20px + env(safe-area-inset-left, 0px));
            padding-right: calc(20px + env(safe-area-inset-right, 0px));
            color: white;
        }
        
        .container {
            text-align: center;
            max-width: 400px;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .icon-wrapper {
            width: 100px;
            height: 100px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
        }
        
        .icon {
            width: 56px;
            height: 56px;
            opacity: 0.95;
        }
        
        h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 12px;
            letter-spacing: -0.5px;
        }
        
        p {
            opacity: 0.85;
            line-height: 1.6;
            margin-bottom: 32px;
            font-size: 16px;
        }
        
        .actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px 28px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .btn-primary {
            background: white;
            color: #2563eb;
        }
        
        .btn-primary:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.25);
        }
        
        .btn svg {
            width: 18px;
            height: 18px;
        }
        
        .status {
            margin-top: 40px;
            padding: 16px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            font-size: 14px;
        }
        
        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #ef4444;
            animation: pulse 2s infinite;
        }
        
        .status-dot.online {
            background: #22c55e;
            animation: none;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .cached-pages {
            margin-top: 32px;
            text-align: left;
        }
        
        .cached-pages h3 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 12px;
            opacity: 0.9;
        }
        
        .cached-pages ul {
            list-style: none;
        }
        
        .cached-pages li {
            margin-bottom: 8px;
        }
        
        .cached-pages a {
            color: white;
            text-decoration: none;
            opacity: 0.8;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            transition: opacity 0.2s;
        }
        
        .cached-pages a:hover {
            opacity: 1;
        }
        
        .cached-pages svg {
            width: 16px;
            height: 16px;
        }
        
        @media (max-width: 375px) {
            h1 {
                font-size: 24px;
            }
            
            .icon-wrapper {
                width: 80px;
                height: 80px;
            }
            
            .icon {
                width: 44px;
                height: 44px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon-wrapper">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="1" y1="1" x2="23" y2="23"></line>
                <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"></path>
                <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"></path>
                <path d="M10.71 5.05A16 16 0 0 1 22.58 9"></path>
                <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"></path>
                <path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path>
                <line x1="12" y1="20" x2="12.01" y2="20"></line>
            </svg>
        </div>
        
        <h1><?php _e("You're Offline", 'rental-gates'); ?></h1>
        <p><?php _e("It looks like you've lost your internet connection. Don't worry, some features may still be available.", 'rental-gates'); ?></p>
        
        <div class="actions">
            <button class="btn btn-primary" onclick="location.reload()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <polyline points="1 20 1 14 7 14"></polyline>
                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
                <?php _e('Try Again', 'rental-gates'); ?>
            </button>
            
            <a href="<?php echo home_url('/rental-gates/dashboard/'); ?>" class="btn btn-secondary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
                <?php _e('Go to Dashboard', 'rental-gates'); ?>
            </a>
        </div>
        
        <div class="status">
            <div class="status-indicator">
                <span class="status-dot" id="statusDot"></span>
                <span id="statusText"><?php _e('Waiting for connection...', 'rental-gates'); ?></span>
            </div>
        </div>
        
        <div class="cached-pages" id="cachedPages" style="display: none;">
            <h3><?php _e('Available Offline:', 'rental-gates'); ?></h3>
            <ul id="cachedList"></ul>
        </div>
    </div>
    
    <script>
        // Check online status
        function updateStatus() {
            var dot = document.getElementById('statusDot');
            var text = document.getElementById('statusText');
            
            if (navigator.onLine) {
                dot.classList.add('online');
                text.textContent = '<?php _e('Connection restored! Reloading...', 'rental-gates'); ?>';
                setTimeout(function() {
                    location.reload();
                }, 1000);
            } else {
                dot.classList.remove('online');
                text.textContent = '<?php _e('Waiting for connection...', 'rental-gates'); ?>';
            }
        }
        
        window.addEventListener('online', updateStatus);
        window.addEventListener('offline', updateStatus);
        updateStatus();
        
        // Show cached pages
        if ('caches' in window) {
            caches.keys().then(function(names) {
                names.forEach(function(name) {
                    if (name.includes('rental-gates')) {
                        caches.open(name).then(function(cache) {
                            cache.keys().then(function(requests) {
                                var list = document.getElementById('cachedList');
                                var container = document.getElementById('cachedPages');
                                var pages = requests.filter(function(r) {
                                    return r.url.includes('/rental-gates/dashboard') && 
                                           !r.url.includes('.js') && 
                                           !r.url.includes('.css');
                                });
                                
                                if (pages.length > 0) {
                                    container.style.display = 'block';
                                    pages.slice(0, 5).forEach(function(request) {
                                        var url = new URL(request.url);
                                        var path = url.pathname.replace('/rental-gates/dashboard/', '').replace(/\/$/, '') || 'Dashboard';
                                        var name = path.charAt(0).toUpperCase() + path.slice(1);
                                        
                                        var li = document.createElement('li');
                                        li.innerHTML = '<a href="' + request.url + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg> ' + name + '</a>';
                                        list.appendChild(li);
                                    });
                                }
                            });
                        });
                    }
                });
            });
        }
    </script>
</body>
</html>
