<?php
/**
 * Rental Gates - Standalone Landing Page
 * Full-page template that wraps landing-content.php
 * @version 2.17.0
 */
if (!defined('ABSPATH')) exit;

// Variables
$platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
$primary_color = get_option('rental_gates_primary_color', '#0ea5e9');
$landing_theme = get_option('rental_gates_landing_theme', 'modern');
$lang_attr = function_exists('get_language_attributes') ? get_language_attributes() : 'lang="en-US"';
$charset = get_bloginfo('charset') ?: 'UTF-8';

// Set font based on theme
$font_url = $landing_theme === 'minimal' 
    ? 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap'
    : 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap';

$font_family = $landing_theme === 'minimal'
    ? "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
    : "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";

// Skip link target differs by theme
$skip_target = $landing_theme === 'minimal' ? '#rgm-features' : '#rg-features';
?>
<!DOCTYPE html>
<html <?php echo $lang_attr; ?>>
<head>
    <meta charset="<?php echo esc_attr($charset); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title><?php echo esc_html($platform_name); ?> - Modern Property Management</title>
    <meta name="description" content="<?php esc_attr_e('Streamline your property management with modern tools for buildings, tenants, leases, and payments.', 'rental-gates'); ?>">
    <meta name="theme-color" content="<?php echo esc_attr($primary_color); ?>">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="<?php echo esc_url($font_url); ?>" rel="stylesheet">
    
    <style>
        /* Base Reset */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
        body {
            font-family: <?php echo $font_family; ?>;
            font-size: 16px;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        /* Accessibility */
        .skip-link {
            position: absolute;
            top: -40px;
            left: 0;
            background: #0f172a;
            color: #fff;
            padding: 8px 16px;
            z-index: 10000;
            transition: top 0.3s;
            font-weight: 600;
        }
        .skip-link:focus { top: 0; }
        
        /* Ensure landing takes full viewport */
        .rg-landing, .rgm-landing {
            min-height: 100vh;
        }
    </style>
</head>
<body class="rg-theme-<?php echo esc_attr($landing_theme); ?>">
    <!-- Skip Link for Accessibility -->
    <a href="<?php echo $skip_target; ?>" class="skip-link"><?php _e('Skip to main content', 'rental-gates'); ?></a>
    
    <?php
    // Include the appropriate landing page content based on theme
    $theme_file = $landing_theme === 'minimal' ? 'landing-content-minimal.php' : 'landing-content.php';
    include RENTAL_GATES_PLUGIN_DIR . 'templates/public/' . $theme_file;
    ?>
    
    <?php wp_footer(); ?>
</body>
</html>
