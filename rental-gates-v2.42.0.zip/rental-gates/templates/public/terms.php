<?php
/**
 * Rental Gates - Terms of Service Page
 */
if (!defined('ABSPATH')) exit;

$page_title = __('Terms of Service', 'rental-gates');
$page_subtitle = __('Please read these terms carefully before using our services', 'rental-gates');
$meta_description = __('Rental Gates Terms of Service - The rules and guidelines that govern your use of our property management platform.', 'rental-gates');
$current_page = 'terms';
$last_updated = '2024-01-01';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-header.php';
?>

<section class="content-section">
    <div class="container">
        <div class="content-grid sidebar">
            <article class="prose">
                <p><strong><?php _e('Last Updated:', 'rental-gates'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($last_updated)); ?></p>
                
                <h2><?php _e('Agreement to Terms', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('By accessing or using %s ("Service"), you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you may not access the Service.', 'rental-gates'), esc_html($platform_name)); ?></p>
                
                <h2><?php _e('Description of Service', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('%s provides a cloud-based property management platform that enables users to manage properties, tenants, leases, payments, and related operations. The Service includes web applications, APIs, and related tools.', 'rental-gates'), esc_html($platform_name)); ?></p>
                
                <h2><?php _e('User Accounts', 'rental-gates'); ?></h2>
                <h3><?php _e('Registration', 'rental-gates'); ?></h3>
                <p><?php _e('To use certain features of the Service, you must register for an account. You agree to:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('Provide accurate, current, and complete information', 'rental-gates'); ?></li>
                    <li><?php _e('Maintain and promptly update your information', 'rental-gates'); ?></li>
                    <li><?php _e('Maintain the security of your password and account', 'rental-gates'); ?></li>
                    <li><?php _e('Accept responsibility for all activities under your account', 'rental-gates'); ?></li>
                    <li><?php _e('Notify us immediately of unauthorized access', 'rental-gates'); ?></li>
                </ul>
                
                <h3><?php _e('Account Types', 'rental-gates'); ?></h3>
                <p><?php _e('Different account types (Owner, Staff, Tenant, Vendor) have different permissions and capabilities. You are responsible for ensuring appropriate access levels for users within your organization.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Acceptable Use', 'rental-gates'); ?></h2>
                <p><?php _e('You agree NOT to:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('Use the Service for any illegal purpose or in violation of any laws', 'rental-gates'); ?></li>
                    <li><?php _e('Violate the rights of others, including privacy and intellectual property rights', 'rental-gates'); ?></li>
                    <li><?php _e('Transmit malware, viruses, or other harmful code', 'rental-gates'); ?></li>
                    <li><?php _e('Attempt to gain unauthorized access to our systems', 'rental-gates'); ?></li>
                    <li><?php _e('Interfere with or disrupt the Service or servers', 'rental-gates'); ?></li>
                    <li><?php _e('Scrape, harvest, or collect information without permission', 'rental-gates'); ?></li>
                    <li><?php _e('Use the Service to send spam or unsolicited communications', 'rental-gates'); ?></li>
                    <li><?php _e('Impersonate another person or entity', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Payment Terms', 'rental-gates'); ?></h2>
                <h3><?php _e('Subscription Fees', 'rental-gates'); ?></h3>
                <ul>
                    <li><?php _e('Subscription fees are billed in advance on a monthly or annual basis', 'rental-gates'); ?></li>
                    <li><?php _e('All fees are non-refundable unless otherwise stated', 'rental-gates'); ?></li>
                    <li><?php _e('We may change pricing with 30 days notice', 'rental-gates'); ?></li>
                    <li><?php _e('Failure to pay may result in suspension or termination', 'rental-gates'); ?></li>
                </ul>
                
                <h3><?php _e('Payment Processing', 'rental-gates'); ?></h3>
                <p><?php _e('Payments are processed through third-party payment processors. You agree to their terms of service. We are not responsible for errors made by payment processors.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Intellectual Property', 'rental-gates'); ?></h2>
                <p><?php _e('The Service and its original content, features, and functionality are owned by us and are protected by copyright, trademark, and other intellectual property laws. You retain ownership of data you submit but grant us a license to use it to provide the Service.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Your Content', 'rental-gates'); ?></h2>
                <p><?php _e('You are responsible for all content you submit to the Service. By submitting content, you represent that:', 'rental-gates'); ?></p>
                <ul>
                    <li><?php _e('You have the right to submit such content', 'rental-gates'); ?></li>
                    <li><?php _e('The content does not violate any laws or third-party rights', 'rental-gates'); ?></li>
                    <li><?php _e('The content is accurate and not misleading', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Privacy', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('Your use of the Service is also governed by our <a href="%s">Privacy Policy</a>, which is incorporated by reference.', 'rental-gates'), home_url('/rental-gates/privacy')); ?></p>
                
                <h2><?php _e('Disclaimer of Warranties', 'rental-gates'); ?></h2>
                <p><?php _e('THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Limitation of Liability', 'rental-gates'); ?></h2>
                <p><?php _e('IN NO EVENT SHALL WE BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING LOSS OF PROFITS, DATA, OR GOODWILL, ARISING OUT OF OR IN CONNECTION WITH YOUR USE OF THE SERVICE.', 'rental-gates'); ?></p>
                <p><?php _e('OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID US IN THE 12 MONTHS PRIOR TO THE CLAIM.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Indemnification', 'rental-gates'); ?></h2>
                <p><?php _e('You agree to indemnify and hold us harmless from any claims, damages, or expenses arising from your use of the Service, your content, or your violation of these Terms.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Termination', 'rental-gates'); ?></h2>
                <ul>
                    <li><?php _e('You may terminate your account at any time through your account settings', 'rental-gates'); ?></li>
                    <li><?php _e('We may terminate or suspend access for violation of these Terms', 'rental-gates'); ?></li>
                    <li><?php _e('Upon termination, your right to use the Service ceases immediately', 'rental-gates'); ?></li>
                    <li><?php _e('You may export your data before termination', 'rental-gates'); ?></li>
                </ul>
                
                <h2><?php _e('Changes to Terms', 'rental-gates'); ?></h2>
                <p><?php _e('We reserve the right to modify these Terms at any time. We will provide notice of significant changes. Your continued use after changes constitutes acceptance of the new Terms.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Governing Law', 'rental-gates'); ?></h2>
                <p><?php _e('These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in which we operate, without regard to its conflict of law provisions.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Dispute Resolution', 'rental-gates'); ?></h2>
                <p><?php _e('Any disputes arising from these Terms or your use of the Service shall first be attempted to be resolved through informal negotiation. If unsuccessful, disputes shall be resolved through binding arbitration.', 'rental-gates'); ?></p>
                
                <h2><?php _e('Contact Information', 'rental-gates'); ?></h2>
                <p><?php echo sprintf(__('For questions about these Terms, please contact us at <a href="mailto:%s">%s</a> or through our <a href="%s">Contact page</a>.', 'rental-gates'), esc_attr($support_email), esc_html($support_email), home_url('/rental-gates/contact')); ?></p>
            </article>
            
            <aside>
                <div class="card">
                    <h3 style="font-size: 1rem; font-weight: 600; color: var(--gray-900); margin-bottom: 16px;"><?php _e('Quick Links', 'rental-gates'); ?></h3>
                    <ul style="list-style: none; font-size: 0.9375rem;">
                        <li style="margin-bottom: 12px;"><a href="#" style="color: var(--primary);"><?php _e('Download PDF', 'rental-gates'); ?></a></li>
                        <li style="margin-bottom: 12px;"><a href="<?php echo home_url('/rental-gates/privacy'); ?>" style="color: var(--primary);"><?php _e('Privacy Policy', 'rental-gates'); ?></a></li>
                        <li style="margin-bottom: 12px;"><a href="<?php echo home_url('/rental-gates/contact'); ?>" style="color: var(--primary);"><?php _e('Contact Us', 'rental-gates'); ?></a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-footer.php'; ?>
