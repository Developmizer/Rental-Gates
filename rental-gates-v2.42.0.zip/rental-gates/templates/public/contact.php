<?php
/**
 * Rental Gates - Contact Us Page
 */
if (!defined('ABSPATH')) exit;

$page_title = __('Contact Us', 'rental-gates');
$page_subtitle = __('We\'d love to hear from you. Get in touch with our team.', 'rental-gates');
$meta_description = __('Contact the Rental Gates team. We\'re here to help with questions, support, or feedback about our property management software.', 'rental-gates');
$current_page = 'contact';

// Contact info
$contact_email = get_option('rental_gates_support_email', get_option('admin_email'));
$contact_phone = get_option('rental_gates_support_phone', '');
$contact_address = get_option('rental_gates_contact_address', '');

// Departments
$departments = array(
    array(
        'name' => __('Sales', 'rental-gates'),
        'email' => 'sales@' . parse_url(home_url(), PHP_URL_HOST),
        'desc' => __('For pricing, demos, and enterprise inquiries', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>'
    ),
    array(
        'name' => __('Support', 'rental-gates'),
        'email' => $contact_email,
        'desc' => __('Technical support and account assistance', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z"/>'
    ),
    array(
        'name' => __('Partnerships', 'rental-gates'),
        'email' => 'partners@' . parse_url(home_url(), PHP_URL_HOST),
        'desc' => __('Integration and partnership opportunities', 'rental-gates'),
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>'
    )
);

$extra_css = '<style>
    /* Contact Page Specific Styles */
    .contact-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 64px;
    }
    
    .contact-form-wrapper {
        background: #fff;
        border-radius: var(--radius-lg);
        padding: 40px;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--gray-100);
    }
    
    .contact-form-title {
        font-family: "DM Serif Display", serif;
        font-size: 1.5rem;
        color: var(--gray-900);
        margin-bottom: 8px;
    }
    
    .contact-form-subtitle {
        color: var(--gray-500);
        margin-bottom: 32px;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    
    .contact-info-section {
        padding-top: 20px;
    }
    
    .contact-info-section h2 {
        font-family: "DM Serif Display", serif;
        font-size: 1.75rem;
        color: var(--gray-900);
        margin-bottom: 16px;
    }
    
    .contact-info-section > p {
        color: var(--gray-500);
        margin-bottom: 32px;
        font-size: 1.0625rem;
    }
    
    .contact-info-item {
        display: flex;
        align-items: flex-start;
        gap: 16px;
        margin-bottom: 24px;
    }
    
    .contact-info-icon {
        width: 48px;
        height: 48px;
        background: var(--primary-50);
        color: var(--primary);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .contact-info-content h3 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .contact-info-content p,
    .contact-info-content a {
        color: var(--gray-600);
        font-size: 0.9375rem;
    }
    
    .contact-info-content a:hover {
        color: var(--primary);
    }
    
    .departments-section {
        margin-top: 48px;
        padding-top: 48px;
        border-top: 1px solid var(--gray-200);
    }
    
    .departments-section h3 {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 24px;
    }
    
    .department-cards {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }
    
    .department-card {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 20px;
        background: var(--gray-50);
        border-radius: var(--radius-md);
        transition: all 0.2s;
    }
    
    .department-card:hover {
        background: var(--primary-50);
    }
    
    .department-icon {
        width: 44px;
        height: 44px;
        background: #fff;
        color: var(--primary);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .department-info h4 {
        font-size: 0.9375rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 2px;
    }
    
    .department-info p {
        font-size: 0.8125rem;
        color: var(--gray-500);
        margin-bottom: 4px;
    }
    
    .department-info a {
        font-size: 0.875rem;
        color: var(--primary);
        font-weight: 500;
    }
    
    .form-success {
        background: #ecfdf5;
        border: 1px solid #a7f3d0;
        color: #065f46;
        padding: 16px;
        border-radius: var(--radius-sm);
        margin-bottom: 24px;
        display: none;
    }
    
    .form-success.show {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .form-error-alert {
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
        padding: 16px;
        border-radius: var(--radius-sm);
        margin-bottom: 24px;
        display: none;
    }
    
    .form-error-alert.show {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    /* FAQ Preview */
    .faq-preview {
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        padding: 48px;
        text-align: center;
        margin-top: 64px;
    }
    
    .faq-preview h2 {
        font-family: "DM Serif Display", serif;
        font-size: 1.75rem;
        color: var(--gray-900);
        margin-bottom: 12px;
    }
    
    .faq-preview p {
        color: var(--gray-500);
        margin-bottom: 24px;
    }
    
    @media (max-width: 768px) {
        .contact-grid {
            grid-template-columns: 1fr;
            gap: 48px;
        }
        
        .contact-form-wrapper {
            padding: 24px;
            order: 2;
        }
        
        .contact-info-section {
            order: 1;
        }
        
        .form-row {
            grid-template-columns: 1fr;
        }
        
        .faq-preview {
            padding: 32px 24px;
        }
    }
</style>';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-header.php';
?>

<section class="content-section">
    <div class="container">
        <div class="contact-grid">
            <!-- Contact Form -->
            <div class="contact-form-wrapper">
                <h2 class="contact-form-title"><?php _e('Send us a message', 'rental-gates'); ?></h2>
                <p class="contact-form-subtitle"><?php _e('Fill out the form and we\'ll get back to you within 24 hours.', 'rental-gates'); ?></p>
                
                <div class="form-success" id="formSuccess">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span><?php _e('Thank you! Your message has been sent successfully.', 'rental-gates'); ?></span>
                </div>
                
                <div class="form-error-alert" id="formError">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span id="formErrorText"><?php _e('Something went wrong. Please try again.', 'rental-gates'); ?></span>
                </div>
                
                <form id="contactForm" method="post">
                    <input type="hidden" name="action" value="rental_gates_contact_form">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('rental_gates_contact'); ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="contact_name"><?php _e('Name', 'rental-gates'); ?> *</label>
                            <input type="text" id="contact_name" name="name" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="contact_email"><?php _e('Email', 'rental-gates'); ?> *</label>
                            <input type="email" id="contact_email" name="email" class="form-input" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="contact_phone"><?php _e('Phone', 'rental-gates'); ?></label>
                            <input type="tel" id="contact_phone" name="phone" class="form-input">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="contact_company"><?php _e('Company', 'rental-gates'); ?></label>
                            <input type="text" id="contact_company" name="company" class="form-input">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="contact_subject"><?php _e('Subject', 'rental-gates'); ?> *</label>
                        <select id="contact_subject" name="subject" class="form-select" required>
                            <option value=""><?php _e('Select a topic', 'rental-gates'); ?></option>
                            <option value="sales"><?php _e('Sales Inquiry', 'rental-gates'); ?></option>
                            <option value="support"><?php _e('Technical Support', 'rental-gates'); ?></option>
                            <option value="billing"><?php _e('Billing Question', 'rental-gates'); ?></option>
                            <option value="partnership"><?php _e('Partnership Opportunity', 'rental-gates'); ?></option>
                            <option value="feedback"><?php _e('Product Feedback', 'rental-gates'); ?></option>
                            <option value="other"><?php _e('Other', 'rental-gates'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="contact_message"><?php _e('Message', 'rental-gates'); ?> *</label>
                        <textarea id="contact_message" name="message" class="form-textarea" rows="5" required placeholder="<?php _e('How can we help you?', 'rental-gates'); ?>"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" id="submitBtn" style="width: 100%;">
                        <span id="submitText"><?php _e('Send Message', 'rental-gates'); ?></span>
                        <svg id="submitSpinner" style="display: none;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <circle cx="12" cy="12" r="10" stroke-width="2" opacity="0.3"/>
                            <path d="M12 2a10 10 0 0 1 10 10" stroke-width="2" stroke-linecap="round">
                                <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/>
                            </path>
                        </svg>
                    </button>
                </form>
            </div>
            
            <!-- Contact Info -->
            <div class="contact-info-section">
                <h2><?php _e('Get in touch', 'rental-gates'); ?></h2>
                <p><?php _e('We\'re here to help and answer any questions you might have. We look forward to hearing from you.', 'rental-gates'); ?></p>
                
                <div class="contact-info-item">
                    <div class="contact-info-icon">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <div class="contact-info-content">
                        <h3><?php _e('Email', 'rental-gates'); ?></h3>
                        <a href="mailto:<?php echo esc_attr($contact_email); ?>"><?php echo esc_html($contact_email); ?></a>
                    </div>
                </div>
                
                <?php if ($contact_phone): ?>
                <div class="contact-info-item">
                    <div class="contact-info-icon">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                        </svg>
                    </div>
                    <div class="contact-info-content">
                        <h3><?php _e('Phone', 'rental-gates'); ?></h3>
                        <a href="tel:<?php echo esc_attr($contact_phone); ?>"><?php echo esc_html($contact_phone); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="contact-info-item">
                    <div class="contact-info-icon">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="contact-info-content">
                        <h3><?php _e('Business Hours', 'rental-gates'); ?></h3>
                        <p><?php _e('Monday - Friday: 9am - 6pm EST', 'rental-gates'); ?></p>
                    </div>
                </div>
                
                <!-- Departments -->
                <div class="departments-section">
                    <h3><?php _e('Contact by Department', 'rental-gates'); ?></h3>
                    <div class="department-cards">
                        <?php foreach ($departments as $dept): ?>
                        <div class="department-card">
                            <div class="department-icon">
                                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <?php echo $dept['icon']; ?>
                                </svg>
                            </div>
                            <div class="department-info">
                                <h4><?php echo esc_html($dept['name']); ?></h4>
                                <p><?php echo esc_html($dept['desc']); ?></p>
                                <a href="mailto:<?php echo esc_attr($dept['email']); ?>"><?php echo esc_html($dept['email']); ?></a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- FAQ Preview -->
        <div class="faq-preview">
            <h2><?php _e('Looking for quick answers?', 'rental-gates'); ?></h2>
            <p><?php _e('Check out our frequently asked questions for instant help with common topics.', 'rental-gates'); ?></p>
            <a href="<?php echo home_url('/rental-gates/faq'); ?>" class="btn btn-secondary">
                <?php _e('Browse FAQ', 'rental-gates'); ?>
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>
    </div>
</section>

<?php
$extra_js = '<script>
document.getElementById("contactForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById("submitBtn");
    const btnText = document.getElementById("submitText");
    const spinner = document.getElementById("submitSpinner");
    const success = document.getElementById("formSuccess");
    const error = document.getElementById("formError");
    
    // Reset states
    success.classList.remove("show");
    error.classList.remove("show");
    btn.disabled = true;
    btnText.style.display = "none";
    spinner.style.display = "block";
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch("' . admin_url('admin-ajax.php') . '", {
            method: "POST",
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            success.classList.add("show");
            this.reset();
        } else {
            document.getElementById("formErrorText").textContent = result.data || "' . __('Something went wrong. Please try again.', 'rental-gates') . '";
            error.classList.add("show");
        }
    } catch (err) {
        error.classList.add("show");
    } finally {
        btn.disabled = false;
        btnText.style.display = "block";
        spinner.style.display = "none";
    }
});
</script>';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-footer.php';
?>
