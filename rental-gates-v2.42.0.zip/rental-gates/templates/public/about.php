<?php
/**
 * Rental Gates - About Us Page
 */
if (!defined('ABSPATH')) exit;

$page_title = __('About Us', 'rental-gates');
$page_subtitle = __('Learn about our mission to revolutionize property management', 'rental-gates');
$meta_description = __('Learn about Rental Gates - modern property management software built to simplify operations for landlords and property managers.', 'rental-gates');
$current_page = 'about';

// Team members (can be made configurable later)
$team = array(
    array(
        'name' => 'Sarah Mitchell',
        'role' => __('CEO & Co-Founder', 'rental-gates'),
        'bio' => __('Former property manager with 15+ years of experience. Founded Rental Gates to solve the problems she faced daily.', 'rental-gates'),
        'initials' => 'SM'
    ),
    array(
        'name' => 'David Chen',
        'role' => __('CTO & Co-Founder', 'rental-gates'),
        'bio' => __('Software engineer who built property tech solutions for Fortune 500 companies. Passionate about creating intuitive software.', 'rental-gates'),
        'initials' => 'DC'
    ),
    array(
        'name' => 'Maria Rodriguez',
        'role' => __('Head of Customer Success', 'rental-gates'),
        'bio' => __('Dedicated to ensuring every customer succeeds. Previously led support teams at leading SaaS companies.', 'rental-gates'),
        'initials' => 'MR'
    ),
    array(
        'name' => 'James Wilson',
        'role' => __('Head of Product', 'rental-gates'),
        'bio' => __('Product leader focused on building features that matter. Background in real estate technology and UX design.', 'rental-gates'),
        'initials' => 'JW'
    )
);

// Stats
$stats = array(
    array('value' => '10K+', 'label' => __('Properties Managed', 'rental-gates')),
    array('value' => '500+', 'label' => __('Happy Customers', 'rental-gates')),
    array('value' => '99.9%', 'label' => __('Uptime', 'rental-gates')),
    array('value' => '24/7', 'label' => __('Support', 'rental-gates'))
);

// Values
$values = array(
    array(
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>',
        'title' => __('Simplicity First', 'rental-gates'),
        'desc' => __('We believe powerful software should be simple to use. Every feature is designed with ease of use in mind.', 'rental-gates')
    ),
    array(
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>',
        'title' => __('Security & Privacy', 'rental-gates'),
        'desc' => __('Your data security is paramount. We use bank-level encryption and never sell or share your information.', 'rental-gates')
    ),
    array(
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>',
        'title' => __('Customer Focused', 'rental-gates'),
        'desc' => __('Our customers are at the heart of everything we do. We actively listen to feedback and continuously improve.', 'rental-gates')
    ),
    array(
        'icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>',
        'title' => __('Innovation', 'rental-gates'),
        'desc' => __('We embrace cutting-edge technology like AI to help you work smarter, not harder.', 'rental-gates')
    )
);

$extra_css = '<style>
    /* About Page Specific Styles */
    .about-story {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 64px;
        align-items: center;
    }
    
    .about-story-content h2 {
        font-family: "DM Serif Display", serif;
        font-size: 2rem;
        color: var(--gray-900);
        margin-bottom: 20px;
    }
    
    .about-story-content p {
        color: var(--gray-600);
        margin-bottom: 16px;
        font-size: 1.0625rem;
        line-height: 1.7;
    }
    
    .about-story-image {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-darker) 100%);
        border-radius: var(--radius-lg);
        aspect-ratio: 4/3;
        display: flex;
        align-items: center;
        justify-content: center;
        color: rgba(255,255,255,0.2);
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 32px;
        text-align: center;
        padding: 48px 0;
        border-top: 1px solid var(--gray-200);
        border-bottom: 1px solid var(--gray-200);
        margin: 48px 0;
    }
    
    .stat-item-value {
        font-family: "DM Serif Display", serif;
        font-size: 2.5rem;
        color: var(--primary);
        margin-bottom: 8px;
    }
    
    .stat-item-label {
        font-size: 0.9375rem;
        color: var(--gray-500);
        font-weight: 500;
    }
    
    .values-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 32px;
    }
    
    .value-card {
        display: flex;
        gap: 20px;
    }
    
    .value-icon {
        width: 48px;
        height: 48px;
        background: var(--primary-50);
        color: var(--primary);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .value-content h3 {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 8px;
    }
    
    .value-content p {
        color: var(--gray-500);
        font-size: 0.9375rem;
        line-height: 1.6;
    }
    
    .team-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 32px;
    }
    
    .team-card {
        text-align: center;
    }
    
    .team-avatar {
        width: 100px;
        height: 100px;
        background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary) 100%);
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0 auto 16px;
    }
    
    .team-name {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 4px;
    }
    
    .team-role {
        font-size: 0.875rem;
        color: var(--primary);
        font-weight: 500;
        margin-bottom: 12px;
    }
    
    .team-bio {
        font-size: 0.875rem;
        color: var(--gray-500);
        line-height: 1.6;
    }
    
    .cta-banner {
        background: linear-gradient(135deg, var(--primary-darker) 0%, var(--primary) 100%);
        color: #fff;
        border-radius: var(--radius-lg);
        padding: 48px;
        text-align: center;
        margin-top: 64px;
    }
    
    .cta-banner h2 {
        font-family: "DM Serif Display", serif;
        font-size: 2rem;
        margin-bottom: 16px;
    }
    
    .cta-banner p {
        opacity: 0.9;
        margin-bottom: 24px;
        max-width: 500px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .cta-banner .btn {
        background: #fff;
        color: var(--primary);
    }
    
    .cta-banner .btn:hover {
        background: var(--gray-100);
    }
    
    @media (max-width: 1024px) {
        .team-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .about-story {
            grid-template-columns: 1fr;
            gap: 32px;
        }
        
        .about-story-image {
            order: -1;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .values-grid {
            grid-template-columns: 1fr;
        }
        
        .team-grid {
            grid-template-columns: 1fr;
        }
        
        .cta-banner {
            padding: 32px 24px;
        }
    }
</style>';

include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-header.php';
?>

<!-- Our Story -->
<section class="content-section">
    <div class="container">
        <div class="about-story">
            <div class="about-story-content">
                <h2><?php _e('Our Story', 'rental-gates'); ?></h2>
                <p><?php _e('Rental Gates was born from frustration. Our founders, experienced property managers and software engineers, were tired of using outdated, complicated property management systems that created more problems than they solved.', 'rental-gates'); ?></p>
                <p><?php _e('We set out to build something different—a modern, intuitive platform that makes property management actually enjoyable. One that works the way you think, not the other way around.', 'rental-gates'); ?></p>
                <p><?php _e('Today, Rental Gates helps hundreds of property managers streamline their operations, delight their tenants, and grow their portfolios. And we\'re just getting started.', 'rental-gates'); ?></p>
            </div>
            <div class="about-story-image">
                <svg width="200" height="200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                </svg>
            </div>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <?php foreach ($stats as $stat): ?>
            <div class="stat-item">
                <div class="stat-item-value"><?php echo esc_html($stat['value']); ?></div>
                <div class="stat-item-label"><?php echo esc_html($stat['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Our Values -->
<section class="content-section gray">
    <div class="container">
        <header class="section-header">
            <span class="section-label"><?php _e('Our Values', 'rental-gates'); ?></span>
            <h2 class="section-title"><?php _e('What We Stand For', 'rental-gates'); ?></h2>
            <p class="section-subtitle"><?php _e('These core principles guide everything we do at Rental Gates.', 'rental-gates'); ?></p>
        </header>
        
        <div class="values-grid">
            <?php foreach ($values as $value): ?>
            <div class="value-card">
                <div class="value-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <?php echo $value['icon']; ?>
                    </svg>
                </div>
                <div class="value-content">
                    <h3><?php echo esc_html($value['title']); ?></h3>
                    <p><?php echo esc_html($value['desc']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Team -->
<section class="content-section">
    <div class="container">
        <header class="section-header">
            <span class="section-label"><?php _e('Our Team', 'rental-gates'); ?></span>
            <h2 class="section-title"><?php _e('Meet the People Behind Rental Gates', 'rental-gates'); ?></h2>
            <p class="section-subtitle"><?php _e('Passionate individuals dedicated to making property management better.', 'rental-gates'); ?></p>
        </header>
        
        <div class="team-grid">
            <?php foreach ($team as $member): ?>
            <div class="team-card">
                <div class="team-avatar"><?php echo esc_html($member['initials']); ?></div>
                <h3 class="team-name"><?php echo esc_html($member['name']); ?></h3>
                <p class="team-role"><?php echo esc_html($member['role']); ?></p>
                <p class="team-bio"><?php echo esc_html($member['bio']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- CTA Banner -->
        <div class="cta-banner">
            <h2><?php _e('Ready to Get Started?', 'rental-gates'); ?></h2>
            <p><?php _e('Join thousands of property managers who trust Rental Gates to run their business.', 'rental-gates'); ?></p>
            <a href="<?php echo home_url('/rental-gates/register'); ?>" class="btn">
                <?php _e('Start Your Free Trial', 'rental-gates'); ?>
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>
    </div>
</section>

<?php include RENTAL_GATES_PLUGIN_DIR . 'templates/public/partials/public-layout-footer.php'; ?>
