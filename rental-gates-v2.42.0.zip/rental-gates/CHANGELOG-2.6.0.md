# Rental Gates v2.6.0 Changelog

## Phase 1 - Quick Wins Complete ✅

### 1. AJAX Delete Confirmations
Beautiful modal-based delete confirmations replacing browser `confirm()` dialogs.

**Features:**
- Warning icon with animated styling
- Loading state with spinner during delete
- Toast notification on success/error
- Automatic row/card removal animation
- Declarative `data-rg-delete` attribute support

**Templates Updated:**
- `building-detail.php` - Building & unit deletion
- `lease-detail.php` - Lease actions (activate, delete, end, remove tenant)
- `leases.php` - Lease list actions
- `documents.php` - Document deletion
- `maintenance-detail.php` - Work order deletion
- `tenant-detail.php` - Tenant deletion & portal invitation
- `vendor-detail.php` - Vendor deletion & portal invitation
- `unit-detail.php` - Unit deletion
- `payment-detail.php` - Payment cancellation & deletion

### 2. WordPress Media Library Integration
Replaced custom file upload with native WP Media Library picker.

**Features:**
- `RentalGates.selectImage()` - Single image selection
- `RentalGates.selectImages()` - Multiple image selection
- Gallery manager with live preview
- Automatic thumbnail generation
- Toast notifications on success

**Templates Updated:**
- `buildings-form.php` - Gallery upload now uses WP Media
- `unit-form.php` - Gallery upload now uses WP Media

**Benefits:**
- Images stored in WordPress Media Library
- Automatic image optimization
- Consistent with WordPress ecosystem
- Better file management

### 3. Enhanced QR Code Generator
Complete rewrite of `class-rental-gates-qr.php` with advanced features.

**New Capabilities:**
- Multiple sizes: small (150px), medium (300px), large (500px), print (1000px)
- Bulk generation for all buildings/units
- Scan analytics (daily counts, device breakdown, unique visitors)
- Custom URL QR codes with labels
- Reuses existing QR codes (no duplicates)
- Device type detection (mobile/tablet/desktop)

**New Methods:**
```php
Rental_Gates_QR::get($id)
Rental_Gates_QR::get_by_code($code)
Rental_Gates_QR::get_for_organization($org_id, $args)
Rental_Gates_QR::get_scan_analytics($qr_id, $days)
Rental_Gates_QR::delete($id)
$qr->bulk_generate($items, $size)
$qr->generate_all_buildings($org_id, $size)
$qr->generate_all_units($org_id, $size)
$qr->generate_custom($url, $org_id, $label, $size)
```

### 4. Toast Notification System
New slide-in toast notifications for user feedback.

**Features:**
- 4 types: success (green), error (red), warning (yellow), info (blue)
- Auto-dismiss with configurable duration
- Manual dismiss button
- Stacking support for multiple toasts

**Usage:**
```javascript
RentalGates.showToast('Message', 'success');
RentalGates.showToast('Error message', 'error', 6000);
```

### 5. Component CSS
New comprehensive stylesheet `assets/css/components.css`:
- Modal dialogs (small/medium/large)
- Toast notifications
- Gallery grid with hover effects
- Featured image selector
- QR code display
- Button variants
- Loading spinner
- Responsive adjustments

## Technical Changes

### Files Added/Modified:
- `assets/js/rental-gates.js` - Complete rewrite (~600 lines)
- `assets/css/components.css` - New component styles (~400 lines)
- `includes/public/class-rental-gates-qr.php` - Enhanced (~400 lines)
- `rental-gates.php` - Added wp_enqueue_media, i18n strings, QR handler fixes
- 10+ dashboard templates updated with modal-based actions

### JavaScript API:
```javascript
// Modal System
RentalGates.showModal(options)
RentalGates.hideModal()
RentalGates.confirmDelete(options)

// Media Library
RentalGates.selectImage(callback)
RentalGates.selectImages(callback)
RentalGates.initGallery(containerId, inputId)
RentalGates.initFeaturedImage(buttonId, previewId, inputId)

// QR Codes
RentalGates.generateQR(type, id, callback)
RentalGates.showQRModal(qrData)

// Toast Notifications
RentalGates.showToast(message, type, duration)

// Utilities
RentalGates.formatCurrency(amount, currency)
RentalGates.formatDate(date)
RentalGates.debounce(func, wait)
```

## Version
2.5.9 → 2.6.0
