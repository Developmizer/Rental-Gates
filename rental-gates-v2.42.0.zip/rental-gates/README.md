# Rental Gates - Property Management Platform

[![Version](https://img.shields.io/badge/version-2.24.1-blue.svg)](https://rentalgates.com)
[![WordPress](https://img.shields.io/badge/WordPress-6.0%2B-green.svg)](https://wordpress.org)
[![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)](https://php.net)
[![License](https://img.shields.io/badge/license-GPL--2.0%2B-orange.svg)](https://www.gnu.org/licenses/gpl-2.0.html)

A comprehensive, multi-tenant property management solution for WordPress. Manage buildings, units, tenants, leases, payments, maintenance, and more from a single powerful platform.

---

## 🏠 Overview

Rental Gates transforms your WordPress site into a full-featured property management platform. Whether you're managing a single property or hundreds of buildings, Rental Gates provides the tools you need to streamline operations, collect rent, communicate with tenants, and grow your business.

### Key Features

- **Multi-Tenant Architecture** - Manage multiple organizations from one installation
- **Map-Based Property Management** - Add buildings by placing pins on interactive maps
- **Complete Lease Lifecycle** - Applications, screening, leases, renewals
- **Online Rent Collection** - Stripe integration for payments
- **Maintenance Management** - Work orders, vendor assignments, tracking
- **AI-Powered Tools** - Listing descriptions, tenant screening, insights
- **QR Code Marketing** - Generate codes linking to property listings
- **Progressive Web App** - Installable mobile experience with offline support
- **Role-Based Access** - Owner, Manager, Staff, Tenant, Vendor portals

---

## 📋 Requirements

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| WordPress | 6.0+ | 6.4+ |
| PHP | 7.4+ | 8.1+ |
| MySQL | 5.7+ | 8.0+ |
| Memory | 128MB | 256MB+ |
| HTTPS | Required | Required |

### Required PHP Extensions
- `curl` - API communications
- `json` - Data processing
- `mbstring` - String handling
- `openssl` - Encryption
- `gd` or `imagick` - Image processing

### Recommended Services
- **Stripe Account** - Payment processing
- **OpenAI API Key** - AI features
- **Google Maps API Key** - Enhanced mapping (optional)

---

## 🚀 Quick Start

### Installation

1. **Upload Plugin**
   - Download `rental-gates.zip`
   - Go to WordPress Admin → Plugins → Add New → Upload
   - Upload and activate the plugin

2. **Initial Setup**
   - Navigate to Rental Gates → Settings
   - Configure your organization name and details
   - Add your Stripe API keys (optional)
   - Add your OpenAI API key (optional)

3. **Add Your First Property**
   - Go to Dashboard → Buildings → Add Building
   - Click on the map to place your building
   - Fill in property details and save

4. **Invite Team Members**
   - Go to Dashboard → Staff
   - Add staff members with appropriate roles
   - They'll receive email invitations

### Access URLs

| Portal | URL | Purpose |
|--------|-----|---------|
| Registration | `/rental-gates/register` | New organization signup |
| Login | `/rental-gates/login` | User authentication |
| Owner Dashboard | `/rental-gates/dashboard` | Property owner/manager portal |
| Tenant Portal | `/rental-gates/tenant` | Tenant self-service |
| Staff Portal | `/rental-gates/staff` | Staff member access |
| Vendor Portal | `/rental-gates/vendor` | Vendor work orders |
| Site Admin | `/rental-gates/admin` | Platform administration |

---

## 🏗️ Architecture

### Database Schema

Rental Gates creates 49 database tables organized into logical groups:

```
Core (5 tables)
├── rg_organizations        - Multi-tenant root
├── rg_organization_members - User-org relationships
├── rg_staff_permissions    - Granular access control
├── rg_settings            - Per-org configuration
└── rg_activity_log        - Audit trail

Property (2 tables)
├── rg_buildings           - Properties with geocoding
└── rg_units              - Units with availability states

People (2 tables)
├── rg_tenants            - Tenant profiles
└── rg_vendors            - Vendor profiles

Leasing (5 tables)
├── rg_applications       - Rental applications
├── rg_application_occupants
├── rg_leases            - Active leases
├── rg_lease_tenants     - Lease-tenant links
└── rg_renewals          - Renewal tracking

Financial (7 tables)
├── rg_payments          - Rent payments
├── rg_payment_items     - Line items
├── rg_payment_plans     - Installment plans
├── rg_deposits          - Security deposits
└── ... more

Operations (4 tables)
├── rg_work_orders       - Maintenance requests
├── rg_scheduled_maintenance
└── ... more

Communication (5 tables)
├── rg_messages          - Threaded messaging
├── rg_announcements     - Broadcast messages
├── rg_notifications     - System notifications
└── ... more

Marketing (3 tables)
├── rg_flyers           - Generated flyers
├── rg_qr_codes         - QR tracking
└── rg_qr_scans         - Scan analytics

Subscription (5 tables)
├── rg_plans            - SaaS pricing plans
├── rg_subscriptions    - Active subscriptions
├── rg_invoices         - Billing history
└── ... more

AI (3 tables)
├── rg_ai_usage         - Credit tracking
├── rg_ai_screenings    - Application screenings
└── rg_rent_adjustments - AI rent suggestions
```

### Role Hierarchy

```
Site Admin (Platform)
    └── Owner (Organization)
        └── Property Manager
            └── Staff (Leasing Agent, Maintenance, Accountant)
                └── Tenant / Vendor
```

### File Structure

```
rental-gates/
├── rental-gates.php          # Main plugin file (7,800+ lines)
├── includes/
│   ├── class-rental-gates-*.php    # Core classes
│   ├── models/               # 20 data models
│   ├── api/                  # REST API (156+ endpoints)
│   ├── admin/                # WP Admin integration
│   ├── automation/           # Cron jobs, notifications
│   ├── subscription/         # Billing system
│   ├── maps/                 # Map services
│   └── public/               # Public features
├── templates/
│   ├── auth/                 # Login, register
│   ├── dashboard/            # 5 portal layouts + 44 sections
│   ├── emails/               # 28 email templates
│   ├── flyers/               # Marketing flyers
│   └── public/               # Public-facing pages
├── assets/
│   ├── css/                  # Stylesheets
│   ├── js/                   # JavaScript + PWA
│   └── images/               # Icons, PWA assets
├── docs/                     # Documentation
└── languages/                # Translations
```

---

## 📊 Features by Role

### Property Owner/Manager

| Feature | Description |
|---------|-------------|
| Buildings | Add, edit, manage properties with map-based interface |
| Units | Manage units with availability states, pricing, amenities |
| Tenants | Tenant profiles, contact info, lease history |
| Leases | Create leases, track renewals, manage terms |
| Applications | Receive and review rental applications |
| Payments | Track rent collection, late fees, payment history |
| Maintenance | Work orders, vendor assignments, scheduling |
| Reports | Financial reports, occupancy analytics |
| Marketing | QR codes, flyers, listing management |
| AI Tools | Generate descriptions, screen tenants |
| Settings | Organization settings, staff permissions |

### Tenant

| Feature | Description |
|---------|-------------|
| Dashboard | View lease info, upcoming payments |
| Payments | Pay rent online, view history |
| Maintenance | Submit and track repair requests |
| Messages | Communicate with management |
| Documents | Access lease, receipts, notices |
| Profile | Update contact information |

### Staff

| Feature | Description |
|---------|-------------|
| Assigned Properties | View buildings in their portfolio |
| Leads | Manage prospect pipeline |
| Applications | Process rental applications |
| Showings | Schedule property tours |
| Maintenance | Handle work orders (if assigned) |
| Reports | View relevant analytics |

### Vendor

| Feature | Description |
|---------|-------------|
| Work Orders | View assigned maintenance tasks |
| Updates | Add notes, photos, status updates |
| History | View completed work history |
| Profile | Manage services, availability |

### Site Admin

| Feature | Description |
|---------|-------------|
| Organizations | Manage all organizations |
| Users | User management across platform |
| Plans | Configure subscription plans |
| Settings | Platform-wide configuration |
| Integrations | API keys, third-party services |
| Email Templates | Customize system emails |
| Feature Flags | Enable/disable features |
| PWA Settings | Progressive web app configuration |
| Reports | Platform analytics |
| System Health | Server status, diagnostics |

---

## 🔌 Integrations

### Stripe

Process payments securely with Stripe:
- Subscription billing for platform
- Rent collection for tenants
- Automatic payment reminders
- Failed payment handling

### OpenAI

AI-powered features:
- Generate listing descriptions
- Tenant application screening
- Maintenance request analysis
- Lease term suggestions

### Maps

Interactive property mapping:
- **Google Maps** - Full-featured with Places API
- **OpenStreetMap** - Free alternative with Nominatim

### Email

Transactional email system:
- 28 pre-built templates
- Customizable branding
- Queue for reliability
- Delivery tracking

---

## 📱 Progressive Web App

Rental Gates includes full PWA support:

- **Offline Support** - Access cached data without internet
- **Push Notifications** - Real-time alerts for payments, maintenance
- **Home Screen Install** - Native app-like experience
- **Background Sync** - Queue actions while offline

Enable PWA in Site Admin → PWA Settings.

---

## 🔒 Security

### Built-in Protections

- **CSRF Protection** - Nonce verification on all forms
- **SQL Injection Prevention** - Prepared statements throughout
- **XSS Prevention** - Output escaping and sanitization
- **Rate Limiting** - Configurable per-action limits
- **Role-Based Access** - Granular permission system
- **Encryption** - Sensitive data encryption at rest
- **Audit Logging** - Track all significant actions

### Best Practices

- Always use HTTPS
- Keep WordPress and plugins updated
- Use strong passwords
- Enable two-factor authentication
- Regular backups
- Monitor activity logs

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [Installation Guide](docs/INSTALLATION.md) | Detailed setup instructions |
| [User Guide](docs/USER-GUIDE.md) | Portal-specific documentation |
| [Admin Guide](docs/ADMIN-GUIDE.md) | Platform administration |
| [API Reference](docs/API-REFERENCE.md) | REST API documentation |
| [Developer Guide](docs/DEVELOPER-GUIDE.md) | Hooks, filters, customization |
| [Mobile Optimization](docs/MOBILE-OPTIMIZATION.md) | Responsive design details |
| [Changelog](CHANGELOG.md) | Version history |

---

## 🛠️ Support

### Getting Help

1. **Documentation** - Check the docs folder
2. **Support Tools** - Site Admin → Support
3. **Activity Logs** - Review for troubleshooting
4. **System Health** - Check server requirements

### Reporting Issues

When reporting issues, please include:
- WordPress version
- PHP version
- Plugin version
- Steps to reproduce
- Error messages (if any)
- Browser/device information

---

## 📄 License

Rental Gates is licensed under the GPL v2 or later.

```
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## 🙏 Credits

Built with:
- [WordPress](https://wordpress.org)
- [Stripe](https://stripe.com)
- [OpenAI](https://openai.com)
- [Tailwind CSS](https://tailwindcss.com) concepts
- [Heroicons](https://heroicons.com)

---

**Rental Gates** - Professional Property Management for WordPress

*Version 2.24.1 | © 2024-2025*
