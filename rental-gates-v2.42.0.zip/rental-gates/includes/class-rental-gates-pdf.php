<?php
/**
 * Rental Gates PDF Generator
 * 
 * Generates professional PDF documents for:
 * - Lease agreements
 * - Payment receipts
 * - Invoices
 * - Work orders
 * - Property reports
 * - Flyers/Marketing materials
 * 
 * @package RentalGates
 * @since 2.21.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_PDF {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Generate lease agreement PDF
     */
    public function generate_lease($lease_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $lease = Rental_Gates_Lease::get_with_details($lease_id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        $org = Rental_Gates_Organization::get($lease['organization_id']);
        $unit = Rental_Gates_Unit::get($lease['unit_id']);
        $building = $unit ? Rental_Gates_Building::get($unit['building_id']) : null;
        
        $tenants = $wpdb->get_results($wpdb->prepare(
            "SELECT lt.*, t.first_name, t.last_name, t.email, t.phone
             FROM {$tables['lease_tenants']} lt
             JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
             WHERE lt.lease_id = %d",
            $lease_id
        ), ARRAY_A);
        
        $html = $this->render_lease_template(array(
            'lease' => $lease,
            'organization' => $org,
            'unit' => $unit,
            'building' => $building,
            'tenants' => $tenants,
        ));
        
        return $this->save_pdf($html, 'lease-' . $lease_id . '.html', $org);
    }
    
    /**
     * Generate payment receipt PDF
     */
    public function generate_receipt($payment_id) {
        $payment = Rental_Gates_Payment::get_with_details($payment_id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        $org = Rental_Gates_Organization::get($payment['organization_id']);
        $tenant = $payment['tenant_id'] ? Rental_Gates_Tenant::get($payment['tenant_id']) : null;
        $lease = $payment['lease_id'] ? Rental_Gates_Lease::get($payment['lease_id']) : null;
        $unit = $lease && $lease['unit_id'] ? Rental_Gates_Unit::get($lease['unit_id']) : null;
        
        $html = $this->render_receipt_template(array(
            'payment' => $payment,
            'organization' => $org,
            'tenant' => $tenant,
            'unit' => $unit,
        ));
        
        $filename = 'receipt-' . ($payment['payment_number'] ?? $payment_id) . '.html';
        return $this->save_pdf($html, $filename, $org);
    }
    
    /**
     * Generate invoice PDF
     */
    public function generate_invoice($invoice_data) {
        $org = Rental_Gates_Organization::get($invoice_data['organization_id']);
        $tenant = isset($invoice_data['tenant_id']) ? Rental_Gates_Tenant::get($invoice_data['tenant_id']) : null;
        
        $html = $this->render_invoice_template(array(
            'invoice' => $invoice_data,
            'organization' => $org,
            'tenant' => $tenant,
        ));
        
        $filename = 'invoice-' . ($invoice_data['invoice_number'] ?? date('Ymd-His')) . '.html';
        return $this->save_pdf($html, $filename, $org);
    }
    
    /**
     * Generate work order PDF
     */
    public function generate_work_order($work_order_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $work_order = Rental_Gates_Maintenance::get_with_details($work_order_id);
        if (!$work_order) {
            return new WP_Error('not_found', __('Work order not found', 'rental-gates'));
        }
        
        $org = Rental_Gates_Organization::get($work_order['organization_id']);
        $unit = $work_order['unit_id'] ? Rental_Gates_Unit::get($work_order['unit_id']) : null;
        $building = $unit ? Rental_Gates_Building::get($unit['building_id']) : null;
        $tenant = $work_order['tenant_id'] ? Rental_Gates_Tenant::get($work_order['tenant_id']) : null;
        
        $notes = $wpdb->get_results($wpdb->prepare(
            "SELECT n.*, u.display_name as author_name
             FROM {$tables['work_order_notes']} n
             LEFT JOIN {$wpdb->users} u ON n.user_id = u.ID
             WHERE n.work_order_id = %d ORDER BY n.created_at ASC",
            $work_order_id
        ), ARRAY_A);
        
        $html = $this->render_work_order_template(array(
            'work_order' => $work_order,
            'organization' => $org,
            'unit' => $unit,
            'building' => $building,
            'tenant' => $tenant,
            'notes' => $notes ?: array(),
        ));
        
        return $this->save_pdf($html, 'work-order-' . $work_order_id . '.html', $org);
    }
    
    /**
     * Generate property report PDF
     */
    public function generate_property_report($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $org = Rental_Gates_Organization::get($org_id);
        if (!$org) {
            return new WP_Error('not_found', __('Organization not found', 'rental-gates'));
        }
        
        $stats = array(
            'total_buildings' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = %d AND status = 'active'", $org_id
            )),
            'total_units' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['units']} WHERE organization_id = %d", $org_id
            )),
            'occupied_units' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['units']} WHERE organization_id = %d AND availability = 'occupied'", $org_id
            )),
            'active_leases' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['leases']} WHERE organization_id = %d AND status = 'active'", $org_id
            )),
            'total_tenants' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['tenants']} WHERE organization_id = %d AND status = 'active'", $org_id
            )),
            'monthly_revenue' => $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(rent_amount), 0) FROM {$tables['units']} WHERE organization_id = %d AND availability = 'occupied'", $org_id
            )),
            'collected_this_month' => $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(amount_paid), 0) FROM {$tables['payments']}
                 WHERE organization_id = %d AND status = 'completed'
                 AND MONTH(paid_at) = MONTH(CURRENT_DATE()) AND YEAR(paid_at) = YEAR(CURRENT_DATE())", $org_id
            )),
            'open_maintenance' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['work_orders']} WHERE organization_id = %d AND status IN ('new', 'in_progress')", $org_id
            )),
        );
        
        $buildings = Rental_Gates_Building::get_for_organization($org_id, array('limit' => 100));
        
        $html = $this->render_report_template(array(
            'organization' => $org,
            'stats' => $stats,
            'buildings' => $buildings['items'],
        ));
        
        return $this->save_pdf($html, 'report-' . date('Y-m-d') . '.html', $org);
    }
    
    /**
     * Generate unit flyer PDF
     */
    public function generate_flyer($unit_id, $template = 'modern') {
        $unit = Rental_Gates_Unit::get($unit_id);
        if (!$unit) {
            return new WP_Error('not_found', __('Unit not found', 'rental-gates'));
        }
        
        $building = Rental_Gates_Building::get($unit['building_id']);
        $org = Rental_Gates_Organization::get($unit['organization_id']);
        
        $qr = new Rental_Gates_QR();
        $qr_data = $qr->generate_for_unit($unit_id, 'medium');
        
        $html = $this->render_flyer_template(array(
            'unit' => $unit,
            'building' => $building,
            'organization' => $org,
            'qr_code' => $qr_data['qr_image'] ?? '',
            'template' => $template,
        ));
        
        return $this->save_pdf($html, 'flyer-' . $unit['slug'] . '.html', $org);
    }
    
    // ==========================================
    // TEMPLATE RENDERERS
    // ==========================================
    
    private function render_lease_template($data) {
        extract($data);
        $tenant_names = array_map(function($t) { return $t['first_name'] . ' ' . $t['last_name']; }, $tenants ?: array());
        
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Lease Agreement</title>
<?php echo $this->get_styles(); ?>
</head><body>
<div class="header">
    <h1>RESIDENTIAL LEASE AGREEMENT</h1>
    <p class="org-name"><?php echo esc_html($organization['name'] ?? ''); ?></p>
</div>

<div class="section">
    <h2>1. PARTIES</h2>
    <p><strong>LANDLORD:</strong> <?php echo esc_html($organization['name'] ?? ''); ?></p>
    <?php if (!empty($organization['address'])): ?><p>Address: <?php echo esc_html($organization['address']); ?></p><?php endif; ?>
    <?php if (!empty($organization['contact_email'])): ?><p>Email: <?php echo esc_html($organization['contact_email']); ?></p><?php endif; ?>
    <p><strong>TENANT(S):</strong> <?php echo esc_html(implode(', ', $tenant_names)); ?></p>
</div>

<div class="section">
    <h2>2. PROPERTY</h2>
    <div class="box">
        <p><strong>Property:</strong> <?php echo esc_html($unit['name'] ?? ''); ?></p>
        <p><strong>Building:</strong> <?php echo esc_html($building['name'] ?? ''); ?></p>
        <p><strong>Address:</strong> <?php echo esc_html($building['derived_address'] ?? ''); ?></p>
        <?php if (!empty($unit['bedrooms'])): ?><p><strong>Bedrooms:</strong> <?php echo intval($unit['bedrooms']); ?></p><?php endif; ?>
        <?php if (!empty($unit['bathrooms'])): ?><p><strong>Bathrooms:</strong> <?php echo number_format($unit['bathrooms'], 1); ?></p><?php endif; ?>
        <?php if (!empty($unit['square_footage'])): ?><p><strong>Square Feet:</strong> <?php echo number_format($unit['square_footage']); ?></p><?php endif; ?>
    </div>
</div>

<div class="section">
    <h2>3. LEASE TERM</h2>
    <div class="box">
        <p><strong>Start Date:</strong> <?php echo date('F j, Y', strtotime($lease['start_date'])); ?></p>
        <p><strong>End Date:</strong> <?php echo date('F j, Y', strtotime($lease['end_date'])); ?></p>
        <p><strong>Type:</strong> <?php echo $lease['is_month_to_month'] ? 'Month-to-Month' : 'Fixed Term'; ?></p>
    </div>
</div>

<div class="section">
    <h2>4. RENT AND DEPOSITS</h2>
    <div class="box">
        <p><strong>Monthly Rent:</strong> $<?php echo number_format($lease['rent_amount'], 2); ?></p>
        <p><strong>Security Deposit:</strong> $<?php echo number_format($lease['deposit_amount'] ?? 0, 2); ?></p>
        <p><strong>Due Date:</strong> <?php echo intval($lease['billing_day'] ?? 1); ?> of each month</p>
    </div>
</div>

<div class="section">
    <h2>5. TERMS AND CONDITIONS</h2>
    <ol>
        <li>Rent is due on the <?php echo intval($lease['billing_day'] ?? 1); ?>th of each month.</li>
        <li>Security deposit will be returned within 30 days of lease termination, less deductions.</li>
        <li>Tenant agrees to maintain the property in good condition.</li>
        <li>No alterations without written consent from Landlord.</li>
        <li>Tenant is encouraged to obtain renter's insurance.</li>
    </ol>
</div>

<div class="section signatures">
    <h2>SIGNATURES</h2>
    <div class="sig-grid">
        <div class="sig-box">
            <p>Landlord</p>
            <div class="sig-line"></div>
            <p><?php echo esc_html($organization['name'] ?? ''); ?></p>
            <p>Date: _______________</p>
        </div>
        <?php foreach ($tenants ?: array() as $t): ?>
        <div class="sig-box">
            <p>Tenant</p>
            <div class="sig-line"></div>
            <p><?php echo esc_html($t['first_name'] . ' ' . $t['last_name']); ?></p>
            <p>Date: _______________</p>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="footer">
    <p>Generated <?php echo date('F j, Y'); ?> | Lease ID: <?php echo esc_html($lease['id']); ?></p>
</div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    private function render_receipt_template($data) {
        extract($data);
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Payment Receipt</title>
<?php echo $this->get_styles(); ?>
<style>
.receipt-box { text-align: center; padding: 30px; }
.amount { font-size: 42px; font-weight: 700; color: #10b981; margin: 20px 0; }
.paid-badge { background: #d1fae5; color: #059669; padding: 8px 20px; border-radius: 20px; font-weight: 600; display: inline-block; }
</style>
</head><body>
<div class="header">
    <h1>PAYMENT RECEIPT</h1>
    <p class="org-name"><?php echo esc_html($organization['name'] ?? ''); ?></p>
</div>

<div class="receipt-box">
    <span class="paid-badge">✓ PAID</span>
    <p class="amount">$<?php echo number_format($payment['amount_paid'] ?? $payment['amount'] ?? 0, 2); ?></p>
    <p>Receipt #<?php echo esc_html($payment['payment_number'] ?? $payment['id']); ?></p>
</div>

<div class="section">
    <div class="box">
        <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($payment['paid_at'] ?? $payment['created_at'])); ?></p>
        <p><strong>Type:</strong> <?php echo esc_html(ucfirst($payment['type'] ?? 'Rent')); ?></p>
        <p><strong>Method:</strong> <?php echo esc_html(ucfirst(str_replace('_', ' ', $payment['method'] ?? 'N/A'))); ?></p>
        <?php if ($tenant): ?><p><strong>Tenant:</strong> <?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></p><?php endif; ?>
        <?php if ($unit): ?><p><strong>Property:</strong> <?php echo esc_html($unit['name']); ?></p><?php endif; ?>
    </div>
</div>

<div class="footer">
    <p>Thank you for your payment!</p>
    <p>Generated <?php echo date('F j, Y g:i A'); ?></p>
</div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    private function render_invoice_template($data) {
        extract($data);
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Invoice</title>
<?php echo $this->get_styles(); ?>
<style>
.inv-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
.inv-table th { background: #f3f4f6; padding: 12px; text-align: left; }
.inv-table td { padding: 12px; border-bottom: 1px solid #e5e7eb; }
.total-row { font-size: 18px; font-weight: 700; }
</style>
</head><body>
<div class="header">
    <h1>INVOICE</h1>
    <p><?php echo esc_html($invoice['invoice_number'] ?? 'INV-' . date('Ymd')); ?></p>
</div>

<div class="section">
    <p><strong>From:</strong> <?php echo esc_html($organization['name'] ?? ''); ?></p>
    <?php if ($tenant): ?><p><strong>To:</strong> <?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></p><?php endif; ?>
    <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($invoice['invoice_date'] ?? 'now')); ?></p>
    <p><strong>Due:</strong> <?php echo date('F j, Y', strtotime($invoice['due_date'] ?? '+30 days')); ?></p>
</div>

<table class="inv-table">
    <thead><tr><th>Description</th><th>Period</th><th style="text-align:right">Amount</th></tr></thead>
    <tbody>
    <?php foreach ($invoice['items'] ?? array() as $item): ?>
    <tr>
        <td><?php echo esc_html($item['description']); ?></td>
        <td><?php echo esc_html($item['period'] ?? ''); ?></td>
        <td style="text-align:right">$<?php echo number_format($item['amount'], 2); ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div style="text-align: right;">
    <p class="total-row">Total: $<?php echo number_format($invoice['total'] ?? 0, 2); ?></p>
</div>

<div class="footer"><p>Thank you for your business!</p></div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    private function render_work_order_template($data) {
        extract($data);
        $colors = array('new' => '#3b82f6', 'in_progress' => '#f59e0b', 'completed' => '#10b981', 'cancelled' => '#6b7280');
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Work Order</title>
<?php echo $this->get_styles(); ?>
</head><body>
<div class="header">
    <h1>WORK ORDER #<?php echo esc_html($work_order['id']); ?></h1>
    <p class="org-name"><?php echo esc_html($organization['name'] ?? ''); ?></p>
</div>

<div style="margin-bottom: 20px;">
    <span style="background: <?php echo $colors[$work_order['status']] ?? '#6b7280'; ?>; color: white; padding: 6px 16px; border-radius: 20px; font-size: 12px; font-weight: 600;">
        <?php echo esc_html(strtoupper($work_order['status'])); ?>
    </span>
    <?php if (!empty($work_order['priority'])): ?>
    <span style="background: <?php echo $work_order['priority'] === 'urgent' ? '#ef4444' : '#f59e0b'; ?>; color: white; padding: 6px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; margin-left: 8px;">
        <?php echo esc_html(strtoupper($work_order['priority'])); ?>
    </span>
    <?php endif; ?>
</div>

<div class="section">
    <h2>Details</h2>
    <div class="box">
        <p><strong>Title:</strong> <?php echo esc_html($work_order['title']); ?></p>
        <p><strong>Category:</strong> <?php echo esc_html(ucfirst($work_order['category'] ?? 'General')); ?></p>
        <p><strong>Submitted:</strong> <?php echo date('F j, Y g:i A', strtotime($work_order['created_at'])); ?></p>
        <?php if ($tenant): ?><p><strong>Reported By:</strong> <?php echo esc_html($tenant['first_name'] . ' ' . $tenant['last_name']); ?></p><?php endif; ?>
    </div>
</div>

<?php if ($unit || $building): ?>
<div class="section">
    <h2>Location</h2>
    <div class="box">
        <?php if ($unit): ?><p><strong>Unit:</strong> <?php echo esc_html($unit['name']); ?></p><?php endif; ?>
        <?php if ($building): ?>
        <p><strong>Building:</strong> <?php echo esc_html($building['name']); ?></p>
        <p><strong>Address:</strong> <?php echo esc_html($building['derived_address'] ?? ''); ?></p>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="section">
    <h2>Description</h2>
    <p><?php echo nl2br(esc_html($work_order['description'] ?? '')); ?></p>
</div>

<?php if (!empty($notes)): ?>
<div class="section">
    <h2>Activity Log</h2>
    <?php foreach ($notes as $note): ?>
    <div class="box" style="margin-bottom: 10px;">
        <p style="color: #6b7280; font-size: 12px; margin-bottom: 5px;">
            <?php echo esc_html($note['author_name'] ?? 'System'); ?> - <?php echo date('M j, Y g:i A', strtotime($note['created_at'])); ?>
        </p>
        <p style="margin: 0;"><?php echo nl2br(esc_html($note['note'])); ?></p>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="footer"><p>Generated <?php echo date('F j, Y g:i A'); ?></p></div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    private function render_report_template($data) {
        extract($data);
        $occupancy = $stats['total_units'] > 0 ? round(($stats['occupied_units'] / $stats['total_units']) * 100, 1) : 0;
        $collection = $stats['monthly_revenue'] > 0 ? round(($stats['collected_this_month'] / $stats['monthly_revenue']) * 100, 1) : 0;
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Property Report</title>
<?php echo $this->get_styles(); ?>
<style>
.stats { display: flex; flex-wrap: wrap; gap: 15px; margin: 20px 0; }
.stat { background: #f9fafb; border-radius: 12px; padding: 20px; text-align: center; flex: 1; min-width: 120px; }
.stat-val { font-size: 28px; font-weight: 700; color: #111827; }
.stat-lbl { font-size: 12px; color: #6b7280; margin-top: 5px; }
</style>
</head><body>
<div class="header">
    <h1>PROPERTY REPORT</h1>
    <p class="org-name"><?php echo esc_html($organization['name'] ?? ''); ?></p>
    <p style="color: #6b7280;"><?php echo date('F j, Y'); ?></p>
</div>

<div class="section">
    <h2>Portfolio Overview</h2>
    <div class="stats">
        <div class="stat"><div class="stat-val"><?php echo intval($stats['total_buildings']); ?></div><div class="stat-lbl">Buildings</div></div>
        <div class="stat"><div class="stat-val"><?php echo intval($stats['total_units']); ?></div><div class="stat-lbl">Units</div></div>
        <div class="stat"><div class="stat-val"><?php echo $occupancy; ?>%</div><div class="stat-lbl">Occupancy</div></div>
        <div class="stat"><div class="stat-val"><?php echo intval($stats['total_tenants']); ?></div><div class="stat-lbl">Tenants</div></div>
    </div>
</div>

<div class="section">
    <h2>Financial Summary</h2>
    <div class="box">
        <p><strong>Monthly Potential:</strong> $<?php echo number_format($stats['monthly_revenue']); ?></p>
        <p><strong>Collected This Month:</strong> $<?php echo number_format($stats['collected_this_month']); ?></p>
        <p><strong>Collection Rate:</strong> <?php echo $collection; ?>%</p>
        <p><strong>Active Leases:</strong> <?php echo intval($stats['active_leases']); ?></p>
    </div>
</div>

<div class="section">
    <h2>Operations</h2>
    <div class="box">
        <p><strong>Open Maintenance:</strong> <?php echo intval($stats['open_maintenance']); ?></p>
    </div>
</div>

<?php if (!empty($buildings)): ?>
<div class="section">
    <h2>Buildings</h2>
    <table style="width: 100%; border-collapse: collapse;">
        <thead><tr style="background: #f3f4f6;"><th style="padding: 10px; text-align: left;">Building</th><th style="padding: 10px;">Units</th><th style="padding: 10px;">Status</th></tr></thead>
        <tbody>
        <?php foreach ($buildings as $b): ?>
        <tr><td style="padding: 10px; border-bottom: 1px solid #e5e7eb;"><?php echo esc_html($b['name']); ?></td>
            <td style="padding: 10px; text-align: center; border-bottom: 1px solid #e5e7eb;"><?php echo intval($b['unit_count'] ?? 0); ?></td>
            <td style="padding: 10px; text-align: center; border-bottom: 1px solid #e5e7eb;"><?php echo esc_html(ucfirst($b['status'] ?? 'active')); ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="footer"><p>Generated <?php echo date('F j, Y g:i A'); ?></p></div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    private function render_flyer_template($data) {
        extract($data);
        $amenities = is_array($unit['amenities'] ?? null) ? $unit['amenities'] : json_decode($unit['amenities'] ?? '[]', true);
        ob_start();
        ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Property Flyer</title>
<style>
@page { margin: 0; size: letter; }
body { margin: 0; padding: 30px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); min-height: 100vh; }
.flyer { background: white; border-radius: 20px; overflow: hidden; }
.flyer-head { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; padding: 40px; text-align: center; }
.flyer-title { font-size: 28px; font-weight: 700; margin: 0; }
.flyer-sub { font-size: 16px; opacity: 0.9; margin-top: 10px; }
.flyer-body { padding: 30px; color: #111827; }
.price { background: #10b981; color: white; font-size: 24px; font-weight: 700; padding: 12px 30px; border-radius: 50px; display: inline-block; margin-bottom: 25px; }
.features { display: flex; gap: 20px; margin: 25px 0; justify-content: center; }
.feature { text-align: center; padding: 15px 25px; background: #f9fafb; border-radius: 12px; }
.feature-val { font-size: 22px; font-weight: 700; color: #6366f1; }
.feature-lbl { font-size: 11px; color: #6b7280; }
.amenities { display: flex; flex-wrap: wrap; gap: 8px; margin: 20px 0; justify-content: center; }
.amenity { background: #f3f4f6; padding: 6px 14px; border-radius: 20px; font-size: 12px; }
.qr { text-align: center; padding: 25px; background: #f9fafb; margin-top: 25px; border-radius: 12px; }
.qr img { width: 100px; height: 100px; }
.contact { text-align: center; padding: 25px; background: #111827; color: white; }
</style>
</head><body>
<div class="flyer">
    <div class="flyer-head">
        <h1 class="flyer-title"><?php echo esc_html($unit['name']); ?></h1>
        <p class="flyer-sub"><?php echo esc_html($building['name'] ?? ''); ?> • <?php echo esc_html($building['derived_address'] ?? ''); ?></p>
    </div>
    <div class="flyer-body">
        <div style="text-align: center;">
            <span class="price">$<?php echo number_format($unit['rent_amount']); ?>/mo</span>
        </div>
        
        <div class="features">
            <?php if (!empty($unit['bedrooms'])): ?><div class="feature"><div class="feature-val"><?php echo intval($unit['bedrooms']); ?></div><div class="feature-lbl">Beds</div></div><?php endif; ?>
            <?php if (!empty($unit['bathrooms'])): ?><div class="feature"><div class="feature-val"><?php echo number_format($unit['bathrooms'], 1); ?></div><div class="feature-lbl">Baths</div></div><?php endif; ?>
            <?php if (!empty($unit['square_footage'])): ?><div class="feature"><div class="feature-val"><?php echo number_format($unit['square_footage']); ?></div><div class="feature-lbl">Sq Ft</div></div><?php endif; ?>
        </div>
        
        <?php if (!empty($unit['description'])): ?>
        <p style="text-align: center; line-height: 1.6;"><?php echo esc_html(substr($unit['description'], 0, 250)); ?><?php echo strlen($unit['description']) > 250 ? '...' : ''; ?></p>
        <?php endif; ?>
        
        <?php if (!empty($amenities)): ?>
        <div class="amenities">
            <?php foreach (array_slice($amenities, 0, 6) as $a): ?><span class="amenity">✓ <?php echo esc_html($a); ?></span><?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($qr_code)): ?>
        <div class="qr">
            <img src="<?php echo esc_url($qr_code); ?>" alt="QR">
            <p style="margin: 10px 0 0; font-size: 13px; color: #6b7280;">Scan to view listing</p>
        </div>
        <?php endif; ?>
    </div>
    <div class="contact">
        <strong><?php echo esc_html($organization['name'] ?? ''); ?></strong><br>
        <?php if (!empty($organization['contact_phone'])): ?>📞 <?php echo esc_html($organization['contact_phone']); ?><?php endif; ?>
        <?php if (!empty($organization['contact_email'])): ?> &nbsp; ✉ <?php echo esc_html($organization['contact_email']); ?><?php endif; ?>
    </div>
</div>
</body></html>
        <?php
        return ob_get_clean();
    }
    
    // ==========================================
    // UTILITIES
    // ==========================================
    
    private function get_styles() {
        return '<style>
@page { margin: 40px 50px; }
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; line-height: 1.5; color: #374151; margin: 0; padding: 20px; }
h1 { font-size: 24px; font-weight: 700; color: #111827; margin: 0 0 10px; }
h2 { font-size: 16px; font-weight: 600; color: #111827; margin: 20px 0 10px; border-bottom: 2px solid #e5e7eb; padding-bottom: 5px; }
p { margin: 0 0 8px; }
.header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #6366f1; }
.org-name { font-size: 14px; color: #6b7280; }
.section { margin-bottom: 20px; }
.box { background: #f9fafb; padding: 15px 20px; border-radius: 8px; border: 1px solid #e5e7eb; }
ol { padding-left: 20px; } ol li { margin-bottom: 8px; }
.signatures { margin-top: 40px; }
.sig-grid { display: flex; gap: 30px; flex-wrap: wrap; margin-top: 20px; }
.sig-box { flex: 1; min-width: 200px; text-align: center; }
.sig-line { border-bottom: 1px solid #374151; height: 40px; margin: 10px 0; }
.footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 11px; color: #9ca3af; }
</style>';
    }
    
    private function save_pdf($html, $filename, $org = null) {
        $upload_dir = wp_upload_dir();
        $pdf_dir = $upload_dir['basedir'] . '/rental-gates/pdfs';
        
        if (!file_exists($pdf_dir)) {
            wp_mkdir_p($pdf_dir);
        }
        
        $file_path = $pdf_dir . '/' . $filename;
        $file_url = $upload_dir['baseurl'] . '/rental-gates/pdfs/' . $filename;
        
        file_put_contents($file_path, $html);
        
        return array(
            'success' => true,
            'filename' => str_replace('.html', '.pdf', $filename),
            'url' => $file_url,
            'path' => $file_path,
            'content' => $html,
            'message' => __('Document generated. Use browser print (Ctrl+P) to save as PDF.', 'rental-gates'),
        );
    }
    
    public static function get_download_url($type, $id) {
        return add_query_arg(array(
            'rg_pdf' => $type,
            'id' => $id,
            'nonce' => wp_create_nonce('rg_pdf_' . $type . '_' . $id),
        ), home_url('/'));
    }
}

function rental_gates_pdf() {
    return Rental_Gates_PDF::get_instance();
}
