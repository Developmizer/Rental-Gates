<?php
/**
 * Rental Gates User Restrictions Class
 * Handles WordPress admin bar, redirects, and user restrictions
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_User_Restrictions {
    
    /**
     * Constructor
     */
    public function __construct() {
        // Hide admin bar for non-admin Rental Gates users
        add_action('after_setup_theme', array($this, 'maybe_hide_admin_bar'));
        
        // Redirect from wp-admin
        add_action('admin_init', array($this, 'maybe_redirect_from_admin'));
        
        // Redirect from wp-login.php
        add_action('login_init', array($this, 'maybe_redirect_login'));
        
        // After login redirect
        add_filter('login_redirect', array($this, 'login_redirect'), 10, 3);
        
        // After logout redirect
        add_action('wp_logout', array($this, 'logout_redirect'));
        
        // Prevent profile access
        add_action('load-profile.php', array($this, 'prevent_profile_access'));
        
        // Remove unnecessary dashboard widgets
        add_action('wp_dashboard_setup', array($this, 'remove_dashboard_widgets'), 99);
    }
    
    /**
     * Hide admin bar for Rental Gates users (except site admin)
     */
    public function maybe_hide_admin_bar() {
        if (!is_user_logged_in()) {
            return;
        }
        
        // Keep admin bar for WordPress admins and Site Admins
        if (current_user_can('manage_options') || Rental_Gates_Roles::is_site_admin()) {
            return;
        }
        
        // Hide for all other Rental Gates users
        if (Rental_Gates_Roles::is_rental_gates_user()) {
            show_admin_bar(false);
        }
    }
    
    /**
     * Redirect Rental Gates users from wp-admin
     */
    public function maybe_redirect_from_admin() {
        // Allow AJAX requests
        if (wp_doing_ajax()) {
            return;
        }
        
        // Allow cron
        if (defined('DOING_CRON') && DOING_CRON) {
            return;
        }
        
        if (!is_user_logged_in()) {
            return;
        }
        
        // Allow WordPress admins
        if (current_user_can('manage_options')) {
            return;
        }
        
        // Allow Site Admins
        if (Rental_Gates_Roles::is_site_admin()) {
            return;
        }
        
        // Redirect Rental Gates users to their dashboard
        if (Rental_Gates_Roles::is_rental_gates_user()) {
            $redirect_url = Rental_Gates_Roles::get_dashboard_url();
            wp_safe_redirect($redirect_url);
            exit;
        }
    }
    
    /**
     * Maybe redirect from wp-login.php
     */
    public function maybe_redirect_login() {
        // Allow logout action
        if (isset($_GET['action']) && $_GET['action'] === 'logout') {
            return;
        }
        
        // Allow password reset
        if (isset($_GET['action']) && in_array($_GET['action'], array('lostpassword', 'rp', 'resetpass'))) {
            return;
        }
        
        // Check if coming from Rental Gates
        $redirect_to = isset($_REQUEST['redirect_to']) ? $_REQUEST['redirect_to'] : '';
        if (strpos($redirect_to, 'rental-gates') !== false) {
            wp_redirect(home_url('/rental-gates/login?redirect_to=' . urlencode($redirect_to)));
            exit;
        }
        
        // If user is already logged in
        if (is_user_logged_in()) {
            // If they're a Rental Gates user, redirect to their dashboard
            if (Rental_Gates_Roles::is_rental_gates_user()) {
                $redirect_url = Rental_Gates_Roles::get_dashboard_url();
                wp_safe_redirect($redirect_url);
                exit;
            }
        }
    }
    
    /**
     * Custom login redirect
     */
    public function login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (is_wp_error($user)) {
            return $redirect_to;
        }
        
        // If user is a Rental Gates user
        if (Rental_Gates_Roles::is_rental_gates_user($user->ID)) {
            // If they requested a specific Rental Gates page, honor it
            if (!empty($requested_redirect_to) && strpos($requested_redirect_to, 'rental-gates') !== false) {
                return $requested_redirect_to;
            }
            
            // Otherwise redirect to their dashboard
            return Rental_Gates_Roles::get_dashboard_url($user->ID);
        }
        
        return $redirect_to;
    }
    
    /**
     * Redirect after logout
     */
    public function logout_redirect() {
        // Check if user was a Rental Gates user
        // Since they're logged out, we can't check roles
        // Check if referer was a Rental Gates page
        $referer = wp_get_referer();
        
        if ($referer && strpos($referer, 'rental-gates') !== false) {
            wp_redirect(home_url('/rental-gates/login?logged_out=1'));
            exit;
        }
    }
    
    /**
     * Prevent profile.php access for Rental Gates users
     */
    public function prevent_profile_access() {
        if (!is_user_logged_in()) {
            return;
        }
        
        if (current_user_can('manage_options')) {
            return;
        }
        
        if (Rental_Gates_Roles::is_site_admin()) {
            return;
        }
        
        if (Rental_Gates_Roles::is_rental_gates_user()) {
            $redirect_url = Rental_Gates_Roles::get_dashboard_url();
            wp_safe_redirect($redirect_url . '/profile');
            exit;
        }
    }
    
    /**
     * Remove dashboard widgets for restricted users
     */
    public function remove_dashboard_widgets() {
        if (!is_user_logged_in()) {
            return;
        }
        
        if (current_user_can('manage_options')) {
            return;
        }
        
        // Remove all default widgets for Rental Gates users who somehow access admin
        if (Rental_Gates_Roles::is_rental_gates_user()) {
            global $wp_meta_boxes;
            
            $wp_meta_boxes['dashboard'] = array();
        }
    }
    
    /**
     * Check if current request is a Rental Gates page
     */
    public static function is_rental_gates_page() {
        // Check query var
        if (get_query_var('rental_gates_page')) {
            return true;
        }
        
        // Check URL
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        return strpos($request_uri, '/rental-gates/') !== false;
    }
    
    /**
     * Get appropriate redirect for user
     */
    public static function get_redirect_url($user_id = null) {
        return Rental_Gates_Roles::get_dashboard_url($user_id);
    }
}
