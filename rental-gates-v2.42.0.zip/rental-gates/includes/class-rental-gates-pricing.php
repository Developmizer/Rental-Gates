<?php
/**
 * Rental Gates Pricing Helper
 * 
 * Centralized pricing and discount calculations.
 * Used across frontend displays, checkout, and invoices.
 * 
 * @package RentalGates
 * @since 2.13.0
 */

if (!defined('ABSPATH')) exit;

class Rental_Gates_Pricing {
    
    /**
     * Singleton instance
     */
    private static $instance = null;
    
    /**
     * Cached discount settings
     */
    private $discount = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_discount();
    }
    
    /**
     * Load discount settings
     */
    private function load_discount() {
        $this->discount = get_option('rental_gates_discount', array(
            'enabled' => false,
            'type' => 'percentage',
            'value' => 0,
            'applies_to_plans' => array(),
            'applies_to_period' => 'both',
            'label' => '',
            'badge_text' => '',
            'start_date' => '',
            'end_date' => '',
        ));
    }
    
    /**
     * Reload discount settings (useful after admin saves)
     */
    public function reload() {
        $this->load_discount();
    }
    
    /**
     * Check if discount is currently active
     * 
     * @return bool
     */
    public function is_discount_active() {
        if (empty($this->discount['enabled'])) {
            return false;
        }
        
        // Check date range if specified
        $now = current_time('Y-m-d');
        
        if (!empty($this->discount['start_date']) && $now < $this->discount['start_date']) {
            return false;
        }
        
        if (!empty($this->discount['end_date']) && $now > $this->discount['end_date']) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if discount applies to a specific plan and period
     * 
     * @param string $plan_id Plan ID
     * @param string $period 'monthly' or 'yearly'
     * @return bool
     */
    public function discount_applies($plan_id, $period = 'monthly') {
        if (!$this->is_discount_active()) {
            return false;
        }
        
        // Check if plan is in the list (empty means all plans)
        $applies_to_plans = (array)($this->discount['applies_to_plans'] ?? array());
        if (!empty($applies_to_plans) && !in_array($plan_id, $applies_to_plans)) {
            return false;
        }
        
        // Check period
        $applies_to_period = $this->discount['applies_to_period'] ?? 'both';
        if ($applies_to_period !== 'both' && $applies_to_period !== $period) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Calculate discounted price
     * 
     * @param float $original_price Original price
     * @param string $plan_id Plan ID
     * @param string $period 'monthly' or 'yearly'
     * @return float Discounted price
     */
    public function calculate_price($original_price, $plan_id, $period = 'monthly') {
        if (!$this->discount_applies($plan_id, $period)) {
            return $original_price;
        }
        
        $type = $this->discount['type'] ?? 'percentage';
        $value = floatval($this->discount['value'] ?? 0);
        
        if ($value <= 0) {
            return $original_price;
        }
        
        if ($type === 'percentage') {
            // Percentage discount
            $discount_amount = $original_price * ($value / 100);
            return max(0, $original_price - $discount_amount);
        } else {
            // Fixed amount discount
            return max(0, $original_price - $value);
        }
    }
    
    /**
     * Get discount amount for a price
     * 
     * @param float $original_price Original price
     * @param string $plan_id Plan ID
     * @param string $period 'monthly' or 'yearly'
     * @return float Discount amount
     */
    public function get_discount_amount($original_price, $plan_id, $period = 'monthly') {
        $discounted = $this->calculate_price($original_price, $plan_id, $period);
        return $original_price - $discounted;
    }
    
    /**
     * Get discount percentage for a price
     * 
     * @param float $original_price Original price
     * @param string $plan_id Plan ID
     * @param string $period 'monthly' or 'yearly'
     * @return float Discount percentage
     */
    public function get_discount_percentage($original_price, $plan_id, $period = 'monthly') {
        if ($original_price <= 0) {
            return 0;
        }
        
        $discount_amount = $this->get_discount_amount($original_price, $plan_id, $period);
        return round(($discount_amount / $original_price) * 100, 1);
    }
    
    /**
     * Get full pricing info for a plan
     * 
     * Pricing Data Structure:
     * - price_monthly: The monthly subscription price (e.g., $29)
     * - price_yearly: The TOTAL annual price when paying yearly (e.g., $278 for full year)
     * 
     * Display Logic:
     * - Monthly billing shows: $29/mo
     * - Yearly billing shows: $23/mo (which is $278/12, billed annually)
     * - Savings badge shows: Save 20% (comparing yearly total vs monthly*12)
     * 
     * @param array $plan Plan data
     * @return array Pricing info with original, discounted, and savings
     */
    public function get_plan_pricing($plan) {
        $plan_id = $plan['id'] ?? '';
        $is_free = !empty($plan['is_free']) || empty($plan['price_monthly']);
        
        $monthly_original = floatval($plan['price_monthly'] ?? 0);
        $yearly_original = floatval($plan['price_yearly'] ?? 0);
        
        // If yearly price is not set, calculate as 80% of monthly * 12 (20% discount)
        if ($yearly_original <= 0 && $monthly_original > 0) {
            $yearly_original = round($monthly_original * 12 * 0.8, 0);
        }
        
        // Calculate yearly as monthly equivalent for display (e.g., $278/12 = $23)
        $yearly_monthly_equivalent = $yearly_original > 0 ? round($yearly_original / 12, 0) : 0;
        
        // Calculate discounted prices (promo discounts, if any)
        $monthly_discounted = $this->calculate_price($monthly_original, $plan_id, 'monthly');
        $yearly_discounted = $this->calculate_price($yearly_original, $plan_id, 'yearly');
        $yearly_monthly_discounted = $yearly_discounted > 0 ? round($yearly_discounted / 12, 0) : 0;
        
        // Calculate promo discount savings
        $monthly_savings = $monthly_original - $monthly_discounted;
        $yearly_savings = $yearly_original - $yearly_discounted;
        
        // Calculate yearly vs monthly savings (inherent yearly discount, not promo)
        // This is the "Save 20%" displayed on yearly billing toggle
        $yearly_plan_savings = ($monthly_original * 12) - $yearly_original;
        $yearly_plan_savings_pct = $monthly_original > 0 && $yearly_original > 0 
            ? round((1 - ($yearly_original / ($monthly_original * 12))) * 100) 
            : 0;
        
        return array(
            'is_free' => $is_free,
            
            // Monthly prices (what user pays per month on monthly billing)
            'monthly_original' => $monthly_original,
            'monthly_discounted' => $monthly_discounted,
            'monthly_savings' => $monthly_savings,
            'monthly_has_discount' => $monthly_savings > 0,
            
            // Yearly prices (total annual payment)
            'yearly_original' => $yearly_original,
            'yearly_discounted' => $yearly_discounted,
            'yearly_savings' => $yearly_savings,
            'yearly_has_discount' => $yearly_savings > 0,
            
            // Yearly as monthly equivalent (for display: "$23/mo billed yearly")
            'yearly_monthly_original' => $yearly_monthly_equivalent,
            'yearly_monthly_discounted' => $yearly_monthly_discounted,
            
            // Yearly vs monthly savings (the inherent 20% yearly discount)
            'yearly_plan_savings' => $yearly_plan_savings,
            'yearly_plan_savings_pct' => $yearly_plan_savings_pct,
            
            // Promo discount info
            'has_any_discount' => $monthly_savings > 0 || $yearly_savings > 0,
            'discount_label' => $this->discount['label'] ?? '',
            'discount_badge' => $this->discount['badge_text'] ?? '',
        );
    }
    
    /**
     * Get discount settings
     * 
     * @return array
     */
    public function get_discount_settings() {
        return $this->discount;
    }
    
    /**
     * Check if a plan should be visible on public pricing pages
     * 
     * @param array $plan Plan data
     * @return bool
     */
    public static function is_plan_visible($plan) {
        // Check is_active (default to true if not set)
        $is_active = isset($plan['is_active']) ? (bool)$plan['is_active'] : true;
        if (!$is_active) {
            return false;
        }
        
        // Check is_hidden
        if (!empty($plan['is_hidden'])) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if a plan is available for new subscriptions
     * 
     * @param array $plan Plan data
     * @return bool
     */
    public static function is_plan_available($plan) {
        // Only check is_active for availability
        return isset($plan['is_active']) ? (bool)$plan['is_active'] : true;
    }
    
    /**
     * Filter plans to only visible ones
     * 
     * @param array $plans Array of plans
     * @param string|null $current_plan_id Current user's plan (always show even if hidden)
     * @return array Filtered plans
     */
    public static function filter_visible_plans($plans, $current_plan_id = null) {
        return array_filter($plans, function($plan, $plan_id) use ($current_plan_id) {
            // Always show current plan
            if ($current_plan_id && $plan_id === $current_plan_id) {
                return true;
            }
            return self::is_plan_visible($plan);
        }, ARRAY_FILTER_USE_BOTH);
    }
    
    /**
     * Ensure plan has all required fields with defaults
     * 
     * @param array $plan Plan data
     * @return array Plan with defaults applied
     */
    public static function normalize_plan($plan) {
        return array_merge(array(
            'id' => '',
            'name' => '',
            'description' => '',
            'is_free' => false,
            'is_active' => true,
            'is_hidden' => false,
            'price_monthly' => 0,
            'price_yearly' => 0,
            'sort_order' => 0,
            'is_featured' => false,
            'limits' => array(),
            'modules' => array(),
            'custom_features' => array(),
            'cta_text' => 'Get Started',
            'cta_style' => 'outline',
        ), $plan);
    }
    
    /**
     * Format price for display
     * 
     * @param float $price Price value
     * @param bool $show_decimals Show decimal places
     * @return string Formatted price
     */
    public static function format_price($price, $show_decimals = false) {
        if ($show_decimals || floor($price) != $price) {
            return '$' . number_format($price, 2);
        }
        return '$' . number_format($price, 0);
    }
    
    /**
     * Get Stripe price in cents
     * 
     * @param float $price Price in dollars
     * @return int Price in cents
     */
    public static function to_cents($price) {
        return intval(round($price * 100));
    }
}

// Initialize pricing helper
function rental_gates_pricing() {
    return Rental_Gates_Pricing::get_instance();
}
