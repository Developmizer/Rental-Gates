<?php
/**
 * Rental Gates Form Helper
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Form_Helper {
    
    public static function sanitize_form_data($data, $fields) {
        $sanitized = array();
        
        foreach ($fields as $field => $type) {
            if (!isset($data[$field])) continue;
            
            switch ($type) {
                case 'email':
                    $sanitized[$field] = sanitize_email($data[$field]);
                    break;
                case 'phone':
                    $sanitized[$field] = Rental_Gates_Security::sanitize_phone($data[$field]);
                    break;
                case 'int':
                    $sanitized[$field] = intval($data[$field]);
                    break;
                case 'float':
                    $sanitized[$field] = floatval($data[$field]);
                    break;
                case 'amount':
                    $sanitized[$field] = Rental_Gates_Security::sanitize_amount($data[$field]);
                    break;
                case 'date':
                    $sanitized[$field] = Rental_Gates_Security::sanitize_date($data[$field]);
                    break;
                case 'html':
                    $sanitized[$field] = wp_kses_post($data[$field]);
                    break;
                case 'array':
                    $sanitized[$field] = is_array($data[$field]) ? $data[$field] : array();
                    break;
                default:
                    $sanitized[$field] = sanitize_text_field($data[$field]);
            }
        }
        
        return $sanitized;
    }
}
