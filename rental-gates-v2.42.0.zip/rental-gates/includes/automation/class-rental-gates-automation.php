<?php
/**
 * Rental Gates Automation Engine
 * 
 * Handles automated tasks like rent reminders, lease expiration alerts,
 * late fee generation, and scheduled notifications.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Automation {
    
    /**
     * Initialize automation hooks
     */
    public function __construct() {
        // Schedule cron events on init
        add_action('init', array($this, 'schedule_events'));
        
        // Cron event handlers
        add_action('rental_gates_daily_tasks', array($this, 'run_daily_tasks'));
        add_action('rental_gates_hourly_tasks', array($this, 'run_hourly_tasks'));
        
        // Hook into plugin events
        add_action('rental_gates_lease_activated', array($this, 'on_lease_activated'), 10, 2);
        add_action('rental_gates_lease_terminated', array($this, 'on_lease_terminated'), 10, 2);
        add_action('rental_gates_payment_received', array($this, 'on_payment_received'), 10, 2);
        add_action('rental_gates_maintenance_created', array($this, 'on_maintenance_created'), 10, 2);
        add_action('rental_gates_maintenance_updated', array($this, 'on_maintenance_updated'), 10, 3);
        add_action('rental_gates_application_submitted', array($this, 'on_application_submitted'), 10, 2);
    }
    
    /**
     * Schedule cron events
     */
    public function schedule_events() {
        // Daily tasks at 8 AM
        if (!wp_next_scheduled('rental_gates_daily_tasks')) {
            $timestamp = strtotime('tomorrow 8:00 AM');
            wp_schedule_event($timestamp, 'daily', 'rental_gates_daily_tasks');
        }
        
        // Hourly tasks
        if (!wp_next_scheduled('rental_gates_hourly_tasks')) {
            wp_schedule_event(time(), 'hourly', 'rental_gates_hourly_tasks');
        }
    }
    
    /**
     * Unschedule events (on deactivation)
     */
    public static function unschedule_events() {
        wp_clear_scheduled_hook('rental_gates_daily_tasks');
        wp_clear_scheduled_hook('rental_gates_hourly_tasks');
    }
    
    /**
     * Run daily automated tasks
     */
    public function run_daily_tasks() {
        // Process for each organization
        $organizations = $this->get_all_organizations();
        
        foreach ($organizations as $org_id) {
            $settings = $this->get_automation_settings($org_id);
            
            // Skip if automation is disabled
            if (empty($settings['enabled'])) {
                continue;
            }
            
            // Auto-generate rent payments (on 1st of month or configured day)
            if (!empty($settings['auto_generate_rent'])) {
                $this->auto_generate_rent_payments($org_id, $settings);
            }
            
            // Rent payment reminders
            if (!empty($settings['rent_reminder_enabled'])) {
                $this->process_rent_reminders($org_id, $settings);
            }
            
            // Overdue payment alerts
            if (!empty($settings['overdue_alerts_enabled'])) {
                $this->process_overdue_alerts($org_id, $settings);
            }
            
            // Late fee generation
            if (!empty($settings['late_fees_enabled'])) {
                $this->process_late_fees($org_id, $settings);
            }
            
            // Lease expiration alerts
            if (!empty($settings['lease_expiry_alerts_enabled'])) {
                $this->process_lease_expiry_alerts($org_id, $settings);
            }
            
            // Move-in/Move-out reminders
            if (!empty($settings['move_reminders_enabled'])) {
                $this->process_move_reminders($org_id, $settings);
            }
        }
        
        // Cleanup old notifications
        Rental_Gates_Notification::cleanup(90);
    }
    
    /**
     * Auto-generate rent payment records for the current month
     */
    private function auto_generate_rent_payments($org_id, $settings) {
        // Only run on configured day (default: 1st of month)
        $generate_day = intval($settings['rent_generate_day'] ?? 1);
        
        if (date('j') != $generate_day) {
            return;
        }
        
        // Generate for current month
        $result = Rental_Gates_Payment::generate_monthly_payments($org_id);
        
        if (!is_wp_error($result) && $result['generated'] > 0) {
            error_log("Rental Gates: Auto-generated {$result['generated']} rent payments for org {$org_id}");
        }
    }
    
    /**
     * Run hourly automated tasks
     */
    public function run_hourly_tasks() {
        // Process queued emails
        $this->process_email_queue();
        
        // Process daily digest emails
        $this->process_digest_emails();
    }
    
    /**
     * Process rent payment reminders
     */
    private function process_rent_reminders($org_id, $settings) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $reminder_days = intval($settings['rent_reminder_days'] ?? 3);
        
        // Get active leases with upcoming rent due
        $leases = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, t.id as tenant_id, t.first_name, t.last_name, t.user_id,
                    u.name as unit_name, b.name as building_name
             FROM {$tables['leases']} l
             JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
             JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
             JOIN {$tables['units']} u ON l.unit_id = u.id
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE l.organization_id = %d 
             AND l.status = 'active'
             AND l.billing_day = DAY(DATE_ADD(CURDATE(), INTERVAL %d DAY))",
            $org_id, $reminder_days
        ), ARRAY_A);
        
        foreach ($leases as $lease) {
            // Check if reminder already sent this month
            $already_sent = $this->check_notification_sent(
                $lease['tenant_id'],
                'payment_reminder',
                date('Y-m')
            );
            
            if ($already_sent) continue;
            
            // Check if payment already made this month
            $payment_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['payments']} 
                 WHERE lease_id = %d 
                 AND status = 'succeeded' 
                 AND MONTH(due_date) = MONTH(CURDATE()) 
                 AND YEAR(due_date) = YEAR(CURDATE())",
                $lease['id']
            ));
            
            if ($payment_exists) continue;
            
            // Send reminder
            if ($lease['user_id']) {
                $due_date = date('F j', strtotime("+{$reminder_days} days"));
                
                Rental_Gates_Notification::send(
                    $lease['user_id'],
                    'payment_reminder',
                    __('Rent Payment Reminder', 'rental-gates'),
                    sprintf(
                        __('Your rent payment of $%s for %s is due on %s.', 'rental-gates'),
                        number_format($lease['rent_amount'], 2),
                        $lease['unit_name'],
                        $due_date
                    ),
                    home_url('/rental-gates/tenant/payments'),
                    array(
                        'organization_id' => $org_id,
                        'lease_id' => $lease['id'],
                        'amount' => $lease['rent_amount'],
                        'due_date' => $due_date,
                    )
                );
                
                // Log that reminder was sent
                $this->log_notification_sent($lease['tenant_id'], 'payment_reminder', date('Y-m'));
            }
        }
    }
    
    /**
     * Process overdue payment alerts
     */
    private function process_overdue_alerts($org_id, $settings) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get overdue payments
        $overdue_payments = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, t.first_name, t.last_name, t.user_id,
                    u.name as unit_name, l.id as lease_id
             FROM {$tables['payments']} p
             JOIN {$tables['tenants']} t ON p.tenant_id = t.id
             JOIN {$tables['leases']} l ON p.lease_id = l.id
             JOIN {$tables['units']} u ON l.unit_id = u.id
             WHERE p.organization_id = %d 
             AND p.status = 'pending'
             AND p.due_date < CURDATE()
             AND DATEDIFF(CURDATE(), p.due_date) IN (1, 3, 7, 14, 30)",
            $org_id
        ), ARRAY_A);
        
        foreach ($overdue_payments as $payment) {
            $days_overdue = floor((time() - strtotime($payment['due_date'])) / 86400);
            
            // Check if alert already sent for this overdue milestone
            $alert_key = $payment['id'] . '_' . $days_overdue;
            if ($this->check_notification_sent($payment['tenant_id'], 'payment_overdue', $alert_key)) {
                continue;
            }
            
            if ($payment['user_id']) {
                Rental_Gates_Notification::send(
                    $payment['user_id'],
                    'payment_overdue',
                    __('Payment Overdue', 'rental-gates'),
                    sprintf(
                        __('Your payment of $%s for %s is %d days overdue. Please make payment as soon as possible to avoid additional fees.', 'rental-gates'),
                        number_format($payment['amount'], 2),
                        $payment['unit_name'],
                        $days_overdue
                    ),
                    home_url('/rental-gates/tenant/payments'),
                    array(
                        'organization_id' => $org_id,
                        'payment_id' => $payment['id'],
                        'days_overdue' => $days_overdue,
                    )
                );
                
                $this->log_notification_sent($payment['tenant_id'], 'payment_overdue', $alert_key);
            }
            
            // Also notify property manager
            $this->notify_organization_admins($org_id, 'payment_overdue', 
                sprintf(__('Overdue Payment: %s %s - $%s (%d days)', 'rental-gates'),
                    $payment['first_name'], $payment['last_name'],
                    number_format($payment['amount'], 2), $days_overdue
                ),
                home_url('/rental-gates/tenant/payments/' . $payment['id'])
            );
        }
    }
    
    /**
     * Process late fee generation
     */
    private function process_late_fees($org_id, $settings) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $grace_period = intval($settings['late_fee_grace_days'] ?? 5);
        $late_fee_type = $settings['late_fee_type'] ?? 'fixed';
        $late_fee_amount = floatval($settings['late_fee_amount'] ?? 50);
        $late_fee_percent = floatval($settings['late_fee_percent'] ?? 5);
        
        // Get payments that are past grace period and don't have late fees
        $overdue_payments = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, l.rent_amount
             FROM {$tables['payments']} p
             JOIN {$tables['leases']} l ON p.lease_id = l.id
             WHERE p.organization_id = %d 
             AND p.status = 'pending'
             AND p.due_date < DATE_SUB(CURDATE(), INTERVAL %d DAY)
             AND NOT EXISTS (
                 SELECT 1 FROM {$tables['payments']} lf 
                 WHERE lf.parent_payment_id = p.id 
                 AND lf.type = 'late_fee'
             )",
            $org_id, $grace_period
        ), ARRAY_A);
        
        foreach ($overdue_payments as $payment) {
            // Calculate late fee
            $fee = $late_fee_type === 'percent' 
                ? ($payment['amount'] * $late_fee_percent / 100)
                : $late_fee_amount;
            
            // Create late fee payment record
            $wpdb->insert(
                $tables['payments'],
                array(
                    'organization_id' => $org_id,
                    'lease_id' => $payment['lease_id'],
                    'tenant_id' => $payment['tenant_id'],
                    'parent_payment_id' => $payment['id'],
                    'type' => 'late_fee',
                    'amount' => $fee,
                    'due_date' => current_time('Y-m-d'),
                    'status' => 'pending',
                    'description' => sprintf(__('Late fee for payment due %s', 'rental-gates'), $payment['due_date']),
                    'created_at' => current_time('mysql'),
                ),
                array('%d', '%d', '%d', '%d', '%s', '%f', '%s', '%s', '%s', '%s')
            );
            
            // Notify tenant
            $tenant = Rental_Gates_Tenant::get($payment['tenant_id']);
            if ($tenant && $tenant['user_id']) {
                Rental_Gates_Notification::send(
                    $tenant['user_id'],
                    'late_fee_added',
                    __('Late Fee Added', 'rental-gates'),
                    sprintf(
                        __('A late fee of $%s has been added to your account for the overdue payment.', 'rental-gates'),
                        number_format($fee, 2)
                    ),
                    home_url('/rental-gates/tenant/payments'),
                    array('organization_id' => $org_id)
                );
            }
        }
    }
    
    /**
     * Process lease expiration alerts
     */
    private function process_lease_expiry_alerts($org_id, $settings) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $alert_days = array(90, 60, 30, 14, 7);
        
        foreach ($alert_days as $days) {
            // Get leases expiring in X days
            $leases = $wpdb->get_results($wpdb->prepare(
                "SELECT l.*, t.id as tenant_id, t.first_name, t.last_name, t.user_id,
                        u.name as unit_name, b.name as building_name
                 FROM {$tables['leases']} l
                 JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
                 JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
                 JOIN {$tables['units']} u ON l.unit_id = u.id
                 JOIN {$tables['buildings']} b ON u.building_id = b.id
                 WHERE l.organization_id = %d 
                 AND l.status = 'active'
                 AND l.end_date = DATE_ADD(CURDATE(), INTERVAL %d DAY)",
                $org_id, $days
            ), ARRAY_A);
            
            foreach ($leases as $lease) {
                $alert_key = $lease['id'] . '_' . $days;
                
                if ($this->check_notification_sent($lease['tenant_id'], 'lease_expiring', $alert_key)) {
                    continue;
                }
                
                // Notify tenant
                if ($lease['user_id']) {
                    Rental_Gates_Notification::send(
                        $lease['user_id'],
                        'lease_expiring',
                        __('Lease Expiring Soon', 'rental-gates'),
                        sprintf(
                            __('Your lease for %s expires in %d days on %s. Please contact your property manager about renewal.', 'rental-gates'),
                            $lease['unit_name'],
                            $days,
                            date('F j, Y', strtotime($lease['end_date']))
                        ),
                        home_url('/rental-gates/tenant/lease'),
                        array(
                            'organization_id' => $org_id,
                            'lease_id' => $lease['id'],
                            'days_remaining' => $days,
                        )
                    );
                }
                
                // Notify property manager
                $this->notify_organization_admins($org_id, 'lease_expiring',
                    sprintf(__('Lease Expiring: %s %s - %s (%d days)', 'rental-gates'),
                        $lease['first_name'], $lease['last_name'], $lease['unit_name'], $days
                    ),
                    home_url('/rental-gates/dashboard/leases/' . $lease['id'])
                );
                
                $this->log_notification_sent($lease['tenant_id'], 'lease_expiring', $alert_key);
            }
        }
    }
    
    /**
     * Process move-in/move-out reminders
     */
    private function process_move_reminders($org_id, $settings) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Move-in reminders (3 days before)
        $move_ins = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, t.id as tenant_id, t.first_name, t.user_id,
                    u.name as unit_name
             FROM {$tables['leases']} l
             JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
             JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
             JOIN {$tables['units']} u ON l.unit_id = u.id
             WHERE l.organization_id = %d 
             AND l.status IN ('draft', 'pending', 'active')
             AND l.start_date = DATE_ADD(CURDATE(), INTERVAL 3 DAY)",
            $org_id
        ), ARRAY_A);
        
        foreach ($move_ins as $lease) {
            $alert_key = $lease['id'] . '_move_in';
            if ($this->check_notification_sent($lease['tenant_id'], 'tenant_move_in', $alert_key)) {
                continue;
            }
            
            if ($lease['user_id']) {
                Rental_Gates_Notification::send(
                    $lease['user_id'],
                    'tenant_move_in',
                    __('Move-In Reminder', 'rental-gates'),
                    sprintf(
                        __('Reminder: Your move-in date for %s is in 3 days on %s.', 'rental-gates'),
                        $lease['unit_name'],
                        date('F j, Y', strtotime($lease['start_date']))
                    ),
                    home_url('/rental-gates/tenant'),
                    array('organization_id' => $org_id)
                );
                
                $this->log_notification_sent($lease['tenant_id'], 'tenant_move_in', $alert_key);
            }
        }
        
        // Move-out reminders (7 days before lease end)
        $move_outs = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, t.id as tenant_id, t.first_name, t.user_id,
                    u.name as unit_name
             FROM {$tables['leases']} l
             JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id AND lt.role = 'primary' AND lt.removed_at IS NULL
             JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
             JOIN {$tables['units']} u ON l.unit_id = u.id
             WHERE l.organization_id = %d 
             AND l.status = 'active'
             AND l.end_date = DATE_ADD(CURDATE(), INTERVAL 7 DAY)
             AND l.is_month_to_month = 0",
            $org_id
        ), ARRAY_A);
        
        foreach ($move_outs as $lease) {
            $alert_key = $lease['id'] . '_move_out';
            if ($this->check_notification_sent($lease['tenant_id'], 'tenant_move_out', $alert_key)) {
                continue;
            }
            
            if ($lease['user_id']) {
                Rental_Gates_Notification::send(
                    $lease['user_id'],
                    'tenant_move_out',
                    __('Move-Out Reminder', 'rental-gates'),
                    sprintf(
                        __('Reminder: Your lease for %s ends in 7 days on %s. Please schedule your move-out inspection.', 'rental-gates'),
                        $lease['unit_name'],
                        date('F j, Y', strtotime($lease['end_date']))
                    ),
                    home_url('/rental-gates/tenant'),
                    array('organization_id' => $org_id)
                );
                
                $this->log_notification_sent($lease['tenant_id'], 'tenant_move_out', $alert_key);
            }
        }
    }
    
    /**
     * Process email queue
     */
    private function process_email_queue() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get queued emails that are ready to send
        $queued = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$tables['notifications']} 
             WHERE type = 'queued_email' 
             AND is_read = 0 
             AND created_at <= %s
             LIMIT 50",
            current_time('mysql')
        ), ARRAY_A);
        
        foreach ($queued as $item) {
            $data = json_decode($item['message'], true);
            if ($data && isset($data['to'])) {
                Rental_Gates_Email::send($data['to'], $item['title'], $data['data'] ?? array());
                
                // Mark as processed
                $wpdb->update(
                    $tables['notifications'],
                    array('is_read' => 1, 'read_at' => current_time('mysql')),
                    array('id' => $item['id'])
                );
            }
        }
    }
    
    /**
     * Process digest emails for users who prefer daily/weekly digests
     */
    private function process_digest_emails() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $now = current_time('H');
        
        // Only send digests at 8 AM
        if ($now != 8) return;
        
        $day_of_week = date('w');
        
        // Get users with digest preferences
        $users = $wpdb->get_results(
            "SELECT DISTINCT user_id FROM {$tables['notification_preferences']} 
             WHERE frequency IN ('daily', 'weekly')"
        , ARRAY_A);
        
        foreach ($users as $row) {
            $user_id = $row['user_id'];
            $prefs = Rental_Gates_Notification::get_preferences($user_id);
            
            // Check if user has any daily digests
            $has_daily = false;
            $has_weekly = false;
            foreach ($prefs as $type => $pref) {
                if ($pref['frequency'] === 'daily') $has_daily = true;
                if ($pref['frequency'] === 'weekly') $has_weekly = true;
            }
            
            // Send daily digest
            if ($has_daily) {
                $this->send_digest($user_id, 'daily');
            }
            
            // Send weekly digest on Mondays
            if ($has_weekly && $day_of_week == 1) {
                $this->send_digest($user_id, 'weekly');
            }
        }
    }
    
    /**
     * Send digest email
     */
    private function send_digest($user_id, $frequency) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $interval = $frequency === 'daily' ? '1 DAY' : '7 DAY';
        
        // Get unread notifications from the period
        $notifications = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$tables['notifications']} 
             WHERE user_id = %d 
             AND is_read = 0 
             AND created_at >= DATE_SUB(NOW(), INTERVAL {$interval})
             ORDER BY created_at DESC
             LIMIT 20",
            $user_id
        ), ARRAY_A);
        
        if (empty($notifications)) return;
        
        $user = get_user_by('ID', $user_id);
        if (!$user) return;
        
        // Build digest content
        $items = array();
        foreach ($notifications as $n) {
            $items[] = array(
                'title' => $n['title'],
                'message' => $n['message'],
                'url' => $n['action_url'],
                'time' => human_time_diff(strtotime($n['created_at']), current_time('timestamp')) . ' ago',
            );
        }
        
        Rental_Gates_Email::send($user->user_email, 'generic', array(
            'user_name' => $user->display_name,
            'subject_vars' => array('type' => ucfirst($frequency)),
            'message' => sprintf(
                __('You have %d notifications from the past %s.', 'rental-gates'),
                count($notifications),
                $frequency === 'daily' ? __('24 hours', 'rental-gates') : __('week', 'rental-gates')
            ),
            'items' => $items,
            'action_url' => home_url('/rental-gates/dashboard'),
            'action_text' => __('View Dashboard', 'rental-gates'),
        ));
    }
    
    // ========================================
    // EVENT HANDLERS
    // ========================================
    
    /**
     * Handle lease activated event
     */
    public function on_lease_activated($lease_id, $lease) {
        // Get tenants
        $tenants = Rental_Gates_Lease::get_tenants($lease_id);
        
        foreach ($tenants as $tenant) {
            if (!$tenant['user_id']) continue;
            
            Rental_Gates_Notification::send(
                $tenant['user_id'],
                'lease_activated',
                __('Lease Activated', 'rental-gates'),
                sprintf(
                    __('Your lease for %s has been activated. Welcome to your new home!', 'rental-gates'),
                    $lease['unit_name'] ?? 'your unit'
                ),
                home_url('/rental-gates/tenant'),
                array('organization_id' => $lease['organization_id'], 'lease_id' => $lease_id)
            );
        }
    }
    
    /**
     * Handle lease terminated event
     */
    public function on_lease_terminated($lease_id, $lease) {
        $tenants = Rental_Gates_Lease::get_tenants($lease_id);
        
        foreach ($tenants as $tenant) {
            if (!$tenant['user_id']) continue;
            
            Rental_Gates_Notification::send(
                $tenant['user_id'],
                'lease_terminated',
                __('Lease Terminated', 'rental-gates'),
                __('Your lease has been terminated. Please contact your property manager for details.', 'rental-gates'),
                home_url('/rental-gates/tenant'),
                array('organization_id' => $lease['organization_id'], 'lease_id' => $lease_id)
            );
        }
    }
    
    /**
     * Handle payment received event
     */
    public function on_payment_received($payment_id, $payment) {
        $tenant = Rental_Gates_Tenant::get($payment['tenant_id']);
        if (!$tenant || !$tenant['user_id']) return;
        
        Rental_Gates_Notification::send(
            $tenant['user_id'],
            'payment_received',
            __('Payment Received', 'rental-gates'),
            sprintf(
                __('Thank you! Your payment of $%s has been received.', 'rental-gates'),
                number_format($payment['amount_paid'], 2)
            ),
            home_url('/rental-gates/tenant/payments'),
            array('organization_id' => $payment['organization_id'], 'payment_id' => $payment_id)
        );
        
        // Send email receipt
        Rental_Gates_Email::send_payment_receipt($payment_id);
    }
    
    /**
     * Handle maintenance created event
     */
    public function on_maintenance_created($work_order_id, $work_order) {
        // Notify tenant
        if (!empty($work_order['tenant_id'])) {
            $tenant = Rental_Gates_Tenant::get($work_order['tenant_id']);
            if ($tenant && $tenant['user_id']) {
                Rental_Gates_Notification::send(
                    $tenant['user_id'],
                    'maintenance_created',
                    __('Maintenance Request Submitted', 'rental-gates'),
                    sprintf(
                        __('Your maintenance request "%s" has been submitted and is being reviewed.', 'rental-gates'),
                        $work_order['title']
                    ),
                    home_url('/rental-gates/tenant/maintenance'),
                    array('organization_id' => $work_order['organization_id'], 'work_order_id' => $work_order_id)
                );
            }
        }
        
        // Notify property manager
        $this->notify_organization_admins($work_order['organization_id'], 'maintenance_created',
            sprintf(__('New Maintenance Request: %s', 'rental-gates'), $work_order['title']),
            home_url('/rental-gates/dashboard/maintenance/' . $work_order_id)
        );
    }
    
    /**
     * Handle maintenance updated event
     */
    public function on_maintenance_updated($work_order_id, $work_order, $old_status) {
        if ($work_order['status'] === $old_status) return;
        
        // Notify tenant
        if (!empty($work_order['tenant_id'])) {
            $tenant = Rental_Gates_Tenant::get($work_order['tenant_id']);
            if ($tenant && $tenant['user_id']) {
                $type = $work_order['status'] === 'completed' ? 'maintenance_completed' : 'maintenance_updated';
                $message = $work_order['status'] === 'completed'
                    ? __('Your maintenance request has been completed.', 'rental-gates')
                    : sprintf(__('Your maintenance request status has been updated to: %s', 'rental-gates'), ucfirst($work_order['status']));
                
                Rental_Gates_Notification::send(
                    $tenant['user_id'],
                    $type,
                    __('Maintenance Update', 'rental-gates'),
                    $message,
                    home_url('/rental-gates/tenant/maintenance'),
                    array('organization_id' => $work_order['organization_id'], 'work_order_id' => $work_order_id)
                );
            }
        }
        
        // Notify assigned vendor
        if (!empty($work_order['vendor_id']) && $work_order['status'] === 'assigned') {
            $vendor = Rental_Gates_Vendor::get($work_order['vendor_id']);
            if ($vendor && $vendor['user_id']) {
                Rental_Gates_Notification::send(
                    $vendor['user_id'],
                    'vendor_assigned',
                    __('New Work Order Assigned', 'rental-gates'),
                    sprintf(
                        __('You have been assigned a new work order: %s', 'rental-gates'),
                        $work_order['title']
                    ),
                    home_url('/rental-gates/vendor/work-orders'),
                    array('organization_id' => $work_order['organization_id'], 'work_order_id' => $work_order_id)
                );
            }
        }
    }
    
    /**
     * Handle application submitted event
     */
    public function on_application_submitted($application_id, $application) {
        // Notify property manager
        $this->notify_organization_admins($application['organization_id'], 'application_received',
            sprintf(__('New Application: %s %s for %s', 'rental-gates'),
                $application['first_name'], $application['last_name'], $application['unit_name'] ?? 'unit'
            ),
            home_url('/rental-gates/dashboard/applications/' . $application_id)
        );
        
        // Send email to applicant
        Rental_Gates_Email::send_application_received($application_id);
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get all organization IDs
     */
    private function get_all_organizations() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_col("SELECT id FROM {$tables['organizations']} WHERE status = 'active'");
    }
    
    /**
     * Get automation settings for organization
     */
    private function get_automation_settings($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $settings = $wpdb->get_var($wpdb->prepare(
            "SELECT setting_value FROM {$tables['settings']} 
             WHERE organization_id = %d AND setting_key = 'automation_settings'",
            $org_id
        ));
        
        $defaults = array(
            'enabled' => true,
            'rent_reminder_enabled' => true,
            'rent_reminder_days' => 3,
            'overdue_alerts_enabled' => true,
            'late_fees_enabled' => false,
            'late_fee_grace_days' => 5,
            'late_fee_type' => 'fixed',
            'late_fee_amount' => 50,
            'late_fee_percent' => 5,
            'lease_expiry_alerts_enabled' => true,
            'move_reminders_enabled' => true,
        );
        
        if ($settings) {
            return array_merge($defaults, json_decode($settings, true) ?: array());
        }
        
        return $defaults;
    }
    
    /**
     * Notify all admins of an organization
     */
    private function notify_organization_admins($org_id, $type, $message, $action_url = '') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get organization members with admin/owner roles
        $admins = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM {$tables['organization_members']} 
             WHERE organization_id = %d AND role IN ('owner', 'property_manager')",
            $org_id
        ));
        
        foreach ($admins as $user_id) {
            Rental_Gates_Notification::send(
                $user_id,
                $type,
                self::get_type_title($type),
                $message,
                $action_url,
                array('organization_id' => $org_id)
            );
        }
    }
    
    /**
     * Get notification title for type
     */
    private static function get_type_title($type) {
        $titles = Rental_Gates_Notification::TYPES;
        return $titles[$type] ?? ucwords(str_replace('_', ' ', $type));
    }
    
    /**
     * Check if notification was already sent
     */
    private function check_notification_sent($entity_id, $type, $key) {
        $sent = get_transient("rg_notif_{$type}_{$entity_id}_{$key}");
        return !empty($sent);
    }
    
    /**
     * Log that notification was sent
     */
    private function log_notification_sent($entity_id, $type, $key) {
        set_transient("rg_notif_{$type}_{$entity_id}_{$key}", time(), DAY_IN_SECONDS * 30);
    }
}
