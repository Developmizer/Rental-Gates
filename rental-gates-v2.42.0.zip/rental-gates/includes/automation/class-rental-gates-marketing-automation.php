<?php
/**
 * Rental Gates Marketing Automation
 * 
 * Handles automated email sequences, lead nurturing workflows,
 * and trigger-based marketing actions.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Marketing_Automation {
    
    private static $table_name;
    
    /**
     * Trigger types
     */
    const TRIGGER_NEW_LEAD = 'new_lead';
    const TRIGGER_LEAD_STAGE_CHANGE = 'lead_stage_change';
    const TRIGGER_QR_SCAN = 'qr_scan';
    const TRIGGER_APPLICATION_SUBMITTED = 'application_submitted';
    const TRIGGER_FOLLOW_UP_DUE = 'follow_up_due';
    const TRIGGER_NO_ACTIVITY = 'no_activity';
    
    /**
     * Action types
     */
    const ACTION_SEND_EMAIL = 'send_email';
    const ACTION_UPDATE_STAGE = 'update_stage';
    const ACTION_ASSIGN_TO = 'assign_to';
    const ACTION_ADD_NOTE = 'add_note';
    const ACTION_CREATE_TASK = 'create_task';
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['marketing_automation_rules'] ?? $wpdb->prefix . 'rg_marketing_automation_rules';
        }
    }
    
    /**
     * Create automation rule
     */
    public static function create_rule($data) {
        global $wpdb;
        self::init();
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            self::create_table();
        }
        
        if (empty($data['organization_id']) || empty($data['trigger_type']) || empty($data['action_type'])) {
            return new WP_Error('missing_fields', __('Trigger and action are required', 'rental-gates'));
        }
        
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'name' => sanitize_text_field($data['name'] ?? ''),
            'trigger_type' => sanitize_text_field($data['trigger_type']),
            'trigger_conditions' => !empty($data['trigger_conditions']) ? wp_json_encode($data['trigger_conditions']) : null,
            'action_type' => sanitize_text_field($data['action_type']),
            'action_data' => !empty($data['action_data']) ? wp_json_encode($data['action_data']) : null,
            'is_active' => isset($data['is_active']) ? (int) $data['is_active'] : 1,
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create automation rule', 'rental-gates'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Process trigger
     */
    public static function process_trigger($trigger_type, $entity_id, $entity_type, $org_id, $data = array()) {
        global $wpdb;
        self::init();
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            return;
        }
        
        // Get active rules for this trigger
        $rules = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             AND trigger_type = %s 
             AND is_active = 1",
            $org_id, $trigger_type
        ), ARRAY_A);
        
        foreach ($rules as $rule) {
            // Check trigger conditions
            $conditions = json_decode($rule['trigger_conditions'], true) ?: array();
            if (self::check_conditions($conditions, $data)) {
                // Execute action
                self::execute_action($rule, $entity_id, $entity_type, $org_id, $data);
            }
        }
    }
    
    /**
     * Check if conditions are met
     */
    private static function check_conditions($conditions, $data) {
        if (empty($conditions)) {
            return true; // No conditions = always trigger
        }
        
        foreach ($conditions as $condition) {
            $field = $condition['field'] ?? '';
            $operator = $condition['operator'] ?? 'equals';
            $value = $condition['value'] ?? '';
            
            $data_value = $data[$field] ?? null;
            
            switch ($operator) {
                case 'equals':
                    if ($data_value != $value) return false;
                    break;
                case 'not_equals':
                    if ($data_value == $value) return false;
                    break;
                case 'contains':
                    if (strpos($data_value, $value) === false) return false;
                    break;
                case 'greater_than':
                    if ($data_value <= $value) return false;
                    break;
                case 'less_than':
                    if ($data_value >= $value) return false;
                    break;
            }
        }
        
        return true;
    }
    
    /**
     * Execute automation action
     */
    private static function execute_action($rule, $entity_id, $entity_type, $org_id, $data) {
        $action_data = json_decode($rule['action_data'], true) ?: array();
        
        switch ($rule['action_type']) {
            case self::ACTION_SEND_EMAIL:
                self::action_send_email($entity_id, $entity_type, $org_id, $action_data);
                break;
                
            case self::ACTION_UPDATE_STAGE:
                if ($entity_type === 'lead') {
                    Rental_Gates_Lead::update_stage($entity_id, $action_data['stage'] ?? 'contacted');
                }
                break;
                
            case self::ACTION_ASSIGN_TO:
                if ($entity_type === 'lead' && !empty($action_data['user_id'])) {
                    Rental_Gates_Lead::update($entity_id, array('assigned_to' => intval($action_data['user_id'])));
                }
                break;
                
            case self::ACTION_ADD_NOTE:
                if ($entity_type === 'lead' && !empty($action_data['note'])) {
                    Rental_Gates_Lead::add_note($entity_id, $action_data['note']);
                }
                break;
        }
    }
    
    /**
     * Send email action
     */
    private static function action_send_email($entity_id, $entity_type, $org_id, $action_data) {
        if ($entity_type === 'lead') {
            $lead = Rental_Gates_Lead::get($entity_id);
            if ($lead && !empty($lead['email'])) {
                $template = $action_data['template'] ?? 'lead_followup';
                $subject = $action_data['subject'] ?? '';
                $message = $action_data['message'] ?? '';
                
                Rental_Gates_Email::send(
                    $lead['email'],
                    $template,
                    array(
                        'lead_name' => $lead['name'],
                        'message' => $message,
                    ),
                    $subject
                );
            }
        }
    }
    
    /**
     * Create default automation rules for organization
     */
    public static function create_default_rules($org_id) {
        // Welcome email for new leads
        self::create_rule(array(
            'organization_id' => $org_id,
            'name' => __('Welcome New Leads', 'rental-gates'),
            'trigger_type' => self::TRIGGER_NEW_LEAD,
            'action_type' => self::ACTION_SEND_EMAIL,
            'action_data' => array(
                'template' => 'lead_followup',
                'subject' => __('Welcome! We\'re excited to help you find your next home', 'rental-gates'),
                'message' => __('Thank you for your interest. We\'ll be in touch soon!', 'rental-gates'),
            ),
        ));
        
        // Follow-up reminder
        self::create_rule(array(
            'organization_id' => $org_id,
            'name' => __('Follow-up Reminder', 'rental-gates'),
            'trigger_type' => self::TRIGGER_FOLLOW_UP_DUE,
            'action_type' => self::ACTION_ADD_NOTE,
            'action_data' => array(
                'note' => __('Automated reminder: Follow-up date reached', 'rental-gates'),
            ),
        ));
    }
    
    /**
     * Create table
     */
    private static function create_table() {
        global $wpdb;
        self::init();
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE " . self::$table_name . " (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            organization_id bigint(20) UNSIGNED NOT NULL,
            name varchar(255) NOT NULL,
            trigger_type varchar(50) NOT NULL,
            trigger_conditions longtext DEFAULT NULL,
            action_type varchar(50) NOT NULL,
            action_data longtext DEFAULT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY organization_id (organization_id),
            KEY trigger_type (trigger_type),
            KEY is_active (is_active)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
