<?php
/**
 * Rental Gates OpenStreetMap Class
 * OpenStreetMap/Nominatim implementation of the map service
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_OpenStreetMap extends Rental_Gates_Map_Service {
    
    /**
     * Nominatim base URL
     */
    private $nominatim_url = 'https://nominatim.openstreetmap.org';
    
    /**
     * Tile server URL
     */
    private $tile_server;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->provider = 'openstreetmap';
        
        // Allow custom Nominatim server
        $custom_nominatim = get_option('rental_gates_nominatim_url', '');
        if (!empty($custom_nominatim)) {
            $this->nominatim_url = rtrim($custom_nominatim, '/');
        }
        
        // Tile server
        $this->tile_server = get_option(
            'rental_gates_openstreetmap_tile_server',
            'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
        );
    }
    
    /**
     * Reverse geocode coordinates to address
     */
    public function reverse_geocode($lat, $lng) {
        // Validate coordinates
        $coords = Rental_Gates_Security::sanitize_coordinates($lat, $lng);
        if (!$coords) {
            return new WP_Error('invalid_coordinates', __('Invalid coordinates', 'rental-gates'));
        }
        
        // Check cache first
        $cached = $this->get_cached_geocode($coords['lat'], $coords['lng']);
        if ($cached) {
            return $cached;
        }
        
        // Make API request with rate limiting (Nominatim requires 1 req/sec)
        // Add a small delay to be respectful
        usleep(100000); // 100ms
        
        $url = $this->nominatim_url . '/reverse?' . http_build_query(array(
            'format' => 'jsonv2',
            'lat' => $coords['lat'],
            'lon' => $coords['lng'],
            'addressdetails' => 1,
            'accept-language' => substr(get_locale(), 0, 2),
        ));
        
        $response = $this->make_request($url, array(
            'headers' => array(
                'User-Agent' => 'RentalGates/' . RENTAL_GATES_VERSION . ' (' . home_url() . ')',
            ),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['error'])) {
            return new WP_Error(
                'geocode_failed',
                $response['error']
            );
        }
        
        $result = $this->normalize_address($response);
        $result['lat'] = $coords['lat'];
        $result['lng'] = $coords['lng'];
        
        // Cache the result
        $this->cache_geocode_result($coords['lat'], $coords['lng'], $result);
        
        return $result;
    }
    
    /**
     * Geocode address to coordinates
     */
    public function geocode($address) {
        if (empty($address)) {
            return new WP_Error('empty_address', __('Address is required', 'rental-gates'));
        }
        
        // Add delay for rate limiting
        usleep(100000); // 100ms
        
        $url = $this->nominatim_url . '/search?' . http_build_query(array(
            'format' => 'jsonv2',
            'q' => $address,
            'addressdetails' => 1,
            'limit' => 1,
            'accept-language' => substr(get_locale(), 0, 2),
        ));
        
        $response = $this->make_request($url, array(
            'headers' => array(
                'User-Agent' => 'RentalGates/' . RENTAL_GATES_VERSION . ' (' . home_url() . ')',
            ),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (empty($response) || !is_array($response)) {
            return new WP_Error('no_results', __('Address not found', 'rental-gates'));
        }
        
        $result = $response[0];
        $normalized = $this->normalize_address($result);
        $normalized['lat'] = floatval($result['lat']);
        $normalized['lng'] = floatval($result['lon']);
        
        return $normalized;
    }
    
    /**
     * Search for places
     */
    public function search_places($query, $options = array()) {
        $params = array(
            'format' => 'jsonv2',
            'q' => $query,
            'addressdetails' => 1,
            'limit' => 10,
        );
        
        if (!empty($options['location']) && !empty($options['radius'])) {
            // Calculate viewbox from center and radius
            $bounds = $this->get_bounding_box(
                $options['location']['lat'],
                $options['location']['lng'],
                $options['radius']
            );
            
            $params['viewbox'] = implode(',', array(
                $bounds['west'],
                $bounds['north'],
                $bounds['east'],
                $bounds['south'],
            ));
            $params['bounded'] = 1;
        }
        
        $url = $this->nominatim_url . '/search?' . http_build_query($params);
        
        $response = $this->make_request($url, array(
            'headers' => array(
                'User-Agent' => 'RentalGates/' . RENTAL_GATES_VERSION . ' (' . home_url() . ')',
            ),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $places = array();
        foreach ($response as $place) {
            $places[] = array(
                'place_id' => $place['place_id'],
                'name' => $place['name'] ?? $place['display_name'],
                'address' => $place['display_name'],
                'lat' => floatval($place['lat']),
                'lng' => floatval($place['lon']),
                'types' => array($place['type'] ?? 'unknown'),
            );
        }
        
        return $places;
    }
    
    /**
     * Get map JavaScript configuration
     */
    public function get_js_config() {
        return array(
            'provider' => 'openstreetmap',
            'tileServer' => $this->tile_server,
            'attribution' => '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            'maxZoom' => 19,
            'defaultCenter' => array(
                'lat' => 39.8283,
                'lng' => -98.5795, // Center of USA
            ),
            'defaultZoom' => 4,
            'leafletCss' => 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
            'leafletJs' => 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
            'markerClusterCss' => 'https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css',
            'markerClusterJs' => 'https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js',
        );
    }
    
    /**
     * Validate API configuration
     */
    public function validate_config() {
        // OpenStreetMap doesn't require an API key, but let's verify connectivity
        $url = $this->nominatim_url . '/status.php?format=json';
        
        $response = wp_remote_get($url, array(
            'timeout' => 5,
            'headers' => array(
                'User-Agent' => 'RentalGates/' . RENTAL_GATES_VERSION . ' (' . home_url() . ')',
            ),
        ));
        
        if (is_wp_error($response)) {
            return new WP_Error(
                'connection_failed',
                __('Unable to connect to OpenStreetMap services', 'rental-gates')
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code !== 200) {
            return new WP_Error(
                'service_unavailable',
                __('OpenStreetMap service is currently unavailable', 'rental-gates')
            );
        }
        
        return true;
    }
    
    /**
     * Normalize address data from Nominatim format
     */
    protected function normalize_address($result) {
        $address = array(
            'formatted_address' => $result['display_name'] ?? '',
            'street_address' => '',
            'city' => '',
            'state' => '',
            'zip' => '',
            'country' => '',
            'country_code' => '',
            'lat' => 0,
            'lng' => 0,
        );
        
        if (isset($result['lat'])) {
            $address['lat'] = floatval($result['lat']);
        }
        if (isset($result['lon'])) {
            $address['lng'] = floatval($result['lon']);
        }
        
        $addr = $result['address'] ?? array();
        
        // Street address
        $house_number = $addr['house_number'] ?? '';
        $road = $addr['road'] ?? $addr['street'] ?? '';
        $address['street_address'] = trim($house_number . ' ' . $road);
        
        // City - try multiple possible keys
        $address['city'] = $addr['city'] ?? 
                          $addr['town'] ?? 
                          $addr['village'] ?? 
                          $addr['municipality'] ?? 
                          $addr['hamlet'] ?? '';
        
        // State
        $address['state'] = $addr['state'] ?? 
                           $addr['region'] ?? 
                           $addr['province'] ?? '';
        
        // Postal code
        $address['zip'] = $addr['postcode'] ?? '';
        
        // Country
        $address['country'] = $addr['country'] ?? '';
        $address['country_code'] = strtoupper($addr['country_code'] ?? '');
        
        return $address;
    }
    
    /**
     * Get static map URL (using external service or tiles)
     */
    public function get_static_map_url($lat, $lng, $options = array()) {
        $defaults = array(
            'zoom' => 15,
            'width' => 400,
            'height' => 300,
        );
        
        $options = wp_parse_args($options, $defaults);
        
        // Use a static map service
        // Note: For production, consider hosting your own static map service
        return sprintf(
            'https://staticmap.openstreetmap.de/staticmap.php?center=%s,%s&zoom=%d&size=%dx%d&markers=%s,%s,red-pushpin',
            $lat,
            $lng,
            $options['zoom'],
            $options['width'],
            $options['height'],
            $lat,
            $lng
        );
    }
    
    /**
     * Get tile URL for a specific location
     */
    public function get_tile_url($lat, $lng, $zoom = 15) {
        // Convert lat/lng to tile coordinates
        $x = floor(($lng + 180) / 360 * pow(2, $zoom));
        $y = floor((1 - log(tan(deg2rad($lat)) + 1 / cos(deg2rad($lat))) / M_PI) / 2 * pow(2, $zoom));
        
        $tile_url = str_replace(
            array('{s}', '{z}', '{x}', '{y}'),
            array('a', $zoom, $x, $y),
            $this->tile_server
        );
        
        return $tile_url;
    }
}
