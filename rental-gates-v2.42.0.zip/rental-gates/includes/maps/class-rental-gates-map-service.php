<?php
/**
 * Rental Gates Map Service Abstract Class
 * Provides a provider-agnostic interface for map functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

abstract class Rental_Gates_Map_Service {
    
    /**
     * Provider name
     */
    protected $provider;
    
    /**
     * Get provider name
     */
    public function get_provider() {
        return $this->provider;
    }
    
    /**
     * Reverse geocode coordinates to address
     * 
     * @param float $lat Latitude
     * @param float $lng Longitude
     * @return array|WP_Error Address data or error
     */
    abstract public function reverse_geocode($lat, $lng);
    
    /**
     * Geocode address to coordinates
     * 
     * @param string $address Address string
     * @return array|WP_Error Coordinates or error
     */
    abstract public function geocode($address);
    
    /**
     * Search for places
     * 
     * @param string $query Search query
     * @param array $options Search options (bounds, types, etc.)
     * @return array|WP_Error Places or error
     */
    abstract public function search_places($query, $options = array());
    
    /**
     * Get map JavaScript configuration
     * 
     * @return array Configuration for frontend
     */
    abstract public function get_js_config();
    
    /**
     * Validate API configuration
     * 
     * @return bool|WP_Error True if valid, error otherwise
     */
    abstract public function validate_config();
    
    /**
     * Normalize address data from provider-specific format
     * 
     * @param array $raw_data Raw geocoding response
     * @return array Normalized address data
     */
    protected function normalize_address($raw_data) {
        return array(
            'formatted_address' => '',
            'street_address' => '',
            'city' => '',
            'state' => '',
            'zip' => '',
            'country' => '',
            'country_code' => '',
            'lat' => 0,
            'lng' => 0,
        );
    }
    
    /**
     * Calculate distance between two points
     * 
     * @param float $lat1 Latitude 1
     * @param float $lng1 Longitude 1
     * @param float $lat2 Latitude 2
     * @param float $lng2 Longitude 2
     * @param string $unit 'km' or 'mi'
     * @return float Distance
     */
    public function calculate_distance($lat1, $lng1, $lat2, $lng2, $unit = 'mi') {
        $earth_radius = $unit === 'km' ? 6371 : 3959;
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return round($earth_radius * $c, 2);
    }
    
    /**
     * Get bounding box for radius search
     * 
     * @param float $lat Center latitude
     * @param float $lng Center longitude
     * @param float $radius Radius in miles
     * @return array Bounding box coordinates
     */
    public function get_bounding_box($lat, $lng, $radius) {
        $earth_radius = 3959; // miles
        
        $lat_delta = rad2deg($radius / $earth_radius);
        $lng_delta = rad2deg($radius / ($earth_radius * cos(deg2rad($lat))));
        
        return array(
            'north' => $lat + $lat_delta,
            'south' => $lat - $lat_delta,
            'east' => $lng + $lng_delta,
            'west' => $lng - $lng_delta,
        );
    }
    
    /**
     * Check if coordinates are within bounding box
     * 
     * @param float $lat Latitude
     * @param float $lng Longitude
     * @param array $bounds Bounding box
     * @return bool
     */
    public function is_within_bounds($lat, $lng, $bounds) {
        return $lat >= $bounds['south'] && 
               $lat <= $bounds['north'] && 
               $lng >= $bounds['west'] && 
               $lng <= $bounds['east'];
    }
    
    /**
     * Cache geocoding result
     * 
     * @param float $lat Latitude
     * @param float $lng Longitude
     * @param array $data Address data
     */
    protected function cache_geocode_result($lat, $lng, $data) {
        Rental_Gates_Cache::set_geocode_cache($lat, $lng, $data);
    }
    
    /**
     * Get cached geocoding result
     * 
     * @param float $lat Latitude
     * @param float $lng Longitude
     * @return array|false Cached data or false
     */
    protected function get_cached_geocode($lat, $lng) {
        return Rental_Gates_Cache::get_geocode_cache($lat, $lng);
    }
    
    /**
     * Make HTTP request with rate limiting
     * 
     * @param string $url Request URL
     * @param array $args Request arguments
     * @return array|WP_Error Response or error
     */
    protected function make_request($url, $args = array()) {
        // Check rate limit
        $rate_check = Rental_Gates_Rate_Limit::check('geocode');
        if (is_wp_error($rate_check)) {
            return $rate_check;
        }
        
        $defaults = array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json',
            ),
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($code !== 200) {
            return new WP_Error(
                'api_error',
                sprintf(__('Map API request failed with status %d', 'rental-gates'), $code)
            );
        }
        
        return json_decode($body, true);
    }
}
