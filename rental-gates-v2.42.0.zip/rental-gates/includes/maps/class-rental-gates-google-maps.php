<?php
/**
 * Rental Gates Google Maps Class
 * Google Maps implementation of the map service
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Google_Maps extends Rental_Gates_Map_Service {
    
    /**
     * API key
     */
    private $api_key;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->provider = 'google';
        $this->api_key = get_option('rental_gates_google_maps_api_key', '');
    }
    
    /**
     * Reverse geocode coordinates to address
     */
    public function reverse_geocode($lat, $lng) {
        // Validate coordinates
        $coords = Rental_Gates_Security::sanitize_coordinates($lat, $lng);
        if (!$coords) {
            return new WP_Error('invalid_coordinates', __('Invalid coordinates', 'rental-gates'));
        }
        
        // Check cache first
        $cached = $this->get_cached_geocode($coords['lat'], $coords['lng']);
        if ($cached) {
            return $cached;
        }
        
        // Make API request
        $url = add_query_arg(array(
            'latlng' => $coords['lat'] . ',' . $coords['lng'],
            'key' => $this->api_key,
            'language' => substr(get_locale(), 0, 2),
        ), 'https://maps.googleapis.com/maps/api/geocode/json');
        
        $response = $this->make_request($url);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if ($response['status'] !== 'OK') {
            return new WP_Error(
                'geocode_failed',
                $this->get_error_message($response['status']),
                array('status' => $response['status'])
            );
        }
        
        if (empty($response['results'])) {
            return new WP_Error('no_results', __('No address found for coordinates', 'rental-gates'));
        }
        
        $result = $this->normalize_address($response['results'][0]);
        $result['lat'] = $coords['lat'];
        $result['lng'] = $coords['lng'];
        
        // Cache the result
        $this->cache_geocode_result($coords['lat'], $coords['lng'], $result);
        
        return $result;
    }
    
    /**
     * Geocode address to coordinates
     */
    public function geocode($address) {
        if (empty($address)) {
            return new WP_Error('empty_address', __('Address is required', 'rental-gates'));
        }
        
        $url = add_query_arg(array(
            'address' => urlencode($address),
            'key' => $this->api_key,
            'language' => substr(get_locale(), 0, 2),
        ), 'https://maps.googleapis.com/maps/api/geocode/json');
        
        $response = $this->make_request($url);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if ($response['status'] !== 'OK') {
            return new WP_Error(
                'geocode_failed',
                $this->get_error_message($response['status'])
            );
        }
        
        if (empty($response['results'])) {
            return new WP_Error('no_results', __('Address not found', 'rental-gates'));
        }
        
        $result = $response['results'][0];
        $location = $result['geometry']['location'];
        
        $normalized = $this->normalize_address($result);
        $normalized['lat'] = $location['lat'];
        $normalized['lng'] = $location['lng'];
        
        return $normalized;
    }
    
    /**
     * Search for places
     */
    public function search_places($query, $options = array()) {
        $params = array(
            'query' => $query,
            'key' => $this->api_key,
        );
        
        if (!empty($options['location'])) {
            $params['location'] = $options['location']['lat'] . ',' . $options['location']['lng'];
        }
        
        if (!empty($options['radius'])) {
            $params['radius'] = $options['radius'] * 1609.34; // Convert miles to meters
        }
        
        if (!empty($options['type'])) {
            $params['type'] = $options['type'];
        }
        
        $url = add_query_arg($params, 'https://maps.googleapis.com/maps/api/place/textsearch/json');
        
        $response = $this->make_request($url);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if ($response['status'] !== 'OK' && $response['status'] !== 'ZERO_RESULTS') {
            return new WP_Error('search_failed', $this->get_error_message($response['status']));
        }
        
        $places = array();
        foreach ($response['results'] ?? array() as $place) {
            $places[] = array(
                'place_id' => $place['place_id'],
                'name' => $place['name'],
                'address' => $place['formatted_address'],
                'lat' => $place['geometry']['location']['lat'],
                'lng' => $place['geometry']['location']['lng'],
                'types' => $place['types'] ?? array(),
            );
        }
        
        return $places;
    }
    
    /**
     * Get map JavaScript configuration
     */
    public function get_js_config() {
        return array(
            'provider' => 'google',
            'apiKey' => $this->api_key,
            'apiUrl' => 'https://maps.googleapis.com/maps/api/js',
            'libraries' => array('places', 'marker'),
            'version' => 'weekly',
            'defaultCenter' => array(
                'lat' => 39.8283,
                'lng' => -98.5795, // Center of USA
            ),
            'defaultZoom' => 4,
            'styles' => $this->get_map_styles(),
        );
    }
    
    /**
     * Validate API configuration
     */
    public function validate_config() {
        if (empty($this->api_key)) {
            return new WP_Error(
                'missing_api_key',
                __('Google Maps API key is not configured', 'rental-gates')
            );
        }
        
        // Test the API key with a simple request
        $url = add_query_arg(array(
            'latlng' => '40.714224,-73.961452', // NYC
            'key' => $this->api_key,
        ), 'https://maps.googleapis.com/maps/api/geocode/json');
        
        $response = wp_remote_get($url, array('timeout' => 5));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($body['status'] === 'REQUEST_DENIED') {
            return new WP_Error(
                'invalid_api_key',
                __('Google Maps API key is invalid or restricted', 'rental-gates')
            );
        }
        
        return true;
    }
    
    /**
     * Normalize address data from Google format
     */
    protected function normalize_address($result) {
        $address = array(
            'formatted_address' => $result['formatted_address'] ?? '',
            'street_address' => '',
            'city' => '',
            'state' => '',
            'zip' => '',
            'country' => '',
            'country_code' => '',
            'lat' => 0,
            'lng' => 0,
        );
        
        if (isset($result['geometry']['location'])) {
            $address['lat'] = $result['geometry']['location']['lat'];
            $address['lng'] = $result['geometry']['location']['lng'];
        }
        
        $components = $result['address_components'] ?? array();
        $street_number = '';
        $route = '';
        
        foreach ($components as $component) {
            $types = $component['types'];
            
            if (in_array('street_number', $types)) {
                $street_number = $component['long_name'];
            }
            if (in_array('route', $types)) {
                $route = $component['long_name'];
            }
            if (in_array('locality', $types)) {
                $address['city'] = $component['long_name'];
            }
            if (in_array('administrative_area_level_1', $types)) {
                $address['state'] = $component['short_name'];
            }
            if (in_array('postal_code', $types)) {
                $address['zip'] = $component['long_name'];
            }
            if (in_array('country', $types)) {
                $address['country'] = $component['long_name'];
                $address['country_code'] = $component['short_name'];
            }
        }
        
        // Combine street address
        $address['street_address'] = trim($street_number . ' ' . $route);
        
        return $address;
    }
    
    /**
     * Get error message for status code
     */
    private function get_error_message($status) {
        $messages = array(
            'ZERO_RESULTS' => __('No results found', 'rental-gates'),
            'OVER_DAILY_LIMIT' => __('API daily limit exceeded', 'rental-gates'),
            'OVER_QUERY_LIMIT' => __('API query limit exceeded', 'rental-gates'),
            'REQUEST_DENIED' => __('API request denied', 'rental-gates'),
            'INVALID_REQUEST' => __('Invalid request', 'rental-gates'),
            'UNKNOWN_ERROR' => __('Unknown error occurred', 'rental-gates'),
        );
        
        return $messages[$status] ?? $status;
    }
    
    /**
     * Get custom map styles
     */
    private function get_map_styles() {
        // Modern, clean map style
        return array(
            array(
                'featureType' => 'poi',
                'elementType' => 'labels',
                'stylers' => array(array('visibility' => 'off')),
            ),
            array(
                'featureType' => 'transit',
                'elementType' => 'labels',
                'stylers' => array(array('visibility' => 'off')),
            ),
        );
    }
    
    /**
     * Get static map URL
     */
    public function get_static_map_url($lat, $lng, $options = array()) {
        $defaults = array(
            'zoom' => 15,
            'size' => '400x300',
            'maptype' => 'roadmap',
            'markers' => "color:red|{$lat},{$lng}",
        );
        
        $params = wp_parse_args($options, $defaults);
        $params['center'] = "{$lat},{$lng}";
        $params['key'] = $this->api_key;
        
        return add_query_arg($params, 'https://maps.googleapis.com/maps/api/staticmap');
    }
}
