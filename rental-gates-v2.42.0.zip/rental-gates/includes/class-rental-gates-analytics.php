<?php
/**
 * Rental Gates Analytics Helper
 * 
 * Provides comprehensive analytics and reporting data aggregation
 * for dashboards, charts, and exports.
 * 
 * @package RentalGates
 * @since 2.37.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Analytics {
    
    /**
     * Get comprehensive financial analytics
     * 
     * @param int $org_id Organization ID
     * @param string $period Period: 'day', 'week', 'month', 'quarter', 'year', or custom date range
     * @param string $start_date Optional start date (Y-m-d)
     * @param string $end_date Optional end date (Y-m-d)
     * @return array
     */
    public static function get_financial_analytics($org_id, $period = 'month', $start_date = null, $end_date = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Calculate date range
        $date_range = self::calculate_date_range($period, $start_date, $end_date);
        $start = $date_range['start'];
        $end = $date_range['end'];
        
        // Total revenue collected
        $revenue_collected = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount_paid), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d AND status = 'succeeded' 
             AND paid_at BETWEEN %s AND %s",
            $org_id, $start, $end . ' 23:59:59'
        )));
        
        // Total billed
        $total_billed = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d 
             AND due_date BETWEEN %s AND %s",
            $org_id, $start, $end
        )));
        
        // Collection rate
        $collection_rate = $total_billed > 0 ? ($revenue_collected / $total_billed) * 100 : 0;
        
        // Outstanding balance
        $outstanding_balance = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount - amount_paid), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d AND status IN ('pending', 'partially_paid')",
            $org_id
        )));
        
        // Overdue amount
        $overdue_amount = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount - amount_paid), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d AND status IN ('pending', 'partially_paid') 
             AND due_date < CURDATE()",
            $org_id
        )));
        
        // Previous period for comparison
        $prev_range = self::get_previous_period_range($period, $start, $end);
        $prev_revenue = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount_paid), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d AND status = 'succeeded' 
             AND paid_at BETWEEN %s AND %s",
            $org_id, $prev_range['start'], $prev_range['end'] . ' 23:59:59'
        )));
        
        // Growth calculation
        $revenue_growth = $prev_revenue > 0 ? (($revenue_collected - $prev_revenue) / $prev_revenue) * 100 : 0;
        
        // Revenue by building
        $revenue_by_building = $wpdb->get_results($wpdb->prepare(
            "SELECT b.id, b.name as building_name,
                    COALESCE(SUM(p.amount_paid), 0) as collected,
                    COALESCE(SUM(p.amount), 0) as billed
             FROM {$tables['buildings']} b
             LEFT JOIN {$tables['units']} u ON b.id = u.building_id
             LEFT JOIN {$tables['leases']} l ON u.id = l.unit_id AND l.status = 'active'
             LEFT JOIN {$tables['payments']} p ON l.id = p.lease_id 
                 AND p.paid_at BETWEEN %s AND %s AND p.status = 'succeeded'
             WHERE b.organization_id = %d
             GROUP BY b.id, b.name
             ORDER BY collected DESC",
            $start, $end . ' 23:59:59', $org_id
        ), ARRAY_A);
        
        // Revenue by payment type
        $revenue_by_type = $wpdb->get_results($wpdb->prepare(
            "SELECT COALESCE(type, 'rent') as payment_type,
                    SUM(amount_paid) as collected,
                    COUNT(*) as transaction_count
             FROM {$tables['payments']}
             WHERE organization_id = %d AND status = 'succeeded'
             AND paid_at BETWEEN %s AND %s
             GROUP BY COALESCE(type, 'rent')
             ORDER BY collected DESC",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // Daily revenue trend (for period)
        $daily_revenue = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(paid_at) as date,
                    SUM(amount_paid) as revenue,
                    COUNT(*) as transactions
             FROM {$tables['payments']}
             WHERE organization_id = %d AND status = 'succeeded'
             AND paid_at BETWEEN %s AND %s
             GROUP BY DATE(paid_at)
             ORDER BY date ASC",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        return array(
            'period' => $period,
            'start_date' => $start,
            'end_date' => $end,
            'revenue_collected' => $revenue_collected,
            'total_billed' => $total_billed,
            'collection_rate' => round($collection_rate, 2),
            'outstanding_balance' => $outstanding_balance,
            'overdue_amount' => $overdue_amount,
            'revenue_growth' => round($revenue_growth, 2),
            'previous_revenue' => $prev_revenue,
            'revenue_by_building' => $revenue_by_building,
            'revenue_by_type' => $revenue_by_type,
            'daily_revenue' => $daily_revenue,
        );
    }
    
    /**
     * Get occupancy analytics
     * 
     * @param int $org_id Organization ID
     * @return array
     */
    public static function get_occupancy_analytics($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Total units
        $total_units = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['units']} u
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE b.organization_id = %d",
            $org_id
        )));
        
        // Units by status
        $units_by_status = $wpdb->get_results($wpdb->prepare(
            "SELECT u.availability, COUNT(*) as count
             FROM {$tables['units']} u
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE b.organization_id = %d
             GROUP BY u.availability",
            $org_id
        ), ARRAY_A);
        
        $occupied = 0;
        $available = 0;
        $coming_soon = 0;
        $renewal_pending = 0;
        $unlisted = 0;
        
        foreach ($units_by_status as $row) {
            switch ($row['availability']) {
                case 'occupied':
                    $occupied = intval($row['count']);
                    break;
                case 'available':
                    $available = intval($row['count']);
                    break;
                case 'coming_soon':
                    $coming_soon = intval($row['count']);
                    break;
                case 'renewal_pending':
                    $renewal_pending = intval($row['count']);
                    break;
                case 'unlisted':
                    $unlisted = intval($row['count']);
                    break;
            }
        }
        
        $occupancy_rate = $total_units > 0 ? ($occupied / $total_units) * 100 : 0;
        
        // Vacancy rate
        $vacancy_rate = $total_units > 0 ? (($available + $coming_soon) / $total_units) * 100 : 0;
        
        // Average days vacant (last 12 months)
        $avg_days_vacant = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT AVG(DATEDIFF(lease_start, previous_lease_end))
             FROM (
                 SELECT l.start_date as lease_start,
                        (SELECT MAX(end_date) FROM {$tables['leases']} l2 
                         WHERE l2.unit_id = l.unit_id AND l2.end_date < l.start_date) as previous_lease_end
                 FROM {$tables['leases']} l
                 JOIN {$tables['units']} u ON l.unit_id = u.id
                 JOIN {$tables['buildings']} b ON u.building_id = b.id
                 WHERE b.organization_id = %d
                 AND l.start_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
             ) as gaps
             WHERE previous_lease_end IS NOT NULL",
            $org_id
        )));
        
        // Occupancy by building
        $occupancy_by_building = $wpdb->get_results($wpdb->prepare(
            "SELECT b.id, b.name,
                    COUNT(u.id) as total_units,
                    SUM(CASE WHEN u.availability = 'occupied' THEN 1 ELSE 0 END) as occupied_units,
                    ROUND(SUM(CASE WHEN u.availability = 'occupied' THEN 1 ELSE 0 END) * 100.0 / COUNT(u.id), 2) as occupancy_rate
             FROM {$tables['buildings']} b
             LEFT JOIN {$tables['units']} u ON b.id = u.building_id
             WHERE b.organization_id = %d
             GROUP BY b.id, b.name
             ORDER BY occupancy_rate DESC",
            $org_id
        ), ARRAY_A);
        
        return array(
            'total_units' => $total_units,
            'occupied' => $occupied,
            'available' => $available,
            'coming_soon' => $coming_soon,
            'renewal_pending' => $renewal_pending,
            'unlisted' => $unlisted,
            'occupancy_rate' => round($occupancy_rate, 2),
            'vacancy_rate' => round($vacancy_rate, 2),
            'avg_days_vacant' => round($avg_days_vacant, 1),
            'occupancy_by_building' => $occupancy_by_building,
        );
    }
    
    /**
     * Get revenue trend data
     * 
     * @param int $org_id Organization ID
     * @param int $months Number of months to include
     * @return array
     */
    public static function get_revenue_trend($org_id, $months = 12) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $revenue_trend = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE_FORMAT(paid_at, '%%Y-%%m') as month,
                    SUM(amount_paid) as revenue,
                    COUNT(*) as transactions
             FROM {$tables['payments']}
             WHERE organization_id = %d AND status = 'succeeded'
             AND paid_at >= DATE_SUB(CURDATE(), INTERVAL %d MONTH)
             GROUP BY DATE_FORMAT(paid_at, '%%Y-%%m')
             ORDER BY month ASC",
            $org_id, $months
        ), ARRAY_A);
        
        // Fill in missing months with zero
        $result = array();
        for ($i = $months - 1; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-{$i} months"));
            $month_label = date('M Y', strtotime("-{$i} months"));
            
            $found = false;
            foreach ($revenue_trend as $row) {
                if ($row['month'] === $month) {
                    $result[] = array(
                        'month' => $month,
                        'label' => $month_label,
                        'revenue' => floatval($row['revenue']),
                        'transactions' => intval($row['transactions']),
                    );
                    $found = true;
                    break;
                }
            }
            
            if (!$found) {
                $result[] = array(
                    'month' => $month,
                    'label' => $month_label,
                    'revenue' => 0,
                    'transactions' => 0,
                );
            }
        }
        
        return $result;
    }
    
    /**
     * Get maintenance analytics
     * 
     * @param int $org_id Organization ID
     * @param string $period Period
     * @return array
     */
    public static function get_maintenance_analytics($org_id, $period = 'month') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $date_range = self::calculate_date_range($period);
        $start = $date_range['start'];
        $end = $date_range['end'];
        
        // Total work orders
        $total_work_orders = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['work_orders']}
             WHERE organization_id = %d
             AND created_at BETWEEN %s AND %s",
            $org_id, $start, $end . ' 23:59:59'
        )));
        
        // By status
        $by_status = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count
             FROM {$tables['work_orders']}
             WHERE organization_id = %d
             AND created_at BETWEEN %s AND %s
             GROUP BY status",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // By priority
        $by_priority = $wpdb->get_results($wpdb->prepare(
            "SELECT priority, COUNT(*) as count
             FROM {$tables['work_orders']}
             WHERE organization_id = %d
             AND created_at BETWEEN %s AND %s
             GROUP BY priority",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // Average response time (hours from creation to first update)
        $avg_response_time = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, updated_at))
             FROM {$tables['work_orders']}
             WHERE organization_id = %d
             AND created_at BETWEEN %s AND %s
             AND status != 'open'",
            $org_id, $start, $end . ' 23:59:59'
        )));
        
        // Average completion time
        $avg_completion_time = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT AVG(TIMESTAMPDIFF(DAY, created_at, completed_at))
             FROM {$tables['work_orders']}
             WHERE organization_id = %d
             AND status = 'completed'
             AND created_at BETWEEN %s AND %s",
            $org_id, $start, $end . ' 23:59:59'
        )));
        
        return array(
            'total_work_orders' => $total_work_orders,
            'by_status' => $by_status,
            'by_priority' => $by_priority,
            'avg_response_time_hours' => round($avg_response_time, 1),
            'avg_completion_time_days' => round($avg_completion_time, 1),
        );
    }
    
    /**
     * Calculate date range based on period
     * 
     * @param string $period Period type
     * @param string $start_date Optional custom start date
     * @param string $end_date Optional custom end date
     * @return array
     */
    private static function calculate_date_range($period, $start_date = null, $end_date = null) {
        if ($start_date && $end_date) {
            return array(
                'start' => $start_date,
                'end' => $end_date,
            );
        }
        
        $today = date('Y-m-d');
        
        switch ($period) {
            case 'today':
                return array('start' => $today, 'end' => $today);
                
            case 'week':
                return array(
                    'start' => date('Y-m-d', strtotime('monday this week')),
                    'end' => date('Y-m-d', strtotime('sunday this week')),
                );
                
            case 'month':
                return array(
                    'start' => date('Y-m-01'),
                    'end' => date('Y-m-t'),
                );
                
            case 'quarter':
                $quarter = ceil(date('n') / 3);
                $start_month = (($quarter - 1) * 3) + 1;
                return array(
                    'start' => date("Y-{$start_month}-01"),
                    'end' => date('Y-m-t', strtotime(date("Y-{$start_month}-01") . ' +2 months')),
                );
                
            case 'year':
                return array(
                    'start' => date('Y-01-01'),
                    'end' => date('Y-12-31'),
                );
                
            case 'last_7_days':
                return array(
                    'start' => date('Y-m-d', strtotime('-7 days')),
                    'end' => $today,
                );
                
            case 'last_30_days':
                return array(
                    'start' => date('Y-m-d', strtotime('-30 days')),
                    'end' => $today,
                );
                
            case 'last_90_days':
                return array(
                    'start' => date('Y-m-d', strtotime('-90 days')),
                    'end' => $today,
                );
                
            default:
                return array(
                    'start' => date('Y-m-01'),
                    'end' => date('Y-m-t'),
                );
        }
    }
    
    /**
     * Get previous period range for comparison
     * 
     * @param string $period Period type
     * @param string $start Current start date
     * @param string $end Current end date
     * @return array
     */
    private static function get_previous_period_range($period, $start, $end) {
        $start_ts = strtotime($start);
        $end_ts = strtotime($end);
        $days_diff = ($end_ts - $start_ts) / (60 * 60 * 24);
        
        $prev_end = date('Y-m-d', $start_ts - 86400); // Day before start
        $prev_start = date('Y-m-d', $start_ts - ($days_diff * 86400) - 86400);
        
        return array(
            'start' => $prev_start,
            'end' => $prev_end,
        );
    }
    
    /**
     * Get comprehensive marketing analytics
     * 
     * @param int $org_id Organization ID
     * @param string $period Period: 'day', 'week', 'month', 'quarter', 'year'
     * @param string $start_date Optional start date (Y-m-d)
     * @param string $end_date Optional end date (Y-m-d)
     * @return array
     */
    public static function get_marketing_analytics($org_id, $period = 'month', $start_date = null, $end_date = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Calculate date range
        $date_range = self::calculate_date_range($period, $start_date, $end_date);
        $start = $date_range['start'];
        $end = $date_range['end'];
        
        // QR Code Analytics
        $qr_analytics = Rental_Gates_QR::get_organization_analytics($org_id, $period === 'month' ? 30 : ($period === 'week' ? 7 : 365));
        
        // Lead Analytics
        $total_leads = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at BETWEEN %s AND %s",
            $org_id, $start, $end . ' 23:59:59'
        )));
        
        // Leads by source
        $leads_by_source = $wpdb->get_results($wpdb->prepare(
            "SELECT source, COUNT(*) as count 
             FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at BETWEEN %s AND %s
             GROUP BY source",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // Leads by stage
        $leads_by_stage = $wpdb->get_results($wpdb->prepare(
            "SELECT stage, COUNT(*) as count 
             FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at BETWEEN %s AND %s
             GROUP BY stage",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // Conversion funnel
        $funnel = array(
            'scans' => $qr_analytics['total_scans'] ?? 0,
            'leads' => $total_leads,
            'applications' => intval($wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['applications']} 
                 WHERE organization_id = %d AND created_at BETWEEN %s AND %s",
                $org_id, $start, $end . ' 23:59:59'
            ))),
            'leases' => intval($wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['leases']} 
                 WHERE organization_id = %d AND created_at BETWEEN %s AND %s AND status = 'active'",
                $org_id, $start, $end . ' 23:59:59'
            ))),
        );
        
        // Calculate conversion rates
        $scan_to_lead_rate = $funnel['scans'] > 0 ? ($funnel['leads'] / $funnel['scans']) * 100 : 0;
        $lead_to_app_rate = $funnel['leads'] > 0 ? ($funnel['applications'] / $funnel['leads']) * 100 : 0;
        $app_to_lease_rate = $funnel['applications'] > 0 ? ($funnel['leases'] / $funnel['applications']) * 100 : 0;
        $overall_conversion = $funnel['scans'] > 0 ? ($funnel['leases'] / $funnel['scans']) * 100 : 0;
        
        // Lead scoring summary
        $lead_scores = array();
        if (class_exists('Rental_Gates_Lead_Scoring')) {
            $scored_leads = $wpdb->get_results($wpdb->prepare(
                "SELECT ls.score, COUNT(*) as count
                 FROM {$tables['lead_scores']} ls
                 JOIN {$tables['leads']} l ON ls.lead_id = l.id
                 WHERE l.organization_id = %d AND ls.created_at >= %s
                 GROUP BY ls.score
                 ORDER BY ls.score DESC",
                $org_id, $start
            ), ARRAY_A);
            
            $hot_leads = 0;
            $warm_leads = 0;
            $cool_leads = 0;
            $cold_leads = 0;
            
            foreach ($scored_leads as $row) {
                $score = intval($row['score']);
                $priority = Rental_Gates_Lead_Scoring::get_priority_level($score);
                switch ($priority) {
                    case 'hot':
                        $hot_leads += intval($row['count']);
                        break;
                    case 'warm':
                        $warm_leads += intval($row['count']);
                        break;
                    case 'cool':
                        $cool_leads += intval($row['count']);
                        break;
                    case 'cold':
                        $cold_leads += intval($row['count']);
                        break;
                }
            }
            
            $lead_scores = array(
                'hot' => $hot_leads,
                'warm' => $warm_leads,
                'cool' => $cool_leads,
                'cold' => $cold_leads,
            );
        }
        
        // Daily trend for leads
        $daily_leads = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as count 
             FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at BETWEEN %s AND %s
             GROUP BY DATE(created_at) 
             ORDER BY date ASC",
            $org_id, $start, $end . ' 23:59:59'
        ), ARRAY_A);
        
        // Previous period for comparison
        $prev_range = self::get_previous_period_range($period, $start, $end);
        $prev_leads = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at BETWEEN %s AND %s",
            $org_id, $prev_range['start'], $prev_range['end'] . ' 23:59:59'
        )));
        
        $lead_growth = $prev_leads > 0 ? (($total_leads - $prev_leads) / $prev_leads) * 100 : ($total_leads > 0 ? 100 : 0);
        
        return array(
            'period' => $period,
            'start_date' => $start,
            'end_date' => $end,
            'qr_analytics' => $qr_analytics,
            'total_leads' => $total_leads,
            'leads_by_source' => $leads_by_source,
            'leads_by_stage' => $leads_by_stage,
            'funnel' => $funnel,
            'conversion_rates' => array(
                'scan_to_lead' => round($scan_to_lead_rate, 2),
                'lead_to_application' => round($lead_to_app_rate, 2),
                'application_to_lease' => round($app_to_lease_rate, 2),
                'overall' => round($overall_conversion, 2),
            ),
            'lead_scores' => $lead_scores,
            'daily_leads' => $daily_leads,
            'lead_growth' => round($lead_growth, 2),
            'previous_leads' => $prev_leads,
        );
    }
}
