<?php
/**
 * Rental Gates Auth Class
 * Handles user authentication, registration, and login
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Auth
{

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('wp_ajax_nopriv_rental_gates_login', array($this, 'ajax_login'));
        add_action('wp_ajax_nopriv_rental_gates_register', array($this, 'ajax_register'));
        add_action('wp_ajax_rental_gates_logout', array($this, 'ajax_logout'));

        // Password reset
        add_action('wp_ajax_nopriv_rental_gates_forgot_password', array($this, 'ajax_forgot_password'));
        add_action('wp_ajax_nopriv_rental_gates_reset_password', array($this, 'ajax_reset_password'));
        add_action('wp_ajax_nopriv_rental_gates_send_magic_link', array($this, 'ajax_send_magic_link'));
    }

    /**
     * Process registration from REST API
     */
    public static function process_registration($request)
    {
        // Rate limit
        $rate_check = Rental_Gates_Rate_Limit::check('auth_register');
        if (is_wp_error($rate_check)) {
            return Rental_Gates_REST_API::error(
                $rate_check->get_error_message(),
                'rate_limited',
                429
            );
        }

        // Get and validate data
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $name = sanitize_text_field($request->get_param('name'));
        $organization_name = sanitize_text_field($request->get_param('organization_name'));
        $phone = Rental_Gates_Security::sanitize_phone($request->get_param('phone'));

        // Get plan selection
        $plan_slug = sanitize_text_field($request->get_param('plan') ?? 'free');
        $billing_cycle = sanitize_text_field($request->get_param('billing') ?? 'monthly');

        // Validate plan - map landing page slugs to database slugs if needed
        $plan_mapping = array(
            'free' => 'free',
            'starter' => 'starter',
            'professional' => 'professional',
            'enterprise' => 'enterprise',
            // Legacy mappings
            'basic' => 'starter',
            'silver' => 'professional',
            'gold' => 'enterprise',
        );

        if (!array_key_exists($plan_slug, $plan_mapping)) {
            $plan_slug = 'free';
        }

        if (!in_array($billing_cycle, array('monthly', 'yearly'))) {
            $billing_cycle = 'monthly';
        }

        // Validation
        $errors = array();

        if (empty($email)) {
            $errors[] = __('Email is required', 'rental-gates');
        } elseif (!is_email($email)) {
            $errors[] = __('Invalid email address', 'rental-gates');
        } elseif (email_exists($email)) {
            $errors[] = __('Email already registered', 'rental-gates');
        }

        if (empty($password)) {
            $errors[] = __('Password is required', 'rental-gates');
        } elseif (strlen($password) < 8) {
            $errors[] = __('Password must be at least 8 characters', 'rental-gates');
        }

        if (empty($name)) {
            $errors[] = __('Name is required', 'rental-gates');
        }

        if (empty($organization_name)) {
            $errors[] = __('Organization name is required', 'rental-gates');
        }

        if (!empty($errors)) {
            return Rental_Gates_REST_API::error(
                implode(', ', $errors),
                'validation_error',
                400
            );
        }

        // Start transaction
        global $wpdb;
        $wpdb->query('START TRANSACTION');

        try {
            // Create WordPress user
            $user_id = wp_create_user($email, $password, $email);

            if (is_wp_error($user_id)) {
                throw new Exception($user_id->get_error_message());
            }

            // Update user meta
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $name,
                'first_name' => explode(' ', $name)[0],
                'last_name' => implode(' ', array_slice(explode(' ', $name), 1)),
            ));

            // Assign owner role
            $user = get_user_by('ID', $user_id);
            $user->set_role('rental_gates_owner');

            // Create organization with plan
            $org_data = array(
                'name' => $organization_name,
                'contact_email' => $email,
                'contact_phone' => $phone,
                'plan_id' => $plan_slug,
            );

            $organization = Rental_Gates_Organization::create($org_data);

            if (is_wp_error($organization)) {
                throw new Exception($organization->get_error_message());
            }

            // Add user as primary owner
            Rental_Gates_Organization::add_member($organization['id'], $user_id, 'owner', true);

            // Create subscription record
            $subscription_data = self::create_subscription($organization['id'], $plan_slug, $billing_cycle);

            // Commit transaction
            $wpdb->query('COMMIT');

            // Log user in
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, true);

            // Send welcome email
            Rental_Gates_Email::send_welcome($user_id, $organization['id']);

            // Log activity
            self::log_registration($user_id, $organization['id']);

            // Build response
            $response_data = array(
                'user' => array(
                    'id' => $user_id,
                    'name' => $name,
                    'email' => $email,
                ),
                'organization' => $organization,
                'subscription' => $subscription_data,
                'plan' => $plan_slug,
                'billing_cycle' => $billing_cycle,
                'redirect_url' => home_url('/rental-gates/dashboard'),
            );

            // For paid plans requiring payment, redirect to checkout page
            if (!empty($subscription_data['payment_required'])) {
                $response_data['redirect_url'] = add_query_arg(array(
                    'subscription_id' => $subscription_data['subscription_id'],
                    'plan' => $plan_slug,
                    'billing' => $billing_cycle,
                ), home_url('/rental-gates/checkout'));
                $response_data['payment_required'] = true;
            }

            return Rental_Gates_REST_API::success($response_data, __('Registration successful', 'rental-gates'), 201);

        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');

            // Clean up user if created
            if (isset($user_id) && !is_wp_error($user_id)) {
                wp_delete_user($user_id);
            }

            return Rental_Gates_REST_API::error(
                $e->getMessage(),
                'registration_failed',
                500
            );
        }
    }

    /**
     * Create subscription for organization
     * 
     * @param int $organization_id
     * @param string $plan_slug
     * @param string $billing_cycle
     * @return array Subscription data including payment_required flag
     */
    private static function create_subscription($organization_id, $plan_slug, $billing_cycle)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        // Plan price mapping (hardcoded to ensure consistency)
        $plan_prices = array(
            'free' => array('monthly' => 0, 'yearly' => 0, 'trial_days' => 0),
            'starter' => array('monthly' => 19, 'yearly' => 180, 'trial_days' => 0),
            'professional' => array('monthly' => 49, 'yearly' => 468, 'trial_days' => 0),
            'enterprise' => array('monthly' => 149, 'yearly' => 1428, 'trial_days' => 0),
        );

        // Get plan details from database
        $plan = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['plans']} WHERE slug = %s AND is_active = 1",
            $plan_slug
        ), ARRAY_A);

        // If plan not found in DB, use hardcoded values
        if (!$plan && isset($plan_prices[$plan_slug])) {
            $plan = array(
                'id' => null,
                'slug' => $plan_slug,
                'price_monthly' => $plan_prices[$plan_slug]['monthly'],
                'price_yearly' => $plan_prices[$plan_slug]['yearly'],
                'trial_days' => $plan_prices[$plan_slug]['trial_days'],
            );
        }

        // Final fallback to free
        if (!$plan) {
            $plan_slug = 'free';
            $plan = array(
                'id' => null,
                'slug' => 'free',
                'price_monthly' => 0,
                'price_yearly' => 0,
                'trial_days' => 0,
            );
        }

        $is_free = ($plan_slug === 'free' || floatval($plan['price_monthly']) == 0);
        $trial_days = intval($plan['trial_days'] ?? 0);
        $has_trial = !$is_free && $trial_days > 0;

        // Calculate amount
        $amount = $billing_cycle === 'yearly'
            ? floatval($plan['price_yearly'])
            : floatval($plan['price_monthly']);

        // Calculate subscription dates
        $now = current_time('mysql');
        $period_start = $now;
        $period_end = null;
        $trial_end = null;

        // Determine status
        if ($is_free) {
            $status = 'active';
        } elseif ($has_trial) {
            $status = 'trialing';
            $trial_end = date('Y-m-d H:i:s', strtotime("+{$trial_days} days"));
            $period_end = $trial_end;
        } else {
            // Paid plan without trial - requires payment
            $status = 'pending_payment';
        }

        // Insert subscription record
        $subscription_data = array(
            'organization_id' => $organization_id,
            'plan_id' => $plan['id'] ?? null,
            'plan_slug' => $plan_slug,
            'status' => $status,
            'billing_cycle' => $billing_cycle,
            'current_period_start' => $period_start,
            'current_period_end' => $period_end,
            'trial_end' => $trial_end,
            'amount' => $amount,
            'currency' => 'USD',
            'created_at' => $now,
            'updated_at' => $now,
        );

        $wpdb->insert($tables['subscriptions'], $subscription_data);
        $subscription_id = $wpdb->insert_id;

        // Update organization with plan (set to free until payment confirmed for paid plans)
        $wpdb->update(
            $tables['organizations'],
            array('plan_id' => $is_free ? $plan_slug : 'free'), // Start with free, upgrade after payment
            array('id' => $organization_id)
        );

        $result = array(
            'subscription_id' => $subscription_id,
            'plan_slug' => $plan_slug,
            'status' => $status,
            'trial_days' => $trial_days,
            'has_trial' => $has_trial,
            'is_free' => $is_free,
            'amount' => $amount,
            'billing_cycle' => $billing_cycle,
            'payment_required' => !$is_free && !$has_trial,
        );

        return $result;
    }

    /**
     * Create Stripe Checkout session for subscription
     * 
     * @param int $organization_id
     * @param array $plan
     * @param string $billing_cycle
     * @return string|null Checkout URL or null
     */
    private static function create_stripe_checkout($organization_id, $plan, $billing_cycle)
    {
        // Check if Stripe is configured
        $stripe_secret = get_option('rental_gates_stripe_secret_key', '');
        if (empty($stripe_secret)) {
            return null;
        }

        // This would integrate with Stripe to create a checkout session
        // For now, return null to use trial-based flow
        // Full implementation would use Stripe PHP SDK

        return null;
    }

    /**
     * AJAX login handler
     */
    public function ajax_login()
    {
        check_ajax_referer('rental_gates_nonce', 'nonce');

        // Rate limit
        $rate_check = Rental_Gates_Rate_Limit::check('auth_login');
        if (is_wp_error($rate_check)) {
            wp_send_json_error(array(
                'message' => $rate_check->get_error_message(),
            ), 429);
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = !empty($_POST['remember']);

        if (empty($email) || empty($password)) {
            wp_send_json_error(array(
                'message' => __('Email and password are required', 'rental-gates'),
            ));
        }

        $user = wp_authenticate($email, $password);

        if (is_wp_error($user)) {
            // Log failed attempt
            self::log_failed_login($email);

            wp_send_json_error(array(
                'message' => __('Invalid email or password', 'rental-gates'),
            ));
        }

        // Check if user has a Rental Gates role
        if (!Rental_Gates_Roles::is_rental_gates_user($user->ID)) {
            global $wpdb;
            $tables = Rental_Gates_Database::get_table_names();

            // Check if there's a tenant record with this email that isn't linked yet
            if (class_exists('Rental_Gates_Tenant')) {
                // Find unlinked tenant with this email
                $tenant = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, organization_id FROM {$tables['tenants']} 
                     WHERE email = %s AND user_id IS NULL AND status = 'active' 
                     LIMIT 1",
                    $user->user_email
                ), ARRAY_A);

                if ($tenant) {
                    // Auto-link the tenant to this user
                    $link_result = Rental_Gates_Tenant::link_to_user($tenant['id'], $user->ID);

                    if (!is_wp_error($link_result)) {
                        // Now they should have access - continue with login
                        wp_set_current_user($user->ID);
                        wp_set_auth_cookie($user->ID, $remember);

                        $redirect_url = Rental_Gates_Roles::get_dashboard_url($user->ID);
                        self::log_successful_login($user->ID);

                        wp_send_json_success(array(
                            'user' => array(
                                'id' => $user->ID,
                                'name' => $user->display_name,
                                'email' => $user->user_email,
                            ),
                            'redirect_url' => $redirect_url,
                        ));
                    }
                }
            }

            // Check if there's a vendor record with this email that isn't linked yet
            if (class_exists('Rental_Gates_Vendor')) {
                // Find unlinked vendor with this email
                $vendor = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, organization_id FROM {$tables['vendors']} 
                     WHERE contact_email = %s AND user_id IS NULL AND status = 'active' 
                     LIMIT 1",
                    $user->user_email
                ), ARRAY_A);

                if ($vendor) {
                    // Auto-link the vendor to this user
                    $link_result = Rental_Gates_Vendor::link_to_user($vendor['id'], $user->ID);

                    if (!is_wp_error($link_result)) {
                        // Now they should have access - continue with login
                        wp_set_current_user($user->ID);
                        wp_set_auth_cookie($user->ID, $remember);

                        $redirect_url = Rental_Gates_Roles::get_dashboard_url($user->ID);
                        self::log_successful_login($user->ID);

                        wp_send_json_success(array(
                            'user' => array(
                                'id' => $user->ID,
                                'name' => $user->display_name,
                                'email' => $user->user_email,
                            ),
                            'redirect_url' => $redirect_url,
                        ));
                    }
                }
            }

            wp_send_json_error(array(
                'message' => __('Your account does not have access to this portal. Please contact your property manager.', 'rental-gates'),
            ));
        }

        // Set auth cookie
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);

        // Get redirect URL
        $redirect_url = Rental_Gates_Roles::get_dashboard_url($user->ID);

        // Log successful login
        self::log_successful_login($user->ID);

        wp_send_json_success(array(
            'user' => array(
                'id' => $user->ID,
                'name' => $user->display_name,
                'email' => $user->user_email,
            ),
            'redirect_url' => $redirect_url,
        ));
    }

    /**
     * AJAX register handler
     */
    public function ajax_register()
    {
        check_ajax_referer('rental_gates_nonce', 'nonce');

        // Create a mock request object for the REST handler
        $request = new WP_REST_Request('POST');
        $request->set_param('email', $_POST['email'] ?? '');
        $request->set_param('password', $_POST['password'] ?? '');
        $request->set_param('name', $_POST['name'] ?? '');
        $request->set_param('organization_name', $_POST['organization_name'] ?? '');
        $request->set_param('phone', $_POST['phone'] ?? '');
        $request->set_param('plan', $_POST['plan'] ?? 'free');
        $request->set_param('billing', $_POST['billing'] ?? 'monthly');

        $result = self::process_registration($request);

        if (is_wp_error($result)) {
            wp_send_json_error(array(
                'message' => $result->get_error_message(),
            ));
        }

        $data = $result->get_data();

        if (!$data['success']) {
            wp_send_json_error(array(
                'message' => $data['message'],
            ));
        }

        wp_send_json_success($data['data']);
    }

    /**
     * AJAX logout handler
     */
    public function ajax_logout()
    {
        wp_logout();

        wp_send_json_success(array(
            'redirect_url' => home_url('/rental-gates/login'),
        ));
    }

    /**
     * AJAX forgot password handler
     */
    public function ajax_forgot_password()
    {
        check_ajax_referer('rental_gates_nonce', 'nonce');

        // Rate limit
        $rate_check = Rental_Gates_Rate_Limit::check('auth_password_reset');
        if (is_wp_error($rate_check)) {
            wp_send_json_error(array(
                'message' => $rate_check->get_error_message(),
            ), 429);
        }

        $email = sanitize_email($_POST['email'] ?? '');

        if (empty($email)) {
            wp_send_json_error(array(
                'message' => __('Email is required', 'rental-gates'),
            ));
        }

        $user = get_user_by('email', $email);

        // Always return success to prevent email enumeration
        $message = __('If an account exists with this email, a password reset link has been sent.', 'rental-gates');

        if ($user) {
            $result = retrieve_password($email);

            if (is_wp_error($result)) {
                // Log but don't expose error
                error_log('Rental Gates: Password reset failed - ' . $result->get_error_message());
            }
        }

        wp_send_json_success(array(
            'message' => $message,
        ));
    }

    /**
     * AJAX reset password handler
     */
    public function ajax_reset_password()
    {
        check_ajax_referer('rental_gates_nonce', 'nonce');

        $key = sanitize_text_field($_POST['key'] ?? '');
        $login = sanitize_text_field($_POST['login'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (empty($key) || empty($login) || empty($password)) {
            wp_send_json_error(array(
                'message' => __('All fields are required', 'rental-gates'),
            ));
        }

        if ($password !== $confirm) {
            wp_send_json_error(array(
                'message' => __('Passwords do not match', 'rental-gates'),
            ));
        }

        if (strlen($password) < 8) {
            wp_send_json_error(array(
                'message' => __('Password must be at least 8 characters', 'rental-gates'),
            ));
        }

        // Verify reset key
        $user = check_password_reset_key($key, $login);

        if (is_wp_error($user)) {
            wp_send_json_error(array(
                'message' => __('Invalid or expired reset link', 'rental-gates'),
            ));
        }

        // Reset password
        reset_password($user, $password);

        wp_send_json_success(array(
            'message' => __('Password has been reset. You can now log in.', 'rental-gates'),
            'redirect_url' => home_url('/rental-gates/login'),
        ));
    }

    /**
     * Create tenant portal account
     */
    public static function create_tenant_account($tenant_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $tenant = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['tenants']} WHERE id = %d",
            $tenant_id
        ), ARRAY_A);

        if (!$tenant) {
            return new WP_Error('not_found', __('Tenant not found', 'rental-gates'));
        }

        // Check if user already exists
        if ($tenant['user_id']) {
            return new WP_Error('exists', __('Account already exists', 'rental-gates'));
        }

        $existing_user = get_user_by('email', $tenant['email']);
        if ($existing_user) {
            // Link existing user
            $wpdb->update(
                $tables['tenants'],
                array('user_id' => $existing_user->ID),
                array('id' => $tenant_id)
            );

            $existing_user->add_role('rental_gates_tenant');

            return $existing_user->ID;
        }

        // Create new user
        $password = wp_generate_password(16);
        $user_id = wp_create_user($tenant['email'], $password, $tenant['email']);

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        // Update user
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $tenant['first_name'] . ' ' . $tenant['last_name'],
            'first_name' => $tenant['first_name'],
            'last_name' => $tenant['last_name'],
        ));

        // Assign role
        $user = get_user_by('ID', $user_id);
        $user->set_role('rental_gates_tenant');

        // Link to tenant record
        $wpdb->update(
            $tables['tenants'],
            array('user_id' => $user_id),
            array('id' => $tenant_id)
        );

        // Send invitation email
        Rental_Gates_Email::send($tenant['email'], 'tenant_invitation', array(
            'tenant_name' => $tenant['first_name'],
            'temp_password' => $password,
            'login_url' => home_url('/rental-gates/login'),
            'message' => __('Your tenant portal account has been created. Please log in and change your password.', 'rental-gates'),
            'action_url' => home_url('/rental-gates/login'),
            'action_text' => __('Log In', 'rental-gates'),
        ));

        return $user_id;
    }

    /**
     * Create vendor portal account
     */
    public static function create_vendor_account($vendor_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $vendor = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['vendors']} WHERE id = %d",
            $vendor_id
        ), ARRAY_A);

        if (!$vendor) {
            return new WP_Error('not_found', __('Vendor not found', 'rental-gates'));
        }

        if ($vendor['user_id']) {
            return new WP_Error('exists', __('Account already exists', 'rental-gates'));
        }

        $existing_user = get_user_by('email', $vendor['email']);
        if ($existing_user) {
            $wpdb->update(
                $tables['vendors'],
                array('user_id' => $existing_user->ID),
                array('id' => $vendor_id)
            );

            $existing_user->add_role('rental_gates_vendor');

            return $existing_user->ID;
        }

        // Create new user
        $password = wp_generate_password(16);
        $user_id = wp_create_user($vendor['email'], $password, $vendor['email']);

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $vendor['contact_name'],
        ));

        $user = get_user_by('ID', $user_id);
        $user->set_role('rental_gates_vendor');

        $wpdb->update(
            $tables['vendors'],
            array('user_id' => $user_id),
            array('id' => $vendor_id)
        );

        // Send invitation
        Rental_Gates_Email::send($vendor['email'], 'staff_invitation', array(
            'user_name' => $vendor['contact_name'],
            'temp_password' => $password,
            'login_url' => home_url('/rental-gates/login'),
            'message' => __('Your vendor portal account has been created. Please log in and change your password.', 'rental-gates'),
            'action_url' => home_url('/rental-gates/login'),
            'action_text' => __('Log In', 'rental-gates'),
        ));

        return $user_id;
    }

    /**
     * Log registration
     */
    private static function log_registration($user_id, $org_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $wpdb->insert(
            $tables['activity_log'],
            array(
                'user_id' => $user_id,
                'organization_id' => $org_id,
                'action' => 'user_registered',
                'entity_type' => 'user',
                'entity_id' => $user_id,
                'ip_address' => Rental_Gates_Security::get_client_ip(),
                'user_agent' => isset($_SERVER['HTTP_USER_AGENT'])
                    ? sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT'], 0, 500))
                    : '',
                'created_at' => current_time('mysql'),
            )
        );
    }

    /**
     * Log successful login
     */
    private static function log_successful_login($user_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $wpdb->insert(
            $tables['activity_log'],
            array(
                'user_id' => $user_id,
                'organization_id' => Rental_Gates_Roles::get_organization_id($user_id),
                'action' => 'user_login',
                'entity_type' => 'user',
                'entity_id' => $user_id,
                'ip_address' => Rental_Gates_Security::get_client_ip(),
                'created_at' => current_time('mysql'),
            )
        );
    }

    /**
     * Helper: Generate & Store Magic Token
     */
    private static function generate_magic_token($user_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $token = wp_generate_password(64, false);
        $hashed_token = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        // Clean up old tokens first
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$tables['magic_links']} WHERE user_id = %d",
            $user_id
        ));

        $wpdb->insert(
            $tables['magic_links'],
            array(
                'user_id' => $user_id,
                'token' => $hashed_token,
                'expires_at' => $expires,
                'ip_address' => Rental_Gates_Security::get_client_ip(),
                'created_at' => current_time('mysql'),
            )
        );

        return $token; // Return raw token for the email link
    }

    /**
     * Public Method: Verify Magic Token
     */
    public static function verify_magic_token($raw_token)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $hashed_token = hash('sha256', $raw_token);

        $link = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['magic_links']} 
             WHERE token = %s 
             AND used_at IS NULL 
             AND expires_at > NOW()",
            $hashed_token
        ));

        if (!$link) {
            return new WP_Error('invalid_token', __('Invalid or expired login link.', 'rental-gates'));
        }

        // Mark used
        $wpdb->update(
            $tables['magic_links'],
            array('used_at' => current_time('mysql')),
            array('id' => $link->id)
        );

        // Login User
        wp_set_current_user($link->user_id);
        wp_set_auth_cookie($link->user_id, true);

        // Log
        self::log_successful_login($link->user_id);

        return $link->user_id;
    }

    /**
     * AJAX Handler: Send Magic Link
     */
    public function ajax_send_magic_link()
    {
        check_ajax_referer('rental_gates_nonce', 'nonce');

        $email = sanitize_email($_POST['email'] ?? '');
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(array('message' => __('Please enter a valid email.', 'rental-gates')));
        }

        // Rate limit
        $rate_check = Rental_Gates_Rate_Limit::check('auth_magic_link', 3, 300); // 3 per 5 mins
        if (is_wp_error($rate_check)) {
            wp_send_json_error(array('message' => __('Too many attempts. Please wait.', 'rental-gates')), 429);
        }

        $user = get_user_by('email', $email);

        // Always say success for security
        if (!$user) {
            wp_send_json_success(array('message' => __('If an account exists, a login link has been sent.', 'rental-gates')));
        }

        $token = self::generate_magic_token($user->ID);
        $link = home_url('/rental-gates/magic-login?token=' . $token);

        Rental_Gates_Email::send($email, 'magic_link', array(
            'login_url' => $link,
            'name' => $user->display_name
        ));

        wp_send_json_success(array('message' => __('If an account exists, a login link has been sent.', 'rental-gates')));
    }

    /**
     * Log failed login
     */
    private static function log_failed_login($email)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $wpdb->insert(
            $tables['activity_log'],
            array(
                'user_id' => 0,
                'action' => 'login_failed',
                'new_values' => wp_json_encode(array('email' => $email)),
                'ip_address' => Rental_Gates_Security::get_client_ip(),
                'created_at' => current_time('mysql'),
            )
        );

        // Check for brute force
        $failed_attempts = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['activity_log']} 
             WHERE action = 'login_failed' 
             AND ip_address = %s 
             AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
            Rental_Gates_Security::get_client_ip()
        ));

        if ($failed_attempts >= 10) {
            Rental_Gates_Rate_Limit::block_ip(
                Rental_Gates_Security::get_client_ip(),
                3600,
                'Too many failed login attempts'
            );
        }
    }
}
