<?php
/**
 * Rental Gates QR Code Generator
 * 
 * Features:
 * - Generate QR codes for buildings, units, organizations
 * - Track scans with analytics
 * - Bulk generation
 * - Multiple size options
 * - Download functionality
 * 
 * @version 2.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_QR {
    
    /**
     * QR code sizes
     */
    const SIZES = array(
        'small' => 150,
        'medium' => 300,
        'large' => 500,
        'print' => 1000,
    );
    
    /**
     * Generate QR code for building
     */
    public function generate_for_building($building_id, $size = 'medium') {
        return $this->generate('building', $building_id, $size);
    }
    
    /**
     * Generate QR code for unit
     */
    public function generate_for_unit($unit_id, $size = 'medium') {
        return $this->generate('unit', $unit_id, $size);
    }
    
    /**
     * Generate QR code for organization
     */
    public function generate_for_organization($org_id, $size = 'medium') {
        return $this->generate('organization', $org_id, $size);
    }
    
    /**
     * Generate QR code for custom URL
     */
    public function generate_custom($url, $org_id, $label = '', $size = 'medium') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $code = Rental_Gates_Security::generate_qr_code();
        $size_px = self::SIZES[$size] ?? self::SIZES['medium'];
        
        // Store in database
        $wpdb->insert($tables['qr_codes'], array(
            'organization_id' => intval($org_id),
            'type' => 'custom',
            'entity_id' => 0,
            'code' => $code,
            'destination_url' => $url,
            'label' => sanitize_text_field($label),
            'created_at' => current_time('mysql'),
        ));
        
        $qr_image = $this->get_qr_image_url($url, $size_px);
        
        return array(
            'id' => $wpdb->insert_id,
            'code' => $code,
            'url' => $url,
            'qr_image' => $qr_image,
            'size' => $size,
            'size_px' => $size_px,
        );
    }
    
    /**
     * Main generate function
     */
    private function generate($type, $id, $size = 'medium') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get organization ID
        $org_id = $this->get_org_id_for_entity($type, $id);
        if (!$org_id) {
            return new WP_Error('not_found', __('Entity not found', 'rental-gates'));
        }
        
        // Check for existing QR code
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['qr_codes']} WHERE type = %s AND entity_id = %d",
            $type, $id
        ), ARRAY_A);
        
        if ($existing) {
            // Return existing QR code with updated image URL
            $size_px = self::SIZES[$size] ?? self::SIZES['medium'];
            $url = $existing['destination_url'] ?: $this->get_destination_url($type, $id);
            
            return array(
                'id' => $existing['id'],
                'code' => $existing['code'],
                'url' => $url,
                'qr_image' => $this->get_qr_image_url($url, $size_px),
                'size' => $size,
                'size_px' => $size_px,
                'scan_count' => intval($existing['scan_count']),
                'last_scanned_at' => $existing['last_scanned_at'],
                'created_at' => $existing['created_at'],
            );
        }
        
        // Generate new QR code
        $code = Rental_Gates_Security::generate_qr_code();
        $url = $this->get_destination_url($type, $id);
        $size_px = self::SIZES[$size] ?? self::SIZES['medium'];
        
        // Build insert data - check for destination_url column (v2.7.0+)
        $insert_data = array(
            'organization_id' => $org_id,
            'type' => $type,
            'entity_id' => $id,
            'code' => $code,
            'created_at' => current_time('mysql'),
        );
        
        // Check if destination_url column exists (added in v2.7.0)
        $columns = $wpdb->get_col("DESCRIBE {$tables['qr_codes']}", 0);
        if (in_array('destination_url', $columns)) {
            $insert_data['destination_url'] = $url;
        }
        
        $wpdb->insert($tables['qr_codes'], $insert_data);
        
        $qr_image = $this->get_qr_image_url($url, $size_px);
        
        return array(
            'id' => $wpdb->insert_id,
            'code' => $code,
            'url' => $url,
            'qr_image' => $qr_image,
            'size' => $size,
            'size_px' => $size_px,
            'scan_count' => 0,
            'last_scanned_at' => null,
            'created_at' => current_time('mysql'),
        );
    }
    
    /**
     * Bulk generate QR codes
     */
    public function bulk_generate($items, $size = 'medium') {
        $results = array();
        
        foreach ($items as $item) {
            if (isset($item['type']) && isset($item['id'])) {
                $result = $this->generate($item['type'], $item['id'], $size);
                if (!is_wp_error($result)) {
                    $results[] = $result;
                }
            }
        }
        
        return $results;
    }
    
    /**
     * Generate QR codes for all buildings in organization
     */
    public function generate_all_buildings($org_id, $size = 'medium') {
        $buildings = Rental_Gates_Building::get_for_organization($org_id, array('per_page' => 1000));
        
        $items = array();
        foreach ($buildings['items'] as $building) {
            $items[] = array('type' => 'building', 'id' => $building['id']);
        }
        
        return $this->bulk_generate($items, $size);
    }
    
    /**
     * Generate QR codes for all units in organization
     */
    public function generate_all_units($org_id, $size = 'medium') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $units = $wpdb->get_results($wpdb->prepare(
            "SELECT id FROM {$tables['units']} WHERE organization_id = %d",
            $org_id
        ), ARRAY_A);
        
        $items = array();
        foreach ($units as $unit) {
            $items[] = array('type' => 'unit', 'id' => $unit['id']);
        }
        
        return $this->bulk_generate($items, $size);
    }
    
    /**
     * Get QR code by ID
     */
    public static function get($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $qr = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['qr_codes']} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$qr) {
            return null;
        }
        
        return self::format_qr($qr);
    }
    
    /**
     * Get QR code by code string
     */
    public static function get_by_code($code) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $qr = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['qr_codes']} WHERE code = %s",
            $code
        ), ARRAY_A);
        
        if (!$qr) {
            return null;
        }
        
        return self::format_qr($qr);
    }
    
    /**
     * Get all QR codes for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'type' => null,
            'page' => 1,
            'per_page' => 20,
            'orderby' => 'created_at',
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('organization_id = %d');
        $values = array($org_id);
        
        if ($args['type']) {
            $where[] = 'type = %s';
            $values[] = $args['type'];
        }
        
        $where_clause = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';
        $offset = ($args['page'] - 1) * $args['per_page'];
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$tables['qr_codes']} WHERE {$where_clause} ORDER BY {$orderby} LIMIT %d OFFSET %d",
            array_merge($values, array($args['per_page'], $offset))
        );
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        $qr_codes = array();
        foreach ($results as $row) {
            $qr_codes[] = self::format_qr($row);
        }
        
        // Get total count
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['qr_codes']} WHERE {$where_clause}",
            $values
        ));
        
        return array(
            'items' => $qr_codes,
            'total' => intval($total),
            'pages' => ceil($total / $args['per_page']),
        );
    }
    
    /**
     * Track a QR code scan
     */
    public static function track_scan($qr_code, $type = null, $entity_id = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get QR code record
        $qr = $wpdb->get_row($wpdb->prepare(
            "SELECT id, organization_id FROM {$tables['qr_codes']} WHERE code = %s",
            $qr_code
        ), ARRAY_A);
        
        if (!$qr) {
            return false;
        }
        
        // Check which columns exist in qr_scans table
        $scan_columns = $wpdb->get_col("DESCRIBE {$tables['qr_scans']}", 0);
        
        // Build insert data based on available columns
        $insert_data = array(
            'qr_code_id' => $qr['id'],
            'ip_address' => self::get_client_ip(),
            'user_agent' => sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500)),
            'referrer' => sanitize_text_field($_SERVER['HTTP_REFERER'] ?? ''),
            'scanned_at' => current_time('mysql'),
        );
        
        // Add optional columns if they exist
        if (in_array('organization_id', $scan_columns)) {
            $insert_data['organization_id'] = $qr['organization_id'];
        }
        if (in_array('country', $scan_columns)) {
            $insert_data['country'] = self::get_country_from_ip();
        }
        if (in_array('device_type', $scan_columns)) {
            $insert_data['device_type'] = self::get_device_type();
        }
        
        // Record scan
        $wpdb->insert($tables['qr_scans'], $insert_data);
        
        // Trigger marketing automation
        if (class_exists('Rental_Gates_Marketing_Automation')) {
            Rental_Gates_Marketing_Automation::process_trigger(
                Rental_Gates_Marketing_Automation::TRIGGER_QR_SCAN,
                $qr['id'],
                'qr_code',
                $qr['organization_id'],
                array(
                    'qr_code_id' => $qr['id'],
                    'type' => $type,
                    'entity_id' => $entity_id,
                )
            );
        }
        
        // Check which columns exist in qr_codes table
        $qr_columns = $wpdb->get_col("DESCRIBE {$tables['qr_codes']}", 0);
        
        // Update scan count on QR code if column exists
        if (in_array('scan_count', $qr_columns) && in_array('last_scanned_at', $qr_columns)) {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$tables['qr_codes']} SET scan_count = scan_count + 1, last_scanned_at = %s WHERE id = %d",
                current_time('mysql'),
                $qr['id']
            ));
        } elseif (in_array('scan_count', $qr_columns)) {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$tables['qr_codes']} SET scan_count = scan_count + 1 WHERE id = %d",
                $qr['id']
            ));
        }
        
        return true;
    }
    
    /**
     * Get scan analytics for a QR code
     */
    public static function get_scan_analytics($qr_id, $days = 30) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $start_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        // Get daily scan counts
        $daily = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(scanned_at) as date, COUNT(*) as count 
             FROM {$tables['qr_scans']} 
             WHERE qr_code_id = %d AND scanned_at >= %s 
             GROUP BY DATE(scanned_at) 
             ORDER BY date ASC",
            $qr_id, $start_date
        ), ARRAY_A);
        
        // Check if device_type column exists (added in v2.7.0)
        $columns = $wpdb->get_col("DESCRIBE {$tables['qr_scans']}", 0);
        $has_device_type = in_array('device_type', $columns);
        $has_country = in_array('country', $columns);
        
        // Get device breakdown (only if column exists)
        $devices = array();
        if ($has_device_type) {
            $devices = $wpdb->get_results($wpdb->prepare(
                "SELECT device_type, COUNT(*) as count 
                 FROM {$tables['qr_scans']} 
                 WHERE qr_code_id = %d AND scanned_at >= %s 
                 GROUP BY device_type",
                $qr_id, $start_date
            ), ARRAY_A);
        }
        
        // Get geographic breakdown
        $geographic = array();
        if ($has_country) {
            $geographic = $wpdb->get_results($wpdb->prepare(
                "SELECT country, COUNT(*) as count 
                 FROM {$tables['qr_scans']} 
                 WHERE qr_code_id = %d AND scanned_at >= %s AND country IS NOT NULL AND country != ''
                 GROUP BY country 
                 ORDER BY count DESC 
                 LIMIT 10",
                $qr_id, $start_date
            ), ARRAY_A);
        }
        
        // Get hourly distribution
        $hourly = $wpdb->get_results($wpdb->prepare(
            "SELECT HOUR(scanned_at) as hour, COUNT(*) as count 
             FROM {$tables['qr_scans']} 
             WHERE qr_code_id = %d AND scanned_at >= %s 
             GROUP BY HOUR(scanned_at) 
             ORDER BY hour ASC",
            $qr_id, $start_date
        ), ARRAY_A);
        
        // Get total scans
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['qr_scans']} WHERE qr_code_id = %d AND scanned_at >= %s",
            $qr_id, $start_date
        ));
        
        // Get unique IPs (approximate unique visitors)
        $unique = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_address) FROM {$tables['qr_scans']} WHERE qr_code_id = %d AND scanned_at >= %s",
            $qr_id, $start_date
        ));
        
        // Get scans from previous period for comparison
        $prev_start_date = date('Y-m-d H:i:s', strtotime("-{$days} days", strtotime($start_date)));
        $prev_total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['qr_scans']} WHERE qr_code_id = %d AND scanned_at >= %s AND scanned_at < %s",
            $qr_id, $prev_start_date, $start_date
        ));
        
        // Calculate growth
        $growth = 0;
        if ($prev_total > 0) {
            $growth = round((($total - $prev_total) / $prev_total) * 100, 1);
        } elseif ($total > 0) {
            $growth = 100; // New scans
        }
        
        // Get conversion data (leads created from this QR)
        $qr = self::get($qr_id);
        $conversions = 0;
        if ($qr) {
            $lead_source = $qr['type'] === 'building' ? 'qr_building' : 'qr_unit';
            $conversions = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['leads']} 
                 WHERE organization_id = %d 
                 AND source = %s 
                 AND source_id = %d 
                 AND created_at >= %s",
                $qr['organization_id'], $lead_source, $qr['entity_id'], $start_date
            ));
        }
        
        // Calculate conversion rate
        $conversion_rate = $total > 0 ? round(($conversions / $total) * 100, 2) : 0;
        
        // Get applications from QR leads
        $applications = 0;
        if ($qr) {
            $lead_source = $qr['type'] === 'building' ? 'qr_building' : 'qr_unit';
            $lead_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$tables['leads']} 
                 WHERE organization_id = %d 
                 AND source = %s 
                 AND source_id = %d 
                 AND created_at >= %s",
                $qr['organization_id'], $lead_source, $qr['entity_id'], $start_date
            ));
            
            if (!empty($lead_ids)) {
                $placeholders = implode(',', array_fill(0, count($lead_ids), '%d'));
                $applications = intval($wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$tables['applications']} 
                     WHERE organization_id = %d 
                     AND lead_id IN ($placeholders)",
                    array_merge(array($qr['organization_id']), $lead_ids)
                )));
            }
        }
        
        // Get leases from QR applications
        $leases = 0;
        if ($applications > 0 && !empty($lead_ids)) {
            $placeholders = implode(',', array_fill(0, count($lead_ids), '%d'));
            $application_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$tables['applications']} 
                 WHERE organization_id = %d 
                 AND lead_id IN ($placeholders)",
                array_merge(array($qr['organization_id']), $lead_ids)
            ));
            
            if (!empty($application_ids)) {
                $app_placeholders = implode(',', array_fill(0, count($application_ids), '%d'));
                $leases = intval($wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$tables['leases']} 
                     WHERE organization_id = %d 
                     AND application_id IN ($app_placeholders) 
                     AND status = 'active'",
                    array_merge(array($qr['organization_id']), $application_ids)
                )));
            }
        }
        
        return array(
            'total_scans' => intval($total),
            'unique_visitors' => intval($unique),
            'daily_scans' => $daily ?: array(),
            'device_breakdown' => $devices ?: array(),
            'geographic_breakdown' => $geographic ?: array(),
            'hourly_distribution' => $hourly ?: array(),
            'period_days' => $days,
            'growth_percentage' => $growth,
            'previous_period_scans' => intval($prev_total),
            'conversions' => array(
                'leads' => intval($conversions),
                'applications' => $applications,
                'leases' => $leases,
            ),
            'conversion_rates' => array(
                'scan_to_lead' => $total > 0 ? round(($conversions / $total) * 100, 2) : 0,
                'lead_to_application' => $conversions > 0 ? round(($applications / $conversions) * 100, 2) : 0,
                'application_to_lease' => $applications > 0 ? round(($leases / $applications) * 100, 2) : 0,
                'overall' => $total > 0 ? round(($leases / $total) * 100, 2) : 0,
            ),
        );
    }
    
    /**
     * Get organization-wide QR analytics
     */
    public static function get_organization_analytics($org_id, $days = 30) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $start_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        // Get total scans across all QR codes
        $total_scans = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['qr_scans']} qs
             JOIN {$tables['qr_codes']} qc ON qs.qr_code_id = qc.id
             WHERE qc.organization_id = %d AND qs.scanned_at >= %s",
            $org_id, $start_date
        ));
        
        // Get top performing QR codes
        $top_qr_codes = $wpdb->get_results($wpdb->prepare(
            "SELECT qc.id, qc.type, qc.entity_id, qc.code, COUNT(qs.id) as scan_count
             FROM {$tables['qr_codes']} qc
             LEFT JOIN {$tables['qr_scans']} qs ON qc.id = qs.qr_code_id AND qs.scanned_at >= %s
             WHERE qc.organization_id = %d
             GROUP BY qc.id
             ORDER BY scan_count DESC
             LIMIT 10",
            $start_date, $org_id
        ), ARRAY_A);
        
        // Get device breakdown
        $columns = $wpdb->get_col("DESCRIBE {$tables['qr_scans']}", 0);
        $has_device_type = in_array('device_type', $columns);
        
        $device_breakdown = array();
        if ($has_device_type) {
            $device_breakdown = $wpdb->get_results($wpdb->prepare(
                "SELECT qs.device_type, COUNT(*) as count
                 FROM {$tables['qr_scans']} qs
                 JOIN {$tables['qr_codes']} qc ON qs.qr_code_id = qc.id
                 WHERE qc.organization_id = %d AND qs.scanned_at >= %s
                 GROUP BY qs.device_type",
                $org_id, $start_date
            ), ARRAY_A);
        }
        
        // Get daily trend
        $daily_trend = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(qs.scanned_at) as date, COUNT(*) as count
             FROM {$tables['qr_scans']} qs
             JOIN {$tables['qr_codes']} qc ON qs.qr_code_id = qc.id
             WHERE qc.organization_id = %d AND qs.scanned_at >= %s
             GROUP BY DATE(qs.scanned_at)
             ORDER BY date ASC",
            $org_id, $start_date
        ), ARRAY_A);
        
        return array(
            'total_scans' => intval($total_scans),
            'total_qr_codes' => intval($wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['qr_codes']} WHERE organization_id = %d", $org_id
            ))),
            'top_qr_codes' => $top_qr_codes ?: array(),
            'device_breakdown' => $device_breakdown ?: array(),
            'daily_trend' => $daily_trend ?: array(),
            'period_days' => $days,
        );
    }
    
    /**
     * Delete a QR code
     */
    public static function delete($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Delete scans first
        $wpdb->delete($tables['qr_scans'], array('qr_code_id' => $id));
        
        // Delete QR code
        $result = $wpdb->delete($tables['qr_codes'], array('id' => $id));
        
        return $result !== false;
    }
    
    /**
     * Get organization ID for entity
     */
    private function get_org_id_for_entity($type, $id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        if ($type === 'building') {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT organization_id FROM {$tables['buildings']} WHERE id = %d", $id
            ));
        } elseif ($type === 'unit') {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT organization_id FROM {$tables['units']} WHERE id = %d", $id
            ));
        } elseif ($type === 'organization') {
            return $id;
        }
        
        return null;
    }
    
    /**
     * Get destination URL for entity
     */
    private function get_destination_url($type, $id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        if ($type === 'building') {
            $slug = $wpdb->get_var($wpdb->prepare(
                "SELECT slug FROM {$tables['buildings']} WHERE id = %d", $id
            ));
            return home_url('/rental-gates/building/' . $slug);
            
        } elseif ($type === 'unit') {
            $data = $wpdb->get_row($wpdb->prepare(
                "SELECT u.slug as unit_slug, b.slug as building_slug 
                 FROM {$tables['units']} u
                 JOIN {$tables['buildings']} b ON u.building_id = b.id 
                 WHERE u.id = %d", $id
            ), ARRAY_A);
            
            if ($data) {
                return home_url('/rental-gates/listings/' . $data['building_slug'] . '/' . $data['unit_slug']);
            }
            
        } elseif ($type === 'organization') {
            $slug = $wpdb->get_var($wpdb->prepare(
                "SELECT slug FROM {$tables['organizations']} WHERE id = %d", $id
            ));
            return home_url('/rental-gates/profile/' . $slug);
        }
        
        return home_url('/rental-gates/');
    }
    
    /**
     * Get QR image URL using free API
     */
    private function get_qr_image_url($url, $size = 300) {
        // Using QR Server API (free, no API key required)
        return 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&data=' . urlencode($url);
    }
    
    /**
     * Get QR image as base64 for embedding
     */
    public static function get_qr_base64($url, $size = 300) {
        $qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&format=png&data=' . urlencode($url);
        
        $response = wp_remote_get($qr_url);
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        return 'data:image/png;base64,' . base64_encode($body);
    }
    
    /**
     * Format QR code data
     */
    private static function format_qr($qr) {
        $instance = new self();
        
        $qr['id'] = intval($qr['id']);
        $qr['organization_id'] = intval($qr['organization_id']);
        $qr['entity_id'] = intval($qr['entity_id'] ?? 0);
        $qr['scan_count'] = intval($qr['scan_count'] ?? 0);
        $qr['destination_url'] = $qr['destination_url'] ?? '';
        $qr['label'] = $qr['label'] ?? '';
        $qr['last_scanned_at'] = $qr['last_scanned_at'] ?? null;
        
        // Generate URL - use stored destination_url or generate from entity
        $url = !empty($qr['destination_url']) ? $qr['destination_url'] : $instance->get_destination_url($qr['type'], $qr['entity_id']);
        $qr['qr_image'] = $instance->get_qr_image_url($url);
        $qr['url'] = $url;
        
        return $qr;
    }
    
    /**
     * Get client IP address
     */
    private static function get_client_ip() {
        $ip = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return sanitize_text_field(trim($ip));
    }
    
    /**
     * Get country from IP (basic implementation)
     */
    private static function get_country_from_ip() {
        // This is a placeholder - in production, use a GeoIP service
        return '';
    }
    
    /**
     * Get device type from user agent
     */
    private static function get_device_type() {
        $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        if (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false) {
            if (strpos($ua, 'tablet') !== false || strpos($ua, 'ipad') !== false) {
                return 'tablet';
            }
            return 'mobile';
        }
        
        return 'desktop';
    }
}
