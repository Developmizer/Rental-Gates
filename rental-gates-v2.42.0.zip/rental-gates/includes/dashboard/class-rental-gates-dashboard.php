<?php
/**
 * Rental Gates Dashboard Class
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Dashboard {
    // Dashboard functionality
}
