<?php
/**
 * Rental Gates Subscription Invoice Class
 *
 * Handles invoice generation and management for subscriptions.
 *
 * @package Rental_Gates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Subscription_Invoice
{

    /**
     * Get invoice by ID
     *
     * @param int $id Invoice ID
     * @return array|null Invoice data or null if not found
     */
    public static function get($id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rg_invoices';

        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $id
        ), ARRAY_A);

        if ($invoice) {
            $invoice['items'] = json_decode($invoice['items'] ?? '[]', true);
            $invoice['meta_data'] = json_decode($invoice['meta_data'] ?? '{}', true);
        }

        return $invoice;
    }

    /**
     * Create invoice from subscription data
     *
     * @param int $org_id Organization ID
     * @param array $subscription Subscription data
     * @param array $plan Plan data
     * @param array $stripe_invoice Optional Stripe invoice object
     * @return array|WP_Error Created invoice or error
     */
    public static function create_from_subscription($org_id, $subscription, $plan, $stripe_invoice = null)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rg_invoices';

        // Helper to ensure timestamp
        $get_timestamp = function ($val) {
            if (empty($val))
                return time();
            return is_numeric($val) ? (int) $val : strtotime($val);
        };

        // Normalize dates immediately
        $period_start = $get_timestamp($subscription['current_period_start'] ?? null);
        $period_end = $get_timestamp($subscription['current_period_end'] ?? null);

        // Generate invoice number
        $invoice_number = self::generate_invoice_number($org_id);

        if ($stripe_invoice && !empty($stripe_invoice['id'])) {
            $existing_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table_name} WHERE stripe_invoice_id = %s",
                $stripe_invoice['id']
            ));

            if ($existing_id) {
                // Update existing invoice with latest status
                $status = $stripe_invoice['status'] === 'paid' ? 'paid' : 'pending';
                $paid_at = $stripe_invoice['status'] === 'paid' ? date('Y-m-d H:i:s', $stripe_invoice['status_transitions']['paid_at']) : null;

                $wpdb->update(
                    $table_name,
                    array(
                        'status' => $status,
                        'paid_at' => $paid_at,
                        'pdf_url' => $stripe_invoice['invoice_pdf'] ?? null
                    ),
                    array('id' => $existing_id)
                );

                return self::get($existing_id);
            }
        }

        // Calculate amounts
        $amount = $plan['price_monthly'] ?? 0;
        if (($subscription['billing_cycle'] ?? 'monthly') === 'yearly') {
            $amount = $plan['price_yearly'] ?? 0;
        }

        $tax = 0; // Tax calculation logic would go here
        $total = $amount + $tax;

        // Prepare items
        $items = array(
            array(
                'description' => sprintf(
                    __('%s Plan - %s (%s - %s)', 'rental-gates'),
                    $plan['name'],
                    ucfirst($subscription['billing_cycle'] ?? 'monthly'),
                    date_i18n(get_option('date_format'), $period_start),
                    date_i18n(get_option('date_format'), $period_end)
                ),
                'amount' => $amount,
                'quantity' => 1
            )
        );

        // Stripe data
        $stripe_invoice_id = null;
        $pdf_url = null;
        $status = 'paid'; // Assumed paid if coming from successful subscription creation
        $paid_at = current_time('mysql');

        if ($stripe_invoice) {
            $stripe_invoice_id = $stripe_invoice['id'];
            $pdf_url = $stripe_invoice['invoice_pdf'] ?? null;
            $status = $stripe_invoice['status'] === 'paid' ? 'paid' : 'pending';
            $paid_at = $stripe_invoice['status'] === 'paid' ? date('Y-m-d H:i:s', $stripe_invoice['status_transitions']['paid_at']) : null;
            $amount = $stripe_invoice['subtotal'] / 100;
            $tax = $stripe_invoice['tax'] / 100;
            $total = $stripe_invoice['total'] / 100;
        }

        $data = array(
            'organization_id' => $org_id,
            'subscription_id' => $subscription['id'],
            'invoice_number' => $invoice_number,
            'amount' => $amount,
            'tax' => $tax,
            'total' => $total,
            'currency' => $subscription['currency'] ?? 'USD',
            'status' => $status,
            'due_date' => date('Y-m-d', $period_start),

            'paid_at' => $paid_at,
            'stripe_invoice_id' => $stripe_invoice_id,
            'pdf_url' => $pdf_url,
            'items' => json_encode($items),
            'created_at' => current_time('mysql'),
        );

        $inserted = $wpdb->insert(
            $table_name,
            $data,
            array('%d', '%d', '%s', '%f', '%f', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if (!$inserted) {
            return new WP_Error('db_insert_error', __('Could not create invoice', 'rental-gates'));
        }

        $invoice_id = $wpdb->insert_id;

        return self::get($invoice_id);
    }

    /**
     * Get invoices for an organization
     *
     * @param int $org_id Organization ID
     * @param int $limit Optional limit
     * @param int $offset Optional offset
     * @return array List of invoices
     */
    public static function get_for_organization($org_id, $limit = 20, $offset = 0)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rg_invoices';

        $invoices = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE organization_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $org_id,
            $limit,
            $offset
        ), ARRAY_A);

        if ($invoices) {
            foreach ($invoices as &$invoice) {
                $invoice['items'] = json_decode($invoice['items'] ?? '[]', true);
                $invoice['meta_data'] = json_decode($invoice['meta_data'] ?? '{}', true);
            }
        }

        return $invoices;
    }

    /**
     * Generate a unique invoice number
     */
    private static function generate_invoice_number($org_id)
    {
        $prefix = 'INV-' . date('Y') . '-';
        $random = strtoupper(substr(md5(uniqid()), 0, 6));
        return $prefix . $org_id . '-' . $random;
    }
    /**
     * Create invoice from one-time payment (e.g. AI Credits)
     *
     * @param int $org_id Organization ID
     * @param array $items Line items
     * @param float $total Total amount
     * @param string $payment_intent_id Stripe Payment Intent ID
     * @return array|WP_Error Created invoice or error
     */
    public static function create_from_payment($org_id, $items, $total, $payment_intent_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rg_invoices';

        // Generate invoice number
        $invoice_number = self::generate_invoice_number($org_id);

        $data = array(
            'organization_id' => $org_id,
            'subscription_id' => null, // One-time payment
            'invoice_number' => $invoice_number,
            'amount' => $total,
            'tax' => 0, // Simplified for credits
            'total' => $total,
            'currency' => 'USD',
            'status' => 'paid',
            'due_date' => current_time('mysql'),
            'paid_at' => current_time('mysql'),
            'stripe_invoice_id' => $payment_intent_id, // Storing PI here as reference
            'pdf_url' => null,
            'items' => json_encode($items),
            'created_at' => current_time('mysql'),
        );

        $inserted = $wpdb->insert(
            $table_name,
            $data,
            array('%d', '%d', '%s', '%f', '%f', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if (!$inserted) {
            return new WP_Error('db_insert_error', __('Could not create invoice', 'rental-gates'));
        }

        $invoice_id = $wpdb->insert_id;

        return self::get($invoice_id);
    }
    /**
     * Get invoice by subscription ID
     */
    public static function get_by_subscription($subscription_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rg_invoices';

        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE subscription_id = %d ORDER BY id DESC LIMIT 1",
            $subscription_id
        ), ARRAY_A);

        if ($invoice) {
            $invoice['items'] = json_decode($invoice['items'] ?? '[]', true) ?: array();
            $invoice['meta_data'] = json_decode($invoice['meta_data'] ?? '{}', true) ?: array();
        }

        return $invoice;
    }

    /**
     * Generate modern HTML invoice
     */
    public static function generate_html($invoice)
    {
        if (!$invoice)
            return '';

        $meta = $invoice['meta_data'] ?? array();
        $org = $meta['organization'] ?? array();
        $plan = $meta['plan'] ?? array();
        $items = $invoice['items'] ?? array();

        // Get site info for branding
        $site_name = get_bloginfo('name');
        $site_url = home_url();
        $logo_url = get_option('rental_gates_logo_url', '');

        // Format dates
        $invoice_date = date_i18n('F j, Y', strtotime($invoice['created_at']));
        $paid_date = $invoice['paid_at'] ? date_i18n('F j, Y', strtotime($invoice['paid_at'])) : '';
        $period_start = !empty($meta['period_start']) ? date_i18n('M j, Y', $meta['period_start']) : '';
        $period_end = !empty($meta['period_end']) ? date_i18n('M j, Y', $meta['period_end']) : '';

        // Status styling
        $status = $invoice['status'];
        $status_colors = array(
            'paid' => array('bg' => '#dcfce7', 'text' => '#166534', 'border' => '#86efac'),
            'pending' => array('bg' => '#fef9c3', 'text' => '#854d0e', 'border' => '#fde047'),
            'failed' => array('bg' => '#fee2e2', 'text' => '#991b1b', 'border' => '#fca5a5'),
            'refunded' => array('bg' => '#f3f4f6', 'text' => '#4b5563', 'border' => '#d1d5db'),
        );
        $status_style = $status_colors[$status] ?? $status_colors['pending'];

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php printf(__('Invoice %s', 'rental-gates'), esc_html($invoice['invoice_number'])); ?></title>
            <style>
                /* Reset & Base */
                *,
                *::before,
                *::after {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                }

                :root {
                    --primary: #0d9488;
                    --primary-dark: #0f766e;
                    --gray-50: #fafaf9;
                    --gray-100: #f5f5f4;
                    --gray-200: #e7e5e4;
                    --gray-300: #d6d3d1;
                    --gray-400: #a8a29e;
                    --gray-500: #78716c;
                    --gray-600: #57534e;
                    --gray-700: #44403c;
                    --gray-800: #292524;
                    --gray-900: #1c1917;
                }

                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                    font-size: 14px;
                    line-height: 1.6;
                    color: var(--gray-800);
                    background: #fff;
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                }

                .invoice-container {
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 48px;
                    background: #fff;
                }

                /* Header */
                .invoice-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    margin-bottom: 48px;
                    padding-bottom: 32px;
                    border-bottom: 2px solid var(--gray-200);
                }

                .company-info {
                    flex: 1;
                }

                .company-logo {
                    max-height: 48px;
                    max-width: 200px;
                    margin-bottom: 12px;
                }

                .company-name {
                    font-size: 24px;
                    font-weight: 700;
                    color: var(--gray-900);
                    margin-bottom: 4px;
                }

                .company-details {
                    font-size: 13px;
                    color: var(--gray-500);
                }

                .invoice-title-section {
                    text-align: right;
                }

                .invoice-title {
                    font-size: 36px;
                    font-weight: 800;
                    color: var(--primary);
                    letter-spacing: -1px;
                    margin-bottom: 8px;
                }

                .invoice-number {
                    font-size: 15px;
                    color: var(--gray-600);
                    font-weight: 500;
                }

                .invoice-status {
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    padding: 6px 14px;
                    border-radius: 100px;
                    font-size: 12px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    margin-top: 12px;
                    background:
                        <?php echo esc_attr($status_style['bg']); ?>
                    ;
                    color:
                        <?php echo esc_attr($status_style['text']); ?>
                    ;
                    border: 1px solid
                        <?php echo esc_attr($status_style['border']); ?>
                    ;
                }

                .status-dot {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: currentColor;
                }

                /* Info Grid */
                .info-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 32px;
                    margin-bottom: 40px;
                }

                .info-block {
                    padding: 20px;
                    background: var(--gray-50);
                    border-radius: 12px;
                    border: 1px solid var(--gray-200);
                }

                .info-block-label {
                    font-size: 11px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: var(--gray-400);
                    margin-bottom: 8px;
                }

                .info-block-value {
                    font-size: 14px;
                    color: var(--gray-800);
                    font-weight: 500;
                }

                .info-block-value.large {
                    font-size: 16px;
                    font-weight: 600;
                }

                .info-block-sub {
                    font-size: 12px;
                    color: var(--gray-500);
                    margin-top: 4px;
                }

                /* Dates Row */
                .dates-row {
                    display: flex;
                    gap: 24px;
                    margin-bottom: 40px;
                    padding: 20px 24px;
                    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
                    border-radius: 12px;
                }

                .date-item {
                    flex: 1;
                    text-align: center;
                    padding: 0 16px;
                    border-right: 1px solid rgba(255, 255, 255, 0.2);
                }

                .date-item:last-child {
                    border-right: none;
                }

                .date-label {
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: rgba(255, 255, 255, 0.7);
                    margin-bottom: 4px;
                }

                .date-value {
                    font-size: 15px;
                    font-weight: 600;
                    color: #fff;
                }

                /* Items Table */
                .items-section {
                    margin-bottom: 40px;
                }

                .items-header {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    margin-bottom: 16px;
                }

                .items-header h3 {
                    font-size: 16px;
                    font-weight: 600;
                    color: var(--gray-800);
                }

                .items-table {
                    width: 100%;
                    border-collapse: collapse;
                    border-radius: 12px;
                    overflow: hidden;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
                }

                .items-table thead {
                    background: var(--gray-100);
                }

                .items-table th {
                    padding: 14px 16px;
                    text-align: left;
                    font-size: 11px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: var(--gray-500);
                    border-bottom: 2px solid var(--gray-200);
                }

                .items-table th:last-child {
                    text-align: right;
                }

                .items-table tbody tr {
                    border-bottom: 1px solid var(--gray-200);
                }

                .items-table tbody tr:last-child {
                    border-bottom: none;
                }

                .items-table td {
                    padding: 20px 16px;
                    vertical-align: top;
                }

                .items-table td:last-child {
                    text-align: right;
                }

                .item-description {
                    font-size: 15px;
                    font-weight: 600;
                    color: var(--gray-800);
                    margin-bottom: 4px;
                }

                .item-details {
                    font-size: 13px;
                    color: var(--gray-500);
                    margin-bottom: 8px;
                }

                .item-features {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 8px;
                    margin-top: 12px;
                }

                .feature-tag {
                    display: inline-flex;
                    align-items: center;
                    gap: 4px;
                    padding: 4px 10px;
                    background: var(--gray-100);
                    border-radius: 100px;
                    font-size: 11px;
                    font-weight: 500;
                    color: var(--gray-600);
                }

                .feature-tag svg {
                    width: 12px;
                    height: 12px;
                    color: var(--primary);
                }

                .item-qty,
                .item-price {
                    font-size: 14px;
                    color: var(--gray-600);
                }

                .item-amount {
                    font-size: 15px;
                    font-weight: 600;
                    color: var(--gray-800);
                }

                /* Totals */
                .totals-section {
                    display: flex;
                    justify-content: flex-end;
                    margin-bottom: 40px;
                }

                .totals-box {
                    width: 320px;
                    background: var(--gray-50);
                    border-radius: 12px;
                    padding: 24px;
                    border: 1px solid var(--gray-200);
                }

                .totals-row {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 10px 0;
                    font-size: 14px;
                }

                .totals-row:not(:last-child) {
                    border-bottom: 1px solid var(--gray-200);
                }

                .totals-label {
                    color: var(--gray-600);
                }

                .totals-value {
                    font-weight: 600;
                    color: var(--gray-800);
                }

                .totals-row.total {
                    padding-top: 16px;
                    margin-top: 8px;
                    border-top: 2px solid var(--gray-300);
                }

                .totals-row.total .totals-label {
                    font-size: 16px;
                    font-weight: 700;
                    color: var(--gray-800);
                }

                .totals-row.total .totals-value {
                    font-size: 24px;
                    font-weight: 800;
                    color: var(--primary);
                }

                /* Payment Info */
                .payment-info {
                    background: linear-gradient(135deg, #f0fdfa 0%, #ccfbf1 100%);
                    border: 1px solid #99f6e4;
                    border-radius: 12px;
                    padding: 24px;
                    margin-bottom: 40px;
                }

                .payment-info-header {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    margin-bottom: 16px;
                }

                .payment-info-header svg {
                    width: 24px;
                    height: 24px;
                    color: var(--primary);
                }

                .payment-info-header h4 {
                    font-size: 16px;
                    font-weight: 600;
                    color: var(--gray-800);
                }

                .payment-info-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                }

                .payment-info-item .label {
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: var(--gray-500);
                    margin-bottom: 4px;
                }

                .payment-info-item .value {
                    font-size: 14px;
                    font-weight: 600;
                    color: var(--gray-800);
                }

                /* Billing Period */
                .billing-period {
                    background: var(--gray-50);
                    border: 1px solid var(--gray-200);
                    border-radius: 12px;
                    padding: 20px 24px;
                    margin-bottom: 40px;
                }

                .billing-period-header {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    margin-bottom: 12px;
                }

                .billing-period-header svg {
                    width: 20px;
                    height: 20px;
                    color: var(--gray-500);
                }

                .billing-period-header h4 {
                    font-size: 14px;
                    font-weight: 600;
                    color: var(--gray-700);
                }

                .billing-period-dates {
                    display: flex;
                    align-items: center;
                    gap: 16px;
                }

                .billing-period-date {
                    font-size: 14px;
                    color: var(--gray-600);
                }

                .billing-period-arrow {
                    color: var(--gray-400);
                }

                /* Footer */
                .invoice-footer {
                    text-align: center;
                    padding-top: 32px;
                    border-top: 1px solid var(--gray-200);
                }

                .footer-thanks {
                    font-size: 18px;
                    font-weight: 600;
                    color: var(--gray-800);
                    margin-bottom: 8px;
                }

                .footer-note {
                    font-size: 13px;
                    color: var(--gray-500);
                    margin-bottom: 4px;
                }

                .footer-generated {
                    font-size: 11px;
                    color: var(--gray-400);
                    margin-top: 16px;
                }

                /* Action Buttons (for web view, hidden in print) */
                .invoice-actions {
                    display: flex;
                    justify-content: center;
                    gap: 12px;
                    margin-bottom: 32px;
                    padding: 20px;
                    background: var(--gray-50);
                    border-radius: 12px;
                }

                .action-btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    padding: 12px 20px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: 600;
                    text-decoration: none;
                    cursor: pointer;
                    border: none;
                    transition: all 0.2s;
                }

                .action-btn svg {
                    width: 18px;
                    height: 18px;
                }

                .action-btn-primary {
                    background: var(--primary);
                    color: #fff;
                }

                .action-btn-primary:hover {
                    background: var(--primary-dark);
                }

                @media print {
                    .invoice-container {
                        padding: 0;
                    }

                    .invoice-actions {
                        display: none !important;
                    }

                    body {
                        background: #fff;
                    }
                }
            </style>
        </head>

        <body>
            <div class="invoice-container">
                <!-- Actions -->
                <?php if (!isset($_GET['print'])): ?>
                    <div class="invoice-actions">
                        <button onclick="window.print()" class="action-btn action-btn-primary">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z">
                                </path>
                            </svg>
                            <?php _e('Print Invoice', 'rental-gates'); ?>
                        </button>
                    </div>
                <?php endif; ?>

                <!-- Header -->
                <header class="invoice-header">
                    <div class="company-info">
                        <?php if ($logo_url): ?>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>"
                                class="company-logo">
                        <?php else: ?>
                            <div class="company-name"><?php echo esc_html($site_name); ?></div>
                        <?php endif; ?>
                        <div class="company-details">
                            <?php echo esc_html($site_url); ?>
                        </div>
                    </div>

                    <div class="invoice-title-section">
                        <h1 class="invoice-title"><?php _e('INVOICE', 'rental-gates'); ?></h1>
                        <div class="invoice-number">#<?php echo esc_html($invoice['invoice_number']); ?></div>
                        <div class="invoice-status">
                            <span class="status-dot"></span>
                            <?php echo esc_html(ucfirst($status)); ?>
                        </div>
                    </div>
                </header>

                <!-- Info Grid -->
                <div class="info-grid">
                    <!-- Billed To -->
                    <div class="info-block">
                        <div class="info-block-label"><?php _e('Billed To', 'rental-gates'); ?></div>
                        <div class="info-block-value large"><?php echo esc_html($org['name'] ?? 'Organization'); ?></div>
                        <div class="info-block-sub"><?php echo esc_html($org['email'] ?? ''); ?></div>
                        <?php if (!empty($org['address'])): ?>
                            <div class="info-block-sub">
                                <?php echo esc_html($org['address']); ?><br>
                                <?php echo esc_html(($org['city'] ?? '') . ', ' . ($org['state'] ?? '') . ' ' . ($org['zip'] ?? '')); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Dates -->
                    <div class="info-block">
                        <div class="info-block-label"><?php _e('Invoice Date', 'rental-gates'); ?></div>
                        <div class="info-block-value"><?php echo esc_html($invoice_date); ?></div>
                        <?php if ($paid_date): ?>
                            <div class="info-block-sub"><?php printf(__('Paid on %s', 'rental-gates'), $paid_date); ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- Total -->
                    <div class="info-block">
                        <div class="info-block-label"><?php _e('Amount', 'rental-gates'); ?></div>
                        <div class="info-block-value large" style="color: var(--primary);">
                            $<?php echo number_format($invoice['total'], 2); ?></div>
                        <div class="info-block-sub"><?php echo esc_html(strtoupper($invoice['currency'])); ?></div>
                    </div>
                </div>

                <!-- Usage Period -->
                <?php if ($period_start && $period_end): ?>
                    <div class="billing-period">
                        <div class="billing-period-header">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                </path>
                            </svg>
                            <h4><?php _e('Billing Period', 'rental-gates'); ?></h4>
                        </div>
                        <div class="billing-period-dates">
                            <span class="billing-period-date"><?php echo esc_html($period_start); ?></span>
                            <span class="billing-period-arrow">→</span>
                            <span class="billing-period-date"><?php echo esc_html($period_end); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Items -->
                <div class="items-section">
                    <div class="items-header">
                        <h3><?php _e('Services Description', 'rental-gates'); ?></h3>
                    </div>
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th style="width: 50%"><?php _e('Description', 'rental-gates'); ?></th>
                                <th style="width: 15%"><?php _e('Qty', 'rental-gates'); ?></th>
                                <th style="width: 15%"><?php _e('Unit Price', 'rental-gates'); ?></th>
                                <th><?php _e('Amount', 'rental-gates'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="item-description"><?php echo esc_html($item['description']); ?></div>
                                        <?php if (!empty($item['details'])): ?>
                                            <div class="item-details"><?php echo esc_html($item['details']); ?></div>
                                        <?php endif; ?>

                                        <?php if (!empty($item['features'])): ?>
                                            <div class="item-features">
                                                <?php foreach ($item['features'] as $feature): ?>
                                                    <span class="feature-tag">
                                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                        <?php echo esc_html($feature); ?>
                                                    </span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="item-qty"><?php echo esc_html($item['quantity']); ?></span></td>
                                    <td><span
                                            class="item-price">$<?php echo number_format(abs($item['unit_price'] ?? $item['amount']), 2); ?></span>
                                    </td>
                                    <td><span class="item-amount">$<?php echo number_format($item['amount'], 2); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Totals -->
                <div class="totals-section">
                    <div class="totals-box">
                        <div class="totals-row">
                            <span class="totals-label"><?php _e('Subtotal', 'rental-gates'); ?></span>
                            <span class="totals-value">$<?php echo number_format($invoice['amount'], 2); ?></span>
                        </div>
                        <?php if ($invoice['tax'] > 0): ?>
                            <div class="totals-row">
                                <span class="totals-label"><?php _e('Tax', 'rental-gates'); ?></span>
                                <span class="totals-value">$<?php echo number_format($invoice['tax'], 2); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="totals-row total">
                            <span class="totals-label"><?php _e('Total Paid', 'rental-gates'); ?></span>
                            <span class="totals-value">$<?php echo number_format($invoice['total'], 2); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <footer class="invoice-footer">
                    <div class="footer-thanks"><?php _e('Thank you for your business!', 'rental-gates'); ?></div>
                    <div class="footer-note">
                        <?php _e('If you have any questions about this invoice, please contact support.', 'rental-gates'); ?>
                    </div>
                    <div class="footer-generated">
                        <?php printf(__('Generated by %s on %s', 'rental-gates'), esc_html($site_name), date_i18n('F j, Y g:i a')); ?>
                    </div>
                </footer>
            </div>
        </body>

        </html>
        <?php
        return ob_get_clean();
    }
}

