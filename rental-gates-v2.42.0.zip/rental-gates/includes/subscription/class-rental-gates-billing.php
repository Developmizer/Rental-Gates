<?php
/**
 * Rental Gates Billing Class
 * 
 * Handles platform billing (Landlords paying for the software).
 * This is distinct from the property rent collection (Tenants paying Landlords).
 * 
 * @package RentalGates
 */

if (!defined('ABSPATH'))
    exit;

class Rental_Gates_Billing
{

    /**
     * Get the Stripe Customer ID for an organization
     * Creates one if it doesn't exist
     */
    public static function get_or_create_customer($org_id)
    {
        $user_id = get_current_user_id(); // Fallback to current user if org owner logic needs help

        // Use the robust logic in Rental_Gates_Stripe which handles checking DB and creating in Stripe
        return Rental_Gates_Stripe::get_or_create_customer($user_id);
    }

    /**
     * Create a Setup Intent for adding a payment method
     */
    public static function create_setup_intent($org_id)
    {
        $customer_id = self::get_or_create_customer($org_id);

        if (is_wp_error($customer_id)) {
            return $customer_id;
        }

        return Rental_Gates_Stripe::api_request('setup_intents', 'POST', array(
            'customer' => $customer_id,
            'payment_method_types' => array('card'),
            'usage' => 'off_session', // For future subscription charges
        ));
    }

    /**
     * Subscribe an organization to a plan
     */
    public static function subscribe($org_id, $plan_id, $payment_method_id = null, $billing_cycle = 'monthly')
    {
        global $wpdb;

        // Get plan details from Feature Gate (source of truth)
        $plans_config = rg_get_all_plans();

        if (!isset($plans_config[$plan_id])) {
            return new WP_Error('invalid_plan', __('Invalid plan selected', 'rental-gates'));
        }

        $plan_config = $plans_config[$plan_id];

        // Handle free plans
        if (!empty($plan_config['is_free']) || empty($plan_config['price_monthly'])) {
            // Cancel existing paid subs and switch to free
            self::cancel_subscription($org_id);
            self::update_org_plan($org_id, $plan_id);
            return true;
        }

        $customer_id = self::get_or_create_customer($org_id);
        if (is_wp_error($customer_id))
            return $customer_id;

        // Attach payment method if provided
        if ($payment_method_id) {
            $attach = Rental_Gates_Stripe::attach_payment_method($payment_method_id, $customer_id);
            if (is_wp_error($attach) && strpos($attach->get_error_message(), 'already been attached') === false) {
                return $attach;
            }

            // Set as default for invoice settings
            Rental_Gates_Stripe::set_customer_invoice_payment_method($customer_id, $payment_method_id);
        }

        // Get Price ID (dynamically create if needed)
        $price_id = Rental_Gates_Stripe::get_or_create_plan_price($plan_id, $plan_config, $billing_cycle);

        if (is_wp_error($price_id)) {
            return $price_id;
        }

        // Create Subscription using Stripe Helper
        $subscription = Rental_Gates_Stripe::create_subscription(
            $customer_id,
            $price_id,
            $payment_method_id,
            array(
                'organization_id' => $org_id,
                'plan_id' => $plan_id,
                'source' => 'rental_gates',
            )
        );

        if (is_wp_error($subscription))
            return $subscription;

        // Save to DB
        self::save_subscription_to_db($org_id, $subscription, $plan_id, $billing_cycle);

        // Send subscription confirmation email
        if (class_exists('Rental_Gates_Email')) {
            $tables = Rental_Gates_Database::get_table_names();
            $sub_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$tables['subscriptions']} WHERE stripe_subscription_id = %s",
                $subscription['id']
            ), ARRAY_A);
            
            if ($sub_record) {
                error_log('Rental Gates: Attempting to send subscription confirmation email for org_id: ' . $org_id);
                $email_result = Rental_Gates_Email::send_subscription_confirmation(
                    $org_id,
                    $sub_record,
                    $plan_config
                );
                if (is_wp_error($email_result)) {
                    error_log('Rental Gates: Email error: ' . $email_result->get_error_message());
                } elseif ($email_result === false) {
                    error_log('Rental Gates: Email sending returned false');
                }
            } else {
                error_log('Rental Gates: Subscription record not found for stripe_subscription_id: ' . $subscription['id']);
            }
        } else {
            error_log('Rental Gates: Rental_Gates_Email class not found');
        }

        // IMMEDIATE INVOICE CREATION (Fix for missing invoice bug)
        // We use the expansion from create_subscription to create the invoice record immediately
        // instead of waiting for the webhook which might be delayed or fail.
        if (
            !empty($subscription['latest_invoice']) &&
            (is_array($subscription['latest_invoice']) || is_object($subscription['latest_invoice'])) &&
            class_exists('Rental_Gates_Subscription_Invoice')
        ) {
            $invoice_obj = is_object($subscription['latest_invoice'])
                ? json_decode(json_encode($subscription['latest_invoice']), true)
                : $subscription['latest_invoice'];

            // Re-fetch sub from DB to ensure we have the ID correct
            $tables = Rental_Gates_Database::get_table_names();
            $sub_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$tables['subscriptions']} WHERE stripe_subscription_id = %s",
                $subscription['id']
            ), ARRAY_A);

            if ($sub_record) {
                $plan_data = isset($plans_config[$plan_id]) ? $plans_config[$plan_id] : array('name' => 'Unknown Plan');

                Rental_Gates_Subscription_Invoice::create_from_subscription(
                    $org_id,
                    $sub_record,
                    $plan_data,
                    $invoice_obj
                );
            }
        }

        return $subscription;
    }

    /**
     * Cancel Subscription
     */
    public static function cancel_subscription($org_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $sub = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} WHERE organization_id = %d AND status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete')",
            $org_id
        ));

        if (!$sub || empty($sub->stripe_subscription_id)) {
            // Just update local DB plan if no stripe sub
            return true;
        }

        // Use Stripe Helper
        $result = Rental_Gates_Stripe::cancel_subscription($sub->stripe_subscription_id);

        if (is_wp_error($result))
            return $result;

        // Update DB - keep status as 'active' when cancel_at_period_end is true
        // Status will change to 'cancelled' when the period actually ends (via webhook)
        // This allows the subscription to still be found and the resume button to show
        $wpdb->update(
            $tables['subscriptions'],
            array(
                'cancel_at_period_end' => 1,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $sub->id),
            array('%d', '%s'),
            array('%d')
        );

        return true;
    }

    /**
     * Change Subscription Plan (Upgrade/Downgrade)
     */
    public static function change_plan($org_id, $new_plan_id, $payment_method_id = null)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $sub = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} WHERE organization_id = %d AND status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete')",
            $org_id
        ));

        // If no active subscription, just subscribe new
        if (!$sub || empty($sub->stripe_subscription_id)) {
            return self::subscribe($org_id, $new_plan_id, $payment_method_id);
        }

        $plans_config = rg_get_all_plans();
        if (!isset($plans_config[$new_plan_id])) {
            return new WP_Error('invalid_plan', __('Invalid plan selected', 'rental-gates'));
        }
        $new_plan = $plans_config[$new_plan_id];

        // Handle switch to free
        if (!empty($new_plan['is_free']) || empty($new_plan['price_monthly'])) {
            // Cancel current sub at end of period
            $result = self::cancel_subscription($org_id);
            if (is_wp_error($result))
                return $result;

            // We don't update org plan immediately for downgrades usually, 
            // but rental_gates.php logic handles the "scheduled downgrade" state.
            // For now, let's return the cancellation result so the controller can handle the DB update for "downgrade_to_plan"
            return array('action' => 'downgrade_scheduled', 'subscription' => $sub);
        }

        // Handle incomplete/pending subscriptions - Stripe doesn't allow plan changes on these statuses
        // Cancel the problematic subscription and create a new one
        if (in_array($sub->status, array('incomplete', 'incomplete_expired', 'pending_payment'))) {
            // Cancel the subscription first
            if (!empty($sub->stripe_subscription_id)) {
                Rental_Gates_Stripe::cancel_subscription($sub->stripe_subscription_id);
            }
            
            // Delete the subscription record
            $wpdb->delete(
                $tables['subscriptions'],
                array('id' => $sub->id),
                array('%d')
            );
            
            // Create a new subscription for the new plan
            return self::subscribe($org_id, $new_plan_id, $payment_method_id);
        }

        // Resume if pending cancellation
        if ($sub->cancel_at_period_end) {
            Rental_Gates_Stripe::resume_subscription($sub->stripe_subscription_id);
        }

        // Get New Price ID
        $price_id = Rental_Gates_Stripe::get_or_create_plan_price($new_plan_id, $new_plan);
        if (is_wp_error($price_id))
            return $price_id;

        // Use Stripe Helper
        $result = Rental_Gates_Stripe::change_subscription_plan(
            $sub->stripe_subscription_id,
            $price_id,
            'create_prorations'
        );

        if (is_wp_error($result)) {
            // If the error is about incomplete status, handle it gracefully
            $error_message = $result->get_error_message();
            if (strpos($error_message, 'incomplete') !== false) {
                // Cancel the incomplete subscription and create a new one
                if (!empty($sub->stripe_subscription_id)) {
                    Rental_Gates_Stripe::cancel_subscription($sub->stripe_subscription_id);
                }
                
                // Delete the incomplete subscription record
                $wpdb->delete(
                    $tables['subscriptions'],
                    array('id' => $sub->id),
                    array('%d')
                );
                
                // Create a new subscription for the new plan
                return self::subscribe($org_id, $new_plan_id, $payment_method_id);
            }
            return $result;
        }

        // Update DB
        self::save_subscription_to_db($org_id, $result, $new_plan_id);

        // Send subscription confirmation email for plan change
        if (class_exists('Rental_Gates_Email')) {
            $tables = Rental_Gates_Database::get_table_names();
            $sub_record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$tables['subscriptions']} WHERE stripe_subscription_id = %s",
                $result['id']
            ), ARRAY_A);
            
            if ($sub_record) {
                error_log('Rental Gates: Attempting to send plan change confirmation email for org_id: ' . $org_id);
                $email_result = Rental_Gates_Email::send_subscription_confirmation(
                    $org_id,
                    $sub_record,
                    $new_plan
                );
                if (is_wp_error($email_result)) {
                    error_log('Rental Gates: Plan change email error: ' . $email_result->get_error_message());
                } elseif ($email_result === false) {
                    error_log('Rental Gates: Plan change email sending returned false');
                }
            } else {
                error_log('Rental Gates: Subscription record not found for plan change, stripe_subscription_id: ' . $result['id']);
            }
        }

        return $result;
    }

    /**
     * Cancel Subscription Immediately
     */
    public static function cancel_subscription_immediately($org_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $sub = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} WHERE organization_id = %d AND status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete')",
            $org_id
        ));

        if (!$sub || empty($sub->stripe_subscription_id)) {
            // Just update local DB plan if no stripe sub
            self::update_org_plan($org_id, 'free');
            return true;
        }

        // Use Stripe Helper (assuming added, otherwise use api_request)
        if (method_exists('Rental_Gates_Stripe', 'cancel_subscription_immediately')) {
            $result = Rental_Gates_Stripe::cancel_subscription_immediately($sub->stripe_subscription_id);
        } else {
            // Fallback
            $result = Rental_Gates_Stripe::api_request("subscriptions/{$sub->stripe_subscription_id}", 'DELETE');
        }

        if (is_wp_error($result))
            return $result;

        // Update DB
        $wpdb->update(
            $tables['subscriptions'],
            array('status' => 'cancelled', 'cancelled_at' => current_time('mysql'), 'cancel_at_period_end' => 0),
            array('id' => $sub->id),
            array('%s', '%s', '%d'),
            array('%d')
        );

        self::update_org_plan($org_id, 'free');

        return true;
    }

    /**
     * Update local DB with subscription state
     */
    private static function save_subscription_to_db($org_id, $stripe_sub, $plan_id, $billing_cycle = 'monthly')
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        // Update Org Plan (Source of Truth for Feature Gate)
        self::update_org_plan($org_id, $plan_id);

        // Determine billing cycle from Stripe subscription if not explicitly provided
        // Stripe stores interval in various locations depending on API version
        $determined_billing_cycle = $billing_cycle;
        
        // Path 1: Direct plan object (older API responses)
        if (isset($stripe_sub['plan']['interval'])) {
            $determined_billing_cycle = ($stripe_sub['plan']['interval'] === 'year') ? 'yearly' : 'monthly';
        }
        // Path 2: items.data[0].plan.interval (subscription items)
        elseif (isset($stripe_sub['items']['data'][0]['plan']['interval'])) {
            $determined_billing_cycle = ($stripe_sub['items']['data'][0]['plan']['interval'] === 'year') ? 'yearly' : 'monthly';
        }
        // Path 3: items.data[0].price.recurring.interval (price-based)
        elseif (isset($stripe_sub['items']['data'][0]['price']['recurring']['interval'])) {
            $determined_billing_cycle = ($stripe_sub['items']['data'][0]['price']['recurring']['interval'] === 'year') ? 'yearly' : 'monthly';
        }

        // Get amount - handle different Stripe response structures
        $amount = 0;
        
        // Path 1: Direct plan amount
        if (isset($stripe_sub['plan']['amount'])) {
            $amount = $stripe_sub['plan']['amount'] / 100;
        }
        // Path 2: items.data[0].plan.amount
        elseif (isset($stripe_sub['items']['data'][0]['plan']['amount'])) {
            $amount = $stripe_sub['items']['data'][0]['plan']['amount'] / 100;
        }
        // Path 3: items.data[0].price.unit_amount
        elseif (isset($stripe_sub['items']['data'][0]['price']['unit_amount'])) {
            $amount = $stripe_sub['items']['data'][0]['price']['unit_amount'] / 100;
        }

        // Ensure status is always set - default to 'active' if empty
        $status = !empty($stripe_sub['status']) ? $stripe_sub['status'] : 'active';
        
        $data = array(
            'organization_id' => $org_id,
            'plan_id' => $plan_id,
            'plan_slug' => $plan_id, // Also save as plan_slug for compatibility
            'stripe_subscription_id' => $stripe_sub['id'],
            'stripe_customer_id' => $stripe_sub['customer'],
            'status' => $status,
            'amount' => $amount,
            'billing_cycle' => $determined_billing_cycle,
            'current_period_start' => date('Y-m-d H:i:s', $stripe_sub['current_period_start']),
            'current_period_end' => date('Y-m-d H:i:s', $stripe_sub['current_period_end']),
            'cancel_at_period_end' => !empty($stripe_sub['cancel_at_period_end']) ? 1 : 0,
            'updated_at' => current_time('mysql')
        );

        // Handle trial end date
        if (!empty($stripe_sub['trial_end'])) {
            $data['trial_end'] = date('Y-m-d H:i:s', $stripe_sub['trial_end']);
        }

        // Check for ANY existing subscription for this org to avoid duplicate key errors
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$tables['subscriptions']} WHERE organization_id = %d",
            $org_id
        ));

        if ($existing) {
            $wpdb->update($tables['subscriptions'], $data, array('id' => $existing));
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($tables['subscriptions'], $data);
        }

        // Log for debugging
        error_log(sprintf(
            'Rental Gates - Subscription saved: org_id=%d, plan=%s, billing_cycle=%s, amount=%s',
            $org_id,
            $plan_id,
            $determined_billing_cycle,
            $amount
        ));
    }

    /**
     * Update organization plan in database
     * 
     * @param int $org_id Organization ID
     * @param string $plan_id Plan slug/ID
     */
    public static function update_org_plan($org_id, $plan_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        $wpdb->update(
            $tables['organizations'],
            array('plan_id' => $plan_id, 'updated_at' => current_time('mysql')),
            array('id' => $org_id),
            array('%s', '%s'),
            array('%d')
        );
    }
    /**
     * AJAX Handler: Cancel Subscription
     */
    public static function ajax_cancel_subscription()
    {
        check_ajax_referer('rental_gates_cancel', 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'rental-gates')));
        }

        $org_id = rg_feature_gate()->get_user_org_id();
        if (!$org_id && !current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Organization not found.', 'rental-gates')));
        }

        // Check permissions (Owner only)
        if (!rg_feature_gate()->check_role(array('owner'))) {
            wp_send_json_error(array('message' => __('Only the organization owner can cancel the subscription.', 'rental-gates')));
        }

        $result = self::cancel_subscription($org_id);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success(array(
            'message' => __('Subscription cancelled successfully.', 'rental-gates'),
            'redirect' => home_url('/rental-gates/dashboard/billing?cancelled=1')
        ));
    }

    /**
     * AJAX Handler: Resume Subscription
     */
    public static function ajax_resume_subscription()
    {
        check_ajax_referer('rental_gates_resume', 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'rental-gates')));
        }

        $org_id = rg_feature_gate()->get_user_org_id();
        if (!$org_id) {
            wp_send_json_error(array('message' => __('Organization not found.', 'rental-gates')));
        }

        // Check permissions (Owner only)
        if (!rg_feature_gate()->check_role(array('owner'))) {
            wp_send_json_error(array('message' => __('Only the organization owner can resume the subscription.', 'rental-gates')));
        }

        // Get subscription - include subscriptions with cancel_at_period_end = 1 (scheduled to cancel)
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        $sub = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} 
             WHERE organization_id = %d 
             AND (status IN ('active', 'trialing', 'past_due', 'unpaid', 'incomplete') 
                  OR cancel_at_period_end = 1)",
            $org_id
        ));

        if (!$sub || empty($sub->stripe_subscription_id)) {
            wp_send_json_error(array('message' => __('No active subscription found.', 'rental-gates')));
        }

        $result = Rental_Gates_Stripe::resume_subscription($sub->stripe_subscription_id);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        // Update DB
        $wpdb->update(
            $tables['subscriptions'],
            array('cancel_at_period_end' => 0, 'updated_at' => current_time('mysql')),
            array('id' => $sub->id),
            array('%d', '%s'),
            array('%d')
        );

        wp_send_json_success(array(
            'message' => __('Subscription resumed successfully.', 'rental-gates'),
            'redirect' => home_url('/rental-gates/dashboard/billing?resumed=1')
        ));
    }

    /**
     * AJAX Handler: Change Plan
     */
    public static function ajax_change_plan()
    {
        check_ajax_referer('rental_gates_change_plan', 'nonce');

        $plan_id = sanitize_text_field($_POST['plan_id'] ?? '');
        if (!$plan_id) {
            wp_send_json_error(array('message' => __('Invalid plan.', 'rental-gates')));
        }

        $org_id = rg_feature_gate()->get_user_org_id();

        // Check permissions (Owner only)
        if (!rg_feature_gate()->check_role(array('owner'))) {
            wp_send_json_error(array('message' => __('Only the organization owner can change the plan.', 'rental-gates')));
        }

        $result = self::change_plan($org_id, $plan_id);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success(array(
            'message' => __('Plan changed successfully.', 'rental-gates'),
            'redirect' => home_url('/rental-gates/dashboard/billing?changed=1')
        ));
    }

    /**
     * Sync subscription status with Stripe
     * 
     * This method fetches the latest subscription status from Stripe and updates
     * the local database to ensure consistency.
     * 
     * @param int $org_id Organization ID
     * @return array|WP_Error Updated subscription data or error
     */
    public static function sync_subscription_status($org_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        // Get local subscription
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} WHERE organization_id = %d ORDER BY created_at DESC LIMIT 1",
            $org_id
        ));

        if (!$subscription || empty($subscription->stripe_subscription_id)) {
            return array(
                'synced' => false,
                'reason' => 'no_stripe_subscription',
                'subscription' => $subscription
            );
        }

        // Check if Stripe is configured
        if (!class_exists('Rental_Gates_Stripe') || !Rental_Gates_Stripe::is_configured()) {
            return new WP_Error('stripe_not_configured', __('Stripe is not configured', 'rental-gates'));
        }

        // Fetch from Stripe
        $stripe_sub = Rental_Gates_Stripe::api_request(
            "subscriptions/{$subscription->stripe_subscription_id}",
            'GET'
        );

        if (is_wp_error($stripe_sub)) {
            // If subscription not found in Stripe, it may have been deleted
            if (strpos($stripe_sub->get_error_message(), 'No such subscription') !== false) {
                $wpdb->update(
                    $tables['subscriptions'],
                    array(
                        'status' => 'cancelled',
                        'cancelled_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql')
                    ),
                    array('id' => $subscription->id),
                    array('%s', '%s', '%s'),
                    array('%d')
                );
                
                // Downgrade org to free
                self::update_org_plan($org_id, 'free');
                
                return array(
                    'synced' => true,
                    'action' => 'cancelled_not_found',
                    'message' => __('Subscription not found in Stripe, marked as cancelled', 'rental-gates')
                );
            }
            return $stripe_sub;
        }

        // Map Stripe status to local status
        $status_map = array(
            'active' => 'active',
            'trialing' => 'trialing',
            'past_due' => 'past_due',
            'unpaid' => 'unpaid',
            'incomplete' => 'incomplete',
            'incomplete_expired' => 'expired',
            'canceled' => 'cancelled',
            'paused' => 'cancelled',
        );

        // Map status, default to 'active' if empty or unknown
        $stripe_status = $stripe_sub['status'] ?? '';
        $new_status = $status_map[$stripe_status] ?? (!empty($stripe_status) ? $stripe_status : 'active');
        $cancel_at_period_end = !empty($stripe_sub['cancel_at_period_end']) ? 1 : 0;
        
        // If subscription is marked as cancelled in Stripe but period hasn't ended yet,
        // keep status as 'active' to maintain access until period_end
        if ($new_status === 'cancelled' && !empty($stripe_sub['current_period_end'])) {
            $period_end = $stripe_sub['current_period_end'];
            $period_end_timestamp = is_numeric($period_end) ? $period_end : strtotime($period_end);
            if ($period_end_timestamp > time()) {
                // Period hasn't ended yet, keep as active
                $new_status = 'active';
            }
        }

        // Determine billing cycle from Stripe subscription
        // Try multiple paths as Stripe API structure varies
        $billing_cycle = null;
        
        // Path 1: Direct plan object (older API responses)
        if (isset($stripe_sub['plan']['interval'])) {
            $billing_cycle = ($stripe_sub['plan']['interval'] === 'year') ? 'yearly' : 'monthly';
        }
        // Path 2: items.data[0].plan.interval (subscription items)
        elseif (isset($stripe_sub['items']['data'][0]['plan']['interval'])) {
            $billing_cycle = ($stripe_sub['items']['data'][0]['plan']['interval'] === 'year') ? 'yearly' : 'monthly';
        }
        // Path 3: items.data[0].price.recurring.interval (price-based)
        elseif (isset($stripe_sub['items']['data'][0]['price']['recurring']['interval'])) {
            $billing_cycle = ($stripe_sub['items']['data'][0]['price']['recurring']['interval'] === 'year') ? 'yearly' : 'monthly';
        }

        // Get amount from Stripe - try multiple paths
        $amount = null;
        
        // Path 1: Direct plan amount
        if (isset($stripe_sub['plan']['amount'])) {
            $amount = $stripe_sub['plan']['amount'] / 100;
        }
        // Path 2: items.data[0].plan.amount
        elseif (isset($stripe_sub['items']['data'][0]['plan']['amount'])) {
            $amount = $stripe_sub['items']['data'][0]['plan']['amount'] / 100;
        }
        // Path 3: items.data[0].price.unit_amount
        elseif (isset($stripe_sub['items']['data'][0]['price']['unit_amount'])) {
            $amount = $stripe_sub['items']['data'][0]['price']['unit_amount'] / 100;
        }

        // Update local subscription
        $update_data = array(
            'status' => $new_status,
            'cancel_at_period_end' => $cancel_at_period_end,
            'current_period_start' => date('Y-m-d H:i:s', $stripe_sub['current_period_start']),
            'current_period_end' => date('Y-m-d H:i:s', $stripe_sub['current_period_end']),
            'updated_at' => current_time('mysql')
        );

        // Update billing_cycle if determined from Stripe
        if ($billing_cycle !== null) {
            $update_data['billing_cycle'] = $billing_cycle;
        }

        // Update amount if determined from Stripe
        if ($amount !== null) {
            $update_data['amount'] = $amount;
        }

        // Handle trial end
        if (!empty($stripe_sub['trial_end'])) {
            $update_data['trial_end'] = date('Y-m-d H:i:s', $stripe_sub['trial_end']);
        }

        // Handle cancellation
        if ($new_status === 'cancelled' && empty($subscription->cancelled_at)) {
            $update_data['cancelled_at'] = current_time('mysql');
            // Downgrade to free if cancelled
            self::update_org_plan($org_id, 'free');
        }

        $wpdb->update(
            $tables['subscriptions'],
            $update_data,
            array('id' => $subscription->id)
        );

        // Re-fetch the subscription from database to get the complete updated record
        $updated_subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['subscriptions']} WHERE id = %d",
            $subscription->id
        ), ARRAY_A);

        return array(
            'synced' => true,
            'old_status' => $subscription->status,
            'new_status' => $new_status,
            'billing_cycle' => $updated_subscription['billing_cycle'] ?? $billing_cycle,
            'cancel_at_period_end' => $cancel_at_period_end,
            'subscription' => $updated_subscription
        );
    }

    /**
     * Get subscription with validation
     * 
     * Returns subscription data after optionally syncing with Stripe
     * 
     * @param int $org_id Organization ID
     * @param bool $sync Whether to sync with Stripe first
     * @return array|null Subscription data
     */
    public static function get_subscription($org_id, $sync = false)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        if ($sync) {
            self::sync_subscription_status($org_id);
        }

        return $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, p.name as plan_name, p.slug as plan_slug_from_plan
             FROM {$tables['subscriptions']} s
             LEFT JOIN {$tables['plans']} p ON s.plan_id = p.id
             WHERE s.organization_id = %d
             ORDER BY s.created_at DESC LIMIT 1",
            $org_id
        ), ARRAY_A);
    }

    /**
     * Check if organization has an active paid subscription
     * 
     * @param int $org_id Organization ID
     * @return bool
     */
    public static function has_active_subscription($org_id)
    {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();

        $active_statuses = array('active', 'trialing');
        $placeholders = implode(',', array_fill(0, count($active_statuses), '%s'));

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['subscriptions']} 
             WHERE organization_id = %d 
             AND status IN ($placeholders)
             AND stripe_subscription_id IS NOT NULL
             AND stripe_subscription_id != ''",
            array_merge(array($org_id), $active_statuses)
        ));

        return intval($count) > 0;
    }

    /**
     * Get days remaining in current period
     * 
     * @param int $org_id Organization ID
     * @return int|null Days remaining or null if no subscription
     */
    public static function get_days_remaining($org_id)
    {
        $subscription = self::get_subscription($org_id);
        
        if (!$subscription || empty($subscription['current_period_end'])) {
            return null;
        }

        $end = strtotime($subscription['current_period_end']);
        $now = time();
        
        if ($end <= $now) {
            return 0;
        }

        return ceil(($end - $now) / 86400);
    }

    /**
     * Get trial days remaining
     * 
     * @param int $org_id Organization ID
     * @return int|null Trial days remaining or null if not trialing
     */
    public static function get_trial_days_remaining($org_id)
    {
        $subscription = self::get_subscription($org_id);
        
        if (!$subscription || $subscription['status'] !== 'trialing' || empty($subscription['trial_end'])) {
            return null;
        }

        $end = strtotime($subscription['trial_end']);
        $now = time();
        
        if ($end <= $now) {
            return 0;
        }

        return ceil(($end - $now) / 86400);
    }
}
