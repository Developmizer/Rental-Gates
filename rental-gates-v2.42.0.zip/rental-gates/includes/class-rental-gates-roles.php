<?php
/**
 * Rental Gates Roles Class
 * Handles user roles, capabilities, and organization-based permissions
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Roles {
    
    /**
     * Role definitions with capabilities
     */
    const ROLES = array(
        'rental_gates_site_admin' => array(
            'name' => 'RG Site Admin',
            'capabilities' => array(
                // Platform management
                'rg_manage_platform' => true,
                'rg_manage_organizations' => true,
                'rg_manage_plans' => true,
                'rg_manage_feature_flags' => true,
                'rg_manage_integrations' => true,
                'rg_manage_templates' => true,
                'rg_view_audit_logs' => true,
                'rg_support_mode' => true,
                'rg_view_all_reports' => true,
                // All other capabilities
                'rg_manage_buildings' => true,
                'rg_manage_units' => true,
                'rg_manage_tenants' => true,
                'rg_manage_leases' => true,
                'rg_manage_applications' => true,
                'rg_manage_payments' => true,
                'rg_manage_maintenance' => true,
                'rg_manage_vendors' => true,
                'rg_manage_leads' => true,
                'rg_manage_marketing' => true,
                'rg_manage_communications' => true,
                'rg_manage_settings' => true,
                'rg_manage_staff' => true,
                'rg_use_ai_tools' => true,
                'rg_view_reports' => true,
                'rg_export_data' => true,
                'read' => true,
                'upload_files' => true,
            ),
        ),
        'rental_gates_owner' => array(
            'name' => 'RG Owner',
            'capabilities' => array(
                // Full organization control
                'rg_manage_buildings' => true,
                'rg_manage_units' => true,
                'rg_manage_tenants' => true,
                'rg_manage_leases' => true,
                'rg_manage_applications' => true,
                'rg_manage_payments' => true,
                'rg_manage_maintenance' => true,
                'rg_manage_vendors' => true,
                'rg_manage_leads' => true,
                'rg_manage_marketing' => true,
                'rg_manage_communications' => true,
                'rg_manage_settings' => true,
                'rg_manage_staff' => true,
                'rg_use_ai_tools' => true,
                'rg_view_reports' => true,
                'rg_export_data' => true,
                'rg_manage_subscription' => true,
                'rg_connect_stripe' => true,
                'read' => true,
                'upload_files' => true,
            ),
        ),
        'rental_gates_manager' => array(
            'name' => 'RG Property Manager',
            'capabilities' => array(
                // Same as owner
                'rg_manage_buildings' => true,
                'rg_manage_units' => true,
                'rg_manage_tenants' => true,
                'rg_manage_leases' => true,
                'rg_manage_applications' => true,
                'rg_manage_payments' => true,
                'rg_manage_maintenance' => true,
                'rg_manage_vendors' => true,
                'rg_manage_leads' => true,
                'rg_manage_marketing' => true,
                'rg_manage_communications' => true,
                'rg_manage_settings' => true,
                'rg_manage_staff' => true,
                'rg_use_ai_tools' => true,
                'rg_view_reports' => true,
                'rg_export_data' => true,
                'rg_manage_subscription' => true,
                'rg_connect_stripe' => true,
                'read' => true,
                'upload_files' => true,
            ),
        ),
        'rental_gates_staff' => array(
            'name' => 'RG Staff',
            'capabilities' => array(
                // Limited - controlled by staff_permissions table
                'rg_view_buildings' => true,
                'rg_view_units' => true,
                'rg_view_tenants' => true,
                'rg_view_leases' => true,
                'rg_view_applications' => true,
                'rg_view_payments' => true,
                'rg_view_maintenance' => true,
                'rg_view_vendors' => true,
                'rg_view_leads' => true,
                'rg_view_marketing' => true,
                'rg_send_messages' => true,
                'read' => true,
                'upload_files' => true,
            ),
        ),
        'rental_gates_tenant' => array(
            'name' => 'RG Tenant',
            'capabilities' => array(
                // Tenant portal access
                'rg_access_tenant_portal' => true,
                'rg_view_own_lease' => true,
                'rg_make_payments' => true,
                'rg_submit_maintenance' => true,
                'rg_view_own_documents' => true,
                'rg_send_messages' => true,
                'read' => true,
            ),
        ),
        'rental_gates_vendor' => array(
            'name' => 'RG Vendor',
            'capabilities' => array(
                // Vendor portal access
                'rg_access_vendor_portal' => true,
                'rg_view_assigned_work_orders' => true,
                'rg_update_work_orders' => true,
                'rg_view_own_payouts' => true,
                'rg_send_messages' => true,
                'read' => true,
                'upload_files' => true,
            ),
        ),
    );
    
    /**
     * Staff permission modules
     */
    const STAFF_MODULES = array(
        'buildings' => 'Buildings & Units',
        'tenants' => 'Tenants',
        'leases' => 'Leases',
        'applications' => 'Applications',
        'payments' => 'Payments',
        'maintenance' => 'Maintenance',
        'vendors' => 'Vendors',
        'leads' => 'Leads',
        'marketing' => 'Marketing',
        'reports' => 'Reports',
        'settings' => 'Settings',
    );
    
    /**
     * Permission templates
     */
    const PERMISSION_TEMPLATES = array(
        'full_access' => array(
            'name' => 'Full Access',
            'description' => 'Full access to all modules',
            'permissions' => array(
                'buildings' => 'full',
                'tenants' => 'full',
                'leases' => 'full',
                'applications' => 'full',
                'payments' => 'full',
                'maintenance' => 'full',
                'vendors' => 'full',
                'leads' => 'full',
                'marketing' => 'full',
                'reports' => 'full',
                'settings' => 'view',
            ),
        ),
        'leasing_agent' => array(
            'name' => 'Leasing Agent',
            'description' => 'Applications, Leads, and viewing',
            'permissions' => array(
                'buildings' => 'view',
                'tenants' => 'view',
                'leases' => 'view',
                'applications' => 'full',
                'payments' => 'view',
                'maintenance' => 'view',
                'vendors' => 'none',
                'leads' => 'full',
                'marketing' => 'full',
                'reports' => 'view',
                'settings' => 'none',
            ),
        ),
        'maintenance_coordinator' => array(
            'name' => 'Maintenance Coordinator',
            'description' => 'Maintenance and vendor management',
            'permissions' => array(
                'buildings' => 'view',
                'tenants' => 'view',
                'leases' => 'none',
                'applications' => 'none',
                'payments' => 'none',
                'maintenance' => 'full',
                'vendors' => 'full',
                'leads' => 'none',
                'marketing' => 'none',
                'reports' => 'view',
                'settings' => 'none',
            ),
        ),
        'bookkeeper' => array(
            'name' => 'Bookkeeper',
            'description' => 'Payments and reports',
            'permissions' => array(
                'buildings' => 'view',
                'tenants' => 'view',
                'leases' => 'view',
                'applications' => 'none',
                'payments' => 'full',
                'maintenance' => 'view',
                'vendors' => 'view',
                'leads' => 'none',
                'marketing' => 'none',
                'reports' => 'full',
                'settings' => 'none',
            ),
        ),
        'read_only' => array(
            'name' => 'Read Only',
            'description' => 'View everything, modify nothing',
            'permissions' => array(
                'buildings' => 'view',
                'tenants' => 'view',
                'leases' => 'view',
                'applications' => 'view',
                'payments' => 'view',
                'maintenance' => 'view',
                'vendors' => 'view',
                'leads' => 'view',
                'marketing' => 'view',
                'reports' => 'view',
                'settings' => 'view',
            ),
        ),
    );
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'register_roles'));
    }
    
    /**
     * Register custom roles
     */
    public function register_roles() {
        foreach (self::ROLES as $role_slug => $role_data) {
            $existing_role = get_role($role_slug);
            
            if (!$existing_role) {
                add_role($role_slug, $role_data['name'], $role_data['capabilities']);
            } else {
                // Update capabilities if role exists
                foreach ($role_data['capabilities'] as $cap => $grant) {
                    if ($grant) {
                        $existing_role->add_cap($cap);
                    } else {
                        $existing_role->remove_cap($cap);
                    }
                }
            }
        }
        
        // Add capabilities to administrator
        $admin = get_role('administrator');
        if ($admin) {
            foreach (self::ROLES['rental_gates_site_admin']['capabilities'] as $cap => $grant) {
                if ($grant) {
                    $admin->add_cap($cap);
                }
            }
        }
    }
    
    /**
     * Remove all custom roles
     */
    public static function remove_roles() {
        foreach (array_keys(self::ROLES) as $role_slug) {
            remove_role($role_slug);
        }
    }
    
    /**
     * Check if user has a specific Rental Gates role
     */
    public static function is_rental_gates_user($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        // Check for rental gates roles
        $rg_roles = array_keys(self::ROLES);
        if (!empty(array_intersect($rg_roles, (array) $user->roles))) {
            return true;
        }
        
        // Also allow WordPress administrators (they can access everything)
        if (in_array('administrator', (array) $user->roles)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Check if user is site admin
     */
    public static function is_site_admin($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        return in_array('rental_gates_site_admin', (array) $user->roles) || 
               in_array('administrator', (array) $user->roles);
    }
    
    /**
     * Check if user is owner or manager
     */
    public static function is_owner_or_manager($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        return in_array('rental_gates_owner', (array) $user->roles) || 
               in_array('rental_gates_manager', (array) $user->roles) ||
               self::is_site_admin($user_id);
    }
    
    /**
     * Check if user is staff
     */
    public static function is_staff($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        return in_array('rental_gates_staff', (array) $user->roles);
    }
    
    /**
     * Check if user is tenant
     */
    public static function is_tenant($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        return in_array('rental_gates_tenant', (array) $user->roles);
    }
    
    /**
     * Check if user is vendor
     */
    public static function is_vendor($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        return in_array('rental_gates_vendor', (array) $user->roles);
    }
    
    /**
     * Get user's organization ID
     */
    public static function get_organization_id($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return null;
        }
        
        global $wpdb;
        
        // Check if tables exist
        if (!class_exists('Rental_Gates_Database')) {
            return null;
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check if organization_members table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['organization_members']}'");
        if (!$table_exists) {
            return null;
        }
        
        // Check organization_members table
        $org_id = $wpdb->get_var($wpdb->prepare(
            "SELECT organization_id FROM {$tables['organization_members']} 
             WHERE user_id = %d AND status = 'active' 
             LIMIT 1",
            $user_id
        ));
        
        if ($org_id) {
            return intval($org_id);
        }
        
        // Check if tenants table exists before querying
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['tenants']}'");
        if ($table_exists) {
            // Check if tenant
            $org_id = $wpdb->get_var($wpdb->prepare(
                "SELECT organization_id FROM {$tables['tenants']} 
                 WHERE user_id = %d AND status = 'active' 
                 LIMIT 1",
                $user_id
            ));
            
            if ($org_id) {
                return intval($org_id);
            }
        }
        
        // Check if vendors table exists before querying
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['vendors']}'");
        if ($table_exists) {
            // Check if vendor
            $org_id = $wpdb->get_var($wpdb->prepare(
                "SELECT organization_id FROM {$tables['vendors']} 
                 WHERE user_id = %d AND status = 'active' 
                 LIMIT 1",
                $user_id
            ));
            
            if ($org_id) {
                return intval($org_id);
            }
        }
        
        // For administrators without an organization, auto-create one
        $user = get_userdata($user_id);
        if ($user && (in_array('administrator', (array) $user->roles) || user_can($user_id, 'manage_options'))) {
            $org_id = self::auto_create_organization_for_user($user_id);
            if ($org_id) {
                return intval($org_id);
            }
        }
        
        return null;
    }
    
    /**
     * Auto-create organization for a user
     */
    private static function auto_create_organization_for_user($user_id) {
        global $wpdb;
        
        $user = get_userdata($user_id);
        if (!$user) {
            return null;
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check if organizations table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['organizations']}'");
        if (!$table_exists) {
            return null;
        }
        
        // Create organization
        $org_name = $user->display_name ? $user->display_name . "'s Properties" : 'My Properties';
        $org_slug = sanitize_title($org_name) . '-' . $user_id;
        
        $result = $wpdb->insert(
            $tables['organizations'],
            array(
                'name' => $org_name,
                'slug' => $org_slug,
                'contact_email' => $user->user_email,
                'status' => 'active',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            )
        );
        
        if ($result === false) {
            error_log('Rental Gates: Failed to auto-create organization: ' . $wpdb->last_error);
            return null;
        }
        
        $org_id = $wpdb->insert_id;
        
        // Add user as owner
        $wpdb->insert(
            $tables['organization_members'],
            array(
                'organization_id' => $org_id,
                'user_id' => $user_id,
                'role' => 'owner',
                'is_primary_owner' => 1,
                'status' => 'active',
                'joined_at' => current_time('mysql'),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            )
        );
        
        // Assign the owner role to the user
        $user->add_role('rental_gates_owner');
        
        error_log('Rental Gates: Auto-created organization ' . $org_id . ' for user ' . $user_id);
        
        return $org_id;
    }
    
    /**
     * Get user's primary role in Rental Gates
     */
    public static function get_primary_role($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return null;
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return null;
        }
        
        // Priority order
        $role_priority = array(
            'rental_gates_site_admin',
            'rental_gates_owner',
            'rental_gates_manager',
            'rental_gates_staff',
            'rental_gates_tenant',
            'rental_gates_vendor',
        );
        
        foreach ($role_priority as $role) {
            if (in_array($role, (array) $user->roles)) {
                return $role;
            }
        }
        
        // Check for administrator
        if (in_array('administrator', (array) $user->roles)) {
            return 'rental_gates_site_admin';
        }
        
        return null;
    }
    
    /**
     * Get staff permissions for a user in an organization
     */
    public static function get_staff_permissions($user_id, $organization_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $permissions = $wpdb->get_results($wpdb->prepare(
            "SELECT module, permission_level, building_ids 
             FROM {$tables['staff_permissions']} 
             WHERE user_id = %d AND organization_id = %d",
            $user_id,
            $organization_id
        ), ARRAY_A);
        
        $result = array();
        foreach ($permissions as $perm) {
            $result[$perm['module']] = array(
                'level' => $perm['permission_level'],
                'building_ids' => $perm['building_ids'] ? json_decode($perm['building_ids'], true) : null,
            );
        }
        
        return $result;
    }
    
    /**
     * Check if staff has permission for a module
     */
    public static function staff_can($user_id, $organization_id, $module, $action = 'view') {
        $permissions = self::get_staff_permissions($user_id, $organization_id);
        
        if (!isset($permissions[$module])) {
            return false;
        }
        
        $level = $permissions[$module]['level'];
        
        if ($level === 'none') {
            return false;
        }
        
        if ($action === 'view') {
            return in_array($level, array('view', 'full'));
        }
        
        if ($action === 'edit' || $action === 'full') {
            return $level === 'full';
        }
        
        return false;
    }
    
    /**
     * Check if staff can access a specific building
     */
    public static function staff_can_access_building($user_id, $organization_id, $building_id) {
        $permissions = self::get_staff_permissions($user_id, $organization_id);
        
        // Check buildings module
        if (!isset($permissions['buildings'])) {
            return false;
        }
        
        $building_ids = $permissions['buildings']['building_ids'];
        
        // null means all buildings
        if ($building_ids === null) {
            return true;
        }
        
        return in_array($building_id, $building_ids);
    }
    
    /**
     * Set staff permissions
     */
    public static function set_staff_permissions($user_id, $organization_id, $module, $level, $building_ids = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $data = array(
            'organization_id' => $organization_id,
            'user_id' => $user_id,
            'module' => $module,
            'permission_level' => $level,
            'building_ids' => $building_ids ? wp_json_encode($building_ids) : null,
            'updated_at' => current_time('mysql'),
        );
        
        // Check if exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$tables['staff_permissions']} 
             WHERE organization_id = %d AND user_id = %d AND module = %s",
            $organization_id,
            $user_id,
            $module
        ));
        
        if ($existing) {
            $wpdb->update(
                $tables['staff_permissions'],
                $data,
                array('id' => $existing)
            );
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($tables['staff_permissions'], $data);
        }
        
        return true;
    }
    
    /**
     * Apply permission template to staff
     */
    public static function apply_permission_template($user_id, $organization_id, $template_slug, $building_ids = null) {
        if (!isset(self::PERMISSION_TEMPLATES[$template_slug])) {
            return false;
        }
        
        $template = self::PERMISSION_TEMPLATES[$template_slug];
        
        foreach ($template['permissions'] as $module => $level) {
            self::set_staff_permissions($user_id, $organization_id, $module, $level, $building_ids);
        }
        
        return true;
    }
    
    /**
     * Get redirect URL for user based on role
     */
    public static function get_dashboard_url($user_id = null) {
        $role = self::get_primary_role($user_id);
        
        switch ($role) {
            case 'rental_gates_site_admin':
                return home_url('/rental-gates/admin');
            case 'rental_gates_owner':
            case 'rental_gates_manager':
                return home_url('/rental-gates/dashboard');
            case 'rental_gates_staff':
                return home_url('/rental-gates/staff');
            case 'rental_gates_tenant':
                return home_url('/rental-gates/tenant');
            case 'rental_gates_vendor':
                return home_url('/rental-gates/vendor');
            default:
                return home_url('/rental-gates/map');
        }
    }
    
    /**
     * Get user capabilities for current organization context
     */
    public static function get_user_capabilities($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $role = self::get_primary_role($user_id);
        $org_id = self::get_organization_id($user_id);
        
        $capabilities = array(
            'role' => $role,
            'organization_id' => $org_id,
            'is_site_admin' => self::is_site_admin($user_id),
            'is_owner' => self::is_owner_or_manager($user_id),
            'is_staff' => self::is_staff($user_id),
            'is_tenant' => self::is_tenant($user_id),
            'is_vendor' => self::is_vendor($user_id),
            'modules' => array(),
        );
        
        // For staff, get detailed permissions
        if ($role === 'rental_gates_staff' && $org_id) {
            $permissions = self::get_staff_permissions($user_id, $org_id);
            foreach (self::STAFF_MODULES as $module => $label) {
                $capabilities['modules'][$module] = isset($permissions[$module]) 
                    ? $permissions[$module]['level'] 
                    : 'none';
            }
        } elseif (in_array($role, array('rental_gates_owner', 'rental_gates_manager', 'rental_gates_site_admin'))) {
            // Full access
            foreach (self::STAFF_MODULES as $module => $label) {
                $capabilities['modules'][$module] = 'full';
            }
        }
        
        return $capabilities;
    }
}
