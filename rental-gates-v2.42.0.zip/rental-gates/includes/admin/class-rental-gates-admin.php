<?php
/**
 * Rental Gates Admin Class
 * Handles WordPress admin area settings and pages
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            __('Rental Gates', 'rental-gates'),
            __('Rental Gates', 'rental-gates'),
            'manage_options',
            'rental-gates',
            array($this, 'render_dashboard_page'),
            'dashicons-building',
            30
        );
        
        // Dashboard
        add_submenu_page(
            'rental-gates',
            __('Dashboard', 'rental-gates'),
            __('Dashboard', 'rental-gates'),
            'manage_options',
            'rental-gates',
            array($this, 'render_dashboard_page')
        );
        
        // Settings
        add_submenu_page(
            'rental-gates',
            __('Settings', 'rental-gates'),
            __('Settings', 'rental-gates'),
            'manage_options',
            'rental-gates-settings',
            array($this, 'render_settings_page')
        );
        
        // Map Settings
        add_submenu_page(
            'rental-gates',
            __('Map Settings', 'rental-gates'),
            __('Map Settings', 'rental-gates'),
            'manage_options',
            'rental-gates-maps',
            array($this, 'render_maps_page')
        );
        
        // Stripe Settings
        add_submenu_page(
            'rental-gates',
            __('Payment Settings', 'rental-gates'),
            __('Payments', 'rental-gates'),
            'manage_options',
            'rental-gates-payments',
            array($this, 'render_payments_page')
        );
        
        // AI Settings
        add_submenu_page(
            'rental-gates',
            __('AI Settings', 'rental-gates'),
            __('AI Tools', 'rental-gates'),
            'manage_options',
            'rental-gates-ai',
            array($this, 'render_ai_page')
        );
        
        // Email Settings
        add_submenu_page(
            'rental-gates',
            __('Email Settings', 'rental-gates'),
            __('Email', 'rental-gates'),
            'manage_options',
            'rental-gates-email',
            array($this, 'render_email_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // General settings
        register_setting('rental_gates_general', 'rental_gates_default_language');
        register_setting('rental_gates_general', 'rental_gates_allow_rtl');
        register_setting('rental_gates_general', 'rental_gates_coming_soon_window');
        register_setting('rental_gates_general', 'rental_gates_renewal_notice_days');
        register_setting('rental_gates_general', 'rental_gates_move_in_notice_days');
        register_setting('rental_gates_general', 'rental_gates_delete_data_on_uninstall');
        
        // Map settings
        register_setting('rental_gates_maps', 'rental_gates_map_provider');
        register_setting('rental_gates_maps', 'rental_gates_google_maps_api_key');
        register_setting('rental_gates_maps', 'rental_gates_nominatim_url');
        register_setting('rental_gates_maps', 'rental_gates_openstreetmap_tile_server');
        
        // Stripe settings
        register_setting('rental_gates_payments', 'rental_gates_stripe_mode');
        register_setting('rental_gates_payments', 'rental_gates_stripe_test_publishable_key');
        register_setting('rental_gates_payments', 'rental_gates_stripe_test_secret_key');
        register_setting('rental_gates_payments', 'rental_gates_stripe_live_publishable_key');
        register_setting('rental_gates_payments', 'rental_gates_stripe_live_secret_key');
        register_setting('rental_gates_payments', 'rental_gates_stripe_webhook_secret');
        register_setting('rental_gates_payments', 'rental_gates_platform_fee_percentage');
        
        // AI settings
        register_setting('rental_gates_ai', 'rental_gates_enable_ai_tools');
        register_setting('rental_gates_ai', 'rental_gates_ai_provider');
        register_setting('rental_gates_ai', 'rental_gates_openai_api_key');
        register_setting('rental_gates_ai', 'rental_gates_gemini_api_key');
        
        // Email settings
        register_setting('rental_gates_email', 'rental_gates_email_from_name');
        register_setting('rental_gates_email', 'rental_gates_email_from_address');
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get stats
        $org_count = $wpdb->get_var("SELECT COUNT(*) FROM {$tables['organizations']}");
        $building_count = $wpdb->get_var("SELECT COUNT(*) FROM {$tables['buildings']}");
        $unit_count = $wpdb->get_var("SELECT COUNT(*) FROM {$tables['units']}");
        $tenant_count = $wpdb->get_var("SELECT COUNT(*) FROM {$tables['tenants']} WHERE status = 'active'");
        
        ?>
        <div class="wrap">
            <h1><?php _e('Rental Gates Dashboard', 'rental-gates'); ?></h1>
            
            <div class="rental-gates-admin-cards" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px;">
                <div class="card" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h3 style="margin-top: 0;"><?php _e('Organizations', 'rental-gates'); ?></h3>
                    <p style="font-size: 32px; font-weight: bold; margin: 0;"><?php echo number_format($org_count); ?></p>
                </div>
                <div class="card" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h3 style="margin-top: 0;"><?php _e('Buildings', 'rental-gates'); ?></h3>
                    <p style="font-size: 32px; font-weight: bold; margin: 0;"><?php echo number_format($building_count); ?></p>
                </div>
                <div class="card" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h3 style="margin-top: 0;"><?php _e('Units', 'rental-gates'); ?></h3>
                    <p style="font-size: 32px; font-weight: bold; margin: 0;"><?php echo number_format($unit_count); ?></p>
                </div>
                <div class="card" style="padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h3 style="margin-top: 0;"><?php _e('Active Tenants', 'rental-gates'); ?></h3>
                    <p style="font-size: 32px; font-weight: bold; margin: 0;"><?php echo number_format($tenant_count); ?></p>
                </div>
            </div>
            
            <div class="card" style="margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                <h2><?php _e('Quick Links', 'rental-gates'); ?></h2>
                <p>
                    <a href="<?php echo home_url('/rental-gates/admin'); ?>" class="button button-primary" target="_blank">
                        <?php _e('Open Site Admin Dashboard', 'rental-gates'); ?>
                    </a>
                    <a href="<?php echo home_url('/rental-gates/map'); ?>" class="button" target="_blank">
                        <?php _e('View Public Map', 'rental-gates'); ?>
                    </a>
                    <a href="<?php echo home_url('/rental-gates/pricing'); ?>" class="button" target="_blank">
                        <?php _e('View Pricing Page', 'rental-gates'); ?>
                    </a>
                </p>
            </div>
            
            <div class="card" style="margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                <h2><?php _e('Plugin Information', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php _e('Version', 'rental-gates'); ?></th>
                        <td><?php echo RENTAL_GATES_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Database Version', 'rental-gates'); ?></th>
                        <td><?php echo RENTAL_GATES_DB_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Map Provider', 'rental-gates'); ?></th>
                        <td><?php echo ucfirst(get_option('rental_gates_map_provider', 'google')); ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('AI Tools', 'rental-gates'); ?></th>
                        <td><?php echo get_option('rental_gates_enable_ai_tools') ? __('Enabled', 'rental-gates') : __('Disabled', 'rental-gates'); ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Stripe Mode', 'rental-gates'); ?></th>
                        <td><?php echo ucfirst(get_option('rental_gates_stripe_mode', 'test')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Rental Gates Settings', 'rental-gates'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('rental_gates_general'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Default Language', 'rental-gates'); ?></th>
                        <td>
                            <select name="rental_gates_default_language">
                                <option value="en" <?php selected(get_option('rental_gates_default_language'), 'en'); ?>>English</option>
                                <option value="ar" <?php selected(get_option('rental_gates_default_language'), 'ar'); ?>>العربية (Arabic)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Enable RTL Support', 'rental-gates'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="rental_gates_allow_rtl" value="1" <?php checked(get_option('rental_gates_allow_rtl'), 1); ?>>
                                <?php _e('Enable right-to-left layout for Arabic', 'rental-gates'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Coming Soon Window', 'rental-gates'); ?></th>
                        <td>
                            <input type="number" name="rental_gates_coming_soon_window" value="<?php echo esc_attr(get_option('rental_gates_coming_soon_window', 30)); ?>" min="1" max="90">
                            <p class="description"><?php _e('Days before available date to show unit as "Coming Soon"', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Renewal Notice', 'rental-gates'); ?></th>
                        <td>
                            <input type="number" name="rental_gates_renewal_notice_days" value="<?php echo esc_attr(get_option('rental_gates_renewal_notice_days', 60)); ?>" min="30" max="180">
                            <p class="description"><?php _e('Days before lease end to send renewal notices', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Move-in Notice', 'rental-gates'); ?></th>
                        <td>
                            <input type="number" name="rental_gates_move_in_notice_days" value="<?php echo esc_attr(get_option('rental_gates_move_in_notice_days', 7)); ?>" min="1" max="30">
                            <p class="description"><?php _e('Days before move-in to trigger checklist', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Delete Data on Uninstall', 'rental-gates'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="rental_gates_delete_data_on_uninstall" value="1" <?php checked(get_option('rental_gates_delete_data_on_uninstall'), 1); ?>>
                                <?php _e('Delete all plugin data when uninstalled (dangerous!)', 'rental-gates'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render maps settings page
     */
    public function render_maps_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Map Settings', 'rental-gates'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('rental_gates_maps'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Map Provider', 'rental-gates'); ?></th>
                        <td>
                            <select name="rental_gates_map_provider" id="rental_gates_map_provider">
                                <option value="google" <?php selected(get_option('rental_gates_map_provider'), 'google'); ?>>Google Maps</option>
                                <option value="openstreetmap" <?php selected(get_option('rental_gates_map_provider'), 'openstreetmap'); ?>>OpenStreetMap (Free)</option>
                            </select>
                            <p class="description"><?php _e('Select your preferred map provider', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <div id="google-maps-settings">
                    <h2><?php _e('Google Maps Settings', 'rental-gates'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('API Key', 'rental-gates'); ?></th>
                            <td>
                                <input type="text" name="rental_gates_google_maps_api_key" value="<?php echo esc_attr(get_option('rental_gates_google_maps_api_key')); ?>" class="regular-text">
                                <p class="description">
                                    <?php _e('Get your API key from', 'rental-gates'); ?>
                                    <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div id="osm-settings">
                    <h2><?php _e('OpenStreetMap Settings', 'rental-gates'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Custom Nominatim URL', 'rental-gates'); ?></th>
                            <td>
                                <input type="url" name="rental_gates_nominatim_url" value="<?php echo esc_attr(get_option('rental_gates_nominatim_url')); ?>" class="regular-text" placeholder="https://nominatim.openstreetmap.org">
                                <p class="description"><?php _e('Leave empty to use default Nominatim server', 'rental-gates'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Custom Tile Server', 'rental-gates'); ?></th>
                            <td>
                                <input type="text" name="rental_gates_openstreetmap_tile_server" value="<?php echo esc_attr(get_option('rental_gates_openstreetmap_tile_server')); ?>" class="regular-text" placeholder="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png">
                                <p class="description"><?php _e('Leave empty for default OpenStreetMap tiles', 'rental-gates'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <?php submit_button(); ?>
            </form>
            
            <script>
            jQuery(document).ready(function($) {
                function toggleMapSettings() {
                    var provider = $('#rental_gates_map_provider').val();
                    if (provider === 'google') {
                        $('#google-maps-settings').show();
                        $('#osm-settings').hide();
                    } else {
                        $('#google-maps-settings').hide();
                        $('#osm-settings').show();
                    }
                }
                
                toggleMapSettings();
                $('#rental_gates_map_provider').on('change', toggleMapSettings);
            });
            </script>
        </div>
        <?php
    }
    
    /**
     * Render payments settings page
     */
    public function render_payments_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Payment Settings', 'rental-gates'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('rental_gates_payments'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Stripe Mode', 'rental-gates'); ?></th>
                        <td>
                            <select name="rental_gates_stripe_mode">
                                <option value="test" <?php selected(get_option('rental_gates_stripe_mode'), 'test'); ?>><?php _e('Test Mode', 'rental-gates'); ?></option>
                                <option value="live" <?php selected(get_option('rental_gates_stripe_mode'), 'live'); ?>><?php _e('Live Mode', 'rental-gates'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Platform Fee', 'rental-gates'); ?></th>
                        <td>
                            <input type="number" name="rental_gates_platform_fee_percentage" value="<?php echo esc_attr(get_option('rental_gates_platform_fee_percentage', 2.5)); ?>" min="0" max="10" step="0.1">%
                            <p class="description"><?php _e('Platform fee percentage on transactions', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Test Keys', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Test Publishable Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="text" name="rental_gates_stripe_test_publishable_key" value="<?php echo esc_attr(get_option('rental_gates_stripe_test_publishable_key')); ?>" class="regular-text" placeholder="pk_test_...">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Test Secret Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="password" name="rental_gates_stripe_test_secret_key" value="<?php echo esc_attr(get_option('rental_gates_stripe_test_secret_key')); ?>" class="regular-text" placeholder="sk_test_...">
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Live Keys', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Live Publishable Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="text" name="rental_gates_stripe_live_publishable_key" value="<?php echo esc_attr(get_option('rental_gates_stripe_live_publishable_key')); ?>" class="regular-text" placeholder="pk_live_...">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Live Secret Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="password" name="rental_gates_stripe_live_secret_key" value="<?php echo esc_attr(get_option('rental_gates_stripe_live_secret_key')); ?>" class="regular-text" placeholder="sk_live_...">
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Webhook', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Webhook URL', 'rental-gates'); ?></th>
                        <td>
                            <code><?php echo rest_url('rental-gates/v1/webhooks/stripe'); ?></code>
                            <p class="description"><?php _e('Add this URL in your Stripe Dashboard', 'rental-gates'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Webhook Secret', 'rental-gates'); ?></th>
                        <td>
                            <input type="password" name="rental_gates_stripe_webhook_secret" value="<?php echo esc_attr(get_option('rental_gates_stripe_webhook_secret')); ?>" class="regular-text" placeholder="whsec_...">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render AI settings page
     */
    public function render_ai_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('AI Settings', 'rental-gates'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('rental_gates_ai'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Enable AI Tools', 'rental-gates'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="rental_gates_enable_ai_tools" value="1" <?php checked(get_option('rental_gates_enable_ai_tools'), 1); ?>>
                                <?php _e('Enable AI-powered features', 'rental-gates'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Default AI Provider', 'rental-gates'); ?></th>
                        <td>
                            <select name="rental_gates_ai_provider">
                                <option value="openai" <?php selected(get_option('rental_gates_ai_provider'), 'openai'); ?>>OpenAI (GPT-4)</option>
                                <option value="gemini" <?php selected(get_option('rental_gates_ai_provider'), 'gemini'); ?>>Google Gemini</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('OpenAI Settings', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('OpenAI API Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="password" name="rental_gates_openai_api_key" value="<?php echo esc_attr(get_option('rental_gates_openai_api_key')); ?>" class="regular-text" placeholder="sk-...">
                            <p class="description">
                                <?php _e('Get your API key from', 'rental-gates'); ?>
                                <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Google Gemini Settings', 'rental-gates'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Gemini API Key', 'rental-gates'); ?></th>
                        <td>
                            <input type="password" name="rental_gates_gemini_api_key" value="<?php echo esc_attr(get_option('rental_gates_gemini_api_key')); ?>" class="regular-text">
                            <p class="description">
                                <?php _e('Get your API key from', 'rental-gates'); ?>
                                <a href="https://makersuite.google.com/app/apikey" target="_blank">Google AI Studio</a>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('AI Credit Costs', 'rental-gates'); ?></h2>
                <table class="widefat" style="max-width: 500px;">
                    <thead>
                        <tr>
                            <th><?php _e('Tool', 'rental-gates'); ?></th>
                            <th><?php _e('Credits per Use', 'rental-gates'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td><?php _e('Description Generator', 'rental-gates'); ?></td><td>2</td></tr>
                        <tr><td><?php _e('Maintenance Categorizer', 'rental-gates'); ?></td><td>1</td></tr>
                        <tr><td><?php _e('Applicant Screening', 'rental-gates'); ?></td><td>10</td></tr>
                        <tr><td><?php _e('Marketing Copy', 'rental-gates'); ?></td><td>2</td></tr>
                        <tr><td><?php _e('Message Suggestions', 'rental-gates'); ?></td><td>1</td></tr>
                        <tr><td><?php _e('Report Insights', 'rental-gates'); ?></td><td>5</td></tr>
                    </tbody>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render email settings page
     */
    public function render_email_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Email Settings', 'rental-gates'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('rental_gates_email'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('From Name', 'rental-gates'); ?></th>
                        <td>
                            <input type="text" name="rental_gates_email_from_name" value="<?php echo esc_attr(get_option('rental_gates_email_from_name', get_bloginfo('name'))); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('From Email', 'rental-gates'); ?></th>
                        <td>
                            <input type="email" name="rental_gates_email_from_address" value="<?php echo esc_attr(get_option('rental_gates_email_from_address', get_option('admin_email'))); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <h2><?php _e('Email Templates', 'rental-gates'); ?></h2>
            <p><?php _e('The following email templates are available:', 'rental-gates'); ?></p>
            <ul style="list-style: disc; margin-left: 20px;">
                <?php foreach (Rental_Gates_Email::TEMPLATES as $key => $subject): ?>
                    <li><code><?php echo esc_html($key); ?></code> - <?php echo esc_html($subject); ?></li>
                <?php endforeach; ?>
            </ul>
            <p class="description">
                <?php _e('You can customize templates by creating files in your theme:', 'rental-gates'); ?>
                <code>your-theme/rental-gates/emails/{template-name}.php</code>
            </p>
        </div>
        <?php
    }
}
