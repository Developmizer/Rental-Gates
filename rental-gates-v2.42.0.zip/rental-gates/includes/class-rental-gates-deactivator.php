<?php
/**
 * Rental Gates Deactivator Class
 * Handles plugin deactivation tasks
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Deactivator {
    
    /**
     * Deactivate the plugin
     */
    public static function deactivate() {
        // Clear scheduled cron jobs
        self::clear_cron_jobs();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Log deactivation
        self::log_deactivation();
        
        // Set deactivation flag
        update_option('rental_gates_deactivated', time());
    }
    
    /**
     * Clear all scheduled cron jobs
     */
    private static function clear_cron_jobs() {
        $cron_hooks = array(
            'rental_gates_availability_cron',
            'rental_gates_notifications_cron',
            'rental_gates_ai_credits_reset',
            'rental_gates_cleanup_temp',
        );
        
        foreach ($cron_hooks as $hook) {
            $timestamp = wp_next_scheduled($hook);
            if ($timestamp) {
                wp_unschedule_event($timestamp, $hook);
            }
            // Also clear any remaining events
            wp_clear_scheduled_hook($hook);
        }
    }
    
    /**
     * Log deactivation
     */
    private static function log_deactivation() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Only log if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $tables['activity_log']
        ));
        
        if ($table_exists) {
            $wpdb->insert(
                $tables['activity_log'],
                array(
                    'user_id' => get_current_user_id(),
                    'action' => 'plugin_deactivated',
                    'new_values' => wp_json_encode(array(
                        'version' => RENTAL_GATES_VERSION,
                        'reason' => 'manual_deactivation',
                    )),
                    'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
                    'created_at' => current_time('mysql'),
                ),
                array('%d', '%s', '%s', '%s', '%s')
            );
        }
    }
    
    /**
     * Uninstall the plugin (called from uninstall.php)
     */
    public static function uninstall() {
        // Only run if user can manage options
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Check if user wants to delete data
        $delete_data = get_option('rental_gates_delete_data_on_uninstall', false);
        
        if ($delete_data) {
            // Drop all database tables
            Rental_Gates_Database::drop_tables();
            
            // Remove all options
            self::delete_options();
            
            // Remove user roles
            Rental_Gates_Roles::remove_roles();
            
            // Delete upload directory
            self::delete_upload_directory();
            
            // Delete user meta
            self::delete_user_meta();
        }
        
        // Clear cron jobs
        self::clear_cron_jobs();
    }
    
    /**
     * Delete all plugin options
     */
    private static function delete_options() {
        global $wpdb;
        
        // Delete options starting with rental_gates_
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'rental_gates_%'"
        );
        
        // Delete transients
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rental_gates_%'"
        );
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_rental_gates_%'"
        );
    }
    
    /**
     * Delete upload directory
     */
    private static function delete_upload_directory() {
        $upload_dir = wp_upload_dir();
        $rental_gates_dir = $upload_dir['basedir'] . '/rental-gates';
        
        if (is_dir($rental_gates_dir)) {
            self::recursive_delete($rental_gates_dir);
        }
    }
    
    /**
     * Recursively delete a directory
     */
    private static function recursive_delete($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            
            if (is_dir($path)) {
                self::recursive_delete($path);
            } else {
                unlink($path);
            }
        }
        
        rmdir($dir);
    }
    
    /**
     * Delete user meta related to plugin
     */
    private static function delete_user_meta() {
        global $wpdb;
        
        $wpdb->query(
            "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'rental_gates_%'"
        );
    }
}
