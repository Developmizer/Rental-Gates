<?php
/**
 * Rental Gates Lease Model
 * 
 * Handles lease management including CRUD operations,
 * tenant assignments, and lease lifecycle.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Lease {
    
    private static $table_name;
    private static $lease_tenants_table;
    
    /**
     * Initialize table names
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['leases'];
            self::$lease_tenants_table = $tables['lease_tenants'];
        }
    }
    
    /**
     * Create a new lease
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $required = array('organization_id', 'unit_id', 'start_date', 'rent_amount');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return new WP_Error('missing_field', sprintf(__('Missing required field: %s', 'rental-gates'), $field));
            }
        }
        
        // Validate unit belongs to organization
        $unit = Rental_Gates_Unit::get($data['unit_id']);
        if (!$unit) {
            return new WP_Error('invalid_unit', __('Unit not found', 'rental-gates'));
        }
        
        $building = Rental_Gates_Building::get($unit['building_id']);
        if (!$building || $building['organization_id'] != $data['organization_id']) {
            return new WP_Error('invalid_unit', __('Unit does not belong to this organization', 'rental-gates'));
        }
        
        // Check for overlapping active leases on same unit
        if (empty($data['skip_overlap_check'])) {
            $overlap = self::check_overlap($data['unit_id'], $data['start_date'], $data['end_date'] ?? null);
            if ($overlap) {
                return new WP_Error('lease_overlap', __('This unit already has an active lease during this period', 'rental-gates'));
            }
        }
        
        // Prepare insert data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'unit_id' => intval($data['unit_id']),
            'application_id' => !empty($data['application_id']) ? intval($data['application_id']) : null,
            'previous_lease_id' => !empty($data['previous_lease_id']) ? intval($data['previous_lease_id']) : null,
            'start_date' => sanitize_text_field($data['start_date']),
            'end_date' => !empty($data['end_date']) ? sanitize_text_field($data['end_date']) : null,
            'is_month_to_month' => !empty($data['is_month_to_month']) ? 1 : 0,
            'notice_period_days' => intval($data['notice_period_days'] ?? 30),
            'rent_amount' => floatval($data['rent_amount']),
            'deposit_amount' => isset($data['deposit_amount']) ? floatval($data['deposit_amount']) : null,
            'billing_frequency' => in_array($data['billing_frequency'] ?? '', array('monthly', 'weekly', 'biweekly')) 
                ? $data['billing_frequency'] : 'monthly',
            'billing_day' => intval($data['billing_day'] ?? 1),
            'status' => in_array($data['status'] ?? '', array('draft', 'active', 'ending', 'ended', 'renewed')) 
                ? $data['status'] : 'draft',
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating lease', 'rental-gates'));
        }
        
        $lease_id = $wpdb->insert_id;
        
        // Add tenants if provided
        if (!empty($data['tenants']) && is_array($data['tenants'])) {
            foreach ($data['tenants'] as $tenant_data) {
                self::add_tenant($lease_id, $tenant_data['tenant_id'], $tenant_data['role'] ?? 'primary');
            }
        }
        
        // Update unit availability if lease is active
        if ($insert_data['status'] === 'active') {
            Rental_Gates_Unit::update($data['unit_id'], array('availability' => 'occupied'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('leases_org_' . $data['organization_id']);
        }
        
        return self::get($lease_id);
    }
    
    /**
     * Get lease by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $lease = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$lease) {
            return null;
        }
        
        return self::format_lease($lease);
    }
    
    /**
     * Get lease with full details (unit, building, tenants)
     */
    public static function get_with_details($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $lease = $wpdb->get_row($wpdb->prepare(
            "SELECT l.*, 
                    u.name as unit_name, u.slug as unit_slug, u.building_id,
                    b.name as building_name, b.slug as building_slug, b.derived_address
             FROM " . self::$table_name . " l
             JOIN {$tables['units']} u ON l.unit_id = u.id
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE l.id = %d",
            $id
        ), ARRAY_A);
        
        if (!$lease) {
            return null;
        }
        
        $lease = self::format_lease($lease);
        $lease['tenants'] = self::get_tenants($id);
        
        return $lease;
    }
    
    /**
     * Get leases for a specific tenant
     * 
     * @param int $tenant_id The tenant ID
     * @param array $args Optional arguments (status, include_ended)
     * @return array Array of lease records
     */
    public static function get_for_tenant($tenant_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => array('active', 'ending', 'draft'), // Default to active-ish statuses
            'include_ended' => false,
            'org_id' => null,
        );
        $args = wp_parse_args($args, $defaults);
        
        // Build status filter
        $statuses = (array) $args['status'];
        if ($args['include_ended']) {
            $statuses = array_merge($statuses, array('ended', 'terminated', 'expired'));
        }
        $status_placeholders = implode(',', array_fill(0, count($statuses), '%s'));
        
        // Build query - Note: units table uses 'name' not 'unit_number'
        $sql = "SELECT l.*, 
                       u.name as unit_name, u.slug as unit_slug, u.building_id,
                       b.name as building_name, b.derived_address as building_address
                FROM " . self::$table_name . " l
                INNER JOIN " . self::$lease_tenants_table . " lt ON l.id = lt.lease_id AND lt.removed_at IS NULL
                LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
                LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
                WHERE lt.tenant_id = %d 
                AND l.status IN ($status_placeholders)";
        
        $params = array_merge(array($tenant_id), $statuses);
        
        // Add org filter if provided
        if ($args['org_id']) {
            $sql .= " AND l.organization_id = %d";
            $params[] = $args['org_id'];
        }
        
        $sql .= " ORDER BY l.start_date DESC";
        
        return $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A) ?: array();
    }
    
    /**
     * Get leases for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => null,
            'unit_id' => null,
            'building_id' => null,
            'search' => null,
            'expiring_days' => null, // Filter leases expiring within X days
            'per_page' => 50,
            'page' => 1,
            'orderby' => 'start_date',
            'order' => 'DESC',
            'limit' => null, // Deprecated, use per_page
            'offset' => null, // Deprecated, use page
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('l.organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "l.status IN ($placeholders)";
                $params = array_merge($params, $args['status']);
            } else {
                $where[] = 'l.status = %s';
                $params[] = $args['status'];
            }
        }
        
        if ($args['unit_id']) {
            $where[] = 'l.unit_id = %d';
            $params[] = $args['unit_id'];
        }
        
        if ($args['building_id']) {
            $where[] = 'u.building_id = %d';
            $params[] = $args['building_id'];
        }
        
        if ($args['expiring_days']) {
            $where[] = 'l.end_date IS NOT NULL AND l.end_date <= DATE_ADD(CURDATE(), INTERVAL %d DAY) AND l.end_date >= CURDATE()';
            $params[] = intval($args['expiring_days']);
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(u.name LIKE %s OR b.name LIKE %s)';
            $params[] = $search;
            $params[] = $search;
        }
        
        $orderby = in_array($args['orderby'], array('start_date', 'end_date', 'rent_amount', 'status', 'created_at')) 
            ? 'l.' . $args['orderby'] : 'l.start_date';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        // Handle pagination (support both old and new params)
        $per_page = $args['limit'] ?? $args['per_page'];
        $offset = $args['offset'] ?? (($args['page'] - 1) * $per_page);
        
        // Get total count
        $count_sql = "SELECT COUNT(*) FROM " . self::$table_name . " l
                      JOIN {$tables['units']} u ON l.unit_id = u.id
                      JOIN {$tables['buildings']} b ON u.building_id = b.id
                      WHERE " . implode(' AND ', $where);
        $total = $wpdb->get_var($wpdb->prepare($count_sql, ...$params));
        
        $sql = "SELECT l.*, 
                       u.name as unit_name, u.slug as unit_slug, u.building_id,
                       b.name as building_name, b.slug as building_slug
                FROM " . self::$table_name . " l
                JOIN {$tables['units']} u ON l.unit_id = u.id
                JOIN {$tables['buildings']} b ON u.building_id = b.id
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($per_page);
        $params[] = intval($offset);
        
        $leases = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        // Get tenants for each lease
        $items = array();
        foreach ($leases as $lease) {
            $formatted = self::format_lease($lease);
            $formatted['tenants'] = self::get_tenants($lease['id']);
            // Add primary tenant name for display
            if (!empty($formatted['tenants'])) {
                $primary = array_filter($formatted['tenants'], function($t) { return $t['role'] === 'primary'; });
                $primary = reset($primary) ?: $formatted['tenants'][0];
                $formatted['tenant_name'] = trim($primary['first_name'] . ' ' . $primary['last_name']);
            }
            $items[] = $formatted;
        }
        
        return array(
            'items' => $items,
            'total' => intval($total),
            'pages' => ceil($total / $per_page),
            'page' => $args['page'],
            'per_page' => $per_page,
        );
    }
    
    /**
     * Get active lease for unit
     */
    public static function get_active_for_unit($unit_id) {
        global $wpdb;
        self::init();
        
        $lease = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " 
             WHERE unit_id = %d AND status IN ('active', 'ending')
             ORDER BY start_date DESC LIMIT 1",
            $unit_id
        ), ARRAY_A);
        
        if (!$lease) {
            return null;
        }
        
        $formatted = self::format_lease($lease);
        $formatted['tenants'] = self::get_tenants($lease['id']);
        
        return $formatted;
    }
    
    /**
     * Count leases for organization
     */
    public static function count_for_organization($org_id, $status = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($status) {
            if (is_array($status)) {
                $placeholders = implode(',', array_fill(0, count($status), '%s'));
                $sql .= " AND status IN ($placeholders)";
                $params = array_merge($params, $status);
            } else {
                $sql .= " AND status = %s";
                $params[] = $status;
            }
        }
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Update lease
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $lease = self::get($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'start_date', 'end_date', 'is_month_to_month', 'notice_period_days',
            'rent_amount', 'deposit_amount', 'billing_frequency', 'billing_day',
            'status', 'notes', 'signed_at', 'signed_document'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'rent_amount':
                    case 'deposit_amount':
                        $update_data[$field] = floatval($data[$field]);
                        break;
                    case 'is_month_to_month':
                        $update_data[$field] = !empty($data[$field]) ? 1 : 0;
                        break;
                    case 'notice_period_days':
                    case 'billing_day':
                    case 'signed_document':
                        $update_data[$field] = intval($data[$field]);
                        break;
                    case 'billing_frequency':
                        $update_data[$field] = in_array($data[$field], array('monthly', 'weekly', 'biweekly')) 
                            ? $data[$field] : $lease['billing_frequency'];
                        break;
                    case 'status':
                        $update_data[$field] = in_array($data[$field], array('draft', 'active', 'ending', 'ended', 'renewed')) 
                            ? $data[$field] : $lease['status'];
                        break;
                    case 'notes':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $lease;
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        // Handle status change effects
        if (isset($update_data['status'])) {
            $old_status = $lease['status'];
            $new_status = $update_data['status'];
            
            // Update unit availability based on lease status
            if ($new_status === 'active' && $old_status !== 'active') {
                Rental_Gates_Unit::update($lease['unit_id'], array('availability' => 'occupied'));
                
                // Update tenant statuses to active
                $tenants = self::get_tenants($id);
                foreach ($tenants as $t) {
                    Rental_Gates_Tenant::update($t['tenant_id'], array('status' => 'active'));
                }
            } elseif ($new_status === 'ended' && $old_status !== 'ended') {
                Rental_Gates_Unit::update($lease['unit_id'], array('availability' => 'available'));
                
                // Update tenant statuses to former
                $tenants = self::get_tenants($id);
                foreach ($tenants as $t) {
                    Rental_Gates_Tenant::update($t['tenant_id'], array('status' => 'former'));
                }
            }
        }
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating lease', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('leases_org_' . $lease['organization_id']);
        }
        
        return self::get($id);
    }
    
    /**
     * Delete lease
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $lease = self::get($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        // Only allow deleting draft leases
        if ($lease['status'] !== 'draft') {
            return new WP_Error('cannot_delete', __('Only draft leases can be deleted. End the lease instead.', 'rental-gates'));
        }
        
        // Delete lease tenant associations
        $wpdb->delete(self::$lease_tenants_table, array('lease_id' => $id));
        
        // Delete lease
        $wpdb->delete(self::$table_name, array('id' => $id));
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('leases_org_' . $lease['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Add tenant to lease
     */
    public static function add_tenant($lease_id, $tenant_id, $role = 'primary') {
        global $wpdb;
        self::init();
        
        // Check if already added
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$lease_tenants_table . " 
             WHERE lease_id = %d AND tenant_id = %d AND removed_at IS NULL",
            $lease_id, $tenant_id
        ));
        
        if ($existing) {
            return new WP_Error('already_added', __('Tenant is already on this lease', 'rental-gates'));
        }
        
        $result = $wpdb->insert(self::$lease_tenants_table, array(
            'lease_id' => intval($lease_id),
            'tenant_id' => intval($tenant_id),
            'role' => in_array($role, array('primary', 'co_tenant', 'occupant')) ? $role : 'primary',
            'added_at' => current_time('mysql'),
        ));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error adding tenant to lease', 'rental-gates'));
        }
        
        return true;
    }
    
    /**
     * Remove tenant from lease
     */
    public static function remove_tenant($lease_id, $tenant_id) {
        global $wpdb;
        self::init();
        
        $result = $wpdb->update(
            self::$lease_tenants_table,
            array('removed_at' => current_time('mysql')),
            array('lease_id' => $lease_id, 'tenant_id' => $tenant_id, 'removed_at' => null)
        );
        
        return $result !== false;
    }
    
    /**
     * Get tenants for lease
     */
    public static function get_tenants($lease_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $tenants = $wpdb->get_results($wpdb->prepare(
            "SELECT lt.*, t.first_name, t.last_name, t.email, t.phone, t.status as tenant_status
             FROM " . self::$lease_tenants_table . " lt
             JOIN {$tables['tenants']} t ON lt.tenant_id = t.id
             WHERE lt.lease_id = %d AND lt.removed_at IS NULL
             ORDER BY lt.role = 'primary' DESC, lt.added_at ASC",
            $lease_id
        ), ARRAY_A);
        
        return array_map(function($t) {
            $t['full_name'] = $t['first_name'] . ' ' . $t['last_name'];
            return $t;
        }, $tenants);
    }
    
    /**
     * Check for overlapping leases
     */
    public static function check_overlap($unit_id, $start_date, $end_date = null, $exclude_lease_id = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT id FROM " . self::$table_name . " 
                WHERE unit_id = %d 
                AND status IN ('active', 'draft')
                AND (
                    (end_date IS NULL OR end_date >= %s)
                    AND start_date <= %s
                )";
        
        $params = array(
            $unit_id,
            $start_date,
            $end_date ?: '9999-12-31'
        );
        
        if ($exclude_lease_id) {
            $sql .= " AND id != %d";
            $params[] = $exclude_lease_id;
        }
        
        return $wpdb->get_var($wpdb->prepare($sql, $params));
    }
    
    /**
     * Activate lease
     */
    public static function activate($id) {
        $lease = self::get($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        if ($lease['status'] !== 'draft') {
            return new WP_Error('invalid_status', __('Only draft leases can be activated', 'rental-gates'));
        }
        
        // Check for tenants
        $tenants = self::get_tenants($id);
        if (empty($tenants)) {
            return new WP_Error('no_tenants', __('Lease must have at least one tenant before activation', 'rental-gates'));
        }
        
        return self::update($id, array('status' => 'active'));
    }
    
    /**
     * End lease
     */
    public static function end_lease($id, $end_date = null) {
        $lease = self::get($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        if (!in_array($lease['status'], array('active', 'ending'))) {
            return new WP_Error('invalid_status', __('Only active leases can be ended', 'rental-gates'));
        }
        
        $data = array(
            'status' => 'ended',
        );
        
        if ($end_date) {
            $data['end_date'] = $end_date;
        } elseif (!$lease['end_date']) {
            $data['end_date'] = current_time('Y-m-d');
        }
        
        return self::update($id, $data);
    }
    
    /**
     * Terminate lease early
     */
    public static function terminate($id, $termination_date = null, $reason = '', $notes = '') {
        $lease = self::get($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        if (!in_array($lease['status'], array('active', 'pending'))) {
            return new WP_Error('invalid_status', __('Only active or pending leases can be terminated', 'rental-gates'));
        }
        
        $data = array(
            'status' => 'terminated',
            'end_date' => $termination_date ?: current_time('Y-m-d'),
        );
        
        // Store termination details in notes
        $termination_notes = sprintf(
            __('Terminated on %s. Reason: %s', 'rental-gates'),
            $termination_date ?: current_time('Y-m-d'),
            $reason ?: __('Not specified', 'rental-gates')
        );
        if ($notes) {
            $termination_notes .= "\n" . $notes;
        }
        $data['notes'] = ($lease['notes'] ? $lease['notes'] . "\n\n" : '') . $termination_notes;
        
        $result = self::update($id, $data);
        
        if (!is_wp_error($result)) {
            // Free up the unit
            if ($lease['unit_id']) {
                Rental_Gates_Unit::update($lease['unit_id'], array('status' => 'available'));
            }
            
            // Update tenant status
            if (!empty($lease['tenants'])) {
                foreach ($lease['tenants'] as $tenant) {
                    Rental_Gates_Tenant::update($tenant['tenant_id'], array('status' => 'inactive'));
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Renew lease
     */
    public static function renew($id, $new_end_date, $new_rent_amount = null) {
        $lease = self::get_with_details($id);
        if (!$lease) {
            return new WP_Error('not_found', __('Lease not found', 'rental-gates'));
        }
        
        if (!in_array($lease['status'], array('active', 'ending'))) {
            return new WP_Error('invalid_status', __('Only active leases can be renewed', 'rental-gates'));
        }
        
        // Mark old lease as renewed
        self::update($id, array('status' => 'renewed'));
        
        // Create new lease
        $new_lease_data = array(
            'organization_id' => $lease['organization_id'],
            'unit_id' => $lease['unit_id'],
            'previous_lease_id' => $id,
            'start_date' => $lease['end_date'] ?: current_time('Y-m-d'),
            'end_date' => $new_end_date,
            'is_month_to_month' => $lease['is_month_to_month'],
            'notice_period_days' => $lease['notice_period_days'],
            'rent_amount' => $new_rent_amount ?: $lease['rent_amount'],
            'deposit_amount' => $lease['deposit_amount'],
            'billing_frequency' => $lease['billing_frequency'],
            'billing_day' => $lease['billing_day'],
            'status' => 'active',
            'skip_overlap_check' => true,
            'tenants' => array_map(function($t) {
                return array('tenant_id' => $t['tenant_id'], 'role' => $t['role']);
            }, $lease['tenants']),
        );
        
        return self::create($new_lease_data);
    }
    
    /**
     * Get lease statistics for organization
     */
    public static function get_stats($org_id) {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total' => 0,
            'active' => 0,
            'draft' => 0,
            'ending' => 0,
            'ended' => 0,
            'expiring_soon' => 0,
            'monthly_revenue' => 0,
        );
        
        // Count by status
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM " . self::$table_name . " 
             WHERE organization_id = %d GROUP BY status",
            $org_id
        ), ARRAY_A);
        
        foreach ($results as $row) {
            $stats[$row['status']] = intval($row['count']);
            $stats['total'] += intval($row['count']);
        }
        
        // Count expiring in next 30 days
        $stats['expiring_soon'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             AND status = 'active' 
             AND end_date IS NOT NULL 
             AND end_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)",
            $org_id
        )));
        
        // Calculate monthly revenue from active leases
        $stats['monthly_revenue'] = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT SUM(rent_amount) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status = 'active'",
            $org_id
        )) ?: 0);
        
        return $stats;
    }
    
    /**
     * Format lease data
     */
    private static function format_lease($lease) {
        if (!$lease) return null;
        
        $lease['id'] = intval($lease['id']);
        $lease['organization_id'] = intval($lease['organization_id']);
        $lease['unit_id'] = intval($lease['unit_id']);
        $lease['application_id'] = $lease['application_id'] ? intval($lease['application_id']) : null;
        $lease['previous_lease_id'] = $lease['previous_lease_id'] ? intval($lease['previous_lease_id']) : null;
        $lease['is_month_to_month'] = (bool) $lease['is_month_to_month'];
        $lease['notice_period_days'] = intval($lease['notice_period_days']);
        $lease['rent_amount'] = floatval($lease['rent_amount']);
        $lease['deposit_amount'] = $lease['deposit_amount'] ? floatval($lease['deposit_amount']) : null;
        $lease['billing_day'] = intval($lease['billing_day']);
        
        // Calculate lease duration
        if ($lease['start_date'] && $lease['end_date']) {
            $start = new DateTime($lease['start_date']);
            $end = new DateTime($lease['end_date']);
            $diff = $start->diff($end);
            $lease['duration_months'] = ($diff->y * 12) + $diff->m;
        } else {
            $lease['duration_months'] = null;
        }
        
        // Check if expiring soon
        if ($lease['status'] === 'active' && $lease['end_date']) {
            $end = new DateTime($lease['end_date']);
            $now = new DateTime();
            $days_until_end = $now->diff($end)->days;
            $lease['days_until_end'] = $end > $now ? $days_until_end : -$days_until_end;
            $lease['is_expiring_soon'] = $lease['days_until_end'] > 0 && $lease['days_until_end'] <= 30;
        } else {
            $lease['days_until_end'] = null;
            $lease['is_expiring_soon'] = false;
        }
        
        // Parse documents
        if (!empty($lease['documents'])) {
            $lease['documents'] = json_decode($lease['documents'], true);
        } else {
            $lease['documents'] = array();
        }
        
        // Parse meta data
        if (!empty($lease['meta_data'])) {
            $lease['meta_data'] = json_decode($lease['meta_data'], true);
        } else {
            $lease['meta_data'] = array();
        }
        
        return $lease;
    }
}
