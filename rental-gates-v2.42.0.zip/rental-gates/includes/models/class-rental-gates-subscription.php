<?php
/**
 * Rental Gates Subscription Model
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Subscription {
    
    public static function create_for_organization($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get free plan
        $free_plan = $wpdb->get_row(
            "SELECT * FROM {$tables['plans']} WHERE slug = 'free' LIMIT 1",
            ARRAY_A
        );
        
        if (!$free_plan) {
            return new WP_Error('no_plan', 'Free plan not found');
        }
        
        $wpdb->insert($tables['subscriptions'], array(
            'organization_id' => $org_id,
            'plan_id' => $free_plan['id'],
            'plan_slug' => 'free',
            'status' => 'active',
            'billing_cycle' => 'monthly',
            'current_period_start' => current_time('mysql'),
            'ai_credits_used' => 0,
            'ai_credits_reset_at' => date('Y-m-01 00:00:00', strtotime('+1 month')),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ));
        
        return $wpdb->insert_id;
    }
    
    public static function get_for_organization($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, p.* FROM {$tables['subscriptions']} s
             LEFT JOIN {$tables['plans']} p ON s.plan_id = p.id
             WHERE s.organization_id = %d",
            $org_id
        ), ARRAY_A);
    }
}
