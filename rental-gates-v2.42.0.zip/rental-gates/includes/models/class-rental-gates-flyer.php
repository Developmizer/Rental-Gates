<?php
/**
 * Rental Gates Flyer Model
 * 
 * Handles property flyer generation with multiple templates
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Flyer {
    
    /**
     * Available templates
     */
    const TEMPLATES = array(
        'modern' => 'Modern',
        'classic' => 'Classic',
        'minimal' => 'Minimal',
        'bold' => 'Bold'
    );
    
    /**
     * Create a new flyer
     */
    public static function create($data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['entity_id'])) {
            return new WP_Error('missing_data', __('Missing required data', 'rental-gates'));
        }
        
        $type = $data['type'] ?? 'unit';
        $entity_id = intval($data['entity_id']);
        $template = sanitize_text_field($data['template'] ?? 'modern');
        $include_qr = isset($data['include_qr']) ? (bool) $data['include_qr'] : true;
        
        // Get entity data
        if ($type === 'unit') {
            $unit = Rental_Gates_Unit::get($entity_id);
            if (!$unit) {
                return new WP_Error('not_found', __('Unit not found', 'rental-gates'));
            }
            $entity_data = $unit;
        } elseif ($type === 'building') {
            $building = Rental_Gates_Building::get($entity_id);
            if (!$building) {
                return new WP_Error('not_found', __('Building not found', 'rental-gates'));
            }
            $entity_data = $building;
        } else {
            return new WP_Error('invalid_type', __('Invalid flyer type', 'rental-gates'));
        }
        
        // Generate QR code if needed
        $qr_code_id = null;
        $qr_image_url = null;
        
        if ($include_qr) {
            $qr = new Rental_Gates_QR();
            if ($type === 'unit') {
                $qr_result = $qr->generate_for_unit($entity_id, 'medium');
            } else {
                $qr_result = $qr->generate_for_building($entity_id, 'medium');
            }
            
            if (!is_wp_error($qr_result)) {
                $qr_code_id = $qr_result['id'];
                $qr_image_url = $qr_result['qr_image'];
            }
        }
        
        // Build title
        $title = !empty($data['title']) ? sanitize_text_field($data['title']) : '';
        if (empty($title)) {
            if ($type === 'unit') {
                $title = sprintf(__('%s - %s', 'rental-gates'), $entity_data['building_name'] ?? '', $entity_data['name']);
            } else {
                $title = $entity_data['name'];
            }
        }
        
        // Check which columns exist (for backward compatibility)
        $columns = $wpdb->get_col("DESCRIBE {$tables['flyers']}", 0);
        
        // Build insert data based on available columns
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'template' => $template,
            'created_at' => current_time('mysql'),
        );
        
        // Add v2.7.0+ columns if they exist
        if (in_array('type', $columns)) {
            $insert_data['type'] = $type;
        }
        if (in_array('entity_id', $columns)) {
            $insert_data['entity_id'] = $entity_id;
        } elseif (in_array('unit_id', $columns) && $type === 'unit') {
            // Fallback to old column name
            $insert_data['unit_id'] = $entity_id;
        }
        if (in_array('title', $columns)) {
            $insert_data['title'] = $title;
        }
        if (in_array('qr_code_id', $columns)) {
            $insert_data['qr_code_id'] = $qr_code_id;
        }
        if (in_array('include_qr', $columns)) {
            $insert_data['include_qr'] = $include_qr ? 1 : 0;
        }
        if (in_array('status', $columns)) {
            $insert_data['status'] = 'generating';
        }
        
        $wpdb->insert($tables['flyers'], $insert_data);
        $flyer_id = $wpdb->insert_id;
        
        if (!$flyer_id) {
            return new WP_Error('db_error', __('Failed to create flyer. Please try again.', 'rental-gates'));
        }
        
        // Generate the flyer HTML/PDF
        $result = self::generate($flyer_id, $entity_data, $template, $qr_image_url);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return array(
            'id' => $flyer_id,
            'file_url' => $result['file_url'],
            'thumbnail_url' => $result['thumbnail_url'] ?? null
        );
    }
    
    /**
     * Generate flyer PDF/HTML
     */
    public static function generate($flyer_id, $entity_data, $template = 'modern', $qr_image_url = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get organization for branding
        $flyer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['flyers']} WHERE id = %d",
            $flyer_id
        ), ARRAY_A);
        
        if (!$flyer) {
            return new WP_Error('not_found', __('Flyer not found', 'rental-gates'));
        }
        
        $org = Rental_Gates_Organization::get($flyer['organization_id']);
        
        // Use PDF class for better print optimization
        $pdf = rental_gates_pdf();
        
        // Get building if unit
        $building = null;
        if ($flyer['type'] === 'unit' && !empty($flyer['entity_id'])) {
            $unit = Rental_Gates_Unit::get($flyer['entity_id']);
            if ($unit && !empty($unit['building_id'])) {
                $building = Rental_Gates_Building::get($unit['building_id']);
            }
        } elseif ($flyer['type'] === 'building' && !empty($flyer['entity_id'])) {
            $building = Rental_Gates_Building::get($flyer['entity_id']);
        }
        
        // Generate HTML content using enhanced template
        $html = self::render_template($template, $entity_data, $org, $qr_image_url, $flyer, $building);
        
        // Save HTML file (print-optimized)
        $upload_dir = wp_upload_dir();
        $flyers_dir = $upload_dir['basedir'] . '/rental-gates/flyers';
        
        if (!file_exists($flyers_dir)) {
            wp_mkdir_p($flyers_dir);
        }
        
        $filename = 'flyer-' . $flyer_id . '-' . time() . '.html';
        $filepath = $flyers_dir . '/' . $filename;
        $file_url = $upload_dir['baseurl'] . '/rental-gates/flyers/' . $filename;
        
        file_put_contents($filepath, $html);
        
        // Generate thumbnail if possible
        $thumbnail_url = null;
        
        // Update database
        $update_data = array(
            'file_url' => $file_url,
            'status' => 'ready',
            'generated_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        // Add thumbnail if column exists
        $columns = $wpdb->get_col("DESCRIBE {$tables['flyers']}", 0);
        if (in_array('thumbnail_url', $columns) && $thumbnail_url) {
            $update_data['thumbnail_url'] = $thumbnail_url;
        }
        
        $wpdb->update(
            $tables['flyers'],
            $update_data,
            array('id' => $flyer_id)
        );
        
        return array(
            'file_url' => $file_url,
            'html' => $html,
            'thumbnail_url' => $thumbnail_url
        );
    }
    
    /**
     * Regenerate an existing flyer
     */
    public static function regenerate($flyer_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $flyer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['flyers']} WHERE id = %d",
            $flyer_id
        ), ARRAY_A);
        
        if (!$flyer) {
            return new WP_Error('not_found', __('Flyer not found', 'rental-gates'));
        }
        
        // Get entity data
        if ($flyer['type'] === 'unit') {
            $entity_data = Rental_Gates_Unit::get($flyer['entity_id']);
        } else {
            $entity_data = Rental_Gates_Building::get($flyer['entity_id']);
        }
        
        if (!$entity_data) {
            return new WP_Error('not_found', __('Property not found', 'rental-gates'));
        }
        
        // Get QR image if applicable
        $qr_image_url = null;
        if ($flyer['include_qr'] && $flyer['qr_code_id']) {
            $qr = Rental_Gates_QR::get($flyer['qr_code_id']);
            if ($qr) {
                $qr_image_url = $qr['qr_image'];
            }
        }
        
        return self::generate($flyer_id, $entity_data, $flyer['template'], $qr_image_url);
    }
    
    /**
     * Get flyer by ID
     */
    public static function get($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['flyers']} WHERE id = %d",
            $id
        ), ARRAY_A);
    }
    
    /**
     * Get preview HTML for a flyer (without saving)
     */
    public static function get_preview($data) {
        $type = $data['type'] ?? 'unit';
        $entity_id = intval($data['entity_id']);
        $template = sanitize_text_field($data['template'] ?? 'modern');
        $include_qr = isset($data['include_qr']) ? (bool) $data['include_qr'] : true;
        $org_id = intval($data['organization_id']);
        
        // Get entity data
        if ($type === 'unit') {
            $entity_data = Rental_Gates_Unit::get($entity_id);
        } elseif ($type === 'building') {
            $entity_data = Rental_Gates_Building::get($entity_id);
        } else {
            return new WP_Error('invalid_type', __('Invalid flyer type', 'rental-gates'));
        }
        
        if (!$entity_data) {
            return new WP_Error('not_found', __('Property not found', 'rental-gates'));
        }
        
        $org = Rental_Gates_Organization::get($org_id);
        
        // Get building if unit
        $building = null;
        if ($type === 'unit' && !empty($entity_data['building_id'])) {
            $building = Rental_Gates_Building::get($entity_data['building_id']);
        }
        
        // Generate QR code if needed
        $qr_image_url = null;
        if ($include_qr) {
            $qr = new Rental_Gates_QR();
            if ($type === 'unit') {
                $qr_result = $qr->generate_for_unit($entity_id, 'medium');
            } else {
                $qr_result = $qr->generate_for_building($entity_id, 'medium');
            }
            
            if (!is_wp_error($qr_result)) {
                $qr_image_url = $qr_result['qr_image'];
            }
        }
        
        // Build title
        $title = !empty($data['title']) ? sanitize_text_field($data['title']) : '';
        if (empty($title)) {
            if ($type === 'unit') {
                $title = sprintf(__('%s - %s', 'rental-gates'), $building['name'] ?? '', $entity_data['name']);
            } else {
                $title = $entity_data['name'];
            }
        }
        
        $flyer_data = array(
            'id' => 0,
            'title' => $title,
            'organization_id' => $org_id,
            'type' => $type,
            'entity_id' => $entity_id,
        );
        
        // Generate preview HTML
        $html = self::render_template($template, $entity_data, $org, $qr_image_url, $flyer_data, $building);
        
        return array(
            'html' => $html,
            'preview_url' => 'data:text/html;charset=utf-8,' . urlencode($html)
        );
    }
    
    /**
     * Delete flyer
     */
    public static function delete($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $flyer = self::get($id);
        
        if ($flyer && !empty($flyer['file_url'])) {
            // Delete file
            $upload_dir = wp_upload_dir();
            $filepath = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $flyer['file_url']);
            if (file_exists($filepath)) {
                unlink($filepath);
            }
        }
        
        return $wpdb->delete($tables['flyers'], array('id' => $id));
    }
    
    /**
     * Render flyer template
     */
    private static function render_template($template, $entity, $org, $qr_url, $flyer, $building = null) {
        // Get template colors based on template type
        $colors = self::get_template_colors($template);
        
        // Get organization branding
        $org_logo = !empty($org['logo_url']) ? $org['logo_url'] : '';
        $org_primary_color = !empty($org['primary_color']) ? $org['primary_color'] : $colors['primary'];
        $org_secondary_color = !empty($org['secondary_color']) ? $org['secondary_color'] : $colors['secondary'];
        
        // Build property details
        $price = '';
        if (!empty($entity['rent_amount'])) {
            $price = '$' . number_format($entity['rent_amount']) . '/mo';
        }
        
        $beds = $entity['bedrooms'] ?? 0;
        $baths = $entity['bathrooms'] ?? 0;
        $sqft = $entity['square_feet'] ?? 0;
        
        // Get primary image
        $image_url = '';
        $gallery = $entity['gallery'] ?? array();
        if (!empty($gallery) && is_array($gallery)) {
            $image_url = $gallery[0];
        }
        
        // Features list
        $features = array();
        if ($beds) $features[] = $beds . ' ' . ($beds == 1 ? 'Bedroom' : 'Bedrooms');
        if ($baths) $features[] = $baths . ' ' . ($baths == 1 ? 'Bathroom' : 'Bathrooms');
        if ($sqft) $features[] = number_format($sqft) . ' sq ft';
        
        // Amenities
        $amenities = array();
        if (!empty($entity['amenities']) && is_array($entity['amenities'])) {
            $amenities = array_slice($entity['amenities'], 0, 8);
        }
        
        // Address
        $address = $entity['derived_address'] ?? $entity['address'] ?? '';
        
        // Contact info
        $contact_phone = $org['contact_phone'] ?? '';
        $contact_email = $org['contact_email'] ?? '';
        $org_name = $org['name'] ?? '';
        
        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($flyer['title']); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @page {
            size: letter;
            margin: 0;
        }
        
        @media print {
            body {
                background: none;
            }
            .flyer {
                box-shadow: none;
                margin: 0;
            }
            .no-print {
                display: none;
            }
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        
        .flyer {
            width: 8.5in;
            min-height: 11in;
            margin: 0 auto;
            background: #fff;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        /* Organization Logo */
        .org-logo {
            max-width: 120px;
            max-height: 60px;
            margin-bottom: 12px;
            object-fit: contain;
        }
        
        /* Modern Template */
        .template-modern .flyer-header {
            background: linear-gradient(135deg, <?php echo esc_attr($org_primary_color); ?> 0%, <?php echo esc_attr($org_secondary_color); ?> 100%);
            color: #fff;
            padding: 30px 40px;
        }
        
        .template-modern .flyer-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 12px;
        }
        
        .template-modern .flyer-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .template-modern .flyer-address {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .flyer-image {
            width: 100%;
            height: 320px;
            object-fit: cover;
            display: block;
        }
        
        .flyer-image-placeholder {
            width: 100%;
            height: 320px;
            background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-size: 48px;
        }
        
        .flyer-body {
            padding: 30px 40px;
        }
        
        .flyer-price {
            font-size: 36px;
            font-weight: 700;
            color: <?php echo esc_attr($org_primary_color); ?>;
            margin-bottom: 20px;
        }
        
        .flyer-features {
            display: flex;
            gap: 30px;
            margin-bottom: 24px;
            padding-bottom: 24px;
            border-bottom: 2px solid #f3f4f6;
        }
        
        .flyer-feature {
            text-align: center;
        }
        
        .flyer-feature-value {
            font-size: 28px;
            font-weight: 700;
            color: #111827;
        }
        
        .flyer-feature-label {
            font-size: 13px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .flyer-description {
            font-size: 15px;
            line-height: 1.7;
            color: #374151;
            margin-bottom: 24px;
        }
        
        .flyer-amenities {
            margin-bottom: 24px;
        }
        
        .flyer-amenities h3 {
            font-size: 14px;
            font-weight: 600;
            color: #111827;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .flyer-amenities-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
        }
        
        .flyer-amenity {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #4b5563;
        }
        
        .flyer-amenity::before {
            content: '✓';
            color: <?php echo esc_attr($org_primary_color); ?>;
            font-weight: bold;
        }
        
        .flyer-footer {
            background: #f9fafb;
            padding: 24px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #e5e7eb;
        }
        
        .flyer-contact h4 {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            margin-bottom: 8px;
        }
        
        .flyer-contact p {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 4px;
        }
        
        .flyer-contact a {
            color: <?php echo esc_attr($org_primary_color); ?>;
            text-decoration: none;
        }
        
        .flyer-qr {
            text-align: center;
        }
        
        .flyer-qr img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
        }
        
        .flyer-qr p {
            font-size: 11px;
            color: #6b7280;
            margin-top: 6px;
        }
        
        /* Classic Template Overrides */
        .template-classic .flyer-header {
            background: #1f2937;
            text-align: center;
            padding: 40px;
        }
        
        .template-classic .flyer-badge {
            background: <?php echo esc_attr($org_primary_color); ?>;
        }
        
        .template-classic .flyer-body {
            text-align: center;
        }
        
        .template-classic .flyer-features {
            justify-content: center;
        }
        
        .template-classic .flyer-amenities-grid {
            max-width: 400px;
            margin: 0 auto;
        }
        
        /* Minimal Template Overrides */
        .template-minimal .flyer-header {
            background: #fff;
            color: #111827;
            border-bottom: 3px solid <?php echo esc_attr($org_primary_color); ?>;
        }
        
        .template-minimal .flyer-badge {
            background: <?php echo esc_attr($org_primary_color); ?>;
            color: #fff;
        }
        
        .template-minimal .flyer-footer {
            background: #fff;
        }
        
        /* Bold Template Overrides */
        .template-bold .flyer-header {
            background: <?php echo esc_attr($org_primary_color); ?>;
            padding: 50px 40px;
        }
        
        .template-bold .flyer-title {
            font-size: 42px;
        }
        
        .template-bold .flyer-price {
            font-size: 48px;
        }
        
        /* Print optimization */
        @media print {
            body {
                background: none;
                padding: 0;
            }
            .flyer {
                box-shadow: none;
                margin: 0;
                width: 100%;
            }
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="flyer template-<?php echo esc_attr($template); ?>">
        <div class="flyer-header">
            <?php if ($org_logo): ?>
                <img src="<?php echo esc_url($org_logo); ?>" alt="<?php echo esc_attr($org_name); ?>" class="org-logo">
            <?php endif; ?>
            <div class="flyer-badge"><?php _e('For Rent', 'rental-gates'); ?></div>
            <h1 class="flyer-title"><?php echo esc_html($flyer['title']); ?></h1>
            <p class="flyer-address"><?php echo esc_html($address); ?></p>
        </div>
        
        <?php if ($image_url): ?>
            <img src="<?php echo esc_url($image_url); ?>" alt="Property" class="flyer-image">
        <?php else: ?>
            <div class="flyer-image-placeholder">🏠</div>
        <?php endif; ?>
        
        <div class="flyer-body">
            <?php if ($price): ?>
                <div class="flyer-price"><?php echo esc_html($price); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($features)): ?>
            <div class="flyer-features">
                <?php if ($beds): ?>
                <div class="flyer-feature">
                    <div class="flyer-feature-value"><?php echo esc_html($beds); ?></div>
                    <div class="flyer-feature-label"><?php echo $beds == 1 ? __('Bedroom', 'rental-gates') : __('Bedrooms', 'rental-gates'); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if ($baths): ?>
                <div class="flyer-feature">
                    <div class="flyer-feature-value"><?php echo esc_html($baths); ?></div>
                    <div class="flyer-feature-label"><?php echo $baths == 1 ? __('Bathroom', 'rental-gates') : __('Bathrooms', 'rental-gates'); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if ($sqft): ?>
                <div class="flyer-feature">
                    <div class="flyer-feature-value"><?php echo number_format($sqft); ?></div>
                    <div class="flyer-feature-label"><?php _e('Sq Ft', 'rental-gates'); ?></div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($entity['description'])): ?>
            <p class="flyer-description"><?php echo esc_html(wp_trim_words($entity['description'], 50)); ?></p>
            <?php endif; ?>
            
            <?php if (!empty($amenities)): ?>
            <div class="flyer-amenities">
                <h3><?php _e('Amenities', 'rental-gates'); ?></h3>
                <div class="flyer-amenities-grid">
                    <?php foreach ($amenities as $amenity): ?>
                        <div class="flyer-amenity"><?php echo esc_html(ucfirst(str_replace('_', ' ', $amenity))); ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="flyer-footer">
            <div class="flyer-contact">
                <h4><?php echo esc_html($org_name); ?></h4>
                <?php if ($contact_phone): ?>
                    <p>📞 <a href="tel:<?php echo esc_attr($contact_phone); ?>"><?php echo esc_html($contact_phone); ?></a></p>
                <?php endif; ?>
                <?php if ($contact_email): ?>
                    <p>✉️ <a href="mailto:<?php echo esc_attr($contact_email); ?>"><?php echo esc_html($contact_email); ?></a></p>
                <?php endif; ?>
            </div>
            
            <?php if ($qr_url): ?>
            <div class="flyer-qr">
                <img src="<?php echo esc_url($qr_url); ?>" alt="QR Code">
                <p><?php _e('Scan for details', 'rental-gates'); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get template colors
     */
    private static function get_template_colors($template) {
        $colors = array(
            'modern' => array(
                'primary' => '#3b82f6',
                'secondary' => '#8b5cf6'
            ),
            'classic' => array(
                'primary' => '#dc2626',
                'secondary' => '#1f2937'
            ),
            'minimal' => array(
                'primary' => '#111827',
                'secondary' => '#374151'
            ),
            'bold' => array(
                'primary' => '#f59e0b',
                'secondary' => '#d97706'
            )
        );
        
        return $colors[$template] ?? $colors['modern'];
    }
}
