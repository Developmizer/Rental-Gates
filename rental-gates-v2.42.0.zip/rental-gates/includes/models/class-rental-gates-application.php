<?php
/**
 * Rental Gates Application Model
 * 
 * Handles rental application management including CRUD operations,
 * status workflow, and conversion to tenants.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Application {
    
    private static $table_name;
    private static $occupants_table;
    
    /**
     * Initialize table names
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['applications'];
            self::$occupants_table = $tables['application_occupants'];
        }
    }
    
    /**
     * Create a new application
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $required = array('organization_id', 'unit_id', 'applicant_name', 'applicant_email', 'applicant_phone');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return new WP_Error('missing_field', sprintf(__('Missing required field: %s', 'rental-gates'), $field));
            }
        }
        
        // Validate email
        if (!is_email($data['applicant_email'])) {
            return new WP_Error('invalid_email', __('Invalid email address', 'rental-gates'));
        }
        
        // Generate unique token
        $token = wp_generate_password(32, false);
        
        // Prepare insert data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'unit_id' => intval($data['unit_id']),
            'lead_id' => !empty($data['lead_id']) ? intval($data['lead_id']) : null,
            'token' => $token,
            'applicant_name' => sanitize_text_field($data['applicant_name']),
            'applicant_email' => sanitize_email($data['applicant_email']),
            'applicant_phone' => sanitize_text_field($data['applicant_phone']),
            'current_address' => sanitize_textarea_field($data['current_address'] ?? ''),
            'employer' => sanitize_text_field($data['employer'] ?? ''),
            'income_range' => sanitize_text_field($data['income_range'] ?? ''),
            'desired_move_in' => !empty($data['desired_move_in']) ? sanitize_text_field($data['desired_move_in']) : null,
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'status' => in_array($data['status'] ?? '', array('invited', 'new', 'screening', 'approved', 'declined', 'withdrawn')) 
                ? $data['status'] : 'new',
            'submitted_at' => !empty($data['submitted_at']) ? $data['submitted_at'] : current_time('mysql'),
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating application', 'rental-gates'));
        }
        
        $application_id = $wpdb->insert_id;
        
        // Add occupants if provided
        if (!empty($data['occupants']) && is_array($data['occupants'])) {
            foreach ($data['occupants'] as $occupant) {
                self::add_occupant($application_id, $occupant);
            }
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('applications_org_' . $data['organization_id']);
        }
        
        return self::get($application_id);
    }
    
    /**
     * Get application by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $application = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$application) {
            return null;
        }
        
        return self::format_application($application);
    }
    
    /**
     * Get application by token
     */
    public static function get_by_token($token) {
        global $wpdb;
        self::init();
        
        $application = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE token = %s",
            $token
        ), ARRAY_A);
        
        if (!$application) {
            return null;
        }
        
        return self::format_application($application);
    }
    
    /**
     * Get application with full details (unit, building)
     */
    public static function get_with_details($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $application = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, 
                    u.name as unit_name, u.slug as unit_slug, u.rent_amount as unit_rent,
                    u.bedrooms, u.bathrooms, u.building_id,
                    b.name as building_name, b.slug as building_slug, b.derived_address
             FROM " . self::$table_name . " a
             JOIN {$tables['units']} u ON a.unit_id = u.id
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE a.id = %d",
            $id
        ), ARRAY_A);
        
        if (!$application) {
            return null;
        }
        
        $formatted = self::format_application($application);
        $formatted['occupants'] = self::get_occupants($id);
        
        return $formatted;
    }
    
    /**
     * Get applications for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => null,
            'unit_id' => null,
            'building_id' => null,
            'search' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('a.organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "a.status IN ($placeholders)";
                $params = array_merge($params, $args['status']);
            } else {
                $where[] = 'a.status = %s';
                $params[] = $args['status'];
            }
        }
        
        if ($args['unit_id']) {
            $where[] = 'a.unit_id = %d';
            $params[] = $args['unit_id'];
        }
        
        if ($args['building_id']) {
            $where[] = 'u.building_id = %d';
            $params[] = $args['building_id'];
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(a.applicant_name LIKE %s OR a.applicant_email LIKE %s OR u.name LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'submitted_at', 'applicant_name', 'status')) 
            ? 'a.' . $args['orderby'] : 'a.created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT a.*, 
                       u.name as unit_name, u.slug as unit_slug, u.building_id,
                       b.name as building_name, b.slug as building_slug
                FROM " . self::$table_name . " a
                JOIN {$tables['units']} u ON a.unit_id = u.id
                JOIN {$tables['buildings']} b ON u.building_id = b.id
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $applications = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_application'), $applications);
    }
    
    /**
     * Count applications for organization
     */
    public static function count_for_organization($org_id, $status = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($status) {
            if (is_array($status)) {
                $placeholders = implode(',', array_fill(0, count($status), '%s'));
                $sql .= " AND status IN ($placeholders)";
                $params = array_merge($params, $status);
            } else {
                $sql .= " AND status = %s";
                $params[] = $status;
            }
        }
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Update application
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $application = self::get($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'applicant_name', 'applicant_email', 'applicant_phone',
            'current_address', 'employer', 'income_range', 'desired_move_in',
            'notes', 'status', 'decline_reason'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'applicant_email':
                        $update_data[$field] = sanitize_email($data[$field]);
                        break;
                    case 'notes':
                    case 'current_address':
                    case 'decline_reason':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                    case 'status':
                        $valid_statuses = array('invited', 'new', 'screening', 'approved', 'declined', 'withdrawn');
                        if (in_array($data[$field], $valid_statuses)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $application;
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        // Track decision timestamp
        if (isset($update_data['status']) && in_array($update_data['status'], array('approved', 'declined'))) {
            $update_data['decision_at'] = current_time('mysql');
            $update_data['decision_by'] = get_current_user_id();
        }
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating application', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('applications_org_' . $application['organization_id']);
        }
        
        return self::get($id);
    }
    
    /**
     * Delete application
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        $application = self::get($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        // Delete occupants first
        $wpdb->delete(self::$occupants_table, array('application_id' => $id));
        
        // Delete application
        $wpdb->delete(self::$table_name, array('id' => $id));
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('applications_org_' . $application['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Add occupant to application
     */
    public static function add_occupant($application_id, $data) {
        global $wpdb;
        self::init();
        
        $result = $wpdb->insert(self::$occupants_table, array(
            'application_id' => intval($application_id),
            'name' => sanitize_text_field($data['name'] ?? ''),
            'email' => sanitize_email($data['email'] ?? ''),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'relationship' => sanitize_text_field($data['relationship'] ?? ''),
            'created_at' => current_time('mysql'),
        ));
        
        return $result !== false;
    }
    
    /**
     * Get occupants for application
     */
    public static function get_occupants($application_id) {
        global $wpdb;
        self::init();
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$occupants_table . " WHERE application_id = %d ORDER BY created_at ASC",
            $application_id
        ), ARRAY_A);
    }
    
    /**
     * Approve application and optionally create tenant
     */
    public static function approve($id, $create_tenant = false) {
        $application = self::get_with_details($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        if ($application['status'] === 'approved') {
            return new WP_Error('already_approved', __('Application is already approved', 'rental-gates'));
        }
        
        // Update status
        $result = self::update($id, array('status' => 'approved'));
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $tenant = null;
        
        // Create tenant if requested
        if ($create_tenant) {
            // Parse name into first/last
            $name_parts = explode(' ', $application['applicant_name'], 2);
            $first_name = $name_parts[0];
            $last_name = isset($name_parts[1]) ? $name_parts[1] : '';
            
            $tenant_data = array(
                'organization_id' => $application['organization_id'],
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email' => $application['applicant_email'],
                'phone' => $application['applicant_phone'],
                'status' => 'prospect',
                'notes' => sprintf(__('Created from application #%d', 'rental-gates'), $id),
            );
            
            $tenant = Rental_Gates_Tenant::create($tenant_data);
        }
        
        return array(
            'application' => self::get($id),
            'tenant' => $tenant,
        );
    }
    
    /**
     * Decline application
     */
    public static function decline($id, $reason = '') {
        $application = self::get($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        if ($application['status'] === 'declined') {
            return new WP_Error('already_declined', __('Application is already declined', 'rental-gates'));
        }
        
        return self::update($id, array(
            'status' => 'declined',
            'decline_reason' => $reason,
        ));
    }
    
    /**
     * Move application to screening
     */
    public static function start_screening($id) {
        $application = self::get($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        if (!in_array($application['status'], array('new', 'invited'))) {
            return new WP_Error('invalid_status', __('Can only screen new applications', 'rental-gates'));
        }
        
        return self::update($id, array('status' => 'screening'));
    }
    
    /**
     * Withdraw application
     */
    public static function withdraw($id) {
        $application = self::get($id);
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        if (in_array($application['status'], array('approved', 'declined'))) {
            return new WP_Error('cannot_withdraw', __('Cannot withdraw a decided application', 'rental-gates'));
        }
        
        return self::update($id, array('status' => 'withdrawn'));
    }
    
    /**
     * Get application statistics for organization
     */
    public static function get_stats($org_id) {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total' => 0,
            'new' => 0,
            'screening' => 0,
            'approved' => 0,
            'declined' => 0,
            'withdrawn' => 0,
            'pending' => 0,
        );
        
        // Count by status
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM " . self::$table_name . " 
             WHERE organization_id = %d GROUP BY status",
            $org_id
        ), ARRAY_A);
        
        foreach ($results as $row) {
            $stats[$row['status']] = intval($row['count']);
            $stats['total'] += intval($row['count']);
        }
        
        // Pending = new + screening
        $stats['pending'] = $stats['new'] + $stats['screening'];
        
        return $stats;
    }
    
    /**
     * Get income range label
     */
    public static function get_income_label($range) {
        $labels = array(
            'under_25k' => __('Under $25,000', 'rental-gates'),
            '25k_50k' => __('$25,000 - $50,000', 'rental-gates'),
            '50k_75k' => __('$50,000 - $75,000', 'rental-gates'),
            '75k_100k' => __('$75,000 - $100,000', 'rental-gates'),
            '100k_150k' => __('$100,000 - $150,000', 'rental-gates'),
            'over_150k' => __('Over $150,000', 'rental-gates'),
        );
        
        return $labels[$range] ?? $range;
    }
    
    /**
     * Format application data
     */
    private static function format_application($application) {
        if (!$application) return null;
        
        $application['id'] = intval($application['id']);
        $application['organization_id'] = intval($application['organization_id']);
        $application['unit_id'] = intval($application['unit_id']);
        $application['lead_id'] = $application['lead_id'] ? intval($application['lead_id']) : null;
        $application['decision_by'] = $application['decision_by'] ? intval($application['decision_by']) : null;
        
        // Parse documents
        if (!empty($application['documents'])) {
            $application['documents'] = json_decode($application['documents'], true);
        } else {
            $application['documents'] = array();
        }
        
        // Parse meta data
        if (!empty($application['meta_data'])) {
            $application['meta_data'] = json_decode($application['meta_data'], true);
        } else {
            $application['meta_data'] = array();
        }
        
        // Add income label
        $application['income_label'] = self::get_income_label($application['income_range']);
        
        // Calculate days since submission
        if ($application['submitted_at']) {
            $submitted = new DateTime($application['submitted_at']);
            $now = new DateTime();
            $application['days_pending'] = $now->diff($submitted)->days;
        } else {
            $application['days_pending'] = 0;
        }
        
        return $application;
    }
}
