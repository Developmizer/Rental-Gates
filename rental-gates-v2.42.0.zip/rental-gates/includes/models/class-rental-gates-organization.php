<?php
/**
 * Rental Gates Organization Model
 * Handles organization data and multi-tenant isolation
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Organization {
    
    /**
     * Table name
     */
    private static $table_name;
    private static $members_table;
    
    /**
     * Initialize table names
     */
    public static function init() {
        $tables = Rental_Gates_Database::get_table_names();
        self::$table_name = $tables['organizations'];
        self::$members_table = $tables['organization_members'];
    }
    
    /**
     * Create a new organization
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $validation = self::validate($data);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Generate slug
        $data['slug'] = self::generate_unique_slug($data['name']);
        
        // Set defaults
        $defaults = array(
            'status' => 'active',
            'map_provider' => get_option('rental_gates_map_provider', 'google'),
            'default_language' => get_option('rental_gates_default_language', 'en'),
            'timezone' => 'America/New_York',
            'currency' => 'USD',
            'late_fee_grace_days' => 5,
            'late_fee_type' => 'flat',
            'late_fee_amount' => 0,
            'allow_partial_payments' => 1,
            'coming_soon_window_days' => 30,
            'renewal_notice_days' => 60,
            'move_in_notice_days' => 7,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Serialize JSON fields
        $json_fields = array('social_links', 'branding', 'meta_data');
        foreach ($json_fields as $field) {
            if (isset($data[$field]) && is_array($data[$field])) {
                $data[$field] = wp_json_encode($data[$field]);
            }
        }
        
        $result = $wpdb->insert(self::$table_name, $data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create organization', 'rental-gates'));
        }
        
        $org_id = $wpdb->insert_id;
        
        // Log activity
        self::log_activity($org_id, 'created', null, $data);
        
        // Clear cache
        Rental_Gates_Cache::clear_organization_cache($org_id);
        
        // Create default subscription (free plan)
        if (class_exists('Rental_Gates_Subscription')) {
            Rental_Gates_Subscription::create_for_organization($org_id);
        }
        
        return self::get($org_id);
    }
    
    /**
     * Get organization by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $cache_key = Rental_Gates_Cache::org_key($id);
        $cached = Rental_Gates_Cache::get($cache_key, 'organizations');
        
        if ($cached !== false) {
            return $cached;
        }
        
        $org = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$org) {
            return null;
        }
        
        $org = self::format_organization($org);
        
        Rental_Gates_Cache::set($cache_key, $org, 'organizations');
        
        return $org;
    }
    
    /**
     * Get organization by slug
     */
    public static function get_by_slug($slug) {
        global $wpdb;
        self::init();
        
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . " WHERE slug = %s",
            $slug
        ));
        
        if (!$id) {
            return null;
        }
        
        return self::get($id);
    }
    
    /**
     * Update organization
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        // Get old data for logging
        $old_data = self::get($id);
        if (!$old_data) {
            return new WP_Error('not_found', __('Organization not found', 'rental-gates'));
        }
        
        // Validate
        $validation = self::validate($data, true);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Update slug if name changed
        if (isset($data['name']) && $data['name'] !== $old_data['name']) {
            $data['slug'] = self::generate_unique_slug($data['name'], $id);
        }
        
        $data['updated_at'] = current_time('mysql');
        
        // Serialize JSON fields
        $json_fields = array('social_links', 'branding', 'meta_data');
        foreach ($json_fields as $field) {
            if (isset($data[$field]) && is_array($data[$field])) {
                $data[$field] = wp_json_encode($data[$field]);
            }
        }
        
        $result = $wpdb->update(
            self::$table_name,
            $data,
            array('id' => $id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update organization', 'rental-gates'));
        }
        
        // Log activity
        self::log_activity($id, 'updated', $old_data, $data);
        
        // Clear cache
        Rental_Gates_Cache::clear_organization_cache($id);
        
        return self::get($id);
    }
    
    /**
     * Delete organization
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        // Get data for logging
        $org = self::get($id);
        if (!$org) {
            return new WP_Error('not_found', __('Organization not found', 'rental-gates'));
        }
        
        // Start transaction
        $wpdb->query('START TRANSACTION');
        
        try {
            // Delete all related data
            $tables = Rental_Gates_Database::get_table_names();
            
            // Delete members
            $wpdb->delete(self::$members_table, array('organization_id' => $id));
            
            // Delete buildings (will cascade to units)
            $wpdb->delete($tables['buildings'], array('organization_id' => $id));
            
            // Delete other org-related data
            $org_tables = array(
                'units', 'tenants', 'vendors', 'applications', 'leases',
                'leads', 'work_orders', 'payments', 'documents',
                'announcements', 'subscriptions', 'stripe_accounts'
            );
            
            foreach ($org_tables as $table_key) {
                if (isset($tables[$table_key])) {
                    $wpdb->delete($tables[$table_key], array('organization_id' => $id));
                }
            }
            
            // Delete organization
            $result = $wpdb->delete(self::$table_name, array('id' => $id));
            
            if ($result === false) {
                throw new Exception('Failed to delete organization');
            }
            
            $wpdb->query('COMMIT');
            
            // Log activity
            self::log_activity($id, 'deleted', $org, null);
            
            // Clear cache
            Rental_Gates_Cache::clear_organization_cache($id);
            
            return true;
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('db_error', $e->getMessage());
        }
    }
    
    /**
     * Get all organizations (for site admin)
     */
    public static function get_all($args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'status' => null,
            'search' => '',
            'orderby' => 'created_at',
            'order' => 'DESC',
            'page' => 1,
            'per_page' => 20,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $values[] = $args['status'];
        }
        
        if (!empty($args['search'])) {
            $where[] = '(name LIKE %s OR contact_email LIKE %s)';
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $values[] = $search;
            $values[] = $search;
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Get total count
        $count_query = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE {$where_clause}";
        if (!empty($values)) {
            $count_query = $wpdb->prepare($count_query, $values);
        }
        $total = $wpdb->get_var($count_query);
        
        // Get results
        $offset = ($args['page'] - 1) * $args['per_page'];
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';
        
        $query = "SELECT * FROM " . self::$table_name . " 
                  WHERE {$where_clause} 
                  ORDER BY {$orderby} 
                  LIMIT %d OFFSET %d";
        
        $query_values = array_merge($values, array($args['per_page'], $offset));
        $results = $wpdb->get_results($wpdb->prepare($query, $query_values), ARRAY_A);
        
        $organizations = array();
        foreach ($results as $row) {
            $organizations[] = self::format_organization($row);
        }
        
        return array(
            'items' => $organizations,
            'total' => intval($total),
            'pages' => ceil($total / $args['per_page']),
        );
    }
    
    /**
     * Add member to organization
     */
    public static function add_member($org_id, $user_id, $role = 'staff', $is_primary = false) {
        global $wpdb;
        self::init();
        
        // Check if already a member
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$members_table . " 
             WHERE organization_id = %d AND user_id = %d",
            $org_id,
            $user_id
        ));
        
        if ($existing) {
            return new WP_Error('already_member', __('User is already a member', 'rental-gates'));
        }
        
        $data = array(
            'organization_id' => $org_id,
            'user_id' => $user_id,
            'role' => $role,
            'is_primary_owner' => $is_primary ? 1 : 0,
            'status' => 'active',
            'joined_at' => current_time('mysql'),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$members_table, $data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to add member', 'rental-gates'));
        }
        
        // Assign WordPress role
        $user = get_user_by('ID', $user_id);
        if ($user) {
            $wp_role = 'rental_gates_' . $role;
            $user->add_role($wp_role);
        }
        
        // Clear cache
        Rental_Gates_Cache::clear_organization_cache($org_id);
        
        return true;
    }
    
    /**
     * Remove member from organization
     */
    public static function remove_member($org_id, $user_id) {
        global $wpdb;
        self::init();
        
        // Check if primary owner
        $member = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$members_table . " 
             WHERE organization_id = %d AND user_id = %d",
            $org_id,
            $user_id
        ), ARRAY_A);
        
        if (!$member) {
            return new WP_Error('not_member', __('User is not a member', 'rental-gates'));
        }
        
        if ($member['is_primary_owner']) {
            return new WP_Error('cannot_remove_owner', __('Cannot remove primary owner', 'rental-gates'));
        }
        
        $result = $wpdb->delete(
            self::$members_table,
            array('organization_id' => $org_id, 'user_id' => $user_id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to remove member', 'rental-gates'));
        }
        
        // Remove staff permissions
        $tables = Rental_Gates_Database::get_table_names();
        $wpdb->delete(
            $tables['staff_permissions'],
            array('organization_id' => $org_id, 'user_id' => $user_id)
        );
        
        // Clear cache
        Rental_Gates_Cache::clear_organization_cache($org_id);
        
        return true;
    }
    
    /**
     * Get organization members
     */
    public static function get_members($org_id, $role = null) {
        global $wpdb;
        self::init();
        
        $where = array('om.organization_id = %d', 'om.status = %s');
        $values = array($org_id, 'active');
        
        if ($role) {
            $where[] = 'om.role = %s';
            $values[] = $role;
        }
        
        $where_clause = implode(' AND ', $where);
        
        $query = "SELECT om.*, u.display_name, u.user_email 
                  FROM " . self::$members_table . " om
                  JOIN {$wpdb->users} u ON om.user_id = u.ID
                  WHERE {$where_clause}
                  ORDER BY om.is_primary_owner DESC, om.joined_at ASC";
        
        return $wpdb->get_results($wpdb->prepare($query, $values), ARRAY_A);
    }
    
    /**
     * Get organization stats
     */
    public static function get_stats($org_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check if tables exist
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['buildings']}'");
        if (!$table_exists) {
            // Tables not yet created, return empty stats
            return array(
                'buildings' => 0,
                'units' => array(
                    'total' => 0,
                    'available' => 0,
                    'coming_soon' => 0,
                    'occupied' => 0,
                    'renewal_pending' => 0,
                    'unlisted' => 0,
                ),
                'tenants' => 0,
                'active_leases' => 0,
                'open_maintenance' => 0,
                'new_leads_month' => 0,
                'occupancy_rate' => 0,
            );
        }
        
        // Try cache first
        $cached = Rental_Gates_Cache::get_stats($org_id, 'overview');
        if ($cached !== false) {
            return $cached;
        }
        
        $stats = array();
        
        // Buildings count
        $stats['buildings'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['buildings']} WHERE organization_id = %d AND status = 'active'",
            $org_id
        )));
        
        // Units by status
        $units_query = $wpdb->get_results($wpdb->prepare(
            "SELECT availability, COUNT(*) as count FROM {$tables['units']} 
             WHERE organization_id = %d 
             GROUP BY availability",
            $org_id
        ), ARRAY_A);
        
        $stats['units'] = array(
            'total' => 0,
            'available' => 0,
            'coming_soon' => 0,
            'occupied' => 0,
            'renewal_pending' => 0,
            'unlisted' => 0,
        );
        
        foreach ($units_query as $row) {
            $stats['units'][$row['availability']] = intval($row['count']);
            $stats['units']['total'] += intval($row['count']);
        }
        
        // Tenants count
        $stats['tenants'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['tenants']} WHERE organization_id = %d AND status = 'active'",
            $org_id
        )));
        
        // Active leases
        $stats['active_leases'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leases']} WHERE organization_id = %d AND status = 'active'",
            $org_id
        )));
        
        // Open maintenance requests
        $stats['open_maintenance'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['work_orders']} 
             WHERE organization_id = %d AND status IN ('open', 'assigned', 'in_progress')",
            $org_id
        )));
        
        // New leads this month
        $stats['new_leads_month'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leads']} 
             WHERE organization_id = %d AND created_at >= %s",
            $org_id,
            date('Y-m-01 00:00:00')
        )));
        
        // Occupancy rate
        $occupied_count = $stats['units']['occupied'] + $stats['units']['renewal_pending'];
        $rentable_units = $stats['units']['total'] - $stats['units']['unlisted'];
        $stats['occupancy_rate'] = $rentable_units > 0 
            ? round(($occupied_count / $rentable_units) * 100, 1) 
            : 0;
        
        // Cache for 5 minutes
        Rental_Gates_Cache::set_stats($org_id, 'overview', $stats, 300);
        
        return $stats;
    }
    
    /**
     * Validate organization data
     */
    public static function validate($data, $is_update = false) {
        $errors = array();
        
        if (!$is_update) {
            if (empty($data['name'])) {
                $errors[] = __('Organization name is required', 'rental-gates');
            }
        }
        
        if (isset($data['name']) && strlen($data['name']) > 255) {
            $errors[] = __('Organization name is too long', 'rental-gates');
        }
        
        if (isset($data['contact_email']) && !empty($data['contact_email'])) {
            if (!is_email($data['contact_email'])) {
                $errors[] = __('Invalid contact email', 'rental-gates');
            }
        }
        
        if (isset($data['map_provider']) && !in_array($data['map_provider'], array('google', 'openstreetmap'))) {
            $errors[] = __('Invalid map provider', 'rental-gates');
        }
        
        if (isset($data['default_language']) && !in_array($data['default_language'], array('en', 'ar'))) {
            $errors[] = __('Invalid language', 'rental-gates');
        }
        
        if (!empty($errors)) {
            return new WP_Error('validation_error', implode(', ', $errors));
        }
        
        return true;
    }
    
    /**
     * Format organization data
     */
    private static function format_organization($org) {
        // Parse JSON fields
        $json_fields = array('social_links', 'branding', 'meta_data');
        foreach ($json_fields as $field) {
            if (isset($org[$field])) {
                $org[$field] = json_decode($org[$field], true) ?: array();
            }
        }
        
        // Cast numeric fields
        $org['id'] = intval($org['id']);
        $org['logo'] = $org['logo'] ? intval($org['logo']) : null;
        $org['cover_image'] = $org['cover_image'] ? intval($org['cover_image']) : null;
        $org['late_fee_grace_days'] = intval($org['late_fee_grace_days']);
        $org['late_fee_amount'] = floatval($org['late_fee_amount']);
        $org['late_fee_max_cap'] = $org['late_fee_max_cap'] ? floatval($org['late_fee_max_cap']) : null;
        $org['late_fee_recurring'] = (bool) $org['late_fee_recurring'];
        $org['allow_partial_payments'] = (bool) $org['allow_partial_payments'];
        $org['coming_soon_window_days'] = intval($org['coming_soon_window_days']);
        $org['renewal_notice_days'] = intval($org['renewal_notice_days']);
        $org['move_in_notice_days'] = intval($org['move_in_notice_days']);
        
        // Add URLs
        if ($org['logo']) {
            $org['logo_url'] = wp_get_attachment_url($org['logo']);
        }
        if ($org['cover_image']) {
            $org['cover_image_url'] = wp_get_attachment_url($org['cover_image']);
        }
        
        // Public URL
        $org['public_url'] = home_url('/rental-gates/profile/' . $org['slug']);
        
        return $org;
    }
    
    /**
     * Generate unique slug
     */
    private static function generate_unique_slug($name, $exclude_id = null) {
        global $wpdb;
        self::init();
        
        $slug = sanitize_title($name);
        $original_slug = $slug;
        $counter = 1;
        
        while (true) {
            $query = "SELECT id FROM " . self::$table_name . " WHERE slug = %s";
            $values = array($slug);
            
            if ($exclude_id) {
                $query .= " AND id != %d";
                $values[] = $exclude_id;
            }
            
            $existing = $wpdb->get_var($wpdb->prepare($query, $values));
            
            if (!$existing) {
                break;
            }
            
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    /**
     * Log activity
     */
    private static function log_activity($org_id, $action, $old_data, $new_data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $wpdb->insert(
            $tables['activity_log'],
            array(
                'user_id' => get_current_user_id(),
                'organization_id' => $org_id,
                'action' => 'organization_' . $action,
                'entity_type' => 'organization',
                'entity_id' => $org_id,
                'old_values' => $old_data ? wp_json_encode($old_data) : null,
                'new_values' => $new_data ? wp_json_encode($new_data) : null,
                'ip_address' => Rental_Gates_Security::get_client_ip(),
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s')
        );
    }
}
