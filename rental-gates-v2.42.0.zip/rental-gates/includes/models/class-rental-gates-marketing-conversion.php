<?php
/**
 * Rental Gates Marketing Conversion Tracker
 * 
 * Tracks conversions from marketing touchpoints (QR scans, leads) 
 * through the funnel to leases with attribution modeling.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Marketing_Conversion {
    
    /**
     * Track a conversion event
     */
    public static function track($event_type, $entity_id, $entity_type, $org_id, $data = array()) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Store in activity log with conversion metadata
        $wpdb->insert(
            $tables['activity_log'],
            array(
                'organization_id' => $org_id,
                'user_id' => get_current_user_id() ?: null,
                'entity_type' => $entity_type,
                'entity_id' => $entity_id,
                'action' => 'conversion_' . $event_type,
                'details' => wp_json_encode(array_merge($data, array(
                    'conversion_type' => $event_type,
                    'tracked_at' => current_time('mysql'),
                ))),
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%s')
        );
        
        return true;
    }
    
    /**
     * Get conversion funnel for a marketing source
     */
    public static function get_funnel($org_id, $source = null, $source_id = null, $days = 30) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $start_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $where = array("l.organization_id = %d", "l.created_at >= %s");
        $params = array($org_id, $start_date);
        
        if ($source) {
            $where[] = "l.source = %s";
            $params[] = $source;
        }
        
        if ($source_id) {
            $where[] = "l.source_id = %d";
            $params[] = $source_id;
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Get leads
        $leads = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leads']} l WHERE {$where_clause}",
            $params
        )));
        
        // Get applications from these leads
        $lead_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT l.id FROM {$tables['leads']} l WHERE {$where_clause}",
            $params
        ));
        
        $applications = 0;
        $leases = 0;
        
        if (!empty($lead_ids)) {
            $placeholders = implode(',', array_fill(0, count($lead_ids), '%d'));
            
            // Applications
            $applications = intval($wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$tables['applications']} 
                 WHERE organization_id = %d AND lead_id IN ($placeholders)",
                array_merge(array($org_id), $lead_ids)
            )));
            
            // Leases from applications
            $application_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$tables['applications']} 
                 WHERE organization_id = %d AND lead_id IN ($placeholders)",
                array_merge(array($org_id), $lead_ids)
            ));
            
            if (!empty($application_ids)) {
                $app_placeholders = implode(',', array_fill(0, count($application_ids), '%d'));
                $leases = intval($wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$tables['leases']} 
                     WHERE organization_id = %d AND application_id IN ($app_placeholders) AND status = 'active'",
                    array_merge(array($org_id), $application_ids)
                )));
            }
        }
        
        return array(
            'leads' => $leads,
            'applications' => $applications,
            'leases' => $leases,
            'conversion_rates' => array(
                'lead_to_application' => $leads > 0 ? round(($applications / $leads) * 100, 2) : 0,
                'application_to_lease' => $applications > 0 ? round(($leases / $applications) * 100, 2) : 0,
                'overall' => $leads > 0 ? round(($leases / $leads) * 100, 2) : 0,
            ),
        );
    }
    
    /**
     * Get attribution data (first-touch, last-touch, multi-touch)
     */
    public static function get_attribution($org_id, $lead_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $lead = Rental_Gates_Lead::get($lead_id);
        if (!$lead) {
            return null;
        }
        
        // First touch (source when lead was created)
        $first_touch = array(
            'source' => $lead['source'],
            'source_id' => $lead['source_id'],
            'date' => $lead['created_at'],
        );
        
        // Last touch (most recent activity before conversion)
        $last_activity = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['activity_log']} 
             WHERE organization_id = %d AND entity_type = 'lead' AND entity_id = %d
             ORDER BY created_at DESC LIMIT 1",
            $org_id, $lead_id
        ), ARRAY_A);
        
        $last_touch = $first_touch;
        if ($last_activity) {
            $details = json_decode($last_activity['details'], true);
            if (!empty($details['source'])) {
                $last_touch = array(
                    'source' => $details['source'],
                    'source_id' => $details['source_id'] ?? null,
                    'date' => $last_activity['created_at'],
                );
            }
        }
        
        // Multi-touch (all touchpoints)
        $all_touchpoints = array($first_touch);
        
        // Get all activities
        $activities = Rental_Gates_Lead::get_activity($lead_id, 50);
        foreach ($activities as $activity) {
            $details = json_decode($activity['details'], true);
            if (!empty($details['source']) && $details['source'] !== $first_touch['source']) {
                $all_touchpoints[] = array(
                    'source' => $details['source'],
                    'source_id' => $details['source_id'] ?? null,
                    'date' => $activity['created_at'],
                );
            }
        }
        
        return array(
            'first_touch' => $first_touch,
            'last_touch' => $last_touch,
            'all_touchpoints' => $all_touchpoints,
        );
    }
}
