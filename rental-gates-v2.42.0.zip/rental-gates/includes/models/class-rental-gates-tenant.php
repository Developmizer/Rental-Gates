<?php
/**
 * Rental Gates Tenant Model
 * 
 * Handles tenant management including CRUD operations,
 * user linking, and lease associations.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Tenant {
    
    private static $table_name;
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['tenants'];
        }
    }
    
    /**
     * Create a new tenant
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $required = array('organization_id', 'first_name', 'last_name', 'email', 'phone');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return new WP_Error('missing_field', sprintf(__('Missing required field: %s', 'rental-gates'), $field));
            }
        }
        
        // Validate email
        if (!is_email($data['email'])) {
            return new WP_Error('invalid_email', __('Invalid email address', 'rental-gates'));
        }
        
        // Check for duplicate email in same organization
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . " WHERE email = %s AND organization_id = %d",
            $data['email'], $data['organization_id']
        ));
        
        if ($existing) {
            return new WP_Error('duplicate_email', __('A tenant with this email already exists', 'rental-gates'));
        }
        
        // Prepare insert data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'user_id' => !empty($data['user_id']) ? intval($data['user_id']) : null,
            'first_name' => sanitize_text_field($data['first_name']),
            'last_name' => sanitize_text_field($data['last_name']),
            'email' => sanitize_email($data['email']),
            'phone' => sanitize_text_field($data['phone']),
            'preferred_contact' => in_array($data['preferred_contact'] ?? '', array('email', 'phone', 'text')) 
                ? $data['preferred_contact'] : 'email',
            'emergency_contact_name' => sanitize_text_field($data['emergency_contact_name'] ?? ''),
            'emergency_contact_phone' => sanitize_text_field($data['emergency_contact_phone'] ?? ''),
            'date_of_birth' => !empty($data['date_of_birth']) ? sanitize_text_field($data['date_of_birth']) : null,
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'status' => in_array($data['status'] ?? '', array('active', 'former', 'prospect')) 
                ? $data['status'] : 'prospect',
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating tenant', 'rental-gates'));
        }
        
        $tenant_id = $wpdb->insert_id;
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('tenants_org_' . $data['organization_id']);
        }
        
        return self::get($tenant_id);
    }
    
    /**
     * Get tenant by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $tenant = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$tenant) {
            return null;
        }
        
        return self::format_tenant($tenant);
    }
    
    /**
     * Get tenant by email within organization
     */
    public static function get_by_email($email, $org_id) {
        global $wpdb;
        self::init();
        
        $tenant = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE email = %s AND organization_id = %d",
            $email, $org_id
        ), ARRAY_A);
        
        if (!$tenant) {
            return null;
        }
        
        return self::format_tenant($tenant);
    }
    
    /**
     * Get tenant by user ID
     */
    public static function get_by_user_id($user_id, $org_id = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT * FROM " . self::$table_name . " WHERE user_id = %d";
        $params = array($user_id);
        
        if ($org_id) {
            $sql .= " AND organization_id = %d";
            $params[] = $org_id;
        }
        
        $tenant = $wpdb->get_row($wpdb->prepare($sql, $params), ARRAY_A);
        
        if (!$tenant) {
            return null;
        }
        
        return self::format_tenant($tenant);
    }
    
    /**
     * Get tenants for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'status' => null,
            'search' => null,
            'orderby' => 'last_name',
            'order' => 'ASC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR phone LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        $orderby = in_array($args['orderby'], array('first_name', 'last_name', 'email', 'status', 'created_at')) 
            ? $args['orderby'] : 'last_name';
        $order = strtoupper($args['order']) === 'DESC' ? 'DESC' : 'ASC';
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $tenants = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_tenant'), $tenants);
    }
    
    /**
     * Count tenants for organization
     */
    public static function count_for_organization($org_id, $status = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($status) {
            $sql .= " AND status = %s";
            $params[] = $status;
        }
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Update tenant
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $tenant = self::get($id);
        if (!$tenant) {
            return new WP_Error('not_found', __('Tenant not found', 'rental-gates'));
        }
        
        // Check for duplicate email if email is being changed
        if (!empty($data['email']) && $data['email'] !== $tenant['email']) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . self::$table_name . " WHERE email = %s AND organization_id = %d AND id != %d",
                $data['email'], $tenant['organization_id'], $id
            ));
            
            if ($existing) {
                return new WP_Error('duplicate_email', __('A tenant with this email already exists', 'rental-gates'));
            }
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'first_name', 'last_name', 'email', 'phone', 'preferred_contact',
            'emergency_contact_name', 'emergency_contact_phone', 'date_of_birth',
            'notes', 'status', 'forwarding_address', 'user_id'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'email':
                        $update_data[$field] = sanitize_email($data[$field]);
                        break;
                    case 'notes':
                    case 'forwarding_address':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                    case 'user_id':
                        $update_data[$field] = !empty($data[$field]) ? intval($data[$field]) : null;
                        break;
                    case 'preferred_contact':
                        $update_data[$field] = in_array($data[$field], array('email', 'phone', 'text')) 
                            ? $data[$field] : 'email';
                        break;
                    case 'status':
                        $update_data[$field] = in_array($data[$field], array('active', 'former', 'prospect')) 
                            ? $data[$field] : $tenant['status'];
                        break;
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $tenant;
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating tenant', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('tenants_org_' . $tenant['organization_id']);
        }
        
        return self::get($id);
    }
    
    /**
     * Delete tenant
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $tenant = self::get($id);
        if (!$tenant) {
            return new WP_Error('not_found', __('Tenant not found', 'rental-gates'));
        }
        
        // Check for active leases
        $active_leases = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['lease_tenants']} lt
             JOIN {$tables['leases']} l ON lt.lease_id = l.id
             WHERE lt.tenant_id = %d AND l.status IN ('active', 'pending')",
            $id
        ));
        
        if ($active_leases > 0) {
            return new WP_Error('has_leases', __('Cannot delete tenant with active leases', 'rental-gates'));
        }
        
        // Delete lease associations
        $wpdb->delete($tables['lease_tenants'], array('tenant_id' => $id));
        
        // Delete tenant
        $wpdb->delete(self::$table_name, array('id' => $id));
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('tenants_org_' . $tenant['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Link tenant to WordPress user
     */
    public static function link_to_user($tenant_id, $user_id) {
        global $wpdb;
        self::init();
        
        $tenant = self::get($tenant_id);
        if (!$tenant) {
            return new WP_Error('not_found', __('Tenant not found', 'rental-gates'));
        }
        
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return new WP_Error('user_not_found', __('User not found', 'rental-gates'));
        }
        
        // Update tenant with user ID
        $result = $wpdb->update(
            self::$table_name,
            array('user_id' => $user_id, 'updated_at' => current_time('mysql')),
            array('id' => $tenant_id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error linking tenant to user', 'rental-gates'));
        }
        
        // Add tenant role to user
        $user->add_role('rental_gates_tenant');
        
        // Store organization association
        update_user_meta($user_id, 'rental_gates_tenant_id', $tenant_id);
        update_user_meta($user_id, 'rental_gates_organization_id', $tenant['organization_id']);
        
        return self::get($tenant_id);
    }
    
    /**
     * Create WordPress user for tenant and send invitation
     */
    public static function invite_to_portal($tenant_id) {
        global $wpdb;
        self::init();
        
        $tenant = self::get($tenant_id);
        if (!$tenant) {
            return new WP_Error('not_found', __('Tenant not found', 'rental-gates'));
        }
        
        // Check if already has user
        if ($tenant['user_id']) {
            return new WP_Error('already_linked', __('Tenant already has portal access', 'rental-gates'));
        }
        
        // Check if user with this email already exists
        $existing_user = get_user_by('email', $tenant['email']);
        if ($existing_user) {
            // Link existing user
            return self::link_to_user($tenant_id, $existing_user->ID);
        }
        
        // Create new user
        $username = sanitize_user(strtolower($tenant['first_name'] . '.' . $tenant['last_name']));
        $username = self::generate_unique_username($username);
        $password = wp_generate_password(12, true);
        
        $user_id = wp_create_user($username, $password, $tenant['email']);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        // Update user info
        wp_update_user(array(
            'ID' => $user_id,
            'first_name' => $tenant['first_name'],
            'last_name' => $tenant['last_name'],
            'display_name' => $tenant['first_name'] . ' ' . $tenant['last_name'],
        ));
        
        // Link tenant to user
        $result = self::link_to_user($tenant_id, $user_id);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Send invitation email
        $organization = Rental_Gates_Organization::get($tenant['organization_id']);
        $login_url = home_url('/rental-gates/login');
        
        $subject = sprintf(__('Welcome to %s Tenant Portal', 'rental-gates'), $organization['name']);
        $message = sprintf(
            __("Hello %s,\n\nYou've been invited to access the tenant portal for %s.\n\nLogin URL: %s\nUsername: %s\nPassword: %s\n\nPlease change your password after logging in.\n\nBest regards,\n%s", 'rental-gates'),
            $tenant['first_name'],
            $organization['name'],
            $login_url,
            $username,
            $password,
            $organization['name']
        );
        
        wp_mail($tenant['email'], $subject, $message);
        
        return self::get($tenant_id);
    }
    
    /**
     * Generate unique username
     */
    private static function generate_unique_username($username) {
        $original = $username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $original . $counter;
            $counter++;
        }
        
        return $username;
    }
    
    /**
     * Get tenant's current lease
     */
    public static function get_current_lease($tenant_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $lease = $wpdb->get_row($wpdb->prepare(
            "SELECT l.* FROM {$tables['leases']} l
             JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id
             WHERE lt.tenant_id = %d AND l.status = 'active'
             ORDER BY l.start_date DESC LIMIT 1",
            $tenant_id
        ), ARRAY_A);
        
        return $lease;
    }
    
    /**
     * Get tenant's lease history
     */
    public static function get_lease_history($tenant_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $leases = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, u.name as unit_name, b.name as building_name
             FROM {$tables['leases']} l
             JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id
             JOIN {$tables['units']} u ON l.unit_id = u.id
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE lt.tenant_id = %d
             ORDER BY l.start_date DESC",
            $tenant_id
        ), ARRAY_A);
        
        return $leases;
    }
    
    /**
     * Format tenant data
     */
    private static function format_tenant($tenant) {
        if (!$tenant) return null;
        
        $tenant['id'] = intval($tenant['id']);
        $tenant['organization_id'] = intval($tenant['organization_id']);
        $tenant['user_id'] = $tenant['user_id'] ? intval($tenant['user_id']) : null;
        $tenant['full_name'] = $tenant['first_name'] . ' ' . $tenant['last_name'];
        $tenant['has_portal_access'] = !empty($tenant['user_id']);
        
        // Parse meta data
        if (!empty($tenant['meta_data'])) {
            $tenant['meta_data'] = json_decode($tenant['meta_data'], true);
        } else {
            $tenant['meta_data'] = array();
        }
        
        return $tenant;
    }
    
    /**
     * Get tenant statistics for organization
     */
    public static function get_stats($org_id) {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total' => 0,
            'active' => 0,
            'former' => 0,
            'prospect' => 0,
            'with_portal' => 0,
        );
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM " . self::$table_name . " 
             WHERE organization_id = %d GROUP BY status",
            $org_id
        ), ARRAY_A);
        
        foreach ($results as $row) {
            $stats[$row['status']] = intval($row['count']);
            $stats['total'] += intval($row['count']);
        }
        
        $stats['with_portal'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND user_id IS NOT NULL",
            $org_id
        )));
        
        return $stats;
    }
}
