<?php
/**
 * Rental Gates Lead Model
 * 
 * Handles lead/prospect management including CRUD operations,
 * pipeline stages, interests tracking, and conversion.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Lead {
    
    private static $table_name;
    private static $interests_table;
    
    /**
     * Lead stages
     */
    const STAGE_NEW = 'new';
    const STAGE_CONTACTED = 'contacted';
    const STAGE_TOURING = 'touring';
    const STAGE_APPLIED = 'applied';
    const STAGE_WON = 'won';
    const STAGE_LOST = 'lost';
    
    /**
     * Lead sources
     */
    const SOURCE_QR_BUILDING = 'qr_building';
    const SOURCE_QR_UNIT = 'qr_unit';
    const SOURCE_MAP = 'map';
    const SOURCE_PROFILE = 'profile';
    const SOURCE_MANUAL = 'manual';
    const SOURCE_REFERRAL = 'referral';
    
    /**
     * Initialize table names
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['leads'];
            self::$interests_table = $tables['lead_interests'];
        }
    }
    
    /**
     * Get all stages with labels and colors
     */
    public static function get_stages() {
        return array(
            self::STAGE_NEW => array(
                'label' => __('New', 'rental-gates'),
                'color' => '#3b82f6',
                'bg' => '#dbeafe',
            ),
            self::STAGE_CONTACTED => array(
                'label' => __('Contacted', 'rental-gates'),
                'color' => '#8b5cf6',
                'bg' => '#ede9fe',
            ),
            self::STAGE_TOURING => array(
                'label' => __('Touring', 'rental-gates'),
                'color' => '#f59e0b',
                'bg' => '#fef3c7',
            ),
            self::STAGE_APPLIED => array(
                'label' => __('Applied', 'rental-gates'),
                'color' => '#06b6d4',
                'bg' => '#cffafe',
            ),
            self::STAGE_WON => array(
                'label' => __('Won', 'rental-gates'),
                'color' => '#10b981',
                'bg' => '#d1fae5',
            ),
            self::STAGE_LOST => array(
                'label' => __('Lost', 'rental-gates'),
                'color' => '#6b7280',
                'bg' => '#f3f4f6',
            ),
        );
    }
    
    /**
     * Get all sources with labels
     */
    public static function get_sources() {
        return array(
            self::SOURCE_QR_BUILDING => __('QR Code (Building)', 'rental-gates'),
            self::SOURCE_QR_UNIT => __('QR Code (Unit)', 'rental-gates'),
            self::SOURCE_MAP => __('Map Search', 'rental-gates'),
            self::SOURCE_PROFILE => __('Company Profile', 'rental-gates'),
            self::SOURCE_MANUAL => __('Manual Entry', 'rental-gates'),
            self::SOURCE_REFERRAL => __('Referral', 'rental-gates'),
        );
    }
    
    /**
     * Create a new lead
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['name']) || empty($data['email'])) {
            return new WP_Error('missing_fields', __('Name and email are required', 'rental-gates'));
        }
        
        // Check for duplicate email in same org (active leads only)
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . " 
             WHERE organization_id = %d AND email = %s AND stage NOT IN ('won', 'lost')",
            $data['organization_id'],
            $data['email']
        ));
        
        if ($existing) {
            // Return existing lead ID instead of error - add interest if provided
            if (!empty($data['building_id']) || !empty($data['unit_id'])) {
                self::add_interest($existing, $data['building_id'] ?? null, $data['unit_id'] ?? null);
            }
            return $existing;
        }
        
        // Prepare data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'name' => sanitize_text_field($data['name']),
            'email' => sanitize_email($data['email']),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'source' => in_array($data['source'] ?? '', array_keys(self::get_sources())) 
                ? $data['source'] : self::SOURCE_MANUAL,
            'source_id' => !empty($data['source_id']) ? intval($data['source_id']) : null,
            'stage' => self::STAGE_NEW,
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'follow_up_date' => !empty($data['follow_up_date']) ? $data['follow_up_date'] : null,
            'assigned_to' => !empty($data['assigned_to']) ? intval($data['assigned_to']) : null,
            'created_at' => current_time('mysql'),
        );
        
        // Handle meta data
        if (!empty($data['meta_data'])) {
            $insert_data['meta_data'] = is_array($data['meta_data']) 
                ? wp_json_encode($data['meta_data']) 
                : $data['meta_data'];
        }
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create lead', 'rental-gates'));
        }
        
        $lead_id = $wpdb->insert_id;
        
        // Add interests if provided
        if (!empty($data['interests'])) {
            self::add_interests($lead_id, $data['interests']);
        }
        
        // Add single interest from source
        if (!empty($data['building_id']) || !empty($data['unit_id'])) {
            self::add_interest($lead_id, $data['building_id'] ?? null, $data['unit_id'] ?? null);
        }
        
        // Create notification for assigned user
        if (!empty($insert_data['assigned_to'])) {
            if (class_exists('Rental_Gates_Notification')) {
                Rental_Gates_Notification::create(
                    $insert_data['assigned_to'],
                    'lead',
                    __('New lead assigned to you', 'rental-gates'),
                    sprintf(__('%s is interested in your properties', 'rental-gates'), $insert_data['name']),
                    home_url('/rental-gates/dashboard/leads/' . $lead_id)
                );
            }
        }
        
        // Trigger marketing automation
        if (class_exists('Rental_Gates_Marketing_Automation')) {
            Rental_Gates_Marketing_Automation::process_trigger(
                Rental_Gates_Marketing_Automation::TRIGGER_NEW_LEAD,
                $lead_id,
                'lead',
                $insert_data['organization_id'],
                array_merge($insert_data, array('lead_id' => $lead_id))
            );
        }
        
        return $lead_id;
    }
    
    /**
     * Get a single lead
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $lead = $wpdb->get_row($wpdb->prepare(
            "SELECT l.*, u.display_name as assigned_name
             FROM " . self::$table_name . " l
             LEFT JOIN {$wpdb->users} u ON l.assigned_to = u.ID
             WHERE l.id = %d",
            $id
        ), ARRAY_A);
        
        if (!$lead) {
            return null;
        }
        
        return self::format_lead($lead);
    }
    
    /**
     * Get lead with full details including interests
     */
    public static function get_with_details($id) {
        $lead = self::get($id);
        
        if (!$lead) {
            return null;
        }
        
        $lead['interests'] = self::get_interests($id);
        $lead['activity'] = self::get_activity($id);
        
        return $lead;
    }
    
    /**
     * Get leads for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'stage' => null,
            'source' => null,
            'assigned_to' => null,
            'search' => null,
            'follow_up_due' => false,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('l.organization_id = %d');
        $params = array($org_id);
        
        if ($args['stage']) {
            if (is_array($args['stage'])) {
                $placeholders = implode(',', array_fill(0, count($args['stage']), '%s'));
                $where[] = "l.stage IN ($placeholders)";
                $params = array_merge($params, $args['stage']);
            } else {
                $where[] = 'l.stage = %s';
                $params[] = $args['stage'];
            }
        }
        
        if ($args['source']) {
            $where[] = 'l.source = %s';
            $params[] = $args['source'];
        }
        
        if ($args['assigned_to']) {
            $where[] = 'l.assigned_to = %d';
            $params[] = $args['assigned_to'];
        }
        
        if ($args['search']) {
            $where[] = '(l.name LIKE %s OR l.email LIKE %s OR l.phone LIKE %s)';
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        if ($args['follow_up_due']) {
            $where[] = 'l.follow_up_date IS NOT NULL AND l.follow_up_date <= %s';
            $params[] = current_time('mysql');
        }
        
        $where_clause = implode(' AND ', $where);
        $orderby = in_array($args['orderby'], array('name', 'email', 'stage', 'created_at', 'follow_up_date')) 
            ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = $wpdb->prepare(
            "SELECT l.*, u.display_name as assigned_name
             FROM " . self::$table_name . " l
             LEFT JOIN {$wpdb->users} u ON l.assigned_to = u.ID
             WHERE $where_clause
             ORDER BY l.$orderby $order
             LIMIT %d OFFSET %d",
            array_merge($params, array($args['limit'], $args['offset']))
        );
        
        $leads = $wpdb->get_results($sql, ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_lead'), $leads);
    }
    
    /**
     * Count leads for organization
     */
    public static function count_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $where = array('organization_id = %d');
        $params = array($org_id);
        
        if (!empty($args['stage'])) {
            if (is_array($args['stage'])) {
                $placeholders = implode(',', array_fill(0, count($args['stage']), '%s'));
                $where[] = "stage IN ($placeholders)";
                $params = array_merge($params, $args['stage']);
            } else {
                $where[] = 'stage = %s';
                $params[] = $args['stage'];
            }
        }
        
        if (!empty($args['source'])) {
            $where[] = 'source = %s';
            $params[] = $args['source'];
        }
        
        $where_clause = implode(' AND ', $where);
        
        return intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE {$where_clause}",
            $params
        )));
    }
    
    /**
     * Get lead counts by stage
     */
    public static function get_stage_counts($org_id) {
        global $wpdb;
        self::init();
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT stage, COUNT(*) as count 
             FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             GROUP BY stage",
            $org_id
        ), ARRAY_A);
        
        $counts = array();
        foreach (self::get_stages() as $stage => $config) {
            $counts[$stage] = 0;
        }
        
        foreach ($results as $row) {
            $counts[$row['stage']] = intval($row['count']);
        }
        
        return $counts;
    }
    
    /**
     * Update a lead
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $lead = self::get($id);
        if (!$lead) {
            return new WP_Error('not_found', __('Lead not found', 'rental-gates'));
        }
        
        $update_data = array();
        $formats = array();
        
        $allowed_fields = array(
            'name' => '%s',
            'email' => '%s',
            'phone' => '%s',
            'stage' => '%s',
            'notes' => '%s',
            'follow_up_date' => '%s',
            'assigned_to' => '%d',
            'lost_reason' => '%s',
        );
        
        foreach ($allowed_fields as $field => $format) {
            if (isset($data[$field])) {
                if ($field === 'email') {
                    $update_data[$field] = sanitize_email($data[$field]);
                } elseif ($field === 'notes' || $field === 'lost_reason') {
                    $update_data[$field] = sanitize_textarea_field($data[$field]);
                } elseif ($field === 'assigned_to' || $field === 'follow_up_date') {
                    $update_data[$field] = $data[$field] ?: null;
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
                $formats[] = $format;
            }
        }
        
        if (empty($update_data)) {
            return $lead;
        }
        
        // Track stage change for activity
        $old_stage = $lead['stage'];
        $new_stage = $update_data['stage'] ?? $old_stage;
        
        $result = $wpdb->update(
            self::$table_name,
            $update_data,
            array('id' => $id),
            $formats,
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update lead', 'rental-gates'));
        }
        
        // Log stage change
        if ($old_stage !== $new_stage) {
            self::log_activity($id, 'stage_change', array(
                'from' => $old_stage,
                'to' => $new_stage,
            ));
            
            // Trigger marketing automation
            if (class_exists('Rental_Gates_Marketing_Automation')) {
                Rental_Gates_Marketing_Automation::process_trigger(
                    Rental_Gates_Marketing_Automation::TRIGGER_LEAD_STAGE_CHANGE,
                    $id,
                    'lead',
                    $lead['organization_id'],
                    array(
                        'lead_id' => $id,
                        'old_stage' => $old_stage,
                        'new_stage' => $new_stage,
                    )
                );
            }
        }
        
        return self::get($id);
    }
    
    /**
     * Update lead stage
     */
    public static function update_stage($id, $stage, $lost_reason = null) {
        $data = array('stage' => $stage);
        
        if ($stage === self::STAGE_LOST && $lost_reason) {
            $data['lost_reason'] = $lost_reason;
        }
        
        return self::update($id, $data);
    }
    
    /**
     * Delete a lead
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        // Delete interests first
        $wpdb->delete(self::$interests_table, array('lead_id' => $id), array('%d'));
        
        // Delete the lead
        $result = $wpdb->delete(self::$table_name, array('id' => $id), array('%d'));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to delete lead', 'rental-gates'));
        }
        
        return true;
    }
    
    /**
     * Add an interest to a lead
     */
    public static function add_interest($lead_id, $building_id = null, $unit_id = null) {
        global $wpdb;
        self::init();
        
        if (!$building_id && !$unit_id) {
            return false;
        }
        
        // Check if interest already exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$interests_table . " 
             WHERE lead_id = %d AND (building_id = %d OR building_id IS NULL) AND (unit_id = %d OR unit_id IS NULL)",
            $lead_id,
            $building_id ?: 0,
            $unit_id ?: 0
        ));
        
        if ($existing) {
            return $existing;
        }
        
        $wpdb->insert(
            self::$interests_table,
            array(
                'lead_id' => $lead_id,
                'building_id' => $building_id,
                'unit_id' => $unit_id,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%d', '%s')
        );
        
        return $wpdb->insert_id;
    }
    
    /**
     * Add multiple interests
     */
    public static function add_interests($lead_id, $interests) {
        foreach ($interests as $interest) {
            self::add_interest(
                $lead_id,
                $interest['building_id'] ?? null,
                $interest['unit_id'] ?? null
            );
        }
    }
    
    /**
     * Get interests for a lead
     */
    public static function get_interests($lead_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT li.*, b.name as building_name, u.name as unit_name
             FROM " . self::$interests_table . " li
             LEFT JOIN {$tables['buildings']} b ON li.building_id = b.id
             LEFT JOIN {$tables['units']} u ON li.unit_id = u.id
             WHERE li.lead_id = %d
             ORDER BY li.created_at DESC",
            $lead_id
        ), ARRAY_A);
    }
    
    /**
     * Remove an interest
     */
    public static function remove_interest($interest_id) {
        global $wpdb;
        self::init();
        
        return $wpdb->delete(self::$interests_table, array('id' => $interest_id), array('%d'));
    }
    
    /**
     * Log activity for a lead
     */
    public static function log_activity($lead_id, $type, $data = array()) {
        $lead = self::get($lead_id);
        if (!$lead) return;
        
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $wpdb->insert(
            $tables['activity_log'],
            array(
                'organization_id' => $lead['organization_id'],
                'user_id' => get_current_user_id() ?: null,
                'entity_type' => 'lead',
                'entity_id' => $lead_id,
                'action' => $type,
                'details' => wp_json_encode($data),
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get activity for a lead
     */
    public static function get_activity($lead_id, $limit = 20) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $activities = $wpdb->get_results($wpdb->prepare(
            "SELECT al.*, u.display_name as user_name
             FROM {$tables['activity_log']} al
             LEFT JOIN {$wpdb->users} u ON al.user_id = u.ID
             WHERE al.entity_type = 'lead' AND al.entity_id = %d
             ORDER BY al.created_at DESC
             LIMIT %d",
            $lead_id,
            $limit
        ), ARRAY_A);
        
        return array_map(function($activity) {
            if (!empty($activity['details'])) {
                $activity['details'] = json_decode($activity['details'], true);
            }
            return $activity;
        }, $activities);
    }
    
    /**
     * Add a note to lead
     */
    public static function add_note($lead_id, $note) {
        $lead = self::get($lead_id);
        if (!$lead) {
            return new WP_Error('not_found', __('Lead not found', 'rental-gates'));
        }
        
        // Append to existing notes
        $existing_notes = $lead['notes'] ?: '';
        $timestamp = current_time('M j, Y g:i a');
        $user = wp_get_current_user();
        $user_name = $user->display_name ?: __('System', 'rental-gates');
        
        $new_note = sprintf("[%s - %s]\n%s", $timestamp, $user_name, $note);
        $updated_notes = $existing_notes ? $existing_notes . "\n\n" . $new_note : $new_note;
        
        global $wpdb;
        self::init();
        
        $wpdb->update(
            self::$table_name,
            array('notes' => $updated_notes),
            array('id' => $lead_id),
            array('%s'),
            array('%d')
        );
        
        // Log activity
        self::log_activity($lead_id, 'note_added', array('note' => $note));
        
        return self::get($lead_id);
    }
    
    /**
     * Convert lead to tenant (when they sign a lease)
     */
    public static function convert_to_tenant($lead_id, $tenant_id) {
        $lead = self::get($lead_id);
        if (!$lead) {
            return new WP_Error('not_found', __('Lead not found', 'rental-gates'));
        }
        
        // Update stage to won
        self::update($lead_id, array(
            'stage' => self::STAGE_WON,
        ));
        
        // Log conversion
        self::log_activity($lead_id, 'converted', array(
            'tenant_id' => $tenant_id,
        ));
        
        return true;
    }
    
    /**
     * Get leads with follow-ups due today or overdue
     */
    public static function get_follow_ups_due($org_id) {
        return self::get_for_organization($org_id, array(
            'follow_up_due' => true,
            'stage' => array(self::STAGE_NEW, self::STAGE_CONTACTED, self::STAGE_TOURING),
            'orderby' => 'follow_up_date',
            'order' => 'ASC',
        ));
    }
    
    /**
     * Get recent leads
     */
    public static function get_recent($org_id, $limit = 10) {
        return self::get_for_organization($org_id, array(
            'limit' => $limit,
            'orderby' => 'created_at',
            'order' => 'DESC',
        ));
    }
    
    /**
     * Format a lead record
     */
    private static function format_lead($lead) {
        if (!$lead) return null;
        
        $stages = self::get_stages();
        $sources = self::get_sources();
        
        $lead['id'] = intval($lead['id']);
        $lead['organization_id'] = intval($lead['organization_id']);
        $lead['assigned_to'] = $lead['assigned_to'] ? intval($lead['assigned_to']) : null;
        $lead['source_id'] = $lead['source_id'] ? intval($lead['source_id']) : null;
        
        // Add labels
        $lead['stage_label'] = $stages[$lead['stage']]['label'] ?? $lead['stage'];
        $lead['stage_color'] = $stages[$lead['stage']]['color'] ?? '#6b7280';
        $lead['stage_bg'] = $stages[$lead['stage']]['bg'] ?? '#f3f4f6';
        $lead['source_label'] = $sources[$lead['source']] ?? $lead['source'];
        
        // Parse meta data
        if (!empty($lead['meta_data']) && is_string($lead['meta_data'])) {
            $lead['meta_data'] = json_decode($lead['meta_data'], true);
        }
        
        // Format dates
        $lead['created_at_formatted'] = date_i18n('M j, Y', strtotime($lead['created_at']));
        $lead['created_at_relative'] = human_time_diff(strtotime($lead['created_at'])) . ' ' . __('ago', 'rental-gates');
        
        if (!empty($lead['follow_up_date'])) {
            $lead['follow_up_formatted'] = date_i18n('M j, Y', strtotime($lead['follow_up_date']));
            $lead['follow_up_overdue'] = strtotime($lead['follow_up_date']) < current_time('timestamp');
        }
        
        // Get initials
        $parts = explode(' ', $lead['name']);
        $lead['initials'] = '';
        foreach ($parts as $part) {
            $lead['initials'] .= strtoupper(substr($part, 0, 1));
        }
        $lead['initials'] = substr($lead['initials'], 0, 2);
        
        return $lead;
    }
    
    /**
     * Create lead from QR scan
     */
    public static function create_from_qr_scan($org_id, $type, $entity_id, $visitor_data) {
        $source = $type === 'building' ? self::SOURCE_QR_BUILDING : self::SOURCE_QR_UNIT;
        
        $data = array(
            'organization_id' => $org_id,
            'name' => $visitor_data['name'] ?? __('QR Visitor', 'rental-gates'),
            'email' => $visitor_data['email'] ?? '',
            'phone' => $visitor_data['phone'] ?? '',
            'source' => $source,
            'source_id' => $entity_id,
            'notes' => sprintf(__('Scanned QR code for %s #%d', 'rental-gates'), $type, $entity_id),
            'meta_data' => array(
                'qr_scan' => true,
                'scan_time' => current_time('mysql'),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            ),
        );
        
        if ($type === 'building') {
            $data['building_id'] = $entity_id;
        } else {
            $data['unit_id'] = $entity_id;
        }
        
        return self::create($data);
    }
}
