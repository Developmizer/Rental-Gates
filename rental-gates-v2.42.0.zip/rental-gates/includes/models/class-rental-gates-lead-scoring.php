<?php
/**
 * Rental Gates Lead Scoring Model
 * 
 * Handles lead scoring with configurable rules, behavioral tracking,
 * and prioritization based on engagement and property interest.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Lead_Scoring {
    
    private static $table_name;
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['lead_scores'] ?? $wpdb->prefix . 'rg_lead_scores';
        }
    }
    
    /**
     * Default scoring rules
     */
    public static function get_default_rules() {
        return array(
            // Source quality
            'source_qr' => 20,
            'source_referral' => 25,
            'source_map' => 15,
            'source_profile' => 10,
            'source_manual' => 5,
            
            // Engagement
            'email_opened' => 5,
            'email_clicked' => 10,
            'website_visited' => 8,
            'property_viewed' => 12,
            'application_started' => 30,
            'application_completed' => 50,
            'tour_scheduled' => 40,
            'tour_completed' => 60,
            
            // Property interest
            'single_property_interest' => 10,
            'multiple_property_interest' => 20,
            'high_value_property' => 15,
            
            // Demographics
            'has_phone' => 5,
            'has_complete_profile' => 10,
            
            // Time-based
            'recent_activity' => 10, // Activity in last 7 days
            'response_time_fast' => 15, // Responded within 24 hours
        );
    }
    
    /**
     * Calculate score for a lead
     */
    public static function calculate_score($lead_id, $rules = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        if (!$rules) {
            $rules = self::get_default_rules();
        }
        
        $lead = Rental_Gates_Lead::get($lead_id);
        if (!$lead) {
            return new WP_Error('not_found', __('Lead not found', 'rental-gates'));
        }
        
        $score = 0;
        $breakdown = array();
        
        // Source quality scoring
        $source_key = 'source_' . $lead['source'];
        if (isset($rules[$source_key])) {
            $points = $rules[$source_key];
            $score += $points;
            $breakdown['source'] = array('points' => $points, 'reason' => sprintf(__('Source: %s', 'rental-gates'), $lead['source_label']));
        }
        
        // Demographics
        if (!empty($lead['phone'])) {
            $points = $rules['has_phone'] ?? 0;
            $score += $points;
            $breakdown['has_phone'] = array('points' => $points, 'reason' => __('Phone number provided', 'rental-gates'));
        }
        
        // Property interest
        $interests = Rental_Gates_Lead::get_interests($lead_id);
        $interest_count = count($interests);
        
        if ($interest_count > 0) {
            if ($interest_count === 1) {
                $points = $rules['single_property_interest'] ?? 0;
                $score += $points;
                $breakdown['property_interest'] = array('points' => $points, 'reason' => __('Interested in property', 'rental-gates'));
            } else {
                $points = $rules['multiple_property_interest'] ?? 0;
                $score += $points;
                $breakdown['property_interest'] = array('points' => $points, 'reason' => sprintf(__('Interested in %d properties', 'rental-gates'), $interest_count));
            }
            
            // Check for high-value properties
            foreach ($interests as $interest) {
                if (!empty($interest['unit_id'])) {
                    $unit = Rental_Gates_Unit::get($interest['unit_id']);
                    if ($unit && !empty($unit['rent_amount']) && $unit['rent_amount'] > 2000) {
                        $points = $rules['high_value_property'] ?? 0;
                        $score += $points;
                        $breakdown['high_value'] = array('points' => $points, 'reason' => __('High-value property interest', 'rental-gates'));
                        break;
                    }
                }
            }
        }
        
        // Engagement scoring (from activity log)
        $activity = Rental_Gates_Lead::get_activity($lead_id, 50);
        $recent_activity = false;
        $seven_days_ago = strtotime('-7 days');
        
        foreach ($activity as $act) {
            $act_time = strtotime($act['created_at']);
            
            // Check for recent activity
            if ($act_time >= $seven_days_ago) {
                $recent_activity = true;
            }
            
            // Score based on action type
            $action_key = 'engagement_' . $act['action'];
            if (isset($rules[$action_key])) {
                $points = $rules[$action_key];
                $score += $points;
                if (!isset($breakdown['engagement'])) {
                    $breakdown['engagement'] = array('points' => 0, 'reason' => __('Engagement activities', 'rental-gates'));
                }
                $breakdown['engagement']['points'] += $points;
            }
        }
        
        if ($recent_activity) {
            $points = $rules['recent_activity'] ?? 0;
            $score += $points;
            $breakdown['recent_activity'] = array('points' => $points, 'reason' => __('Recent activity', 'rental-gates'));
        }
        
        // Check application status
        if ($lead['stage'] === Rental_Gates_Lead::STAGE_APPLIED) {
            $points = $rules['application_completed'] ?? 0;
            $score += $points;
            $breakdown['application'] = array('points' => $points, 'reason' => __('Application submitted', 'rental-gates'));
        } elseif ($lead['stage'] === Rental_Gates_Lead::STAGE_TOURING) {
            $points = $rules['tour_scheduled'] ?? 0;
            $score += $points;
            $breakdown['tour'] = array('points' => $points, 'reason' => __('Tour scheduled', 'rental-gates'));
        }
        
        // Response time (if lead was contacted quickly)
        if (!empty($lead['created_at']) && !empty($lead['updated_at'])) {
            $created = strtotime($lead['created_at']);
            $updated = strtotime($lead['updated_at']);
            $response_time = $updated - $created;
            
            if ($response_time > 0 && $response_time <= 86400) { // Within 24 hours
                $points = $rules['response_time_fast'] ?? 0;
                $score += $points;
                $breakdown['fast_response'] = array('points' => $points, 'reason' => __('Quick response', 'rental-gates'));
            }
        }
        
        // Ensure score is non-negative
        $score = max(0, $score);
        
        // Save score
        self::save_score($lead_id, $score, $breakdown);
        
        return array(
            'lead_id' => $lead_id,
            'score' => $score,
            'breakdown' => $breakdown,
            'priority' => self::get_priority_level($score),
        );
    }
    
    /**
     * Get priority level from score
     */
    public static function get_priority_level($score) {
        if ($score >= 80) {
            return 'hot';
        } elseif ($score >= 50) {
            return 'warm';
        } elseif ($score >= 25) {
            return 'cool';
        } else {
            return 'cold';
        }
    }
    
    /**
     * Save score to database
     */
    private static function save_score($lead_id, $score, $breakdown) {
        global $wpdb;
        self::init();
        
        // Check if table exists, create if not
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            self::create_table();
        }
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . " WHERE lead_id = %d ORDER BY created_at DESC LIMIT 1",
            $lead_id
        ));
        
        $data = array(
            'lead_id' => $lead_id,
            'score' => $score,
            'breakdown' => wp_json_encode($breakdown),
            'created_at' => current_time('mysql'),
        );
        
        if ($existing) {
            $wpdb->update(
                self::$table_name,
                $data,
                array('id' => $existing),
                array('%d', '%d', '%s', '%s'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                self::$table_name,
                $data,
                array('%d', '%d', '%s', '%s')
            );
        }
        
        // Update lead meta with current score
        $lead = Rental_Gates_Lead::get($lead_id);
        if ($lead) {
            $meta_data = $lead['meta_data'] ?? array();
            if (!is_array($meta_data)) {
                $meta_data = json_decode($meta_data, true) ?: array();
            }
            $meta_data['score'] = $score;
            $meta_data['score_priority'] = self::get_priority_level($score);
            $meta_data['score_updated'] = current_time('mysql');
            
            global $wpdb;
            $tables = Rental_Gates_Database::get_table_names();
            $wpdb->update(
                $tables['leads'],
                array('meta_data' => wp_json_encode($meta_data)),
                array('id' => $lead_id),
                array('%s'),
                array('%d')
            );
        }
    }
    
    /**
     * Get score for a lead
     */
    public static function get_score($lead_id) {
        global $wpdb;
        self::init();
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            // Calculate and return
            return self::calculate_score($lead_id);
        }
        
        $score_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE lead_id = %d ORDER BY created_at DESC LIMIT 1",
            $lead_id
        ), ARRAY_A);
        
        if (!$score_data) {
            // Calculate and return
            return self::calculate_score($lead_id);
        }
        
        $breakdown = json_decode($score_data['breakdown'], true) ?: array();
        
        return array(
            'lead_id' => $lead_id,
            'score' => intval($score_data['score']),
            'breakdown' => $breakdown,
            'priority' => self::get_priority_level($score_data['score']),
            'updated_at' => $score_data['created_at'],
        );
    }
    
    /**
     * Recalculate scores for all leads in organization
     */
    public static function recalculate_all($org_id) {
        $leads = Rental_Gates_Lead::get_for_organization($org_id, array('limit' => 1000));
        
        $results = array(
            'processed' => 0,
            'updated' => 0,
            'errors' => 0,
        );
        
        foreach ($leads as $lead) {
            $result = self::calculate_score($lead['id']);
            if (is_wp_error($result)) {
                $results['errors']++;
            } else {
                $results['updated']++;
            }
            $results['processed']++;
        }
        
        return $results;
    }
    
    /**
     * Create lead_scores table
     */
    private static function create_table() {
        global $wpdb;
        self::init();
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE " . self::$table_name . " (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            lead_id bigint(20) UNSIGNED NOT NULL,
            score int(11) NOT NULL DEFAULT 0,
            breakdown longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lead_id (lead_id),
            KEY score (score),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
