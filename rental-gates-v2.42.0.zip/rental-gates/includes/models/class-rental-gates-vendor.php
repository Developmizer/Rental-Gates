<?php
/**
 * Rental Gates Vendor Model
 * 
 * Handles vendor CRUD operations and work order assignments
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Vendor {
    
    private static $table_name;
    private static $assignments_table;
    
    /**
     * Initialize table names
     */
    private static function init_tables() {
        if (!self::$table_name) {
            global $wpdb;
            self::$table_name = $wpdb->prefix . 'rg_vendors';
            self::$assignments_table = $wpdb->prefix . 'rg_work_order_vendors';
        }
    }
    
    /**
     * Service categories
     */
    public static function get_service_categories() {
        return array(
            'plumbing' => __('Plumbing', 'rental-gates'),
            'electrical' => __('Electrical', 'rental-gates'),
            'hvac' => __('HVAC', 'rental-gates'),
            'appliance' => __('Appliance Repair', 'rental-gates'),
            'structural' => __('Structural/Carpentry', 'rental-gates'),
            'pest' => __('Pest Control', 'rental-gates'),
            'cleaning' => __('Cleaning', 'rental-gates'),
            'landscaping' => __('Landscaping', 'rental-gates'),
            'painting' => __('Painting', 'rental-gates'),
            'roofing' => __('Roofing', 'rental-gates'),
            'locksmith' => __('Locksmith', 'rental-gates'),
            'general' => __('General Contractor', 'rental-gates'),
            'other' => __('Other', 'rental-gates'),
        );
    }
    
    /**
     * Get status labels
     */
    public static function get_status_labels() {
        return array(
            'active' => __('Active', 'rental-gates'),
            'paused' => __('Paused', 'rental-gates'),
            'inactive' => __('Inactive', 'rental-gates'),
        );
    }
    
    /**
     * Create a new vendor
     */
    public static function create($data) {
        self::init_tables();
        global $wpdb;
        
        $defaults = array(
            'organization_id' => 0,
            'user_id' => null,
            'company_name' => '',
            'contact_name' => '',
            'email' => '',
            'phone' => '',
            'service_categories' => array(),
            'service_buildings' => array(),
            'hourly_rate' => null,
            'notes' => '',
            'status' => 'active',
            'stripe_account_id' => null,
            'stripe_status' => 'not_connected',
            'meta_data' => array(),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['company_name']) || empty($data['contact_name']) || empty($data['email']) || empty($data['phone'])) {
            return new WP_Error('missing_required', __('Missing required fields', 'rental-gates'));
        }
        
        // Validate email
        if (!is_email($data['email'])) {
            return new WP_Error('invalid_email', __('Invalid email address', 'rental-gates'));
        }
        
        // Check for duplicate email in same org
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . " WHERE organization_id = %d AND email = %s",
            $data['organization_id'],
            $data['email']
        ));
        
        if ($existing) {
            return new WP_Error('duplicate_email', __('A vendor with this email already exists', 'rental-gates'));
        }
        
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'user_id' => $data['user_id'] ? intval($data['user_id']) : null,
            'company_name' => sanitize_text_field($data['company_name']),
            'contact_name' => sanitize_text_field($data['contact_name']),
            'email' => sanitize_email($data['email']),
            'phone' => sanitize_text_field($data['phone']),
            'service_categories' => is_array($data['service_categories']) ? json_encode($data['service_categories']) : $data['service_categories'],
            'service_buildings' => is_array($data['service_buildings']) ? json_encode($data['service_buildings']) : $data['service_buildings'],
            'hourly_rate' => $data['hourly_rate'] ? floatval($data['hourly_rate']) : null,
            'notes' => sanitize_textarea_field($data['notes']),
            'status' => in_array($data['status'], array('active', 'paused', 'inactive')) ? $data['status'] : 'active',
            'stripe_account_id' => $data['stripe_account_id'] ? sanitize_text_field($data['stripe_account_id']) : null,
            'stripe_status' => in_array($data['stripe_status'], array('not_connected', 'pending', 'ready')) ? $data['stripe_status'] : 'not_connected',
            'meta_data' => is_array($data['meta_data']) ? json_encode($data['meta_data']) : $data['meta_data'],
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create vendor', 'rental-gates'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get vendor by ID
     */
    public static function get($id) {
        self::init_tables();
        global $wpdb;
        
        $vendor = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if ($vendor) {
            $vendor = self::format_vendor($vendor);
        }
        
        return $vendor;
    }
    
    /**
     * Get vendor with work order stats
     */
    public static function get_with_stats($id) {
        self::init_tables();
        global $wpdb;
        
        $tables = Rental_Gates_Database::get_table_names();
        
        $vendor = $wpdb->get_row($wpdb->prepare(
            "SELECT v.*,
                    (SELECT COUNT(*) FROM {$tables['work_order_vendors']} wov WHERE wov.vendor_id = v.id) as total_assignments,
                    (SELECT COUNT(*) FROM {$tables['work_order_vendors']} wov WHERE wov.vendor_id = v.id AND wov.status = 'completed') as completed_jobs,
                    (SELECT COUNT(*) FROM {$tables['work_order_vendors']} wov WHERE wov.vendor_id = v.id AND wov.status IN ('assigned', 'accepted')) as active_jobs,
                    (SELECT SUM(wov.cost) FROM {$tables['work_order_vendors']} wov WHERE wov.vendor_id = v.id AND wov.status = 'completed') as total_earnings
             FROM " . self::$table_name . " v
             WHERE v.id = %d",
            $id
        ), ARRAY_A);
        
        if ($vendor) {
            $vendor = self::format_vendor($vendor);
        }
        
        return $vendor;
    }
    
    /**
     * Get vendors for organization
     */
    public static function get_for_organization($organization_id, $args = array()) {
        self::init_tables();
        global $wpdb;
        
        $defaults = array(
            'status' => null,
            'category' => null,
            'building_id' => null,
            'search' => null,
            'per_page' => 20,
            'page' => 1,
            'orderby' => 'company_name',
            'order' => 'ASC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array("organization_id = %d");
        $params = array($organization_id);
        
        if ($args['status']) {
            $where[] = "status = %s";
            $params[] = $args['status'];
        }
        
        if ($args['category']) {
            $where[] = "service_categories LIKE %s";
            $params[] = '%"' . $args['category'] . '"%';
        }
        
        if ($args['building_id']) {
            $where[] = "(service_buildings IS NULL OR service_buildings = '[]' OR service_buildings LIKE %s)";
            $params[] = '%' . intval($args['building_id']) . '%';
        }
        
        if ($args['search']) {
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = "(company_name LIKE %s OR contact_name LIKE %s OR email LIKE %s OR phone LIKE %s)";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Get total count
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE " . $where_clause,
            ...$params
        ));
        
        // Order
        $allowed_orderby = array('company_name', 'contact_name', 'email', 'status', 'created_at', 'hourly_rate');
        $orderby = in_array($args['orderby'], $allowed_orderby) ? $args['orderby'] : 'company_name';
        $order = strtoupper($args['order']) === 'DESC' ? 'DESC' : 'ASC';
        
        // Pagination
        $per_page = max(1, intval($args['per_page']));
        $page = max(1, intval($args['page']));
        $offset = ($page - 1) * $per_page;
        
        $params[] = $per_page;
        $params[] = $offset;
        
        $vendors = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " 
             WHERE " . $where_clause . " 
             ORDER BY {$orderby} {$order} 
             LIMIT %d OFFSET %d",
            ...$params
        ), ARRAY_A);
        
        $vendors = array_map(array(__CLASS__, 'format_vendor'), $vendors);
        
        return array(
            'items' => $vendors,
            'total' => intval($total),
            'pages' => ceil($total / $per_page),
            'page' => $page,
            'per_page' => $per_page,
        );
    }
    
    /**
     * Get vendors by category (for work order assignment)
     */
    public static function get_by_category($organization_id, $category, $building_id = null) {
        self::init_tables();
        global $wpdb;
        
        $where = array("organization_id = %d", "status = 'active'");
        $params = array($organization_id);
        
        if ($category) {
            $where[] = "service_categories LIKE %s";
            $params[] = '%"' . $category . '"%';
        }
        
        if ($building_id) {
            // Include vendors with no building restriction OR vendors that service this building
            $where[] = "(service_buildings IS NULL OR service_buildings = '[]' OR service_buildings LIKE %s)";
            $params[] = '%' . intval($building_id) . '%';
        }
        
        $where_clause = implode(' AND ', $where);
        
        $vendors = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE " . $where_clause . " ORDER BY company_name ASC",
            ...$params
        ), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_vendor'), $vendors);
    }
    
    /**
     * Count vendors for organization
     */
    public static function count_for_organization($organization_id, $status = null) {
        self::init_tables();
        global $wpdb;
        
        if ($status) {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d AND status = %s",
                $organization_id,
                $status
            ));
        }
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d",
            $organization_id
        ));
    }
    
    /**
     * Update vendor
     */
    public static function update($id, $data) {
        self::init_tables();
        global $wpdb;
        
        $vendor = self::get($id);
        if (!$vendor) {
            return new WP_Error('not_found', __('Vendor not found', 'rental-gates'));
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'company_name', 'contact_name', 'email', 'phone', 'service_categories',
            'service_buildings', 'hourly_rate', 'notes', 'status', 'stripe_account_id',
            'stripe_status', 'meta_data', 'user_id'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'email':
                        if (!is_email($data[$field])) {
                            return new WP_Error('invalid_email', __('Invalid email address', 'rental-gates'));
                        }
                        // Check for duplicate (excluding current)
                        $existing = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM " . self::$table_name . " WHERE organization_id = %d AND email = %s AND id != %d",
                            $vendor['organization_id'],
                            $data[$field],
                            $id
                        ));
                        if ($existing) {
                            return new WP_Error('duplicate_email', __('A vendor with this email already exists', 'rental-gates'));
                        }
                        $update_data[$field] = sanitize_email($data[$field]);
                        break;
                        
                    case 'service_categories':
                    case 'service_buildings':
                    case 'meta_data':
                        $update_data[$field] = is_array($data[$field]) ? json_encode($data[$field]) : $data[$field];
                        break;
                        
                    case 'hourly_rate':
                        $update_data[$field] = $data[$field] !== '' ? floatval($data[$field]) : null;
                        break;
                        
                    case 'status':
                        if (in_array($data[$field], array('active', 'paused', 'inactive'))) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                        
                    case 'stripe_status':
                        if (in_array($data[$field], array('not_connected', 'pending', 'ready'))) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                        
                    case 'user_id':
                        $update_data[$field] = $data[$field] ? intval($data[$field]) : null;
                        break;
                        
                    case 'notes':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                        
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return true;
        }
        
        $result = $wpdb->update(
            self::$table_name,
            $update_data,
            array('id' => $id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update vendor', 'rental-gates'));
        }
        
        return true;
    }
    
    /**
     * Delete vendor
     */
    public static function delete($id) {
        self::init_tables();
        global $wpdb;
        
        $vendor = self::get($id);
        if (!$vendor) {
            return new WP_Error('not_found', __('Vendor not found', 'rental-gates'));
        }
        
        // Check for active assignments
        $active_assignments = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$assignments_table . " WHERE vendor_id = %d AND status IN ('assigned', 'accepted')",
            $id
        ));
        
        if ($active_assignments > 0) {
            return new WP_Error('has_assignments', __('Cannot delete vendor with active work order assignments', 'rental-gates'));
        }
        
        // Delete assignment history
        $wpdb->delete(self::$assignments_table, array('vendor_id' => $id));
        
        // Delete vendor
        $result = $wpdb->delete(self::$table_name, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to delete vendor', 'rental-gates'));
        }
        
        return true;
    }
    
    /**
     * Assign vendor to work order
     */
    public static function assign_to_work_order($vendor_id, $work_order_id, $notes = '') {
        self::init_tables();
        global $wpdb;
        
        // Check if already assigned
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$assignments_table . " WHERE vendor_id = %d AND work_order_id = %d AND status NOT IN ('declined', 'completed')",
            $vendor_id,
            $work_order_id
        ));
        
        if ($existing) {
            return new WP_Error('already_assigned', __('Vendor is already assigned to this work order', 'rental-gates'));
        }
        
        $result = $wpdb->insert(
            self::$assignments_table,
            array(
                'vendor_id' => intval($vendor_id),
                'work_order_id' => intval($work_order_id),
                'status' => 'assigned',
                'notes' => sanitize_textarea_field($notes),
                'assigned_at' => current_time('mysql'),
            )
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to assign vendor', 'rental-gates'));
        }
        
        // Update work order status to 'assigned' if it was 'open'
        $tables = Rental_Gates_Database::get_table_names();
        $wpdb->query($wpdb->prepare(
            "UPDATE {$tables['work_orders']} SET status = 'assigned' WHERE id = %d AND status = 'open'",
            $work_order_id
        ));
        
        return $wpdb->insert_id;
    }
    
    /**
     * Update assignment status
     */
    public static function update_assignment_status($assignment_id, $status, $cost = null) {
        self::init_tables();
        global $wpdb;
        
        $allowed_statuses = array('assigned', 'accepted', 'declined', 'completed');
        if (!in_array($status, $allowed_statuses)) {
            return new WP_Error('invalid_status', __('Invalid assignment status', 'rental-gates'));
        }
        
        $update_data = array('status' => $status);
        
        if ($status === 'accepted') {
            $update_data['accepted_at'] = current_time('mysql');
        } elseif ($status === 'completed') {
            $update_data['completed_at'] = current_time('mysql');
            if ($cost !== null) {
                $update_data['cost'] = floatval($cost);
            }
        }
        
        $result = $wpdb->update(
            self::$assignments_table,
            $update_data,
            array('id' => $assignment_id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update assignment', 'rental-gates'));
        }
        
        return true;
    }
    
    /**
     * Remove vendor from work order
     */
    public static function remove_from_work_order($vendor_id, $work_order_id) {
        self::init_tables();
        global $wpdb;
        
        $result = $wpdb->delete(
            self::$assignments_table,
            array(
                'vendor_id' => intval($vendor_id),
                'work_order_id' => intval($work_order_id),
            )
        );
        
        return $result !== false;
    }
    
    /**
     * Get assignments for vendor
     */
    public static function get_assignments($vendor_id, $status = null, $limit = 20) {
        self::init_tables();
        global $wpdb;
        
        $tables = Rental_Gates_Database::get_table_names();
        
        $where = "wov.vendor_id = %d";
        $params = array($vendor_id);
        
        if ($status) {
            $where .= " AND wov.status = %s";
            $params[] = $status;
        }
        
        $params[] = $limit;
        
        $assignments = $wpdb->get_results($wpdb->prepare(
            "SELECT wov.*, 
                    wo.title as work_order_title, wo.category as work_order_category,
                    wo.priority as work_order_priority, wo.status as work_order_status,
                    b.name as building_name, u.name as unit_name
             FROM " . self::$assignments_table . " wov
             LEFT JOIN {$tables['work_orders']} wo ON wov.work_order_id = wo.id
             LEFT JOIN {$tables['buildings']} b ON wo.building_id = b.id
             LEFT JOIN {$tables['units']} u ON wo.unit_id = u.id
             WHERE {$where}
             ORDER BY wov.assigned_at DESC
             LIMIT %d",
            ...$params
        ), ARRAY_A);
        
        return $assignments;
    }
    
    /**
     * Get stats for organization
     */
    public static function get_stats($organization_id) {
        self::init_tables();
        global $wpdb;
        
        $tables = Rental_Gates_Database::get_table_names();
        
        $stats = array(
            'total' => 0,
            'active' => 0,
            'paused' => 0,
            'inactive' => 0,
            'with_active_jobs' => 0,
        );
        
        // Basic counts
        $counts = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM " . self::$table_name . " WHERE organization_id = %d GROUP BY status",
            $organization_id
        ), ARRAY_A);
        
        foreach ($counts as $row) {
            $stats[$row['status']] = intval($row['count']);
            $stats['total'] += intval($row['count']);
        }
        
        // Vendors with active jobs
        $stats['with_active_jobs'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT v.id) 
             FROM " . self::$table_name . " v
             INNER JOIN " . self::$assignments_table . " wov ON v.id = wov.vendor_id
             WHERE v.organization_id = %d AND wov.status IN ('assigned', 'accepted')",
            $organization_id
        ));
        
        return $stats;
    }
    
    /**
     * Format vendor data
     */
    private static function format_vendor($vendor) {
        if (!$vendor) {
            return null;
        }
        
        // Decode JSON fields
        $vendor['service_categories'] = $vendor['service_categories'] ? json_decode($vendor['service_categories'], true) : array();
        $vendor['service_buildings'] = $vendor['service_buildings'] ? json_decode($vendor['service_buildings'], true) : array();
        $vendor['meta_data'] = $vendor['meta_data'] ? json_decode($vendor['meta_data'], true) : array();
        
        // Ensure arrays
        if (!is_array($vendor['service_categories'])) {
            $vendor['service_categories'] = array();
        }
        if (!is_array($vendor['service_buildings'])) {
            $vendor['service_buildings'] = array();
        }
        if (!is_array($vendor['meta_data'])) {
            $vendor['meta_data'] = array();
        }
        
        // Add labels
        $categories = self::get_service_categories();
        $vendor['service_categories_labels'] = array();
        foreach ($vendor['service_categories'] as $cat) {
            if (isset($categories[$cat])) {
                $vendor['service_categories_labels'][$cat] = $categories[$cat];
            }
        }
        
        $statuses = self::get_status_labels();
        $vendor['status_label'] = isset($statuses[$vendor['status']]) ? $statuses[$vendor['status']] : $vendor['status'];
        
        // Cast numeric fields
        $vendor['id'] = intval($vendor['id']);
        $vendor['organization_id'] = intval($vendor['organization_id']);
        $vendor['user_id'] = $vendor['user_id'] ? intval($vendor['user_id']) : null;
        $vendor['hourly_rate'] = $vendor['hourly_rate'] !== null ? floatval($vendor['hourly_rate']) : null;
        
        // Stats if present
        if (isset($vendor['total_assignments'])) {
            $vendor['total_assignments'] = intval($vendor['total_assignments']);
        }
        if (isset($vendor['completed_jobs'])) {
            $vendor['completed_jobs'] = intval($vendor['completed_jobs']);
        }
        if (isset($vendor['active_jobs'])) {
            $vendor['active_jobs'] = intval($vendor['active_jobs']);
        }
        if (isset($vendor['total_earnings'])) {
            $vendor['total_earnings'] = floatval($vendor['total_earnings'] ?: 0);
        }
        
        return $vendor;
    }
    
    /**
     * Link vendor to WordPress user
     */
    public static function link_to_user($vendor_id, $user_id) {
        global $wpdb;
        self::init_tables();
        
        $vendor = self::get($vendor_id);
        if (!$vendor) {
            return new WP_Error('not_found', __('Vendor not found', 'rental-gates'));
        }
        
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return new WP_Error('user_not_found', __('User not found', 'rental-gates'));
        }
        
        // Update vendor with user ID
        $result = $wpdb->update(
            self::$table_name,
            array('user_id' => $user_id, 'updated_at' => current_time('mysql')),
            array('id' => $vendor_id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error linking vendor to user', 'rental-gates'));
        }
        
        // Add vendor role to user
        $user->add_role('rental_gates_vendor');
        
        // Store organization association
        update_user_meta($user_id, 'rental_gates_vendor_id', $vendor_id);
        update_user_meta($user_id, 'rental_gates_organization_id', $vendor['organization_id']);
        
        return self::get($vendor_id);
    }
    
    /**
     * Create WordPress user for vendor and send invitation
     */
    public static function invite_to_portal($vendor_id) {
        global $wpdb;
        self::init_tables();
        
        $vendor = self::get($vendor_id);
        if (!$vendor) {
            return new WP_Error('not_found', __('Vendor not found', 'rental-gates'));
        }
        
        // Check if already has user
        if ($vendor['user_id']) {
            return new WP_Error('already_linked', __('Vendor already has portal access', 'rental-gates'));
        }
        
        // Check if user with this email already exists
        $existing_user = get_user_by('email', $vendor['contact_email']);
        if ($existing_user) {
            // Link existing user
            return self::link_to_user($vendor_id, $existing_user->ID);
        }
        
        // Create new user
        $username = sanitize_user(strtolower(str_replace(' ', '.', $vendor['contact_name'])));
        $username = self::generate_unique_username($username);
        $password = wp_generate_password(12, true);
        
        $user_id = wp_create_user($username, $password, $vendor['contact_email']);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        // Update user info
        $name_parts = explode(' ', $vendor['contact_name'], 2);
        wp_update_user(array(
            'ID' => $user_id,
            'first_name' => $name_parts[0] ?? '',
            'last_name' => $name_parts[1] ?? '',
            'display_name' => $vendor['contact_name'],
        ));
        
        // Link vendor to user
        $result = self::link_to_user($vendor_id, $user_id);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Send invitation email
        $organization = Rental_Gates_Organization::get($vendor['organization_id']);
        $login_url = home_url('/rental-gates/login');
        
        $subject = sprintf(__('Welcome to %s Vendor Portal', 'rental-gates'), $organization['name']);
        $message = sprintf(
            __("Hello %s,\n\nYou've been invited to access the vendor portal for %s.\n\nAs a vendor, you'll be able to:\n- View and manage assigned work orders\n- Accept or decline assignments\n- Mark work orders as complete\n- Track your work history\n\nLogin URL: %s\nUsername: %s\nPassword: %s\n\nPlease change your password after logging in.\n\nBest regards,\n%s", 'rental-gates'),
            $vendor['contact_name'],
            $organization['name'],
            $login_url,
            $username,
            $password,
            $organization['name']
        );
        
        wp_mail($vendor['contact_email'], $subject, $message);
        
        return self::get($vendor_id);
    }
    
    /**
     * Generate unique username
     */
    private static function generate_unique_username($username) {
        $username = sanitize_user($username, true);
        if (empty($username)) {
            $username = 'vendor';
        }
        
        $original = $username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $original . $counter;
            $counter++;
        }
        
        return $username;
    }
}
