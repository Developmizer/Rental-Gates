<?php
/**
 * Rental Gates Notification Model
 * 
 * Handles in-app notifications, email preferences, and notification management.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Notification {
    
    private static $table_name;
    private static $prefs_table;
    
    /**
     * Notification types
     */
    const TYPES = array(
        // Lease notifications
        'lease_created' => 'Lease Created',
        'lease_activated' => 'Lease Activated',
        'lease_expiring' => 'Lease Expiring Soon',
        'lease_expired' => 'Lease Expired',
        'lease_renewed' => 'Lease Renewed',
        'lease_terminated' => 'Lease Terminated',
        
        // Payment notifications
        'payment_due' => 'Payment Due',
        'payment_reminder' => 'Payment Reminder',
        'payment_overdue' => 'Payment Overdue',
        'payment_received' => 'Payment Received',
        'late_fee_added' => 'Late Fee Added',
        
        // Maintenance notifications
        'maintenance_created' => 'Maintenance Request Created',
        'maintenance_assigned' => 'Maintenance Assigned',
        'maintenance_updated' => 'Maintenance Updated',
        'maintenance_completed' => 'Maintenance Completed',
        
        // Application notifications
        'application_received' => 'Application Received',
        'application_approved' => 'Application Approved',
        'application_declined' => 'Application Declined',
        
        // Tenant notifications
        'tenant_invited' => 'Tenant Portal Invitation',
        'tenant_move_in' => 'Move-In Reminder',
        'tenant_move_out' => 'Move-Out Reminder',
        
        // Vendor notifications
        'vendor_assigned' => 'Work Order Assigned',
        'vendor_invitation' => 'Vendor Portal Invitation',
        
        // System notifications
        'announcement' => 'Announcement',
        'system_alert' => 'System Alert',
    );
    
    /**
     * Initialize tables
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['notifications'];
            self::$prefs_table = $tables['notification_preferences'];
        }
    }
    
    /**
     * Create notification
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'user_id' => 0,
            'organization_id' => null,
            'type' => 'system_alert',
            'title' => '',
            'message' => '',
            'action_url' => '',
            'is_read' => 0,
            'meta_data' => array(),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        if (empty($data['user_id']) || empty($data['title'])) {
            return new WP_Error('missing_required', __('User ID and title are required', 'rental-gates'));
        }
        
        $result = $wpdb->insert(
            self::$table_name,
            array(
                'user_id' => intval($data['user_id']),
                'organization_id' => $data['organization_id'] ? intval($data['organization_id']) : null,
                'type' => sanitize_key($data['type']),
                'title' => sanitize_text_field($data['title']),
                'message' => wp_kses_post($data['message']),
                'action_url' => esc_url_raw($data['action_url']),
                'is_read' => 0,
                'meta_data' => is_array($data['meta_data']) ? json_encode($data['meta_data']) : $data['meta_data'],
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating notification', 'rental-gates'));
        }
        
        return self::get($wpdb->insert_id);
    }
    
    /**
     * Get notification by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $notification = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        return $notification ? self::format_notification($notification) : null;
    }
    
    /**
     * Get notifications for user
     */
    public static function get_for_user($user_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'is_read' => null,
            'type' => null,
            'limit' => 20,
            'offset' => 0,
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('user_id = %d');
        $params = array($user_id);
        
        if ($args['is_read'] !== null) {
            $where[] = 'is_read = %d';
            $params[] = intval($args['is_read']);
        }
        
        if ($args['type']) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY created_at {$order} 
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $notifications = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_notification'), $notifications);
    }
    
    /**
     * Get unread count for user
     */
    public static function get_unread_count($user_id) {
        global $wpdb;
        self::init();
        
        return intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE user_id = %d AND is_read = 0",
            $user_id
        )));
    }
    
    /**
     * Mark notification as read
     */
    public static function mark_read($id, $user_id = null) {
        global $wpdb;
        self::init();
        
        $where = array('id' => $id);
        if ($user_id) {
            $where['user_id'] = $user_id;
        }
        
        return $wpdb->update(
            self::$table_name,
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            $where,
            array('%d', '%s'),
            array('%d', '%d')
        ) !== false;
    }
    
    /**
     * Mark all notifications as read for user
     */
    public static function mark_all_read($user_id) {
        global $wpdb;
        self::init();
        
        return $wpdb->update(
            self::$table_name,
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            array('user_id' => $user_id, 'is_read' => 0),
            array('%d', '%s'),
            array('%d', '%d')
        ) !== false;
    }
    
    /**
     * Delete notification
     */
    public static function delete($id, $user_id = null) {
        global $wpdb;
        self::init();
        
        $where = array('id' => $id);
        if ($user_id) {
            $where['user_id'] = $user_id;
        }
        
        return $wpdb->delete(self::$table_name, $where, array('%d', '%d')) !== false;
    }
    
    /**
     * Delete old notifications
     */
    public static function cleanup($days = 90) {
        global $wpdb;
        self::init();
        
        return $wpdb->query($wpdb->prepare(
            "DELETE FROM " . self::$table_name . " WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
    
    /**
     * Get user notification preferences
     */
    public static function get_preferences($user_id) {
        global $wpdb;
        self::init();
        
        $prefs = $wpdb->get_results($wpdb->prepare(
            "SELECT notification_type, channel, frequency FROM " . self::$prefs_table . " WHERE user_id = %d",
            $user_id
        ), ARRAY_A);
        
        $preferences = array();
        foreach ($prefs as $pref) {
            $preferences[$pref['notification_type']] = array(
                'channel' => $pref['channel'],
                'frequency' => $pref['frequency'],
            );
        }
        
        // Fill in defaults
        foreach (self::TYPES as $type => $label) {
            if (!isset($preferences[$type])) {
                $preferences[$type] = array(
                    'channel' => 'both',
                    'frequency' => 'immediate',
                );
            }
        }
        
        return $preferences;
    }
    
    /**
     * Update user notification preference
     */
    public static function update_preference($user_id, $type, $channel = 'both', $frequency = 'immediate') {
        global $wpdb;
        self::init();
        
        // Validate channel
        $valid_channels = array('in_app', 'email', 'both', 'none');
        if (!in_array($channel, $valid_channels)) {
            $channel = 'both';
        }
        
        // Validate frequency
        $valid_frequencies = array('immediate', 'daily', 'weekly');
        if (!in_array($frequency, $valid_frequencies)) {
            $frequency = 'immediate';
        }
        
        // Upsert
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$prefs_table . " WHERE user_id = %d AND notification_type = %s",
            $user_id, $type
        ));
        
        if ($existing) {
            return $wpdb->update(
                self::$prefs_table,
                array('channel' => $channel, 'frequency' => $frequency),
                array('id' => $existing),
                array('%s', '%s'),
                array('%d')
            ) !== false;
        } else {
            return $wpdb->insert(
                self::$prefs_table,
                array(
                    'user_id' => $user_id,
                    'notification_type' => $type,
                    'channel' => $channel,
                    'frequency' => $frequency,
                ),
                array('%d', '%s', '%s', '%s')
            ) !== false;
        }
    }
    
    /**
     * Send notification (creates in-app and optionally sends email)
     */
    public static function send($user_id, $type, $title, $message, $action_url = '', $meta_data = array()) {
        // Get user preferences
        $prefs = self::get_preferences($user_id);
        $pref = $prefs[$type] ?? array('channel' => 'both', 'frequency' => 'immediate');
        
        // Get organization ID if available
        $org_id = null;
        if (!empty($meta_data['organization_id'])) {
            $org_id = $meta_data['organization_id'];
        } else {
            $org_id = Rental_Gates_Roles::get_organization_id($user_id);
        }
        
        $result = array('in_app' => false, 'email' => false);
        
        // Create in-app notification
        if (in_array($pref['channel'], array('in_app', 'both'))) {
            $notification = self::create(array(
                'user_id' => $user_id,
                'organization_id' => $org_id,
                'type' => $type,
                'title' => $title,
                'message' => $message,
                'action_url' => $action_url,
                'meta_data' => $meta_data,
            ));
            
            $result['in_app'] = !is_wp_error($notification);
        }
        
        // Send email
        if (in_array($pref['channel'], array('email', 'both'))) {
            $user = get_user_by('ID', $user_id);
            if ($user && $user->user_email) {
                // Get organization data for email template
                $org_data = array();
                if ($org_id) {
                    $org = Rental_Gates_Organization::get($org_id);
                    if ($org) {
                        $org_data = array(
                            'organization_name' => $org['name'],
                            'organization_id' => $org_id,
                        );
                    }
                }
                
                $email_data = array_merge($org_data, array(
                    'user_name' => $user->display_name,
                    'message' => $message,
                    'action_url' => $action_url,
                    'action_text' => __('View Details', 'rental-gates'),
                ), $meta_data);
                
                // Map notification type to email template
                $email_template = self::get_email_template($type);
                $result['email'] = Rental_Gates_Email::send($user->user_email, $email_template, $email_data);
            }
        }
        
        return $result;
    }
    
    /**
     * Send notification to multiple users
     */
    public static function send_bulk($user_ids, $type, $title, $message, $action_url = '', $meta_data = array()) {
        $results = array();
        
        foreach ($user_ids as $user_id) {
            $results[$user_id] = self::send($user_id, $type, $title, $message, $action_url, $meta_data);
        }
        
        return $results;
    }
    
    /**
     * Get email template for notification type
     */
    private static function get_email_template($type) {
        $mapping = array(
            'lease_created' => 'lease_created',
            'lease_expiring' => 'lease_ending',
            'lease_renewed' => 'renewal_offer',
            'payment_due' => 'payment_reminder',
            'payment_reminder' => 'payment_reminder',
            'payment_overdue' => 'payment_overdue',
            'payment_received' => 'payment_receipt',
            'maintenance_created' => 'maintenance_created',
            'maintenance_updated' => 'maintenance_update',
            'maintenance_completed' => 'maintenance_completed',
            'application_received' => 'application_received',
            'application_approved' => 'application_approved',
            'application_declined' => 'application_declined',
            'vendor_assigned' => 'vendor_assignment',
            'tenant_invited' => 'tenant_invitation',
            'announcement' => 'announcement',
        );
        
        return $mapping[$type] ?? 'generic';
    }
    
    /**
     * Format notification data
     */
    private static function format_notification($notification) {
        if (!$notification) return null;
        
        $notification['id'] = intval($notification['id']);
        $notification['user_id'] = intval($notification['user_id']);
        $notification['organization_id'] = $notification['organization_id'] ? intval($notification['organization_id']) : null;
        $notification['is_read'] = (bool) $notification['is_read'];
        
        // Type label
        $notification['type_label'] = self::TYPES[$notification['type']] ?? $notification['type'];
        
        // Parse meta data
        if (!empty($notification['meta_data'])) {
            $notification['meta_data'] = json_decode($notification['meta_data'], true) ?: array();
        } else {
            $notification['meta_data'] = array();
        }
        
        // Time ago
        $notification['time_ago'] = human_time_diff(strtotime($notification['created_at']), current_time('timestamp')) . ' ' . __('ago', 'rental-gates');
        
        return $notification;
    }
}
