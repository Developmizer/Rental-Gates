<?php
/**
 * Rental Gates Message Model
 * Handles messaging between staff, tenants, and vendors
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Message {
    
    /**
     * Get or create a thread between two participants
     */
    public static function get_or_create_thread($org_id, $participant_1_id, $participant_1_type, $participant_2_id, $participant_2_type, $work_order_id = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Normalize order for consistent lookup
        if ($participant_1_id > $participant_2_id) {
            list($participant_1_id, $participant_2_id) = array($participant_2_id, $participant_1_id);
            list($participant_1_type, $participant_2_type) = array($participant_2_type, $participant_1_type);
        }
        
        // Check for existing thread
        $thread = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['message_threads']}
             WHERE organization_id = %d
               AND participant_1_id = %d AND participant_1_type = %s
               AND participant_2_id = %d AND participant_2_type = %s
               AND (work_order_id = %d OR (work_order_id IS NULL AND %d IS NULL))",
            $org_id,
            $participant_1_id, $participant_1_type,
            $participant_2_id, $participant_2_type,
            $work_order_id, $work_order_id
        ), ARRAY_A);
        
        if ($thread) {
            return $thread;
        }
        
        // Create new thread
        $wpdb->insert(
            $tables['message_threads'],
            array(
                'organization_id' => $org_id,
                'participant_1_id' => $participant_1_id,
                'participant_1_type' => $participant_1_type,
                'participant_2_id' => $participant_2_id,
                'participant_2_type' => $participant_2_type,
                'work_order_id' => $work_order_id,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%d', '%s')
        );
        
        return self::get_thread($wpdb->insert_id);
    }
    
    /**
     * Get a thread by ID
     */
    public static function get_thread($thread_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['message_threads']} WHERE id = %d",
            $thread_id
        ), ARRAY_A);
    }
    
    /**
     * Get threads for a user
     */
    public static function get_user_threads($org_id, $user_id, $user_type, $limit = 50, $offset = 0) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $threads = $wpdb->get_results($wpdb->prepare(
            "SELECT t.*, 
                    (SELECT COUNT(*) FROM {$tables['messages']} m 
                     WHERE m.thread_id = t.id AND m.read_at IS NULL 
                     AND NOT (m.sender_id = %d AND m.sender_type = %s)) as unread_count
             FROM {$tables['message_threads']} t
             WHERE t.organization_id = %d
               AND ((t.participant_1_id = %d AND t.participant_1_type = %s)
                    OR (t.participant_2_id = %d AND t.participant_2_type = %s))
             ORDER BY COALESCE(t.last_message_at, t.created_at) DESC
             LIMIT %d OFFSET %d",
            $user_id, $user_type,
            $org_id,
            $user_id, $user_type,
            $user_id, $user_type,
            $limit, $offset
        ), ARRAY_A);
        
        // Enrich with participant details and last message
        foreach ($threads as &$thread) {
            $thread = self::enrich_thread($thread, $user_id, $user_type);
        }
        
        return $threads;
    }
    
    /**
     * Enrich thread with participant details
     */
    private static function enrich_thread($thread, $current_user_id, $current_user_type) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Determine the "other" participant
        if ($thread['participant_1_id'] == $current_user_id && $thread['participant_1_type'] == $current_user_type) {
            $other_id = $thread['participant_2_id'];
            $other_type = $thread['participant_2_type'];
        } else {
            $other_id = $thread['participant_1_id'];
            $other_type = $thread['participant_1_type'];
        }
        
        // Get participant details
        $thread['other_participant'] = self::get_participant_info($other_id, $other_type);
        
        // Get last message - keep as object for owner template compatibility
        $thread['last_message'] = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['messages']} WHERE thread_id = %d ORDER BY created_at DESC LIMIT 1",
            $thread['id']
        ), ARRAY_A);
        
        // Also provide text-only version for tenant template
        $thread['last_message_text'] = $thread['last_message']['message'] ?? '';
        
        return $thread;
    }
    
    /**
     * Get participant info by type
     */
    public static function get_participant_info($user_id, $user_type) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        switch ($user_type) {
            case 'staff':
                $user = get_userdata($user_id);
                if ($user) {
                    return array(
                        'id' => $user_id,
                        'type' => 'staff',
                        'name' => $user->display_name,
                        'email' => $user->user_email,
                        'avatar' => get_avatar_url($user_id, array('size' => 96)),
                    );
                }
                break;
                
            case 'tenant':
                $tenant = $wpdb->get_row($wpdb->prepare(
                    "SELECT t.*, u.display_name, u.user_email
                     FROM {$tables['tenants']} t
                     LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
                     WHERE t.id = %d",
                    $user_id
                ), ARRAY_A);
                if ($tenant) {
                    return array(
                        'id' => $user_id,
                        'type' => 'tenant',
                        'name' => $tenant['display_name'] ?? ($tenant['first_name'] . ' ' . $tenant['last_name']),
                        'email' => $tenant['user_email'] ?? $tenant['email'],
                        'avatar' => get_avatar_url($tenant['user_id'] ?? 0, array('size' => 96)),
                    );
                }
                break;
                
            case 'vendor':
                $vendor = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$tables['vendors']} WHERE id = %d",
                    $user_id
                ), ARRAY_A);
                if ($vendor) {
                    return array(
                        'id' => $user_id,
                        'type' => 'vendor',
                        'name' => $vendor['company_name'],
                        'email' => $vendor['email'],
                        'avatar' => null,
                    );
                }
                break;
        }
        
        return array(
            'id' => $user_id,
            'type' => $user_type,
            'name' => 'Unknown',
            'email' => '',
            'avatar' => null,
        );
    }
    
    /**
     * Send a message
     */
    public static function send($thread_id, $sender_id, $sender_type, $message, $attachments = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $thread = self::get_thread($thread_id);
        if (!$thread) {
            return new WP_Error('invalid_thread', __('Thread not found', 'rental-gates'));
        }
        
        // Verify sender is a participant
        $is_participant = (
            ($thread['participant_1_id'] == $sender_id && $thread['participant_1_type'] == $sender_type) ||
            ($thread['participant_2_id'] == $sender_id && $thread['participant_2_type'] == $sender_type)
        );
        
        if (!$is_participant) {
            return new WP_Error('not_participant', __('You are not a participant in this conversation', 'rental-gates'));
        }
        
        // Insert message
        $result = $wpdb->insert(
            $tables['messages'],
            array(
                'thread_id' => $thread_id,
                'sender_id' => $sender_id,
                'sender_type' => $sender_type,
                'message' => $message,
                'attachments' => $attachments ? wp_json_encode($attachments) : null,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to send message', 'rental-gates'));
        }
        
        $message_id = $wpdb->insert_id;
        
        // Update thread last_message_at
        $wpdb->update(
            $tables['message_threads'],
            array('last_message_at' => current_time('mysql')),
            array('id' => $thread_id),
            array('%s'),
            array('%d')
        );
        
        // Create notification for recipient
        $recipient_id = ($thread['participant_1_id'] == $sender_id && $thread['participant_1_type'] == $sender_type)
            ? $thread['participant_2_id']
            : $thread['participant_1_id'];
        $recipient_type = ($thread['participant_1_id'] == $sender_id && $thread['participant_1_type'] == $sender_type)
            ? $thread['participant_2_type']
            : $thread['participant_1_type'];
        
        // Get recipient's WordPress user ID for notification
        $recipient_wp_id = self::get_wp_user_id($recipient_id, $recipient_type);
        if ($recipient_wp_id) {
            $sender_info = self::get_participant_info($sender_id, $sender_type);
            Rental_Gates_Notification::create(
                $recipient_wp_id,
                'message',
                sprintf(__('New message from %s', 'rental-gates'), $sender_info['name']),
                wp_trim_words($message, 20),
                home_url('/rental-gates/dashboard/messages/' . $thread_id)
            );
        }
        
        return self::get_message($message_id);
    }
    
    /**
     * Get WordPress user ID from participant
     */
    private static function get_wp_user_id($participant_id, $participant_type) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        switch ($participant_type) {
            case 'staff':
                return $participant_id; // Staff ID is already WP user ID
                
            case 'tenant':
                return $wpdb->get_var($wpdb->prepare(
                    "SELECT user_id FROM {$tables['tenants']} WHERE id = %d",
                    $participant_id
                ));
                
            case 'vendor':
                return $wpdb->get_var($wpdb->prepare(
                    "SELECT user_id FROM {$tables['vendors']} WHERE id = %d",
                    $participant_id
                ));
        }
        
        return null;
    }
    
    /**
     * Get a single message
     */
    public static function get_message($message_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $message = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['messages']} WHERE id = %d",
            $message_id
        ), ARRAY_A);
        
        if ($message) {
            $message['sender'] = self::get_participant_info($message['sender_id'], $message['sender_type']);
            $message['sender_name'] = $message['sender']['name'] ?? 'Unknown';
            $message['content'] = $message['message']; // Alias for JS compatibility
            if (!empty($message['attachments'])) {
                $message['attachments'] = json_decode($message['attachments'], true);
            }
        }
        
        return $message;
    }
    
    /**
     * Get messages in a thread
     */
    public static function get_thread_messages($thread_id, $limit = 50, $before_id = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $where_before = $before_id ? $wpdb->prepare(" AND id < %d", $before_id) : "";
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$tables['messages']}
             WHERE thread_id = %d {$where_before}
             ORDER BY created_at DESC
             LIMIT %d",
            $thread_id, $limit
        ), ARRAY_A);
        
        // Enrich with sender info and reverse for chronological order
        $messages = array_reverse($messages);
        foreach ($messages as &$message) {
            $message['sender'] = self::get_participant_info($message['sender_id'], $message['sender_type']);
            // Add convenience aliases
            $message['content'] = $message['message']; // Alias for templates
            $message['sender_name'] = $message['sender']['name'] ?? 'Unknown';
            if (!empty($message['attachments'])) {
                $message['attachments'] = json_decode($message['attachments'], true);
            }
        }
        
        return $messages;
    }
    
    /**
     * Mark messages as read
     */
    public static function mark_as_read($thread_id, $reader_id, $reader_type) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->query($wpdb->prepare(
            "UPDATE {$tables['messages']}
             SET read_at = %s
             WHERE thread_id = %d
               AND read_at IS NULL
               AND NOT (sender_id = %d AND sender_type = %s)",
            current_time('mysql'),
            $thread_id,
            $reader_id, $reader_type
        ));
    }
    
    /**
     * Get unread count for user
     */
    public static function get_unread_count($org_id, $user_id, $user_type) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$tables['messages']} m
             JOIN {$tables['message_threads']} t ON m.thread_id = t.id
             WHERE t.organization_id = %d
               AND ((t.participant_1_id = %d AND t.participant_1_type = %s)
                    OR (t.participant_2_id = %d AND t.participant_2_type = %s))
               AND m.read_at IS NULL
               AND NOT (m.sender_id = %d AND m.sender_type = %s)",
            $org_id,
            $user_id, $user_type,
            $user_id, $user_type,
            $user_id, $user_type
        ));
    }
    
    /**
     * Delete a thread and all its messages
     */
    public static function delete_thread($thread_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Delete messages first
        $wpdb->delete($tables['messages'], array('thread_id' => $thread_id), array('%d'));
        
        // Delete thread
        return $wpdb->delete($tables['message_threads'], array('id' => $thread_id), array('%d'));
    }
    
    /**
     * Get all contacts for starting a new conversation
     */
    public static function get_contacts($org_id, $user_type = 'staff') {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $contacts = array(
            'staff' => array(),
            'tenants' => array(),
            'vendors' => array(),
        );
        
        // Get staff members
        $staff = $wpdb->get_results($wpdb->prepare(
            "SELECT om.user_id, u.display_name, u.user_email, om.role
             FROM {$tables['organization_members']} om
             JOIN {$wpdb->users} u ON om.user_id = u.ID
             WHERE om.organization_id = %d AND om.status = 'active'
             ORDER BY u.display_name",
            $org_id
        ), ARRAY_A);
        
        foreach ($staff as $s) {
            $contacts['staff'][] = array(
                'id' => $s['user_id'],
                'type' => 'staff',
                'name' => $s['display_name'],
                'email' => $s['user_email'],
                'role' => $s['role'],
                'avatar' => get_avatar_url($s['user_id'], array('size' => 48)),
            );
        }
        
        // Get tenants
        $tenants = $wpdb->get_results($wpdb->prepare(
            "SELECT t.id, t.first_name, t.last_name, t.email, t.user_id
             FROM {$tables['tenants']} t
             WHERE t.organization_id = %d AND t.status = 'active'
             ORDER BY t.first_name, t.last_name",
            $org_id
        ), ARRAY_A);
        
        foreach ($tenants as $t) {
            $contacts['tenants'][] = array(
                'id' => $t['id'],
                'type' => 'tenant',
                'name' => trim($t['first_name'] . ' ' . $t['last_name']),
                'email' => $t['email'],
                'avatar' => get_avatar_url($t['user_id'] ?? 0, array('size' => 48)),
            );
        }
        
        // Get vendors
        $vendors = $wpdb->get_results($wpdb->prepare(
            "SELECT v.id, v.company_name, v.contact_name, v.email
             FROM {$tables['vendors']} v
             WHERE v.organization_id = %d AND v.status = 'active'
             ORDER BY v.company_name",
            $org_id
        ), ARRAY_A);
        
        foreach ($vendors as $v) {
            $contacts['vendors'][] = array(
                'id' => $v['id'],
                'type' => 'vendor',
                'name' => $v['company_name'],
                'contact' => $v['contact_name'],
                'email' => $v['email'],
                'avatar' => null,
            );
        }
        
        return $contacts;
    }
}
