<?php
/**
 * Rental Gates Invoice Model
 * 
 * Handles invoice and receipt generation, storage, and retrieval.
 * Supports both pending invoices and paid receipts.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Invoice {
    
    private static $table_name;
    private static $table_checked = false;
    
    /**
     * Initialize table name and ensure table exists
     */
    private static function init() {
        if (!self::$table_name) {
            global $wpdb;
            self::$table_name = $wpdb->prefix . 'rg_invoices';
        }
        
        // Only check/create table once per request
        if (!self::$table_checked) {
            self::$table_checked = true;
            self::ensure_table_exists();
        }
    }
    
    /**
     * Ensure table exists (lightweight check)
     */
    private static function ensure_table_exists() {
        global $wpdb;
        
        // Quick check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        
        if (!$table_exists) {
            self::create_table();
        } else {
            // Check if critical columns exist
            $columns = $wpdb->get_results("SHOW COLUMNS FROM " . self::$table_name);
            $column_names = array_map(function($col) { return $col->Field; }, $columns);
            
            $required_columns = array('payment_id', 'tenant_id', 'lease_id', 'invoice_number', 'type', 'status');
            $missing_columns = array_diff($required_columns, $column_names);
            
            if (!empty($missing_columns)) {
                // Table structure is broken, drop and recreate
                $wpdb->query("DROP TABLE IF EXISTS " . self::$table_name);
                self::create_table();
            }
        }
    }
    
    /**
     * Create invoices table if not exists
     */
    public static function create_table() {
        global $wpdb;
        
        if (!self::$table_name) {
            self::$table_name = $wpdb->prefix . 'rg_invoices';
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Use dbDelta format (no IF NOT EXISTS for proper column updates)
        $sql = "CREATE TABLE " . self::$table_name . " (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            organization_id bigint(20) UNSIGNED NOT NULL,
            payment_id bigint(20) UNSIGNED NULL,
            tenant_id bigint(20) UNSIGNED NULL,
            lease_id bigint(20) UNSIGNED NULL,
            invoice_number varchar(50) NOT NULL,
            type enum('invoice','receipt') NOT NULL DEFAULT 'invoice',
            status enum('draft','sent','paid','cancelled','void') NOT NULL DEFAULT 'draft',
            issue_date date NOT NULL,
            due_date date NULL,
            paid_date datetime NULL,
            subtotal decimal(10,2) NOT NULL DEFAULT 0.00,
            tax_amount decimal(10,2) NOT NULL DEFAULT 0.00,
            tax_rate decimal(5,2) NOT NULL DEFAULT 0.00,
            fees decimal(10,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(10,2) NOT NULL DEFAULT 0.00,
            amount_paid decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(3) NOT NULL DEFAULT 'USD',
            payment_method varchar(50) NULL,
            transaction_reference varchar(255) NULL,
            line_items longtext NULL,
            tenant_data longtext NULL,
            property_data longtext NULL,
            organization_data longtext NULL,
            notes text NULL,
            terms text NULL,
            file_path varchar(500) NULL,
            html_content longtext NULL,
            meta_data longtext NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY organization_id (organization_id),
            KEY payment_id (payment_id),
            KEY tenant_id (tenant_id),
            KEY invoice_number (invoice_number),
            KEY type (type),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Verify payment_id column exists (manual check for existing tables)
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM " . self::$table_name . " LIKE 'payment_id'");
        if (empty($column_exists)) {
            $wpdb->query("ALTER TABLE " . self::$table_name . " ADD COLUMN payment_id bigint(20) UNSIGNED NULL AFTER organization_id");
            $wpdb->query("ALTER TABLE " . self::$table_name . " ADD KEY payment_id (payment_id)");
        }
    }
    
    /**
     * Generate unique invoice number
     */
    private static function generate_invoice_number($org_id, $type = 'invoice') {
        global $wpdb;
        self::init();
        
        $prefix = $type === 'receipt' ? 'RCP' : 'INV';
        $year = date('Y');
        
        $last = $wpdb->get_var($wpdb->prepare(
            "SELECT invoice_number FROM " . self::$table_name . " 
             WHERE organization_id = %d AND invoice_number LIKE %s 
             ORDER BY id DESC LIMIT 1",
            $org_id, $prefix . '-' . $year . '-%'
        ));
        
        if ($last) {
            $parts = explode('-', $last);
            $num = intval(end($parts)) + 1;
        } else {
            $num = 1;
        }
        
        return $prefix . '-' . $year . '-' . str_pad($num, 5, '0', STR_PAD_LEFT);
    }
    
    /**
     * Create invoice from payment
     */
    public static function create_from_payment($payment_id, $type = 'invoice') {
        global $wpdb;
        self::init();
        
        $payment = Rental_Gates_Payment::get_with_details($payment_id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        // Get organization details
        $org = Rental_Gates_Organization::get($payment['organization_id']);
        
        // Get tenant details - try from payment first, then from lease
        $tenant = null;
        if ($payment['tenant_id']) {
            $tenant = Rental_Gates_Tenant::get($payment['tenant_id']);
        }
        
        // Get lease and property details
        $lease = null;
        $unit = null;
        $building = null;
        if ($payment['lease_id']) {
            $lease = Rental_Gates_Lease::get_with_details($payment['lease_id']);
            if ($lease) {
                $unit = Rental_Gates_Unit::get($lease['unit_id']);
                if ($unit) {
                    $building = Rental_Gates_Building::get($unit['building_id']);
                }
                
                // If no tenant from payment, try to get primary tenant from lease
                if (!$tenant && !empty($lease['tenant_id'])) {
                    $tenant = Rental_Gates_Tenant::get($lease['tenant_id']);
                }
                
                // If still no tenant, query lease_tenants table
                if (!$tenant) {
                    $tables = Rental_Gates_Database::get_table_names();
                    $lease_tenant = $wpdb->get_row($wpdb->prepare(
                        "SELECT t.* FROM {$tables['tenants']} t
                         JOIN {$tables['lease_tenants']} lt ON t.id = lt.tenant_id
                         WHERE lt.lease_id = %d AND lt.removed_at IS NULL
                         ORDER BY FIELD(lt.role, 'primary', 'co_tenant', 'occupant'), lt.id ASC
                         LIMIT 1",
                        $payment['lease_id']
                    ), ARRAY_A);
                    if ($lease_tenant) {
                        $tenant = $lease_tenant;
                    }
                }
            }
        }
        
        // Build line items - only include the actual payment amount
        // Platform fees are internal (between platform and owner) and should NOT be shown to tenants
        $line_items = array(
            array(
                'description' => $payment['description'] ?: sprintf(__('%s Payment', 'rental-gates'), ucfirst($payment['type'])),
                'quantity' => 1,
                'unit_price' => $payment['amount'],
                'amount' => $payment['amount'],
            ),
        );
        
        // Note: Platform fee and Stripe fee are NOT added as line items
        // These are internal fees deducted from the owner's payout, not charged to the tenant
        
        // Tenant data snapshot
        $tenant_data = array(
            'name' => $tenant ? ($tenant['first_name'] . ' ' . $tenant['last_name']) : __('N/A', 'rental-gates'),
            'email' => $tenant['email'] ?? '',
            'phone' => $tenant['phone'] ?? '',
            'address' => '',
        );
        
        // Property data snapshot
        $property_data = array(
            'building_name' => $building['name'] ?? '',
            'building_address' => $building['derived_address'] ?? '',
            'unit_name' => $unit['name'] ?? '',
            'unit_number' => $unit['unit_number'] ?? '',
        );
        
        // Organization data snapshot
        $org_data = array(
            'name' => $org['name'] ?? '',
            'email' => $org['contact_email'] ?? '',
            'phone' => $org['contact_phone'] ?? '',
            'address' => $org['address'] ?? '',
            'logo_url' => $org['logo_url'] ?? '',
        );
        
        // Get payment method details from meta
        $meta = is_array($payment['meta_data']) ? $payment['meta_data'] : array();
        $stripe_details = $meta['stripe_details'] ?? array();
        $payment_method = $payment['method_label'] ?? ucfirst($payment['method']);
        if (!empty($stripe_details['card_brand']) && !empty($stripe_details['card_last4'])) {
            $payment_method = ucfirst($stripe_details['card_brand']) . ' •••• ' . $stripe_details['card_last4'];
        }
        
        // Determine status based on payment
        $status = 'draft';
        if ($type === 'receipt' || $payment['status'] === 'succeeded') {
            $status = 'paid';
            $type = 'receipt'; // Auto-convert to receipt if paid
        }
        
        $invoice_data = array(
            'organization_id' => $payment['organization_id'],
            'payment_id' => $payment_id,
            'tenant_id' => $payment['tenant_id'],
            'lease_id' => $payment['lease_id'],
            'invoice_number' => self::generate_invoice_number($payment['organization_id'], $type),
            'type' => $type,
            'status' => $status,
            'issue_date' => $payment['created_at'] ? date('Y-m-d', strtotime($payment['created_at'])) : date('Y-m-d'),
            'due_date' => $payment['due_date'],
            'paid_date' => $payment['paid_at'],
            'subtotal' => $payment['amount'],
            'tax_amount' => 0,
            'tax_rate' => 0,
            'fees' => 0, // Fees are internal (owner-side) and not shown to tenants
            'total_amount' => $payment['amount'], // Total is just the payment amount
            'amount_paid' => $payment['amount_paid'],
            'currency' => $payment['currency'],
            'payment_method' => $payment_method,
            'transaction_reference' => $payment['stripe_payment_intent_id'] ?: $payment['payment_number'],
            'line_items' => json_encode($line_items),
            'tenant_data' => json_encode($tenant_data),
            'property_data' => json_encode($property_data),
            'organization_data' => json_encode($org_data),
            'notes' => '', // Internal notes from payment are not included in invoices
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $invoice_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating invoice', 'rental-gates'));
        }
        
        $invoice_id = $wpdb->insert_id;
        
        // Generate HTML content
        $invoice = self::get($invoice_id);
        $html = self::generate_html($invoice);
        
        // Save HTML
        $wpdb->update(
            self::$table_name,
            array('html_content' => $html),
            array('id' => $invoice_id)
        );
        
        return self::get($invoice_id);
    }
    
    /**
     * Get invoice by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$invoice) {
            return null;
        }
        
        return self::format_invoice($invoice);
    }
    
    /**
     * Get invoice by payment ID
     */
    public static function get_by_payment($payment_id) {
        global $wpdb;
        self::init();
        
        // Suppress errors and check result
        $wpdb->suppress_errors(true);
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE payment_id = %d ORDER BY id DESC LIMIT 1",
            $payment_id
        ), ARRAY_A);
        $wpdb->suppress_errors(false);
        
        if (!$invoice || $wpdb->last_error) {
            return null;
        }
        
        return self::format_invoice($invoice);
    }
    
    /**
     * Get invoices for tenant
     */
    public static function get_for_tenant($tenant_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'type' => null,
            'status' => null,
            'limit' => 50,
            'order' => 'DESC',
        );
        $args = wp_parse_args($args, $defaults);
        
        $where = array('tenant_id = %d');
        $params = array($tenant_id);
        
        if ($args['type']) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        $limit = intval($args['limit']);
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY created_at {$order} 
                LIMIT {$limit}";
        
        $results = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_invoice'), $results);
    }
    
    /**
     * Get invoices for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'type' => null,
            'status' => null,
            'tenant_id' => null,
            'limit' => 100,
            'order' => 'DESC',
        );
        $args = wp_parse_args($args, $defaults);
        
        $where = array('organization_id = %d');
        $params = array($org_id);
        
        if ($args['type']) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        
        if ($args['tenant_id']) {
            $where[] = 'tenant_id = %d';
            $params[] = $args['tenant_id'];
        }
        
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        $limit = intval($args['limit']);
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY created_at {$order} 
                LIMIT {$limit}";
        
        $results = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_invoice'), $results);
    }
    
    /**
     * Format invoice data
     */
    private static function format_invoice($invoice) {
        if (!$invoice) return null;
        
        $invoice['id'] = intval($invoice['id']);
        $invoice['organization_id'] = intval($invoice['organization_id']);
        $invoice['payment_id'] = $invoice['payment_id'] ? intval($invoice['payment_id']) : null;
        $invoice['tenant_id'] = $invoice['tenant_id'] ? intval($invoice['tenant_id']) : null;
        $invoice['lease_id'] = $invoice['lease_id'] ? intval($invoice['lease_id']) : null;
        $invoice['subtotal'] = floatval($invoice['subtotal']);
        $invoice['tax_amount'] = floatval($invoice['tax_amount']);
        $invoice['tax_rate'] = floatval($invoice['tax_rate']);
        $invoice['fees'] = floatval($invoice['fees']);
        $invoice['total_amount'] = floatval($invoice['total_amount']);
        $invoice['amount_paid'] = floatval($invoice['amount_paid']);
        
        // Parse JSON fields
        $invoice['line_items'] = !empty($invoice['line_items']) ? json_decode($invoice['line_items'], true) : array();
        $invoice['tenant_data'] = !empty($invoice['tenant_data']) ? json_decode($invoice['tenant_data'], true) : array();
        $invoice['property_data'] = !empty($invoice['property_data']) ? json_decode($invoice['property_data'], true) : array();
        $invoice['organization_data'] = !empty($invoice['organization_data']) ? json_decode($invoice['organization_data'], true) : array();
        $invoice['meta_data'] = !empty($invoice['meta_data']) ? json_decode($invoice['meta_data'], true) : array();
        
        // Calculate balance
        $invoice['balance'] = $invoice['total_amount'] - $invoice['amount_paid'];
        $invoice['is_paid'] = $invoice['status'] === 'paid' || $invoice['balance'] <= 0;
        
        // Type label
        $invoice['type_label'] = $invoice['type'] === 'receipt' ? __('Receipt', 'rental-gates') : __('Invoice', 'rental-gates');
        
        return $invoice;
    }
    
    /**
     * Generate HTML content for invoice/receipt
     */
    public static function generate_html($invoice) {
        if (!is_array($invoice)) {
            $invoice = self::get($invoice);
        }
        
        if (!$invoice) {
            return '';
        }
        
        $org = $invoice['organization_data'];
        $tenant = $invoice['tenant_data'];
        $property = $invoice['property_data'];
        $is_receipt = $invoice['type'] === 'receipt';
        
        // Status badge colors
        $status_colors = array(
            'draft' => '#6b7280',
            'sent' => '#3b82f6',
            'paid' => '#10b981',
            'cancelled' => '#ef4444',
            'void' => '#6b7280',
        );
        $status_color = $status_colors[$invoice['status']] ?? '#6b7280';
        
        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_receipt ? __('Receipt', 'rental-gates') : __('Invoice', 'rental-gates'); ?> #<?php echo esc_html($invoice['invoice_number']); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            font-size: 14px;
            line-height: 1.5;
            color: #1f2937;
            background: #fff;
        }
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
        }
        
        /* Header */
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
            padding-bottom: 24px;
            border-bottom: 2px solid #e5e7eb;
        }
        .company-info h1 {
            font-size: 24px;
            font-weight: 700;
            color: #111827;
            margin-bottom: 8px;
        }
        .company-info p {
            color: #6b7280;
            font-size: 13px;
        }
        .invoice-title {
            text-align: right;
        }
        .invoice-title h2 {
            font-size: 32px;
            font-weight: 700;
            color: <?php echo $is_receipt ? '#10b981' : '#6366f1'; ?>;
            margin-bottom: 8px;
        }
        .invoice-number {
            font-size: 14px;
            color: #6b7280;
        }
        .invoice-status {
            display: inline-block;
            margin-top: 8px;
            padding: 4px 12px;
            background: <?php echo $status_color; ?>20;
            color: <?php echo $status_color; ?>;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            margin-bottom: 40px;
        }
        .info-block h3 {
            font-size: 11px;
            font-weight: 600;
            color: #9ca3af;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .info-block p {
            color: #374151;
            font-size: 14px;
        }
        .info-block .name {
            font-weight: 600;
            color: #111827;
        }
        
        /* Dates */
        .dates-row {
            display: flex;
            gap: 40px;
            margin-bottom: 32px;
            padding: 16px 20px;
            background: #f9fafb;
            border-radius: 8px;
        }
        .date-item {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .date-label {
            font-size: 12px;
            color: #6b7280;
        }
        .date-value {
            font-weight: 600;
            color: #111827;
        }
        
        /* Table */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        .items-table th {
            text-align: left;
            padding: 12px 16px;
            background: #f3f4f6;
            font-size: 11px;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .items-table th:last-child {
            text-align: right;
        }
        .items-table td {
            padding: 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .items-table td:last-child {
            text-align: right;
            font-weight: 500;
        }
        .item-description {
            font-weight: 500;
            color: #111827;
        }
        .item-details {
            font-size: 12px;
            color: #6b7280;
            margin-top: 2px;
        }
        
        /* Totals */
        .totals-section {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 40px;
        }
        .totals-box {
            width: 280px;
        }
        .totals-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .totals-row:last-child {
            border-bottom: none;
        }
        .totals-row.total {
            padding-top: 12px;
            margin-top: 4px;
            border-top: 2px solid #111827;
            border-bottom: none;
        }
        .totals-label {
            color: #6b7280;
        }
        .totals-value {
            font-weight: 500;
            color: #111827;
        }
        .totals-row.total .totals-label,
        .totals-row.total .totals-value {
            font-size: 16px;
            font-weight: 700;
        }
        .totals-row.paid .totals-value {
            color: #10b981;
        }
        .totals-row.balance .totals-value {
            color: <?php echo $invoice['balance'] > 0 ? '#ef4444' : '#10b981'; ?>;
        }
        
        /* Payment Info */
        .payment-info {
            padding: 20px;
            background: linear-gradient(135deg, #ecfdf5 0%, #f0fdf4 100%);
            border: 1px solid #86efac;
            border-radius: 8px;
            margin-bottom: 24px;
        }
        .payment-info h4 {
            font-size: 12px;
            font-weight: 600;
            color: #059669;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }
        .payment-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
        }
        .payment-info-item {
            font-size: 13px;
        }
        .payment-info-item .label {
            color: #6b7280;
            font-size: 11px;
        }
        .payment-info-item .value {
            color: #065f46;
            font-weight: 600;
        }
        
        /* Notes */
        .notes-section {
            padding: 16px 20px;
            background: #f9fafb;
            border-radius: 8px;
            margin-bottom: 24px;
        }
        .notes-section h4 {
            font-size: 12px;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .notes-section p {
            color: #374151;
            font-size: 13px;
        }
        
        /* Footer */
        .invoice-footer {
            text-align: center;
            padding-top: 24px;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 12px;
        }
        
        /* Print styles */
        @media print {
            body { background: #fff; }
            .invoice-container { padding: 20px; max-width: 100%; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <!-- Header -->
        <div class="invoice-header">
            <div class="company-info">
                <h1><?php echo esc_html($org['name'] ?? __('Property Management', 'rental-gates')); ?></h1>
                <?php if (!empty($org['address'])): ?>
                    <p><?php echo esc_html($org['address']); ?></p>
                <?php endif; ?>
                <?php if (!empty($org['email'])): ?>
                    <p><?php echo esc_html($org['email']); ?></p>
                <?php endif; ?>
                <?php if (!empty($org['phone'])): ?>
                    <p><?php echo esc_html($org['phone']); ?></p>
                <?php endif; ?>
            </div>
            <div class="invoice-title">
                <h2><?php echo $is_receipt ? __('RECEIPT', 'rental-gates') : __('INVOICE', 'rental-gates'); ?></h2>
                <div class="invoice-number">#<?php echo esc_html($invoice['invoice_number']); ?></div>
                <div class="invoice-status"><?php echo esc_html(ucfirst($invoice['status'])); ?></div>
            </div>
        </div>
        
        <!-- Bill To / Property / Reference -->
        <div class="info-grid">
            <div class="info-block">
                <h3><?php _e('Bill To', 'rental-gates'); ?></h3>
                <p class="name"><?php echo esc_html($tenant['name'] ?? __('N/A', 'rental-gates')); ?></p>
                <?php if (!empty($tenant['email'])): ?>
                    <p><?php echo esc_html($tenant['email']); ?></p>
                <?php endif; ?>
                <?php if (!empty($tenant['phone'])): ?>
                    <p><?php echo esc_html($tenant['phone']); ?></p>
                <?php endif; ?>
            </div>
            <div class="info-block">
                <h3><?php _e('Property', 'rental-gates'); ?></h3>
                <?php if (!empty($property['unit_name']) || !empty($property['unit_number'])): ?>
                    <p class="name"><?php echo esc_html($property['unit_name'] ?: $property['unit_number']); ?></p>
                <?php endif; ?>
                <?php if (!empty($property['building_name'])): ?>
                    <p><?php echo esc_html($property['building_name']); ?></p>
                <?php endif; ?>
                <?php if (!empty($property['building_address'])): ?>
                    <p><?php echo esc_html($property['building_address']); ?></p>
                <?php endif; ?>
            </div>
            <div class="info-block">
                <h3><?php _e('Reference', 'rental-gates'); ?></h3>
                <?php if (!empty($invoice['transaction_reference'])): ?>
                    <p class="name"><?php echo esc_html($invoice['transaction_reference']); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Dates -->
        <div class="dates-row">
            <div class="date-item">
                <div>
                    <div class="date-label"><?php _e('Issue Date', 'rental-gates'); ?></div>
                    <div class="date-value"><?php echo date_i18n('F j, Y', strtotime($invoice['issue_date'])); ?></div>
                </div>
            </div>
            <?php if (!$is_receipt && $invoice['due_date']): ?>
            <div class="date-item">
                <div>
                    <div class="date-label"><?php _e('Due Date', 'rental-gates'); ?></div>
                    <div class="date-value"><?php echo date_i18n('F j, Y', strtotime($invoice['due_date'])); ?></div>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($invoice['paid_date']): ?>
            <div class="date-item">
                <div>
                    <div class="date-label"><?php _e('Paid Date', 'rental-gates'); ?></div>
                    <div class="date-value"><?php echo date_i18n('F j, Y', strtotime($invoice['paid_date'])); ?></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Line Items -->
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 50%;"><?php _e('Description', 'rental-gates'); ?></th>
                    <th style="width: 15%;"><?php _e('Qty', 'rental-gates'); ?></th>
                    <th style="width: 15%;"><?php _e('Unit Price', 'rental-gates'); ?></th>
                    <th style="width: 20%;"><?php _e('Amount', 'rental-gates'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoice['line_items'] as $item): ?>
                <tr>
                    <td>
                        <div class="item-description"><?php echo esc_html($item['description']); ?></div>
                        <?php if (!empty($item['details'])): ?>
                            <div class="item-details"><?php echo esc_html($item['details']); ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?php echo intval($item['quantity']); ?></td>
                    <td>$<?php echo number_format($item['unit_price'], 2); ?></td>
                    <td>$<?php echo number_format($item['amount'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Totals -->
        <div class="totals-section">
            <div class="totals-box">
                <div class="totals-row">
                    <span class="totals-label"><?php _e('Subtotal', 'rental-gates'); ?></span>
                    <span class="totals-value">$<?php echo number_format($invoice['subtotal'], 2); ?></span>
                </div>
                <?php if ($invoice['tax_amount'] > 0): ?>
                <div class="totals-row">
                    <span class="totals-label"><?php printf(__('Tax (%s%%)', 'rental-gates'), number_format($invoice['tax_rate'], 1)); ?></span>
                    <span class="totals-value">$<?php echo number_format($invoice['tax_amount'], 2); ?></span>
                </div>
                <?php endif; ?>
                <div class="totals-row total">
                    <span class="totals-label"><?php _e('Total', 'rental-gates'); ?></span>
                    <span class="totals-value">$<?php echo number_format($invoice['total_amount'], 2); ?></span>
                </div>
                <?php if ($invoice['amount_paid'] > 0): ?>
                <div class="totals-row paid">
                    <span class="totals-label"><?php _e('Amount Paid', 'rental-gates'); ?></span>
                    <span class="totals-value">-$<?php echo number_format($invoice['amount_paid'], 2); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($invoice['balance'] != 0): ?>
                <div class="totals-row balance">
                    <span class="totals-label"><?php _e('Balance Due', 'rental-gates'); ?></span>
                    <span class="totals-value">$<?php echo number_format(max(0, $invoice['balance']), 2); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Payment Info (for receipts) -->
        <?php if ($is_receipt && $invoice['payment_method']): ?>
        <div class="payment-info">
            <h4><?php _e('Payment Information', 'rental-gates'); ?></h4>
            <div class="payment-info-grid">
                <div class="payment-info-item">
                    <div class="label"><?php _e('Payment Method', 'rental-gates'); ?></div>
                    <div class="value"><?php echo esc_html($invoice['payment_method']); ?></div>
                </div>
                <div class="payment-info-item">
                    <div class="label"><?php _e('Amount Paid', 'rental-gates'); ?></div>
                    <div class="value">$<?php echo number_format($invoice['amount_paid'], 2); ?></div>
                </div>
                <?php if ($invoice['paid_date']): ?>
                <div class="payment-info-item">
                    <div class="label"><?php _e('Date', 'rental-gates'); ?></div>
                    <div class="value"><?php echo date_i18n('F j, Y g:i A', strtotime($invoice['paid_date'])); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Notes -->
        <?php if (!empty($invoice['notes'])): ?>
        <div class="notes-section">
            <h4><?php _e('Notes', 'rental-gates'); ?></h4>
            <p><?php echo nl2br(esc_html($invoice['notes'])); ?></p>
        </div>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="invoice-footer">
            <p><?php _e('Thank you for your payment!', 'rental-gates'); ?></p>
            <p><?php printf(__('Generated on %s', 'rental-gates'), date_i18n('F j, Y g:i A')); ?></p>
        </div>
    </div>
</body>
</html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Update invoice
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $allowed = array('status', 'paid_date', 'amount_paid', 'payment_method', 'transaction_reference', 'notes');
        $update_data = array();
        
        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $update_data[$field] = $data[$field];
            }
        }
        
        if (empty($update_data)) {
            return self::get($id);
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        return self::get($id);
    }
    
    /**
     * Delete invoice
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        return $wpdb->delete(self::$table_name, array('id' => $id));
    }
}
