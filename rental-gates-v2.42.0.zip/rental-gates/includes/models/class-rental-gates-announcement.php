<?php
/**
 * Rental Gates Announcement Model
 * Handles broadcast announcements to tenants, staff, and vendors
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Announcement {
    
    /**
     * Create a new announcement
     */
    public static function create($data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'organization_id' => null,
            'title' => '',
            'message' => '',
            'audience_type' => 'all', // all, buildings, units, tenants, staff, vendors
            'audience_ids' => null,
            'priority' => 'normal', // low, normal, high, urgent
            'delivery' => 'immediate', // immediate, scheduled
            'scheduled_at' => null,
            'channels' => 'both', // in_app, email, both
            'created_by' => get_current_user_id(),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['title']) || empty($data['message'])) {
            return new WP_Error('missing_fields', __('Missing required fields', 'rental-gates'));
        }
        
        $result = $wpdb->insert(
            $tables['announcements'],
            array(
                'organization_id' => $data['organization_id'],
                'title' => sanitize_text_field($data['title']),
                'message' => wp_kses_post($data['message']),
                'audience_type' => $data['audience_type'],
                'audience_ids' => $data['audience_ids'] ? wp_json_encode($data['audience_ids']) : null,
                'delivery' => $data['delivery'],
                'scheduled_at' => $data['scheduled_at'],
                'channels' => $data['channels'],
                'created_by' => $data['created_by'],
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create announcement', 'rental-gates'));
        }
        
        $announcement_id = $wpdb->insert_id;
        
        // If immediate delivery, send now
        if ($data['delivery'] === 'immediate') {
            self::send($announcement_id);
        }
        
        return self::get($announcement_id);
    }
    
    /**
     * Get announcement by ID
     */
    public static function get($announcement_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $announcement = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, u.display_name as created_by_name
             FROM {$tables['announcements']} a
             LEFT JOIN {$wpdb->users} u ON a.created_by = u.ID
             WHERE a.id = %d",
            $announcement_id
        ), ARRAY_A);
        
        if ($announcement && $announcement['audience_ids']) {
            $announcement['audience_ids'] = json_decode($announcement['audience_ids'], true);
        }
        
        return $announcement;
    }
    
    /**
     * Get announcements for organization
     */
    public static function get_all($org_id, $args = array()) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'limit' => 20,
            'offset' => 0,
            'status' => null, // sent, pending, scheduled
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array("a.organization_id = %d");
        $params = array($org_id);
        
        if ($args['status'] === 'sent') {
            $where[] = "a.sent_at IS NOT NULL";
        } elseif ($args['status'] === 'pending') {
            $where[] = "a.sent_at IS NULL AND a.delivery = 'immediate'";
        } elseif ($args['status'] === 'scheduled') {
            $where[] = "a.sent_at IS NULL AND a.delivery = 'scheduled'";
        }
        
        $where_sql = implode(' AND ', $where);
        $order = $args['order'] === 'ASC' ? 'ASC' : 'DESC';
        
        $announcements = $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, u.display_name as created_by_name,
                    (SELECT COUNT(*) FROM {$tables['announcement_recipients']} ar WHERE ar.announcement_id = a.id) as recipient_count,
                    (SELECT COUNT(*) FROM {$tables['announcement_recipients']} ar WHERE ar.announcement_id = a.id AND ar.read_at IS NOT NULL) as read_count
             FROM {$tables['announcements']} a
             LEFT JOIN {$wpdb->users} u ON a.created_by = u.ID
             WHERE {$where_sql}
             ORDER BY COALESCE(a.sent_at, a.scheduled_at, a.created_at) {$order}
             LIMIT %d OFFSET %d",
            array_merge($params, array($args['limit'], $args['offset']))
        ), ARRAY_A);
        
        foreach ($announcements as &$ann) {
            if ($ann['audience_ids']) {
                $ann['audience_ids'] = json_decode($ann['audience_ids'], true);
            }
        }
        
        return $announcements;
    }
    
    /**
     * Get total count for organization
     */
    public static function count($org_id, $status = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $where = "organization_id = %d";
        $params = array($org_id);
        
        if ($status === 'sent') {
            $where .= " AND sent_at IS NOT NULL";
        } elseif ($status === 'pending') {
            $where .= " AND sent_at IS NULL AND delivery = 'immediate'";
        } elseif ($status === 'scheduled') {
            $where .= " AND sent_at IS NULL AND delivery = 'scheduled'";
        }
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['announcements']} WHERE {$where}",
            $params
        ));
    }
    
    /**
     * Send an announcement
     */
    public static function send($announcement_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $announcement = self::get($announcement_id);
        if (!$announcement) {
            return new WP_Error('not_found', __('Announcement not found', 'rental-gates'));
        }
        
        if ($announcement['sent_at']) {
            return new WP_Error('already_sent', __('Announcement already sent', 'rental-gates'));
        }
        
        // Get recipients based on audience type
        $recipients = self::get_recipients($announcement);
        
        if (empty($recipients)) {
            return new WP_Error('no_recipients', __('No recipients found', 'rental-gates'));
        }
        
        // Create recipient records and send notifications
        foreach ($recipients as $recipient) {
            // Insert recipient record
            $wpdb->insert(
                $tables['announcement_recipients'],
                array(
                    'announcement_id' => $announcement_id,
                    'user_id' => $recipient['user_id'],
                    'recipient_type' => $recipient['type'],
                    'delivered_at' => current_time('mysql'),
                ),
                array('%d', '%d', '%s', '%s')
            );
            
            // Create in-app notification
            if (in_array($announcement['channels'], array('in_app', 'both'))) {
                Rental_Gates_Notification::create(
                    $recipient['user_id'],
                    'announcement',
                    $announcement['title'],
                    wp_trim_words(strip_tags($announcement['message']), 20),
                    home_url('/rental-gates/dashboard/announcements/' . $announcement_id)
                );
            }
            
            // Send email
            if (in_array($announcement['channels'], array('email', 'both')) && !empty($recipient['email'])) {
                self::send_email($recipient, $announcement);
            }
        }
        
        // Mark as sent
        $wpdb->update(
            $tables['announcements'],
            array('sent_at' => current_time('mysql')),
            array('id' => $announcement_id),
            array('%s'),
            array('%d')
        );
        
        return array(
            'success' => true,
            'recipients' => count($recipients),
        );
    }
    
    /**
     * Get recipients based on audience type
     */
    private static function get_recipients($announcement) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $recipients = array();
        $org_id = $announcement['organization_id'];
        $audience_type = $announcement['audience_type'];
        $audience_ids = $announcement['audience_ids'];
        
        switch ($audience_type) {
            case 'all':
                // All tenants with user accounts
                $tenants = $wpdb->get_results($wpdb->prepare(
                    "SELECT t.user_id, t.email, 'tenant' as type
                     FROM {$tables['tenants']} t
                     WHERE t.organization_id = %d AND t.status = 'active' AND t.user_id IS NOT NULL",
                    $org_id
                ), ARRAY_A);
                $recipients = array_merge($recipients, $tenants);
                
                // All staff
                $staff = $wpdb->get_results($wpdb->prepare(
                    "SELECT om.user_id, u.user_email as email, 'staff' as type
                     FROM {$tables['organization_members']} om
                     JOIN {$wpdb->users} u ON om.user_id = u.ID
                     WHERE om.organization_id = %d AND om.status = 'active'",
                    $org_id
                ), ARRAY_A);
                $recipients = array_merge($recipients, $staff);
                break;
                
            case 'tenants':
                if (!empty($audience_ids)) {
                    $placeholders = implode(',', array_fill(0, count($audience_ids), '%d'));
                    $tenants = $wpdb->get_results($wpdb->prepare(
                        "SELECT t.user_id, t.email, 'tenant' as type
                         FROM {$tables['tenants']} t
                         WHERE t.id IN ({$placeholders}) AND t.user_id IS NOT NULL",
                        $audience_ids
                    ), ARRAY_A);
                } else {
                    $tenants = $wpdb->get_results($wpdb->prepare(
                        "SELECT t.user_id, t.email, 'tenant' as type
                         FROM {$tables['tenants']} t
                         WHERE t.organization_id = %d AND t.status = 'active' AND t.user_id IS NOT NULL",
                        $org_id
                    ), ARRAY_A);
                }
                $recipients = $tenants;
                break;
                
            case 'staff':
                if (!empty($audience_ids)) {
                    $placeholders = implode(',', array_fill(0, count($audience_ids), '%d'));
                    $staff = $wpdb->get_results($wpdb->prepare(
                        "SELECT om.user_id, u.user_email as email, 'staff' as type
                         FROM {$tables['organization_members']} om
                         JOIN {$wpdb->users} u ON om.user_id = u.ID
                         WHERE om.user_id IN ({$placeholders})",
                        $audience_ids
                    ), ARRAY_A);
                } else {
                    $staff = $wpdb->get_results($wpdb->prepare(
                        "SELECT om.user_id, u.user_email as email, 'staff' as type
                         FROM {$tables['organization_members']} om
                         JOIN {$wpdb->users} u ON om.user_id = u.ID
                         WHERE om.organization_id = %d AND om.status = 'active'",
                        $org_id
                    ), ARRAY_A);
                }
                $recipients = $staff;
                break;
                
            case 'buildings':
                // Tenants in specific buildings
                if (!empty($audience_ids)) {
                    $placeholders = implode(',', array_fill(0, count($audience_ids), '%d'));
                    $tenants = $wpdb->get_results($wpdb->prepare(
                        "SELECT DISTINCT t.user_id, t.email, 'tenant' as type
                         FROM {$tables['tenants']} t
                         JOIN {$tables['leases']} l ON t.id = l.tenant_id
                         JOIN {$tables['units']} u ON l.unit_id = u.id
                         WHERE u.building_id IN ({$placeholders}) 
                           AND t.user_id IS NOT NULL
                           AND l.status = 'active'",
                        $audience_ids
                    ), ARRAY_A);
                    $recipients = $tenants;
                }
                break;
                
            case 'units':
                // Tenants in specific units
                if (!empty($audience_ids)) {
                    $placeholders = implode(',', array_fill(0, count($audience_ids), '%d'));
                    $tenants = $wpdb->get_results($wpdb->prepare(
                        "SELECT DISTINCT t.user_id, t.email, 'tenant' as type
                         FROM {$tables['tenants']} t
                         JOIN {$tables['leases']} l ON t.id = l.tenant_id
                         WHERE l.unit_id IN ({$placeholders})
                           AND t.user_id IS NOT NULL
                           AND l.status = 'active'",
                        $audience_ids
                    ), ARRAY_A);
                    $recipients = $tenants;
                }
                break;
                
            case 'vendors':
                if (!empty($audience_ids)) {
                    $placeholders = implode(',', array_fill(0, count($audience_ids), '%d'));
                    $vendors = $wpdb->get_results($wpdb->prepare(
                        "SELECT v.user_id, v.email, 'vendor' as type
                         FROM {$tables['vendors']} v
                         WHERE v.id IN ({$placeholders}) AND v.user_id IS NOT NULL",
                        $audience_ids
                    ), ARRAY_A);
                } else {
                    $vendors = $wpdb->get_results($wpdb->prepare(
                        "SELECT v.user_id, v.email, 'vendor' as type
                         FROM {$tables['vendors']} v
                         WHERE v.organization_id = %d AND v.status = 'active' AND v.user_id IS NOT NULL",
                        $org_id
                    ), ARRAY_A);
                }
                $recipients = $vendors;
                break;
        }
        
        // Filter out recipients without user_id
        return array_filter($recipients, function($r) {
            return !empty($r['user_id']);
        });
    }
    
    /**
     * Send email notification
     */
    private static function send_email($recipient, $announcement) {
        $subject = $announcement['title'];
        
        $message = sprintf(
            __("Hello,\n\n%s\n\n%s\n\nView this announcement: %s", 'rental-gates'),
            $announcement['title'],
            strip_tags($announcement['message']),
            home_url('/rental-gates/dashboard/announcements/' . $announcement['id'])
        );
        
        wp_mail($recipient['email'], $subject, $message);
    }
    
    /**
     * Mark announcement as read by user
     */
    public static function mark_read($announcement_id, $user_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->update(
            $tables['announcement_recipients'],
            array('read_at' => current_time('mysql')),
            array(
                'announcement_id' => $announcement_id,
                'user_id' => $user_id,
            ),
            array('%s'),
            array('%d', '%d')
        );
    }
    
    /**
     * Get announcements for a specific user
     */
    public static function get_for_user($user_id, $limit = 20, $offset = 0) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, ar.delivered_at, ar.read_at
             FROM {$tables['announcements']} a
             JOIN {$tables['announcement_recipients']} ar ON a.id = ar.announcement_id
             WHERE ar.user_id = %d
             ORDER BY ar.delivered_at DESC
             LIMIT %d OFFSET %d",
            $user_id, $limit, $offset
        ), ARRAY_A);
    }
    
    /**
     * Get unread count for user
     */
    public static function get_unread_count($user_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$tables['announcement_recipients']}
             WHERE user_id = %d AND read_at IS NULL",
            $user_id
        ));
    }
    
    /**
     * Update announcement
     */
    public static function update($announcement_id, $data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $announcement = self::get($announcement_id);
        if (!$announcement) {
            return new WP_Error('not_found', __('Announcement not found', 'rental-gates'));
        }
        
        // Can only update unsent announcements
        if ($announcement['sent_at']) {
            return new WP_Error('already_sent', __('Cannot edit sent announcements', 'rental-gates'));
        }
        
        $update_data = array('updated_at' => current_time('mysql'));
        $formats = array('%s');
        
        if (isset($data['title'])) {
            $update_data['title'] = sanitize_text_field($data['title']);
            $formats[] = '%s';
        }
        if (isset($data['message'])) {
            $update_data['message'] = wp_kses_post($data['message']);
            $formats[] = '%s';
        }
        if (isset($data['audience_type'])) {
            $update_data['audience_type'] = $data['audience_type'];
            $formats[] = '%s';
        }
        if (isset($data['audience_ids'])) {
            $update_data['audience_ids'] = $data['audience_ids'] ? wp_json_encode($data['audience_ids']) : null;
            $formats[] = '%s';
        }
        if (isset($data['delivery'])) {
            $update_data['delivery'] = $data['delivery'];
            $formats[] = '%s';
        }
        if (isset($data['scheduled_at'])) {
            $update_data['scheduled_at'] = $data['scheduled_at'];
            $formats[] = '%s';
        }
        if (isset($data['channels'])) {
            $update_data['channels'] = $data['channels'];
            $formats[] = '%s';
        }
        
        $result = $wpdb->update(
            $tables['announcements'],
            $update_data,
            array('id' => $announcement_id),
            $formats,
            array('%d')
        );
        
        return $result !== false ? self::get($announcement_id) : new WP_Error('db_error', __('Failed to update', 'rental-gates'));
    }
    
    /**
     * Delete announcement
     */
    public static function delete($announcement_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Delete recipients first
        $wpdb->delete($tables['announcement_recipients'], array('announcement_id' => $announcement_id), array('%d'));
        
        // Delete announcement
        return $wpdb->delete($tables['announcements'], array('id' => $announcement_id), array('%d'));
    }
    
    /**
     * Get scheduled announcements ready to send
     */
    public static function get_due_scheduled() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$tables['announcements']}
             WHERE delivery = 'scheduled'
               AND sent_at IS NULL
               AND scheduled_at <= %s",
            current_time('mysql')
        ), ARRAY_A);
    }
}
