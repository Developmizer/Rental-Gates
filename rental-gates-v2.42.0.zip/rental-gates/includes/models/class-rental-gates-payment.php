<?php
/**
 * Rental Gates Payment Model
 * 
 * Handles payment management including CRUD operations,
 * payment tracking, and financial reporting.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Payment {
    
    private static $table_name;
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['payments'];
        }
    }
    
    /**
     * Generate unique payment number
     */
    private static function generate_payment_number($org_id) {
        global $wpdb;
        self::init();
        
        $prefix = 'PAY';
        $year = date('y');
        
        // Get the last payment number for this org
        $last = $wpdb->get_var($wpdb->prepare(
            "SELECT payment_number FROM " . self::$table_name . " 
             WHERE organization_id = %d AND payment_number LIKE %s 
             ORDER BY id DESC LIMIT 1",
            $org_id, $prefix . $year . '%'
        ));
        
        if ($last) {
            $num = intval(substr($last, -5)) + 1;
        } else {
            $num = 1;
        }
        
        return $prefix . $year . str_pad($num, 5, '0', STR_PAD_LEFT);
    }
    
    /**
     * Create a new payment
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate required fields
        $required = array('organization_id', 'amount');
        foreach ($required as $field) {
            if (!isset($data[$field]) || $data[$field] === '') {
                return new WP_Error('missing_field', sprintf(__('Missing required field: %s', 'rental-gates'), $field));
            }
        }
        
        // Generate payment number
        $payment_number = self::generate_payment_number($data['organization_id']);
        
        // Calculate net amount
        $amount = floatval($data['amount']);
        $platform_fee = floatval($data['platform_fee'] ?? 0);
        $stripe_fee = floatval($data['stripe_fee'] ?? 0);
        $net_amount = $amount - $platform_fee - $stripe_fee;
        
        // Prepare insert data
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'lease_id' => !empty($data['lease_id']) ? intval($data['lease_id']) : null,
            'tenant_id' => !empty($data['tenant_id']) ? intval($data['tenant_id']) : null,
            'paid_by_user_id' => !empty($data['paid_by_user_id']) ? intval($data['paid_by_user_id']) : null,
            'payment_number' => $payment_number,
            'type' => in_array($data['type'] ?? '', array('rent', 'deposit', 'late_fee', 'damage', 'other', 'refund')) 
                ? $data['type'] : 'rent',
            'method' => in_array($data['method'] ?? '', array('stripe_card', 'stripe_ach', 'stripe_visa', 'stripe_mastercard', 'stripe_amex', 'stripe_discover', 'stripe', 'cash', 'check', 'money_order', 'other', 'external')) 
                ? $data['method'] : 'other',
            'stripe_payment_intent_id' => sanitize_text_field($data['stripe_payment_intent_id'] ?? ''),
            'stripe_charge_id' => sanitize_text_field($data['stripe_charge_id'] ?? ''),
            'amount' => $amount,
            'amount_paid' => floatval($data['amount_paid'] ?? 0),
            'platform_fee' => $platform_fee,
            'stripe_fee' => $stripe_fee,
            'net_amount' => $net_amount,
            'currency' => strtoupper(sanitize_text_field($data['currency'] ?? 'USD')),
            'status' => in_array($data['status'] ?? '', array('pending', 'processing', 'succeeded', 'partially_paid', 'failed', 'refunded', 'cancelled')) 
                ? $data['status'] : 'pending',
            'due_date' => !empty($data['due_date']) ? sanitize_text_field($data['due_date']) : null,
            'paid_at' => !empty($data['paid_at']) ? sanitize_text_field($data['paid_at']) : null,
            'period_start' => !empty($data['period_start']) ? sanitize_text_field($data['period_start']) : null,
            'period_end' => !empty($data['period_end']) ? sanitize_text_field($data['period_end']) : null,
            'description' => sanitize_text_field($data['description'] ?? ''),
            'notes' => sanitize_textarea_field($data['notes'] ?? ''),
            'is_prorated' => !empty($data['is_prorated']) ? 1 : 0,
            'proration_days' => !empty($data['proration_days']) ? intval($data['proration_days']) : null,
            'meta_data' => isset($data['meta_data']) ? (is_string($data['meta_data']) ? $data['meta_data'] : json_encode($data['meta_data'])) : null,
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating payment', 'rental-gates'));
        }
        
        $payment_id = $wpdb->insert_id;
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('payments_org_' . $data['organization_id']);
            Rental_Gates_Cache::delete_stats($data['organization_id'], 'payments');
            Rental_Gates_Cache::delete_stats($data['organization_id'], 'dashboard');
        }
        
        return self::get($payment_id);
    }
    
    /**
     * Get payment by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$payment) {
            return null;
        }
        
        return self::format_payment($payment);
    }
    
    /**
     * Get payment by payment number
     */
    public static function get_by_number($payment_number) {
        global $wpdb;
        self::init();
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE payment_number = %s",
            $payment_number
        ), ARRAY_A);
        
        if (!$payment) {
            return null;
        }
        
        return self::format_payment($payment);
    }
    
    /**
     * Get payment with full details (lease, tenant, unit)
     */
    public static function get_with_details($id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT p.*, 
                    l.start_date as lease_start, l.end_date as lease_end, l.rent_amount as lease_rent,
                    u.name as unit_name, u.building_id,
                    b.name as building_name,
                    t.first_name as tenant_first_name, t.last_name as tenant_last_name, t.email as tenant_email
             FROM " . self::$table_name . " p
             LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
             LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
             LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
             LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id
             WHERE p.id = %d",
            $id
        ), ARRAY_A);
        
        if (!$payment) {
            return null;
        }
        
        $formatted = self::format_payment($payment);
        
        // Add tenant full name
        if (!empty($payment['tenant_first_name'])) {
            $formatted['tenant_name'] = $payment['tenant_first_name'] . ' ' . $payment['tenant_last_name'];
        }
        
        return $formatted;
    }
    
    /**
     * Get payments for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => null,
            'type' => null,
            'lease_id' => null,
            'tenant_id' => null,
            'search' => null,
            'date_from' => null,
            'date_to' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('p.organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "p.status IN ($placeholders)";
                $params = array_merge($params, $args['status']);
            } else {
                $where[] = 'p.status = %s';
                $params[] = $args['status'];
            }
        }
        
        if ($args['type']) {
            $where[] = 'p.type = %s';
            $params[] = $args['type'];
        }
        
        if ($args['lease_id']) {
            $where[] = 'p.lease_id = %d';
            $params[] = $args['lease_id'];
        }
        
        if ($args['tenant_id']) {
            $where[] = 'p.tenant_id = %d';
            $params[] = $args['tenant_id'];
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(p.payment_number LIKE %s OR t.first_name LIKE %s OR t.last_name LIKE %s OR u.name LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        if ($args['date_from']) {
            $where[] = 'p.created_at >= %s';
            $params[] = $args['date_from'] . ' 00:00:00';
        }
        
        if ($args['date_to']) {
            $where[] = 'p.created_at <= %s';
            $params[] = $args['date_to'] . ' 23:59:59';
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'due_date', 'amount', 'status', 'paid_at')) 
            ? 'p.' . $args['orderby'] : 'p.created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT p.*, 
                       u.name as unit_name, u.building_id,
                       b.name as building_name,
                       t.first_name as tenant_first_name, t.last_name as tenant_last_name
                FROM " . self::$table_name . " p
                LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
                LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
                LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
                LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $payments = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(function($p) {
            $formatted = self::format_payment($p);
            if (!empty($p['tenant_first_name'])) {
                $formatted['tenant_name'] = $p['tenant_first_name'] . ' ' . $p['tenant_last_name'];
            }
            return $formatted;
        }, $payments);
    }
    
    /**
     * Get payments for lease
     */
    public static function get_for_lease($lease_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'status' => null,
            'orderby' => 'due_date',
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('lease_id = %d');
        $params = array($lease_id);
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'due_date', 'amount')) 
            ? $args['orderby'] : 'due_date';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}";
        
        $payments = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_payment'), $payments);
    }
    
    /**
     * Count payments for organization
     */
    public static function count_for_organization($org_id, $status = null) {
        global $wpdb;
        self::init();
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($status) {
            if (is_array($status)) {
                $placeholders = implode(',', array_fill(0, count($status), '%s'));
                $sql .= " AND status IN ($placeholders)";
                $params = array_merge($params, $status);
            } else {
                $sql .= " AND status = %s";
                $params[] = $status;
            }
        }
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Update payment
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $payment = self::get($id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        $update_data = array();
        
        $allowed_fields = array(
            'type', 'method', 'amount', 'amount_paid', 'status', 'due_date', 
            'paid_at', 'period_start', 'period_end', 'description', 'notes',
            'stripe_payment_intent_id', 'stripe_charge_id', 'receipt_url', 'failure_reason'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                switch ($field) {
                    case 'amount':
                    case 'amount_paid':
                        $update_data[$field] = floatval($data[$field]);
                        break;
                    case 'notes':
                    case 'description':
                    case 'failure_reason':
                        $update_data[$field] = sanitize_textarea_field($data[$field]);
                        break;
                    case 'type':
                        $valid = array('rent', 'deposit', 'late_fee', 'damage', 'other', 'refund');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    case 'method':
                        $valid = array('stripe_card', 'stripe_ach', 'cash', 'check', 'money_order', 'other', 'external');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    case 'status':
                        $valid = array('pending', 'processing', 'succeeded', 'partially_paid', 'failed', 'refunded', 'cancelled');
                        if (in_array($data[$field], $valid)) {
                            $update_data[$field] = $data[$field];
                        }
                        break;
                    default:
                        $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $payment;
        }
        
        $update_data['updated_at'] = current_time('mysql');
        
        // Update paid_at and amount_paid when marking as succeeded
        if (isset($update_data['status']) && $update_data['status'] === 'succeeded') {
            // Set paid_at if not already set
            if (empty($payment['paid_at'])) {
                $update_data['paid_at'] = current_time('mysql');
            }
            // Always ensure amount_paid is set correctly when succeeding (fixes $0 bug)
            // Only set if not explicitly provided in update data
            if (!isset($data['amount_paid']) || floatval($data['amount_paid']) <= 0) {
                $update_data['amount_paid'] = $payment['amount'];
            }
        }
        
        // Recalculate net amount if amount changed
        if (isset($update_data['amount'])) {
            $update_data['net_amount'] = floatval($update_data['amount']) - $payment['platform_fee'] - $payment['stripe_fee'];
        }
        
        $result = $wpdb->update(self::$table_name, $update_data, array('id' => $id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating payment', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('payments_org_' . $payment['organization_id']);
            Rental_Gates_Cache::delete_stats($payment['organization_id'], 'payments');
            Rental_Gates_Cache::delete_stats($payment['organization_id'], 'dashboard');
        }
        
        return self::get($id);
    }
    
    /**
     * Delete payment
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        $payment = self::get($id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        // Only allow deleting pending payments
        if (!in_array($payment['status'], array('pending', 'cancelled'))) {
            return new WP_Error('cannot_delete', __('Can only delete pending or cancelled payments', 'rental-gates'));
        }
        
        $wpdb->delete(self::$table_name, array('id' => $id));
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('payments_org_' . $payment['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Mark payment as paid
     * Also generates a receipt automatically
     */
    public static function mark_paid($id, $method = null, $notes = '', $options = array()) {
        $payment = self::get($id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        // Prevent double-processing
        if ($payment['status'] === 'succeeded' && $payment['amount_paid'] >= $payment['amount']) {
            return $payment; // Already paid
        }
        
        $data = array(
            'status' => 'succeeded',
            'amount_paid' => $payment['amount'], // Explicitly set full amount
            'paid_at' => current_time('mysql'),
        );
        
        if ($method) {
            $data['method'] = $method;
        }
        
        if ($notes) {
            $data['notes'] = $payment['notes'] ? $payment['notes'] . "\n" . $notes : $notes;
        }
        
        $result = self::update($id, $data);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Generate receipt automatically
        if (!isset($options['skip_receipt']) || !$options['skip_receipt']) {
            if (class_exists('Rental_Gates_Invoice')) {
                Rental_Gates_Invoice::create_from_payment($id, 'receipt');
            }
        }
        
        // Clear all relevant caches
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::delete('payment_' . $id);
            Rental_Gates_Cache::delete('payments_org_' . $payment['organization_id']);
            if ($payment['tenant_id']) {
                Rental_Gates_Cache::delete('payments_tenant_' . $payment['tenant_id']);
            }
        }
        
        return $result;
    }
    
    /**
     * Mark payment as failed
     */
    public static function mark_failed($id, $reason = '') {
        return self::update($id, array(
            'status' => 'failed',
            'failure_reason' => $reason,
        ));
    }
    
    /**
     * Cancel payment
     */
    public static function cancel($id) {
        $payment = self::get($id);
        if (!$payment) {
            return new WP_Error('not_found', __('Payment not found', 'rental-gates'));
        }
        
        if ($payment['status'] === 'succeeded') {
            return new WP_Error('cannot_cancel', __('Cannot cancel a completed payment', 'rental-gates'));
        }
        
        return self::update($id, array('status' => 'cancelled'));
    }
    
    /**
     * Get overdue payments for organization
     */
    public static function get_overdue($org_id) {
        global $wpdb;
        self::init();
        
        $today = date('Y-m-d');
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             AND status IN ('pending', 'partially_paid') 
             AND due_date < %s
             ORDER BY due_date ASC",
            $org_id, $today
        ), ARRAY_A);
    }
    
    /**
     * Get payment statistics for organization
     */
    public static function get_stats($org_id, $period = 'month') {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total_collected' => 0,
            'total_pending' => 0,
            'total_overdue' => 0,
            'count_succeeded' => 0,
            'count_pending' => 0,
            'count_overdue' => 0,
            'count_failed' => 0,
        );
        
        // Date range
        switch ($period) {
            case 'week':
                $start_date = date('Y-m-d', strtotime('-7 days'));
                break;
            case 'year':
                $start_date = date('Y-01-01');
                break;
            case 'month':
            default:
                $start_date = date('Y-m-01');
        }
        
        // Collected this period
        $stats['total_collected'] = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount_paid), 0) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status = 'succeeded' AND paid_at >= %s",
            $org_id, $start_date
        )));
        
        // Pending payments
        $pending = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) as count, COALESCE(SUM(amount - amount_paid), 0) as total 
             FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status IN ('pending', 'partially_paid')",
            $org_id
        ), ARRAY_A);
        $stats['count_pending'] = intval($pending['count']);
        $stats['total_pending'] = floatval($pending['total']);
        
        // Overdue payments
        $today = date('Y-m-d');
        $overdue = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) as count, COALESCE(SUM(amount - amount_paid), 0) as total 
             FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status IN ('pending', 'partially_paid') AND due_date < %s",
            $org_id, $today
        ), ARRAY_A);
        $stats['count_overdue'] = intval($overdue['count']);
        $stats['total_overdue'] = floatval($overdue['total']);
        
        // Succeeded count
        $stats['count_succeeded'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status = 'succeeded' AND paid_at >= %s",
            $org_id, $start_date
        )));
        
        // Failed count
        $stats['count_failed'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND status = 'failed' AND created_at >= %s",
            $org_id, $start_date
        )));
        
        return $stats;
    }
    
    /**
     * Get type label
     */
    public static function get_type_label($type) {
        $labels = array(
            'rent' => __('Rent', 'rental-gates'),
            'deposit' => __('Deposit', 'rental-gates'),
            'late_fee' => __('Late Fee', 'rental-gates'),
            'damage' => __('Damage', 'rental-gates'),
            'other' => __('Other', 'rental-gates'),
            'refund' => __('Refund', 'rental-gates'),
        );
        
        return $labels[$type] ?? $type;
    }
    
    /**
     * Get method label
     */
    public static function get_method_label($method) {
        $labels = array(
            'stripe_card' => __('Credit Card', 'rental-gates'),
            'stripe_ach' => __('Bank Transfer', 'rental-gates'),
            'cash' => __('Cash', 'rental-gates'),
            'check' => __('Check', 'rental-gates'),
            'money_order' => __('Money Order', 'rental-gates'),
            'other' => __('Other', 'rental-gates'),
            'external' => __('External', 'rental-gates'),
        );
        
        return $labels[$method] ?? $method;
    }
    
    /**
     * Format payment data
     */
    private static function format_payment($payment) {
        if (!$payment) return null;
        
        $payment['id'] = intval($payment['id']);
        $payment['organization_id'] = intval($payment['organization_id']);
        $payment['lease_id'] = $payment['lease_id'] ? intval($payment['lease_id']) : null;
        $payment['tenant_id'] = $payment['tenant_id'] ? intval($payment['tenant_id']) : null;
        $payment['paid_by_user_id'] = $payment['paid_by_user_id'] ? intval($payment['paid_by_user_id']) : null;
        $payment['amount'] = floatval($payment['amount']);
        $payment['amount_paid'] = floatval($payment['amount_paid']);
        $payment['platform_fee'] = floatval($payment['platform_fee']);
        $payment['stripe_fee'] = floatval($payment['stripe_fee']);
        $payment['net_amount'] = floatval($payment['net_amount']);
        $payment['is_prorated'] = (bool) $payment['is_prorated'];
        $payment['proration_days'] = $payment['proration_days'] ? intval($payment['proration_days']) : null;
        
        // Add labels
        $payment['type_label'] = self::get_type_label($payment['type']);
        $payment['method_label'] = self::get_method_label($payment['method']);
        
        // Calculate balance
        $payment['balance'] = $payment['amount'] - $payment['amount_paid'];
        
        // Check if overdue
        if ($payment['due_date'] && in_array($payment['status'], array('pending', 'partially_paid'))) {
            $payment['is_overdue'] = strtotime($payment['due_date']) < strtotime('today');
            if ($payment['is_overdue']) {
                $due = new DateTime($payment['due_date']);
                $now = new DateTime();
                $payment['days_overdue'] = $now->diff($due)->days;
            } else {
                $payment['days_overdue'] = 0;
            }
        } else {
            $payment['is_overdue'] = false;
            $payment['days_overdue'] = 0;
        }
        
        // Parse meta data
        if (!empty($payment['meta_data'])) {
            $payment['meta_data'] = json_decode($payment['meta_data'], true);
        } else {
            $payment['meta_data'] = array();
        }
        
        return $payment;
    }
    
    /**
     * Get payments for a specific tenant
     * Retrieves all payments linked to a tenant by tenant_id or via their leases
     */
    public static function get_for_tenant($tenant_id, $args = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => null,
            'limit' => 50,
            'order' => 'DESC',
        );
        $args = wp_parse_args($args, $defaults);
        
        $where = array('(p.tenant_id = %d OR lt.tenant_id = %d)');
        $params = array($tenant_id, $tenant_id);
        
        if ($args['status']) {
            if (is_array($args['status'])) {
                $placeholders = implode(',', array_fill(0, count($args['status']), '%s'));
                $where[] = "p.status IN ($placeholders)";
                $params = array_merge($params, $args['status']);
            } else {
                $where[] = 'p.status = %s';
                $params[] = $args['status'];
            }
        }
        
        $where_clause = implode(' AND ', $where);
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        $limit = intval($args['limit']);
        
        $sql = "SELECT DISTINCT p.*, 
                       l.rent_amount as lease_rent, l.unit_id,
                       u.unit_number, u.name as unit_name, 
                       b.name as building_name,
                       t.first_name as tenant_first_name, t.last_name as tenant_last_name
                FROM " . self::$table_name . " p
                LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
                LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id
                LEFT JOIN {$tables['units']} u ON l.unit_id = u.id
                LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id
                LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id
                WHERE {$where_clause}
                ORDER BY COALESCE(p.due_date, p.created_at) {$order}
                LIMIT {$limit}";
        
        $results = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        if (!$results) {
            return array();
        }
        
        return array_map(array(__CLASS__, 'format_payment'), $results);
    }
    
    /**
     * Generate a rent payment for a lease
     * Creates a pending payment record that tenants can then pay
     */
    public static function generate_rent_payment($lease_id, $due_date = null, $options = array()) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        // Get lease with details
        $lease = $wpdb->get_row($wpdb->prepare(
            "SELECT l.*, u.name as unit_name, u.unit_number
             FROM {$tables['leases']} l
             JOIN {$tables['units']} u ON l.unit_id = u.id
             WHERE l.id = %d AND l.status = 'active'",
            $lease_id
        ), ARRAY_A);
        
        if (!$lease) {
            return new WP_Error('not_found', __('Active lease not found', 'rental-gates'));
        }
        
        // Get primary tenant
        $tenant = $wpdb->get_row($wpdb->prepare(
            "SELECT t.* FROM {$tables['tenants']} t
             JOIN {$tables['lease_tenants']} lt ON t.id = lt.tenant_id
             WHERE lt.lease_id = %d AND lt.is_primary = 1
             LIMIT 1",
            $lease_id
        ), ARRAY_A);
        
        // If no primary, get first tenant
        if (!$tenant) {
            $tenant = $wpdb->get_row($wpdb->prepare(
                "SELECT t.* FROM {$tables['tenants']} t
                 JOIN {$tables['lease_tenants']} lt ON t.id = lt.tenant_id
                 WHERE lt.lease_id = %d
                 ORDER BY lt.id LIMIT 1",
                $lease_id
            ), ARRAY_A);
        }
        
        if (!$tenant) {
            return new WP_Error('no_tenant', __('No tenant found for this lease', 'rental-gates'));
        }
        
        // Calculate due date and period
        if (!$due_date) {
            $rent_due_day = intval($lease['rent_due_day'] ?? 1);
            $due_date = date('Y-m-' . str_pad($rent_due_day, 2, '0', STR_PAD_LEFT));
            
            // If past due day this month, set for next month
            if (strtotime($due_date) < strtotime('today')) {
                $due_date = date('Y-m-d', strtotime($due_date . ' +1 month'));
            }
        }
        
        // Calculate period (month of due date)
        $period_start = date('Y-m-01', strtotime($due_date));
        $period_end = date('Y-m-t', strtotime($due_date));
        
        // Check if payment already exists for this period
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::$table_name . "
             WHERE lease_id = %d AND type = 'rent'
             AND period_start = %s AND status NOT IN ('cancelled', 'refunded')
             LIMIT 1",
            $lease_id, $period_start
        ));
        
        if ($existing && empty($options['force'])) {
            return new WP_Error('exists', __('A rent payment already exists for this period', 'rental-gates'));
        }
        
        // Create payment
        $payment_data = array(
            'organization_id' => $lease['organization_id'],
            'lease_id' => $lease_id,
            'tenant_id' => $tenant['id'],
            'type' => 'rent',
            'amount' => floatval($lease['rent_amount']),
            'status' => 'pending',
            'due_date' => $due_date,
            'period_start' => $period_start,
            'period_end' => $period_end,
            'description' => sprintf(
                __('Rent for %s - %s', 'rental-gates'),
                $lease['unit_name'] ?: $lease['unit_number'],
                date('F Y', strtotime($period_start))
            ),
        );
        
        return self::create($payment_data);
    }
    
    /**
     * Generate monthly rent payments for all active leases in an organization
     * Called by cron or manually from dashboard
     */
    public static function generate_monthly_payments($org_id, $for_month = null) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        // Determine the month to generate for
        if (!$for_month) {
            $for_month = date('Y-m');
        }
        
        $period_start = $for_month . '-01';
        
        // Get all active leases
        $leases = $wpdb->get_results($wpdb->prepare(
            "SELECT l.id, l.rent_amount, l.rent_due_day, l.organization_id
             FROM {$tables['leases']} l
             WHERE l.organization_id = %d 
             AND l.status = 'active'
             AND l.start_date <= %s
             AND (l.end_date IS NULL OR l.end_date >= %s)",
            $org_id, $period_start, $period_start
        ), ARRAY_A);
        
        $generated = 0;
        $skipped = 0;
        $errors = array();
        
        foreach ($leases as $lease) {
            $rent_due_day = intval($lease['rent_due_day'] ?? 1);
            $due_date = $for_month . '-' . str_pad($rent_due_day, 2, '0', STR_PAD_LEFT);
            
            $result = self::generate_rent_payment($lease['id'], $due_date);
            
            if (is_wp_error($result)) {
                if ($result->get_error_code() === 'exists') {
                    $skipped++;
                } else {
                    $errors[] = $result->get_error_message();
                }
            } else {
                $generated++;
            }
        }
        
        return array(
            'generated' => $generated,
            'skipped' => $skipped,
            'errors' => $errors,
            'total_leases' => count($leases),
        );
    }
    
    /**
     * Check if tenant has any pending payments
     */
    public static function has_pending_payments($tenant_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " p
             LEFT JOIN {$tables['leases']} l ON p.lease_id = l.id
             LEFT JOIN {$tables['lease_tenants']} lt ON l.id = lt.lease_id
             WHERE (p.tenant_id = %d OR lt.tenant_id = %d)
             AND p.status IN ('pending', 'partially_paid', 'failed')",
            $tenant_id, $tenant_id
        ));
        
        return $count > 0;
    }
}
