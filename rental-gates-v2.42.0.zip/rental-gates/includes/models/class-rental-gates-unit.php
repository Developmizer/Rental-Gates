<?php
/**
 * Rental Gates Unit Model
 * Handles unit data, availability state machine, and operations
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Unit {
    
    /**
     * Availability states
     */
    const AVAILABILITY_STATES = array(
        'available',      // Ready for rent
        'coming_soon',    // Available within X days
        'occupied',       // Has active lease
        'renewal_pending', // Lease ending, renewal offered
        'unlisted',       // Hidden from public
    );
    
    private static $table_name;
    
    public static function init() {
        $tables = Rental_Gates_Database::get_table_names();
        self::$table_name = $tables['units'];
    }
    
    /**
     * Create a new unit
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Validate building exists
        $building = Rental_Gates_Building::get($data['building_id']);
        if (!$building) {
            return new WP_Error('invalid_building', __('Building not found', 'rental-gates'));
        }
        
        // Generate slug
        $slug = self::generate_unique_slug($data['name'], $data['building_id']);
        
        // Handle gallery - use NULL for empty
        $gallery = null;
        if (isset($data['gallery']) && !empty($data['gallery']) && $data['gallery'] !== '[]') {
            $gallery = is_array($data['gallery']) ? wp_json_encode($data['gallery']) : $data['gallery'];
        }
        
        // Handle amenities - use NULL for empty
        $amenities = null;
        if (isset($data['amenities']) && !empty($data['amenities']) && $data['amenities'] !== '[]') {
            $amenities = is_array($data['amenities']) ? wp_json_encode($data['amenities']) : $data['amenities'];
        }
        
        // Handle availability
        $availability = isset($data['availability']) ? sanitize_text_field($data['availability']) : 'available';
        if (!in_array($availability, self::AVAILABILITY_STATES)) {
            $availability = 'available';
        }
        
        $insert_data = array(
            'organization_id' => $building['organization_id'],
            'building_id' => intval($data['building_id']),
            'name' => sanitize_text_field($data['name']),
            'slug' => $slug,
            'unit_type' => isset($data['unit_type']) ? sanitize_text_field($data['unit_type']) : null,
            'description' => isset($data['description']) ? wp_kses_post($data['description']) : '',
            'rent_amount' => floatval($data['rent_amount'] ?? 0),
            'deposit_amount' => isset($data['deposit_amount']) && $data['deposit_amount'] !== '' ? floatval($data['deposit_amount']) : null,
            'availability' => $availability,
            'available_from' => isset($data['available_from']) && !empty($data['available_from']) ? sanitize_text_field($data['available_from']) : null,
            'bedrooms' => isset($data['bedrooms']) ? intval($data['bedrooms']) : 0,
            'bathrooms' => isset($data['bathrooms']) ? floatval($data['bathrooms']) : 0,
            'living_rooms' => isset($data['living_rooms']) ? intval($data['living_rooms']) : 0,
            'kitchens' => isset($data['kitchens']) ? intval($data['kitchens']) : 1,
            'parking_spots' => isset($data['parking_spots']) ? intval($data['parking_spots']) : 0,
            'square_footage' => isset($data['square_footage']) && $data['square_footage'] !== '' ? intval($data['square_footage']) : null,
            'amenities' => $amenities,
            'gallery' => $gallery,
            'featured_image' => isset($data['featured_image']) && $data['featured_image'] ? intval($data['featured_image']) : null,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            error_log('Rental Gates: Failed to create unit. DB Error: ' . $wpdb->last_error);
            return new WP_Error('db_error', __('Failed to create unit', 'rental-gates') . ': ' . $wpdb->last_error);
        }
        
        $unit_id = $wpdb->insert_id;
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::clear_unit_cache($unit_id, $data['building_id'], $building['organization_id']);
        }
        
        return self::get($unit_id);
    }
    
    /**
     * Get unit by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $unit = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$unit) {
            return null;
        }
        
        return self::format_unit($unit);
    }
    
    /**
     * Get unit by slug within a building
     */
    public static function get_by_slug($unit_slug, $building_slug) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $unit = $wpdb->get_row($wpdb->prepare(
            "SELECT u.* FROM " . self::$table_name . " u
             JOIN {$tables['buildings']} b ON u.building_id = b.id
             WHERE u.slug = %s AND b.slug = %s",
            $unit_slug, $building_slug
        ), ARRAY_A);
        
        if (!$unit) {
            return null;
        }
        
        return self::format_unit($unit);
    }
    
    /**
     * Get units for building
     */
    public static function get_for_building($building_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'availability' => null,
            'orderby' => 'name',
            'order' => 'ASC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('building_id = %d');
        $values = array($building_id);
        
        if ($args['availability']) {
            $where[] = 'availability = %s';
            $values[] = $args['availability'];
        }
        
        $where_clause = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'name ASC';
        
        $query = $wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE {$where_clause} ORDER BY {$orderby}",
            $values
        );
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        $units = array();
        foreach ($results as $row) {
            $units[] = self::format_unit($row);
        }
        
        return $units;
    }
    
    /**
     * Alias for get_for_building
     */
    public static function get_by_building($building_id, $args = array()) {
        return self::get_for_building($building_id, $args);
    }
    
    /**
     * Update unit
     */
    public static function update($unit_id, $data) {
        global $wpdb;
        self::init();
        
        $unit = self::get($unit_id);
        if (!$unit) {
            return new WP_Error('not_found', __('Unit not found', 'rental-gates'));
        }
        
        $update_data = array(
            'updated_at' => current_time('mysql'),
        );
        
        // Updatable fields
        $allowed_fields = array(
            'name', 'unit_type', 'description', 'rent_amount', 'deposit_amount',
            'availability', 'available_from', 'bedrooms', 'bathrooms',
            'living_rooms', 'kitchens', 'parking_spots', 'square_footage',
            'featured_image'
        );
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                if (in_array($field, array('rent_amount', 'deposit_amount'))) {
                    $update_data[$field] = $data[$field] !== '' ? floatval($data[$field]) : null;
                } elseif (in_array($field, array('bedrooms', 'living_rooms', 'kitchens', 'parking_spots', 'square_footage', 'featured_image'))) {
                    $update_data[$field] = $data[$field] !== '' ? intval($data[$field]) : null;
                } elseif ($field === 'bathrooms') {
                    $update_data[$field] = floatval($data[$field]);
                } elseif ($field === 'available_from') {
                    $update_data[$field] = !empty($data[$field]) ? sanitize_text_field($data[$field]) : null;
                } elseif ($field === 'availability') {
                    $availability = sanitize_text_field($data[$field]);
                    if (in_array($availability, self::AVAILABILITY_STATES)) {
                        $update_data[$field] = $availability;
                    }
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        // Handle gallery
        if (isset($data['gallery'])) {
            if (empty($data['gallery']) || $data['gallery'] === '[]') {
                $update_data['gallery'] = null;
            } else {
                $update_data['gallery'] = is_array($data['gallery']) ? wp_json_encode($data['gallery']) : $data['gallery'];
            }
        }
        
        // Handle amenities
        if (isset($data['amenities'])) {
            if (empty($data['amenities']) || $data['amenities'] === '[]') {
                $update_data['amenities'] = null;
            } else {
                $update_data['amenities'] = is_array($data['amenities']) ? wp_json_encode($data['amenities']) : $data['amenities'];
            }
        }
        
        // Generate new slug if name changed
        if (isset($data['name']) && $data['name'] !== $unit['name']) {
            $update_data['slug'] = self::generate_unique_slug($data['name'], $unit['building_id'], $unit_id);
        }
        
        $result = $wpdb->update(
            self::$table_name,
            $update_data,
            array('id' => $unit_id)
        );
        
        if ($result === false) {
            error_log('Rental Gates: Failed to update unit. DB Error: ' . $wpdb->last_error);
            return new WP_Error('db_error', __('Failed to update unit', 'rental-gates') . ': ' . $wpdb->last_error);
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::clear_unit_cache($unit_id, $unit['building_id'], $unit['organization_id']);
        }
        
        return self::get($unit_id);
    }
    
    /**
     * Delete unit
     */
    public static function delete($unit_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $unit = self::get($unit_id);
        if (!$unit) {
            return new WP_Error('not_found', __('Unit not found', 'rental-gates'));
        }
        
        // Check for active leases
        $active_lease = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leases']} WHERE unit_id = %d AND status IN ('active', 'ending')",
            $unit_id
        ));
        
        if ($active_lease > 0) {
            return new WP_Error('has_active_lease', __('Cannot delete unit with active lease', 'rental-gates'));
        }
        
        // Delete related records
        $wpdb->delete($tables['applications'], array('unit_id' => $unit_id));
        
        // Delete the unit
        $result = $wpdb->delete(self::$table_name, array('id' => $unit_id));
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to delete unit', 'rental-gates'));
        }
        
        // Clear cache
        if (class_exists('Rental_Gates_Cache')) {
            Rental_Gates_Cache::clear_unit_cache($unit_id, $unit['building_id'], $unit['organization_id']);
        }
        
        return true;
    }
    
    /**
     * Update availability state based on rules
     */
    public static function update_availability_state($unit_id) {
        global $wpdb;
        self::init();
        $tables = Rental_Gates_Database::get_table_names();
        
        $unit = self::get($unit_id);
        if (!$unit || $unit['availability_override']) {
            return; // Don't auto-update if manually overridden
        }
        
        // Check for active lease
        $active_lease = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['leases']} 
             WHERE unit_id = %d AND status IN ('active', 'ending') 
             ORDER BY end_date DESC LIMIT 1",
            $unit_id
        ), ARRAY_A);
        
        $new_state = 'available';
        $available_from = null;
        
        if ($active_lease) {
            if ($active_lease['status'] === 'ending') {
                // Check for pending renewal
                $pending_renewal = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$tables['renewals']} 
                     WHERE lease_id = %d AND status = 'offered'",
                    $active_lease['id']
                ));
                
                $new_state = $pending_renewal ? 'renewal_pending' : 'occupied';
            } else {
                $new_state = 'occupied';
            }
            
            // Set available_from to day after lease ends
            if ($active_lease['end_date']) {
                $available_from = date('Y-m-d', strtotime($active_lease['end_date'] . ' +1 day'));
            }
        } elseif ($unit['available_from']) {
            // Check if we're in "coming soon" window
            $coming_soon_days = get_option('rental_gates_coming_soon_window', 30);
            $available_date = strtotime($unit['available_from']);
            $today = strtotime('today');
            $diff_days = ($available_date - $today) / 86400;
            
            if ($diff_days > 0 && $diff_days <= $coming_soon_days) {
                $new_state = 'coming_soon';
            } elseif ($diff_days > $coming_soon_days) {
                $new_state = 'unlisted'; // Too far out
            }
        }
        
        // Update if changed
        if ($new_state !== $unit['availability']) {
            $wpdb->update(
                self::$table_name,
                array(
                    'availability' => $new_state,
                    'available_from' => $available_from,
                    'updated_at' => current_time('mysql'),
                ),
                array('id' => $unit_id)
            );
            
            Rental_Gates_Cache::clear_unit_cache($unit_id, $unit['building_id'], $unit['organization_id']);
        }
    }
    
    /**
     * Manually override availability
     */
    public static function set_availability($unit_id, $state, $reason = '') {
        global $wpdb;
        self::init();
        
        if (!in_array($state, self::AVAILABILITY_STATES)) {
            return new WP_Error('invalid_state', __('Invalid availability state', 'rental-gates'));
        }
        
        $unit = self::get($unit_id);
        if (!$unit) {
            return new WP_Error('not_found', __('Unit not found', 'rental-gates'));
        }
        
        $result = $wpdb->update(
            self::$table_name,
            array(
                'availability' => $state,
                'availability_override' => 1,
                'availability_override_reason' => sanitize_text_field($reason),
                'updated_at' => current_time('mysql'),
            ),
            array('id' => $unit_id)
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update availability', 'rental-gates'));
        }
        
        // Log the override
        $tables = Rental_Gates_Database::get_table_names();
        $wpdb->insert($tables['activity_log'], array(
            'user_id' => get_current_user_id(),
            'organization_id' => $unit['organization_id'],
            'action' => 'availability_override',
            'entity_type' => 'unit',
            'entity_id' => $unit_id,
            'old_values' => wp_json_encode(array('availability' => $unit['availability'])),
            'new_values' => wp_json_encode(array('availability' => $state, 'reason' => $reason)),
            'created_at' => current_time('mysql'),
        ));
        
        Rental_Gates_Cache::clear_unit_cache($unit_id, $unit['building_id'], $unit['organization_id']);
        
        return self::get($unit_id);
    }
    
    /**
     * Format unit data
     */
    private static function format_unit($unit) {
        // Handle JSON fields safely
        $unit['amenities'] = !empty($unit['amenities']) ? (json_decode($unit['amenities'], true) ?: array()) : array();
        $unit['gallery'] = !empty($unit['gallery']) ? (json_decode($unit['gallery'], true) ?: array()) : array();
        $unit['custom_counts'] = !empty($unit['custom_counts']) ? (json_decode($unit['custom_counts'], true) ?: array()) : array();
        $unit['meta_data'] = !empty($unit['meta_data']) ? (json_decode($unit['meta_data'], true) ?: array()) : array();
        
        // Handle integer fields
        $unit['id'] = intval($unit['id'] ?? 0);
        $unit['organization_id'] = intval($unit['organization_id'] ?? 0);
        $unit['building_id'] = intval($unit['building_id'] ?? 0);
        $unit['rent_amount'] = floatval($unit['rent_amount'] ?? 0);
        $unit['deposit_amount'] = !empty($unit['deposit_amount']) ? floatval($unit['deposit_amount']) : null;
        $unit['bedrooms'] = intval($unit['bedrooms'] ?? 0);
        $unit['bathrooms'] = floatval($unit['bathrooms'] ?? 0);
        $unit['living_rooms'] = intval($unit['living_rooms'] ?? 0);
        $unit['kitchens'] = intval($unit['kitchens'] ?? 1);
        $unit['parking_spots'] = intval($unit['parking_spots'] ?? 0);
        $unit['square_footage'] = !empty($unit['square_footage']) ? intval($unit['square_footage']) : null;
        $unit['availability_override'] = (bool) ($unit['availability_override'] ?? false);
        
        // Handle unit_type - may not exist in older databases
        $unit['unit_type'] = isset($unit['unit_type']) ? $unit['unit_type'] : '';
        
        // Handle featured image
        if (!empty($unit['featured_image'])) {
            $unit['featured_image_url'] = wp_get_attachment_url($unit['featured_image']);
        } else {
            $unit['featured_image_url'] = null;
        }
        
        return $unit;
    }
    
    /**
     * Generate unique slug
     */
    private static function generate_unique_slug($name, $building_id, $exclude_id = null) {
        global $wpdb;
        self::init();
        
        $slug = sanitize_title($name);
        $original_slug = $slug;
        $counter = 1;
        
        while (true) {
            $query = "SELECT id FROM " . self::$table_name . " WHERE building_id = %d AND slug = %s";
            $values = array($building_id, $slug);
            
            if ($exclude_id) {
                $query .= " AND id != %d";
                $values[] = $exclude_id;
            }
            
            $existing = $wpdb->get_var($wpdb->prepare($query, $values));
            
            if (!$existing) {
                break;
            }
            
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
}
