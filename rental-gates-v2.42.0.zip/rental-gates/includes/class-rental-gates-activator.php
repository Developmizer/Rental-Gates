<?php
/**
 * Rental Gates Activator Class
 * Handles plugin activation tasks
 */

if (!defined('ABSPATH')) {
    exit;
}

class Rental_Gates_Activator {
    
    /**
     * Activate the plugin
     */
    public static function activate() {
        // Check PHP version
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            deactivate_plugins(RENTAL_GATES_PLUGIN_BASENAME);
            wp_die(
                __('Rental Gates requires PHP 8.0 or higher. Please upgrade your PHP version.', 'rental-gates'),
                __('Plugin Activation Error', 'rental-gates'),
                array('back_link' => true)
            );
        }
        
        // Check WordPress version
        global $wp_version;
        if (version_compare($wp_version, '6.0', '<')) {
            deactivate_plugins(RENTAL_GATES_PLUGIN_BASENAME);
            wp_die(
                __('Rental Gates requires WordPress 6.0 or higher. Please upgrade WordPress.', 'rental-gates'),
                __('Plugin Activation Error', 'rental-gates'),
                array('back_link' => true)
            );
        }
        
        // Create database tables
        $database = new Rental_Gates_Database();
        $database->create_tables();
        
        // Create invoice table (separate because it's a new addition)
        if (class_exists('Rental_Gates_Invoice')) {
            Rental_Gates_Invoice::create_table();
        }
        
        // Register roles
        $roles = new Rental_Gates_Roles();
        $roles->register_roles();
        
        // Set default options
        self::set_default_options();
        
        // Create upload directories
        self::create_directories();
        
        // Schedule cron jobs
        self::schedule_cron_jobs();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set activation flag
        update_option('rental_gates_activated', time());
        update_option('rental_gates_version', RENTAL_GATES_VERSION);
        update_option('rental_gates_db_version', RENTAL_GATES_DB_VERSION);
        
        // Log activation
        self::log_activation();
    }
    
    /**
     * Set default options
     */
    private static function set_default_options() {
        $defaults = array(
            'rental_gates_map_provider' => 'google',
            'rental_gates_google_maps_api_key' => '',
            'rental_gates_openstreetmap_tile_server' => '',
            'rental_gates_default_language' => 'en',
            'rental_gates_allow_rtl' => 1,
            'rental_gates_coming_soon_window' => 30,
            'rental_gates_renewal_notice_days' => 60,
            'rental_gates_move_in_notice_days' => 7,
            'rental_gates_enable_ai_tools' => 1,
            'rental_gates_ai_provider' => 'openai',
            'rental_gates_openai_api_key' => '',
            'rental_gates_gemini_api_key' => '',
            'rental_gates_stripe_mode' => 'test',
            'rental_gates_stripe_test_publishable_key' => '',
            'rental_gates_stripe_test_secret_key' => '',
            'rental_gates_stripe_live_publishable_key' => '',
            'rental_gates_stripe_live_secret_key' => '',
            'rental_gates_stripe_webhook_secret' => '',
            'rental_gates_platform_fee_percentage' => 2.5,
            'rental_gates_email_from_name' => get_bloginfo('name'),
            'rental_gates_email_from_address' => get_option('admin_email'),
            'rental_gates_maintenance_categories' => wp_json_encode(array(
                'plumbing' => __('Plumbing', 'rental-gates'),
                'electrical' => __('Electrical', 'rental-gates'),
                'hvac' => __('HVAC', 'rental-gates'),
                'appliance' => __('Appliance', 'rental-gates'),
                'structural' => __('Structural', 'rental-gates'),
                'pest' => __('Pest Control', 'rental-gates'),
                'cleaning' => __('Cleaning', 'rental-gates'),
                'general' => __('General', 'rental-gates'),
                'other' => __('Other', 'rental-gates'),
            )),
            'rental_gates_unit_amenities' => wp_json_encode(array(
                'Air Conditioning',
                'Heating',
                'Washer/Dryer',
                'Dishwasher',
                'Refrigerator',
                'Microwave',
                'Garbage Disposal',
                'Hardwood Floors',
                'Carpet',
                'Tile',
                'Balcony',
                'Patio',
                'Storage',
                'Walk-in Closet',
                'Fireplace',
                'Cable Ready',
                'High-Speed Internet',
                'Pet Friendly',
            )),
            'rental_gates_building_amenities' => wp_json_encode(array(
                'Pool',
                'Gym/Fitness Center',
                'Laundry Room',
                'Parking',
                'Garage',
                'Elevator',
                'Doorman',
                'Security',
                'Package Room',
                'Rooftop',
                'Courtyard',
                'BBQ Area',
                'Business Center',
                'Clubhouse',
                'Playground',
                'Dog Park',
                'Bike Storage',
                'EV Charging',
            )),
        );
        
        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                update_option($key, $value);
            }
        }
    }
    
    /**
     * Create upload directories
     */
    private static function create_directories() {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/rental-gates';
        
        $directories = array(
            $base_dir,
            $base_dir . '/documents',
            $base_dir . '/flyers',
            $base_dir . '/qr-codes',
            $base_dir . '/temp',
        );
        
        foreach ($directories as $dir) {
            if (!file_exists($dir)) {
                wp_mkdir_p($dir);
                
                // Create .htaccess to protect files
                $htaccess = $dir . '/.htaccess';
                if (!file_exists($htaccess) && $dir !== $base_dir) {
                    file_put_contents($htaccess, 'deny from all');
                }
                
                // Create index.php for extra security
                $index = $dir . '/index.php';
                if (!file_exists($index)) {
                    file_put_contents($index, '<?php // Silence is golden');
                }
            }
        }
    }
    
    /**
     * Schedule cron jobs
     */
    private static function schedule_cron_jobs() {
        // Availability check - hourly
        if (!wp_next_scheduled('rental_gates_availability_cron')) {
            wp_schedule_event(time(), 'hourly', 'rental_gates_availability_cron');
        }
        
        // Daily notifications
        if (!wp_next_scheduled('rental_gates_notifications_cron')) {
            wp_schedule_event(time(), 'daily', 'rental_gates_notifications_cron');
        }
        
        // AI credits reset - daily check
        if (!wp_next_scheduled('rental_gates_ai_credits_reset')) {
            wp_schedule_event(time(), 'daily', 'rental_gates_ai_credits_reset');
        }
        
        // Subscription expiration check - hourly
        if (!wp_next_scheduled('rental_gates_subscription_expiration')) {
            wp_schedule_event(time(), 'hourly', 'rental_gates_subscription_expiration');
        }
        
        // Cleanup temp files - weekly
        if (!wp_next_scheduled('rental_gates_cleanup_temp')) {
            wp_schedule_event(time(), 'weekly', 'rental_gates_cleanup_temp');
        }
    }
    
    /**
     * Log activation
     */
    private static function log_activation() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        // Only log if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $tables['activity_log']
        ));
        
        if ($table_exists) {
            $wpdb->insert(
                $tables['activity_log'],
                array(
                    'user_id' => get_current_user_id(),
                    'action' => 'plugin_activated',
                    'new_values' => wp_json_encode(array(
                        'version' => RENTAL_GATES_VERSION,
                        'db_version' => RENTAL_GATES_DB_VERSION,
                        'php_version' => PHP_VERSION,
                        'wp_version' => get_bloginfo('version'),
                    )),
                    'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
                    'created_at' => current_time('mysql'),
                ),
                array('%d', '%s', '%s', '%s', '%s')
            );
        }
    }
}
