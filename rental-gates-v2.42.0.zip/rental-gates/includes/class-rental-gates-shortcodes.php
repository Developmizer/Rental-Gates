<?php
/**
 * Rental Gates Shortcodes
 * 
 * Provides shortcodes for embedding Rental Gates components
 * into WordPress pages and posts.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Shortcodes {
    
    /**
     * Initialize shortcodes
     */
    public static function init() {
        // Landing page shortcode
        add_shortcode('rental_gates_landing', array(__CLASS__, 'render_landing_page'));
        
        // Property search shortcode
        add_shortcode('rental_gates_search', array(__CLASS__, 'render_property_search'));
        
        // Single property shortcode
        add_shortcode('rental_gates_property', array(__CLASS__, 'render_property'));
        
        // Application form shortcode
        add_shortcode('rental_gates_apply', array(__CLASS__, 'render_application_form'));
        
        // Auto-render landing page on designated home page (for non-full-page mode)
        add_filter('the_content', array(__CLASS__, 'maybe_render_landing_page'), 1);
        
        // Intercept VERY early for full-page standalone landing
        add_action('template_redirect', array(__CLASS__, 'maybe_override_template'), -999);
    }
    
    /**
     * Render landing page shortcode
     * 
     * Usage: [rental_gates_landing]
     */
    public static function render_landing_page($atts = array()) {
        $atts = shortcode_atts(array(
            'show_pricing' => 'yes',
            'show_testimonials' => 'yes',
            'show_features' => 'yes',
        ), $atts, 'rental_gates_landing');
        
        ob_start();
        
        // Set attributes for template
        set_query_var('rg_landing_atts', $atts);
        
        // Get theme setting and use appropriate template
        $landing_theme = get_option('rental_gates_landing_theme', 'modern');
        $theme_file = $landing_theme === 'minimal' ? 'landing-content-minimal.php' : 'landing-content.php';
        
        // Use the content partial (no HTML wrapper) for embedded mode
        $template = RENTAL_GATES_PLUGIN_DIR . 'templates/public/' . $theme_file;
        if (file_exists($template)) {
            include $template;
        }
        
        return ob_get_clean();
    }
    
    /**
     * Render property search widget
     * 
     * Usage: [rental_gates_search location="new-york" bedrooms="2"]
     */
    public static function render_property_search($atts = array()) {
        $atts = shortcode_atts(array(
            'location' => '',
            'bedrooms' => '',
            'min_rent' => '',
            'max_rent' => '',
            'style' => 'default', // default, compact, map
        ), $atts, 'rental_gates_search');
        
        ob_start();
        ?>
        <div class="rg-search-widget" data-style="<?php echo esc_attr($atts['style']); ?>">
            <form action="<?php echo home_url('/rental-gates/search'); ?>" method="get" class="rg-search-form">
                <div class="rg-search-fields">
                    <input type="text" name="location" placeholder="<?php esc_attr_e('Location', 'rental-gates'); ?>" value="<?php echo esc_attr($atts['location']); ?>">
                    <select name="bedrooms">
                        <option value=""><?php _e('Bedrooms', 'rental-gates'); ?></option>
                        <option value="0" <?php selected($atts['bedrooms'], '0'); ?>><?php _e('Studio', 'rental-gates'); ?></option>
                        <option value="1" <?php selected($atts['bedrooms'], '1'); ?>>1</option>
                        <option value="2" <?php selected($atts['bedrooms'], '2'); ?>>2</option>
                        <option value="3" <?php selected($atts['bedrooms'], '3'); ?>>3+</option>
                    </select>
                    <button type="submit" class="rg-search-btn"><?php _e('Search', 'rental-gates'); ?></button>
                </div>
            </form>
        </div>
        <style>
            .rg-search-widget { margin: 20px 0; }
            .rg-search-form { display: flex; gap: 12px; flex-wrap: wrap; }
            .rg-search-fields { display: flex; gap: 12px; flex-wrap: wrap; width: 100%; }
            .rg-search-fields input, .rg-search-fields select {
                flex: 1;
                min-width: 150px;
                padding: 12px 16px;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                font-size: 15px;
            }
            .rg-search-btn {
                padding: 12px 24px;
                background: #0d9488;
                color: #fff;
                border: none;
                border-radius: 8px;
                font-size: 15px;
                font-weight: 600;
                cursor: pointer;
            }
            .rg-search-btn:hover { background: #0f766e; }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render single property embed
     * 
     * Usage: [rental_gates_property id="123"]
     */
    public static function render_property($atts = array()) {
        $atts = shortcode_atts(array(
            'id' => 0,
            'type' => 'unit', // unit or building
            'style' => 'card', // card, full, minimal
        ), $atts, 'rental_gates_property');
        
        $id = intval($atts['id']);
        if (!$id) {
            return '<p class="rg-error">' . __('Property ID required', 'rental-gates') . '</p>';
        }
        
        ob_start();
        
        if ($atts['type'] === 'building' && class_exists('Rental_Gates_Building')) {
            $building = Rental_Gates_Building::get($id);
            if ($building) {
                self::render_building_card($building, $atts['style']);
            }
        } elseif (class_exists('Rental_Gates_Unit')) {
            $unit = Rental_Gates_Unit::get($id);
            if ($unit) {
                self::render_unit_card($unit, $atts['style']);
            }
        }
        
        return ob_get_clean();
    }
    
    /**
     * Render application form
     * 
     * Usage: [rental_gates_apply unit_id="123"]
     */
    public static function render_application_form($atts = array()) {
        $atts = shortcode_atts(array(
            'unit_id' => 0,
            'building_id' => 0,
        ), $atts, 'rental_gates_apply');
        
        $unit_id = intval($atts['unit_id']);
        $building_id = intval($atts['building_id']);
        
        if (!$unit_id && !$building_id) {
            return '<p class="rg-error">' . __('Unit or Building ID required', 'rental-gates') . '</p>';
        }
        
        // Redirect to application page
        $apply_url = home_url('/rental-gates/apply');
        if ($unit_id) {
            $apply_url = add_query_arg('unit_id', $unit_id, $apply_url);
        } elseif ($building_id) {
            $apply_url = add_query_arg('building_id', $building_id, $apply_url);
        }
        
        ob_start();
        ?>
        <div class="rg-apply-widget">
            <a href="<?php echo esc_url($apply_url); ?>" class="rg-apply-btn">
                <?php _e('Apply Now', 'rental-gates'); ?>
            </a>
        </div>
        <style>
            .rg-apply-widget { text-align: center; margin: 20px 0; }
            .rg-apply-btn {
                display: inline-block;
                padding: 14px 32px;
                background: #0d9488;
                color: #fff;
                text-decoration: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                transition: background 0.2s;
            }
            .rg-apply-btn:hover { background: #0f766e; color: #fff; }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Maybe render landing page on designated home page
     */
    public static function maybe_render_landing_page($content) {
        // Check if we're on the designated landing page
        $landing_page_id = get_option('rental_gates_landing_page_id', 0);
        
        if (!$landing_page_id || !is_page($landing_page_id)) {
            return $content;
        }
        
        // Check if shortcode already exists in content
        if (has_shortcode($content, 'rental_gates_landing')) {
            return $content;
        }
        
        // Return the landing page content
        return self::render_landing_page();
    }
    
    /**
     * Maybe override template for full-page landing (completely standalone, no theme)
     */
    public static function maybe_override_template() {
        $landing_page_id = get_option('rental_gates_landing_page_id', 0);
        $use_full_page = get_option('rental_gates_landing_full_page', '1');
        
        if (!$landing_page_id || !is_page($landing_page_id) || $use_full_page !== '1') {
            return;
        }
        
        // Output standalone landing page (no theme, no wp_head/wp_footer)
        self::output_standalone_landing();
        exit;
    }
    
    /**
     * Output completely standalone landing page HTML
     */
    private static function output_standalone_landing() {
        // Prevent any caching issues
        nocache_headers();
        
        // Get settings
        $platform_name = get_option('rental_gates_platform_name', 'Rental Gates');
        $support_email = get_option('rental_gates_support_email', get_option('admin_email'));
        $is_logged_in = is_user_logged_in();
        $dashboard_url = home_url('/rental-gates/dashboard');
        $login_url = home_url('/rental-gates/login');
        $register_url = home_url('/rental-gates/register');
        $show_pricing = get_option('rental_gates_landing_show_pricing', '1') === '1';
        $show_testimonials = get_option('rental_gates_landing_show_testimonials', '1') === '1';
        $terms_url = get_option('rental_gates_terms_url', '');
        $privacy_url = get_option('rental_gates_privacy_url', '');
        
        // Get language attributes
        $lang_attr = get_language_attributes();
        $charset = get_bloginfo('charset');
        
        // Output the complete standalone HTML
        include RENTAL_GATES_PLUGIN_DIR . 'templates/public/landing-standalone.php';
    }
    
    /**
     * Helper: Render building card
     */
    private static function render_building_card($building, $style = 'card') {
        $gallery = !empty($building['gallery']) ? $building['gallery'] : array();
        $image = !empty($gallery[0]) ? rg_get_gallery_url($gallery[0]) : '';
        $url = home_url('/rental-gates/building/' . $building['slug']);
        ?>
        <div class="rg-property-card rg-style-<?php echo esc_attr($style); ?>">
            <?php if ($image): ?>
            <div class="rg-property-image">
                <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($building['name']); ?>">
            </div>
            <?php endif; ?>
            <div class="rg-property-content">
                <h3 class="rg-property-title">
                    <a href="<?php echo esc_url($url); ?>"><?php echo esc_html($building['name']); ?></a>
                </h3>
                <p class="rg-property-address"><?php echo esc_html($building['derived_address']); ?></p>
                <?php if (!empty($building['description'])): ?>
                <p class="rg-property-desc"><?php echo esc_html(wp_trim_words($building['description'], 20)); ?></p>
                <?php endif; ?>
                <a href="<?php echo esc_url($url); ?>" class="rg-property-link"><?php _e('View Building', 'rental-gates'); ?> &rarr;</a>
            </div>
        </div>
        <?php
        self::render_property_card_styles();
    }
    
    /**
     * Helper: Render unit card
     */
    private static function render_unit_card($unit, $style = 'card') {
        $gallery = !empty($unit['gallery']) ? $unit['gallery'] : array();
        $image = !empty($gallery[0]) ? rg_get_gallery_url($gallery[0]) : '';
        
        // Get building for URL
        $building = null;
        if (class_exists('Rental_Gates_Building') && !empty($unit['building_id'])) {
            $building = Rental_Gates_Building::get($unit['building_id']);
        }
        
        $url = $building ? home_url('/rental-gates/building/' . $building['slug'] . '/unit/' . $unit['slug']) : '#';
        ?>
        <div class="rg-property-card rg-style-<?php echo esc_attr($style); ?>">
            <?php if ($image): ?>
            <div class="rg-property-image">
                <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($unit['unit_number']); ?>">
            </div>
            <?php endif; ?>
            <div class="rg-property-content">
                <h3 class="rg-property-title">
                    <a href="<?php echo esc_url($url); ?>"><?php echo esc_html($unit['unit_number']); ?></a>
                </h3>
                <div class="rg-property-meta">
                    <span><?php echo intval($unit['bedrooms']); ?> <?php _e('bed', 'rental-gates'); ?></span>
                    <span><?php echo floatval($unit['bathrooms']); ?> <?php _e('bath', 'rental-gates'); ?></span>
                    <?php if (!empty($unit['square_feet'])): ?>
                    <span><?php echo number_format($unit['square_feet']); ?> <?php _e('sqft', 'rental-gates'); ?></span>
                    <?php endif; ?>
                </div>
                <p class="rg-property-price">$<?php echo number_format($unit['rent_amount']); ?><span>/mo</span></p>
                <a href="<?php echo esc_url($url); ?>" class="rg-property-link"><?php _e('View Details', 'rental-gates'); ?> &rarr;</a>
            </div>
        </div>
        <?php
        self::render_property_card_styles();
    }
    
    /**
     * Helper: Output property card styles
     */
    private static function render_property_card_styles() {
        static $styles_rendered = false;
        if ($styles_rendered) return;
        $styles_rendered = true;
        ?>
        <style>
            .rg-property-card {
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                overflow: hidden;
                margin: 20px 0;
            }
            .rg-property-image img {
                width: 100%;
                height: 200px;
                object-fit: cover;
            }
            .rg-property-content {
                padding: 20px;
            }
            .rg-property-title {
                font-size: 18px;
                font-weight: 600;
                margin: 0 0 8px;
            }
            .rg-property-title a {
                color: #1c1917;
                text-decoration: none;
            }
            .rg-property-title a:hover {
                color: #0d9488;
            }
            .rg-property-address {
                font-size: 14px;
                color: #78716c;
                margin: 0 0 12px;
            }
            .rg-property-meta {
                display: flex;
                gap: 16px;
                font-size: 14px;
                color: #57534e;
                margin-bottom: 12px;
            }
            .rg-property-price {
                font-size: 24px;
                font-weight: 700;
                color: #0d9488;
                margin: 0 0 16px;
            }
            .rg-property-price span {
                font-size: 14px;
                font-weight: 400;
                color: #78716c;
            }
            .rg-property-desc {
                font-size: 14px;
                color: #57534e;
                margin: 0 0 16px;
                line-height: 1.6;
            }
            .rg-property-link {
                display: inline-block;
                color: #0d9488;
                font-weight: 600;
                text-decoration: none;
            }
            .rg-property-link:hover {
                color: #0f766e;
            }
            .rg-error {
                padding: 12px 16px;
                background: #fef2f2;
                border: 1px solid #fecaca;
                border-radius: 8px;
                color: #dc2626;
                font-size: 14px;
            }
        </style>
        <?php
    }
}
