# Rental Gates - User Guide

Complete guide for all user roles: Property Owners, Managers, Staff, Tenants, and Vendors.

---

## Table of Contents

1. [Getting Started](#getting-started)
2. [Owner/Manager Dashboard](#ownermanager-dashboard)
3. [Managing Buildings](#managing-buildings)
4. [Managing Units](#managing-units)
5. [Tenant Management](#tenant-management)
6. [Lease Management](#lease-management)
7. [Applications](#applications)
8. [Payments](#payments)
9. [Maintenance](#maintenance)
10. [Vendors](#vendors)
11. [Leads & CRM](#leads--crm)
12. [Communications](#communications)
13. [Marketing Tools](#marketing-tools)
14. [AI Tools](#ai-tools)
15. [Reports](#reports)
16. [Staff Portal](#staff-portal)
17. [Tenant Portal](#tenant-portal)
18. [Vendor Portal](#vendor-portal)
19. [Mobile App](#mobile-app)

---

## Getting Started

### Accessing Your Dashboard

**Property Owners/Managers:**
```
https://yoursite.com/rental-gates/dashboard
```

**Staff Members:**
```
https://yoursite.com/rental-gates/staff
```

**Tenants:**
```
https://yoursite.com/rental-gates/tenant
```

**Vendors:**
```
https://yoursite.com/rental-gates/vendor
```

### First Login

1. Check your email for the invitation link
2. Click the link to set your password
3. Log in with your email and password
4. Complete your profile setup

### Navigation

The sidebar provides access to all features:

```
📊 Dashboard      - Overview and quick stats
🏢 Buildings      - Property management
🚪 Units          - Unit listings
👥 Tenants        - Tenant directory
📋 Leases         - Lease management
📝 Applications   - Rental applications
💰 Payments       - Payment tracking
🔧 Maintenance    - Work orders
👷 Vendors        - Vendor directory
📈 Leads          - CRM pipeline
✉️ Messages       - Communications
📢 Announcements  - Broadcast messages
📊 Reports        - Analytics
🤖 AI Tools       - AI features
⚙️ Settings       - Configuration
```

---

## Owner/Manager Dashboard

### Overview Screen

The dashboard home shows key metrics at a glance:

#### Quick Stats
- **Total Buildings** - Properties in portfolio
- **Total Units** - All units across buildings
- **Occupancy Rate** - Percentage occupied
- **Monthly Revenue** - Current month collections
- **Active Leases** - Currently active leases
- **Pending Applications** - Awaiting review

#### Recent Activity
- Latest payments received
- New maintenance requests
- Lease expirations coming up
- Recent applications

#### Quick Actions
- Add Building
- Add Tenant
- Create Lease
- Record Payment
- Create Work Order

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `G` then `D` | Go to Dashboard |
| `G` then `B` | Go to Buildings |
| `G` then `T` | Go to Tenants |
| `G` then `P` | Go to Payments |
| `N` | New/Add action |
| `/` | Search |
| `?` | Show shortcuts |

---

## Managing Buildings

### Adding a Building

1. Click **Buildings** in sidebar
2. Click **Add Building** button
3. **Place on Map:**
   - Click on the map to place a pin
   - Drag to adjust location
   - Address is auto-populated
4. **Fill Details:**
   - Building name
   - Property type (Apartment, House, Commercial, etc.)
   - Year built
   - Total floors
   - Description
5. **Add Amenities:**
   - Select building-wide amenities
   - Pool, Gym, Parking, etc.
6. **Upload Photos:**
   - Click to upload or drag images
   - Reorder by dragging
   - Set featured image
7. Click **Save Building**

### Building Details

View building details including:
- Property information
- Unit list with status
- Occupancy rate
- Revenue summary
- Recent activity
- Documents

### Editing a Building

1. Go to **Buildings**
2. Click on building name
3. Click **Edit** button
4. Make changes
5. Click **Save Changes**

### Archiving a Building

Buildings can be archived (soft delete):
1. Go to building detail
2. Click **Archive**
3. Confirm action

Archived buildings can be restored from Settings.

---

## Managing Units

### Adding a Unit

1. Go to building detail page
2. Click **Add Unit**
3. Fill unit details:

| Field | Description |
|-------|-------------|
| Unit Number | e.g., "101", "A", "Suite 200" |
| Unit Type | Studio, 1BR, 2BR, etc. |
| Bedrooms | Number of bedrooms |
| Bathrooms | Number of bathrooms |
| Square Feet | Unit size |
| Monthly Rent | Rental price |
| Deposit | Security deposit amount |

4. **Floor Plan:**
   - Bedrooms, bathrooms count
   - Living rooms, kitchens
   - Parking spaces

5. **Amenities:**
   - Unit-specific features
   - Washer/Dryer, Balcony, etc.

6. **Photos:**
   - Upload unit images
   - Set featured photo

7. Click **Save Unit**

### Unit Availability States

Units have 5 availability states:

| State | Color | Description |
|-------|-------|-------------|
| **Available** | Green | Ready to rent |
| **Coming Soon** | Blue | Available on future date |
| **Occupied** | Gray | Currently leased |
| **Renewal Pending** | Yellow | Lease ending, renewal in progress |
| **Unlisted** | Red | Not shown publicly |

### Changing Availability

1. Go to unit detail
2. Click **Change Status**
3. Select new status
4. Add effective date (if applicable)
5. Confirm change

### Unit Pricing

Set competitive pricing:
- Base monthly rent
- Pet rent (if applicable)
- Parking fees
- Storage fees
- Move-in specials

---

## Tenant Management

### Adding a Tenant

**From Application:**
1. Approve an application
2. Tenant is created automatically

**Manual Entry:**
1. Go to **Tenants**
2. Click **Add Tenant**
3. Enter information:
   - Name, Email, Phone
   - Emergency contact
   - Employment info
   - Vehicle info
4. Click **Save Tenant**
5. Optionally send invitation email

### Tenant Profile

Each tenant profile contains:

- **Contact Info** - Phone, email, emergency contact
- **Current Lease** - Active lease details
- **Payment History** - All rent payments
- **Maintenance Requests** - Submitted work orders
- **Documents** - Uploaded documents
- **Notes** - Internal notes

### Tenant Actions

| Action | Description |
|--------|-------------|
| Send Message | Direct message to tenant |
| Send Notice | Official notice (via email) |
| View Ledger | Complete payment history |
| Add Note | Internal note (tenant doesn't see) |
| Edit Profile | Update tenant information |

### Inviting Tenants to Portal

1. Go to tenant profile
2. Click **Invite to Portal**
3. Enter their email
4. Click **Send Invitation**

They'll receive email with login link.

---

## Lease Management

### Creating a Lease

1. Go to **Leases**
2. Click **Create Lease**
3. **Select Property:**
   - Choose building
   - Select unit
4. **Select Tenant(s):**
   - Search existing tenants
   - Or create new tenant
5. **Lease Terms:**

| Field | Description |
|-------|-------------|
| Start Date | Lease begin date |
| End Date | Lease end date |
| Monthly Rent | Rent amount |
| Security Deposit | Deposit amount |
| Pet Deposit | If applicable |
| Late Fee | Amount or percentage |
| Grace Period | Days before late fee |

6. **Additional Terms:**
   - Parking included
   - Utilities included
   - Pet policy
   - Special conditions

7. Click **Create Lease**

### Lease States

| State | Description |
|-------|-------------|
| **Draft** | Not yet active |
| **Pending** | Awaiting signatures |
| **Active** | Currently in effect |
| **Expiring** | Within 60 days of end |
| **Expired** | Past end date |
| **Terminated** | Ended early |
| **Renewed** | Replaced by new lease |

### Lease Actions

- **Edit** - Modify lease terms
- **Renew** - Create renewal offer
- **Terminate** - End lease early
- **View Document** - See/download lease PDF
- **Send to Tenant** - Email lease for review

### Lease Renewals

1. Go to expiring lease
2. Click **Create Renewal**
3. Adjust terms if needed:
   - New end date
   - Rent adjustment
   - Updated terms
4. Click **Send Renewal Offer**
5. Tenant receives email to accept/decline

---

## Applications

### Application Workflow

```
Received → Under Review → Approved/Declined
                ↓
            Lease Created
```

### Reviewing Applications

1. Go to **Applications**
2. Click on application
3. Review information:
   - Personal details
   - Employment/income
   - Rental history
   - References
   - Credit check (if integrated)
4. Use **AI Screening** for analysis
5. Make decision

### Application Actions

| Action | Description |
|--------|-------------|
| **Approve** | Accept and create tenant |
| **Decline** | Reject with reason |
| **Request Info** | Ask for more documents |
| **Schedule Tour** | Set up property showing |
| **AI Screen** | Run AI analysis |

### Application Settings

Configure in **Settings → Applications:**
- Application fee
- Required documents
- Screening questions
- Auto-responses

---

## Payments

### Recording a Payment

1. Go to **Payments**
2. Click **Record Payment**
3. Enter details:
   - Select tenant/lease
   - Amount
   - Payment date
   - Payment method
   - Reference number
4. Click **Save Payment**

### Online Payments

If Stripe is configured, tenants can pay online:
1. Tenant logs into portal
2. Clicks **Pay Rent**
3. Enters card details
4. Payment is recorded automatically

### Payment Status

| Status | Description |
|--------|-------------|
| **Pending** | Awaiting processing |
| **Completed** | Successfully processed |
| **Failed** | Payment declined |
| **Refunded** | Money returned |
| **Partial** | Partial payment received |

### Late Fees

Configure automatic late fees:
1. Go to **Settings → Payments**
2. Set late fee amount ($ or %)
3. Set grace period (days)
4. Enable/disable automatic application

### Payment Reminders

Automatic reminders are sent:
- 7 days before due
- 3 days before due
- On due date
- After due date (if late)

Configure in **Settings → Notifications.**

---

## Maintenance

### Creating a Work Order

**As Owner/Manager:**
1. Go to **Maintenance**
2. Click **Create Work Order**
3. Select building/unit
4. Choose category:
   - Plumbing
   - Electrical
   - HVAC
   - Appliance
   - General
5. Set priority (Low/Medium/High/Emergency)
6. Describe the issue
7. Upload photos (optional)
8. Click **Submit**

**Tenants can also submit via portal**

### Work Order Lifecycle

```
New → Assigned → In Progress → Completed → Closed
        ↓
    On Hold (waiting for parts, etc.)
```

### Assigning Vendors

1. Open work order
2. Click **Assign Vendor**
3. Select vendor from list
4. Add any notes
5. Click **Assign**

Vendor receives notification.

### Tracking Progress

Each work order shows:
- Current status
- Assigned vendor
- Timeline of updates
- Photos before/after
- Cost tracking
- Time spent

### Completing Work Orders

1. Vendor marks as complete (or manager)
2. Add completion notes
3. Upload final photos
4. Enter cost information
5. Click **Complete**

Optional: Send satisfaction survey to tenant.

---

## Vendors

### Adding a Vendor

1. Go to **Vendors**
2. Click **Add Vendor**
3. Enter information:
   - Company name
   - Contact person
   - Phone, Email
   - Services offered
   - Service area
   - Hourly rate
   - Insurance info
4. Click **Save Vendor**
5. Optionally invite to portal

### Vendor Categories

- Plumbing
- Electrical
- HVAC
- Roofing
- Landscaping
- Cleaning
- General Contractor
- Appliance Repair
- Pest Control
- Locksmith

### Vendor Performance

Track vendor metrics:
- Response time
- Completion rate
- Average rating
- Jobs completed
- Total spend

---

## Leads & CRM

### Lead Pipeline

Track prospects through stages:

```
New → Contacted → Toured → Applied → Converted
                              ↓
                          Lost/Archived
```

### Adding Leads

Leads can come from:
- Website contact form
- Phone inquiries (manual entry)
- QR code scans
- Referrals

### Lead Actions

| Action | Description |
|--------|-------------|
| **Contact** | Log contact attempt |
| **Schedule Tour** | Set showing appointment |
| **Send Listing** | Email property info |
| **Convert** | Create application |
| **Archive** | Mark as lost |

### Lead Sources

Track where leads come from:
- Website
- Zillow/Apartments.com
- Referral
- Walk-in
- QR Code
- Social Media
- Other

---

## Communications

### Messages

Send direct messages to tenants:

1. Go to **Messages**
2. Click **New Message**
3. Select recipient(s)
4. Type message
5. Attach files if needed
6. Click **Send**

### Message Templates

Create reusable templates:
1. Go to **Settings → Templates**
2. Click **Add Template**
3. Name the template
4. Write content (use variables)
5. Save

Available variables:
- `{{tenant_name}}`
- `{{unit_number}}`
- `{{rent_amount}}`
- `{{due_date}}`
- `{{building_name}}`

### Announcements

Broadcast to multiple recipients:

1. Go to **Announcements**
2. Click **Create Announcement**
3. Enter title and message
4. Select audience:
   - All Tenants
   - Specific Buildings
   - Specific Tenants
5. Choose delivery:
   - Email
   - In-app notification
   - Both
6. Click **Send**

---

## Marketing Tools

### QR Codes

Generate QR codes linking to listings:

1. Go to **Marketing**
2. Click **Generate QR Code**
3. Select building or unit
4. Customize design:
   - Logo in center
   - Colors
   - Size
5. Download or print

### Flyers

Create property flyers:

1. Go to **Marketing → Flyers**
2. Click **Create Flyer**
3. Select template
4. Choose property
5. Customize content:
   - Headlines
   - Features
   - Pricing
   - Contact info
6. Generate PDF
7. Download or print

### Listing Syndication

Export listings for other platforms:
1. Go to **Marketing → Export**
2. Select properties
3. Choose format (CSV, XML)
4. Download file

---

## AI Tools

### Generate Listing Description

1. Go to **AI Tools**
2. Click **Listing Description**
3. Select unit
4. Choose tone (Professional, Friendly, Luxury)
5. Click **Generate**
6. Review and edit
7. Apply to listing

### Tenant Screening

1. Open an application
2. Click **AI Screen**
3. AI analyzes:
   - Income vs rent ratio
   - Employment stability
   - Rental history
   - Red flags
4. Review recommendations
5. Make final decision

### Maintenance Triage

AI helps categorize and prioritize:
1. New work order submitted
2. AI suggests:
   - Category
   - Priority level
   - Recommended vendor
3. Manager approves/adjusts

### Credit Usage

- Each AI action uses credits
- Credits reset monthly
- Track usage in **AI Tools → Usage**
- Upgrade plan for more credits

---

## Reports

### Available Reports

| Report | Description |
|--------|-------------|
| **Revenue** | Income by period |
| **Occupancy** | Vacancy rates |
| **Collections** | Payment status |
| **Maintenance** | Work order stats |
| **Lease Expiration** | Upcoming renewals |
| **Tenant Aging** | Outstanding balances |
| **Lead Conversion** | Pipeline metrics |

### Generating Reports

1. Go to **Reports**
2. Select report type
3. Set date range
4. Apply filters (building, status, etc.)
5. Click **Generate**
6. View on screen or export

### Export Options

- PDF (formatted report)
- Excel (data only)
- CSV (for imports)

### Scheduled Reports

Set up automatic report delivery:
1. Go to **Reports → Scheduled**
2. Click **Add Schedule**
3. Select report
4. Set frequency (daily/weekly/monthly)
5. Add recipients
6. Save

---

## Staff Portal

Staff members have limited access based on their role.

### Staff Roles

| Role | Access |
|------|--------|
| **Property Manager** | Full property access |
| **Leasing Agent** | Leads, applications, showings |
| **Maintenance Coordinator** | Work orders, vendors |
| **Accountant** | Payments, reports |

### Staff Dashboard

Shows:
- Assigned properties
- Pending tasks
- Today's appointments
- Recent activity

### Adding Staff

1. Go to **Staff** (owner only)
2. Click **Add Staff**
3. Enter name and email
4. Select role
5. Assign properties/buildings
6. Click **Send Invitation**

---

## Tenant Portal

### Tenant Dashboard

Tenants see:
- Lease summary
- Upcoming payment due
- Recent payments
- Maintenance request status
- Messages

### Paying Rent

1. Log into tenant portal
2. Click **Pay Rent**
3. Review amount
4. Enter payment method
5. Click **Pay Now**
6. Receive confirmation

### Submitting Maintenance

1. Click **Maintenance**
2. Click **New Request**
3. Select category
4. Describe issue
5. Upload photos
6. Set urgency
7. Submit

### Viewing Lease

1. Click **My Lease**
2. View lease details
3. Download PDF if needed

### Updating Profile

1. Click **Profile**
2. Update contact info
3. Add emergency contact
4. Update vehicle info
5. Save changes

---

## Vendor Portal

### Vendor Dashboard

Vendors see:
- Assigned work orders
- Order history
- Payment history
- Profile settings

### Managing Work Orders

1. View assigned orders
2. Click to see details
3. Add updates/notes
4. Upload progress photos
5. Mark as complete

### Updating Status

| Status | When to Use |
|--------|-------------|
| **Acknowledged** | Accepted the job |
| **En Route** | On the way |
| **On Site** | Arrived at property |
| **In Progress** | Working on repair |
| **Completed** | Work finished |

---

## Mobile App

### Installing the App

**Android:**
1. Visit the site in Chrome
2. Tap "Add to Home Screen" prompt
3. Or: Menu → Add to Home Screen

**iOS:**
1. Visit the site in Safari
2. Tap Share button
3. Select "Add to Home Screen"
4. Tap "Add"

### Offline Features

When offline, you can:
- View cached data
- Browse previous pages
- Queue actions (sync when online)

### Push Notifications

Enable notifications for:
- New payments
- Maintenance updates
- Messages
- Lease alerts
- Application submissions

Configure in **Profile → Notification Settings.**

---

## Tips & Best Practices

### For Owners/Managers

1. **Keep data current** - Update unit availability promptly
2. **Document everything** - Add notes to tenant profiles
3. **Use automation** - Set up payment reminders
4. **Regular reports** - Review weekly metrics
5. **Respond quickly** - Address maintenance promptly

### For Tenants

1. **Pay on time** - Set up autopay if available
2. **Submit detailed requests** - Include photos
3. **Update contact info** - Keep current
4. **Read announcements** - Stay informed
5. **Use the portal** - Faster than calling

### For Vendors

1. **Update status** - Keep orders current
2. **Document work** - Upload photos
3. **Communicate** - Add notes for management
4. **Complete promptly** - Build good reputation
5. **Submit accurate costs** - Include all expenses

---

*User Guide v2.24.1*
