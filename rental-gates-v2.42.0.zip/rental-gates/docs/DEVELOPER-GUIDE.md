# Rental Gates - Developer Guide

Complete guide for developers extending and customizing Rental Gates.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Hooks & Filters](#hooks--filters)
3. [Custom Models](#custom-models)
4. [Extending the REST API](#extending-the-rest-api)
5. [Custom Dashboard Sections](#custom-dashboard-sections)
6. [Email Customization](#email-customization)
7. [Template Overrides](#template-overrides)
8. [JavaScript Integration](#javascript-integration)
9. [Database Schema](#database-schema)
10. [Cron Jobs](#cron-jobs)
11. [Security Considerations](#security-considerations)
12. [Testing](#testing)
13. [Performance](#performance)

---

## Architecture Overview

### Plugin Structure

```
rental-gates/
├── rental-gates.php          # Main plugin class (singleton)
├── includes/
│   ├── class-rental-gates-activator.php    # Activation logic
│   ├── class-rental-gates-deactivator.php  # Deactivation logic
│   ├── class-rental-gates-loader.php       # Hook/filter registration
│   ├── class-rental-gates-database.php     # Database schema & helpers
│   ├── class-rental-gates-roles.php        # Roles & capabilities
│   ├── class-rental-gates-auth.php         # Authentication
│   ├── class-rental-gates-security.php     # Security utilities
│   ├── class-rental-gates-email.php        # Email system
│   ├── class-rental-gates-cache.php        # Caching layer
│   ├── class-rental-gates-validation.php   # Data validation
│   ├── class-rental-gates-pwa.php          # PWA features
│   ├── models/                             # Data models
│   ├── api/                                # REST API
│   ├── admin/                              # WP Admin integration
│   ├── automation/                         # Scheduled tasks
│   ├── subscription/                       # Billing system
│   ├── maps/                               # Map providers
│   └── public/                             # Public features
├── templates/                              # PHP templates
├── assets/                                 # CSS, JS, images
└── languages/                              # Translations
```

### Main Plugin Class

```php
class Rental_Gates {
    private static $instance = null;
    
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
}

// Access instance
$rg = Rental_Gates::instance();
```

### Database Access

```php
// Get table names
$tables = Rental_Gates_Database::get_table_names();
// $tables['buildings'], $tables['units'], etc.

// Direct query
global $wpdb;
$buildings = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$tables['buildings']} WHERE organization_id = %d",
    $org_id
));
```

---

## Hooks & Filters

### Action Hooks

#### Lifecycle Hooks

```php
// After plugin activation
do_action('rental_gates_activated');

// After plugin deactivation
do_action('rental_gates_deactivated');

// On plugin init
do_action('rental_gates_init');

// Before templates load
do_action('rental_gates_before_template', $template_name);

// After templates load
do_action('rental_gates_after_template', $template_name);
```

#### Entity Hooks

```php
// Buildings
do_action('rental_gates_building_created', $building_id, $data);
do_action('rental_gates_building_updated', $building_id, $data, $old_data);
do_action('rental_gates_building_deleted', $building_id);

// Units
do_action('rental_gates_unit_created', $unit_id, $data);
do_action('rental_gates_unit_updated', $unit_id, $data, $old_data);
do_action('rental_gates_unit_availability_changed', $unit_id, $new_status, $old_status);

// Tenants
do_action('rental_gates_tenant_created', $tenant_id, $data);
do_action('rental_gates_tenant_invited', $tenant_id, $user_id);

// Leases
do_action('rental_gates_lease_created', $lease_id, $data);
do_action('rental_gates_lease_signed', $lease_id);
do_action('rental_gates_lease_terminated', $lease_id, $reason);
do_action('rental_gates_lease_renewed', $old_lease_id, $new_lease_id);

// Applications
do_action('rental_gates_application_received', $app_id, $data);
do_action('rental_gates_application_approved', $app_id);
do_action('rental_gates_application_declined', $app_id, $reason);

// Payments
do_action('rental_gates_payment_created', $payment_id, $data);
do_action('rental_gates_payment_completed', $payment_id);
do_action('rental_gates_payment_failed', $payment_id, $error);
do_action('rental_gates_payment_refunded', $payment_id, $amount);

// Maintenance
do_action('rental_gates_work_order_created', $order_id, $data);
do_action('rental_gates_work_order_assigned', $order_id, $vendor_id);
do_action('rental_gates_work_order_completed', $order_id);

// Messages
do_action('rental_gates_message_sent', $message_id, $thread_id);
do_action('rental_gates_announcement_sent', $announcement_id, $recipient_ids);
```

#### Authentication Hooks

```php
// After user login
do_action('rental_gates_user_logged_in', $user_id, $user);

// After user logout
do_action('rental_gates_user_logged_out', $user_id);

// After registration
do_action('rental_gates_user_registered', $user_id, $org_id);

// Password reset
do_action('rental_gates_password_reset', $user_id);
```

#### Email Hooks

```php
// Before email sent
do_action('rental_gates_before_email', $template, $to, $data);

// After email sent
do_action('rental_gates_after_email', $template, $to, $result);
```

### Filter Hooks

#### Data Filters

```php
// Filter building data before save
$data = apply_filters('rental_gates_building_data', $data, $building_id);

// Filter unit data before save
$data = apply_filters('rental_gates_unit_data', $data, $unit_id);

// Filter tenant data before save
$data = apply_filters('rental_gates_tenant_data', $data, $tenant_id);

// Filter lease data before save
$data = apply_filters('rental_gates_lease_data', $data, $lease_id);

// Filter payment data before save
$data = apply_filters('rental_gates_payment_data', $data, $payment_id);
```

#### Display Filters

```php
// Filter formatted building display
$building = apply_filters('rental_gates_format_building', $building);

// Filter formatted unit display
$unit = apply_filters('rental_gates_format_unit', $unit);

// Filter formatted tenant display
$tenant = apply_filters('rental_gates_format_tenant', $tenant);

// Filter rent amount display
$rent = apply_filters('rental_gates_format_rent', $rent, $unit_id);

// Filter currency display
$formatted = apply_filters('rental_gates_format_currency', $formatted, $amount);
```

#### Email Filters

```php
// Filter email subject
$subject = apply_filters('rental_gates_email_subject', $subject, $template);

// Filter email body
$body = apply_filters('rental_gates_email_body', $body, $template, $data);

// Filter email headers
$headers = apply_filters('rental_gates_email_headers', $headers, $template);

// Filter email recipient
$to = apply_filters('rental_gates_email_recipient', $to, $template);
```

#### API Filters

```php
// Filter API response
$response = apply_filters('rental_gates_api_response', $response, $endpoint);

// Filter API request data
$data = apply_filters('rental_gates_api_request', $data, $endpoint);

// Filter API authentication
$authenticated = apply_filters('rental_gates_api_authenticate', $authenticated, $request);
```

#### Permission Filters

```php
// Filter capability check
$can = apply_filters('rental_gates_user_can', $can, $capability, $user_id);

// Filter organization access
$has_access = apply_filters('rental_gates_org_access', $has_access, $org_id, $user_id);

// Filter building access
$has_access = apply_filters('rental_gates_building_access', $has_access, $building_id, $user_id);
```

#### Settings Filters

```php
// Filter default settings
$defaults = apply_filters('rental_gates_default_settings', $defaults);

// Filter plan limits
$limits = apply_filters('rental_gates_plan_limits', $limits, $plan_id);

// Filter feature availability
$enabled = apply_filters('rental_gates_feature_enabled', $enabled, $feature, $org_id);
```

### Usage Examples

#### Add custom data to buildings

```php
// Add custom field when building is created
add_action('rental_gates_building_created', function($building_id, $data) {
    // Save custom meta
    update_post_meta($building_id, '_custom_field', $data['custom_value'] ?? '');
}, 10, 2);

// Include custom field in API response
add_filter('rental_gates_format_building', function($building) {
    $building['custom_field'] = get_post_meta($building['id'], '_custom_field', true);
    return $building;
});
```

#### Custom email recipient

```php
// CC property manager on all tenant emails
add_filter('rental_gates_email_headers', function($headers, $template) {
    if (strpos($template, 'tenant_') === 0) {
        $headers[] = 'Cc: manager@example.com';
    }
    return $headers;
}, 10, 2);
```

#### Custom permission check

```php
// Allow vendors to see building details
add_filter('rental_gates_building_access', function($has_access, $building_id, $user_id) {
    if (Rental_Gates_Roles::is_vendor($user_id)) {
        // Check if vendor has work orders at this building
        $has_access = vendor_has_work_orders($building_id, $user_id);
    }
    return $has_access;
}, 10, 3);
```

---

## Custom Models

### Creating a Model

```php
<?php
class Rental_Gates_Custom_Model {
    
    private static $table_name = 'rg_custom_items';
    
    /**
     * Create item
     */
    public static function create($data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'organization_id' => 0,
            'name' => '',
            'status' => 'active',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validate
        if (empty($data['name'])) {
            return new WP_Error('missing_name', 'Name is required');
        }
        
        // Insert
        $result = $wpdb->insert(
            $tables['custom_items'],
            $data,
            array('%d', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', $wpdb->last_error);
        }
        
        $id = $wpdb->insert_id;
        
        // Fire action
        do_action('rental_gates_custom_item_created', $id, $data);
        
        return $id;
    }
    
    /**
     * Get item by ID
     */
    public static function get($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $item = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['custom_items']} WHERE id = %d",
            $id
        ));
        
        if (!$item) {
            return null;
        }
        
        return apply_filters('rental_gates_format_custom_item', $item);
    }
    
    /**
     * Get items by organization
     */
    public static function get_by_organization($org_id, $args = array()) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $defaults = array(
            'status' => 'active',
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 20,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $sql = "SELECT * FROM {$tables['custom_items']} 
                WHERE organization_id = %d";
        $params = array($org_id);
        
        if ($args['status']) {
            $sql .= " AND status = %s";
            $params[] = $args['status'];
        }
        
        $sql .= " ORDER BY {$args['orderby']} {$args['order']}";
        $sql .= " LIMIT %d OFFSET %d";
        $params[] = $args['limit'];
        $params[] = $args['offset'];
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    /**
     * Update item
     */
    public static function update($id, $data) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $data['updated_at'] = current_time('mysql');
        
        $old_data = self::get($id);
        
        $result = $wpdb->update(
            $tables['custom_items'],
            $data,
            array('id' => $id)
        );
        
        if ($result !== false) {
            do_action('rental_gates_custom_item_updated', $id, $data, $old_data);
        }
        
        return $result !== false;
    }
    
    /**
     * Delete item
     */
    public static function delete($id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        do_action('rental_gates_custom_item_deleted', $id);
        
        return $wpdb->delete(
            $tables['custom_items'],
            array('id' => $id),
            array('%d')
        );
    }
}
```

### Adding Custom Table

Add to activator:

```php
add_action('rental_gates_activated', function() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $table = $wpdb->prefix . 'rg_custom_items';
    
    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        organization_id bigint(20) UNSIGNED NOT NULL,
        name varchar(255) NOT NULL,
        status varchar(50) DEFAULT 'active',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY organization_id (organization_id),
        KEY status (status)
    ) $charset;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});
```

---

## Extending the REST API

### Register Custom Endpoint

```php
add_action('rest_api_init', function() {
    register_rest_route('rental-gates/v1', '/custom-items', array(
        array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'get_custom_items',
            'permission_callback' => 'custom_items_permission',
        ),
        array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => 'create_custom_item',
            'permission_callback' => 'custom_items_permission',
        ),
    ));
    
    register_rest_route('rental-gates/v1', '/custom-items/(?P<id>\d+)', array(
        array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'get_custom_item',
            'permission_callback' => 'custom_items_permission',
        ),
        array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => 'update_custom_item',
            'permission_callback' => 'custom_items_permission',
        ),
        array(
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => 'delete_custom_item',
            'permission_callback' => 'custom_items_permission',
        ),
    ));
});

function custom_items_permission($request) {
    return is_user_logged_in() && current_user_can('rg_manage_buildings');
}

function get_custom_items($request) {
    $org_id = Rental_Gates_Roles::get_user_organization();
    $items = Rental_Gates_Custom_Model::get_by_organization($org_id);
    
    return new WP_REST_Response(array(
        'success' => true,
        'data' => $items,
    ));
}

function create_custom_item($request) {
    $data = array(
        'organization_id' => Rental_Gates_Roles::get_user_organization(),
        'name' => sanitize_text_field($request->get_param('name')),
    );
    
    $id = Rental_Gates_Custom_Model::create($data);
    
    if (is_wp_error($id)) {
        return new WP_REST_Response(array(
            'success' => false,
            'error' => $id->get_error_message(),
        ), 400);
    }
    
    return new WP_REST_Response(array(
        'success' => true,
        'data' => Rental_Gates_Custom_Model::get($id),
    ), 201);
}
```

---

## Custom Dashboard Sections

### Create Section Template

Create `templates/dashboard/sections/custom.php`:

```php
<?php
if (!defined('ABSPATH')) exit;

// Get data
$org_id = Rental_Gates_Roles::get_user_organization();
$items = Rental_Gates_Custom_Model::get_by_organization($org_id);
?>

<header class="section-header">
    <h1>Custom Section</h1>
    <button class="btn btn-primary" onclick="openModal('add-item-modal')">
        Add Item
    </button>
</header>

<div class="section-content">
    <?php if (empty($items)): ?>
        <div class="empty-state">
            <p>No items yet</p>
        </div>
    <?php else: ?>
        <div class="items-grid">
            <?php foreach ($items as $item): ?>
                <div class="item-card">
                    <h3><?php echo esc_html($item->name); ?></h3>
                    <span class="status"><?php echo esc_html($item->status); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Add Item Modal -->
<div class="modal-overlay" id="add-item-modal">
    <div class="modal">
        <div class="modal-header">
            <h2>Add Item</h2>
            <button class="modal-close" onclick="closeModal('add-item-modal')">&times;</button>
        </div>
        <form method="post" action="">
            <?php wp_nonce_field('add_custom_item'); ?>
            <div class="modal-body">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('add-item-modal')">
                    Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    Add Item
                </button>
            </div>
        </form>
    </div>
</div>
```

### Add Navigation Item

```php
add_filter('rental_gates_dashboard_nav', function($nav) {
    $nav['custom'] = array(
        'label' => __('Custom', 'rental-gates'),
        'icon' => '<svg>...</svg>',
        'capability' => 'rg_manage_buildings',
    );
    return $nav;
});
```

---

## Email Customization

### Create Custom Template

Create `templates/emails/custom_notification.php`:

```php
<?php
if (!defined('ABSPATH')) exit;

$title = $data['title'] ?? 'Notification';
$message = $data['message'] ?? '';
$action_url = $data['action_url'] ?? '';
$action_text = $data['action_text'] ?? 'View Details';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center" style="padding: 40px 0;">
                <table width="600" cellpadding="0" cellspacing="0">
                    <!-- Header -->
                    <tr>
                        <td style="background: #2563eb; padding: 20px; text-align: center;">
                            <h1 style="color: #fff; margin: 0;"><?php echo esc_html($title); ?></h1>
                        </td>
                    </tr>
                    
                    <!-- Body -->
                    <tr>
                        <td style="background: #fff; padding: 40px;">
                            <?php echo wp_kses_post($message); ?>
                            
                            <?php if ($action_url): ?>
                            <p style="text-align: center; margin-top: 30px;">
                                <a href="<?php echo esc_url($action_url); ?>" 
                                   style="background: #2563eb; color: #fff; padding: 12px 30px; 
                                          text-decoration: none; border-radius: 6px;">
                                    <?php echo esc_html($action_text); ?>
                                </a>
                            </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background: #f3f4f6; padding: 20px; text-align: center; font-size: 12px; color: #666;">
                            <p>© <?php echo date('Y'); ?> <?php echo esc_html(get_bloginfo('name')); ?></p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
```

### Send Custom Email

```php
// Send custom notification
Rental_Gates_Email::send(
    'user@example.com',
    'Custom Notification',
    'custom_notification',
    array(
        'title' => 'Important Update',
        'message' => '<p>Your custom message here.</p>',
        'action_url' => home_url('/rental-gates/dashboard'),
        'action_text' => 'Go to Dashboard',
    )
);
```

---

## Template Overrides

### Override in Theme

Copy template to your theme:

```
your-theme/
└── rental-gates/
    └── dashboard/
        └── sections/
            └── overview.php    # Overrides plugin template
```

### Template Loading Order

1. `your-theme/rental-gates/{template}.php`
2. `your-theme/{template}.php`
3. `rental-gates/templates/{template}.php`

### Template Functions

```php
// Get template path
$path = Rental_Gates::get_template_path('dashboard/sections/overview.php');

// Load template with data
Rental_Gates::get_template('dashboard/sections/overview.php', array(
    'buildings' => $buildings,
    'stats' => $stats,
));
```

---

## JavaScript Integration

### Accessing Plugin Data

```javascript
// Global data object (available on rental-gates pages)
console.log(rentalGatesData);
// {
//     ajaxUrl: '/wp-admin/admin-ajax.php',
//     apiBase: '/wp-json/rental-gates/v1',
//     restNonce: 'abc123',
//     homeUrl: 'https://site.com',
//     pluginUrl: 'https://site.com/wp-content/plugins/rental-gates/',
//     isLoggedIn: true,
//     pwaEnabled: true,
// }
```

### Making API Calls

```javascript
// Using Fetch
async function getBuildings() {
    const response = await fetch(rentalGatesData.apiBase + '/buildings', {
        headers: {
            'X-WP-Nonce': rentalGatesData.restNonce
        }
    });
    return response.json();
}

// Using jQuery
jQuery.ajax({
    url: rentalGatesData.apiBase + '/buildings',
    headers: {
        'X-WP-Nonce': rentalGatesData.restNonce
    },
    success: function(response) {
        console.log(response.data);
    }
});
```

### Custom Events

```javascript
// Listen for Rental Gates events
document.addEventListener('rental_gates_building_loaded', function(e) {
    console.log('Building loaded:', e.detail);
});

document.addEventListener('rental_gates_payment_completed', function(e) {
    console.log('Payment completed:', e.detail);
});

// Dispatch custom event
document.dispatchEvent(new CustomEvent('rental_gates_custom_event', {
    detail: { data: 'value' }
}));
```

---

## Database Schema

### Table Naming

All tables use `rg_` prefix:

```php
$tables = Rental_Gates_Database::get_table_names();
// Returns: array(
//     'organizations' => 'wp_rg_organizations',
//     'buildings' => 'wp_rg_buildings',
//     ...
// )
```

### Common Columns

Most tables include:

| Column | Type | Description |
|--------|------|-------------|
| `id` | bigint(20) | Primary key |
| `organization_id` | bigint(20) | Organization FK |
| `created_at` | datetime | Creation timestamp |
| `updated_at` | datetime | Last update timestamp |

### Foreign Keys

Use proper indexing:

```sql
CREATE TABLE wp_rg_custom (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    organization_id bigint(20) UNSIGNED NOT NULL,
    building_id bigint(20) UNSIGNED,
    PRIMARY KEY (id),
    KEY organization_id (organization_id),
    KEY building_id (building_id),
    CONSTRAINT fk_custom_org FOREIGN KEY (organization_id) 
        REFERENCES wp_rg_organizations(id) ON DELETE CASCADE
);
```

---

## Cron Jobs

### Register Custom Cron

```php
// Register interval
add_filter('cron_schedules', function($schedules) {
    $schedules['every_six_hours'] = array(
        'interval' => 6 * HOUR_IN_SECONDS,
        'display' => 'Every 6 Hours',
    );
    return $schedules;
});

// Schedule event
register_activation_hook(__FILE__, function() {
    if (!wp_next_scheduled('rental_gates_custom_cron')) {
        wp_schedule_event(time(), 'every_six_hours', 'rental_gates_custom_cron');
    }
});

// Handle event
add_action('rental_gates_custom_cron', function() {
    // Your cron logic here
    error_log('Custom cron executed at ' . date('Y-m-d H:i:s'));
});

// Clean up on deactivation
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('rental_gates_custom_cron');
});
```

### Existing Cron Jobs

| Hook | Schedule | Purpose |
|------|----------|---------|
| `rental_gates_availability_cron` | Hourly | Update unit availability |
| `rental_gates_notifications_cron` | Daily | Send scheduled notifications |
| `rental_gates_ai_credits_reset` | Daily | Reset AI credit counters |

---

## Security Considerations

### Nonce Verification

```php
// In form
wp_nonce_field('rental_gates_custom_action', 'custom_nonce');

// Verify
if (!wp_verify_nonce($_POST['custom_nonce'] ?? '', 'rental_gates_custom_action')) {
    wp_die('Security check failed');
}
```

### Capability Checks

```php
// Check capability
if (!current_user_can('rg_manage_buildings')) {
    wp_die('Permission denied');
}

// Check organization access
$org_id = Rental_Gates_Roles::get_user_organization();
if (!$org_id || $building->organization_id !== $org_id) {
    wp_die('Access denied');
}
```

### Data Sanitization

```php
// Text input
$name = sanitize_text_field($_POST['name']);

// Email
$email = sanitize_email($_POST['email']);

// Textarea
$description = sanitize_textarea_field($_POST['description']);

// Integer
$id = absint($_POST['id']);

// Float
$amount = floatval($_POST['amount']);

// HTML
$content = wp_kses_post($_POST['content']);
```

### Output Escaping

```php
// Text
echo esc_html($variable);

// Attribute
echo esc_attr($variable);

// URL
echo esc_url($url);

// JavaScript
echo esc_js($variable);

// Textarea
echo esc_textarea($variable);
```

---

## Testing

### Unit Testing

```php
class Test_Building_Model extends WP_UnitTestCase {
    
    public function test_create_building() {
        $data = array(
            'organization_id' => 1,
            'name' => 'Test Building',
            'address' => '123 Test St',
        );
        
        $id = Rental_Gates_Building::create($data);
        
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);
        
        $building = Rental_Gates_Building::get($id);
        
        $this->assertEquals('Test Building', $building->name);
    }
    
    public function test_create_building_requires_name() {
        $data = array(
            'organization_id' => 1,
        );
        
        $result = Rental_Gates_Building::create($data);
        
        $this->assertWPError($result);
    }
}
```

### Integration Testing

```php
class Test_API_Buildings extends WP_Test_REST_TestCase {
    
    public function test_get_buildings() {
        wp_set_current_user($this->admin_user);
        
        $request = new WP_REST_Request('GET', '/rental-gates/v1/buildings');
        $response = rest_do_request($request);
        
        $this->assertEquals(200, $response->get_status());
        $this->assertTrue($response->get_data()['success']);
    }
}
```

---

## Performance

### Caching

```php
// Use transients for expensive queries
function get_expensive_data($org_id) {
    $cache_key = 'rg_expensive_data_' . $org_id;
    $data = get_transient($cache_key);
    
    if (false === $data) {
        // Expensive query
        $data = compute_expensive_data($org_id);
        set_transient($cache_key, $data, HOUR_IN_SECONDS);
    }
    
    return $data;
}

// Invalidate cache
function clear_expensive_data($org_id) {
    delete_transient('rg_expensive_data_' . $org_id);
}
```

### Query Optimization

```php
// Use specific columns
$wpdb->get_results("SELECT id, name FROM {$table}");

// Use proper indexes
// Ensure WHERE columns are indexed

// Limit results
$wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table} LIMIT %d OFFSET %d",
    20, 0
));

// Use prepared statements
$wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id);
```

### Lazy Loading

```php
// Load related data only when needed
class Building {
    private $units = null;
    
    public function get_units() {
        if ($this->units === null) {
            $this->units = Unit::get_by_building($this->id);
        }
        return $this->units;
    }
}
```

---

*Developer Guide v2.24.1*
