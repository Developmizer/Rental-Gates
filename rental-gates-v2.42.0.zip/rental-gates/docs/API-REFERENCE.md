# Rental Gates - API Reference

Complete REST API documentation for developers integrating with Rental Gates.

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Request Format](#request-format)
4. [Response Format](#response-format)
5. [Error Handling](#error-handling)
6. [Rate Limiting](#rate-limiting)
7. [Endpoints](#endpoints)
   - [Authentication](#authentication-endpoints)
   - [Organizations](#organizations)
   - [Buildings](#buildings)
   - [Units](#units)
   - [Tenants](#tenants)
   - [Leases](#leases)
   - [Applications](#applications)
   - [Payments](#payments)
   - [Maintenance](#maintenance)
   - [Vendors](#vendors)
   - [Leads](#leads)
   - [Messages](#messages)
   - [Notifications](#notifications)
   - [Documents](#documents)
   - [AI Tools](#ai-tools)
8. [Webhooks](#webhooks)
9. [Code Examples](#code-examples)

---

## Overview

### Base URL

```
https://yoursite.com/wp-json/rental-gates/v1
```

### API Version

Current version: `v1`

### Content Type

All requests should use:
```
Content-Type: application/json
```

### Character Encoding

UTF-8 encoding is required for all requests and responses.

---

## Authentication

### Methods

Rental Gates supports multiple authentication methods:

#### 1. WordPress Nonce (Browser Sessions)

For logged-in WordPress users:

```javascript
fetch('/wp-json/rental-gates/v1/buildings', {
    headers: {
        'X-WP-Nonce': rentalGatesData.restNonce
    }
});
```

#### 2. Application Passwords (Recommended for API)

WordPress 5.6+ includes Application Passwords:

1. Go to **Users → Profile → Application Passwords**
2. Create new password
3. Use in requests:

```bash
curl -X GET \
  https://yoursite.com/wp-json/rental-gates/v1/buildings \
  -u username:xxxx-xxxx-xxxx-xxxx-xxxx-xxxx
```

#### 3. JWT Token (Plugin Required)

With JWT Authentication plugin:

```bash
# Get token
curl -X POST \
  https://yoursite.com/wp-json/jwt-auth/v1/token \
  -d '{"username":"user","password":"pass"}'

# Use token
curl -X GET \
  https://yoursite.com/wp-json/rental-gates/v1/buildings \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Authentication Errors

| Code | Message | Solution |
|------|---------|----------|
| 401 | `rest_not_logged_in` | Provide authentication |
| 401 | `rest_cookie_invalid_nonce` | Refresh nonce |
| 403 | `rest_forbidden` | Check permissions |

---

## Request Format

### GET Requests

Query parameters for filtering and pagination:

```
GET /buildings?status=active&per_page=20&page=1
```

### POST/PUT Requests

JSON body for creating/updating:

```bash
curl -X POST \
  https://yoursite.com/wp-json/rental-gates/v1/buildings \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Sunset Apartments",
    "address": "123 Main St",
    "city": "Los Angeles",
    "state": "CA",
    "zip": "90001"
  }'
```

### DELETE Requests

```bash
curl -X DELETE \
  https://yoursite.com/wp-json/rental-gates/v1/buildings/123
```

---

## Response Format

### Success Response

```json
{
    "success": true,
    "data": {
        "id": 123,
        "name": "Sunset Apartments",
        ...
    }
}
```

### Collection Response

```json
{
    "success": true,
    "data": [...],
    "meta": {
        "total": 150,
        "per_page": 20,
        "current_page": 1,
        "last_page": 8
    }
}
```

### Error Response

```json
{
    "success": false,
    "error": {
        "code": "invalid_param",
        "message": "Invalid building ID",
        "data": {
            "param": "id"
        }
    }
}
```

---

## Error Handling

### HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 204 | No Content (deleted) |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 422 | Validation Error |
| 429 | Rate Limited |
| 500 | Server Error |

### Error Codes

| Code | Description |
|------|-------------|
| `invalid_param` | Invalid parameter value |
| `missing_param` | Required parameter missing |
| `not_found` | Resource not found |
| `already_exists` | Duplicate resource |
| `permission_denied` | Access denied |
| `rate_limited` | Too many requests |
| `validation_error` | Data validation failed |

---

## Rate Limiting

### Limits

| Endpoint Type | Limit |
|---------------|-------|
| Read (GET) | 100/minute |
| Write (POST/PUT) | 30/minute |
| Delete | 10/minute |
| Auth | 10/minute |

### Headers

Rate limit info in response headers:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
```

### Exceeded

When rate limited:

```json
{
    "code": "rate_limited",
    "message": "Rate limit exceeded. Retry after 60 seconds.",
    "data": {
        "retry_after": 60
    }
}
```

---

## Endpoints

### Authentication Endpoints

#### Login

```
POST /auth/login
```

**Request:**
```json
{
    "email": "user@example.com",
    "password": "password123"
}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "user": {
            "id": 1,
            "email": "user@example.com",
            "name": "John Doe"
        },
        "redirect": "/rental-gates/dashboard"
    }
}
```

#### Logout

```
POST /auth/logout
```

#### Get Current User

```
GET /auth/me
```

#### Password Reset Request

```
POST /auth/password-reset
```

**Request:**
```json
{
    "email": "user@example.com"
}
```

---

### Organizations

#### List Organizations

```
GET /organizations
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `search` | string | Search by name |
| `status` | string | active, suspended |
| `plan` | string | Plan slug |
| `per_page` | int | Results per page (default 20) |
| `page` | int | Page number |

#### Get Organization

```
GET /organizations/{id}
```

#### Create Organization

```
POST /organizations
```

**Request:**
```json
{
    "name": "ABC Properties",
    "email": "contact@abc.com",
    "phone": "555-123-4567",
    "address": "123 Business Ave",
    "city": "New York",
    "state": "NY",
    "zip": "10001"
}
```

#### Update Organization

```
PUT /organizations/{id}
```

#### Delete Organization

```
DELETE /organizations/{id}
```

---

### Buildings

#### List Buildings

```
GET /buildings
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `search` | string | Search by name/address |
| `status` | string | active, archived |
| `type` | string | apartment, house, commercial |
| `per_page` | int | Results per page |
| `page` | int | Page number |

#### Get Building

```
GET /buildings/{id}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "id": 1,
        "name": "Sunset Apartments",
        "slug": "sunset-apartments",
        "address": "123 Main St",
        "city": "Los Angeles",
        "state": "CA",
        "zip": "90001",
        "country": "US",
        "latitude": 34.0522,
        "longitude": -118.2437,
        "property_type": "apartment",
        "year_built": 1985,
        "total_floors": 3,
        "description": "Beautiful apartment complex...",
        "amenities": ["pool", "gym", "parking"],
        "images": [...],
        "units_count": 24,
        "vacant_count": 3,
        "occupancy_rate": 87.5,
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-06-20T14:45:00Z"
    }
}
```

#### Create Building

```
POST /buildings
```

**Request:**
```json
{
    "name": "Sunset Apartments",
    "address": "123 Main St",
    "city": "Los Angeles",
    "state": "CA",
    "zip": "90001",
    "latitude": 34.0522,
    "longitude": -118.2437,
    "property_type": "apartment",
    "year_built": 1985,
    "total_floors": 3,
    "description": "Beautiful apartment complex...",
    "amenities": ["pool", "gym", "parking"]
}
```

#### Update Building

```
PUT /buildings/{id}
```

#### Delete Building

```
DELETE /buildings/{id}
```

#### Get Building Units

```
GET /buildings/{id}/units
```

---

### Units

#### List Units

```
GET /units
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `building_id` | int | Filter by building |
| `status` | string | available, occupied, etc. |
| `bedrooms` | int | Number of bedrooms |
| `min_rent` | float | Minimum rent |
| `max_rent` | float | Maximum rent |
| `per_page` | int | Results per page |

#### Get Unit

```
GET /units/{id}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "id": 1,
        "building_id": 1,
        "unit_number": "101",
        "unit_type": "2br",
        "bedrooms": 2,
        "bathrooms": 1.5,
        "sqft": 950,
        "rent": 1500.00,
        "deposit": 1500.00,
        "availability_status": "available",
        "available_date": "2024-07-01",
        "floor": 1,
        "amenities": ["washer_dryer", "balcony"],
        "images": [...],
        "description": "Spacious 2-bedroom unit...",
        "created_at": "2024-01-15T10:30:00Z"
    }
}
```

#### Create Unit

```
POST /units
```

**Request:**
```json
{
    "building_id": 1,
    "unit_number": "101",
    "unit_type": "2br",
    "bedrooms": 2,
    "bathrooms": 1.5,
    "sqft": 950,
    "rent": 1500.00,
    "deposit": 1500.00,
    "availability_status": "available",
    "available_date": "2024-07-01",
    "floor": 1,
    "amenities": ["washer_dryer", "balcony"]
}
```

#### Update Unit

```
PUT /units/{id}
```

#### Delete Unit

```
DELETE /units/{id}
```

#### Update Availability

```
PUT /units/{id}/availability
```

**Request:**
```json
{
    "status": "coming_soon",
    "available_date": "2024-08-01"
}
```

---

### Tenants

#### List Tenants

```
GET /tenants
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `search` | string | Search name/email |
| `building_id` | int | Filter by building |
| `status` | string | active, past |
| `per_page` | int | Results per page |

#### Get Tenant

```
GET /tenants/{id}
```

#### Create Tenant

```
POST /tenants
```

**Request:**
```json
{
    "first_name": "John",
    "last_name": "Doe",
    "email": "john.doe@example.com",
    "phone": "555-123-4567",
    "emergency_contact": "Jane Doe",
    "emergency_phone": "555-987-6543"
}
```

#### Update Tenant

```
PUT /tenants/{id}
```

#### Delete Tenant

```
DELETE /tenants/{id}
```

#### Get Tenant Leases

```
GET /tenants/{id}/leases
```

#### Get Tenant Payments

```
GET /tenants/{id}/payments
```

---

### Leases

#### List Leases

```
GET /leases
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `building_id` | int | Filter by building |
| `unit_id` | int | Filter by unit |
| `tenant_id` | int | Filter by tenant |
| `status` | string | active, expired, etc. |
| `expiring_within` | int | Days until expiration |

#### Get Lease

```
GET /leases/{id}
```

#### Create Lease

```
POST /leases
```

**Request:**
```json
{
    "unit_id": 1,
    "tenant_ids": [1, 2],
    "start_date": "2024-07-01",
    "end_date": "2025-06-30",
    "rent_amount": 1500.00,
    "deposit_amount": 1500.00,
    "pet_deposit": 300.00,
    "late_fee": 50.00,
    "grace_period_days": 5,
    "payment_day": 1,
    "terms": "Standard lease terms..."
}
```

#### Update Lease

```
PUT /leases/{id}
```

#### Terminate Lease

```
POST /leases/{id}/terminate
```

**Request:**
```json
{
    "termination_date": "2024-09-30",
    "reason": "Mutual agreement",
    "notes": "Tenant relocating for work"
}
```

#### Create Renewal

```
POST /leases/{id}/renew
```

**Request:**
```json
{
    "new_end_date": "2026-06-30",
    "new_rent": 1550.00
}
```

---

### Applications

#### List Applications

```
GET /applications
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `unit_id` | int | Filter by unit |
| `status` | string | pending, approved, declined |

#### Get Application

```
GET /applications/{id}
```

#### Create Application

```
POST /applications
```

**Request:**
```json
{
    "unit_id": 1,
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "555-123-4567",
    "current_address": "456 Old St",
    "employer": "Acme Corp",
    "income": 5000.00,
    "move_in_date": "2024-08-01",
    "occupants": [
        {
            "name": "Jane Doe",
            "relationship": "spouse",
            "age": 35
        }
    ]
}
```

#### Update Application Status

```
PUT /applications/{id}/status
```

**Request:**
```json
{
    "status": "approved",
    "notes": "Application approved after verification"
}
```

---

### Payments

#### List Payments

```
GET /payments
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `lease_id` | int | Filter by lease |
| `tenant_id` | int | Filter by tenant |
| `status` | string | pending, completed, failed |
| `type` | string | rent, deposit, fee |
| `from_date` | date | Start date |
| `to_date` | date | End date |

#### Get Payment

```
GET /payments/{id}
```

#### Record Payment

```
POST /payments
```

**Request:**
```json
{
    "lease_id": 1,
    "amount": 1500.00,
    "payment_date": "2024-07-01",
    "payment_method": "card",
    "reference": "TXN123456",
    "items": [
        {
            "description": "July Rent",
            "amount": 1500.00,
            "type": "rent"
        }
    ]
}
```

#### Refund Payment

```
POST /payments/{id}/refund
```

**Request:**
```json
{
    "amount": 1500.00,
    "reason": "Duplicate payment"
}
```

---

### Maintenance

#### List Work Orders

```
GET /maintenance
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `building_id` | int | Filter by building |
| `unit_id` | int | Filter by unit |
| `status` | string | new, assigned, completed |
| `priority` | string | low, medium, high, emergency |
| `vendor_id` | int | Filter by vendor |

#### Get Work Order

```
GET /maintenance/{id}
```

#### Create Work Order

```
POST /maintenance
```

**Request:**
```json
{
    "unit_id": 1,
    "category": "plumbing",
    "priority": "medium",
    "title": "Leaky faucet",
    "description": "Kitchen faucet is dripping constantly",
    "access_instructions": "Key under mat"
}
```

#### Update Work Order

```
PUT /maintenance/{id}
```

#### Assign Vendor

```
POST /maintenance/{id}/assign
```

**Request:**
```json
{
    "vendor_id": 5,
    "notes": "Please call tenant first"
}
```

---

### Vendors

#### List Vendors

```
GET /vendors
```

#### Get Vendor

```
GET /vendors/{id}
```

#### Create Vendor

```
POST /vendors
```

**Request:**
```json
{
    "company_name": "Quick Fix Plumbing",
    "contact_name": "Mike Smith",
    "email": "mike@quickfix.com",
    "phone": "555-555-5555",
    "services": ["plumbing"],
    "hourly_rate": 75.00,
    "service_area": "Los Angeles County"
}
```

#### Update Vendor

```
PUT /vendors/{id}
```

#### Delete Vendor

```
DELETE /vendors/{id}
```

---

### Leads

#### List Leads

```
GET /leads
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `status` | string | new, contacted, toured, etc. |
| `source` | string | website, referral, etc. |
| `unit_id` | int | Interested unit |

#### Get Lead

```
GET /leads/{id}
```

#### Create Lead

```
POST /leads
```

**Request:**
```json
{
    "first_name": "Jane",
    "last_name": "Smith",
    "email": "jane@example.com",
    "phone": "555-111-2222",
    "source": "website",
    "interested_units": [1, 2],
    "move_in_date": "2024-09-01",
    "notes": "Looking for 2BR, pet-friendly"
}
```

#### Update Lead Status

```
PUT /leads/{id}/status
```

**Request:**
```json
{
    "status": "contacted",
    "notes": "Left voicemail"
}
```

---

### Messages

#### List Threads

```
GET /messages/threads
```

#### Get Thread

```
GET /messages/threads/{id}
```

#### Create Thread

```
POST /messages/threads
```

**Request:**
```json
{
    "recipient_id": 5,
    "subject": "Lease renewal",
    "message": "Hi, I wanted to discuss..."
}
```

#### Send Message

```
POST /messages/threads/{id}/messages
```

**Request:**
```json
{
    "content": "Thank you for getting back to me..."
}
```

---

### Notifications

#### List Notifications

```
GET /notifications
```

#### Mark as Read

```
PUT /notifications/{id}/read
```

#### Mark All as Read

```
PUT /notifications/read-all
```

---

### Documents

#### List Documents

```
GET /documents
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `entity_type` | string | building, unit, lease, tenant |
| `entity_id` | int | Related entity ID |
| `type` | string | lease, receipt, notice |

#### Upload Document

```
POST /documents
```

**Request (multipart/form-data):**
```
entity_type: lease
entity_id: 1
type: lease_agreement
file: [binary]
```

#### Delete Document

```
DELETE /documents/{id}
```

---

### AI Tools

#### Generate Listing Description

```
POST /ai/listing-description
```

**Request:**
```json
{
    "unit_id": 1,
    "style": "professional",
    "highlights": ["renovated kitchen", "great views"]
}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "description": "Stunning 2-bedroom apartment with breathtaking city views...",
        "credits_used": 1,
        "credits_remaining": 49
    }
}
```

#### Screen Application

```
POST /ai/screen-application
```

**Request:**
```json
{
    "application_id": 1
}
```

#### Get AI Usage

```
GET /ai/usage
```

---

## Webhooks

### Configuring Webhooks

Set webhook URL in **Site Admin → Integrations → Webhooks**

### Events

| Event | Trigger |
|-------|---------|
| `tenant.created` | New tenant added |
| `lease.created` | New lease created |
| `lease.signed` | Lease signed |
| `payment.completed` | Payment successful |
| `payment.failed` | Payment failed |
| `maintenance.created` | New work order |
| `maintenance.completed` | Work order done |
| `application.received` | New application |

### Webhook Payload

```json
{
    "event": "payment.completed",
    "timestamp": "2024-07-01T10:30:00Z",
    "data": {
        "id": 123,
        "lease_id": 1,
        "amount": 1500.00,
        ...
    }
}
```

### Verifying Webhooks

Verify signature in `X-RG-Signature` header:

```php
$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_RG_SIGNATURE'];
$secret = 'your_webhook_secret';

$expected = hash_hmac('sha256', $payload, $secret);

if (hash_equals($expected, $signature)) {
    // Valid webhook
}
```

---

## Code Examples

### PHP

```php
<?php
// Using WordPress HTTP API
$response = wp_remote_get(
    rest_url('rental-gates/v1/buildings'),
    array(
        'headers' => array(
            'X-WP-Nonce' => wp_create_nonce('wp_rest')
        )
    )
);

$buildings = json_decode(wp_remote_retrieve_body($response), true);
```

### JavaScript

```javascript
// Using Fetch API
const response = await fetch('/wp-json/rental-gates/v1/buildings', {
    headers: {
        'X-WP-Nonce': rentalGatesData.restNonce
    }
});

const data = await response.json();
console.log(data.data);
```

### cURL

```bash
# List buildings
curl -X GET \
  "https://yoursite.com/wp-json/rental-gates/v1/buildings" \
  -u username:application-password

# Create building
curl -X POST \
  "https://yoursite.com/wp-json/rental-gates/v1/buildings" \
  -u username:application-password \
  -H "Content-Type: application/json" \
  -d '{
    "name": "New Building",
    "address": "123 New St"
  }'
```

### Python

```python
import requests
from requests.auth import HTTPBasicAuth

auth = HTTPBasicAuth('username', 'application-password')
base_url = 'https://yoursite.com/wp-json/rental-gates/v1'

# Get buildings
response = requests.get(f'{base_url}/buildings', auth=auth)
buildings = response.json()

# Create building
new_building = {
    'name': 'New Building',
    'address': '123 New St'
}
response = requests.post(
    f'{base_url}/buildings',
    json=new_building,
    auth=auth
)
```

---

*API Reference v2.24.1*
