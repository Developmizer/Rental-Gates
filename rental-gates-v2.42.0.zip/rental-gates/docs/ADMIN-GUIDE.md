# Rental Gates - Site Admin Guide

Complete guide for platform administrators managing the Rental Gates installation.

---

## Table of Contents

1. [Admin Dashboard Overview](#admin-dashboard-overview)
2. [Organization Management](#organization-management)
3. [User Management](#user-management)
4. [Subscription Plans](#subscription-plans)
5. [Platform Settings](#platform-settings)
6. [Integrations](#integrations)
7. [Email Templates](#email-templates)
8. [Feature Flags](#feature-flags)
9. [PWA Settings](#pwa-settings)
10. [Activity Monitoring](#activity-monitoring)
11. [Reports & Analytics](#reports--analytics)
12. [System Health](#system-health)
13. [Support Tools](#support-tools)
14. [Security Best Practices](#security-best-practices)

---

## Admin Dashboard Overview

Access the Site Admin dashboard at:
```
https://yoursite.com/rental-gates/admin
```

### Who Can Access

- WordPress Administrators
- Users with `rg_manage_platform` capability

### Admin Navigation

```
📊 Dashboard        - Platform overview
🏢 Organizations    - Manage all organizations
👥 Users            - User management
💳 Plans            - Subscription plans
⚙️ Settings         - Platform configuration
📧 Email Templates  - Customize emails
🔌 Integrations     - API connections
🚀 Feature Flags    - Enable/disable features
📱 PWA Settings     - Progressive web app
📋 Activity Log     - Audit trail
📊 Reports          - Platform analytics
🖥️ System Health    - Server diagnostics
🛠️ Support Tools    - Troubleshooting
```

### Dashboard Metrics

The admin dashboard shows:

| Metric | Description |
|--------|-------------|
| Total Organizations | Active accounts on platform |
| Total Users | All registered users |
| Total Buildings | Properties across all orgs |
| Total Units | Units across all orgs |
| Monthly Recurring Revenue | Subscription income |
| Active Subscriptions | Paying customers |
| Trial Accounts | Organizations in trial |
| Churn Rate | Cancellation percentage |

---

## Organization Management

### Viewing Organizations

1. Go to **Organizations**
2. See list with:
   - Organization name
   - Owner name/email
   - Plan
   - Status
   - Created date
   - Last activity

### Organization Details

Click an organization to see:

- **Overview** - Key stats
- **Members** - Users in organization
- **Buildings** - Properties managed
- **Subscription** - Plan and billing
- **Activity** - Recent actions
- **Settings** - Org-specific settings

### Organization Actions

| Action | Description |
|--------|-------------|
| **View As** | Log in as org owner (support mode) |
| **Edit** | Modify organization details |
| **Change Plan** | Upgrade/downgrade subscription |
| **Suspend** | Temporarily disable access |
| **Delete** | Permanently remove (careful!) |

### Creating an Organization

1. Click **Add Organization**
2. Enter details:
   - Organization name
   - Owner name
   - Owner email
   - Initial plan
3. Click **Create**
4. Owner receives welcome email

### Suspending an Organization

When suspended:
- Users cannot log in
- Data is preserved
- Subscription is paused
- Can be reactivated

To suspend:
1. Go to organization detail
2. Click **Suspend**
3. Enter reason
4. Confirm

### Deleting an Organization

**Warning:** This permanently removes:
- All organization data
- Buildings, units, tenants
- Leases, payments
- All related records

To delete:
1. Go to organization detail
2. Click **Delete**
3. Type organization name to confirm
4. Click **Permanently Delete**

---

## User Management

### User List

View all users across the platform:

| Column | Description |
|--------|-------------|
| Name | User display name |
| Email | Login email |
| Role | User role(s) |
| Organization | Associated org(s) |
| Last Login | Most recent activity |
| Status | Active/Suspended |

### User Roles

| Role | Scope | Description |
|------|-------|-------------|
| Site Admin | Platform | Full platform access |
| Owner | Organization | Organization owner |
| Property Manager | Organization | Manage properties/staff |
| Staff | Organization | Limited access |
| Tenant | Organization | Tenant portal only |
| Vendor | Organization | Vendor portal only |

### User Actions

| Action | Description |
|--------|-------------|
| **View** | See user details |
| **Edit** | Modify user info |
| **Reset Password** | Send reset email |
| **Suspend** | Disable login |
| **Delete** | Remove user |
| **Impersonate** | Log in as user (support) |

### Adding Users

Site admins are added through WordPress:
1. Go to **WordPress Admin → Users**
2. Add new user
3. Assign `administrator` role
4. They can access Site Admin

### Impersonation (Support Mode)

For troubleshooting:
1. Find user in list
2. Click **Impersonate**
3. You're logged in as that user
4. Yellow banner shows active impersonation
5. Click **Exit** to return

All actions are logged with "[Impersonating]" tag.

---

## Subscription Plans

### Default Plans

Rental Gates comes with 4 default plans:

| Plan | Price | Units | Buildings | Features |
|------|-------|-------|-----------|----------|
| **Free** | $0 | 5 | 1 | Basic features |
| **Starter** | $29/mo | 25 | 3 | + Payments, Reports |
| **Professional** | $79/mo | 100 | 10 | + AI, Automation |
| **Enterprise** | $199/mo | Unlimited | Unlimited | All features |

### Managing Plans

1. Go to **Plans**
2. Click plan to edit
3. Modify:
   - Name
   - Price
   - Billing interval
   - Unit/building limits
   - Features included
4. Save changes

### Creating a Plan

1. Click **Add Plan**
2. Configure:

| Field | Description |
|-------|-------------|
| Name | Plan display name |
| Slug | URL-friendly identifier |
| Price | Monthly amount |
| Interval | monthly/yearly |
| Trial Days | Free trial length |
| Unit Limit | Max units allowed |
| Building Limit | Max buildings allowed |

3. Select features to include
4. Click **Create Plan**

### Plan Features

Toggle features per plan:

| Feature | Description |
|---------|-------------|
| Online Payments | Stripe rent collection |
| AI Tools | OpenAI integration |
| Automation | Scheduled tasks |
| Reports | Analytics dashboard |
| API Access | REST API usage |
| Custom Branding | White-label options |
| Priority Support | Faster response |

### Changing a Customer's Plan

1. Go to **Organizations**
2. Click organization
3. Click **Change Plan**
4. Select new plan
5. Choose:
   - Immediate change
   - End of billing period
6. Confirm

---

## Platform Settings

### General Settings

| Setting | Description |
|---------|-------------|
| Platform Name | Shown in emails, UI |
| Support Email | Contact email |
| Support URL | Help center link |
| Terms URL | Terms of service |
| Privacy URL | Privacy policy |

### Registration Settings

| Setting | Description |
|---------|-------------|
| Allow Registration | Enable/disable signups |
| Default Plan | Plan for new orgs |
| Trial Days | Default trial length |
| Require Email Verification | Verify before access |
| Allowed Email Domains | Restrict signups (optional) |

### Security Settings

| Setting | Description |
|---------|-------------|
| Session Timeout | Auto-logout time |
| Password Requirements | Minimum length, complexity |
| Rate Limiting | Requests per minute |
| Failed Login Lockout | Attempts before lock |
| Two-Factor Auth | Enable 2FA option |

### Payment Settings

| Setting | Description |
|---------|-------------|
| Currency | Default currency |
| Payment Retry | Auto-retry failed payments |
| Grace Period | Days before suspension |
| Invoice Prefix | e.g., "INV-" |

---

## Integrations

### Stripe Configuration

1. Go to **Integrations → Stripe**
2. Enter API keys:
   - Test Publishable Key
   - Test Secret Key
   - Live Publishable Key
   - Live Secret Key
   - Webhook Secret
3. Configure webhook URL:
   ```
   https://yoursite.com/wp-json/rental-gates/v1/stripe/webhook
   ```
4. Select events to listen for
5. Save

### OpenAI Configuration

1. Go to **Integrations → OpenAI**
2. Enter API Key
3. Select default model:
   - GPT-3.5 Turbo (faster, cheaper)
   - GPT-4 (more accurate)
4. Set monthly credit limits
5. Save

### Google Maps Configuration

1. Go to **Integrations → Maps**
2. Select **Google Maps**
3. Enter API Key
4. Enable required APIs in Google Console:
   - Maps JavaScript API
   - Places API
   - Geocoding API
5. Save

### OpenStreetMap

Free alternative to Google Maps:
1. Go to **Integrations → Maps**
2. Select **OpenStreetMap**
3. No API key required
4. Save

---

## Email Templates

### Customizing Templates

1. Go to **Email Templates**
2. Select template to edit
3. Modify:
   - Subject line
   - Body content
   - Variables
4. Preview
5. Save

### Available Templates

| Template | Trigger |
|----------|---------|
| Welcome | New user registration |
| Password Reset | Password reset request |
| Tenant Invitation | Invite to portal |
| Staff Invitation | New staff member |
| Vendor Invitation | New vendor |
| Application Received | New application |
| Application Approved | Application approved |
| Application Declined | Application declined |
| Lease Created | New lease |
| Lease Signed | Lease executed |
| Lease Ending | Expiration reminder |
| Payment Receipt | Payment confirmation |
| Payment Reminder | Upcoming payment |
| Payment Overdue | Past due notice |
| Payment Failed | Card declined |
| Maintenance Created | New work order |
| Maintenance Update | Status change |
| Maintenance Completed | Work finished |
| Announcement | Broadcast message |
| Lead Followup | CRM automation |

### Template Variables

Use double braces for dynamic content:

| Variable | Output |
|----------|--------|
| `{{tenant_name}}` | John Smith |
| `{{unit_number}}` | Unit 101 |
| `{{building_name}}` | Sunset Apartments |
| `{{rent_amount}}` | $1,500.00 |
| `{{due_date}}` | January 1, 2025 |
| `{{payment_amount}}` | $1,500.00 |
| `{{lease_start}}` | January 1, 2025 |
| `{{lease_end}}` | December 31, 2025 |
| `{{organization_name}}` | ABC Properties |
| `{{login_url}}` | Link to login |
| `{{dashboard_url}}` | Link to dashboard |

### Email Branding

Customize appearance:
1. Go to **Settings → Branding**
2. Upload logo
3. Set primary color
4. Set footer text
5. Preview email
6. Save

---

## Feature Flags

Control feature availability across the platform.

### Available Flags

| Flag | Description |
|------|-------------|
| `payments_enabled` | Online payment processing |
| `ai_enabled` | AI-powered features |
| `automation_enabled` | Scheduled automations |
| `qr_codes_enabled` | QR code generation |
| `flyers_enabled` | Marketing flyer creator |
| `api_access_enabled` | REST API access |
| `multi_building` | Multiple buildings per org |
| `custom_branding` | White-label options |
| `advanced_reports` | Extended reporting |

### Managing Flags

1. Go to **Feature Flags**
2. Toggle flags on/off
3. Set scope:
   - Global (all orgs)
   - Per-plan basis
   - Per-organization
4. Save changes

### Per-Organization Overrides

Override flags for specific organizations:
1. Go to organization detail
2. Click **Feature Overrides**
3. Enable/disable specific features
4. Save

---

## PWA Settings

Configure Progressive Web App features.

### General Settings

| Setting | Description |
|---------|-------------|
| Enable PWA | Master switch |
| App Name | Full app name |
| Short Name | Icon label (max 12 chars) |
| Description | App description |
| Theme Color | Browser toolbar color |
| Background Color | Splash screen color |
| Display Mode | standalone/fullscreen |

### Push Notifications

1. Enable **Push Notifications**
2. VAPID keys generate automatically
3. Users can subscribe in their settings
4. Send notifications via:
   - Announcements
   - API calls
   - Automated triggers

### Testing PWA

1. Open site in Chrome
2. Open DevTools (F12)
3. Go to **Application** tab
4. Check **Manifest**
5. Check **Service Workers**
6. Test **Add to Home Screen**

---

## Activity Monitoring

### Activity Log

Track all significant actions:

| Logged Events |
|---------------|
| User login/logout |
| Organization created/modified |
| Building added/edited |
| Lease created/signed |
| Payment processed |
| Settings changed |
| User role changes |
| Failed login attempts |

### Viewing Activity

1. Go to **Activity Log**
2. Filter by:
   - Date range
   - User
   - Organization
   - Action type
3. Search for specific events
4. Export if needed

### Retention

Activity logs are retained for:
- 90 days (default)
- Configurable in settings
- Older logs auto-purged

### Audit Requirements

For compliance, export logs:
1. Go to **Activity Log**
2. Set date range
3. Click **Export**
4. Download CSV/PDF

---

## Reports & Analytics

### Platform Reports

| Report | Description |
|--------|-------------|
| Revenue | MRR, ARR, growth |
| Signups | New registrations |
| Churn | Cancellations |
| Usage | Feature utilization |
| Organizations | Org statistics |

### Generating Reports

1. Go to **Reports**
2. Select report type
3. Set parameters:
   - Date range
   - Grouping
   - Filters
4. Generate
5. View or export

### Scheduled Reports

Automate report delivery:
1. Click **Schedule Report**
2. Select report
3. Set frequency
4. Add recipients
5. Save

---

## System Health

### Health Dashboard

Monitor server status:

| Check | Healthy | Warning | Critical |
|-------|---------|---------|----------|
| PHP Version | 8.1+ | 7.4-8.0 | < 7.4 |
| Memory | < 50% | 50-80% | > 80% |
| Database | Connected | Slow | Failed |
| Cron | Running | Delayed | Stopped |
| SSL | Valid | Expiring | Invalid |
| Disk Space | < 70% | 70-90% | > 90% |

### Database Status

View table information:
- Total tables (49)
- Total rows
- Database size
- Recent queries

### Cron Jobs

Monitor scheduled tasks:

| Job | Schedule | Last Run | Status |
|-----|----------|----------|--------|
| Availability Check | Hourly | Time | ✓ |
| Notifications | Daily | Time | ✓ |
| AI Credits Reset | Daily | Time | ✓ |
| Cleanup | Weekly | Time | ✓ |

### Server Information

View environment details:
- WordPress version
- PHP version
- MySQL version
- Active plugins
- Theme info
- Memory usage

---

## Support Tools

### Impersonation

Log in as any user for troubleshooting:
1. Go to **Support Tools**
2. Search for user
3. Click **Impersonate**
4. Troubleshoot as that user
5. Click **Exit** to return

### Cache Management

Clear various caches:
- Object cache
- Transients
- Rewrite rules
- Option autoloads

### Debug Mode

Enable for detailed logging:
1. Set `WP_DEBUG` to `true`
2. Check `/wp-content/debug.log`
3. Remember to disable in production

### Data Export

Export data for organizations:
1. Select organization
2. Choose data types
3. Select format (JSON/CSV)
4. Download

### Bulk Operations

Perform actions across organizations:
- Send announcements
- Apply plan changes
- Enable features
- Clear caches

---

## Security Best Practices

### Platform Security

1. **Keep Updated**
   - WordPress core
   - All plugins
   - Rental Gates

2. **Strong Passwords**
   - Enforce complexity
   - Regular rotation
   - No shared accounts

3. **Access Control**
   - Minimal permissions
   - Regular audits
   - Remove unused accounts

4. **HTTPS Required**
   - Valid SSL certificate
   - Force HTTPS redirect
   - HSTS enabled

5. **Backup Strategy**
   - Daily database backups
   - Weekly full backups
   - Off-site storage
   - Test restores

### Monitoring

1. **Activity Logs**
   - Review regularly
   - Alert on anomalies
   - Archive for compliance

2. **Failed Logins**
   - Monitor patterns
   - Investigate spikes
   - Block suspicious IPs

3. **API Usage**
   - Track endpoint usage
   - Monitor rate limits
   - Investigate abuse

### Incident Response

If you suspect a breach:

1. **Contain**
   - Disable affected accounts
   - Revoke API keys
   - Block suspicious IPs

2. **Investigate**
   - Review activity logs
   - Check access patterns
   - Identify scope

3. **Remediate**
   - Reset passwords
   - Patch vulnerabilities
   - Update credentials

4. **Communicate**
   - Notify affected users
   - Document incident
   - Report if required

---

## Maintenance Checklist

### Daily
- [ ] Check system health
- [ ] Review failed payments
- [ ] Monitor error logs

### Weekly
- [ ] Review activity logs
- [ ] Check backup status
- [ ] Review support requests

### Monthly
- [ ] Generate revenue reports
- [ ] Review churn metrics
- [ ] Update documentation
- [ ] Security audit

### Quarterly
- [ ] Full security review
- [ ] Performance optimization
- [ ] Feature usage analysis
- [ ] Plan pricing review

---

*Admin Guide v2.24.1*
