/**
 * Rental Gates PWA Module
 * Handles service worker, install prompt, push notifications, and offline support
 * 
 * @version 2.24.0
 */

(function () {
    'use strict';

    const RentalGatesPWA = {

        // Configuration
        config: {
            serviceWorkerPath: '/wp-content/plugins/rental-gates/assets/js/service-worker.js',
            vapidPublicKey: null,
            debug: false
        },

        // State
        state: {
            isInstalled: false,
            isOnline: navigator.onLine,
            deferredPrompt: null,
            swRegistration: null,
            pushSubscription: null
        },

        /**
         * Initialize PWA
         */
        init: function (options = {}) {
            this.config = { ...this.config, ...options };

            if (this.config.debug) {
                console.log('[PWA] Initializing...');
            }

            // Check if already installed
            this.checkInstallState();

            // Register service worker
            this.registerServiceWorker();

            // Set up online/offline handlers
            this.setupNetworkHandlers();

            // Set up install prompt handler
            this.setupInstallPrompt();

            // Set up UI elements
            this.setupUI();

            // Check for updates periodically
            this.checkForUpdates();
        },

        /**
         * Register Service Worker
         */
        registerServiceWorker: async function () {
            if (!('serviceWorker' in navigator)) {
                console.log('[PWA] Service Workers not supported');
                return;
            }

            try {
                // Note: Service worker scope is limited to its directory by default.
                // For broader scope, the server must send Service-Worker-Allowed header.
                const registration = await navigator.serviceWorker.register(
                    this.config.serviceWorkerPath
                    // Scope intentionally omitted - see https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerContainer/register
                );

                this.state.swRegistration = registration;

                if (this.config.debug) {
                    console.log('[PWA] Service Worker registered:', registration.scope);
                }

                // Handle updates
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;

                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            this.showUpdateNotification();
                        }
                    });
                });

                // Listen for messages from service worker
                navigator.serviceWorker.addEventListener('message', (event) => {
                    this.handleServiceWorkerMessage(event.data);
                });

                // Initialize push notifications if supported
                this.initPushNotifications();

            } catch (error) {
                console.error('[PWA] Service Worker registration failed:', error);
            }
        },

        /**
         * Setup network status handlers
         */
        setupNetworkHandlers: function () {
            window.addEventListener('online', () => {
                this.state.isOnline = true;
                this.showNetworkStatus('online');
                this.syncOfflineData();
            });

            window.addEventListener('offline', () => {
                this.state.isOnline = false;
                this.showNetworkStatus('offline');
            });
        },

        /**
         * Show network status notification
         */
        showNetworkStatus: function (status) {
            const notification = document.createElement('div');
            notification.className = 'rg-pwa-network-status ' + status;
            notification.innerHTML = status === 'online'
                ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg> Back online'
                : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.58 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg> You\'re offline';

            document.body.appendChild(notification);

            // Animate in
            requestAnimationFrame(() => {
                notification.classList.add('visible');
            });

            // Remove after delay
            setTimeout(() => {
                notification.classList.remove('visible');
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        },

        /**
         * Setup install prompt handler
         */
        setupInstallPrompt: function () {
            window.addEventListener('beforeinstallprompt', (e) => {
                e.preventDefault();
                this.state.deferredPrompt = e;

                if (this.config.debug) {
                    console.log('[PWA] Install prompt deferred');
                }

                // Show install button
                this.showInstallButton();
            });

            // Handle app installed
            window.addEventListener('appinstalled', () => {
                this.state.isInstalled = true;
                this.state.deferredPrompt = null;
                this.hideInstallButton();

                if (this.config.debug) {
                    console.log('[PWA] App installed');
                }

                // Track installation
                this.trackEvent('pwa_installed');
            });
        },

        /**
         * Check if app is already installed
         */
        checkInstallState: function () {
            // Check display mode
            if (window.matchMedia('(display-mode: standalone)').matches) {
                this.state.isInstalled = true;
            }

            // Check iOS standalone
            if (window.navigator.standalone === true) {
                this.state.isInstalled = true;
            }

            // Check referrer (Android TWA)
            if (document.referrer.includes('android-app://')) {
                this.state.isInstalled = true;
            }
        },

        /**
         * Setup UI elements
         */
        setupUI: function () {
            // Add CSS
            this.addStyles();

            // Create install banner (hidden by default)
            this.createInstallBanner();

            // Create update notification (hidden by default)
            this.createUpdateNotification();
        },

        /**
         * Add PWA styles
         */
        addStyles: function () {
            const styles = `
                .rg-pwa-network-status {
                    position: fixed;
                    bottom: 80px;
                    left: 50%;
                    transform: translateX(-50%) translateY(100px);
                    background: #1f2937;
                    color: white;
                    padding: 12px 20px;
                    border-radius: 8px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    font-size: 14px;
                    font-weight: 500;
                    z-index: 10000;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    transition: transform 0.3s ease;
                }
                .rg-pwa-network-status.visible {
                    transform: translateX(-50%) translateY(0);
                }
                .rg-pwa-network-status svg {
                    width: 20px;
                    height: 20px;
                }
                .rg-pwa-network-status.online {
                    background: #059669;
                }
                .rg-pwa-network-status.offline {
                    background: #dc2626;
                }
                
                .rg-pwa-install-banner {
                    position: fixed;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background: white;
                    padding: 16px 20px;
                    display: none;
                    align-items: center;
                    gap: 16px;
                    box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
                    z-index: 9999;
                    border-top: 1px solid #e5e7eb;
                }
                .rg-pwa-install-banner.visible {
                    display: flex;
                }
                .rg-pwa-install-banner .icon {
                    width: 48px;
                    height: 48px;
                    border-radius: 12px;
                    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-shrink: 0;
                }
                .rg-pwa-install-banner .icon svg {
                    width: 28px;
                    height: 28px;
                    color: white;
                }
                .rg-pwa-install-banner .content {
                    flex: 1;
                }
                .rg-pwa-install-banner .title {
                    font-weight: 600;
                    color: #111827;
                    margin-bottom: 2px;
                }
                .rg-pwa-install-banner .subtitle {
                    font-size: 13px;
                    color: #6b7280;
                }
                .rg-pwa-install-banner .actions {
                    display: flex;
                    gap: 8px;
                }
                .rg-pwa-install-banner .btn {
                    padding: 10px 20px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: 500;
                    border: none;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .rg-pwa-install-banner .btn-primary {
                    background: #2563eb;
                    color: white;
                }
                .rg-pwa-install-banner .btn-primary:hover {
                    background: #1d4ed8;
                }
                .rg-pwa-install-banner .btn-secondary {
                    background: #f3f4f6;
                    color: #374151;
                }
                .rg-pwa-install-banner .btn-secondary:hover {
                    background: #e5e7eb;
                }
                .rg-pwa-install-banner .close {
                    position: absolute;
                    top: 8px;
                    right: 8px;
                    background: none;
                    border: none;
                    padding: 4px;
                    cursor: pointer;
                    color: #9ca3af;
                }
                
                .rg-pwa-update-notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #1f2937;
                    color: white;
                    padding: 16px 20px;
                    border-radius: 12px;
                    display: none;
                    align-items: center;
                    gap: 12px;
                    z-index: 10001;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                    max-width: 360px;
                }
                .rg-pwa-update-notification.visible {
                    display: flex;
                }
                .rg-pwa-update-notification .content {
                    flex: 1;
                }
                .rg-pwa-update-notification .title {
                    font-weight: 600;
                    margin-bottom: 4px;
                }
                .rg-pwa-update-notification .subtitle {
                    font-size: 13px;
                    opacity: 0.8;
                }
                .rg-pwa-update-notification .btn {
                    padding: 8px 16px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    font-size: 13px;
                    font-weight: 500;
                    cursor: pointer;
                    white-space: nowrap;
                }
                .rg-pwa-update-notification .btn:hover {
                    background: #1d4ed8;
                }
                
                @media (max-width: 480px) {
                    .rg-pwa-install-banner {
                        flex-wrap: wrap;
                        padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px));
                    }
                    .rg-pwa-install-banner .actions {
                        width: 100%;
                        justify-content: stretch;
                    }
                    .rg-pwa-install-banner .btn {
                        flex: 1;
                    }
                    .rg-pwa-update-notification {
                        left: 20px;
                        right: 20px;
                        max-width: none;
                    }
                }
            `;

            const styleSheet = document.createElement('style');
            styleSheet.textContent = styles;
            document.head.appendChild(styleSheet);
        },

        /**
         * Create install banner
         */
        createInstallBanner: function () {
            const banner = document.createElement('div');
            banner.className = 'rg-pwa-install-banner';
            banner.id = 'rg-pwa-install-banner';
            banner.innerHTML = `
                <div class="icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                </div>
                <div class="content">
                    <div class="title">Install Rental Gates</div>
                    <div class="subtitle">Add to home screen for quick access</div>
                </div>
                <div class="actions">
                    <button class="btn btn-secondary" id="rg-pwa-install-later">Later</button>
                    <button class="btn btn-primary" id="rg-pwa-install-now">Install</button>
                </div>
                <button class="close" id="rg-pwa-install-close">&times;</button>
            `;

            document.body.appendChild(banner);

            // Event listeners
            document.getElementById('rg-pwa-install-now').addEventListener('click', () => {
                this.promptInstall();
            });

            document.getElementById('rg-pwa-install-later').addEventListener('click', () => {
                this.hideInstallButton();
                localStorage.setItem('rg_pwa_install_dismissed', Date.now());
            });

            document.getElementById('rg-pwa-install-close').addEventListener('click', () => {
                this.hideInstallButton();
                localStorage.setItem('rg_pwa_install_dismissed', Date.now());
            });
        },

        /**
         * Create update notification
         */
        createUpdateNotification: function () {
            const notification = document.createElement('div');
            notification.className = 'rg-pwa-update-notification';
            notification.id = 'rg-pwa-update-notification';
            notification.innerHTML = `
                <div class="content">
                    <div class="title">Update Available</div>
                    <div class="subtitle">A new version of Rental Gates is ready</div>
                </div>
                <button class="btn" id="rg-pwa-update-now">Update Now</button>
            `;

            document.body.appendChild(notification);

            document.getElementById('rg-pwa-update-now').addEventListener('click', () => {
                this.applyUpdate();
            });
        },

        /**
         * Show install button
         */
        showInstallButton: function () {
            // Check if dismissed recently (within 24 hours)
            const dismissed = localStorage.getItem('rg_pwa_install_dismissed');
            if (dismissed && Date.now() - parseInt(dismissed) < 24 * 60 * 60 * 1000) {
                return;
            }

            const banner = document.getElementById('rg-pwa-install-banner');
            if (banner) {
                banner.classList.add('visible');
            }
        },

        /**
         * Hide install button
         */
        hideInstallButton: function () {
            const banner = document.getElementById('rg-pwa-install-banner');
            if (banner) {
                banner.classList.remove('visible');
            }
        },

        /**
         * Prompt app installation
         */
        promptInstall: async function () {
            if (!this.state.deferredPrompt) {
                // Show iOS instructions
                if (this.isIOS()) {
                    this.showIOSInstallInstructions();
                }
                return;
            }

            this.state.deferredPrompt.prompt();

            const result = await this.state.deferredPrompt.userChoice;

            if (this.config.debug) {
                console.log('[PWA] Install prompt result:', result.outcome);
            }

            this.state.deferredPrompt = null;
            this.hideInstallButton();
        },

        /**
         * Show iOS install instructions
         */
        showIOSInstallInstructions: function () {
            const modal = document.createElement('div');
            modal.className = 'rg-pwa-ios-modal';
            modal.innerHTML = `
                <div class="rg-pwa-ios-modal-content">
                    <div class="rg-pwa-ios-modal-header">
                        <h3>Install Rental Gates</h3>
                        <button class="close">&times;</button>
                    </div>
                    <div class="rg-pwa-ios-modal-body">
                        <p>To install this app on your iPhone:</p>
                        <ol>
                            <li>Tap the <strong>Share</strong> button <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg></li>
                            <li>Scroll down and tap <strong>Add to Home Screen</strong></li>
                            <li>Tap <strong>Add</strong> in the top right corner</li>
                        </ol>
                    </div>
                </div>
            `;

            // Add styles
            const style = document.createElement('style');
            style.textContent = `
                .rg-pwa-ios-modal {
                    position: fixed;
                    inset: 0;
                    background: rgba(0,0,0,0.5);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                    z-index: 10002;
                }
                .rg-pwa-ios-modal-content {
                    background: white;
                    border-radius: 16px;
                    max-width: 360px;
                    width: 100%;
                    overflow: hidden;
                }
                .rg-pwa-ios-modal-header {
                    padding: 16px 20px;
                    border-bottom: 1px solid #e5e7eb;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .rg-pwa-ios-modal-header h3 {
                    margin: 0;
                    font-size: 18px;
                }
                .rg-pwa-ios-modal-header .close {
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                    color: #6b7280;
                }
                .rg-pwa-ios-modal-body {
                    padding: 20px;
                }
                .rg-pwa-ios-modal-body p {
                    margin: 0 0 16px;
                    color: #374151;
                }
                .rg-pwa-ios-modal-body ol {
                    margin: 0;
                    padding-left: 20px;
                }
                .rg-pwa-ios-modal-body li {
                    margin-bottom: 12px;
                    color: #4b5563;
                    line-height: 1.5;
                }
                .rg-pwa-ios-modal-body svg {
                    vertical-align: middle;
                    margin: 0 4px;
                }
            `;
            document.head.appendChild(style);
            document.body.appendChild(modal);

            modal.querySelector('.close').addEventListener('click', () => {
                modal.remove();
            });

            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                }
            });
        },

        /**
         * Check if iOS
         */
        isIOS: function () {
            return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        },

        /**
         * Show update notification
         */
        showUpdateNotification: function () {
            const notification = document.getElementById('rg-pwa-update-notification');
            if (notification) {
                notification.classList.add('visible');
            }
        },

        /**
         * Apply service worker update
         */
        applyUpdate: function () {
            if (this.state.swRegistration && this.state.swRegistration.waiting) {
                this.state.swRegistration.waiting.postMessage({ type: 'SKIP_WAITING' });
            }

            window.location.reload();
        },

        /**
         * Check for updates periodically
         */
        checkForUpdates: function () {
            if (!this.state.swRegistration) return;

            // Check every hour
            setInterval(() => {
                this.state.swRegistration.update();
            }, 60 * 60 * 1000);
        },

        /**
         * Initialize push notifications
         */
        initPushNotifications: async function () {
            if (!('PushManager' in window)) {
                console.log('[PWA] Push notifications not supported');
                return;
            }

            if (!this.state.swRegistration) {
                return;
            }

            try {
                this.state.pushSubscription = await this.state.swRegistration.pushManager.getSubscription();

                if (this.config.debug) {
                    console.log('[PWA] Push subscription:', this.state.pushSubscription);
                }
            } catch (error) {
                console.error('[PWA] Push init error:', error);
            }
        },

        /**
         * Subscribe to push notifications
         */
        subscribeToPush: async function () {
            if (!this.state.swRegistration || !this.config.vapidPublicKey) {
                console.error('[PWA] Cannot subscribe: missing registration or VAPID key');
                return null;
            }

            try {
                const permission = await Notification.requestPermission();

                if (permission !== 'granted') {
                    console.log('[PWA] Push notification permission denied');
                    return null;
                }

                const subscription = await this.state.swRegistration.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey: this.urlBase64ToUint8Array(this.config.vapidPublicKey)
                });

                this.state.pushSubscription = subscription;

                // Send subscription to server
                await this.sendSubscriptionToServer(subscription);

                return subscription;

            } catch (error) {
                console.error('[PWA] Push subscription failed:', error);
                return null;
            }
        },

        /**
         * Unsubscribe from push notifications
         */
        unsubscribeFromPush: async function () {
            if (!this.state.pushSubscription) {
                return true;
            }

            try {
                await this.state.pushSubscription.unsubscribe();
                this.state.pushSubscription = null;

                // Notify server
                await this.removeSubscriptionFromServer();

                return true;
            } catch (error) {
                console.error('[PWA] Unsubscribe failed:', error);
                return false;
            }
        },

        /**
         * Send subscription to server
         */
        sendSubscriptionToServer: async function (subscription) {
            try {
                const response = await fetch('/wp-json/rental-gates/v1/push/subscribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': window.rentalGatesData?.nonce || ''
                    },
                    body: JSON.stringify({
                        subscription: subscription.toJSON()
                    })
                });

                return response.ok;
            } catch (error) {
                console.error('[PWA] Failed to send subscription:', error);
                return false;
            }
        },

        /**
         * Remove subscription from server
         */
        removeSubscriptionFromServer: async function () {
            try {
                const response = await fetch('/wp-json/rental-gates/v1/push/unsubscribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': window.rentalGatesData?.nonce || ''
                    }
                });

                return response.ok;
            } catch (error) {
                console.error('[PWA] Failed to remove subscription:', error);
                return false;
            }
        },

        /**
         * Convert VAPID key
         */
        urlBase64ToUint8Array: function (base64String) {
            const padding = '='.repeat((4 - base64String.length % 4) % 4);
            const base64 = (base64String + padding)
                .replace(/-/g, '+')
                .replace(/_/g, '/');

            const rawData = window.atob(base64);
            const outputArray = new Uint8Array(rawData.length);

            for (let i = 0; i < rawData.length; ++i) {
                outputArray[i] = rawData.charCodeAt(i);
            }

            return outputArray;
        },

        /**
         * Handle service worker messages
         */
        handleServiceWorkerMessage: function (data) {
            if (this.config.debug) {
                console.log('[PWA] SW message:', data);
            }

            switch (data.type) {
                case 'SYNC_COMPLETE':
                    this.showSyncNotification(data.count);
                    break;
            }
        },

        /**
         * Show sync notification
         */
        showSyncNotification: function (count) {
            if (count === 0) return;

            const notification = document.createElement('div');
            notification.className = 'rg-pwa-network-status online';
            notification.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> ${count} item(s) synced`;

            document.body.appendChild(notification);

            requestAnimationFrame(() => {
                notification.classList.add('visible');
            });

            setTimeout(() => {
                notification.classList.remove('visible');
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        },

        /**
         * Sync offline data
         */
        syncOfflineData: function () {
            if ('serviceWorker' in navigator && 'sync' in window.registration) {
                navigator.serviceWorker.ready.then(registration => {
                    registration.sync.register('rental-gates-sync');
                });
            }
        },

        /**
         * Track analytics event
         */
        trackEvent: function (eventName, data = {}) {
            if (typeof gtag === 'function') {
                gtag('event', eventName, data);
            }

            if (this.config.debug) {
                console.log('[PWA] Event:', eventName, data);
            }
        },

        /**
         * Get install state
         */
        isInstalled: function () {
            return this.state.isInstalled;
        },

        /**
         * Get online state
         */
        isOnline: function () {
            return this.state.isOnline;
        },

        /**
         * Get push subscription
         */
        getPushSubscription: function () {
            return this.state.pushSubscription;
        }
    };

    // Export to global scope
    window.RentalGatesPWA = RentalGatesPWA;

    // Auto-initialize when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            if (window.rentalGatesData?.pwaEnabled) {
                RentalGatesPWA.init({
                    vapidPublicKey: window.rentalGatesData?.vapidPublicKey,
                    debug: window.rentalGatesData?.debug || false
                });
            }
        });
    } else {
        if (window.rentalGatesData?.pwaEnabled) {
            RentalGatesPWA.init({
                vapidPublicKey: window.rentalGatesData?.vapidPublicKey,
                debug: window.rentalGatesData?.debug || false
            });
        }
    }

})();
