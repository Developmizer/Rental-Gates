/**
 * Rental Gates Service Worker
 * Handles offline support, caching, and push notifications
 * 
 * @version 2.29.0
 */

const CACHE_NAME = 'rental-gates-v2.29.0';
const STATIC_CACHE = 'rental-gates-static-v2.29.0';
const DYNAMIC_CACHE = 'rental-gates-dynamic-v2.29.0';
const API_CACHE = 'rental-gates-api-v2.29.0';

// Static assets to cache immediately
const STATIC_ASSETS = [
    '/rental-gates/dashboard/',
    '/wp-content/plugins/rental-gates/assets/css/rental-gates.css',
    '/wp-content/plugins/rental-gates/assets/css/components.css',
    '/wp-content/plugins/rental-gates/assets/css/mobile.css',
    '/wp-content/plugins/rental-gates/assets/js/rental-gates.js',
    '/wp-content/plugins/rental-gates/assets/images/pwa/icon-192x192.png',
    '/wp-content/plugins/rental-gates/assets/images/pwa/icon-512x512.png',
];

// API routes to cache
const API_ROUTES = [
    '/wp-json/rental-gates/v1/buildings',
    '/wp-json/rental-gates/v1/units',
    '/wp-json/rental-gates/v1/tenants',
    '/wp-json/rental-gates/v1/leases',
    '/wp-json/rental-gates/v1/payments',
    '/wp-json/rental-gates/v1/notifications',
];

// Pages that should work offline
const OFFLINE_PAGES = [
    '/rental-gates/dashboard/',
    '/rental-gates/dashboard/buildings',
    '/rental-gates/dashboard/tenants',
    '/rental-gates/dashboard/payments',
    '/rental-gates/dashboard/maintenance',
    '/rental-gates/dashboard/messages',
];

// Offline fallback page
const OFFLINE_PAGE = '/rental-gates/offline/';

/**
 * Install event - Cache static assets
 */
self.addEventListener('install', (event) => {
    console.log('[SW] Installing Service Worker...');

    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then((cache) => {
                console.log('[SW] Caching static assets');
                return cache.addAll(STATIC_ASSETS.map(url => {
                    return new Request(url, { cache: 'reload' });
                })).catch(err => {
                    console.log('[SW] Some assets failed to cache:', err);
                });
            })
            .then(() => {
                console.log('[SW] Static assets cached');
                return self.skipWaiting();
            })
    );
});

/**
 * Activate event - Clean up old caches
 */
self.addEventListener('activate', (event) => {
    console.log('[SW] Activating Service Worker...');

    event.waitUntil(
        caches.keys()
            .then((cacheNames) => {
                return Promise.all(
                    cacheNames
                        .filter((name) => {
                            return name.startsWith('rental-gates-') &&
                                name !== STATIC_CACHE &&
                                name !== DYNAMIC_CACHE &&
                                name !== API_CACHE;
                        })
                        .map((name) => {
                            console.log('[SW] Deleting old cache:', name);
                            return caches.delete(name);
                        })
                );
            })
            .then(() => {
                console.log('[SW] Service Worker activated');
                return self.clients.claim();
            })
    );
});

/**
 * Fetch event - Handle requests with caching strategies
 */
self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    // Skip non-GET requests
    if (request.method !== 'GET') {
        return;
    }

    // Skip cross-origin requests
    if (url.origin !== location.origin) {
        return;
    }

    // Skip admin and wp-admin requests
    if (url.pathname.includes('/wp-admin') || url.pathname.includes('/wp-login')) {
        return;
    }

    // API requests - Network first, then cache
    if (url.pathname.includes('/wp-json/rental-gates/')) {
        event.respondWith(networkFirstStrategy(request, API_CACHE));
        return;
    }

    // Static assets - Cache first
    if (isStaticAsset(url.pathname)) {
        event.respondWith(cacheFirstStrategy(request, STATIC_CACHE));
        return;
    }

    // Dashboard pages - Stale while revalidate
    if (url.pathname.includes('/rental-gates/dashboard')) {
        event.respondWith(staleWhileRevalidate(request, DYNAMIC_CACHE));
        return;
    }

    // Default - Network first
    event.respondWith(networkFirstStrategy(request, DYNAMIC_CACHE));
});

/**
 * Cache First Strategy
 * Good for static assets that rarely change
 */
async function cacheFirstStrategy(request, cacheName) {
    const cachedResponse = await caches.match(request);

    if (cachedResponse) {
        return cachedResponse;
    }

    try {
        const networkResponse = await fetch(request);

        if (networkResponse.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, networkResponse.clone());
        }

        return networkResponse;
    } catch (error) {
        console.log('[SW] Cache first failed:', error);
        return new Response('Offline', { status: 503 });
    }
}

/**
 * Network First Strategy
 * Good for API calls and dynamic content
 */
async function networkFirstStrategy(request, cacheName) {
    try {
        const networkResponse = await fetch(request);

        if (networkResponse.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, networkResponse.clone());
        }

        return networkResponse;
    } catch (error) {
        console.log('[SW] Network first - falling back to cache');
        const cachedResponse = await caches.match(request);

        if (cachedResponse) {
            return cachedResponse;
        }

        // Return offline page for navigation requests
        if (request.mode === 'navigate') {
            return caches.match(OFFLINE_PAGE) || createOfflineResponse();
        }

        return createOfflineResponse();
    }
}

/**
 * Stale While Revalidate Strategy
 * Good for pages that should load fast but stay fresh
 */
async function staleWhileRevalidate(request, cacheName) {
    const cache = await caches.open(cacheName);
    const cachedResponse = await cache.match(request);

    const fetchPromise = fetch(request)
        .then((networkResponse) => {
            if (networkResponse.ok) {
                cache.put(request, networkResponse.clone());
            }
            return networkResponse;
        })
        .catch((error) => {
            console.log('[SW] Stale while revalidate fetch failed:', error);
            return null;
        });

    return cachedResponse || fetchPromise || createOfflineResponse();
}

/**
 * Check if URL is a static asset
 */
function isStaticAsset(pathname) {
    const staticExtensions = ['.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.woff', '.woff2', '.ttf'];
    return staticExtensions.some(ext => pathname.endsWith(ext));
}

/**
 * Create offline response
 */
function createOfflineResponse() {
    const html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Offline - Rental Gates</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                    color: white;
                }
                .container {
                    text-align: center;
                    max-width: 400px;
                }
                .icon {
                    width: 80px;
                    height: 80px;
                    margin-bottom: 24px;
                    opacity: 0.9;
                }
                h1 { font-size: 24px; margin-bottom: 12px; }
                p { opacity: 0.8; margin-bottom: 24px; line-height: 1.6; }
                .btn {
                    display: inline-block;
                    background: white;
                    color: #2563eb;
                    padding: 12px 32px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 600;
                    transition: transform 0.2s;
                }
                .btn:hover { transform: scale(1.05); }
                .status { margin-top: 32px; font-size: 14px; opacity: 0.6; }
            </style>
        </head>
        <body>
            <div class="container">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.58 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>
                </svg>
                <h1>You're Offline</h1>
                <p>It looks like you've lost your internet connection. Some features may be unavailable until you're back online.</p>
                <a href="javascript:location.reload()" class="btn">Try Again</a>
                <div class="status">Cached data may still be available</div>
            </div>
            <script>
                window.addEventListener('online', () => location.reload());
            </script>
        </body>
        </html>
    `;

    return new Response(html, {
        status: 503,
        headers: { 'Content-Type': 'text/html' }
    });
}

/**
 * Push notification event
 */
self.addEventListener('push', (event) => {
    console.log('[SW] Push notification received');

    let data = {
        title: 'Rental Gates',
        body: 'You have a new notification',
        icon: '/wp-content/plugins/rental-gates/assets/images/pwa/icon-192x192.png',
        badge: '/wp-content/plugins/rental-gates/assets/images/pwa/badge-72x72.png',
        tag: 'rental-gates-notification',
        data: { url: '/rental-gates/dashboard/notifications' }
    };

    if (event.data) {
        try {
            const pushData = event.data.json();
            data = { ...data, ...pushData };
        } catch (e) {
            data.body = event.data.text();
        }
    }

    const options = {
        body: data.body,
        icon: data.icon,
        badge: data.badge,
        tag: data.tag,
        data: data.data,
        vibrate: [100, 50, 100],
        requireInteraction: data.requireInteraction || false,
        actions: data.actions || [
            { action: 'view', title: 'View' },
            { action: 'dismiss', title: 'Dismiss' }
        ]
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

/**
 * Notification click event
 */
self.addEventListener('notificationclick', (event) => {
    console.log('[SW] Notification clicked:', event.action);

    event.notification.close();

    if (event.action === 'dismiss') {
        return;
    }

    const urlToOpen = event.notification.data?.url || '/rental-gates/dashboard/';

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then((windowClients) => {
                // Check if there's already a window open
                for (const client of windowClients) {
                    if (client.url.includes('/rental-gates/') && 'focus' in client) {
                        client.navigate(urlToOpen);
                        return client.focus();
                    }
                }

                // Open new window if none exists
                if (clients.openWindow) {
                    return clients.openWindow(urlToOpen);
                }
            })
    );
});

/**
 * Background sync event
 */
self.addEventListener('sync', (event) => {
    console.log('[SW] Background sync:', event.tag);

    if (event.tag === 'rental-gates-sync') {
        event.waitUntil(syncData());
    }
});

/**
 * Sync offline data when back online
 */
async function syncData() {
    console.log('[SW] Syncing offline data...');

    try {
        // Get pending requests from IndexedDB
        const db = await openDatabase();
        const pendingRequests = await getPendingRequests(db);

        for (const request of pendingRequests) {
            try {
                const response = await fetch(request.url, {
                    method: request.method,
                    headers: request.headers,
                    body: request.body
                });

                if (response.ok) {
                    await removePendingRequest(db, request.id);
                    console.log('[SW] Synced request:', request.url);
                }
            } catch (error) {
                console.log('[SW] Failed to sync request:', error);
            }
        }

        // Notify clients about sync completion
        const windowClients = await clients.matchAll({ type: 'window' });
        windowClients.forEach(client => {
            client.postMessage({
                type: 'SYNC_COMPLETE',
                count: pendingRequests.length
            });
        });

    } catch (error) {
        console.log('[SW] Sync failed:', error);
    }
}

/**
 * IndexedDB helpers for offline queue
 */
const DB_NAME = 'rental-gates-offline';
const DB_VERSION = 1;
const STORE_NAME = 'pending-requests';

function openDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
            }
        };
    });
}

function getPendingRequests(db) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
}

function removePendingRequest(db, id) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(id);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve();
    });
}

/**
 * Message event - Communication with main thread
 */
self.addEventListener('message', (event) => {
    console.log('[SW] Message received:', event.data);

    if (event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }

    if (event.data.type === 'CACHE_URLS') {
        caches.open(DYNAMIC_CACHE).then(cache => {
            cache.addAll(event.data.urls);
        });
    }

    if (event.data.type === 'CLEAR_CACHE') {
        caches.keys().then(names => {
            names.forEach(name => {
                if (name.startsWith('rental-gates-')) {
                    caches.delete(name);
                }
            });
        });
    }
});

console.log('[SW] Service Worker loaded');
