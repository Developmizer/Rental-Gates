<?php
/**
 * Rental Gates Availability Engine
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Availability_Engine {
    
    public function process_all() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $units = $wpdb->get_col(
            "SELECT id FROM {$tables['units']} WHERE availability_override = 0"
        );
        
        foreach ($units as $unit_id) {
            Rental_Gates_Unit::update_availability_state($unit_id);
        }
    }
}
