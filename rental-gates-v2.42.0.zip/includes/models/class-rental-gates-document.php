<?php
/**
 * Rental Gates Document Model
 * 
 * Handles document management including uploads, storage,
 * categorization, and association with entities.
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Document {
    
    private static $table_name;
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['documents'];
        }
    }
    
    /**
     * Get document types
     */
    public static function get_document_types() {
        return array(
            'lease_agreement' => __('Lease Agreement', 'rental-gates'),
            'lease_addendum' => __('Lease Addendum', 'rental-gates'),
            'tenant_id' => __('Tenant ID', 'rental-gates'),
            'proof_of_income' => __('Proof of Income', 'rental-gates'),
            'rental_application' => __('Rental Application', 'rental-gates'),
            'background_check' => __('Background Check', 'rental-gates'),
            'credit_report' => __('Credit Report', 'rental-gates'),
            'reference_letter' => __('Reference Letter', 'rental-gates'),
            'move_in_checklist' => __('Move-In Checklist', 'rental-gates'),
            'move_out_checklist' => __('Move-Out Checklist', 'rental-gates'),
            'inspection_report' => __('Inspection Report', 'rental-gates'),
            'property_photo' => __('Property Photo', 'rental-gates'),
            'insurance' => __('Insurance Document', 'rental-gates'),
            'permit' => __('Permit/License', 'rental-gates'),
            'maintenance_receipt' => __('Maintenance Receipt', 'rental-gates'),
            'invoice' => __('Invoice', 'rental-gates'),
            'vendor_contract' => __('Vendor Contract', 'rental-gates'),
            'correspondence' => __('Correspondence', 'rental-gates'),
            'notice' => __('Notice', 'rental-gates'),
            'other' => __('Other', 'rental-gates'),
        );
    }
    
    /**
     * Get entity types
     */
    public static function get_entity_types() {
        return array(
            'building' => __('Building', 'rental-gates'),
            'unit' => __('Unit', 'rental-gates'),
            'tenant' => __('Tenant', 'rental-gates'),
            'lease' => __('Lease', 'rental-gates'),
            'application' => __('Application', 'rental-gates'),
            'work_order' => __('Work Order', 'rental-gates'),
            'vendor' => __('Vendor', 'rental-gates'),
        );
    }
    
    /**
     * Create document record
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'organization_id' => 0,
            'attachment_id' => 0,
            'entity_type' => '',
            'entity_id' => 0,
            'document_type' => 'other',
            'title' => '',
            'description' => '',
            'file_url' => '',
            'file_name' => '',
            'file_size' => 0,
            'mime_type' => '',
            'is_private' => 1,
            'uploaded_by' => get_current_user_id(),
            'meta_data' => array(),
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['entity_type']) || empty($data['entity_id'])) {
            return new WP_Error('missing_required', __('Missing required fields', 'rental-gates'));
        }
        
        if (empty($data['file_url']) && empty($data['attachment_id'])) {
            return new WP_Error('missing_file', __('No file provided', 'rental-gates'));
        }
        
        // Prepare meta data
        $meta_data = is_array($data['meta_data']) ? json_encode($data['meta_data']) : $data['meta_data'];
        
        $result = $wpdb->insert(
            self::$table_name,
            array(
                'organization_id' => intval($data['organization_id']),
                'attachment_id' => intval($data['attachment_id']),
                'entity_type' => sanitize_key($data['entity_type']),
                'entity_id' => intval($data['entity_id']),
                'document_type' => sanitize_key($data['document_type']),
                'title' => sanitize_text_field($data['title']),
                'description' => sanitize_textarea_field($data['description']),
                'file_url' => esc_url_raw($data['file_url']),
                'file_name' => sanitize_file_name($data['file_name']),
                'file_size' => intval($data['file_size']),
                'mime_type' => sanitize_mime_type($data['mime_type']),
                'is_private' => intval($data['is_private']),
                'uploaded_by' => intval($data['uploaded_by']),
                'meta_data' => $meta_data,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error creating document record', 'rental-gates'));
        }
        
        return self::get($wpdb->insert_id);
    }
    
    /**
     * Get document by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $document = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$document) {
            return null;
        }
        
        return self::format_document($document);
    }
    
    /**
     * Update document
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $document = self::get($id);
        if (!$document) {
            return new WP_Error('not_found', __('Document not found', 'rental-gates'));
        }
        
        $update_data = array();
        $update_format = array();
        
        $allowed_fields = array(
            'document_type' => '%s',
            'title' => '%s',
            'description' => '%s',
            'is_private' => '%d',
        );
        
        foreach ($allowed_fields as $field => $format) {
            if (isset($data[$field])) {
                $update_data[$field] = $data[$field];
                $update_format[] = $format;
            }
        }
        
        if (!empty($data['meta_data'])) {
            $update_data['meta_data'] = is_array($data['meta_data']) ? json_encode($data['meta_data']) : $data['meta_data'];
            $update_format[] = '%s';
        }
        
        if (empty($update_data)) {
            return self::get($id);
        }
        
        $update_data['updated_at'] = current_time('mysql');
        $update_format[] = '%s';
        
        $result = $wpdb->update(
            self::$table_name,
            $update_data,
            array('id' => $id),
            $update_format,
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating document', 'rental-gates'));
        }
        
        return self::get($id);
    }
    
    /**
     * Delete document
     */
    public static function delete($id) {
        global $wpdb;
        self::init();
        
        $document = self::get($id);
        if (!$document) {
            return new WP_Error('not_found', __('Document not found', 'rental-gates'));
        }
        
        // Delete attachment if exists
        if ($document['attachment_id']) {
            wp_delete_attachment($document['attachment_id'], true);
        }
        
        $result = $wpdb->delete(
            self::$table_name,
            array('id' => $id),
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Get documents for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'entity_type' => null,
            'entity_id' => null,
            'document_type' => null,
            'search' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
            'limit' => 50,
            'offset' => 0,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('d.organization_id = %d');
        $params = array($org_id);
        
        if ($args['entity_type']) {
            $where[] = 'd.entity_type = %s';
            $params[] = $args['entity_type'];
        }
        
        if ($args['entity_id']) {
            $where[] = 'd.entity_id = %d';
            $params[] = $args['entity_id'];
        }
        
        if ($args['document_type']) {
            $where[] = 'd.document_type = %s';
            $params[] = $args['document_type'];
        }
        
        if ($args['search']) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(d.title LIKE %s OR d.description LIKE %s OR d.file_name LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'title', 'document_type', 'file_size')) 
            ? 'd.' . $args['orderby'] : 'd.created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT d.*, 
                       u.display_name as uploaded_by_name
                FROM " . self::$table_name . " d
                LEFT JOIN {$wpdb->users} u ON d.uploaded_by = u.ID
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";
        
        $params[] = intval($args['limit']);
        $params[] = intval($args['offset']);
        
        $documents = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_document'), $documents);
    }
    
    /**
     * Get documents for entity
     */
    public static function get_for_entity($entity_type, $entity_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $defaults = array(
            'document_type' => null,
            'orderby' => 'created_at',
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('entity_type = %s', 'entity_id = %d');
        $params = array($entity_type, $entity_id);
        
        if ($args['document_type']) {
            $where[] = 'document_type = %s';
            $params[] = $args['document_type'];
        }
        
        $orderby = in_array($args['orderby'], array('created_at', 'title', 'document_type')) 
            ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $sql = "SELECT * FROM " . self::$table_name . " 
                WHERE " . implode(' AND ', $where) . " 
                ORDER BY {$orderby} {$order}";
        
        $documents = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        
        return array_map(array(__CLASS__, 'format_document'), $documents);
    }
    
    /**
     * Count documents for organization
     */
    public static function count_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $where = array('organization_id = %d');
        $params = array($org_id);
        
        if (!empty($args['entity_type'])) {
            $where[] = 'entity_type = %s';
            $params[] = $args['entity_type'];
        }
        
        if (!empty($args['document_type'])) {
            $where[] = 'document_type = %s';
            $params[] = $args['document_type'];
        }
        
        $sql = "SELECT COUNT(*) FROM " . self::$table_name . " WHERE " . implode(' AND ', $where);
        
        return intval($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
    
    /**
     * Get stats for organization
     */
    public static function get_stats($org_id) {
        global $wpdb;
        self::init();
        
        $stats = array(
            'total' => 0,
            'by_type' => array(),
            'by_entity' => array(),
            'total_size' => 0,
            'recent_count' => 0,
        );
        
        // Total count
        $stats['total'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE organization_id = %d",
            $org_id
        )));
        
        // Count by document type
        $by_type = $wpdb->get_results($wpdb->prepare(
            "SELECT document_type, COUNT(*) as count 
             FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             GROUP BY document_type",
            $org_id
        ), ARRAY_A);
        
        foreach ($by_type as $row) {
            $stats['by_type'][$row['document_type']] = intval($row['count']);
        }
        
        // Count by entity type
        $by_entity = $wpdb->get_results($wpdb->prepare(
            "SELECT entity_type, COUNT(*) as count 
             FROM " . self::$table_name . " 
             WHERE organization_id = %d 
             GROUP BY entity_type",
            $org_id
        ), ARRAY_A);
        
        foreach ($by_entity as $row) {
            $stats['by_entity'][$row['entity_type']] = intval($row['count']);
        }
        
        // Total file size
        $stats['total_size'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(file_size), 0) FROM " . self::$table_name . " WHERE organization_id = %d",
            $org_id
        )));
        
        // Recent (last 30 days)
        $stats['recent_count'] = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " 
             WHERE organization_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            $org_id
        )));
        
        return $stats;
    }
    
    /**
     * Upload document from $_FILES
     */
    public static function upload($file, $data) {
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return new WP_Error('upload_error', self::get_upload_error_message($file['error']));
        }
        
        // Validate file type
        $allowed_types = self::get_allowed_mime_types();
        $file_type = wp_check_filetype($file['name']);
        
        if (!in_array($file_type['type'], $allowed_types)) {
            return new WP_Error('invalid_type', __('File type not allowed', 'rental-gates'));
        }
        
        // Check file size (max 50MB)
        $max_size = 50 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            return new WP_Error('file_too_large', __('File exceeds maximum size of 50MB', 'rental-gates'));
        }
        
        // Require WordPress media functions
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Upload to WordPress media library
        $upload = wp_handle_upload($file, array('test_form' => false));
        
        if (isset($upload['error'])) {
            return new WP_Error('upload_failed', $upload['error']);
        }
        
        // Create attachment
        $attachment = array(
            'post_mime_type' => $upload['type'],
            'post_title' => sanitize_file_name(pathinfo($file['name'], PATHINFO_FILENAME)),
            'post_content' => '',
            'post_status' => 'private',
        );
        
        $attachment_id = wp_insert_attachment($attachment, $upload['file']);
        
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }
        
        // Generate metadata for images
        $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attach_data);
        
        // Create document record
        $doc_data = wp_parse_args($data, array(
            'attachment_id' => $attachment_id,
            'file_url' => $upload['url'],
            'file_name' => $file['name'],
            'file_size' => $file['size'],
            'mime_type' => $upload['type'],
            'title' => !empty($data['title']) ? $data['title'] : pathinfo($file['name'], PATHINFO_FILENAME),
        ));
        
        return self::create($doc_data);
    }
    
    /**
     * Get allowed MIME types
     */
    public static function get_allowed_mime_types() {
        return array(
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
            'text/plain',
            'text/csv',
        );
    }
    
    /**
     * Get upload error message
     */
    private static function get_upload_error_message($code) {
        $messages = array(
            UPLOAD_ERR_INI_SIZE => __('File exceeds server maximum size', 'rental-gates'),
            UPLOAD_ERR_FORM_SIZE => __('File exceeds form maximum size', 'rental-gates'),
            UPLOAD_ERR_PARTIAL => __('File was only partially uploaded', 'rental-gates'),
            UPLOAD_ERR_NO_FILE => __('No file was uploaded', 'rental-gates'),
            UPLOAD_ERR_NO_TMP_DIR => __('Server missing temporary folder', 'rental-gates'),
            UPLOAD_ERR_CANT_WRITE => __('Failed to write file to disk', 'rental-gates'),
            UPLOAD_ERR_EXTENSION => __('File upload stopped by extension', 'rental-gates'),
        );
        
        return isset($messages[$code]) ? $messages[$code] : __('Unknown upload error', 'rental-gates');
    }
    
    /**
     * Format file size for display
     */
    public static function format_file_size($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' bytes';
        }
    }
    
    /**
     * Get file icon based on mime type
     */
    public static function get_file_icon($mime_type) {
        $icons = array(
            'application/pdf' => 'file-text',
            'application/msword' => 'file-text',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'file-text',
            'application/vnd.ms-excel' => 'file-spreadsheet',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'file-spreadsheet',
            'image/jpeg' => 'image',
            'image/png' => 'image',
            'image/gif' => 'image',
            'image/webp' => 'image',
            'text/plain' => 'file-text',
            'text/csv' => 'file-spreadsheet',
        );
        
        return isset($icons[$mime_type]) ? $icons[$mime_type] : 'file';
    }
    
    /**
     * Check if file is an image
     */
    public static function is_image($mime_type) {
        return strpos($mime_type, 'image/') === 0;
    }
    
    /**
     * Format document data
     */
    private static function format_document($document) {
        if (!$document) return null;
        
        $document['id'] = intval($document['id']);
        $document['organization_id'] = intval($document['organization_id']);
        $document['attachment_id'] = intval($document['attachment_id']);
        $document['entity_id'] = intval($document['entity_id']);
        $document['file_size'] = intval($document['file_size']);
        $document['is_private'] = (bool) $document['is_private'];
        $document['uploaded_by'] = $document['uploaded_by'] ? intval($document['uploaded_by']) : null;
        
        // Add labels
        $types = self::get_document_types();
        $document['document_type_label'] = isset($types[$document['document_type']]) 
            ? $types[$document['document_type']] : $document['document_type'];
        
        $entity_types = self::get_entity_types();
        $document['entity_type_label'] = isset($entity_types[$document['entity_type']]) 
            ? $entity_types[$document['entity_type']] : $document['entity_type'];
        
        // Format file size
        $document['file_size_formatted'] = self::format_file_size($document['file_size']);
        
        // Get file icon
        $document['file_icon'] = self::get_file_icon($document['mime_type']);
        
        // Check if image
        $document['is_image'] = self::is_image($document['mime_type']);
        
        // Get file extension
        $document['file_extension'] = strtoupper(pathinfo($document['file_name'], PATHINFO_EXTENSION));
        
        // Parse meta data
        if (!empty($document['meta_data'])) {
            $document['meta_data'] = json_decode($document['meta_data'], true);
        } else {
            $document['meta_data'] = array();
        }
        
        return $document;
    }
}
