<?php
/**
 * Rental Gates AI Usage Model
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_AI_Usage {
    
    public static function reset_monthly_credits() {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $today = date('Y-m-d');
        
        // Reset credits for subscriptions where reset date has passed
        $wpdb->query($wpdb->prepare(
            "UPDATE {$tables['subscriptions']} 
             SET ai_credits_used = 0, 
                 ai_credits_reset_at = DATE_ADD(ai_credits_reset_at, INTERVAL 1 MONTH),
                 updated_at = %s
             WHERE DATE(ai_credits_reset_at) <= %s",
            current_time('mysql'),
            $today
        ));
    }
}
