<?php
/**
 * Rental Gates Marketing Campaign Model
 * 
 * Handles marketing campaign creation, tracking, and performance metrics.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Campaign {
    
    private static $table_name;
    
    /**
     * Campaign statuses
     */
    const STATUS_DRAFT = 'draft';
    const STATUS_ACTIVE = 'active';
    const STATUS_PAUSED = 'paused';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    
    /**
     * Campaign types
     */
    const TYPE_QR = 'qr';
    const TYPE_FLYER = 'flyer';
    const TYPE_EMAIL = 'email';
    const TYPE_SOCIAL = 'social';
    const TYPE_MULTI_CHANNEL = 'multi_channel';
    
    /**
     * Initialize table name
     */
    private static function init() {
        if (!self::$table_name) {
            $tables = Rental_Gates_Database::get_table_names();
            self::$table_name = $tables['marketing_campaigns'] ?? $wpdb->prefix . 'rg_marketing_campaigns';
        }
    }
    
    /**
     * Create a new campaign
     */
    public static function create($data) {
        global $wpdb;
        self::init();
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            self::create_table();
        }
        
        // Validate required fields
        if (empty($data['organization_id']) || empty($data['name'])) {
            return new WP_Error('missing_fields', __('Campaign name is required', 'rental-gates'));
        }
        
        $insert_data = array(
            'organization_id' => intval($data['organization_id']),
            'name' => sanitize_text_field($data['name']),
            'type' => sanitize_text_field($data['type'] ?? self::TYPE_MULTI_CHANNEL),
            'status' => sanitize_text_field($data['status'] ?? self::STATUS_DRAFT),
            'start_date' => !empty($data['start_date']) ? $data['start_date'] : null,
            'end_date' => !empty($data['end_date']) ? $data['end_date'] : null,
            'budget' => !empty($data['budget']) ? floatval($data['budget']) : null,
            'goal' => sanitize_text_field($data['goal'] ?? ''),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'meta_data' => !empty($data['meta_data']) ? wp_json_encode($data['meta_data']) : null,
            'created_at' => current_time('mysql'),
        );
        
        $result = $wpdb->insert(self::$table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to create campaign', 'rental-gates'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get campaign by ID
     */
    public static function get($id) {
        global $wpdb;
        self::init();
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            return null;
        }
        
        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$campaign) {
            return null;
        }
        
        return self::format_campaign($campaign);
    }
    
    /**
     * Get campaigns for organization
     */
    public static function get_for_organization($org_id, $args = array()) {
        global $wpdb;
        self::init();
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . self::$table_name . "'");
        if (!$table_exists) {
            return array('items' => array(), 'total' => 0);
        }
        
        $defaults = array(
            'status' => null,
            'type' => null,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'created_at',
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('organization_id = %d');
        $params = array($org_id);
        
        if ($args['status']) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        
        if ($args['type']) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        
        $where_clause = implode(' AND ', $where);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'created_at DESC';
        
        $campaigns = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::$table_name . " 
             WHERE {$where_clause} 
             ORDER BY {$orderby} 
             LIMIT %d OFFSET %d",
            array_merge($params, array($args['limit'], $args['offset']))
        ), ARRAY_A);
        
        $formatted = array_map(array(__CLASS__, 'format_campaign'), $campaigns);
        
        $total = intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::$table_name . " WHERE {$where_clause}",
            $params
        )));
        
        return array(
            'items' => $formatted,
            'total' => $total,
        );
    }
    
    /**
     * Update campaign
     */
    public static function update($id, $data) {
        global $wpdb;
        self::init();
        
        $campaign = self::get($id);
        if (!$campaign) {
            return new WP_Error('not_found', __('Campaign not found', 'rental-gates'));
        }
        
        $update_data = array();
        $allowed_fields = array('name', 'type', 'status', 'start_date', 'end_date', 'budget', 'goal', 'description', 'meta_data');
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                if ($field === 'meta_data' && is_array($data[$field])) {
                    $update_data[$field] = wp_json_encode($data[$field]);
                } elseif ($field === 'budget') {
                    $update_data[$field] = floatval($data[$field]);
                } elseif (in_array($field, array('start_date', 'end_date'))) {
                    $update_data[$field] = $data[$field] ?: null;
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
            }
        }
        
        if (empty($update_data)) {
            return $campaign;
        }
        
        $result = $wpdb->update(
            self::$table_name,
            $update_data,
            array('id' => $id),
            null,
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Failed to update campaign', 'rental-gates'));
        }
        
        return self::get($id);
    }
    
    /**
     * Get campaign performance metrics
     */
    public static function get_performance($campaign_id) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $campaign = self::get($campaign_id);
        if (!$campaign) {
            return null;
        }
        
        // Get campaign metadata for tracking
        $meta_data = json_decode($campaign['meta_data'], true) ?: array();
        $campaign_tag = 'campaign_' . $campaign_id;
        
        // Get leads from this campaign
        $leads = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leads']} 
             WHERE organization_id = %d 
             AND (meta_data LIKE %s OR source LIKE %s)",
            $campaign['organization_id'],
            '%' . $wpdb->esc_like($campaign_tag) . '%',
            $campaign['type']
        ));
        
        // Get applications
        $applications = 0;
        $leases = 0;
        
        // Calculate ROI if budget is set
        $roi = null;
        if (!empty($campaign['budget']) && $campaign['budget'] > 0) {
            // Estimate revenue from leases (average rent * 12 months)
            $avg_rent = $wpdb->get_var($wpdb->prepare(
                "SELECT AVG(u.rent_amount) FROM {$tables['units']} u
                 JOIN {$tables['buildings']} b ON u.building_id = b.id
                 WHERE b.organization_id = %d",
                $campaign['organization_id']
            ));
            
            if ($avg_rent && $leases > 0) {
                $estimated_revenue = $avg_rent * 12 * $leases;
                $roi = (($estimated_revenue - $campaign['budget']) / $campaign['budget']) * 100;
            }
        }
        
        return array(
            'campaign_id' => $campaign_id,
            'leads' => intval($leads),
            'applications' => $applications,
            'leases' => $leases,
            'budget' => $campaign['budget'],
            'spent' => 0, // Track actual spend separately
            'roi' => $roi,
            'cost_per_lead' => $leads > 0 && $campaign['budget'] > 0 ? $campaign['budget'] / $leads : null,
        );
    }
    
    /**
     * Format campaign data
     */
    private static function format_campaign($campaign) {
        if (!$campaign) return null;
        
        $campaign['id'] = intval($campaign['id']);
        $campaign['organization_id'] = intval($campaign['organization_id']);
        $campaign['budget'] = $campaign['budget'] ? floatval($campaign['budget']) : null;
        
        if (!empty($campaign['meta_data'])) {
            $campaign['meta_data'] = json_decode($campaign['meta_data'], true);
        }
        
        $campaign['created_at_formatted'] = date_i18n('M j, Y', strtotime($campaign['created_at']));
        
        return $campaign;
    }
    
    /**
     * Create campaigns table
     */
    private static function create_table() {
        global $wpdb;
        self::init();
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE " . self::$table_name . " (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            organization_id bigint(20) UNSIGNED NOT NULL,
            name varchar(255) NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'multi_channel',
            status varchar(50) NOT NULL DEFAULT 'draft',
            start_date date DEFAULT NULL,
            end_date date DEFAULT NULL,
            budget decimal(10,2) DEFAULT NULL,
            goal text DEFAULT NULL,
            description text DEFAULT NULL,
            meta_data longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY organization_id (organization_id),
            KEY status (status),
            KEY type (type),
            KEY start_date (start_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
