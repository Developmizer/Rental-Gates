<?php
/**
 * Rental Gates Data Validation
 * 
 * Provides comprehensive validation for all data types used in the plugin.
 * 
 * @package RentalGates
 * @since 2.22.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Validation {
    
    /**
     * Validate email address
     */
    public static function email($email) {
        $email = sanitize_email($email);
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Validate phone number
     */
    public static function phone($phone) {
        $phone = preg_replace('/[^0-9+\-\s\(\)]/', '', $phone);
        $digits = preg_replace('/[^0-9]/', '', $phone);
        return strlen($digits) >= 7 && strlen($digits) <= 15;
    }
    
    /**
     * Validate money amount
     */
    public static function money($amount) {
        if (!is_numeric($amount)) return false;
        return floatval($amount) >= 0 && floatval($amount) <= 999999999.99;
    }
    
    /**
     * Validate date
     */
    public static function date($date, $format = 'Y-m-d') {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) === $date;
    }
    
    /**
     * Validate date range
     */
    public static function date_range($start, $end) {
        if (!self::date($start) || !self::date($end)) return false;
        return strtotime($start) <= strtotime($end);
    }
    
    /**
     * Validate positive integer
     */
    public static function positive_int($value) {
        return is_numeric($value) && intval($value) > 0 && intval($value) == $value;
    }
    
    /**
     * Validate non-negative integer
     */
    public static function non_negative_int($value) {
        return is_numeric($value) && intval($value) >= 0 && intval($value) == $value;
    }
    
    /**
     * Validate slug
     */
    public static function slug($slug) {
        return preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) === 1;
    }
    
    /**
     * Validate URL
     */
    public static function url($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
    
    /**
     * Validate required fields in array
     */
    public static function required($data, $fields) {
        $missing = array();
        foreach ($fields as $field) {
            if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
                $missing[] = $field;
            }
        }
        return empty($missing) ? true : $missing;
    }
    
    /**
     * Validate building data
     */
    public static function building($data) {
        $errors = array();
        
        if (empty($data['name'])) {
            $errors['name'] = __('Building name is required', 'rental-gates');
        }
        
        if (empty($data['organization_id']) || !self::positive_int($data['organization_id'])) {
            $errors['organization_id'] = __('Valid organization required', 'rental-gates');
        }
        
        if (!empty($data['latitude']) && (floatval($data['latitude']) < -90 || floatval($data['latitude']) > 90)) {
            $errors['latitude'] = __('Latitude must be between -90 and 90', 'rental-gates');
        }
        
        if (!empty($data['longitude']) && (floatval($data['longitude']) < -180 || floatval($data['longitude']) > 180)) {
            $errors['longitude'] = __('Longitude must be between -180 and 180', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate unit data
     */
    public static function unit($data) {
        $errors = array();
        
        if (empty($data['name'])) {
            $errors['name'] = __('Unit name is required', 'rental-gates');
        }
        
        if (empty($data['building_id']) || !self::positive_int($data['building_id'])) {
            $errors['building_id'] = __('Valid building required', 'rental-gates');
        }
        
        if (isset($data['rent_amount']) && !self::money($data['rent_amount'])) {
            $errors['rent_amount'] = __('Invalid rent amount', 'rental-gates');
        }
        
        if (isset($data['bedrooms']) && (!is_numeric($data['bedrooms']) || intval($data['bedrooms']) < 0)) {
            $errors['bedrooms'] = __('Bedrooms must be 0 or more', 'rental-gates');
        }
        
        if (isset($data['bathrooms']) && (!is_numeric($data['bathrooms']) || floatval($data['bathrooms']) < 0)) {
            $errors['bathrooms'] = __('Bathrooms must be 0 or more', 'rental-gates');
        }
        
        if (isset($data['square_footage']) && (!is_numeric($data['square_footage']) || intval($data['square_footage']) < 0)) {
            $errors['square_footage'] = __('Square footage must be 0 or more', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate tenant data
     */
    public static function tenant($data) {
        $errors = array();
        
        if (empty($data['first_name'])) {
            $errors['first_name'] = __('First name is required', 'rental-gates');
        }
        
        if (empty($data['last_name'])) {
            $errors['last_name'] = __('Last name is required', 'rental-gates');
        }
        
        if (empty($data['email'])) {
            $errors['email'] = __('Email is required', 'rental-gates');
        } elseif (!self::email($data['email'])) {
            $errors['email'] = __('Invalid email address', 'rental-gates');
        }
        
        if (!empty($data['phone']) && !self::phone($data['phone'])) {
            $errors['phone'] = __('Invalid phone number', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate lease data
     */
    public static function lease($data) {
        $errors = array();
        
        if (empty($data['unit_id']) || !self::positive_int($data['unit_id'])) {
            $errors['unit_id'] = __('Valid unit required', 'rental-gates');
        }
        
        if (empty($data['start_date'])) {
            $errors['start_date'] = __('Start date is required', 'rental-gates');
        } elseif (!self::date($data['start_date'])) {
            $errors['start_date'] = __('Invalid start date', 'rental-gates');
        }
        
        if (empty($data['end_date'])) {
            $errors['end_date'] = __('End date is required', 'rental-gates');
        } elseif (!self::date($data['end_date'])) {
            $errors['end_date'] = __('Invalid end date', 'rental-gates');
        }
        
        if (!empty($data['start_date']) && !empty($data['end_date']) && 
            self::date($data['start_date']) && self::date($data['end_date'])) {
            if (!self::date_range($data['start_date'], $data['end_date'])) {
                $errors['end_date'] = __('End date must be after start date', 'rental-gates');
            }
        }
        
        if (isset($data['rent_amount']) && !self::money($data['rent_amount'])) {
            $errors['rent_amount'] = __('Invalid rent amount', 'rental-gates');
        }
        
        if (isset($data['deposit_amount']) && !self::money($data['deposit_amount'])) {
            $errors['deposit_amount'] = __('Invalid deposit amount', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate payment data
     */
    public static function payment($data) {
        $errors = array();
        
        if (empty($data['amount']) || !self::money($data['amount'])) {
            $errors['amount'] = __('Valid payment amount required', 'rental-gates');
        }
        
        if (isset($data['amount']) && floatval($data['amount']) <= 0) {
            $errors['amount'] = __('Amount must be greater than zero', 'rental-gates');
        }
        
        $valid_types = array('rent', 'deposit', 'late_fee', 'utility', 'other');
        if (!empty($data['type']) && !in_array($data['type'], $valid_types)) {
            $errors['type'] = __('Invalid payment type', 'rental-gates');
        }
        
        $valid_methods = array('card', 'bank_transfer', 'cash', 'check', 'other');
        if (!empty($data['method']) && !in_array($data['method'], $valid_methods)) {
            $errors['method'] = __('Invalid payment method', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate work order data
     */
    public static function work_order($data) {
        $errors = array();
        
        if (empty($data['title'])) {
            $errors['title'] = __('Title is required', 'rental-gates');
        }
        
        $valid_priorities = array('low', 'normal', 'high', 'urgent');
        if (!empty($data['priority']) && !in_array($data['priority'], $valid_priorities)) {
            $errors['priority'] = __('Invalid priority level', 'rental-gates');
        }
        
        $valid_categories = array('plumbing', 'electrical', 'hvac', 'appliance', 'structural', 'pest', 'safety', 'general', 'other');
        if (!empty($data['category']) && !in_array($data['category'], $valid_categories)) {
            $errors['category'] = __('Invalid category', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate lead data
     */
    public static function lead($data) {
        $errors = array();
        
        if (empty($data['name'])) {
            $errors['name'] = __('Name is required', 'rental-gates');
        }
        
        if (empty($data['email'])) {
            $errors['email'] = __('Email is required', 'rental-gates');
        } elseif (!self::email($data['email'])) {
            $errors['email'] = __('Invalid email address', 'rental-gates');
        }
        
        if (!empty($data['phone']) && !self::phone($data['phone'])) {
            $errors['phone'] = __('Invalid phone number', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Validate application data
     */
    public static function application($data) {
        $errors = array();
        
        if (empty($data['first_name'])) {
            $errors['first_name'] = __('First name is required', 'rental-gates');
        }
        
        if (empty($data['last_name'])) {
            $errors['last_name'] = __('Last name is required', 'rental-gates');
        }
        
        if (empty($data['email'])) {
            $errors['email'] = __('Email is required', 'rental-gates');
        } elseif (!self::email($data['email'])) {
            $errors['email'] = __('Invalid email address', 'rental-gates');
        }
        
        if (!empty($data['phone']) && !self::phone($data['phone'])) {
            $errors['phone'] = __('Invalid phone number', 'rental-gates');
        }
        
        if (isset($data['monthly_income']) && (!is_numeric($data['monthly_income']) || floatval($data['monthly_income']) < 0)) {
            $errors['monthly_income'] = __('Invalid income amount', 'rental-gates');
        }
        
        if (!empty($data['date_of_birth']) && !self::date($data['date_of_birth'])) {
            $errors['date_of_birth'] = __('Invalid date of birth', 'rental-gates');
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * Sanitize and validate input array
     */
    public static function sanitize_input($data, $schema) {
        $sanitized = array();
        $errors = array();
        
        foreach ($schema as $field => $rules) {
            $value = isset($data[$field]) ? $data[$field] : null;
            
            // Check required
            if (!empty($rules['required']) && ($value === null || $value === '')) {
                $errors[$field] = sprintf(__('%s is required', 'rental-gates'), $rules['label'] ?? $field);
                continue;
            }
            
            // Skip if empty and not required
            if ($value === null || $value === '') {
                if (isset($rules['default'])) {
                    $sanitized[$field] = $rules['default'];
                }
                continue;
            }
            
            // Sanitize based on type
            switch ($rules['type'] ?? 'string') {
                case 'int':
                    $sanitized[$field] = intval($value);
                    break;
                case 'float':
                    $sanitized[$field] = floatval($value);
                    break;
                case 'bool':
                    $sanitized[$field] = (bool) $value;
                    break;
                case 'email':
                    $sanitized[$field] = sanitize_email($value);
                    if (!self::email($sanitized[$field])) {
                        $errors[$field] = __('Invalid email address', 'rental-gates');
                    }
                    break;
                case 'phone':
                    $sanitized[$field] = sanitize_text_field($value);
                    if (!self::phone($sanitized[$field])) {
                        $errors[$field] = __('Invalid phone number', 'rental-gates');
                    }
                    break;
                case 'date':
                    $sanitized[$field] = sanitize_text_field($value);
                    if (!self::date($sanitized[$field])) {
                        $errors[$field] = __('Invalid date', 'rental-gates');
                    }
                    break;
                case 'money':
                    $sanitized[$field] = floatval($value);
                    if (!self::money($sanitized[$field])) {
                        $errors[$field] = __('Invalid amount', 'rental-gates');
                    }
                    break;
                case 'slug':
                    $sanitized[$field] = sanitize_title($value);
                    break;
                case 'url':
                    $sanitized[$field] = esc_url_raw($value);
                    break;
                case 'textarea':
                    $sanitized[$field] = sanitize_textarea_field($value);
                    break;
                case 'html':
                    $sanitized[$field] = wp_kses_post($value);
                    break;
                case 'array':
                    $sanitized[$field] = is_array($value) ? array_map('sanitize_text_field', $value) : array();
                    break;
                case 'json':
                    $sanitized[$field] = is_array($value) ? $value : json_decode($value, true);
                    break;
                case 'key':
                    $sanitized[$field] = sanitize_key($value);
                    break;
                default:
                    $sanitized[$field] = sanitize_text_field($value);
            }
            
            // Check min/max for numbers
            if (isset($rules['min']) && is_numeric($sanitized[$field]) && $sanitized[$field] < $rules['min']) {
                $errors[$field] = sprintf(__('%s must be at least %s', 'rental-gates'), $rules['label'] ?? $field, $rules['min']);
            }
            if (isset($rules['max']) && is_numeric($sanitized[$field]) && $sanitized[$field] > $rules['max']) {
                $errors[$field] = sprintf(__('%s must be at most %s', 'rental-gates'), $rules['label'] ?? $field, $rules['max']);
            }
            
            // Check allowed values
            if (isset($rules['enum']) && !in_array($sanitized[$field], $rules['enum'])) {
                $errors[$field] = sprintf(__('Invalid value for %s', 'rental-gates'), $rules['label'] ?? $field);
            }
        }
        
        return array(
            'data' => $sanitized,
            'errors' => $errors,
            'valid' => empty($errors),
        );
    }
}
