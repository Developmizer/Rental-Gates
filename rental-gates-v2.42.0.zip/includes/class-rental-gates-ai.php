<?php
/**
 * Rental Gates AI Service
 * 
 * Comprehensive AI integration for property management.
 * Supports OpenAI and Google Gemini providers.
 * 
 * @package RentalGates
 * @since 2.14.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_AI {
    
    /**
     * Singleton instance
     */
    private static $instance = null;
    
    /**
     * Current provider
     */
    private $provider = 'openai';
    
    /**
     * API keys
     */
    private $openai_key = '';
    private $gemini_key = '';
    
    /**
     * Model settings
     */
    private $openai_model = 'gpt-4o-mini';
    private $gemini_model = 'gemini-1.5-flash';
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->provider = get_option('rental_gates_ai_provider', 'openai');
        $this->openai_key = get_option('rental_gates_openai_api_key', '');
        $this->gemini_key = get_option('rental_gates_gemini_api_key', '');
        $this->openai_model = get_option('rental_gates_openai_model', 'gpt-4o-mini');
        $this->gemini_model = get_option('rental_gates_gemini_model', 'gemini-1.5-flash');
    }
    
    /**
     * Check if AI is enabled globally
     */
    public static function is_enabled() {
        return (bool) get_option('rental_gates_enable_ai_tools', false);
    }
    
    /**
     * Check if organization has AI access
     */
    public static function org_has_access($org_id = null) {
        if (!self::is_enabled()) {
            return false;
        }
        
        if (!$org_id) {
            $org_id = Rental_Gates_Roles::get_organization_id();
        }
        
        if (!$org_id) {
            return false;
        }
        
        // Check plan limits using Feature Gate helper
        if (function_exists('rg_module_enabled')) {
            return rg_module_enabled('ai_screening', $org_id);
        }
        
        // Fallback: Check if Feature Gate class exists and use singleton
        if (class_exists('Rental_Gates_Feature_Gate')) {
            $gate = Rental_Gates_Feature_Gate::get_instance();
            $access = $gate->can_access_module('ai_screening', $org_id);
            return !empty($access['enabled']);
        }
        
        return false;
    }
    
    /**
     * Get current provider
     */
    public static function get_provider() {
        return get_option('rental_gates_ai_provider', 'openai');
    }
    
    /**
     * Check if provider is configured
     */
    public function is_configured() {
        if ($this->provider === 'openai') {
            return !empty($this->openai_key);
        } elseif ($this->provider === 'gemini') {
            return !empty($this->gemini_key);
        }
        return false;
    }
    
    /**
     * Get remaining credits for organization
     * Delegates to AI Credits manager
     */
    public static function get_remaining_credits($org_id = null) {
        if (!$org_id) {
            $org_id = Rental_Gates_Roles::get_organization_id();
        }
        
        // Use new credits manager if available
        if (class_exists('Rental_Gates_AI_Credits')) {
            return rg_ai_credits()->get_remaining($org_id);
        }
        
        // Legacy fallback
        if (!$org_id) {
            return 0;
        }
        
        global $wpdb;
        
        if (!class_exists('Rental_Gates_Database')) {
            return 0;
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        $org_table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['organizations']}'");
        if (!$org_table_exists) {
            return 0;
        }
        
        $plans = get_option('rental_gates_plans', array());
        $org = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['organizations']} WHERE id = %d",
            $org_id
        ));
        
        if (!$org) {
            return 0;
        }
        
        $plan_id = $org->plan_id ?? 'free';
        $plan = $plans[$plan_id] ?? array();
        $monthly_limit = $plan['limits']['ai_credits'] ?? 0;
        
        $ai_table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['ai_usage']}'");
        if (!$ai_table_exists) {
            return $monthly_limit;
        }
        
        $used = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(credits_used), 0) 
             FROM {$tables['ai_usage']} 
             WHERE organization_id = %d 
             AND MONTH(created_at) = MONTH(CURRENT_DATE())
             AND YEAR(created_at) = YEAR(CURRENT_DATE())",
            $org_id
        ));
        
        return max(0, $monthly_limit - intval($used));
    }
    
    /**
     * Get usage stats for organization
     * Delegates to AI Credits manager for enhanced stats
     */
    public static function get_usage_stats($org_id = null) {
        if (!$org_id) {
            $org_id = Rental_Gates_Roles::get_organization_id();
        }
        
        // Use new credits manager if available
        if (class_exists('Rental_Gates_AI_Credits')) {
            $balance = rg_ai_credits()->get_balance($org_id);
            
            return array(
                'monthly_limit' => $balance['plan_limit'],
                'used' => $balance['used_this_cycle'],
                'remaining' => $balance['total'],
                'reset_date' => $balance['cycle_end'],
                'by_tool' => rg_ai_credits()->get_usage_breakdown($org_id, 'month'),
                // Enhanced fields from new system
                'subscription_credits' => $balance['subscription'],
                'purchased_credits' => $balance['purchased'],
                'bonus_credits' => $balance['bonus'],
                'percentage_used' => $balance['percentage_used'],
                'status' => $balance['status'],
                'days_until_refresh' => $balance['days_until_refresh'],
            );
        }
        
        // Legacy fallback
        $default_stats = array(
            'monthly_limit' => 0,
            'used' => 0,
            'remaining' => 0,
            'reset_date' => date('Y-m-01', strtotime('+1 month')),
            'by_tool' => array(),
        );
        
        if (!$org_id) {
            return $default_stats;
        }
        
        global $wpdb;
        
        if (!class_exists('Rental_Gates_Database')) {
            return $default_stats;
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['ai_usage']}'");
        if (!$table_exists) {
            return $default_stats;
        }
        
        $plans = get_option('rental_gates_plans', array());
        $org = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tables['organizations']} WHERE id = %d",
            $org_id
        ));
        
        if (!$org) {
            return $default_stats;
        }
        
        $plan_id = $org->plan_id ?? 'free';
        $plan = $plans[$plan_id] ?? array();
        $monthly_limit = $plan['limits']['ai_credits'] ?? 0;
        
        $used = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(credits_used), 0) 
             FROM {$tables['ai_usage']} 
             WHERE organization_id = %d 
             AND MONTH(created_at) = MONTH(CURRENT_DATE())
             AND YEAR(created_at) = YEAR(CURRENT_DATE())",
            $org_id
        ));
        
        $by_tool = $wpdb->get_results($wpdb->prepare(
            "SELECT tool, COUNT(*) as count, SUM(credits_used) as credits
             FROM {$tables['ai_usage']} 
             WHERE organization_id = %d 
             AND MONTH(created_at) = MONTH(CURRENT_DATE())
             AND YEAR(created_at) = YEAR(CURRENT_DATE())
             GROUP BY tool",
            $org_id
        ), ARRAY_A);
        
        $tools = array();
        if ($by_tool) {
            foreach ($by_tool as $row) {
                $tools[$row['tool']] = array(
                    'count' => intval($row['count']),
                    'credits' => intval($row['credits']),
                );
            }
        }
        
        $reset_date = date('Y-m-01', strtotime('+1 month'));
        
        return array(
            'monthly_limit' => intval($monthly_limit),
            'used' => intval($used),
            'remaining' => max(0, $monthly_limit - intval($used)),
            'reset_date' => $reset_date,
            'by_tool' => $tools,
        );
    }
    
    /**
     * Log AI usage
     */
    private function log_usage($org_id, $user_id, $tool, $credits, $input, $output, $model = null, $tokens = null) {
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $wpdb->insert($tables['ai_usage'], array(
            'organization_id' => $org_id,
            'user_id' => $user_id,
            'tool' => $tool,
            'credits_used' => $credits,
            'input_data' => is_string($input) ? $input : json_encode($input),
            'output_data' => is_string($output) ? $output : json_encode($output),
            'provider' => $this->provider,
            'model' => $model,
            'tokens_used' => $tokens,
            'created_at' => current_time('mysql'),
        ));
        
        return $wpdb->insert_id;
    }
    
    /**
     * Call OpenAI API
     */
    private function call_openai($messages, $model = 'gpt-4o-mini', $max_tokens = 1000, $temperature = 0.7) {
        if (empty($this->openai_key)) {
            return new WP_Error('no_api_key', __('OpenAI API key not configured', 'rental-gates'));
        }
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 60,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->openai_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => $model,
                'messages' => $messages,
                'max_tokens' => $max_tokens,
                'temperature' => $temperature,
            )),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('api_error', $body['error']['message'] ?? 'Unknown error');
        }
        
        return array(
            'content' => $body['choices'][0]['message']['content'] ?? '',
            'tokens' => $body['usage']['total_tokens'] ?? 0,
            'model' => $model,
        );
    }
    
    /**
     * Call Google Gemini API
     */
    private function call_gemini($prompt, $model = 'gemini-1.5-flash', $max_tokens = 1000) {
        if (empty($this->gemini_key)) {
            return new WP_Error('no_api_key', __('Google Gemini API key not configured', 'rental-gates'));
        }
        
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $this->gemini_key;
        
        $response = wp_remote_post($url, array(
            'timeout' => 60,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'contents' => array(
                    array('parts' => array(array('text' => $prompt)))
                ),
                'generationConfig' => array(
                    'maxOutputTokens' => $max_tokens,
                    'temperature' => 0.7,
                ),
            )),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('api_error', $body['error']['message'] ?? 'Unknown error');
        }
        
        return array(
            'content' => $body['candidates'][0]['content']['parts'][0]['text'] ?? '',
            'tokens' => $body['usageMetadata']['totalTokenCount'] ?? 0,
            'model' => $model,
        );
    }
    
    /**
     * Call the configured AI provider
     */
    public function call($prompt, $system_prompt = '', $max_tokens = 1000) {
        if ($this->provider === 'openai') {
            $messages = array();
            if ($system_prompt) {
                $messages[] = array('role' => 'system', 'content' => $system_prompt);
            }
            $messages[] = array('role' => 'user', 'content' => $prompt);
            return $this->call_openai($messages, $this->openai_model, $max_tokens);
        } else {
            $full_prompt = $system_prompt ? $system_prompt . "\n\n" . $prompt : $prompt;
            return $this->call_gemini($full_prompt, $this->gemini_model, $max_tokens);
        }
    }
    
    // ==========================================
    // AI TOOLS
    // ==========================================
    
    /**
     * Generate property description
     * Credits: 1
     */
    public function generate_description($data, $org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 1) {
            return new WP_Error('no_credits', __('Insufficient AI credits', 'rental-gates'));
        }
        
        $type = $data['type'] ?? 'unit';
        $style = $data['style'] ?? 'professional';
        
        $prompt = "Generate an engaging property listing description.\n\n";
        $prompt .= "Property Details:\n";
        $prompt .= "- Type: " . ($data['unit_type'] ?? $data['property_type'] ?? 'Apartment') . "\n";
        $prompt .= "- Name: " . ($data['name'] ?? '') . "\n";
        
        if (!empty($data['bedrooms'])) $prompt .= "- Bedrooms: " . $data['bedrooms'] . "\n";
        if (!empty($data['bathrooms'])) $prompt .= "- Bathrooms: " . $data['bathrooms'] . "\n";
        if (!empty($data['sqft'])) $prompt .= "- Square Feet: " . $data['sqft'] . "\n";
        if (!empty($data['rent'])) $prompt .= "- Monthly Rent: $" . number_format($data['rent']) . "\n";
        if (!empty($data['address'])) $prompt .= "- Location: " . $data['address'] . "\n";
        if (!empty($data['amenities'])) $prompt .= "- Amenities: " . implode(', ', (array)$data['amenities']) . "\n";
        if (!empty($data['features'])) $prompt .= "- Features: " . $data['features'] . "\n";
        if (!empty($data['neighborhood'])) $prompt .= "- Neighborhood: " . $data['neighborhood'] . "\n";
        
        $prompt .= "\nStyle: " . ucfirst($style);
        $prompt .= "\n\nWrite a compelling 150-200 word description that highlights the property's best features, appeals to prospective tenants, and creates urgency. Do not use excessive punctuation or emojis.";
        
        $system = "You are a professional real estate copywriter. Write engaging, accurate property descriptions that convert. Be specific and avoid generic filler phrases.";
        
        $result = $this->call($prompt, $system, 500);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $this->log_usage($org_id, $user_id, 'description', 1, $data, $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'description' => trim($result['content']),
            'credits_used' => 1,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * Generate marketing copy
     * Credits: 1
     */
    public function generate_marketing($data, $org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 1) {
            return new WP_Error('no_credits', __('Insufficient AI credits', 'rental-gates'));
        }
        
        $format = $data['format'] ?? 'flyer';
        
        $prompts = array(
            'flyer' => "Create compelling flyer copy with headline, subheadline, 3-4 bullet points, and call-to-action.",
            'social' => "Create an engaging social media post (under 280 characters) with relevant hashtags.",
            'email' => "Create a professional email subject line and body for a property listing announcement.",
            'ad' => "Create short, punchy ad copy (headline + 2-line description) for online advertising.",
        );
        
        $prompt = "Property: " . ($data['name'] ?? 'Available Unit') . "\n";
        if (!empty($data['rent'])) $prompt .= "Rent: $" . number_format($data['rent']) . "/month\n";
        if (!empty($data['bedrooms'])) $prompt .= "Bedrooms: " . $data['bedrooms'] . "\n";
        if (!empty($data['address'])) $prompt .= "Location: " . $data['address'] . "\n";
        if (!empty($data['highlights'])) $prompt .= "Highlights: " . $data['highlights'] . "\n";
        
        $prompt .= "\n" . ($prompts[$format] ?? $prompts['flyer']);
        
        $system = "You are a real estate marketing expert. Create compelling, professional marketing copy that drives action. Be concise and impactful.";
        
        $result = $this->call($prompt, $system, 400);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $this->log_usage($org_id, $user_id, 'marketing', 1, $data, $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'content' => trim($result['content']),
            'format' => $format,
            'credits_used' => 1,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * AI Tenant Screening Analysis
     * Credits: 3
     */
    public function screen_applicant($application_id, $org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 3) {
            return new WP_Error('no_credits', __('Insufficient AI credits (3 required)', 'rental-gates'));
        }
        
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $application = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, u.unit_type, u.rent_amount, u.deposit_amount
             FROM {$tables['applications']} a
             LEFT JOIN {$tables['units']} u ON a.unit_id = u.id
             WHERE a.id = %d AND a.organization_id = %d",
            $application_id,
            $org_id
        ));
        
        if (!$application) {
            return new WP_Error('not_found', __('Application not found', 'rental-gates'));
        }
        
        $prompt = "Analyze this rental application and provide a risk assessment.\n\n";
        $prompt .= "APPLICANT INFORMATION:\n";
        $prompt .= "- Name: " . ($application->first_name ?? '') . " " . ($application->last_name ?? '') . "\n";
        $prompt .= "- Employment: " . ($application->employer ?? 'Not provided') . "\n";
        $prompt .= "- Monthly Income: $" . number_format($application->monthly_income ?? 0) . "\n";
        $prompt .= "- Current Address Duration: " . ($application->current_address_duration ?? 'Unknown') . "\n";
        $prompt .= "- Previous Landlord: " . ($application->previous_landlord_name ?? 'Not provided') . "\n";
        $prompt .= "- Reason for Moving: " . ($application->move_reason ?? 'Not provided') . "\n";
        $prompt .= "- Pets: " . ($application->has_pets ? 'Yes' : 'No') . "\n";
        $prompt .= "- Smoker: " . ($application->is_smoker ? 'Yes' : 'No') . "\n";
        $prompt .= "- Criminal History Disclosed: " . ($application->has_criminal_history ? 'Yes' : 'No') . "\n";
        $prompt .= "- Eviction History Disclosed: " . ($application->has_eviction_history ? 'Yes' : 'No') . "\n";
        
        $prompt .= "\nPROPERTY DETAILS:\n";
        $prompt .= "- Unit Type: " . ($application->unit_type ?? 'Apartment') . "\n";
        $prompt .= "- Monthly Rent: $" . number_format($application->rent_amount ?? 0) . "\n";
        
        $income = floatval($application->monthly_income ?? 0);
        $rent = floatval($application->rent_amount ?? 0);
        $ratio = $income > 0 ? round(($rent / $income) * 100, 1) : 0;
        $prompt .= "- Rent-to-Income Ratio: {$ratio}% (recommended: under 30%)\n";
        
        $prompt .= "\nProvide your analysis in the following JSON format:\n";
        $prompt .= '{"risk_score": "low|medium|high", "recommendation": "approve|review|decline", "strength_factors": ["factor1", "factor2"], "concern_factors": ["concern1", "concern2"], "summary": "2-3 sentence summary"}';
        
        $system = "You are a property management risk analyst. Analyze rental applications objectively based on financial indicators, housing history, and disclosed information. Be fair and non-discriminatory. Focus on verifiable factors like income ratio, employment stability, and housing history. Never make assumptions based on protected characteristics.";
        
        $result = $this->call($prompt, $system, 800);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $content = $result['content'];
        if (preg_match('/\{[^{}]*"risk_score"[^{}]*\}/s', $content, $matches)) {
            $json = $matches[0];
        } else {
            $json = $content;
        }
        
        $analysis = json_decode($json, true);
        
        if (!$analysis || !isset($analysis['risk_score'])) {
            $analysis = array(
                'risk_score' => 'medium',
                'recommendation' => 'review',
                'strength_factors' => array(),
                'concern_factors' => array(),
                'summary' => $content,
            );
        }
        
        $wpdb->insert($tables['ai_screenings'], array(
            'application_id' => $application_id,
            'risk_score' => $analysis['risk_score'],
            'strength_factors' => json_encode($analysis['strength_factors'] ?? array()),
            'concern_factors' => json_encode($analysis['concern_factors'] ?? array()),
            'summary' => $analysis['summary'] ?? '',
            'recommendation' => $analysis['recommendation'] ?? 'review',
            'raw_response' => $result['content'],
            'credits_used' => 3,
            'screened_at' => current_time('mysql'),
        ));
        
        $screening_id = $wpdb->insert_id;
        
        $this->log_usage($org_id, $user_id, 'screening', 3, array('application_id' => $application_id), $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'screening_id' => $screening_id,
            'risk_score' => $analysis['risk_score'],
            'recommendation' => $analysis['recommendation'],
            'strength_factors' => $analysis['strength_factors'] ?? array(),
            'concern_factors' => $analysis['concern_factors'] ?? array(),
            'summary' => $analysis['summary'] ?? '',
            'credits_used' => 3,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * Maintenance Request Triage
     * Credits: 1
     */
    public function triage_maintenance($data, $org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 1) {
            return new WP_Error('no_credits', __('Insufficient AI credits', 'rental-gates'));
        }
        
        $prompt = "Analyze this maintenance request and provide triage information.\n\n";
        $prompt .= "REQUEST:\n";
        $prompt .= "Title: " . ($data['title'] ?? 'Maintenance Request') . "\n";
        $prompt .= "Description: " . ($data['description'] ?? '') . "\n";
        if (!empty($data['location'])) $prompt .= "Location: " . $data['location'] . "\n";
        
        $prompt .= "\nProvide your analysis in the following JSON format:\n";
        $prompt .= '{"category": "plumbing|electrical|hvac|appliance|structural|pest|other", "priority": "emergency|high|medium|low", "estimated_cost_range": "$X-$Y", "suggested_vendor_type": "type", "tenant_instructions": "immediate steps tenant should take", "safety_concerns": ["concern1"] or null, "summary": "brief assessment"}';
        
        $system = "You are a property maintenance expert. Analyze maintenance requests to determine category, priority, and recommended actions. Prioritize safety issues. Be practical and cost-conscious.";
        
        $result = $this->call($prompt, $system, 600);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $content = $result['content'];
        if (preg_match('/\{[^{}]*"category"[^{}]*\}/s', $content, $matches)) {
            $json = $matches[0];
        } else {
            $json = $content;
        }
        
        $analysis = json_decode($json, true);
        
        if (!$analysis || !isset($analysis['category'])) {
            $analysis = array(
                'category' => 'other',
                'priority' => 'medium',
                'summary' => $content,
            );
        }
        
        $this->log_usage($org_id, $user_id, 'maintenance', 1, $data, $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'category' => $analysis['category'] ?? 'other',
            'priority' => $analysis['priority'] ?? 'medium',
            'estimated_cost_range' => $analysis['estimated_cost_range'] ?? null,
            'suggested_vendor_type' => $analysis['suggested_vendor_type'] ?? null,
            'tenant_instructions' => $analysis['tenant_instructions'] ?? null,
            'safety_concerns' => $analysis['safety_concerns'] ?? null,
            'summary' => $analysis['summary'] ?? '',
            'credits_used' => 1,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * Draft tenant message
     * Credits: 1
     */
    public function draft_message($data, $org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 1) {
            return new WP_Error('no_credits', __('Insufficient AI credits', 'rental-gates'));
        }
        
        $type = $data['type'] ?? 'general';
        $tone = $data['tone'] ?? 'professional';
        
        $templates = array(
            'late_rent' => 'a reminder about late rent payment',
            'maintenance' => 'an update about a maintenance request',
            'lease_renewal' => 'a lease renewal offer or discussion',
            'welcome' => 'a welcome message for a new tenant',
            'notice' => 'an important notice or announcement',
            'general' => 'a general communication',
        );
        
        $prompt = "Draft a message regarding " . ($templates[$type] ?? $templates['general']) . ".\n\n";
        $prompt .= "Context: " . ($data['context'] ?? 'General tenant communication') . "\n";
        $prompt .= "Tone: " . ucfirst($tone) . "\n";
        if (!empty($data['tenant_name'])) $prompt .= "Tenant Name: " . $data['tenant_name'] . "\n";
        if (!empty($data['property'])) $prompt .= "Property: " . $data['property'] . "\n";
        if (!empty($data['specific_details'])) $prompt .= "Details: " . $data['specific_details'] . "\n";
        
        $prompt .= "\nWrite a clear, professional message. Include appropriate greeting and closing.";
        
        $system = "You are a professional property manager. Draft clear, respectful communications that maintain good tenant relationships while addressing business matters effectively.";
        
        $result = $this->call($prompt, $system, 500);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $this->log_usage($org_id, $user_id, 'message', 1, $data, $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'message' => trim($result['content']),
            'type' => $type,
            'credits_used' => 1,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * Portfolio Insights
     * Credits: 2
     */
    public function get_portfolio_insights($org_id = null, $user_id = null) {
        if (!$org_id) $org_id = Rental_Gates_Roles::get_organization_id();
        if (!$user_id) $user_id = get_current_user_id();
        
        $remaining = self::get_remaining_credits($org_id);
        if ($remaining < 2) {
            return new WP_Error('no_credits', __('Insufficient AI credits (2 required)', 'rental-gates'));
        }
        
        global $wpdb;
        $tables = Rental_Gates_Database::get_table_names();
        
        $stats = array();
        
        $stats['total_units'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['units']} WHERE organization_id = %d",
            $org_id
        ));
        
        $stats['occupied_units'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['units']} WHERE organization_id = %d AND status = 'occupied'",
            $org_id
        ));
        
        $stats['vacancy_rate'] = $stats['total_units'] > 0 
            ? round((($stats['total_units'] - $stats['occupied_units']) / $stats['total_units']) * 100, 1) 
            : 0;
        
        $stats['monthly_rent_potential'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(rent_amount), 0) FROM {$tables['units']} WHERE organization_id = %d",
            $org_id
        ));
        
        $stats['collected_this_month'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM {$tables['payments']} 
             WHERE organization_id = %d AND status = 'completed'
             AND MONTH(created_at) = MONTH(CURRENT_DATE())
             AND YEAR(created_at) = YEAR(CURRENT_DATE())",
            $org_id
        ));
        
        $stats['open_maintenance'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['maintenance']} 
             WHERE organization_id = %d AND status IN ('new', 'in_progress')",
            $org_id
        ));
        
        $stats['expiring_leases_90d'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$tables['leases']} 
             WHERE organization_id = %d AND status = 'active'
             AND end_date BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 90 DAY)",
            $org_id
        ));
        
        $prompt = "Analyze this property portfolio and provide actionable insights.\n\n";
        $prompt .= "PORTFOLIO METRICS:\n";
        $prompt .= "- Total Units: " . $stats['total_units'] . "\n";
        $prompt .= "- Occupied Units: " . $stats['occupied_units'] . "\n";
        $prompt .= "- Vacancy Rate: " . $stats['vacancy_rate'] . "%\n";
        $prompt .= "- Monthly Rent Potential: $" . number_format($stats['monthly_rent_potential']) . "\n";
        $prompt .= "- Collected This Month: $" . number_format($stats['collected_this_month']) . "\n";
        $prompt .= "- Open Maintenance Requests: " . $stats['open_maintenance'] . "\n";
        $prompt .= "- Leases Expiring in 90 Days: " . $stats['expiring_leases_90d'] . "\n";
        
        $prompt .= "\nProvide your analysis in the following JSON format:\n";
        $prompt .= '{"health_score": 1-100, "key_metrics": [{"label": "name", "value": "X", "trend": "up|down|stable", "insight": "brief"}], "recommendations": [{"priority": "high|medium|low", "action": "what to do", "impact": "expected result"}], "risks": ["risk1"], "opportunities": ["opportunity1"]}';
        
        $system = "You are a real estate portfolio analyst. Provide data-driven insights and actionable recommendations. Focus on occupancy optimization, revenue maximization, and risk mitigation.";
        
        $result = $this->call($prompt, $system, 1000);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $content = $result['content'];
        if (preg_match('/\{.*"health_score".*\}/s', $content, $matches)) {
            $json = $matches[0];
        } else {
            $json = $content;
        }
        
        $analysis = json_decode($json, true);
        
        if (!$analysis || !isset($analysis['health_score'])) {
            $analysis = array(
                'health_score' => 70,
                'key_metrics' => array(),
                'recommendations' => array(),
                'risks' => array(),
                'opportunities' => array(),
                'raw_analysis' => $content,
            );
        }
        
        $this->log_usage($org_id, $user_id, 'insights', 2, $stats, $result['content'], $result['model'], $result['tokens']);
        
        return array(
            'health_score' => intval($analysis['health_score'] ?? 70),
            'key_metrics' => $analysis['key_metrics'] ?? array(),
            'recommendations' => $analysis['recommendations'] ?? array(),
            'risks' => $analysis['risks'] ?? array(),
            'opportunities' => $analysis['opportunities'] ?? array(),
            'portfolio_stats' => $stats,
            'credits_used' => 2,
            'credits_remaining' => self::get_remaining_credits($org_id),
        );
    }
    
    /**
     * Get AI history for organization
     */
    public static function get_history($org_id = null, $limit = 20, $tool = null) {
        if (!$org_id) {
            $org_id = Rental_Gates_Roles::get_organization_id();
        }
        
        if (!$org_id) {
            return array();
        }
        
        global $wpdb;
        
        // Check if Database class exists
        if (!class_exists('Rental_Gates_Database')) {
            return array();
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check if ai_usage table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$tables['ai_usage']}'");
        if (!$table_exists) {
            return array();
        }
        
        $where = "organization_id = %d";
        $params = array($org_id);
        
        if ($tool) {
            $where .= " AND tool = %s";
            $params[] = $tool;
        }
        
        $params[] = $limit;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT u.*, us.display_name as user_name
             FROM {$tables['ai_usage']} u
             LEFT JOIN {$wpdb->users} us ON u.user_id = us.ID
             WHERE {$where}
             ORDER BY created_at DESC
             LIMIT %d",
            $params
        ), ARRAY_A);
        
        return $results ?: array();
    }
}

function rental_gates_ai() {
    return Rental_Gates_AI::get_instance();
}
