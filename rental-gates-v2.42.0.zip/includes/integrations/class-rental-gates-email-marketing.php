<?php
/**
 * Rental Gates Email Marketing Integration
 * 
 * Provides integration with email marketing platforms like Mailchimp,
 * SendGrid, and generic SMTP/API services.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Email_Marketing {
    
    /**
     * Supported providers
     */
    const PROVIDER_MAILCHIMP = 'mailchimp';
    const PROVIDER_SENDGRID = 'sendgrid';
    const PROVIDER_GENERIC = 'generic';
    
    /**
     * Get integration settings for organization
     */
    public static function get_settings($org_id) {
        return array(
            'provider' => get_option('rental_gates_email_provider_' . $org_id, ''),
            'api_key' => get_option('rental_gates_email_api_key_' . $org_id, ''),
            'list_id' => get_option('rental_gates_email_list_id_' . $org_id, ''),
            'enabled' => get_option('rental_gates_email_marketing_enabled_' . $org_id, false),
        );
    }
    
    /**
     * Add contact to email marketing list
     */
    public static function add_contact($org_id, $email, $name, $data = array()) {
        $settings = self::get_settings($org_id);
        
        if (!$settings['enabled'] || empty($settings['provider'])) {
            return false;
        }
        
        switch ($settings['provider']) {
            case self::PROVIDER_MAILCHIMP:
                return self::add_to_mailchimp($settings, $email, $name, $data);
            case self::PROVIDER_SENDGRID:
                return self::add_to_sendgrid($settings, $email, $name, $data);
            default:
                return false;
        }
    }
    
    /**
     * Add to Mailchimp
     */
    private static function add_to_mailchimp($settings, $email, $name, $data) {
        if (empty($settings['api_key']) || empty($settings['list_id'])) {
            return false;
        }
        
        // Extract server from API key (format: key-server)
        $parts = explode('-', $settings['api_key']);
        $server = end($parts);
        
        $url = "https://{$server}.api.mailchimp.com/3.0/lists/{$settings['list_id']}/members";
        
        $body = array(
            'email_address' => $email,
            'status' => 'subscribed',
            'merge_fields' => array(
                'FNAME' => $name,
            ),
        );
        
        if (!empty($data['phone'])) {
            $body['merge_fields']['PHONE'] = $data['phone'];
        }
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode('apikey:' . $settings['api_key']),
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($body),
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }
    
    /**
     * Add to SendGrid
     */
    private static function add_to_sendgrid($settings, $email, $name, $data) {
        if (empty($settings['api_key']) || empty($settings['list_id'])) {
            return false;
        }
        
        $url = 'https://api.sendgrid.com/v3/marketing/contacts';
        
        $contact = array(
            'email' => $email,
            'first_name' => $name,
        );
        
        if (!empty($data['phone'])) {
            $contact['phone_number'] = $data['phone'];
        }
        
        $body = array(
            'list_ids' => array($settings['list_id']),
            'contacts' => array($contact),
        );
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $settings['api_key'],
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($body),
        ));
        
        return !is_wp_error($response) && in_array(wp_remote_retrieve_response_code($response), array(200, 202));
    }
    
    /**
     * Sync lead to email marketing platform
     */
    public static function sync_lead($lead_id) {
        $lead = Rental_Gates_Lead::get($lead_id);
        if (!$lead || empty($lead['email'])) {
            return false;
        }
        
        return self::add_contact(
            $lead['organization_id'],
            $lead['email'],
            $lead['name'],
            array(
                'phone' => $lead['phone'] ?? '',
                'source' => $lead['source'] ?? '',
            )
        );
    }
}
