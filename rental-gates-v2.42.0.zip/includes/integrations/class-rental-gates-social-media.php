<?php
/**
 * Rental Gates Social Media Integration
 * 
 * Provides integration with social media platforms for posting
 * property listings and marketing content.
 * 
 * @version 1.0.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Social_Media {
    
    /**
     * Supported platforms
     */
    const PLATFORM_FACEBOOK = 'facebook';
    const PLATFORM_INSTAGRAM = 'instagram';
    const PLATFORM_TWITTER = 'twitter';
    const PLATFORM_LINKEDIN = 'linkedin';
    
    /**
     * Get integration settings for organization
     */
    public static function get_settings($org_id) {
        return array(
            'facebook' => array(
                'enabled' => get_option('rental_gates_social_facebook_enabled_' . $org_id, false),
                'page_id' => get_option('rental_gates_social_facebook_page_id_' . $org_id, ''),
                'access_token' => get_option('rental_gates_social_facebook_token_' . $org_id, ''),
            ),
            'instagram' => array(
                'enabled' => get_option('rental_gates_social_instagram_enabled_' . $org_id, false),
                'account_id' => get_option('rental_gates_social_instagram_account_id_' . $org_id, ''),
                'access_token' => get_option('rental_gates_social_instagram_token_' . $org_id, ''),
            ),
            'twitter' => array(
                'enabled' => get_option('rental_gates_social_twitter_enabled_' . $org_id, false),
                'api_key' => get_option('rental_gates_social_twitter_api_key_' . $org_id, ''),
                'api_secret' => get_option('rental_gates_social_twitter_api_secret_' . $org_id, ''),
            ),
            'linkedin' => array(
                'enabled' => get_option('rental_gates_social_linkedin_enabled_' . $org_id, false),
                'company_id' => get_option('rental_gates_social_linkedin_company_id_' . $org_id, ''),
                'access_token' => get_option('rental_gates_social_linkedin_token_' . $org_id, ''),
            ),
        );
    }
    
    /**
     * Post to social media
     */
    public static function post($org_id, $platform, $content, $media_url = null) {
        $settings = self::get_settings($org_id);
        
        if (empty($settings[$platform]['enabled'])) {
            return new WP_Error('not_enabled', __('Platform not enabled', 'rental-gates'));
        }
        
        switch ($platform) {
            case self::PLATFORM_FACEBOOK:
                return self::post_to_facebook($settings[$platform], $content, $media_url);
            case self::PLATFORM_INSTAGRAM:
                return self::post_to_instagram($settings[$platform], $content, $media_url);
            case self::PLATFORM_TWITTER:
                return self::post_to_twitter($settings[$platform], $content, $media_url);
            case self::PLATFORM_LINKEDIN:
                return self::post_to_linkedin($settings[$platform], $content, $media_url);
            default:
                return new WP_Error('unsupported', __('Platform not supported', 'rental-gates'));
        }
    }
    
    /**
     * Post to Facebook
     */
    private static function post_to_facebook($settings, $content, $media_url) {
        if (empty($settings['page_id']) || empty($settings['access_token'])) {
            return new WP_Error('missing_credentials', __('Facebook credentials not configured', 'rental-gates'));
        }
        
        $url = "https://graph.facebook.com/v18.0/{$settings['page_id']}/feed";
        
        $body = array(
            'message' => $content,
            'access_token' => $settings['access_token'],
        );
        
        if ($media_url) {
            $body['link'] = $media_url;
        }
        
        $response = wp_remote_post($url, array(
            'body' => $body,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return new WP_Error('api_error', __('Failed to post to Facebook', 'rental-gates'));
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return array('post_id' => $data['id'] ?? null);
    }
    
    /**
     * Post to Instagram
     */
    private static function post_to_instagram($settings, $content, $media_url) {
        // Instagram API requires more complex setup with media containers
        // This is a placeholder for future implementation
        return new WP_Error('not_implemented', __('Instagram posting not yet implemented', 'rental-gates'));
    }
    
    /**
     * Post to Twitter/X
     */
    private static function post_to_twitter($settings, $content, $media_url) {
        // Twitter API v2 requires OAuth 2.0
        // This is a placeholder for future implementation
        return new WP_Error('not_implemented', __('Twitter posting not yet implemented', 'rental-gates'));
    }
    
    /**
     * Post to LinkedIn
     */
    private static function post_to_linkedin($settings, $content, $media_url) {
        if (empty($settings['company_id']) || empty($settings['access_token'])) {
            return new WP_Error('missing_credentials', __('LinkedIn credentials not configured', 'rental-gates'));
        }
        
        $url = "https://api.linkedin.com/v2/ugcPosts";
        
        $body = array(
            'author' => "urn:li:organization:{$settings['company_id']}",
            'lifecycleState' => 'PUBLISHED',
            'specificContent' => array(
                'com.linkedin.ugc.ShareContent' => array(
                    'shareCommentary' => array(
                        'text' => $content,
                    ),
                    'shareMediaCategory' => 'ARTICLE',
                ),
            ),
            'visibility' => array(
                'com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC',
            ),
        );
        
        if ($media_url) {
            $body['specificContent']['com.linkedin.ugc.ShareContent']['media'] = array(
                array(
                    'status' => 'READY',
                    'media' => $media_url,
                ),
            );
        }
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $settings['access_token'],
                'Content-Type' => 'application/json',
                'X-Restli-Protocol-Version' => '2.0.0',
            ),
            'body' => wp_json_encode($body),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if (!in_array($code, array(200, 201))) {
            return new WP_Error('api_error', __('Failed to post to LinkedIn', 'rental-gates'));
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return array('post_id' => $data['id'] ?? null);
    }
}
