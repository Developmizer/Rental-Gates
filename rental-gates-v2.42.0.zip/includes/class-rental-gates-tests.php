<?php
/**
 * Rental Gates Testing Utility
 * 
 * Provides comprehensive testing and validation for the plugin.
 * Run via WP-CLI or admin dashboard.
 * 
 * @package RentalGates
 * @since 2.22.0
 */
if (!defined('ABSPATH')) exit;

class Rental_Gates_Tests {
    
    private static $results = array();
    private static $errors = array();
    private static $warnings = array();
    
    /**
     * Run all tests
     */
    public static function run_all() {
        self::$results = array();
        self::$errors = array();
        self::$warnings = array();
        
        $tests = array(
            'database' => 'Database Tables',
            'models' => 'Model Classes',
            'api' => 'REST API Endpoints',
            'permissions' => 'Permissions System',
            'email' => 'Email System',
            'security' => 'Security Features',
            'files' => 'File Integrity',
        );
        
        foreach ($tests as $test => $name) {
            $method = 'test_' . $test;
            if (method_exists(__CLASS__, $method)) {
                self::$results[$test] = array(
                    'name' => $name,
                    'result' => self::$method(),
                );
            }
        }
        
        return array(
            'results' => self::$results,
            'errors' => self::$errors,
            'warnings' => self::$warnings,
            'summary' => self::get_summary(),
        );
    }
    
    /**
     * Test database tables
     */
    private static function test_database() {
        global $wpdb;
        $passed = 0;
        $failed = 0;
        
        if (!class_exists('Rental_Gates_Database')) {
            self::$errors[] = 'Database class not loaded';
            return array('passed' => 0, 'failed' => 1);
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        foreach ($tables as $key => $table) {
            $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
            if ($exists) {
                $passed++;
            } else {
                $failed++;
                self::$warnings[] = "Table missing: {$key} ({$table})";
            }
        }
        
        // Check for required columns in key tables
        $required_columns = array(
            'organizations' => array('id', 'name', 'slug', 'owner_id', 'plan_id', 'status'),
            'buildings' => array('id', 'organization_id', 'name', 'slug', 'status'),
            'units' => array('id', 'organization_id', 'building_id', 'name', 'rent_amount'),
            'tenants' => array('id', 'organization_id', 'email', 'first_name', 'last_name'),
            'leases' => array('id', 'organization_id', 'unit_id', 'start_date', 'end_date', 'rent_amount'),
            'payments' => array('id', 'organization_id', 'tenant_id', 'amount', 'status'),
        );
        
        foreach ($required_columns as $table_key => $columns) {
            if (!isset($tables[$table_key])) continue;
            
            $table = $tables[$table_key];
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
            
            if ($table_exists) {
                $existing_columns = $wpdb->get_col("SHOW COLUMNS FROM {$table}");
                foreach ($columns as $col) {
                    if (!in_array($col, $existing_columns)) {
                        self::$warnings[] = "Missing column: {$table_key}.{$col}";
                    }
                }
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test model classes
     */
    private static function test_models() {
        $passed = 0;
        $failed = 0;
        
        $models = array(
            'Rental_Gates_Organization' => array('get', 'create', 'update', 'delete'),
            'Rental_Gates_Building' => array('get', 'create', 'update', 'delete', 'get_for_organization'),
            'Rental_Gates_Unit' => array('get', 'create', 'update', 'delete', 'get_for_building'),
            'Rental_Gates_Tenant' => array('get', 'create', 'update', 'delete', 'get_for_organization'),
            'Rental_Gates_Lease' => array('get', 'create', 'update', 'get_with_details'),
            'Rental_Gates_Payment' => array('get', 'create', 'get_for_organization'),
            'Rental_Gates_Maintenance' => array('get', 'create', 'update', 'get_with_details'),
            'Rental_Gates_Lead' => array('get', 'create', 'update', 'get_for_organization'),
            'Rental_Gates_Application' => array('get', 'create', 'update_status'),
            'Rental_Gates_Document' => array('get', 'create', 'delete'),
            'Rental_Gates_Vendor' => array('get', 'create', 'update'),
            'Rental_Gates_Message' => array('create', 'get_conversation'),
            'Rental_Gates_Announcement' => array('create', 'get_active'),
            'Rental_Gates_Notification' => array('create', 'mark_read'),
        );
        
        foreach ($models as $class => $methods) {
            if (!class_exists($class)) {
                $failed++;
                self::$errors[] = "Model class missing: {$class}";
                continue;
            }
            
            $passed++;
            
            foreach ($methods as $method) {
                if (!method_exists($class, $method)) {
                    self::$warnings[] = "Method missing: {$class}::{$method}";
                }
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test REST API endpoints registration
     */
    private static function test_api() {
        $passed = 0;
        $failed = 0;
        
        if (!class_exists('Rental_Gates_REST_API')) {
            self::$errors[] = 'REST API class not loaded';
            return array('passed' => 0, 'failed' => 1);
        }
        
        // Required API handler methods
        $required_handlers = array(
            // Auth
            'login', 'register', 'logout',
            // Buildings
            'get_buildings', 'create_building', 'get_building', 'update_building', 'delete_building',
            // Units
            'get_units', 'create_unit', 'get_unit', 'update_unit', 'delete_unit',
            // Tenants
            'get_tenants', 'create_tenant', 'get_tenant', 'update_tenant',
            // Leases
            'get_leases', 'create_lease', 'get_lease', 'update_lease',
            // Payments
            'get_payments', 'create_payment', 'get_payment',
            // Maintenance
            'get_work_orders', 'create_work_order', 'get_work_order', 'update_work_order',
            // Applications
            'get_applications', 'create_application', 'get_application',
            // Leads
            'get_leads', 'create_lead', 'get_lead', 'update_lead',
            // QR
            'get_qr_codes', 'create_qr_code', 'handle_qr_scan',
            // PDF
            'generate_lease_pdf', 'generate_receipt_pdf', 'generate_flyer_pdf',
            // AI
            'get_ai_credits', 'generate_ai_description', 'draft_ai_message',
        );
        
        $api = new Rental_Gates_REST_API();
        
        foreach ($required_handlers as $handler) {
            if (method_exists($api, $handler)) {
                $passed++;
            } else {
                $failed++;
                self::$errors[] = "API handler missing: {$handler}";
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test permissions system
     */
    private static function test_permissions() {
        $passed = 0;
        $failed = 0;
        
        if (!class_exists('Rental_Gates_Roles')) {
            self::$errors[] = 'Roles class not loaded';
            return array('passed' => 0, 'failed' => 1);
        }
        
        $required_methods = array(
            'get_organization_id',
            'is_site_admin',
            'is_owner',
            'is_owner_or_manager',
            'is_staff',
            'is_tenant',
            'is_vendor',
            'has_role_for_org',
            'get_user_role',
        );
        
        foreach ($required_methods as $method) {
            if (method_exists('Rental_Gates_Roles', $method)) {
                $passed++;
            } else {
                $failed++;
                self::$errors[] = "Role method missing: {$method}";
            }
        }
        
        // Test Feature Gate
        if (class_exists('Rental_Gates_Feature_Gate')) {
            $gate_methods = array('can_access_module', 'check_limit', 'get_plan_features');
            foreach ($gate_methods as $method) {
                if (method_exists('Rental_Gates_Feature_Gate', $method)) {
                    $passed++;
                } else {
                    self::$warnings[] = "Feature gate method missing: {$method}";
                }
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test email system
     */
    private static function test_email() {
        $passed = 0;
        $failed = 0;
        
        if (!class_exists('Rental_Gates_Email')) {
            self::$errors[] = 'Email class not loaded';
            return array('passed' => 0, 'failed' => 1);
        }
        
        // Check for required templates
        $required_templates = array(
            'welcome', 'password_reset', 'tenant_invitation',
            'payment_receipt', 'payment_reminder', 'payment_overdue',
            'maintenance_created', 'maintenance_update', 'maintenance_completed',
            'application_received', 'application_approved', 'application_declined',
            'lease_created', 'lease_ending',
        );
        
        $template_dir = RENTAL_GATES_PLUGIN_DIR . 'templates/emails/';
        
        foreach ($required_templates as $template) {
            $file = $template_dir . $template . '.php';
            if (file_exists($file)) {
                $passed++;
            } else {
                $failed++;
                self::$warnings[] = "Email template missing: {$template}";
            }
        }
        
        // Check helper methods
        $helper_methods = array(
            'send', 'send_bulk', 'button', 'heading', 'text', 'alert',
        );
        
        foreach ($helper_methods as $method) {
            if (method_exists('Rental_Gates_Email', $method)) {
                $passed++;
            } else {
                self::$warnings[] = "Email helper missing: {$method}";
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test security features
     */
    private static function test_security() {
        $passed = 0;
        $failed = 0;
        
        if (!class_exists('Rental_Gates_Security')) {
            self::$errors[] = 'Security class not loaded';
            return array('passed' => 0, 'failed' => 1);
        }
        
        $required_methods = array(
            'verify_nonce',
            'verify_rest_nonce',
            'sanitize_input',
            'validate_email',
            'validate_phone',
            'check_rate_limit',
            'log_security_event',
        );
        
        foreach ($required_methods as $method) {
            if (method_exists('Rental_Gates_Security', $method)) {
                $passed++;
            } else {
                $failed++;
                self::$errors[] = "Security method missing: {$method}";
            }
        }
        
        // Check rate limiting
        if (class_exists('Rental_Gates_Rate_Limit')) {
            $passed++;
        } else {
            self::$warnings[] = 'Rate limit class not found';
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Test file integrity
     */
    private static function test_files() {
        $passed = 0;
        $failed = 0;
        
        $required_files = array(
            'rental-gates.php',
            'includes/class-rental-gates-loader.php',
            'includes/class-rental-gates-database.php',
            'includes/class-rental-gates-roles.php',
            'includes/class-rental-gates-security.php',
            'includes/class-rental-gates-email.php',
            'includes/class-rental-gates-pdf.php',
            'includes/class-rental-gates-ai.php',
            'includes/class-rental-gates-stripe.php',
            'includes/api/class-rental-gates-rest-api.php',
            'includes/models/class-rental-gates-organization.php',
            'includes/models/class-rental-gates-building.php',
            'includes/models/class-rental-gates-unit.php',
            'includes/models/class-rental-gates-tenant.php',
            'includes/models/class-rental-gates-lease.php',
            'includes/models/class-rental-gates-payment.php',
            'includes/models/class-rental-gates-lead.php',
            'includes/public/class-rental-gates-qr.php',
        );
        
        $base = defined('RENTAL_GATES_PLUGIN_DIR') ? RENTAL_GATES_PLUGIN_DIR : dirname(__DIR__) . '/';
        
        foreach ($required_files as $file) {
            if (file_exists($base . $file)) {
                $passed++;
            } else {
                $failed++;
                self::$errors[] = "Required file missing: {$file}";
            }
        }
        
        return array('passed' => $passed, 'failed' => $failed);
    }
    
    /**
     * Get test summary
     */
    private static function get_summary() {
        $total_passed = 0;
        $total_failed = 0;
        
        foreach (self::$results as $result) {
            $total_passed += $result['result']['passed'];
            $total_failed += $result['result']['failed'];
        }
        
        $total = $total_passed + $total_failed;
        $percentage = $total > 0 ? round(($total_passed / $total) * 100, 1) : 0;
        
        return array(
            'total_tests' => $total,
            'passed' => $total_passed,
            'failed' => $total_failed,
            'percentage' => $percentage,
            'status' => $total_failed === 0 ? 'passed' : ($total_failed < 5 ? 'warning' : 'failed'),
            'error_count' => count(self::$errors),
            'warning_count' => count(self::$warnings),
        );
    }
    
    /**
     * Validate API endpoint
     */
    public static function validate_endpoint($endpoint, $method = 'GET', $data = array()) {
        $url = rest_url('rental-gates/v1/' . ltrim($endpoint, '/'));
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
        );
        
        if (!empty($data) && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message(),
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return array(
            'success' => $code >= 200 && $code < 300,
            'code' => $code,
            'body' => $body,
        );
    }
    
    /**
     * Check database integrity
     */
    public static function check_integrity() {
        global $wpdb;
        $issues = array();
        
        if (!class_exists('Rental_Gates_Database')) {
            return array('error' => 'Database class not loaded');
        }
        
        $tables = Rental_Gates_Database::get_table_names();
        
        // Check for orphaned records
        $checks = array(
            array(
                'name' => 'Orphaned units (no building)',
                'query' => "SELECT COUNT(*) FROM {$tables['units']} u 
                           LEFT JOIN {$tables['buildings']} b ON u.building_id = b.id 
                           WHERE b.id IS NULL AND u.building_id IS NOT NULL",
            ),
            array(
                'name' => 'Orphaned leases (no unit)',
                'query' => "SELECT COUNT(*) FROM {$tables['leases']} l 
                           LEFT JOIN {$tables['units']} u ON l.unit_id = u.id 
                           WHERE u.id IS NULL",
            ),
            array(
                'name' => 'Orphaned payments (no tenant)',
                'query' => "SELECT COUNT(*) FROM {$tables['payments']} p 
                           LEFT JOIN {$tables['tenants']} t ON p.tenant_id = t.id 
                           WHERE t.id IS NULL AND p.tenant_id IS NOT NULL",
            ),
            array(
                'name' => 'Orphaned work orders (no building)',
                'query' => "SELECT COUNT(*) FROM {$tables['work_orders']} w 
                           LEFT JOIN {$tables['buildings']} b ON w.building_id = b.id 
                           WHERE b.id IS NULL AND w.building_id IS NOT NULL",
            ),
        );
        
        foreach ($checks as $check) {
            $table_check = explode(' FROM ', $check['query']);
            if (count($table_check) > 1) {
                preg_match('/^([^\s]+)/', trim($table_check[1]), $matches);
                if (!empty($matches[1])) {
                    $exists = $wpdb->get_var("SHOW TABLES LIKE '{$matches[1]}'");
                    if (!$exists) continue;
                }
            }
            
            $count = $wpdb->get_var($check['query']);
            if ($count > 0) {
                $issues[] = array(
                    'type' => 'orphaned',
                    'name' => $check['name'],
                    'count' => intval($count),
                );
            }
        }
        
        return array(
            'issues' => $issues,
            'clean' => empty($issues),
        );
    }
    
    /**
     * Run health check
     */
    public static function health_check() {
        $health = array(
            'version' => defined('RENTAL_GATES_VERSION') ? RENTAL_GATES_VERSION : 'unknown',
            'wordpress' => get_bloginfo('version'),
            'php' => PHP_VERSION,
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
        );
        
        // Check WordPress requirements
        $health['checks'] = array();
        
        // PHP version
        $health['checks']['php_version'] = array(
            'status' => version_compare(PHP_VERSION, '7.4', '>=') ? 'pass' : 'fail',
            'message' => 'PHP 7.4+ required',
            'value' => PHP_VERSION,
        );
        
        // WordPress version
        $health['checks']['wp_version'] = array(
            'status' => version_compare(get_bloginfo('version'), '5.8', '>=') ? 'pass' : 'fail',
            'message' => 'WordPress 5.8+ required',
            'value' => get_bloginfo('version'),
        );
        
        // REST API
        $health['checks']['rest_api'] = array(
            'status' => !empty(rest_url()) ? 'pass' : 'fail',
            'message' => 'REST API enabled',
            'value' => rest_url() ? 'enabled' : 'disabled',
        );
        
        // Database
        global $wpdb;
        $health['checks']['database'] = array(
            'status' => !empty($wpdb->prefix) ? 'pass' : 'fail',
            'message' => 'Database connection',
            'value' => $wpdb->prefix,
        );
        
        // File permissions
        $upload_dir = wp_upload_dir();
        $health['checks']['uploads'] = array(
            'status' => wp_is_writable($upload_dir['basedir']) ? 'pass' : 'warning',
            'message' => 'Uploads writable',
            'value' => wp_is_writable($upload_dir['basedir']) ? 'yes' : 'no',
        );
        
        return $health;
    }
}
